"""Secure deterministic standalone HTML renderer for experiment reports."""

# ruff: noqa: E501

from __future__ import annotations

import json
import math
from collections.abc import Mapping, Sequence
from html import escape
from typing import Any, cast

from cascaqit.native_ir.base import stable_json
from cascaqit.visualization.experiment import ExperimentReportIR, ExperimentSectionIR
from cascaqit.visualization.report_bokeh import (
    inline_bokeh_resources_html,
    render_counts_bokeh_html,
    render_gradient_history_bokeh_html,
    render_objective_history_bokeh_html,
    render_parameter_history_bokeh_html,
    render_problem_comparison_bokeh_html,
    render_problem_metrics_bokeh_html,
    render_pulse_bokeh_html,
    render_register_bokeh_html,
    render_repeated_layer_statistics_bokeh_html,
    render_trend_bokeh_html,
)

__all__ = ["render_experiment_report_html"]

_SERIES_COLORS = (
    "var(--series-1)",
    "var(--series-2)",
    "var(--series-3)",
    "var(--series-4)",
    "var(--series-5)",
    "var(--series-6)",
)

_ZH_TRANSLATIONS = {
    "CASCAQit experiment report": "\u0043\u0041\u0053\u0043\u0041\u0051\u0069\u0074 \u5b9e\u9a8c\u62a5\u544a",
    "Language": "\u8bed\u8a00",
    "Profile": "\u62a5\u544a\u7c7b\u578b",
    "Lifecycle stages": "\u751f\u547d\u5468\u671f\u9636\u6bb5",
    "Sources": "\u6570\u636e\u6e90",
    "Report hash": "\u62a5\u544a\u54c8\u5e0c",
    "Design": "\u8bbe\u8ba1",
    "Validate": "\u6821\u9a8c",
    "Plan / compile": "\u8ba1\u5212 / \u7f16\u8bd1",
    "Execute": "\u6267\u884c",
    "State / noise": "\u72b6\u6001 / \u566a\u58f0",
    "Measure": "\u6d4b\u91cf",
    "Analyze / compare": "\u5206\u6790 / \u5bf9\u6bd4",
    "Experiment design": "\u5b9e\u9a8c\u8bbe\u8ba1",
    "Digital experiment design": "\u6570\u5b57\u5b9e\u9a8c\u8bbe\u8ba1",
    "Analog experiment design": "\u6a21\u62df\u5b9e\u9a8c\u8bbe\u8ba1",
    "Hybrid experiment design": "\u6df7\u5408\u5b9e\u9a8c\u8bbe\u8ba1",
    "Validation and diagnostics": "\u6821\u9a8c\u4e0e\u8bca\u65ad",
    "Validation and alignment": "\u6821\u9a8c\u4e0e\u5bf9\u9f50",
    "Plan and compile": "\u8ba1\u5212\u4e0e\u7f16\u8bd1",
    "Execution": "\u6267\u884c",
    "State and noise": "\u72b6\u6001\u4e0e\u566a\u58f0",
    "Measurement": "\u6d4b\u91cf",
    "Analysis": "\u5206\u6790",
    "Measurement comparison": "\u6d4b\u91cf\u5bf9\u6bd4",
    "Analysis comparison": "\u5206\u6790\u5bf9\u6bd4",
    "Sweep parameters": "\u626b\u63cf\u53c2\u6570",
    "Sweep resource plan": "\u626b\u63cf\u8d44\u6e90\u8ba1\u5212",
    "Sweep execution": "\u626b\u63cf\u6267\u884c",
    "State, noise, and result references": "\u72b6\u6001\u3001\u566a\u58f0\u4e0e\u7ed3\u679c\u5f15\u7528",
    "Measurement trends": "\u6d4b\u91cf\u8d8b\u52bf",
    "Observable trends": "\u89c2\u6d4b\u91cf\u8d8b\u52bf",
    "Batch inputs": "\u6279\u5904\u7406\u8f93\u5165",
    "Batch plan": "\u6279\u5904\u7406\u8ba1\u5212",
    "Batch execution": "\u6279\u5904\u7406\u6267\u884c",
    "Item result references": "\u6761\u76ee\u7ed3\u679c\u5f15\u7528",
    "Batch measurement summary": "\u6279\u5904\u7406\u6d4b\u91cf\u6458\u8981",
    "Atom arrangement": "\u539f\u5b50\u6392\u5217",
    "Control waveforms": "\u63a7\u5236\u6ce2\u5f62",
    "Site addressing timeline": "\u5c40\u90e8\u5bfb\u5740\u65f6\u95f4\u7ebf",
    "Dynamic addressing consumers": "\u52a8\u6001\u5bfb\u5740\u6570\u503c\u6267\u884c\u8bc1\u636e",
    "Register snapshot": "\u539f\u5b50\u9635\u5217\u5feb\u7167",
    "Site phase patterns": "\u4f4d\u70b9\u76f8\u4f4d\u6a21\u5f0f",
    "Site phase pattern consumers": "\u4f4d\u70b9\u76f8\u4f4d\u6570\u503c\u6267\u884c\u8bc1\u636e",
    "Control schedules": "\u63a7\u5236\u8c03\u5ea6",
    "Control constraint diagnostics": "\u63a7\u5236\u7ea6\u675f\u8bca\u65ad",
    "Rabi": "\u62c9\u6bd4",
    "Detuning": "\u5931\u8c10",
    "Phase": "\u76f8\u4f4d",
    "Filled": "\u5df2\u586b\u5145",
    "Empty": "\u7a7a\u4f4d",
    "Vacant": "\u7a7a\u7f3a",
    "Defect": "\u7f3a\u9677",
    "Loading failed": "\u88c5\u8f7d\u5931\u8d25",
    "Measurement distribution": "\u6d4b\u91cf\u5206\u5e03",
    "Resource usage": "\u8d44\u6e90\u4f7f\u7528",
    "Diagnostics": "\u8bca\u65ad",
    "Source facts and provenance": "\u6e90\u4e8b\u5b9e\u4e0e\u6eaf\u6e90",
    "Source paths": "\u6e90\u8def\u5f84",
    "Source identity": "\u6570\u636e\u6e90\u8eab\u4efd",
    "Source": "\u6570\u636e\u6e90",
    "Metric": "\u6307\u6807",
    "Value": "\u503c",
    "Measurement status": "\u6d4b\u91cf\u72b6\u6001",
    "Measurement scope": "\u6d4b\u91cf\u8303\u56f4",
    "Wall time": "\u5899\u949f\u65f6\u95f4",
    "Estimated peak memory": "\u9884\u4f30\u5cf0\u503c\u5185\u5b58",
    "Actual peak RSS": "\u5b9e\u9645\u5cf0\u503c\u5e38\u9a7b\u5185\u5b58",
    "Baseline peak RSS": "\u57fa\u7ebf\u5cf0\u503c\u5e38\u9a7b\u5185\u5b58",
    "Incremental peak RSS": "\u589e\u91cf\u5cf0\u503c\u5e38\u9a7b\u5185\u5b58",
    "Estimate error": "\u4f30\u7b97\u8bef\u5dee",
    "Estimate within tolerance": "\u4f30\u7b97\u662f\u5426\u5728\u5bb9\u5dee\u5185",
    "RSS semantics": "\u5e38\u9a7b\u5185\u5b58\u8bed\u4e49",
    "Target id": "\u76ee\u6807\u6807\u8bc6",
    "Truthfulness": "\u771f\u5b9e\u6027",
    "Measurement fact": "\u6d4b\u91cf\u4e8b\u5b9e",
    "Shots": "\u91c7\u6837\u6b21\u6570",
    "Bit ordering": "\u6bd4\u7279\u987a\u5e8f",
    "Occupation encoding": "\u5360\u636e\u7f16\u7801",
    "Observable": "\u89c2\u6d4b\u91cf",
    "Candidate": "\u5019\u9009\u9879",
    "Delta": "\u5dee\u503c",
    "Index": "\u7d22\u5f15",
    "Parameters": "\u53c2\u6570",
    "State": "\u72b6\u6001",
    "Counts": "\u8ba1\u6570",
    "Status": "\u72b6\u6001",
    "Result / job": "\u7ed3\u679c / \u4efb\u52a1",
    "Block": "\u5757",
    "Type": "\u7c7b\u578b",
    "Input state": "\u8f93\u5165\u72b6\u6001",
    "Output state": "\u8f93\u51fa\u72b6\u6001",
    "Control": "\u63a7\u5236",
    "Frame": "\u5e27",
    "Frames": "\u5e27\u6570",
    "Interval": "\u65f6\u95f4\u533a\u95f4",
    "Active sites / weights": "\u6fc0\u6d3b\u4f4d\u70b9 / \u6743\u91cd",
    "Addressing hash": "\u5bfb\u5740\u54c8\u5e0c",
    "Consumer": "\u6570\u503c\u6267\u884c\u8005",
    "Duration": "\u6301\u7eed\u65f6\u95f4",
    "All off": "\u5168\u90e8\u5173\u95ed",
    "Severity": "\u4e25\u91cd\u7a0b\u5ea6",
    "Code": "\u4ee3\u7801",
    "Stage": "\u9636\u6bb5",
    "Message": "\u6d88\u606f",
    "Available": "\u53ef\u7528",
    "Unavailable": "\u4e0d\u53ef\u7528",
    "available": "\u53ef\u7528",
    "unavailable": "\u4e0d\u53ef\u7528",
    "completed": "\u5df2\u5b8c\u6210",
    "warning": "\u8b66\u544a",
    "running": "\u8fd0\u884c\u4e2d",
    "queued": "\u5df2\u6392\u961f",
    "cancelled": "\u5df2\u53d6\u6d88",
    "error": "\u9519\u8bef",
    "failed": "\u5931\u8d25",
    "stable": "\u7a33\u5b9a",
    "unstable": "\u4e0d\u7a33\u5b9a",
    "insufficient_evidence": "\u8bc1\u636e\u4e0d\u8db3",
    "thresholds_not_met": "\u672a\u6ee1\u8db3\u7a33\u5b9a\u9608\u503c",
    "stability_reached": "\u5df2\u6ee1\u8db3\u7a33\u5b9a\u9608\u503c",
    "passed": "\u901a\u8fc7",
    "VQE stability and stopping diagnosis": "VQE \u7a33\u5b9a\u6027\u4e0e\u505c\u6b62\u8bca\u65ad",
    "VQE stability thresholds": "VQE \u7a33\u5b9a\u6027\u9608\u503c",
    "Thresholds diagnose a saved terminal window. They do not alter the optimizer or prove convergence.": "\u9608\u503c\u53ea\u8bca\u65ad\u5df2\u4fdd\u5b58\u7684\u672b\u7aef\u7a97\u53e3\uff0c\u4e0d\u4f1a\u6539\u53d8\u4f18\u5316\u5668\uff0c\u4e5f\u4e0d\u8bc1\u660e\u6536\u655b\u3002",
    "Window size": "\u7a97\u53e3\u5927\u5c0f",
    "Min iterations": "\u6700\u5c11\u8fed\u4ee3\u6570",
    "Objective range tolerance": "\u76ee\u6807\u8303\u56f4\u5bb9\u5dee",
    "Minimum iterations": "\u6700\u5c11\u8fed\u4ee3\u6570",
    "Update norm tolerance": "\u66f4\u65b0\u6a21\u957f\u5bb9\u5dee",
    "Gradient norm tolerance": "\u68af\u5ea6\u6a21\u957f\u5bb9\u5dee",
    "Sampled standard error tolerance": "\u91c7\u6837\u6807\u51c6\u8bef\u5dee\u5bb9\u5dee",
    "Gradient standard error norm tolerance": "\u68af\u5ea6\u6807\u51c6\u8bef\u5dee\u6a21\u957f\u5bb9\u5dee",
    "Stopping status": "\u505c\u6b62\u8bc1\u636e\u72b6\u6001",
    "Window iterations": "\u7a97\u53e3\u8fed\u4ee3",
    "Objective proxies": "\u76ee\u6807\u4ee3\u7406\u503c",
    "Final center objective": "\u6700\u7ec8\u4e2d\u5fc3\u70b9\u76ee\u6807\u503c",
    "Check": "\u68c0\u67e5\u9879",
    "Per-start stopping context": "\u9010 start \u505c\u6b62\u4e0a\u4e0b\u6587",
    "Selected-start stability diagnosis": "\u9009\u4e2d start \u7a33\u5b9a\u6027\u8bca\u65ad",
    "Terminal objective center proxies": "\u672b\u7aef\u76ee\u6807\u4e2d\u5fc3\u4ee3\u7406\u503c",
    "Sampled uncertainty and repeats": "\u91c7\u6837\u4e0d\u786e\u5b9a\u5ea6\u4e0e repeats",
    "Evaluator": "\u8bc4\u4f30\u5668",
    "Iterations": "\u8fed\u4ee3\u6570",
    "Termination": "\u505c\u6b62\u539f\u56e0",
    "Evaluations / limit": "\u76ee\u6807\u6c42\u503c / \u4e0a\u9650",
    "Backend executions / limit": "Backend \u6267\u884c / \u4e0a\u9650",
    "Observed": "\u89c2\u6d4b\u503c",
    "Threshold": "\u9608\u503c",
    "Samples": "\u6837\u672c\u6570",
    "Standard errors": "\u6807\u51c6\u8bef\u5dee",
    "Repeat stop reasons": "repeat \u505c\u6b62\u539f\u56e0",
    "Yes": "\u662f",
    "No": "\u5426",
    "Measured": "\u5df2\u6d4b\u91cf",
    "Job": "\u4efb\u52a1",
    "No count outcomes available.": "\u6ca1\u6709\u53ef\u7528\u7684\u8ba1\u6570\u7ed3\u679c\u3002",
    "No standard resource measurements are available.": "\u6ca1\u6709\u53ef\u7528\u7684\u6807\u51c6\u8d44\u6e90\u6d4b\u91cf\u3002",
    "Structured resource usage is unavailable.": "\u7ed3\u6784\u5316\u8d44\u6e90\u4f7f\u7528\u6570\u636e\u4e0d\u53ef\u7528\u3002",
    "Offline deterministic derived view. No backend, network, or artifact-byte access.": "\u79bb\u7ebf\u786e\u5b9a\u6027\u6d3e\u751f\u89c6\u56fe\uff1b\u4e0d\u8bbf\u95ee\u540e\u7aef\u3001\u7f51\u7edc\u6216\u4ea7\u7269\u5b57\u8282\u3002",
    "Complete physical Hybrid experiment": "\u5b8c\u6574\u7269\u7406\u566a\u58f0\u6df7\u5408\u5b9e\u9a8c",
    "Algorithm and Hamiltonian design": "\u7b97\u6cd5\u4e0e\u54c8\u5bc6\u987f\u91cf\u8bbe\u8ba1",
    "Sampled VQE energy": "VQE \u6709\u9650 shots \u80fd\u91cf",
    "Hamiltonian and source Circuit": "\u54c8\u5bc6\u987f\u91cf\u4e0e\u6e90\u7ebf\u8def",
    "Measurement evidence consistency": "\u6d4b\u91cf\u8bc1\u636e\u4e00\u81f4\u6027",
    "QWC measurement plan": "QWC \u6d4b\u91cf\u8ba1\u5212",
    "Measurement group execution": "\u6d4b\u91cf\u7ec4\u6267\u884c",
    "Pauli expectations and energy contributions": "Pauli \u671f\u671b\u503c\u4e0e\u80fd\u91cf\u8d21\u732e",
    "Grouped counts and covariance-aware uncertainty": "\u5206\u7ec4\u8ba1\u6570\u4e0e\u534f\u65b9\u5dee\u611f\u77e5\u4e0d\u786e\u5b9a\u5ea6",
    "Sampled energy estimate": "\u6709\u9650 shots \u80fd\u91cf\u4f30\u8ba1",
    "Source Circuit": "\u6e90\u7ebf\u8def",
    "QWC measurement groups": "QWC \u6d4b\u91cf\u7ec4",
    "Measurement contract": "\u6d4b\u91cf\u5951\u7ea6",
    "Measurement group Jobs": "\u6d4b\u91cf\u7ec4\u4efb\u52a1",
    "Pauli expectations": "Pauli \u671f\u671b\u503c",
    "Raw Pauli expectations": "Raw Pauli \u671f\u671b\u503c",
    "Mitigated Pauli expectations": "\u7f13\u89e3\u540e Pauli \u671f\u671b\u503c",
    "Energy assembly": "\u80fd\u91cf\u7ec4\u88c5",
    "Local basis": "\u5c40\u90e8\u6d4b\u91cf\u57fa",
    "Term indices": "\u9879\u7d22\u5f15",
    "Term expectations": "\u5404\u9879\u671f\u671b\u503c",
    "Term standard errors": "\u5404\u9879\u6807\u51c6\u8bef\u5dee",
    "Initial shots": "\u521d\u59cb shots",
    "Final shots": "\u6700\u7ec8 shots",
    "Pilot shots": "Pilot shots",
    "Additional shots": "\u8865\u5145 shots",
    "Pilot group shots": "\u5404\u7ec4 pilot shots",
    "Final group shots": "\u5404\u7ec4\u6700\u7ec8 shots",
    "Results": "\u7ed3\u679c",
    "seeds": "seeds",
    "Sampled energy": "\u6709\u9650 shots \u80fd\u91cf",
    "Energy standard error": "\u80fd\u91cf\u6807\u51c6\u8bef\u5dee",
    "Hamiltonian constant": "\u54c8\u5bc6\u987f\u91cf\u5e38\u6570\u9879",
    "Measurement group energy sum": "\u6d4b\u91cf\u7ec4\u80fd\u91cf\u4e4b\u548c",
    "Raw energy": "Raw \u80fd\u91cf",
    "Mitigated energy": "\u7f13\u89e3\u540e\u80fd\u91cf",
    "Raw standard error": "Raw \u6807\u51c6\u8bef\u5dee",
    "Mitigated standard error": "\u7f13\u89e3\u540e\u6807\u51c6\u8bef\u5dee",
    "Mitigated group energy": "\u7f13\u89e3\u540e\u5206\u7ec4\u80fd\u91cf",
    "Variance amplification": "\u65b9\u5dee\u653e\u5927\u500d\u6570",
    "Readout mitigation": "\u8bfb\u51fa\u8bef\u5dee\u7f13\u89e3",
    "Calibration source": "\u6821\u51c6\u6765\u6e90",
    "Calibration hash": "\u6821\u51c6\u54c8\u5e0c",
    "Condition numbers": "\u6761\u4ef6\u6570",
    "Total condition number": "\u603b\u6761\u4ef6\u6570",
    "Condition number limit": "\u6761\u4ef6\u6570\u4e0a\u9650",
    "raw energy": "raw \u80fd\u91cf",
    "mitigated energy": "\u7f13\u89e3\u540e\u80fd\u91cf",
    "mitigated group energy": "\u7f13\u89e3\u540e\u5206\u7ec4\u80fd\u91cf",
    "mitigated standard error": "\u7f13\u89e3\u540e\u6807\u51c6\u8bef\u5dee",
    "variance amplification": "\u65b9\u5dee\u653e\u5927\u500d\u6570",
    "Interval method": "\u533a\u95f4\u4f30\u8ba1\u65b9\u6cd5",
    "Evaluation scope": "\u8bc4\u4f30\u8303\u56f4",
    "This is a fixed-parameter sampled estimate. It does not claim a global optimum or quantum advantage.": "\u8fd9\u662f\u56fa\u5b9a\u53c2\u6570\u70b9\u7684\u6709\u9650 shots \u4f30\u8ba1\uff0c\u4e0d\u58f0\u79f0\u5168\u5c40\u6700\u4f18\u6216\u91cf\u5b50\u4f18\u52bf\u3002",
    "Workflow consistency": "\u5de5\u4f5c\u6d41\u4e00\u81f4\u6027",
    "Ansatz and optimizer plan": "\u62df\u8bbe\u4e0e\u4f18\u5316\u5668\u8ba1\u5212",
    "Optimization execution": "\u4f18\u5316\u6267\u884c",
    "Objective state evidence": "\u76ee\u6807\u51fd\u6570\u72b6\u6001\u8bc1\u636e",
    "Final sampling": "\u6700\u7ec8\u91c7\u6837",
    "Candidate and baseline analysis": "\u5019\u9009\u89e3\u4e0e\u57fa\u7ebf\u5206\u6790",
    "Hamiltonian terms": "\u54c8\u5bc6\u987f\u91cf\u9879",
    "Objective history": "\u76ee\u6807\u51fd\u6570\u5386\u53f2",
    "Gradient plan": "\u68af\u5ea6\u8ba1\u5212",
    "Gradient history": "\u68af\u5ea6\u5386\u53f2",
    "Gradient cost": "\u68af\u5ea6\u6210\u672c",
    "Gradient components": "\u68af\u5ea6\u5206\u91cf",
    "Shift evidence": "\u504f\u79fb\u8bc1\u636e",
    "Gradient callback": "\u68af\u5ea6\u56de\u8c03",
    "L2 norm": "L2 \u8303\u6570",
    "Occurrences": "\u95e8\u53c2\u6570\u51fa\u73b0\u6b21\u6570",
    "occurrences": "\u95e8\u53c2\u6570\u51fa\u73b0\u6b21\u6570",
    "Shift Jobs": "\u504f\u79fb\u4efb\u52a1",
    "shift Jobs": "\u504f\u79fb\u4efb\u52a1",
    "Backend executions": "Backend \u6267\u884c\u6b21\u6570",
    "Backend executions per gradient": "\u6bcf\u6b21\u68af\u5ea6\u7684 Backend \u6267\u884c\u6b21\u6570",
    "Occurrence": "\u95e8\u53c2\u6570\u4f4d\u7f6e",
    "Gate index": "\u95e8\u5e8f\u53f7",
    "Gate": "\u91cf\u5b50\u95e8",
    "Affine offset": "\u4eff\u5c04\u504f\u7f6e",
    "Coefficients": "\u7cfb\u6570",
    "Gradient occurrences": "\u68af\u5ea6\u95e8\u53c2\u6570\u4f4d\u7f6e",
    "method": "\u65b9\u6cd5",
    "shift": "\u504f\u79fb\u91cf",
    "Positive energy": "\u6b63\u504f\u79fb\u80fd\u91cf",
    "Negative energy": "\u8d1f\u504f\u79fb\u80fd\u91cf",
    "Energy difference": "\u80fd\u91cf\u5dee",
    "Gate derivative": "\u95e8\u5bfc\u6570",
    "Gradient uncertainty": "\u68af\u5ea6\u4e0d\u786e\u5b9a\u5ea6",
    "Gradient uncertainty norm": "\u68af\u5ea6\u4e0d\u786e\u5b9a\u5ea6\u6a21\u957f",
    "Gradient uncertainty target": "\u68af\u5ea6\u4e0d\u786e\u5b9a\u5ea6\u76ee\u6807",
    "Uncertainty target status": "\u4e0d\u786e\u5b9a\u5ea6\u76ee\u6807\u72b6\u6001",
    "Repeat mode": "\u91cd\u590d\u6a21\u5f0f",
    "Actual / configured repeats": "\u5b9e\u9645 / \u914d\u7f6e\u91cd\u590d\u6b21\u6570",
    "Minimum repeats": "\u6700\u5c11\u91cd\u590d\u6b21\u6570",
    "Maximum repeats": "\u6700\u5927\u91cd\u590d\u6b21\u6570",
    "Repeat stop reason": "\u91cd\u590d\u505c\u6b62\u539f\u56e0",
    "Backend execution limit": "Backend \u6267\u884c\u4e0a\u9650",
    "repeat mode": "\u91cd\u590d\u6a21\u5f0f",
    "minimum repeats": "\u6700\u5c11\u91cd\u590d\u6b21\u6570",
    "maximum repeats": "\u6700\u5927\u91cd\u590d\u6b21\u6570",
    "gradient uncertainty norm": "\u68af\u5ea6\u4e0d\u786e\u5b9a\u5ea6\u6a21\u957f",
    "gradient uncertainty target": "\u68af\u5ea6\u4e0d\u786e\u5b9a\u5ea6\u76ee\u6807",
    "uncertainty target status": "\u4e0d\u786e\u5b9a\u5ea6\u76ee\u6807\u72b6\u6001",
    "repeat stop reason": "\u91cd\u590d\u505c\u6b62\u539f\u56e0",
    "Per-repeat shift evidence": "\u9010\u6b21\u91cd\u590d\u504f\u79fb\u8bc1\u636e",
    "Pooled shift evidence": "\u6c60\u5316\u504f\u79fb\u8bc1\u636e",
    "Repeat hash": "\u91cd\u590d\u54c8\u5e0c",
    "Pair hash": "\u504f\u79fb\u5bf9\u54c8\u5e0c",
    "Positive evaluation": "\u6b63\u504f\u79fb\u8bc4\u4f30",
    "Negative evaluation": "\u8d1f\u504f\u79fb\u8bc4\u4f30",
    "Derivative variance": "\u5bfc\u6570\u65b9\u5dee",
    "gradient standard errors": "\u68af\u5ea6\u6807\u51c6\u8bef\u5dee",
    "Gradient covariance and correlation": "\u68af\u5ea6\u534f\u65b9\u5dee\u4e0e\u76f8\u5173\u7cfb\u6570",
    "Covariance": "\u534f\u65b9\u5dee",
    "Correlation": "\u76f8\u5173\u7cfb\u6570",
    "Parameter pair": "\u53c2\u6570\u5bf9",
    "Positive energy standard error": "\u6b63\u504f\u79fb\u80fd\u91cf\u6807\u51c6\u8bef\u5dee",
    "Negative energy standard error": "\u8d1f\u504f\u79fb\u80fd\u91cf\u6807\u51c6\u8bef\u5dee",
    "Derivative standard error": "\u5bfc\u6570\u6807\u51c6\u8bef\u5dee",
    "gradient shots": "\u68af\u5ea6 shots",
    "Workflow cost ledger": "\u5de5\u4f5c\u6d41\u6210\u672c\u5206\u8d26",
    "Cost category": "\u6210\u672c\u7c7b\u522b",
    "total Backend executions": "Backend \u603b\u6267\u884c\u6b21\u6570",
    "Adam update trajectory": "Adam \u66f4\u65b0\u8f68\u8ff9",
    "Adam iterations": "Adam \u8fed\u4ee3\u6b21\u6570",
    "Adam second moment is optimizer state, not sampled-gradient variance. Statistical uncertainty is reported by gradient covariance and standard error.": "Adam \u4e8c\u9636\u77e9\u662f\u4f18\u5316\u5668\u72b6\u6001\uff0c\u4e0d\u662f\u91c7\u6837\u68af\u5ea6\u65b9\u5dee\u3002\u7edf\u8ba1\u4e0d\u786e\u5b9a\u5ea6\u7531\u68af\u5ea6\u534f\u65b9\u5dee\u548c\u6807\u51c6\u8bef\u5dee\u8868\u793a\u3002",
    "Center objective": "\u66f4\u65b0\u524d\u76ee\u6807\u503c",
    "Updated objective": "\u66f4\u65b0\u540e\u76ee\u6807\u503c",
    "First moment": "\u4e00\u9636\u77e9",
    "Second moment": "\u4e8c\u9636\u77e9",
    "Bias-corrected first moment": "\u504f\u5dee\u4fee\u6b63\u4e00\u9636\u77e9",
    "Bias-corrected second moment": "\u504f\u5dee\u4fee\u6b63\u4e8c\u9636\u77e9",
    "Step": "\u66f4\u65b0\u6b65\u957f",
    "Updated parameters": "\u66f4\u65b0\u540e\u53c2\u6570",
    "Bounds projection": "\u8fb9\u754c\u6295\u5f71",
    "Gradient repeats": "\u68af\u5ea6\u91cd\u590d\u6b21\u6570",
    "Gradient repeat stop": "\u68af\u5ea6\u91cd\u590d\u505c\u6b62\u539f\u56e0",
    "Window update norms": "\u7a97\u53e3\u66f4\u65b0\u6a21\u957f",
    "Window gradient uncertainty": "\u7a97\u53e3\u68af\u5ea6\u4e0d\u786e\u5b9a\u5ea6",
    "Window gradient repeats": "\u7a97\u53e3\u68af\u5ea6\u91cd\u590d\u6b21\u6570",
    "Window repeat stop reasons": "\u7a97\u53e3\u91cd\u590d\u505c\u6b62\u539f\u56e0",
    "Adam termination and stopping": "Adam \u7ec8\u6b62\u4e0e\u505c\u6b62\u8bc1\u636e",
    "Stopping evidence": "\u505c\u6b62\u8bc1\u636e",
    "Observed energy": "\u89c2\u6d4b\u80fd\u91cf",
    "Observed best energy": "\u89c2\u6d4b\u6700\u4f4e\u80fd\u91cf",
    "Observed best evaluation": "\u89c2\u6d4b\u6700\u4f4e\u8bc4\u4f30",
    "Final selected energy": "\u6700\u7ec8\u9009\u4e2d\u80fd\u91cf",
    "Final selected evaluation": "\u6700\u7ec8\u9009\u4e2d\u8bc4\u4f30",
    "Running best": "\u5386\u53f2\u6700\u4f18\u503c",
    "Best observed": "\u6700\u4f73\u89c2\u6d4b",
    "Independent candidate confirmation": "\u5019\u9009\u53c2\u6570\u72ec\u7acb\u786e\u8ba4",
    "Source evaluation": "\u6765\u6e90\u8bc4\u4f30",
    "Confirmation mean": "\u786e\u8ba4\u5747\u503c",
    "Lowest confirmation mean": "\u6700\u4f4e\u786e\u8ba4\u5747\u503c",
    "Selected candidate": "\u9009\u4e2d\u5019\u9009",
    "Repeats": "\u91cd\u590d\u6b21\u6570",
    "Selection status": "\u9009\u62e9\u72b6\u6001",
    "Candidates": "\u5019\u9009\u6570",
    "Confirmation shots": "\u786e\u8ba4 shots",
    "Confirmation Backend executions": "\u786e\u8ba4 Backend \u6267\u884c\u6b21\u6570",
    "Runner-up": "\u6b21\u4f18\u5019\u9009",
    "Mean difference": "\u5747\u503c\u5dee",
    "Difference standard error": "\u5dee\u503c\u6807\u51c6\u8bef\u5dee",
    "Difference interval": "\u5dee\u503c\u533a\u95f4",
    "Confirmation looks": "\u786e\u8ba4\u8f6e\u6b21",
    "Look": "\u8f6e\u6b21",
    "Measured candidates": "\u672c\u8f6e\u6d4b\u91cf\u5019\u9009",
    "Repeat counts": "\u7d2f\u8ba1\u91cd\u590d\u6b21\u6570",
    "Selected": "\u9009\u4e2d\u5019\u9009",
    "Shots (look / cumulative)": "shots\uff08\u672c\u8f6e / \u7d2f\u8ba1\uff09",
    "Backend executions (look / cumulative)": "Backend \u6267\u884c\uff08\u672c\u8f6e / \u7d2f\u8ba1\uff09",
    "confirmation mode": "\u786e\u8ba4\u6a21\u5f0f",
    "selection status": "\u9009\u62e9\u72b6\u6001",
    "actual / planned looks": "\u5b9e\u9645 / \u8ba1\u5212\u8f6e\u6b21",
    "nominal confidence": "\u540d\u4e49\u7f6e\u4fe1\u5ea6",
    "decision confidence": "\u51b3\u7b56\u7f6e\u4fe1\u5ea6",
    "candidates": "\u5019\u9009\u6570",
    "shots per group": "\u6bcf\u7ec4 shots",
    "allocation": "\u5206\u914d\u7b56\u7565",
    "confirmation Backend executions": "\u786e\u8ba4 Backend \u6267\u884c\u6b21\u6570",
    "selected candidate": "\u9009\u4e2d\u5019\u9009",
    "runner-up": "\u6bd4\u8f83\u5019\u9009",
    "mean difference": "\u5747\u503c\u5dee",
    "difference standard error": "\u5dee\u503c\u6807\u51c6\u8bef\u5dee",
    "difference interval": "\u5dee\u503c\u533a\u95f4",
    "fixed": "\u56fa\u5b9a",
    "sequential": "\u987a\u5e8f",
    "separated": "\u5df2\u5206\u79bb",
    "inconclusive": "\u672a\u80fd\u533a\u5206",
    "single_candidate": "\u5355\u4e00\u5019\u9009",
    "fixed_repeats_complete": "\u56fa\u5b9a\u91cd\u590d\u5df2\u5b8c\u6210",
    "fixed_repeats": "\u56fa\u5b9a\u91cd\u590d\u5df2\u5b8c\u6210",
    "target_reached": "\u5df2\u8fbe\u4e0d\u786e\u5b9a\u5ea6\u76ee\u6807",
    "confidence_separated": "\u7f6e\u4fe1\u533a\u95f4\u5df2\u5206\u79bb",
    "max_repeats_reached": "\u5df2\u8fbe\u91cd\u590d\u4e0a\u9650",
    "evaluation_budget_exhausted": "\u76ee\u6807\u6c42\u503c\u9884\u7b97\u4e0d\u8db3",
    "backend_budget_exhausted": "Backend \u9884\u7b97\u4e0d\u8db3",
    "reached": "\u5df2\u8fbe\u6807",
    "not_reached": "\u672a\u8fbe\u6807",
    "not_configured": "\u672a\u914d\u7f6e",
    "threshold_not_met": "\u672a\u6ee1\u8db3\u9608\u503c",
    "Classical baseline": "\u7ecf\u5178\u57fa\u7ebf",
    "Most probable candidate": "\u6700\u9ad8\u6982\u7387\u5019\u9009\u89e3",
    "Best observed candidate": "\u6700\u4f73\u89c2\u6d4b\u5019\u9009\u89e3",
    "Problem candidate is not applicable": "\u95ee\u9898\u5019\u9009\u89e3\u4e0d\u9002\u7528",
    "Classical baseline is not applicable": "\u7ecf\u5178\u57fa\u7ebf\u4e0d\u9002\u7528",
    "Optimizer configuration": "\u4f18\u5316\u5668\u914d\u7f6e",
    "Ansatz contract": "Ansatz \u5951\u7ea6",
    "Ansatz kind": "Ansatz \u7c7b\u578b",
    "Parameter count": "\u53c2\u6570\u6570\u91cf",
    "Required gates": "\u6240\u9700\u91cf\u5b50\u95e8",
    "Layer transfer": "\u5c42\u95f4\u53c2\u6570\u8fc1\u79fb",
    "Circuit hash": "\u7ebf\u8def\u54c8\u5e0c",
    "Spec hash": "\u5951\u7ea6\u54c8\u5e0c",
    "Definition": "\u5b9a\u4e49",
    "Consistency checks": "\u4e00\u81f4\u6027\u68c0\u67e5",
    "Hamiltonian contributions": "\u54c8\u5bc6\u987f\u91cf\u8d21\u732e",
    "Candidate gap": "\u5019\u9009\u89e3\u5dee\u8ddd",
    "Fixed-cardinality subspace": "\u56fa\u5b9a\u57fa\u6570\u5b50\u7a7a\u95f4",
    "Fixed-cardinality subspace evidence": "\u56fa\u5b9a\u57fa\u6570\u5b50\u7a7a\u95f4\u8bc1\u636e",
    "Group": "\u5206\u7ec4",
    "Qubits": "\u91cf\u5b50\u4f4d",
    "Target weight": "\u76ee\u6807 weight",
    "Preservation rate": "\u4fdd\u6301\u7387",
    "Preserved shots": "\u4fdd\u6301 shots",
    "Violating shots": "\u8fdd\u89c4 shots",
    "Observed weights": "\u5b9e\u9645 weight \u5206\u5e03",
    "observed status": "\u89c2\u6d4b\u72b6\u6001",
    "preservation rate": "\u4fdd\u6301\u7387",
    "evidence source": "\u8bc1\u636e\u6765\u6e90",
    "preserved shots": "\u4fdd\u6301 shots",
    "violating shots": "\u8fdd\u89c4 shots",
    "preserved": "\u5168\u90e8\u4fdd\u6301",
    "violated": "\u53d1\u73b0\u8fdd\u89c4",
    "Ideal and physical-noise comparison": "\u7406\u60f3\u4e0e\u7269\u7406\u566a\u58f0\u5bf9\u6bd4",
    "Ideal Hybrid parameter sweep": "\u7406\u60f3\u6df7\u5408\u53c2\u6570\u626b\u63cf",
    "Physical-noise Hybrid parameter sweep": "\u7269\u7406\u566a\u58f0\u6df7\u5408\u53c2\u6570\u626b\u63cf",
    "Problem and Native Program design": "\u95ee\u9898\u4e0e\u539f\u751f\u7a0b\u5e8f\u8bbe\u8ba1",
    "Feasibility and diagnostics": "\u53ef\u884c\u6027\u4e0e\u8bca\u65ad",
    "Target mapping and compilation": "\u76ee\u6807\u6620\u5c04\u4e0e\u7f16\u8bd1",
    "Bound execution": "\u53c2\u6570\u7ed1\u5b9a\u6267\u884c",
    "Decoded candidates and objective": "\u5019\u9009\u89e3\u89e3\u7801\u4e0e\u76ee\u6807\u503c",
    "Canonical objective": "\u89c4\u8303\u5316\u76ee\u6807\u51fd\u6570",
    "Logical Hamiltonian": "\u903b\u8f91\u54c8\u5bc6\u987f\u91cf",
    "Generated Native Program": "\u751f\u6210\u7684\u539f\u751f\u7a0b\u5e8f",
    "Parameter schema": "\u53c2\u6570\u6a21\u5f0f",
    "Hamiltonian term assignment": "\u54c8\u5bc6\u987f\u91cf\u9879\u5206\u914d",
    "Decoded candidates": "\u5df2\u89e3\u7801\u5019\u9009\u89e3",
    "Term": "\u9879",
    "Kind": "\u7c7b\u578b",
    "Variables": "\u53d8\u91cf",
    "Coefficient": "\u7cfb\u6570",
    "Operator": "\u7b97\u7b26",
    "Targets": "\u76ee\u6807",
    "Mode": "\u6a21\u5f0f",
    "Feasible": "\u53ef\u884c",
    "Energy scale": "\u80fd\u91cf\u5c3a\u5ea6",
    "Parameter": "\u53c2\u6570",
    "Unit": "\u5355\u4f4d",
    "Bounds": "\u53d6\u503c\u8303\u56f4",
    "Compile impact": "\u7f16\u8bd1\u5f71\u54cd",
    "Logical term": "\u903b\u8f91\u9879",
    "Implementation": "\u5b9e\u73b0\u65b9\u5f0f",
    "Logical": "\u903b\u8f91",
    "Analog": "\u6a21\u62df",
    "Digital": "\u6570\u5b57",
    "Bitstring": "\u6bd4\u7279\u4e32",
    "Objective": "\u76ee\u6807\u503c",
    "Probability": "\u6982\u7387",
    "Node weights": "\u8282\u70b9\u6743\u91cd",
    "Node": "\u8282\u70b9",
    "Weight": "\u6743\u91cd",
    "Selected weight": "\u5df2\u9009\u603b\u6743\u91cd",
    "Expected selected weight": "\u671f\u671b\u5df2\u9009\u6743\u91cd",
    "expected selected weight": "\u671f\u671b\u5df2\u9009\u6743\u91cd",
    "Hybrid Problem experiment": "\u6df7\u5408\u95ee\u9898\u5b9e\u9a8c",
    "Analog Problem experiment": "\u6a21\u62df\u95ee\u9898\u5b9e\u9a8c",
    "Digital Problem experiment": "\u6570\u5b57\u95ee\u9898\u5b9e\u9a8c",
    "Problem optimization comparison": "\u95ee\u9898\u4f18\u5316\u5bf9\u6bd4",
    "Problem layer experiment": "\u95ee\u9898\u5c42\u6570\u5b9e\u9a8c",
    "Problem repeated layer experiment": "\u95ee\u9898\u91cd\u590d\u5c42\u6570\u5b9e\u9a8c",
    "VQE repeated layer experiment": "VQE \u91cd\u590d\u5c42\u6570\u5b9e\u9a8c",
    "Repeated statistical layer selection": "\u91cd\u590d\u5b9e\u9a8c\u7edf\u8ba1\u9009\u5c42",
    "Repeated layer statistics": "\u91cd\u590d\u5c42\u6570\u7edf\u8ba1",
    "Repeated VQE execution cost": "VQE \u91cd\u590d\u5b9e\u9a8c\u6267\u884c\u6210\u672c",
    "VQE sampling benchmark configuration": "VQE \u91c7\u6837\u57fa\u51c6\u914d\u7f6e",
    "VQE paired benchmark execution cost": "VQE \u914d\u5bf9\u57fa\u51c6\u6267\u884c\u6210\u672c",
    "VQE sampling strategy statistics": "VQE \u91c7\u6837\u7b56\u7565\u7edf\u8ba1",
    "VQE benchmark strategy definitions": "VQE \u57fa\u51c6\u7b56\u7565\u5b9a\u4e49",
    "VQE paired benchmark execution ledger": "VQE \u914d\u5bf9\u57fa\u51c6\u6267\u884c\u660e\u7ec6",
    "VQE paired benchmark run results": "VQE \u914d\u5bf9\u57fa\u51c6\u8fd0\u884c\u7ed3\u679c",
    "Estimator RMSE": "\u4f30\u8ba1\u5668\u5747\u65b9\u6839\u8bef\u5dee",
    "Estimator error": "\u4f30\u8ba1\u5668\u8bef\u5dee",
    "Paired exact-reference gap": "\u914d\u5bf9\u7cbe\u786e\u53c2\u8003\u5dee\u8ddd",
    "Diagnostic exact Jobs": "\u8bca\u65ad\u7cbe\u786e Job",
    "Selected VQE run": "\u9009\u4e2d\u7684 VQE \u8fd0\u884c",
    "Repeated run completeness": "\u91cd\u590d\u8fd0\u884c\u5b8c\u6574\u6027",
    "Deterministic seed uniqueness": "\u786e\u5b9a\u6027 seed \u552f\u4e00\u6027",
    "Same-repeat layer transfer": "\u540c repeat \u5c42\u95f4\u53c2\u6570\u8fc1\u79fb",
    "Layer statistics and selection history": "\u5c42\u6570\u7edf\u8ba1\u4e0e\u9009\u62e9\u5386\u53f2",
    "Confidence level": "\u7f6e\u4fe1\u6c34\u5e73",
    "Mean objective": "\u5e73\u5747\u76ee\u6807\u503c",
    "Sample variance": "\u6837\u672c\u65b9\u5dee",
    "Standard error": "\u6807\u51c6\u8bef\u5dee",
    "Confidence interval": "\u7f6e\u4fe1\u533a\u95f4",
    "Paired mean improvement": "\u914d\u5bf9\u5e73\u5747\u6539\u5584",
    "Lower confidence bound": "\u7f6e\u4fe1\u4e0b\u754c",
    "Optimizations": "\u4f18\u5316\u6b21\u6570",
    "executed layers": "\u5df2\u6267\u884c\u5c42\u6570",
    "repeats per layer": "\u6bcf\u5c42 repeat \u6570",
    "selected layers": "\u9009\u4e2d\u5c42\u6570",
    "stop reason": "\u505c\u6b62\u539f\u56e0",
    "confidence level": "\u7f6e\u4fe1\u6c34\u5e73",
    "optimizations": "\u4f18\u5316\u6b21\u6570",
    "total evaluations": "\u603b\u76ee\u6807\u51fd\u6570\u6c42\u503c\u6b21\u6570",
    "objective evaluations": "\u76ee\u6807\u51fd\u6570\u6c42\u503c\u6b21\u6570",
    "gradient evaluations": "\u68af\u5ea6\u6c42\u503c\u6b21\u6570",
    "final sampling Jobs": "\u6700\u7ec8\u91c7\u6837\u4efb\u52a1\u6570",
    "requested shots": "\u8bf7\u6c42 shots",
    "root seed": "\u6839 seed",
    "Shared Problem design": "\u5171\u4eab\u95ee\u9898\u8bbe\u8ba1",
    "Problem and execution alignment": "\u95ee\u9898\u4e0e\u6267\u884c\u5bf9\u9f50",
    "Route and compilation plans": "\u8def\u7ebf\u4e0e\u7f16\u8bd1\u8ba1\u5212",
    "Optimization executions": "\u4f18\u5316\u6267\u884c",
    "Final state evidence": "\u6700\u7ec8\u72b6\u6001\u8bc1\u636e",
    "Final sampling comparison": "\u6700\u7ec8\u91c7\u6837\u5bf9\u6bd4",
    "Problem route comparison": "\u95ee\u9898\u8def\u7ebf\u5bf9\u6bd4",
    "Problem configuration comparison": "\u95ee\u9898\u914d\u7f6e\u5bf9\u6bd4",
    "Compared routes": "\u5bf9\u6bd4\u8def\u7ebf",
    "Compared Problem routes": "\u5df2\u5bf9\u6bd4\u7684\u95ee\u9898\u8def\u7ebf",
    "Comparison policy": "\u5bf9\u6bd4\u89c4\u5219",
    "Problem comparison policy": "\u95ee\u9898\u5bf9\u6bd4\u89c4\u5219",
    "Alignment field": "\u5bf9\u9f50\u5b57\u6bb5",
    "Problem hash": "\u95ee\u9898\u54c8\u5e0c",
    "Logical order": "\u903b\u8f91\u987a\u5e8f",
    "Interpretation": "\u89e3\u8bfb",
    "Topology": "\u62d3\u6251",
    "Target": "\u76ee\u6807",
    "Algorithm": "\u7b97\u6cd5",
    "Compile feasible": "\u7f16\u8bd1\u53ef\u884c",
    "Local reference": "\u672c\u5730\u53c2\u8003\u6267\u884c",
    "Hardware executable": "\u786c\u4ef6\u53ef\u6267\u884c",
    "Analog terms": "\u6a21\u62df\u9879",
    "Digital terms": "\u6570\u5b57\u9879",
    "Probability source": "\u6982\u7387\u6765\u6e90",
    "sources": "\u4e2a\u6570\u636e\u6e90",
    "modes": "\u79cd\u6a21\u5f0f",
    "algorithms": "\u79cd\u7b97\u6cd5",
    "varying dimensions": "\u53d8\u5316\u7ef4\u5ea6",
    "objective": "\u76ee\u6807\u503c",
    "energy breakdown": "\u80fd\u91cf\u5206\u89e3",
    "decoded candidates": "\u89e3\u7801\u5019\u9009\u89e3",
    "convergence": "\u6536\u655b\u8fc7\u7a0b",
    "compile resources": "\u7f16\u8bd1\u8d44\u6e90",
    "runtime resources": "\u8fd0\u884c\u8d44\u6e90",
    "comparable": "\u53ef\u76f4\u63a5\u5bf9\u6bd4",
    "qualified": "\u6709\u6761\u4ef6\u53ef\u6bd4",
    "evidence_only": "\u4ec5\u4f5c\u8bc1\u636e\u5c55\u793a",
    "descriptive_only": "\u4ec5\u4f5c\u63cf\u8ff0",
    "complete_probabilities": "\u5b8c\u6574\u6982\u7387",
    "All sources use the same canonical Problem and logical order.": "\u6240\u6709\u6570\u636e\u6e90\u4f7f\u7528\u540c\u4e00\u89c4\u8303\u5316\u95ee\u9898\u548c\u903b\u8f91\u987a\u5e8f\u3002",
    "Every source reconstructs the same canonical objective.": "\u6bcf\u4e2a\u6570\u636e\u6e90\u90fd\u91cd\u5efa\u540c\u4e00\u89c4\u8303\u5316\u76ee\u6807\u3002",
    "Bitstrings align, but shots and probability sources must be considered.": "\u6bd4\u7279\u4e32\u5df2\u5bf9\u9f50\uff0c\u4f46\u89e3\u8bfb\u65f6\u5fc5\u987b\u8003\u8651\u91c7\u6837\u6b21\u6570\u548c\u6982\u7387\u6765\u6e90\u3002",
    "Parameterizations and optimizer budgets may differ across routes.": "\u4e0d\u540c\u8def\u7ebf\u7684\u53c2\u6570\u5316\u65b9\u5f0f\u548c\u4f18\u5316\u9884\u7b97\u53ef\u80fd\u4e0d\u540c\u3002",
    "Digital gates, Analog controls, and Hybrid blocks use different units.": "\u6570\u5b57\u95e8\u3001\u6a21\u62df\u63a7\u5236\u548c\u6df7\u5408\u5757\u4f7f\u7528\u4e0d\u540c\u7684\u8d44\u6e90\u5355\u4f4d\u3002",
    "Local process measurements are not a standardized benchmark.": "\u672c\u5730\u8fdb\u7a0b\u6d4b\u91cf\u4e0d\u662f\u6807\u51c6\u5316\u6027\u80fd\u57fa\u51c6\u3002",
    "QAOA layer comparison": "QAOA \u5c42\u6570\u5bf9\u6bd4",
    "VQE layer comparison": "VQE \u5c42\u6570\u5bf9\u6bd4",
    "Optimization metrics": "\u4f18\u5316\u6307\u6807",
    "Optimization starts": "\u4f18\u5316\u8d77\u70b9",
    "SPSA iteration history": "SPSA \u8fed\u4ee3\u5386\u53f2",
    "SPSA online stability stopping": "SPSA \u5728\u7ebf\u7a33\u5b9a\u505c\u6b62",
    "SPSA learning-rate calibration": "SPSA \u5b66\u4e60\u7387\u6821\u51c6",
    "Calibration directions": "\u6821\u51c6\u65b9\u5411\u6570",
    "Target update RMS": "\u76ee\u6807\u66f4\u65b0 RMS",
    "Gradient RMS floor": "\u68af\u5ea6 RMS \u4e0b\u9650",
    "Maximum learning rate": "\u5b66\u4e60\u7387\u4e0a\u9650",
    "Derived learning rate": "\u6d3e\u751f\u5b66\u4e60\u7387",
    "Gradient RMS": "\u68af\u5ea6 RMS",
    "Calibration evidence": "\u6821\u51c6\u8bc1\u636e",
    "Calibration direction evidence": "\u6821\u51c6\u65b9\u5411\u8bc1\u636e",
    "Calibration uses complete pre-iteration directions and adds real objective and Backend cost. It calibrates only the local learning-rate scale and does not prove convergence or improvement.": "\u6821\u51c6\u4f7f\u7528\u6b63\u5f0f\u8fed\u4ee3\u524d\u7684\u5b8c\u6574\u6270\u52a8\u65b9\u5411\uff0c\u5e76\u589e\u52a0\u771f\u5b9e objective \u4e0e Backend \u6210\u672c\u3002\u5b83\u53ea\u6821\u51c6\u5c40\u90e8\u5b66\u4e60\u7387\u5c3a\u5ea6\uff0c\u4e0d\u8bc1\u660e\u6536\u655b\u6216\u6539\u5584\u3002",
    "Online checks use pre-final iteration evidence. The final center is evaluated separately. Meeting these engineering thresholds does not prove convergence or optimality.": "\u5728\u7ebf\u68c0\u67e5\u53ea\u4f7f\u7528 final \u4e4b\u524d\u7684\u8fed\u4ee3\u8bc1\u636e\u3002\u6700\u7ec8\u4e2d\u5fc3\u70b9\u4f1a\u5355\u72ec\u6c42\u503c\uff1b\u6ee1\u8db3\u8fd9\u4e9b\u5de5\u7a0b\u9608\u503c\u4e0d\u7b49\u4e8e\u8bc1\u660e\u6536\u655b\u6216\u6700\u4f18\u3002",
    "SPSA stopping configuration": "SPSA \u505c\u6b62\u914d\u7f6e",
    "SPSA stopping evidence": "SPSA \u505c\u6b62\u8bc1\u636e",
    "SPSA stopping checks": "SPSA \u505c\u6b62\u68c0\u67e5",
    "SPSA iterations": "SPSA \u8fed\u4ee3\u6b21\u6570",
    "directions per iteration": "\u6bcf\u8f6e\u6270\u52a8\u65b9\u5411\u6570",
    "objective repeats": "\u76ee\u6807\u91cd\u590d\u6b21\u6570",
    "Iteration": "\u8fed\u4ee3",
    "Direction": "\u65b9\u5411",
    "Learning rate": "\u5b66\u4e60\u7387",
    "Perturbation": "\u6270\u52a8\u5e45\u5ea6",
    "Plus objective": "\u6b63\u6270\u52a8\u76ee\u6807\u503c",
    "Minus objective": "\u8d1f\u6270\u52a8\u76ee\u6807\u503c",
    "Pooled plus objective": "\u6b63\u6270\u52a8\u6c60\u5316\u76ee\u6807\u503c",
    "Pooled plus standard error": "\u6b63\u6270\u52a8\u6c60\u5316\u6807\u51c6\u8bef",
    "Pooled minus objective": "\u8d1f\u6270\u52a8\u6c60\u5316\u76ee\u6807\u503c",
    "Pooled minus standard error": "\u8d1f\u6270\u52a8\u6c60\u5316\u6807\u51c6\u8bef",
    "Direction gradient": "\u65b9\u5411\u68af\u5ea6",
    "Averaged gradient": "\u5e73\u5747\u68af\u5ea6",
    "Gradient standard error": "\u68af\u5ea6\u6807\u51c6\u8bef",
    "Update norm": "\u66f4\u65b0\u6a21\u957f",
    "Projection": "\u8fb9\u754c\u6295\u5f71",
    "Evaluation offsets": "\u6c42\u503c\u504f\u79fb",
    "Start": "\u8d77\u70b9",
    "Initialization": "\u521d\u59cb\u5316",
    "Evaluation range": "\u6c42\u503c\u8303\u56f4",
    "Best evaluation": "\u6700\u4f18\u6c42\u503c",
    "Best objective": "\u6700\u4f18\u76ee\u6807\u503c",
    "best objective estimate": "\u6700\u4f18\u76ee\u6807\u4f30\u8ba1",
    "best source evaluation": "\u6700\u4f18\u6765\u6e90\u6c42\u503c",
    "Parameter trajectories": "\u53c2\u6570\u8f68\u8ff9",
    "Feasible probability": "\u53ef\u884c\u6982\u7387",
    "Expected constraint violations": "\u671f\u671b\u7ea6\u675f\u8fdd\u53cd\u6570",
    "Classical baseline and gap": "\u7ecf\u5178\u57fa\u7ebf\u4e0e\u5dee\u8ddd",
    "Label": "\u6807\u7b7e",
    "Layers": "\u5c42\u6570",
    "Evaluations": "\u6c42\u503c\u6b21\u6570",
    "Minimum objective": "\u6700\u4f4e\u76ee\u6807\u503c",
    "Expected gap": "\u671f\u671b\u5dee\u8ddd",
    "Compile hash": "\u7f16\u8bd1\u54c8\u5e0c",
    "Penalty model": "\u7f5a\u9879\u6a21\u578b",
    "Penalty strength": "\u7f5a\u9879\u5f3a\u5ea6",
    "Strict threshold": "\u4e25\u683c\u9608\u503c",
    "Sufficiency margin": "\u5145\u5206\u6027\u4f59\u91cf",
    "Sufficient": "\u662f\u5426\u5145\u5206",
    "Constraint": "\u7ea6\u675f",
    "Canonical term": "\u89c4\u8303\u5316\u9879",
    "Expected energy decomposition": "\u671f\u671b\u80fd\u91cf\u5206\u89e3",
    "Business objective": "\u4e1a\u52a1\u76ee\u6807",
    "Penalty energy": "\u7f5a\u9879\u80fd\u91cf",
    "Total objective": "\u603b\u76ee\u6807",
    "Route resource evidence": "\u8def\u7ebf\u8d44\u6e90\u8bc1\u636e",
    "Automatic layer selection": "\u81ea\u52a8\u5c42\u6570\u9009\u62e9",
    "Expected Problem objective": "\u671f\u671b Problem \u76ee\u6807\u503c",
    "Independent confirmation mean": "\u72ec\u7acb\u786e\u8ba4\u5747\u503c",
    "Layer objective source": "\u5c42\u76ee\u6807\u503c\u6765\u6e90",
    "Layer objective": "\u5c42\u76ee\u6807\u503c",
    "Final Problem objective": "\u672b\u7aef Problem \u76ee\u6807\u503c",
    "Candidate rank": "\u5019\u9009\u987a\u4f4d",
    "Candidate count": "\u5019\u9009\u6570",
    "repeats per candidate": "\u6bcf\u4e2a\u5019\u9009\u7684\u91cd\u590d\u6b21\u6570",
    "confirmation shots / group": "\u6bcf\u7ec4\u786e\u8ba4 shots",
    "Confirmation standard error": "\u786e\u8ba4\u6807\u51c6\u8bef\u5dee",
    "Backend Jobs": "Backend \u4f5c\u4e1a\u6570",
    "objective Backend Jobs": "\u76ee\u6807\u51fd\u6570 Backend \u4f5c\u4e1a\u6570",
    "confirmation Backend Jobs": "\u786e\u8ba4 Backend \u4f5c\u4e1a\u6570",
    "workflow Backend Jobs": "\u5de5\u4f5c\u6d41 Backend \u4f5c\u4e1a\u6570",
    "objective shots": "\u76ee\u6807\u51fd\u6570 shots",
    "confirmation shots": "\u786e\u8ba4 shots",
    "final sampling shots": "\u672b\u7aef\u91c7\u6837 shots",
    "workflow shots": "\u5de5\u4f5c\u6d41 shots",
    "Layer selection history": "\u5c42\u6570\u9009\u62e9\u5386\u53f2",
    "Max layers": "\u6700\u5927\u5c42\u6570",
    "Executed layers": "\u5df2\u6267\u884c\u5c42\u6570",
    "Selected layers": "\u9009\u4e2d\u5c42\u6570",
    "Minimum improvement": "\u6700\u5c0f\u6539\u5584\u9608\u503c",
    "Numeric tolerance": "\u6570\u503c\u5bb9\u5dee",
    "Patience": "\u8010\u5fc3\u5c42\u6570",
    "Stop reason": "\u505c\u6b62\u539f\u56e0",
    "Total evaluations": "\u603b\u6c42\u503c\u6b21\u6570",
    "Improvement from incumbent": "\u76f8\u5bf9\u5f53\u524d\u6700\u4f18\u5c42\u7684\u6539\u5584",
    "Material improvement": "\u662f\u5426\u8fbe\u5230\u5b9e\u8d28\u6539\u5584",
    "Incumbent layer": "\u5f53\u524d\u9009\u4e2d\u5c42",
    "No-improvement count": "\u8fde\u7eed\u672a\u6539\u5584\u5c42\u6570",
    "Optimizer starts": "\u4f18\u5316\u8d77\u70b9\u6570",
    "First start": "\u9996\u4e2a\u8d77\u70b9",
    "max_layers_reached": "\u5df2\u8fbe\u6700\u5927\u5c42\u6570",
    "patience_exhausted": "\u8fde\u7eed\u672a\u6539\u5584\u5c42\u6570\u5df2\u8fbe\u4e0a\u9650",
    "Method": "\u65b9\u6cd5",
    "Wall time (s)": "\u5899\u949f\u65f6\u95f4\uff08\u79d2\uff09",
    "Estimated peak bytes": "\u9884\u4f30\u5cf0\u503c\u5b57\u8282\u6570",
    "Activation probability": "\u6fc0\u6d3b\u6982\u7387",
    "Contribution": "\u8d21\u732e",
    "Constraint penalty contributions": "\u9010\u7ea6\u675f\u7f5a\u9879\u8d21\u732e",
    "No explicit penalty model is defined for this Problem; all canonical terms remain in the business objective.": "\u8be5\u95ee\u9898\u6ca1\u6709\u663e\u5f0f\u7f5a\u9879\u6a21\u578b\uff1b\u6240\u6709\u89c4\u8303\u5316\u9879\u5747\u4fdd\u7559\u5728\u4e1a\u52a1\u76ee\u6807\u4e2d\u3002",
    "Objective execution request": "\u76ee\u6807\u51fd\u6570\u6267\u884c\u8bf7\u6c42",
    "Sampled objective request": "\u91c7\u6837\u76ee\u6807\u51fd\u6570\u8bf7\u6c42",
    "Sampled objective execution": "\u91c7\u6837\u76ee\u6807\u51fd\u6570\u6267\u884c",
    "QWC group execution evidence": "QWC \u5206\u7ec4\u6267\u884c\u8bc1\u636e",
    "QWC group execution": "QWC \u5206\u7ec4\u6267\u884c",
    "Raw counts": "\u539f\u59cb\u8ba1\u6570",
    "Measurement stage": "\u6d4b\u91cf\u9636\u6bb5",
    "Evidence hash": "\u8bc1\u636e\u54c8\u5e0c",
    "Grouping": "\u5206\u7ec4\u65b9\u5f0f",
    "Simulation method": "\u6a21\u62df\u65b9\u6cd5",
    "Backend": "Backend",
    "Estimator kind": "\u4f30\u8ba1\u5668\u7c7b\u578b",
    "Measurement kind": "\u6d4b\u91cf\u7c7b\u578b",
    "QWC groups": "QWC \u5206\u7ec4\u6570",
    "Shots per group": "\u6bcf\u7ec4 shots",
    "Reference shots / group": "\u6bcf\u7ec4\u53c2\u8003 shots",
    "Actual group shots": "\u5404\u7ec4\u5b9e\u9645 shots",
    "Allocation": "\u5206\u914d\u7b56\u7565",
    "Shots per objective": "\u6bcf\u4e2a\u76ee\u6807\u70b9 shots",
    "Backend executions per objective": "\u6bcf\u4e2a\u76ee\u6807\u70b9\u7684 Backend \u4f5c\u4e1a\u6570",
    "Measurement plan": "\u6d4b\u91cf\u8ba1\u5212",
    "Seed": "\u968f\u673a\u79cd\u5b50",
    "Energy mean": "\u80fd\u91cf\u5747\u503c",
    "Selected objective execution": "\u9009\u4e2d\u7684\u76ee\u6807\u51fd\u6570\u6267\u884c",
    "Final sampling execution": "\u6700\u7ec8\u91c7\u6837\u6267\u884c",
    "Noise channels": "\u566a\u58f0\u901a\u9053",
    "Simulation plan": "\u6a21\u62df\u8ba1\u5212",
    "Noise applications": "\u566a\u58f0\u5e94\u7528\u8bb0\u5f55",
    "Observable uncertainty": "\u53ef\u89c2\u6d4b\u91cf\u4e0d\u786e\u5b9a\u5ea6",
    "Program lineage": "Program \u6eaf\u6e90",
    "Source Program": "\u6e90 Program",
    "Runtime Program": "\u8fd0\u884c\u65f6 Program",
    "Lineage": "\u6eaf\u6e90\u5173\u7cfb",
    "Identity": "\u8eab\u4efd",
    "Execution mode": "\u6267\u884c\u6a21\u5f0f",
    "execution mode": "\u6267\u884c\u6a21\u5f0f",
    "Estimator": "\u4f30\u8ba1\u5668",
    "estimator": "\u4f30\u8ba1\u5668",
    "Source kind": "\u6765\u6e90\u7c7b\u578b",
    "source kind": "\u6765\u6e90\u7c7b\u578b",
    "Effective seed": "\u5b9e\u9645\u968f\u673a\u79cd\u5b50",
    "effective seed": "\u5b9e\u9645\u968f\u673a\u79cd\u5b50",
    "requested seed": "\u8bf7\u6c42\u7684\u968f\u673a\u79cd\u5b50",
    "Backend shots": "Backend \u91c7\u6837\u6b21\u6570",
    "Backend Job": "Backend \u4f5c\u4e1a",
    "Noise model": "\u566a\u58f0\u6a21\u578b",
    "noise model": "\u566a\u58f0\u6a21\u578b",
    "model hash": "\u6a21\u578b\u54c8\u5e0c",
    "report hash": "\u62a5\u544a\u54c8\u5e0c",
    "physical applications": "\u7269\u7406\u901a\u9053\u5e94\u7528\u6b21\u6570",
    "measurement applications": "\u6d4b\u91cf\u901a\u9053\u5e94\u7528\u6b21\u6570",
    "truthfulness": "\u771f\u5b9e\u6027",
    "Channel": "\u901a\u9053",
    "Model": "\u6a21\u578b",
    "Injection point": "\u6ce8\u5165\u4f4d\u7f6e",
    "Integrator": "\u79ef\u5206\u5668",
    "State representation": "\u72b6\u6001\u8868\u793a",
    "Logical sites": "\u903b\u8f91\u4f4d\u70b9",
    "Hilbert dimension": "Hilbert \u7a7a\u95f4\u7ef4\u6570",
    "Device": "\u8bbe\u5907",
    "Dtype": "\u6570\u503c\u7c7b\u578b",
    "Workers": "\u5de5\u4f5c\u7ebf\u7a0b",
    "Trajectories": "\u8f68\u8ff9\u6570",
    "Options hash": "Options \u54c8\u5e0c",
    "Plan hash": "\u8ba1\u5212\u54c8\u5e0c",
    "Requested simulation options": "\u8bf7\u6c42\u7684\u6a21\u62df\u9009\u9879",
    "No physical NoiseModel was requested.": "\u672a\u8bf7\u6c42\u7269\u7406 NoiseModel\u3002",
    "penalty model": "\u7f5a\u9879\u6a21\u578b",
    "penalty strength": "\u7f5a\u9879\u5f3a\u5ea6",
    "strict threshold": "\u4e25\u683c\u9608\u503c",
    "sufficiency margin": "\u5145\u5206\u6027\u4f59\u91cf",
    "sufficient": "\u662f\u5426\u5145\u5206",
    "business objective": "\u4e1a\u52a1\u76ee\u6807",
    "penalty energy": "\u7f5a\u9879\u80fd\u91cf",
    "total objective": "\u603b\u76ee\u6807",
    "defined": "\u5df2\u5b9a\u4e49",
    "not_applicable": "\u4e0d\u9002\u7528",
    "True": "\u662f",
    "False": "\u5426",
}


def render_experiment_report_html(
    report: ExperimentReportIR,
    *,
    language: str = "en",
) -> str:
    """Render a report without executing sources or trusting source text as HTML."""
    if not isinstance(report, ExperimentReportIR):
        raise TypeError("report must be ExperimentReportIR.")
    if language not in {"en", "zh"}:
        raise ValueError("language must be 'en' or 'zh'.")
    report_before = report.to_dict()
    sections = "\n".join(
        _render_section(report, section, order=index + 1)
        for index, section in enumerate(report.sections)
    )
    bokeh_resources = (
        inline_bokeh_resources_html() if 'class="bokeh-plot' in sections else ""
    )
    navigation = "".join(
        (
            f'<a href="#{_attr(section.section_id)}">'
            f"<span>{index + 1}</span>{_text(_stage_label(section.stage))}</a>"
        )
        for index, section in enumerate(report.sections)
    )
    source_rows = "".join(
        (
            "<tr>"
            f"<td><code>{_text(source_id)}</code></td>"
            f"<td><code>{_text(report.source_hashes[source_id])}</code></td>"
            "</tr>"
        )
        for source_id in report.source_ids
    )
    document = f"""<!doctype html>
<html lang="{"zh-CN" if language == "zh" else "en"}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{_text(report.title)}</title>
<style>{_STYLES}</style>
{bokeh_resources}
</head>
<body>
<main class="report-shell">
  <header class="report-header">
    <div class="report-topline">
      <div class="report-kicker">CASCAQit experiment report</div>
      <label class="language-control" for="report-language"><span>Language</span>
        <select id="report-language" aria-label="Language">
          <option value="en"{" selected" if language == "en" else ""}>English</option>
          <option value="zh"{" selected" if language == "zh" else ""}>&#20013;&#25991;</option>
        </select>
      </label>
    </div>
    <div class="report-title-row">
      <div>
        <h1>{_text(report.title)}</h1>
        <p>{_text(report.source_kind)}</p>
      </div>
      <div class="header-status">
        <span class="profile-badge">{_text(report.profile)}</span>
        {_status_badge("error" if report.has_errors else "available")}
      </div>
    </div>
    <div class="report-summary">
      <div><span>Profile</span><strong>{_text(report.profile)}</strong></div>
      <div><span>Lifecycle stages</span><strong>{len(report.sections)}</strong></div>
      <div><span>Sources</span><strong>{len(report.source_ids)}</strong></div>
      <div><span>Report hash</span><code>{_text(report.stable_hash())}</code></div>
    </div>
  </header>
  <nav class="lifecycle" aria-label="Experiment lifecycle">{navigation}</nav>
  {sections}
  <section class="source-index" aria-labelledby="source-index-title">
    <h2 id="source-index-title">Source identity</h2>
    <div class="table-wrap"><table><thead><tr><th>Source</th><th>SHA-256</th></tr></thead>
    <tbody>{source_rows}</tbody></table></div>
  </section>
  <footer>Offline deterministic derived view. No backend, network, or artifact-byte access.</footer>
  {_language_script()}
  <script type="application/json" id="cascaqit-report-data">{_embedded_json(report)}</script>
</main>
</body>
</html>
"""
    if report.to_dict() != report_before:
        raise ValueError("HTML rendering mutated ExperimentReportIR.")
    return document


def _render_section(
    report: ExperimentReportIR,
    section: ExperimentSectionIR,
    *,
    order: int,
) -> str:
    if section.status == "unavailable":
        content = (
            '<div class="unavailable-block">'
            f"<strong>Unavailable</strong><p>{_text(section.unavailable_reason or '')}</p>"
            "</div>"
        )
    else:
        content = _render_stage_content(report, section)
    diagnostics = _render_diagnostics(section)
    source_paths = "".join(
        f"<li><code>{_text(path)}</code></li>" for path in section.source_paths
    )
    evidence = (
        '<details class="evidence"><summary>Source facts and provenance</summary>'
        f"{_render_value(section.payload, key_hint='payload')}"
        + (
            f'<h3>Source paths</h3><ul class="source-paths">{source_paths}</ul>'
            if source_paths
            else ""
        )
        + "</details>"
        if section.status != "unavailable"
        else ""
    )
    section_body = "\n  ".join(
        fragment for fragment in (content, diagnostics, evidence) if fragment
    )
    return f"""<section id="{_attr(section.section_id)}" class="stage-section">
  <div class="stage-heading">
    <div class="stage-index">{order:02d}</div>
    <div><div class="stage-name">{_text(_stage_label(section.stage))}</div><h2>{_text(section.title)}</h2></div>
    {_status_badge(section.status)}
  </div>
  {section_body}
</section>"""


def _render_stage_content(
    report: ExperimentReportIR,
    section: ExperimentSectionIR,
) -> str:
    payload = section.payload
    if report.source_kind == "ObjectiveGradientIR":
        return _render_fixed_gradient_stage(section.stage, payload)
    if report.source_kind == "SampledObjectiveEvaluation":
        return _render_sampled_objective_stage(section.stage, payload)
    problem_comparison = report.source_kind in {
        "ProblemExecutionComparison",
        "ProblemLayerExperiment",
        "ProblemRepeatedLayerExperiment",
    }
    if section.stage == "design":
        if problem_comparison:
            return _render_problem_comparison_design(payload)
        if report.profile == "problem":
            return _render_problem_design(payload)
        if report.profile == "algorithm":
            return _render_algorithm_design(payload)
        return _render_design(report.profile, payload)
    if section.stage == "validate":
        if problem_comparison:
            return _render_problem_comparison_validation(payload)
        if report.profile == "problem":
            return _render_problem_validation(payload)
        if report.profile == "algorithm":
            return _render_algorithm_validation(payload)
        return _render_validation(payload)
    if section.stage == "plan":
        if problem_comparison:
            return _render_problem_comparison_plan(payload)
        if report.profile == "problem":
            return _render_problem_plan(payload)
        if report.profile == "algorithm":
            return _render_algorithm_plan(payload)
        return _render_plan(payload)
    if section.stage == "execute":
        if problem_comparison:
            return _render_key_metrics(payload)
        if report.profile == "algorithm":
            return _render_algorithm_execution(payload)
        return _render_execution(payload)
    if section.stage == "state":
        if problem_comparison:
            return _render_key_metrics(payload)
        if report.profile == "algorithm":
            return _render_algorithm_state(payload)
        return _render_state(payload)
    if section.stage == "measure":
        if report.profile == "algorithm":
            return _render_algorithm_measurement(payload)
        return _render_measurement(report.profile, payload)
    if section.stage == "analyze":
        if problem_comparison:
            return _render_problem_comparison_analysis(payload)
        if report.profile == "problem":
            return _render_problem_analysis(payload)
        if report.profile == "algorithm":
            return _render_algorithm_analysis(payload)
        return _render_analysis(report.profile, payload)
    return ""


def _render_fixed_gradient_stage(stage: str, payload: Mapping[str, Any]) -> str:
    """Render the fixed-parameter gradient profile without workflow-only fields."""
    if stage == "plan":
        return _render_gradient_plan(payload.get("gradient_plan")) + (
            _render_algorithm_objective_request(payload.get("objective_request"))
        )
    if stage == "execute":
        return _render_gradient_history(payload.get("gradient"))
    if stage == "state":
        return _render_algorithm_objective_request(payload)
    if stage == "measure":
        return _render_gradient_uncertainty(payload)
    return _render_key_metrics(payload)


def _render_problem_design(payload: Mapping[str, Any]) -> str:
    problem = payload.get("problem")
    node_weights = payload.get("node_weights", ())
    hamiltonian = payload.get("logical_hamiltonian")
    native = payload.get("native_program")
    penalty = payload.get("penalty_analysis")
    if not isinstance(problem, Mapping) or not isinstance(hamiltonian, Mapping):
        return ""
    linear = problem.get("linear_terms", ())
    quadratic = problem.get("quadratic_terms", ())
    constraints = problem.get("constraints", ())
    logical_terms = hamiltonian.get("terms", ())
    summary = (
        '<div class="domain-summary">'
        f"<span><strong>{_text(problem.get('problem_type', ''))}</strong> problem</span>"
        f"<span><strong>{_sequence_length(problem.get('logical_order'))}</strong> variables</span>"
        f"<span><strong>{_sequence_length(linear) + _sequence_length(quadratic)}</strong> objective terms</span>"
        f"<span><strong>{_sequence_length(constraints)}</strong> constraints</span>"
        + (
            f"<span><strong>{_text(payload.get('mode'))}</strong> mode</span>"
            if payload.get("mode") is not None
            else ""
        )
        + (
            f"<span><strong>{_text(payload.get('algorithm'))}</strong> algorithm</span>"
            if payload.get("algorithm") is not None
            else ""
        )
        + "</div>"
    )
    problem_rows: list[str] = []
    for item in cast(Sequence[Any], linear) if _is_sequence(linear) else ():
        if isinstance(item, Mapping):
            problem_rows.append(
                "<tr>"
                f"<td><code>{_text(item.get('term_id', ''))}</code></td>"
                "<td>linear</td>"
                f"<td><code>{_text(item.get('variable', ''))}</code></td>"
                f"<td>{_format_number(item.get('coefficient'))}</td>"
                "</tr>"
            )
    for item in cast(Sequence[Any], quadratic) if _is_sequence(quadratic) else ():
        if isinstance(item, Mapping):
            targets = f"{item.get('left', '')}, {item.get('right', '')}"
            problem_rows.append(
                "<tr>"
                f"<td><code>{_text(item.get('term_id', ''))}</code></td>"
                "<td>quadratic</td>"
                f"<td><code>{_text(targets)}</code></td>"
                f"<td>{_format_number(item.get('coefficient'))}</td>"
                "</tr>"
            )
    hamiltonian_rows = []
    for item in (
        cast(Sequence[Any], logical_terms) if _is_sequence(logical_terms) else ()
    ):
        if not isinstance(item, Mapping):
            continue
        hamiltonian_rows.append(
            "<tr>"
            f"<td><code>{_text(item.get('term_id', ''))}</code></td>"
            f"<td>{_text(str(item.get('operator', '')).upper())}</td>"
            f"<td><code>{_compact_value(item.get('targets'))}</code></td>"
            f"<td>{_format_number(item.get('coefficient'))}</td>"
            "</tr>"
        )
    weight_rows = []
    for item in cast(Sequence[Any], node_weights) if _is_sequence(node_weights) else ():
        if not isinstance(item, Mapping):
            continue
        weight_rows.append(
            "<tr>"
            f"<td><code>{_text(item.get('node', ''))}</code></td>"
            f"<td>{_format_number(item.get('weight'))}</td>"
            "</tr>"
        )
    weights_html = (
        '<div class="visual-group"><h3>Node weights</h3>'
        + _table(
            ("Node", "Weight"),
            weight_rows,
            label="Node weights",
        )
        + "</div>"
        if weight_rows
        else ""
    )
    native_html = ""
    if isinstance(native, Mapping):
        native_html = (
            '<div class="problem-native"><h3>Generated Native Program</h3>'
            + _render_design(str(payload.get("native_program_kind", "")), native)
            + "</div>"
        )
    if isinstance(penalty, Mapping):
        penalty_rows = []
        penalty_terms = penalty.get("penalty_terms", ())
        for item in (
            cast(Sequence[Any], penalty_terms) if _is_sequence(penalty_terms) else ()
        ):
            if not isinstance(item, Mapping):
                continue
            penalty_rows.append(
                "<tr>"
                f"<td><code>{_text(item.get('constraint_id', ''))}</code></td>"
                f"<td><code>{_text(item.get('canonical_term_id', ''))}</code></td>"
                f"<td><code>{_compact_value(item.get('targets'))}</code></td>"
                f"<td>{_format_number(item.get('coefficient'))}</td>"
                "</tr>"
            )
        penalty_html = (
            '<div class="visual-group"><h3>Penalty model</h3>'
            '<div class="domain-summary">'
            f"<span><strong>{_format_number(penalty.get('penalty_strength'))}</strong> penalty strength</span>"
            f"<span><strong>&gt; {_format_number(penalty.get('minimum_sufficient_strength'))}</strong> strict threshold</span>"
            f"<span><strong>{_format_number(penalty.get('sufficiency_margin'))}</strong> sufficiency margin</span>"
            f"<span><strong>{_text(penalty.get('sufficient', False))}</strong> sufficient</span>"
            "</div>"
            + _table(
                ("Constraint", "Canonical term", "Targets", "Coefficient"),
                penalty_rows,
                label="Penalty model",
            )
            + "</div>"
        )
    else:
        penalty_html = (
            '<div class="visual-group"><h3>Penalty model</h3>'
            '<p class="empty-note">No explicit penalty model is defined for this '
            "Problem; all canonical terms remain in the business objective.</p></div>"
        )
    return (
        summary
        + '<div class="problem-grid">'
        + '<div class="visual-group"><h3>Canonical objective</h3>'
        + _table(
            ("Term", "Kind", "Variables", "Coefficient"),
            problem_rows,
            label="Canonical objective terms",
        )
        + "</div>"
        + '<div class="visual-group"><h3>Logical Hamiltonian</h3>'
        + _table(
            ("Term", "Operator", "Targets", "Coefficient"),
            hamiltonian_rows,
            label="Logical Hamiltonian terms",
        )
        + "</div></div>"
        + weights_html
        + penalty_html
        + native_html
    )


def _render_problem_comparison_design(payload: Mapping[str, Any]) -> str:
    routes = payload.get("routes", ())
    rows = []
    for item in cast(Sequence[Any], routes) if _is_sequence(routes) else ():
        if not isinstance(item, Mapping):
            continue
        rows.append(
            "<tr>"
            f"<td>{_text(item.get('label', ''))}</td>"
            f"<td>{_text(item.get('mode', ''))}</td>"
            f"<td>{_text(item.get('algorithm', ''))}</td>"
            f"<td>{_compact_value(item.get('topology'))}</td>"
            f"<td><code>{_text(item.get('target_id', ''))}</code></td>"
            f"<td>{_text(item.get('compile_feasible', False))}</td>"
            f"<td>{_text(item.get('local_reference', True))}</td>"
            f"<td>{_text(item.get('hardware_executable', False))}</td>"
            "</tr>"
        )
    return (
        _render_problem_design(payload)
        + '<div class="visual-group"><h3>Compared routes</h3>'
        + _table(
            (
                "Label",
                "Mode",
                "Algorithm",
                "Topology",
                "Target",
                "Compile feasible",
                "Local reference",
                "Hardware executable",
            ),
            rows,
            label="Compared Problem routes",
        )
        + "</div>"
    )


def _render_problem_comparison_validation(payload: Mapping[str, Any]) -> str:
    policy = payload.get("comparison_policy", {})
    rows = []
    if isinstance(policy, Mapping):
        for metric, raw_rule in policy.items():
            if not isinstance(raw_rule, Mapping):
                continue
            rows.append(
                "<tr>"
                f"<td>{_text(str(metric).replace('_', ' '))}</td>"
                f"<td>{_text(raw_rule.get('status', ''))}</td>"
                f"<td>{_text(raw_rule.get('reason', ''))}</td>"
                "</tr>"
            )
    alignment = (
        '<div class="domain-summary">'
        f"<span><strong>{_safe_int(payload.get('source_count'))}</strong> sources</span>"
        f"<span><strong>{_compact_value(payload.get('modes'))}</strong> modes</span>"
        f"<span><strong>{_compact_value(payload.get('algorithms'))}</strong> algorithms</span>"
        f"<span><strong>{_compact_value(payload.get('varying_dimensions'))}</strong> varying dimensions</span>"
        "</div>"
    )
    alignment_rows = [
        "<tr>"
        "<td>Problem hash</td>"
        f"<td><code>{_text(payload.get('problem_hash', ''))}</code></td>"
        "</tr>",
        "<tr>"
        "<td>Logical order</td>"
        f"<td><code>{_compact_value(payload.get('logical_order'))}</code></td>"
        "</tr>",
    ]
    layer_experiment = payload.get("layer_experiment")
    layer_html = (
        _render_layer_experiment_config(layer_experiment)
        if isinstance(layer_experiment, Mapping)
        else ""
    )
    repeated_experiment = payload.get("repeated_layer_experiment")
    repeated_html = (
        _render_repeated_layer_experiment_config(repeated_experiment)
        if isinstance(repeated_experiment, Mapping)
        else ""
    )
    return (
        alignment
        + _table(
            ("Alignment field", "Value"),
            alignment_rows,
            label="Problem and execution alignment",
        )
        + '<div class="visual-group"><h3>Comparison policy</h3>'
        + _table(
            ("Metric", "Status", "Interpretation"),
            rows,
            label="Problem comparison policy",
        )
        + "</div>"
        + layer_html
        + repeated_html
    )


def _render_layer_experiment_config(payload: Mapping[str, Any]) -> str:
    measurement = payload.get("measurement")
    measurement_summary = ""
    if isinstance(measurement, Mapping):
        selection = payload.get("sampled_selection")
        selection_config = selection if isinstance(selection, Mapping) else {}
        measurement_summary = (
            '<div class="domain-summary">'
            f"<span><strong>{_text(measurement.get('allocation', ''))}</strong> Allocation</span>"
            f"<span><strong>{_safe_int(measurement.get('shots_per_group'))}</strong> Shots per group</span>"
            f"<span><strong>{_safe_int(selection_config.get('candidate_count'))}</strong> Candidate count</span>"
            f"<span><strong>{_safe_int(selection_config.get('repeats_per_candidate'))}</strong> repeats per candidate</span>"
            f"<span><strong>{_safe_int(selection_config.get('shots_per_group'))}</strong> confirmation shots / group</span>"
            "</div>"
        )
    return (
        '<div class="visual-group"><h3>Automatic layer selection</h3>'
        '<div class="domain-summary">'
        f"<span><strong>{_safe_int(payload.get('max_layers'))}</strong> max layers</span>"
        f"<span><strong>{_format_number(payload.get('min_improvement'))}</strong> minimum improvement</span>"
        f"<span><strong>{_format_number(payload.get('numeric_tolerance'))}</strong> numeric tolerance</span>"
        f"<span><strong>{_safe_int(payload.get('patience'))}</strong> patience</span>"
        f"<span><strong>{_safe_int(payload.get('requested_shots'))}</strong> requested shots</span>"
        f"<span><strong>{_safe_int(payload.get('seed'))}</strong> seed</span>"
        "</div>" + measurement_summary + "</div>"
    )


def _render_repeated_layer_experiment_config(payload: Mapping[str, Any]) -> str:
    shots = payload.get("requested_shots", payload.get("final_shots"))
    return (
        '<div class="visual-group"><h3>Repeated statistical layer selection</h3>'
        '<div class="domain-summary">'
        f"<span><strong>{_safe_int(payload.get('max_layers'))}</strong> max layers</span>"
        f"<span><strong>{_safe_int(payload.get('repeats'))}</strong> repeats per layer</span>"
        f"<span><strong>{_format_number(payload.get('confidence_level'))}</strong> confidence level</span>"
        f"<span><strong>{_format_number(payload.get('min_improvement'))}</strong> minimum improvement</span>"
        f"<span><strong>{_safe_int(payload.get('patience'))}</strong> patience</span>"
        f"<span><strong>{_safe_int(shots)}</strong> requested shots</span>"
        f"<span><strong>{_safe_int(payload.get('seed'))}</strong> root seed</span>"
        "</div></div>"
    )


def _render_vqe_sampling_benchmark_config(payload: Mapping[str, Any]) -> str:
    measurement = payload.get("measurement")
    measurement = measurement if isinstance(measurement, Mapping) else {}
    selection = payload.get("sampled_selection")
    selection = selection if isinstance(selection, Mapping) else {}
    return (
        '<div class="visual-group"><h3>VQE sampling benchmark configuration</h3>'
        '<div class="domain-summary">'
        f"<span><strong>{_safe_int(payload.get('repeats'))}</strong> paired repeats</span>"
        f"<span><strong>{_safe_int(payload.get('objective_evaluation_budget'))}</strong> objective evaluation ceiling</span>"
        f"<span><strong>{_text(measurement.get('allocation', ''))}</strong> QWC allocation</span>"
        f"<span><strong>{_safe_int(measurement.get('shots_per_group'))}</strong> shots per group</span>"
        f"<span><strong>{_safe_int(selection.get('candidate_count'))}</strong> confirmation candidates</span>"
        f"<span><strong>{_safe_int(payload.get('root_seed'))}</strong> root seed</span>"
        "</div>"
        + _table(
            ("Strategy", "Minimum repeats", "Maximum repeats", "Stop rule"),
            (
                "<tr><td>exact</td><td>1</td><td>1</td><td>exact objective</td></tr>",
                "<tr><td>sampled_single</td><td>1</td><td>1</td><td>fixed</td></tr>",
                "<tr><td>sampled_fixed</td>"
                f"<td>{_safe_int(payload.get('fixed_objective_repeats'))}</td>"
                f"<td>{_safe_int(payload.get('fixed_objective_repeats'))}</td>"
                "<td>fixed</td></tr>",
                "<tr><td>sampled_adaptive</td>"
                f"<td>{_safe_int(payload.get('adaptive_objective_repeats'))}</td>"
                f"<td>{_safe_int(payload.get('adaptive_max_objective_repeats'))}</td>"
                f"<td>standard error &le; {_format_number(payload.get('adaptive_standard_error_target'))}</td></tr>",
            ),
            label="VQE benchmark strategy definitions",
        )
        + f'<p class="empty-note">{_text(payload.get("comparison_boundary", ""))}</p>'
        "</div>"
    )


def _render_vqe_stability_config(payload: Mapping[str, Any]) -> str:
    rows = [
        f"<tr><td>{_text(_humanize(key))}</td><td>{_compact_value(payload.get(key))}</td></tr>"
        for key in (
            "window_size",
            "min_iterations",
            "objective_range_tolerance",
            "update_norm_tolerance",
            "gradient_norm_tolerance",
            "sampled_standard_error_tolerance",
        )
    ]
    return (
        '<div class="visual-group"><h3>VQE stability thresholds</h3>'
        '<p class="section-note">Thresholds diagnose a saved terminal window. They do not alter the optimizer or prove convergence.</p>'
        + _table(
            ("Setting", "Value"),
            rows,
            label="VQE stability thresholds",
        )
        + "</div>"
    )


def _render_vqe_stability_execution(payload: Mapping[str, Any]) -> str:
    starts = payload.get("starts", ())
    if not _is_sequence(starts):
        return ""
    rows = []
    for item in cast(Sequence[Any], starts):
        if not isinstance(item, Mapping):
            continue
        termination = item.get("termination", {})
        termination = termination if isinstance(termination, Mapping) else {}
        rows.append(
            "<tr>"
            f"<td>{_safe_int(item.get('start_index'))}</td>"
            f"<td>{_text('yes' if item.get('selected') else 'no')}</td>"
            f"<td>{_text(item.get('evaluator_kind', ''))}</td>"
            f"<td>{_status_badge(str(item.get('status', '')))}</td>"
            f"<td>{_safe_int(item.get('iteration_count'))}</td>"
            f"<td>{_text(termination.get('reason', ''))}</td>"
            f"<td>{_safe_int(item.get('evaluation_count'))} / {_compact_value(item.get('max_evaluations'))}</td>"
            f"<td>{_safe_int(item.get('backend_execution_count'))} / {_compact_value(item.get('max_backend_executions'))}</td>"
            "</tr>"
        )
    return (
        '<div class="visual-group"><h3>Per-start stopping context</h3>'
        '<div class="domain-summary">'
        f"<span><strong>{_status_badge(str(payload.get('status', '')))}</strong> selected-start diagnosis</span>"
        f"<span><strong>{_safe_int(payload.get('selected_start_index'))}</strong> selected start</span>"
        f"<span><strong>{_safe_int(len(rows))}</strong> starts</span>"
        "</div>"
        + _table(
            (
                "Start",
                "Selected",
                "Evaluator",
                "Status",
                "Iterations",
                "Termination",
                "Evaluations / limit",
                "Backend executions / limit",
            ),
            rows,
            label="Per-start stopping context",
        )
        + "</div>"
    )


def _render_vqe_stability_analysis(payload: Mapping[str, Any]) -> str:
    starts = payload.get("starts", ())
    if not _is_sequence(starts):
        return ""
    selected_index = _safe_int(payload.get("selected_start_index"))
    selected = next(
        (
            item
            for item in cast(Sequence[Any], starts)
            if isinstance(item, Mapping)
            and _safe_int(item.get("start_index")) == selected_index
        ),
        None,
    )
    if not isinstance(selected, Mapping):
        return ""
    checks = selected.get("checks", ())
    check_rows = []
    if _is_sequence(checks):
        for check in cast(Sequence[Any], checks):
            if not isinstance(check, Mapping):
                continue
            check_rows.append(
                "<tr>"
                f"<td>{_text(_humanize(str(check.get('name', ''))))}</td>"
                f"<td>{_status_badge(str(check.get('status', '')))}</td>"
                f"<td>{_compact_value(check.get('observed_value'))}</td>"
                f"<td>{_compact_value(check.get('threshold'))}</td>"
                f"<td>{_safe_int(check.get('sample_count'))}</td>"
                "</tr>"
            )
    objective_values = selected.get("objective_proxy_values", ())
    objective_values = objective_values if _is_sequence(objective_values) else ()
    points = [
        {
            "evaluation_index": index,
            "energy": value,
            "parameters": {},
            "result_id": f"stability-center-proxy-{index}",
        }
        for index, value in enumerate(cast(Sequence[Any], objective_values))
    ]
    finite_values = [
        (index, _finite_number(value))
        for index, value in enumerate(cast(Sequence[Any], objective_values))
    ]
    best_index = min(
        ((index, value) for index, value in finite_values if value is not None),
        key=lambda item: item[1] if item[1] is not None else math.inf,
        default=(0, None),
    )[0]
    fallback_rows = [
        f"<tr><td>{index}</td><td>{_format_number(value)}</td></tr>"
        for index, value in enumerate(cast(Sequence[Any], objective_values))
    ]
    fallback = _table(
        ("Terminal point", "Objective center proxy"),
        fallback_rows,
        label="VQE terminal objective center proxies",
    )
    chart = render_objective_history_bokeh_html(
        points,
        best_evaluation_index=best_index,
        baseline_energy=None,
        identity_hint=str(payload.get("diagnostic_id", "vqe-stability")),
        fallback_html=fallback,
        energy_label="Objective center proxy",
        running_best_label="Running minimum proxy",
        best_label="Lowest proxy",
        x_axis_label="SPSA iteration proxy",
        aria_label="VQE terminal objective center proxies",
    )
    sampled_html = ""
    standard_errors = selected.get("sampled_standard_errors", ())
    if _is_sequence(standard_errors) and standard_errors:
        sampled_html = (
            '<div class="visual-group"><h3>Sampled uncertainty and repeats</h3>'
            + _table(
                ("Metric", "Value"),
                [
                    f"<tr><td>Standard errors</td><td>{_compact_value(standard_errors)}</td></tr>",
                    f"<tr><td>Repeat counts</td><td>{_compact_value(selected.get('sampled_repeat_counts'))}</td></tr>",
                    f"<tr><td>Repeat stop reasons</td><td>{_compact_value(selected.get('sampled_repeat_stop_reasons'))}</td></tr>",
                ],
                label="Sampled uncertainty and repeats",
            )
            + "</div>"
        )
    return (
        '<div class="visual-group"><h3>Selected-start stability diagnosis</h3>'
        '<div class="domain-summary">'
        f"<span><strong>{_status_badge(str(payload.get('status', '')))}</strong> stability evidence</span>"
        f"<span><strong>{_safe_int(selected.get('iteration_count'))}</strong> iterations</span>"
        f"<span><strong>{_text(selected.get('evaluator_kind', ''))}</strong> evaluator</span>"
        f"<span><strong>{_text(payload.get('optimality_claim', ''))}</strong> optimality</span>"
        f"<span><strong>{_text(payload.get('convergence_claim', ''))}</strong> strict convergence</span>"
        "</div>"
        '<p class="section-note">'
        + _text(payload.get("interpretation_boundary", ""))
        + "</p>"
        + _table(
            ("Check", "Status", "Observed", "Threshold", "Samples"),
            check_rows,
            label="Selected-start stability checks",
        )
        + "</div>"
        + '<div class="visual-group"><h3>Terminal objective center proxies</h3>'
        + chart
        + "</div>"
        + sampled_html
    )


def _render_vqe_sampling_benchmark_execution(payload: Mapping[str, Any]) -> str:
    runs = payload.get("runs", ())
    rows = []
    for item in cast(Sequence[Any], runs) if _is_sequence(runs) else ():
        if not isinstance(item, Mapping):
            continue
        rows.append(
            "<tr>"
            f"<td>{_safe_int(item.get('repeat_index'))}</td>"
            f"<td><code>{_text(item.get('strategy', ''))}</code></td>"
            f"<td>{_safe_int(item.get('paired_seed'))}</td>"
            f"<td>{_safe_int(item.get('objective_evaluation_count'))}</td>"
            f"<td>{_safe_int(item.get('objective_backend_execution_count'))}</td>"
            f"<td>{_safe_int(item.get('confirmation_backend_execution_count'))}</td>"
            f"<td>{_safe_int(item.get('diagnostic_exact_backend_execution_count'))}</td>"
            f"<td>{_safe_int(item.get('objective_shots'))}</td>"
            f"<td>{_safe_int(item.get('confirmation_shots'))}</td>"
            f"<td>{_format_number(item.get('objective_budget_utilization'))}</td>"
            "</tr>"
        )
    totals = payload.get("cost_totals")
    totals = totals if isinstance(totals, Mapping) else {}
    return (
        '<div class="visual-group"><h3>VQE paired benchmark execution cost</h3>'
        '<div class="domain-summary">'
        f"<span><strong>{_safe_int(totals.get('objective_backend_executions'))}</strong> objective Backend Jobs</span>"
        f"<span><strong>{_safe_int(totals.get('confirmation_backend_executions'))}</strong> confirmation Backend Jobs</span>"
        f"<span><strong>{_safe_int(totals.get('diagnostic_exact_backend_executions'))}</strong> diagnostic exact Jobs</span>"
        f"<span><strong>{_safe_int(totals.get('objective_shots'))}</strong> objective shots</span>"
        f"<span><strong>{_safe_int(totals.get('confirmation_shots'))}</strong> confirmation shots</span>"
        "</div>"
        + _table(
            (
                "Repeat",
                "Strategy",
                "Paired seed",
                "Objective evaluations",
                "Objective Backend Jobs",
                "Confirmation Backend Jobs",
                "Diagnostic exact Jobs",
                "Objective shots",
                "Confirmation shots",
                "Budget utilization",
            ),
            rows,
            label="VQE paired benchmark execution ledger",
        )
        + "</div>"
    )


def _render_vqe_sampling_benchmark_analysis(payload: Mapping[str, Any]) -> str:
    statistics = payload.get("statistics", ())
    statistic_rows = []
    for item in cast(Sequence[Any], statistics) if _is_sequence(statistics) else ():
        if not isinstance(item, Mapping):
            continue
        statistic_rows.append(
            "<tr>"
            f"<td><code>{_text(item.get('strategy', ''))}</code></td>"
            f"<td>{_format_number(item.get('mean_exact_selected_energy'))}</td>"
            f"<td>{_format_number(item.get('exact_selected_energy_interval_low'))}</td>"
            f"<td>{_format_number(item.get('exact_selected_energy_interval_high'))}</td>"
            f"<td>{_compact_value(item.get('mean_estimator_error'))}</td>"
            f"<td>{_compact_value(item.get('estimator_error_rmse'))}</td>"
            f"<td>{_format_number(item.get('mean_paired_exact_reference_gap'))}</td>"
            f"<td>{_format_number(item.get('paired_gap_interval_low'))}</td>"
            f"<td>{_format_number(item.get('paired_gap_interval_high'))}</td>"
            f"<td>{_format_number(item.get('mean_objective_budget_utilization'))}</td>"
            "</tr>"
        )
    runs = payload.get("runs", ())
    run_rows = []
    for item in cast(Sequence[Any], runs) if _is_sequence(runs) else ():
        if not isinstance(item, Mapping):
            continue
        run_rows.append(
            "<tr>"
            f"<td>{_safe_int(item.get('repeat_index'))}</td>"
            f"<td><code>{_text(item.get('strategy', ''))}</code></td>"
            f"<td>{_format_number(item.get('selected_estimator_energy'))}</td>"
            f"<td>{_format_number(item.get('exact_selected_energy'))}</td>"
            f"<td>{_format_number(item.get('estimator_error'))}</td>"
            f"<td>{_format_number(item.get('exact_reference_energy'))}</td>"
            f"<td>{_format_number(item.get('paired_exact_reference_gap'))}</td>"
            "</tr>"
        )
    return (
        '<div class="visual-group"><h3>VQE sampling strategy statistics</h3>'
        + _table(
            (
                "Strategy",
                "Mean exact-selected energy",
                "Energy interval low",
                "Energy interval high",
                "Mean estimator error",
                "Estimator RMSE",
                "Mean paired exact-reference gap",
                "Gap interval low",
                "Gap interval high",
                "Mean budget utilization",
            ),
            statistic_rows,
            label="VQE sampling strategy statistics",
        )
        + _table(
            (
                "Repeat",
                "Strategy",
                "Selected estimator energy",
                "Independent exact energy",
                "Estimator error",
                "Paired exact reference",
                "Paired exact-reference gap",
            ),
            run_rows,
            label="VQE paired benchmark run results",
        )
        + '<p class="empty-note">Exact is a paired same-Ansatz reference. This report does not claim a ground state, global optimum, or quantum advantage.</p>'
        "</div>"
    )


def _render_problem_validation(payload: Mapping[str, Any]) -> str:
    feasibility = payload.get("mode_feasibility")
    summary = (
        '<div class="domain-summary">'
        f"<span><strong>{_text(payload.get('selected_mode', ''))}</strong> selected mode</span>"
        f"<span><strong>{_text(payload.get('layout_valid', False))}</strong> layout valid</span>"
        f"<span><strong>{_text(payload.get('term_conservation', False))}</strong> term conservation</span>"
        f"<span><strong>{_text(payload.get('penalty_model_status', ''))}</strong> penalty model</span>"
        f"<span><strong>{_text(payload.get('penalty_sufficient', ''))}</strong> sufficient</span>"
        f"<span><strong>{_safe_int(payload.get('diagnostic_count'))}</strong> diagnostics</span>"
        "</div>"
    )
    if not isinstance(feasibility, Mapping):
        return summary
    return summary + _table(
        ("Mode", "Feasible", "Energy scale", "Diagnostics"),
        [
            "<tr>"
            f"<td><code>{_text(feasibility.get('mode', ''))}</code></td>"
            f"<td>{_status_badge('available' if feasibility.get('feasible') else 'error')}</td>"
            f"<td>{_format_number(feasibility.get('energy_scale'))}</td>"
            f"<td>{_compact_value(feasibility.get('diagnostic_codes'))}</td>"
            "</tr>"
        ],
        label="Selected mode feasibility",
    )


def _render_problem_plan(payload: Mapping[str, Any]) -> str:
    layout = payload.get("layout_visualization")
    term_mapping = payload.get("term_mapping", ())
    parameter_schema = payload.get("parameter_schema")
    ansatz = payload.get("ansatz")
    summary = (
        '<div class="domain-summary">'
        f"<span><strong>{_text(payload.get('target_id', ''))}</strong> target</span>"
        f"<span><strong>{_text(payload.get('layout_policy', ''))}</strong> layout</span>"
        f"<span><strong>{_sequence_length(term_mapping)}</strong> mapped terms</span>"
        f"<span><strong>{_text(payload.get('local_reference', False))}</strong> local reference</span>"
        f"<span><strong>{_text(payload.get('hardware_executable', False))}</strong> hardware executable</span>"
        "</div>"
    )
    layout_html = _render_register(layout) if isinstance(layout, Mapping) else ""
    mapping_rows = []
    for item in cast(Sequence[Any], term_mapping) if _is_sequence(term_mapping) else ():
        if not isinstance(item, Mapping):
            continue
        mapping_rows.append(
            "<tr>"
            f"<td><code>{_text(item.get('logical_term_id', ''))}</code></td>"
            f"<td>{_text(item.get('implementation', ''))}</td>"
            f"<td>{_format_number(item.get('logical_coefficient'))}</td>"
            f"<td>{_format_number(item.get('analog_coefficient'))}</td>"
            f"<td>{_format_number(item.get('digital_coefficient'))}</td>"
            "</tr>"
        )
    parameter_rows = []
    if isinstance(parameter_schema, Mapping):
        parameters = parameter_schema.get("parameters", ())
        for item in cast(Sequence[Any], parameters) if _is_sequence(parameters) else ():
            if not isinstance(item, Mapping):
                continue
            bounds = f"[{item.get('lower_bound')}, {item.get('upper_bound')}]"
            parameter_rows.append(
                "<tr>"
                f"<td><code>{_text(item.get('name', ''))}</code></td>"
                f"<td>{_text(item.get('unit', ''))}</td>"
                f"<td>{_text(bounds)}</td>"
                f"<td>{_text(item.get('compile_impact', ''))}</td>"
                "</tr>"
            )
    return (
        summary
        + '<div class="design-duo">'
        + layout_html
        + '<div class="visual-group"><h3>Parameter schema</h3>'
        + _table(
            ("Parameter", "Unit", "Bounds", "Compile impact"),
            parameter_rows,
            label="Problem parameter schema",
        )
        + "</div></div>"
        + '<div class="visual-group"><h3>Hamiltonian term assignment</h3>'
        + _table(
            ("Logical term", "Implementation", "Logical", "Analog", "Digital"),
            mapping_rows,
            label="Hamiltonian term assignment",
        )
        + "</div>"
        + (
            _render_ansatz_contract(
                ansatz,
                spec_hash=payload.get("ansatz_spec_hash"),
            )
            if isinstance(ansatz, Mapping)
            else ""
        )
        + _render_pauli_measurement_plan(payload.get("measurement_plan"))
        + _render_algorithm_objective_request(payload.get("objective_request"))
    )


def _render_problem_analysis(payload: Mapping[str, Any]) -> str:
    candidates = payload.get("candidates", ())
    candidate_breakdowns = payload.get("candidate_energy_breakdowns", ())
    history = payload.get("parameter_history", ())
    objective_history = payload.get("objective_history", history)
    baseline = payload.get("baseline")
    optimization = payload.get("optimization")
    gradient_html = _render_gradient_history(payload.get("gradient"))
    adam_html = _render_adam_history(payload.get("adam"))
    workflow_cost_html = _render_workflow_cost(payload.get("workflow_cost"))
    has_selected_weight = (
        any(
            isinstance(item, Mapping)
            and isinstance(item.get("decoded"), Mapping)
            and item["decoded"].get("selected_weight") is not None
            for item in cast(Sequence[Any], candidates)
        )
        if _is_sequence(candidates)
        else False
    )
    breakdown_by_bitstring = {
        str(item.get("bitstring")): item
        for item in (
            cast(Sequence[Any], candidate_breakdowns)
            if _is_sequence(candidate_breakdowns)
            else ()
        )
        if isinstance(item, Mapping)
    }
    candidate_rows = []
    for item in cast(Sequence[Any], candidates) if _is_sequence(candidates) else ():
        if not isinstance(item, Mapping):
            continue
        breakdown = breakdown_by_bitstring.get(str(item.get("bitstring", "")), {})
        decoded = item.get("decoded", {})
        selected_weight_cell = (
            f"<td>{_format_number(decoded.get('selected_weight'))}</td>"
            if has_selected_weight and isinstance(decoded, Mapping)
            else ("<td></td>" if has_selected_weight else "")
        )
        candidate_rows.append(
            "<tr>"
            f"<td><code>{_text(item.get('bitstring', ''))}</code></td>"
            f"<td>{_format_number(breakdown.get('business_objective'))}</td>"
            f"<td>{_format_number(breakdown.get('penalty_energy'))}</td>"
            f"<td>{_format_number(breakdown.get('total_objective'))}</td>"
            f"{selected_weight_cell}"
            f"<td>{_format_number(item.get('probability'))}</td>"
            f"<td>{_text(item.get('count', ''))}</td>"
            f"<td>{_text(item.get('feasible', ''))}</td>"
            "</tr>"
        )
    baseline_energy = (
        _finite_number(baseline.get("objective_value"))
        if isinstance(baseline, Mapping)
        else None
    )
    fallback = '<p class="empty-note">No parameter history available.</p>'
    history_html = (
        render_objective_history_bokeh_html(
            cast(Sequence[Any], objective_history),
            best_evaluation_index=_safe_int(
                payload.get("objective_selected_evaluation_index")
            ),
            baseline_energy=baseline_energy,
            identity_hint="problem.objective-history",
            fallback_html=fallback,
        )
        if _is_sequence(objective_history)
        else fallback
    )
    metrics_html = (
        render_problem_metrics_bokeh_html(
            cast(Sequence[Any], history),
            identity_hint="problem.optimization-metrics",
            fallback_html=(
                '<p class="empty-note">Constraint metrics are not defined '
                "for this Problem.</p>"
            ),
        )
        if _is_sequence(history)
        else fallback
    )
    parameters_html = (
        render_parameter_history_bokeh_html(
            cast(Sequence[Any], objective_history),
            identity_hint="problem.parameter-history",
            fallback_html=fallback,
        )
        if _is_sequence(objective_history)
        else fallback
    )
    selected_index = _safe_int(payload.get("selected_evaluation_index"))
    selected: Mapping[str, Any] | None = None
    if _is_sequence(history):
        for item in cast(Sequence[Any], history):
            if (
                isinstance(item, Mapping)
                and _safe_int(item.get("evaluation_index")) == selected_index
            ):
                selected = item
                break
    selected_metrics = {} if selected is None else selected
    baseline_summary = (
        '<div class="domain-summary">'
        f"<span><strong>{_format_number(selected_metrics.get('baseline_objective'))}</strong> classical baseline</span>"
        f"<span><strong>{_format_number(selected_metrics.get('expected_objective_gap'))}</strong> expected gap</span>"
        f"<span><strong>{_format_number(selected_metrics.get('best_observed_objective_gap'))}</strong> best candidate gap</span>"
        "</div>"
        if selected_metrics.get("baseline_objective") is not None
        else (
            '<p class="empty-note">Classical baseline is unavailable for '
            "this Problem size.</p>"
        )
    )
    starts_html = (
        _render_optimization_starts(
            optimization.get("starts", ()),
            selected_start_index=_safe_int(optimization.get("selected_start_index")),
        )
        if isinstance(optimization, Mapping)
        else ""
    )
    expected_breakdown = payload.get("expected_energy_breakdown")
    if isinstance(expected_breakdown, Mapping):
        constraint_rows = []
        constraint_penalties = expected_breakdown.get("constraint_penalties", ())
        for item in (
            cast(Sequence[Any], constraint_penalties)
            if _is_sequence(constraint_penalties)
            else ()
        ):
            if not isinstance(item, Mapping):
                continue
            constraint_rows.append(
                "<tr>"
                f"<td><code>{_text(item.get('constraint_id', ''))}</code></td>"
                f"<td><code>{_compact_value(item.get('targets'))}</code></td>"
                f"<td>{_format_number(item.get('coefficient'))}</td>"
                f"<td>{_format_number(item.get('activation'))}</td>"
                f"<td>{_format_number(item.get('contribution'))}</td>"
                "</tr>"
            )
        energy_html = (
            '<div class="visual-group"><h3>Expected energy decomposition</h3>'
            '<div class="domain-summary">'
            f"<span><strong>{_format_number(expected_breakdown.get('business_objective'))}</strong> business objective</span>"
            f"<span><strong>{_format_number(expected_breakdown.get('penalty_energy'))}</strong> penalty energy</span>"
            f"<span><strong>{_format_number(expected_breakdown.get('total_objective'))}</strong> total objective</span>"
            "</div>"
            + (
                _table(
                    (
                        "Constraint",
                        "Targets",
                        "Coefficient",
                        "Activation probability",
                        "Contribution",
                    ),
                    constraint_rows,
                    label="Constraint penalty contributions",
                )
                if constraint_rows
                else (
                    '<p class="empty-note">No explicit penalty model is defined for '
                    "this Problem; all canonical terms remain in the business objective."
                    "</p>"
                )
            )
            + "</div>"
        )
    else:
        energy_html = ""
    return (
        '<div class="domain-summary">'
        f"<span><strong>{_format_number(payload.get('objective_value'))}</strong> expected objective</span>"
        f"<span><strong>{_text(payload.get('feasibility', ''))}</strong> best observed feasibility</span>"
        f"<span><strong>{_format_number(selected_metrics.get('feasible_probability'))}</strong> feasible probability</span>"
        f"<span><strong>{_format_number(selected_metrics.get('expected_constraint_violation_count'))}</strong> expected constraint violations</span>"
        + (
            f"<span><strong>{_format_number(payload.get('expected_selected_weight'))}</strong> expected selected weight</span>"
            if payload.get("expected_selected_weight") is not None
            else ""
        )
        + f"<span><strong>{_sequence_length(candidates)}</strong> observed candidates</span>"
        f"<span><strong>{_text(payload.get('optimality_claim', ''))}</strong> optimality claim</span>"
        "</div>"
        + starts_html
        + workflow_cost_html
        + adam_html
        + energy_html
        + '<div class="visual-group"><h3>Objective history</h3>'
        + history_html
        + "</div>"
        + _render_sampled_selection(payload.get("sampled_selection"))
        + '<div class="visual-group"><h3>Optimization metrics</h3>'
        + metrics_html
        + "</div>"
        + '<div class="visual-group"><h3>Parameter trajectories</h3>'
        + parameters_html
        + "</div>"
        + gradient_html
        + '<div class="visual-group"><h3>Classical baseline and gap</h3>'
        + baseline_summary
        + "</div>"
        + '<div class="visual-group"><h3>Decoded candidates</h3>'
        + _table(
            (
                "Bitstring",
                "Business objective",
                "Penalty energy",
                "Total objective",
                *(("Selected weight",) if has_selected_weight else ()),
                "Probability",
                "Count",
                "Feasible",
            ),
            candidate_rows,
            label="Decoded Problem candidates",
        )
        + "</div>"
    )


def _render_problem_comparison_plan(payload: Mapping[str, Any]) -> str:
    sources = payload.get("sources", ())
    rows = []
    for item in cast(Sequence[Any], sources) if _is_sequence(sources) else ():
        if not isinstance(item, Mapping):
            continue
        rows.append(
            "<tr>"
            f"<td>{_text(item.get('label', ''))}</td>"
            f"<td>{_text(item.get('mode', ''))}</td>"
            f"<td>{_text(item.get('algorithm', ''))}</td>"
            f"<td>{_compact_value(item.get('layers'))}</td>"
            f"<td><code>{_text(item.get('target_id', ''))}</code></td>"
            f"<td>{_safe_int(item.get('analog_term_count'))}</td>"
            f"<td>{_safe_int(item.get('digital_term_count'))}</td>"
            f"<td>{_safe_int(item.get('parameter_count'))}</td>"
            f"<td>{_safe_int(item.get('evaluation_count'))}</td>"
            f"<td><code>{_short_hash(item.get('compile_hash'))}</code></td>"
            f"<td><code>{_short_hash(item.get('program_hash'))}</code></td>"
            "</tr>"
        )
    return _table(
        (
            "Label",
            "Mode",
            "Algorithm",
            "Layers",
            "Target",
            "Analog terms",
            "Digital terms",
            "Parameters",
            "Evaluations",
            "Compile hash",
            "Program hash",
        ),
        rows,
        label="Problem comparison compilation plans",
    )


def _render_problem_comparison_analysis(payload: Mapping[str, Any]) -> str:
    series = payload.get("series")
    summaries = payload.get("summaries", ())
    comparison_html = (
        render_problem_comparison_bokeh_html(
            series,
            identity_hint="problem.layer-comparison",
            fallback_html=(
                '<p class="empty-note">No optimization histories are available.</p>'
            ),
        )
        if isinstance(series, Mapping)
        else '<p class="empty-note">No optimization histories are available.</p>'
    )
    rows = []
    candidate_blocks = []
    resource_rows = []
    for item in cast(Sequence[Any], summaries) if _is_sequence(summaries) else ():
        if not isinstance(item, Mapping):
            continue
        energy = item.get("expected_energy_breakdown")
        energy = energy if isinstance(energy, Mapping) else {}
        rows.append(
            "<tr>"
            f"<td>{_text(item.get('label', ''))}</td>"
            f"<td>{_text(item.get('mode', ''))}</td>"
            f"<td>{_text(item.get('algorithm', ''))}</td>"
            f"<td>{_compact_value(item.get('layers'))}</td>"
            f"<td>{_safe_int(item.get('parameter_count'))}</td>"
            f"<td>{_safe_int(item.get('evaluation_count'))}</td>"
            f"<td>{_safe_int(item.get('shots'))}</td>"
            f"<td>{_text(item.get('probability_source', ''))}</td>"
            f"<td>{_format_number(energy.get('business_objective'))}</td>"
            f"<td>{_format_number(energy.get('penalty_energy'))}</td>"
            f"<td>{_format_number(energy.get('total_objective'))}</td>"
            f"<td>{_format_number(item.get('minimum_objective'))}</td>"
            f"<td>{_format_number(item.get('feasible_probability'))}</td>"
            f"<td>{_format_number(item.get('expected_constraint_violation_count'))}</td>"
            f"<td>{_format_number(item.get('expected_objective_gap'))}</td>"
            "</tr>"
        )
        candidate_blocks.append(
            _render_candidate(
                item.get("best_observed_candidate"),
                title=f"{item.get('label', '')} best observed candidate",
            )
        )
        resource_rows.append(
            "<tr>"
            f"<td>{_text(item.get('label', ''))}</td>"
            f"<td>{_compact_value(item.get('execution_method'))}</td>"
            f"<td>{_format_number(item.get('wall_time_seconds'))}</td>"
            f"<td>{_compact_value(item.get('estimated_peak_bytes'))}</td>"
            f"<td>{_compact_value(item.get('resource_measurement_status'))}</td>"
            f"<td>{_text(item.get('local_reference', True))}</td>"
            f"<td>{_text(item.get('hardware_executable', False))}</td>"
            "</tr>"
        )
    comparison_kind = str(payload.get("comparison_kind", "configuration"))
    algorithm = ""
    if comparison_kind == "layer" and summaries and _is_sequence(summaries):
        first_summary = cast(Sequence[Any], summaries)[0]
        if isinstance(first_summary, Mapping):
            algorithm = str(first_summary.get("algorithm", "")).upper()
    comparison_title = {
        "route": "Problem route comparison",
        "layer": f"{algorithm} layer comparison",
        "configuration": "Problem configuration comparison",
    }.get(comparison_kind, "Problem configuration comparison")
    layer_experiment = payload.get("layer_experiment")
    layer_html = (
        _render_layer_experiment_analysis(layer_experiment)
        if isinstance(layer_experiment, Mapping)
        else ""
    )
    repeated_experiment = payload.get("repeated_layer_experiment")
    repeated_html = (
        _render_repeated_layer_experiment_analysis(repeated_experiment)
        if isinstance(repeated_experiment, Mapping)
        else ""
    )
    return (
        layer_html
        + repeated_html
        + f'<div class="visual-group"><h3>{_text(comparison_title)}</h3>'
        + comparison_html
        + "</div>"
        + _table(
            (
                "Label",
                "Mode",
                "Algorithm",
                "Layers",
                "Parameters",
                "Evaluations",
                "Shots",
                "Probability source",
                "Business objective",
                "Penalty energy",
                "Total objective",
                "Minimum objective",
                "Feasible probability",
                "Expected constraint violations",
                "Expected gap",
            ),
            rows,
            label=f"{comparison_title} summary",
        )
        + '<div class="visual-group"><h3>Route resource evidence</h3>'
        + _table(
            (
                "Label",
                "Method",
                "Wall time (s)",
                "Estimated peak bytes",
                "Measurement status",
                "Local reference",
                "Hardware executable",
            ),
            resource_rows,
            label="Route resource evidence",
        )
        + "</div>"
        + '<div class="algorithm-columns">'
        + "".join(candidate_blocks)
        + "</div>"
    )


def _render_layer_experiment_analysis(payload: Mapping[str, Any]) -> str:
    rows = []
    steps = payload.get("steps", ())
    for step in cast(Sequence[Any], steps) if _is_sequence(steps) else ():
        if not isinstance(step, Mapping):
            continue
        rows.append(
            "<tr>"
            f"<td>{_safe_int(step.get('layers'))}</td>"
            f"<td>{_format_number(step.get('layer_objective'))}</td>"
            f"<td>{_format_number(step.get('objective_value'))}</td>"
            f"<td>{_format_number(step.get('improvement_from_incumbent'))}</td>"
            f"<td>{_text(step.get('material_improvement', False))}</td>"
            f"<td>{_safe_int(step.get('incumbent_layer'))}</td>"
            f"<td>{_safe_int(step.get('no_improvement_count'))}</td>"
            f"<td>{_safe_int(step.get('evaluation_count'))}</td>"
            f"<td>{_safe_int(step.get('backend_execution_count'))}</td>"
            f"<td>{_compact_value(step.get('selected_candidate_rank'))}</td>"
            f"<td>{_format_number(step.get('selected_candidate_standard_error'))}</td>"
            f"<td>{_safe_int(step.get('start_count'))}</td>"
            f"<td>{_compact_value(step.get('first_start_initialization'))}</td>"
            "</tr>"
        )
    objective_source = {
        "expected_problem_objective": "Expected Problem objective",
        "independent_confirmation_mean": "Independent confirmation mean",
    }.get(str(payload.get("layer_objective_source", "")), "")
    summary = (
        '<div class="domain-summary">'
        f"<span><strong>{_safe_int(payload.get('executed_layer_count'))}</strong> executed layers</span>"
        f"<span><strong>{_safe_int(payload.get('selected_layers'))}</strong> selected layers</span>"
        f"<span><strong>{_text(payload.get('stop_reason', ''))}</strong> stop reason</span>"
        f"<span><strong>{_safe_int(payload.get('total_evaluation_count'))}</strong> total evaluations</span>"
        f"<span><strong>{_text(objective_source)}</strong> Layer objective source</span>"
        f"<span><strong>{_format_number(payload.get('min_improvement'))}</strong> minimum improvement</span>"
        f"<span><strong>{_safe_int(payload.get('patience'))}</strong> patience</span>"
        "</div>"
    )
    cost = (
        '<div class="domain-summary">'
        f"<span><strong>{_safe_int(payload.get('total_backend_execution_count'))}</strong> objective Backend Jobs</span>"
        f"<span><strong>{_safe_int(payload.get('total_confirmation_backend_execution_count'))}</strong> confirmation Backend Jobs</span>"
        f"<span><strong>{_safe_int(payload.get('total_workflow_backend_execution_count'))}</strong> workflow Backend Jobs</span>"
        f"<span><strong>{_safe_int(payload.get('total_objective_shots'))}</strong> objective shots</span>"
        f"<span><strong>{_safe_int(payload.get('total_confirmation_shots'))}</strong> confirmation shots</span>"
        f"<span><strong>{_safe_int(payload.get('total_final_sampling_shots'))}</strong> final sampling shots</span>"
        f"<span><strong>{_safe_int(payload.get('total_workflow_shots'))}</strong> workflow shots</span>"
        "</div>"
    )
    return (
        '<div class="visual-group"><h3>Automatic layer selection</h3>'
        + summary
        + cost
        + _table(
            (
                "Layers",
                "Layer objective",
                "Final Problem objective",
                "Improvement from incumbent",
                "Material improvement",
                "Incumbent layer",
                "No-improvement count",
                "Evaluations",
                "Backend Jobs",
                "Candidate rank",
                "Confirmation standard error",
                "Optimizer starts",
                "First start",
            ),
            rows,
            label="Layer selection history",
        )
        + "</div>"
    )


def _render_repeated_layer_experiment_analysis(payload: Mapping[str, Any]) -> str:
    rows = []
    steps = payload.get("steps", ())
    for step in cast(Sequence[Any], steps) if _is_sequence(steps) else ():
        if not isinstance(step, Mapping):
            continue
        comparison = step.get("comparison")
        paired = comparison if isinstance(comparison, Mapping) else {}
        interval = (
            f"[{_format_number(step.get('confidence_interval_low'))}, "
            f"{_format_number(step.get('confidence_interval_high'))}]"
        )
        rows.append(
            "<tr>"
            f"<td>{_safe_int(step.get('layers'))}</td>"
            f"<td>{_safe_int(step.get('sample_count'))}</td>"
            f"<td>{_format_number(step.get('mean_objective'))}</td>"
            f"<td>{_format_number(step.get('sample_variance'))}</td>"
            f"<td>{_format_number(step.get('standard_error'))}</td>"
            f"<td>{interval}</td>"
            f"<td>{_format_number(paired.get('mean_improvement'))}</td>"
            f"<td>{_format_number(paired.get('lower_confidence_bound'))}</td>"
            f"<td>{_text(step.get('material_improvement', False))}</td>"
            f"<td>{_safe_int(step.get('incumbent_layer'))}</td>"
            f"<td>{_safe_int(step.get('optimization_count'))}</td>"
            f"<td>{_safe_int(step.get('evaluation_count'))}</td>"
            "</tr>"
        )
    plot = render_repeated_layer_statistics_bokeh_html(
        payload,
        identity_hint=str(payload.get("experiment_id", "repeated-layer")),
        fallback_html='<p class="empty-note">No repeated layer statistics are available.</p>',
    )
    summary = (
        '<div class="domain-summary">'
        f"<span><strong>{_safe_int(payload.get('executed_layer_count'))}</strong> executed layers</span>"
        f"<span><strong>{_safe_int(payload.get('repeats'))}</strong> repeats per layer</span>"
        f"<span><strong>{_safe_int(payload.get('selected_layers'))}</strong> selected layers</span>"
        f"<span><strong>{_text(payload.get('stop_reason', ''))}</strong> stop reason</span>"
        f"<span><strong>{_format_number(payload.get('confidence_level'))}</strong> confidence level</span>"
        f"<span><strong>{_safe_int(payload.get('total_optimization_count'))}</strong> optimizations</span>"
        f"<span><strong>{_safe_int(payload.get('total_evaluation_count'))}</strong> total evaluations</span>"
        "</div>"
    )
    return (
        '<div class="visual-group"><h3>Repeated layer statistics</h3>'
        + summary
        + plot
        + _table(
            (
                "Layers",
                "Samples",
                "Mean objective",
                "Sample variance",
                "Standard error",
                "Confidence interval",
                "Paired mean improvement",
                "Lower confidence bound",
                "Material improvement",
                "Incumbent layer",
                "Optimizations",
                "Evaluations",
            ),
            rows,
            label="Layer statistics and selection history",
        )
        + "</div>"
    )


def _render_design(profile: str, payload: Mapping[str, Any]) -> str:
    if profile == "digital":
        return _render_circuit(payload)
    if profile == "analog":
        return _render_analog_design(payload)
    if profile == "hybrid":
        blocks = payload.get("blocks", ())
        if not _is_sequence(blocks):
            return ""
        rendered = [
            '<div class="domain-summary">'
            f"<span><strong>{_safe_int(payload.get('block_count'))}</strong> blocks</span>"
            f"<span><strong>{_safe_int(payload.get('parameter_count'))}</strong> parameters</span>"
            "</div>"
        ]
        for block in blocks:
            if not isinstance(block, Mapping):
                continue
            block_type = str(block.get("block_type", "unknown"))
            block_id = str(block.get("block_id", "block"))
            if block_type == "analog":
                body = _render_analog_design(block)
            elif block_type == "digital":
                body = _render_circuit(block)
            else:
                body = _render_measurement_contract(block)
            rendered.append(
                '<article class="experiment-block">'
                f'<div class="block-label">{_text(block_type)} / <code>{_text(block_id)}</code></div>'
                f"{body}</article>"
            )
        return "".join(rendered)
    if profile == "sweep":
        return _render_sweep_parameters(payload)
    if profile == "batch":
        return _render_batch_parameters(payload)
    return _render_key_metrics(payload)


def _render_circuit(payload: Mapping[str, Any]) -> str:
    gates = payload.get("gates", ())
    measurements = payload.get("measurements", ())
    qubits = payload.get("qubits", ())
    overview = (
        '<div class="domain-summary">'
        f"<span><strong>{_sequence_length(qubits)}</strong> qubits</span>"
        f"<span><strong>{_safe_int(payload.get('gate_count', _sequence_length(gates)))}</strong> gates</span>"
        f"<span><strong>{_sequence_length(measurements)}</strong> measurements</span>"
        "</div>"
    )
    if not _is_sequence(gates) or not gates:
        return overview + '<p class="empty-note">No gates in this block.</p>'
    rows = []
    for index, gate in enumerate(gates):
        if not isinstance(gate, Mapping):
            continue
        operation = gate.get("operation", gate.get("name", gate.get("gate", "gate")))
        targets = gate.get("targets", gate.get("qubits", ()))
        controls = gate.get("controls", ())
        parameters = gate.get("parameters", gate.get("params", {}))
        rows.append(
            "<tr>"
            f"<td>{index}</td><td><strong>{_text(operation)}</strong></td>"
            f"<td>{_compact_value(controls)}</td><td>{_compact_value(targets)}</td>"
            f"<td>{_compact_value(parameters)}</td>"
            "</tr>"
        )
    return (
        overview
        + _render_circuit_diagram(
            cast(Sequence[Any], qubits) if _is_sequence(qubits) else (),
            cast(Sequence[Any], gates),
            cast(Sequence[Any], measurements) if _is_sequence(measurements) else (),
        )
        + _table(
            ("#", "Operation", "Controls", "Targets", "Parameters"),
            rows,
            label="Circuit operations",
        )
    )


def _render_circuit_diagram(
    qubits: Sequence[Any],
    gates: Sequence[Any],
    measurements: Sequence[Any],
) -> str:
    names = [str(item) for item in qubits]
    if not names:
        return ""
    wire_gap = 52
    top = 34
    left = 92
    operation_gap = 68
    measurement_columns = 1 if measurements else 0
    width = max(720, left + (len(gates) + measurement_columns + 1) * operation_gap)
    height = max(150, top * 2 + (len(names) - 1) * wire_gap)
    y_by_name = {name: top + index * wire_gap for index, name in enumerate(names)}
    elements = []
    for name, y in y_by_name.items():
        elements.append(
            f'<text class="circuit-label" x="8" y="{y + 4}">{_text(name)}</text>'
            f'<line class="circuit-wire" x1="{left}" y1="{y}" x2="{width - 24}" y2="{y}"/>'
        )
    for index, gate in enumerate(gates):
        if not isinstance(gate, Mapping):
            continue
        x = left + (index + 1) * operation_gap
        operation = str(
            gate.get("operation", gate.get("name", gate.get("gate", "U")))
        ).upper()
        controls = [
            str(item) for item in gate.get("controls", ()) if str(item) in y_by_name
        ]
        targets = [
            str(item)
            for item in gate.get("targets", gate.get("qubits", ()))
            if str(item) in y_by_name
        ]
        involved = [*controls, *targets]
        if len(involved) > 1:
            ys = [y_by_name[name] for name in involved]
            elements.append(
                f'<line class="circuit-link" x1="{x}" y1="{min(ys)}" x2="{x}" y2="{max(ys)}"/>'
            )
        for name in controls:
            y = y_by_name[name]
            elements.append(
                f'<circle class="circuit-control" cx="{x}" cy="{y}" r="5"/>'
            )
        for name in targets:
            y = y_by_name[name]
            if operation in {"CX", "CNOT"} and controls:
                elements.append(
                    f'<circle class="circuit-target" cx="{x}" cy="{y}" r="13"/>'
                    f'<line class="circuit-target-mark" x1="{x - 8}" y1="{y}" x2="{x + 8}" y2="{y}"/>'
                    f'<line class="circuit-target-mark" x1="{x}" y1="{y - 8}" x2="{x}" y2="{y + 8}"/>'
                )
            else:
                label = operation if len(operation) <= 5 else operation[:5]
                elements.append(
                    f'<rect class="circuit-gate" x="{x - 21}" y="{y - 15}" width="42" height="30" rx="3"/>'
                    f'<text class="circuit-gate-label" x="{x}" y="{y + 4}">{_text(label)}</text>'
                )
    if measurements:
        x = left + (len(gates) + 1) * operation_gap
        for y in y_by_name.values():
            elements.append(
                f'<rect class="circuit-measure" x="{x - 19}" y="{y - 14}" width="38" height="28" rx="3"/>'
                f'<text class="circuit-gate-label" x="{x}" y="{y + 4}">M</text>'
            )
    return (
        '<div class="visual-group"><h3>Quantum circuit</h3>'
        '<div class="circuit-scroll">'
        f'<svg class="circuit-diagram" viewBox="0 0 {width} {height}" '
        f'width="{width}" height="{height}" role="img" '
        f'aria-label="Quantum circuit with {len(names)} qubits and {len(gates)} gates">'
        + "".join(elements)
        + "</svg></div></div>"
    )


def _render_algorithm_design(payload: Mapping[str, Any]) -> str:
    hamiltonian = payload.get("hamiltonian", {})
    ansatz = payload.get("ansatz", {})
    if not isinstance(hamiltonian, Mapping) or not isinstance(ansatz, Mapping):
        return '<p class="empty-note">Algorithm design facts are unavailable.</p>'
    terms = hamiltonian.get("terms", ())
    rows = []
    if _is_sequence(terms):
        for term in terms:
            if not isinstance(term, Mapping):
                continue
            rows.append(
                "<tr>"
                f"<td><code>{_text(term.get('term_id', ''))}</code></td>"
                f"<td>{_compact_value(term.get('coefficient'))}</td>"
                f"<td>{_text(term.get('observable_name', ''))}</td>"
                f"<td>{_compact_value(term.get('targets'))}</td>"
                f"<td>{_compact_value(term.get('bases'))}</td>"
                "</tr>"
            )
    parameters = ansatz.get("parameter_names", ())
    overview = (
        '<div class="domain-summary">'
        f"<span><strong>{_text(payload.get('algorithm_kind', ''))}</strong> algorithm</span>"
        f"<span><strong>{_safe_int(hamiltonian.get('term_count'))}</strong> Hamiltonian terms</span>"
        f"<span><strong>{_safe_int(ansatz.get('layers'))}</strong> layers</span>"
        f"<span><strong>{_sequence_length(parameters)}</strong> parameters</span>"
        "</div>"
    )
    facts = _table(
        ("Term", "Coefficient", "Observable", "Targets", "Bases"),
        rows,
        label="Hamiltonian terms",
    )
    return (
        overview
        + '<div class="visual-group"><h3>Hamiltonian terms</h3>'
        + facts
        + "</div>"
        + '<div class="visual-group"><h3>Ansatz</h3>'
        + _render_value(ansatz, key_hint="ansatz")
        + "</div>"
    )


def _render_sampled_objective_stage(
    stage: str,
    payload: Mapping[str, Any],
) -> str:
    """Render one fixed-parameter sampled VQE lifecycle stage."""
    if stage == "design":
        return _render_sampled_objective_design(payload)
    if stage == "validate":
        return _render_algorithm_validation(payload)
    if stage == "plan":
        return _render_sampled_objective_plan(payload)
    if stage == "execute":
        return _render_sampled_objective_execution(payload)
    if stage == "state":
        return _render_sampled_objective_state(payload)
    if stage == "measure":
        return _render_sampled_objective_measurement(payload)
    if stage == "analyze":
        return _render_sampled_objective_analysis(payload)
    return ""


def _render_sampled_objective_design(payload: Mapping[str, Any]) -> str:
    hamiltonian = payload.get("hamiltonian", {})
    ansatz = payload.get("ansatz", {})
    if not isinstance(hamiltonian, Mapping) or not isinstance(ansatz, Mapping):
        return '<p class="empty-note">Sampled VQE design facts are unavailable.</p>'
    rows = []
    terms = hamiltonian.get("terms", ())
    for term in cast(Sequence[Any], terms) if _is_sequence(terms) else ():
        if not isinstance(term, Mapping):
            continue
        rows.append(
            "<tr>"
            f"<td>{_safe_int(term.get('term_index'))}</td>"
            f"<td><code>{_text(term.get('term_id', ''))}</code></td>"
            f"<td>{_format_number(term.get('coefficient'))}</td>"
            f"<td>{_text(term.get('observable_name', ''))}</td>"
            f"<td>{_compact_value(term.get('targets'))}</td>"
            f"<td>{_compact_value(term.get('bases'))}</td>"
            "</tr>"
        )
    return (
        '<div class="domain-summary">'
        f"<span><strong>VQE</strong> algorithm</span>"
        f"<span><strong>{_safe_int(hamiltonian.get('term_count'))}</strong> Hamiltonian terms</span>"
        f"<span><strong>{_sequence_length(hamiltonian.get('logical_order'))}</strong> qubits</span>"
        f"<span><strong>{_sequence_length(ansatz.get('parameter_names'))}</strong> bound parameters</span>"
        "</div>"
        '<div class="visual-group"><h3>Hamiltonian terms</h3>'
        + _table(
            ("Index", "Term", "Coefficient", "Observable", "Targets", "Bases"),
            rows,
            label="Hamiltonian terms",
        )
        + "</div>"
        '<div class="visual-group"><h3>Source Circuit</h3>'
        + _table(
            ("Field", "Value"),
            [
                f"<tr><td>Logical order</td><td>{_compact_value(ansatz.get('logical_order'))}</td></tr>",
                f"<tr><td>Parameters</td><td>{_compact_value(ansatz.get('parameter_names'))}</td></tr>",
                f"<tr><td>Circuit hash</td><td><code>{_text(ansatz.get('circuit_hash', ''))}</code></td></tr>",
            ],
            label="Source Circuit",
        )
        + "</div>"
    )


def _render_sampled_objective_plan(payload: Mapping[str, Any]) -> str:
    rows = []
    groups = payload.get("groups", ())
    for group in cast(Sequence[Any], groups) if _is_sequence(groups) else ():
        if not isinstance(group, Mapping):
            continue
        rows.append(
            "<tr>"
            f"<td>{_safe_int(group.get('group_index'))}</td>"
            f"<td>{_compact_value(group.get('basis_by_target'))}</td>"
            f"<td>{_compact_value(group.get('term_ids'))}</td>"
            f"<td>{_compact_value(group.get('term_indices'))}</td>"
            f"<td>{_safe_int(group.get('shots'))}</td>"
            f"<td>{_safe_int(group.get('final_shots'))}</td>"
            "</tr>"
        )
    return (
        '<div class="domain-summary">'
        f"<span><strong>{_text(payload.get('grouping', ''))}</strong> grouping</span>"
        f"<span><strong>{_text(payload.get('allocation', ''))}</strong> allocation</span>"
        f"<span><strong>{_sequence_length(groups)}</strong> measurement groups</span>"
        f"<span><strong>{_safe_int(payload.get('shots_per_group'))}</strong> Reference shots / group</span>"
        f"<span><strong>{_safe_int(payload.get('total_shots'))}</strong> total shots</span>"
        f"<span><strong>{_safe_int(payload.get('backend_execution_count'))}</strong> Backend Jobs</span>"
        f"<span><strong>{_text(payload.get('resolved_seed', ''))}</strong> root seed</span>"
        "</div>"
        '<div class="visual-group"><h3>QWC measurement groups</h3>'
        + _table(
            (
                "Group",
                "Local basis",
                "Terms",
                "Term indices",
                "Initial shots",
                "Final shots",
            ),
            rows,
            label="QWC measurement groups",
        )
        + "</div>"
        '<div class="visual-group"><h3>Measurement contract</h3>'
        + _table(
            ("Field", "Value"),
            [
                f"<tr><td>Required gates</td><td>{_compact_value(payload.get('required_gates'))}</td></tr>",
                f"<tr><td>Plan id</td><td><code>{_text(payload.get('plan_id', ''))}</code></td></tr>",
                f"<tr><td>Plan hash</td><td><code>{_text(payload.get('plan_hash', ''))}</code></td></tr>",
                f"<tr><td>Parameter bind</td><td>{_compact_value(payload.get('parameter_bind'))}</td></tr>",
            ],
            label="Measurement contract",
        )
        + "</div>"
        + _render_algorithm_objective_request(payload.get("objective_request"))
    )


def _render_sampled_objective_execution(payload: Mapping[str, Any]) -> str:
    rows = []
    executions = payload.get("group_executions", ())
    for item in cast(Sequence[Any], executions) if _is_sequence(executions) else ():
        if not isinstance(item, Mapping):
            continue
        rows.append(
            "<tr>"
            f"<td>{_safe_int(item.get('group_index'))}</td>"
            f"<td>{_text(item.get('stage', ''))}</td>"
            f"<td>{_text(item.get('seed', ''))}</td>"
            f"<td>{_safe_int(item.get('shots'))}</td>"
            f"<td><code>{_text(item.get('backend_job_id', ''))}</code></td>"
            f"<td><code>{_text(item.get('result_id', ''))}</code></td>"
            f"<td>{_format_duration(item.get('wall_time_seconds'))}</td>"
            "</tr>"
        )
    return (
        '<div class="domain-summary">'
        f"<span><strong>{_safe_int(payload.get('backend_execution_count'))}</strong> Backend Jobs</span>"
        f"<span><strong>{_safe_int(payload.get('backend_result_count'))}</strong> Backend Results</span>"
        f"<span><strong>{_format_duration(payload.get('total_wall_time_seconds'))}</strong> wall time</span>"
        f"<span><strong>{_compact_value(payload.get('parameters'))}</strong> parameters</span>"
        "</div>"
        '<div class="visual-group"><h3>Measurement group Jobs</h3>'
        + _table(
            (
                "Group",
                "Stage",
                "Seed",
                "Shots",
                "Backend Job",
                "Result",
                "Wall time",
            ),
            rows,
            label="Measurement group Jobs",
        )
        + "</div>"
        + _render_algorithm_objective_execution(payload.get("objective_execution"))
    )


def _render_sampled_objective_state(payload: Mapping[str, Any]) -> str:
    def contribution_table(title: str, value: object) -> str:
        rows = []
        for item in cast(Sequence[Any], value) if _is_sequence(value) else ():
            if not isinstance(item, Mapping):
                continue
            rows.append(
                "<tr>"
                f"<td><code>{_text(item.get('term_id', ''))}</code></td>"
                f"<td>{_text(item.get('observable_name', ''))}</td>"
                f"<td>{_format_number(item.get('coefficient'))}</td>"
                f"<td>{_format_number(item.get('expectation'))}</td>"
                f"<td>{_format_number(item.get('standard_error'))}</td>"
                f"<td>{_format_number(item.get('contribution'))}</td>"
                "</tr>"
            )
        return (
            f'<div class="visual-group"><h3>{_text(title)}</h3>'
            + _table(
                (
                    "Term",
                    "Observable",
                    "Coefficient",
                    "Expectation",
                    "Standard error",
                    "Contribution",
                ),
                rows,
                label=title,
            )
            + "</div>"
        )

    mitigated = payload.get("mitigated_contributions", ())
    contribution_html = (
        contribution_table("Raw Pauli expectations", payload.get("raw_contributions"))
        + contribution_table("Mitigated Pauli expectations", mitigated)
        if _sequence_length(mitigated) > 0
        else contribution_table("Pauli expectations", payload.get("contributions"))
    )
    return (
        '<div class="domain-summary">'
        f"<span><strong>{_text(payload.get('estimator', ''))}</strong> estimator</span>"
        f"<span><strong>{_text(payload.get('source_kind', ''))}</strong> source</span>"
        f"<span><code>{_short_hash(payload.get('observable_source_hash'))}</code> source hash</span>"
        "</div>" + contribution_html
    )


def _render_sampled_objective_measurement(payload: Mapping[str, Any]) -> str:
    parts = [
        '<div class="domain-summary">'
        f"<span><strong>{_safe_int(payload.get('total_shots'))}</strong> total shots</span>"
        f"<span><strong>{_text(payload.get('allocation', ''))}</strong> allocation</span>"
        f"<span><strong>{_safe_int(payload.get('shots_per_group'))}</strong> Reference shots / group</span>"
        f"<span><strong>{_compact_value(payload.get('shots_by_group'))}</strong> Actual group shots</span>"
        f"<span><strong>{_compact_value(payload.get('pilot_shots_by_group'))}</strong> Pilot shots</span>"
        f"<span><strong>{_compact_value(payload.get('additional_shots_by_group'))}</strong> Additional shots</span>"
        f"<span><strong>{_sequence_length(payload.get('groups'))}</strong> groups</span>"
        "</div>"
    ]
    groups = payload.get("groups", ())
    for group in cast(Sequence[Any], groups) if _is_sequence(groups) else ():
        if not isinstance(group, Mapping):
            continue
        group_index = _safe_int(group.get("group_index"))
        mitigated_value = group.get("mitigated_statistics")
        mitigated = mitigated_value if isinstance(mitigated_value, Mapping) else None
        mitigation_summary = ""
        if mitigated is not None:
            mitigation_summary = (
                f"<span><strong>{_format_number(mitigated.get('energy_mean'))}</strong> mitigated group energy</span>"
                f"<span><strong>{_format_number(mitigated.get('energy_standard_error'))}</strong> mitigated standard error</span>"
                f"<span><strong>{_format_number(mitigated.get('variance_amplification'))}</strong> variance amplification</span>"
            )
        parts.append(
            '<div class="visual-group"><h3>'
            f"Measurement group {group_index}</h3>"
            '<div class="domain-summary">'
            f"<span><strong>{_compact_value(group.get('basis_by_target'))}</strong> local basis</span>"
            f"<span><strong>{_format_number(group.get('energy_mean'))}</strong> group energy</span>"
            f"<span><strong>{_format_number(group.get('energy_standard_error'))}</strong> energy standard error</span>"
            f"{mitigation_summary}"
            f"<span><strong>{_compact_value(group.get('seeds'))}</strong> seeds</span>"
            "</div>"
            + _render_counts(group, identity_hint=f"sampled-vqe-group-{group_index}")
            + _table(
                ("Field", "Value"),
                [
                    f"<tr><td>Terms</td><td>{_compact_value(group.get('term_ids'))}</td></tr>",
                    f"<tr><td>Term expectations</td><td>{_compact_value(group.get('term_expectations'))}</td></tr>",
                    f"<tr><td>Term standard errors</td><td>{_compact_value(group.get('term_standard_errors'))}</td></tr>",
                    f"<tr><td>Results</td><td>{_compact_value(group.get('result_ids'))}</td></tr>",
                ],
                label=f"Measurement group {group_index} statistics",
            )
            + "</div>"
        )
    return "".join(parts)


def _render_sampled_objective_analysis(payload: Mapping[str, Any]) -> str:
    interval = (
        f"[{_format_number(payload.get('confidence_interval_low'))}, "
        f"{_format_number(payload.get('confidence_interval_high'))}]"
    )
    mitigation = payload.get("readout_mitigation")
    mitigation_summary = ""
    mitigation_rows: list[str] = []
    if isinstance(mitigation, Mapping):
        mitigation_summary = (
            f"<span><strong>{_format_number(payload.get('raw_energy'))}</strong> raw energy</span>"
            f"<span><strong>{_format_number(payload.get('mitigated_energy'))}</strong> mitigated energy</span>"
        )
        mitigation_rows = [
            f"<tr><td>Raw energy</td><td>{_format_number(payload.get('raw_energy'))}</td></tr>",
            f"<tr><td>Raw standard error</td><td>{_format_number(payload.get('raw_energy_standard_error'))}</td></tr>",
            f"<tr><td>Mitigated energy</td><td>{_format_number(payload.get('mitigated_energy'))}</td></tr>",
            f"<tr><td>Mitigated standard error</td><td>{_format_number(payload.get('mitigated_energy_standard_error'))}</td></tr>",
        ]
    return (
        '<div class="domain-summary">'
        f"<span><strong>{_format_number(payload.get('energy'))}</strong> sampled energy</span>"
        f"<span><strong>{_format_number(payload.get('energy_standard_error'))}</strong> standard error</span>"
        f"{mitigation_summary}"
        f"<span><strong>{_text(interval)}</strong> 95% confidence interval</span>"
        f"<span><strong>{_text(payload.get('optimality_claim', ''))}</strong> optimality claim</span>"
        f"<span><strong>{_text(payload.get('quantum_advantage_claim', ''))}</strong> quantum advantage claim</span>"
        "</div>"
        '<div class="visual-group"><h3>Energy assembly</h3>'
        + _table(
            ("Field", "Value"),
            [
                f"<tr><td>Hamiltonian constant</td><td>{_format_number(payload.get('constant'))}</td></tr>",
                f"<tr><td>Measurement group energy sum</td><td>{_format_number(payload.get('group_energy_sum'))}</td></tr>",
                f"<tr><td>Sampled energy</td><td>{_format_number(payload.get('energy'))}</td></tr>",
                f"<tr><td>Standard error</td><td>{_format_number(payload.get('energy_standard_error'))}</td></tr>",
                *mitigation_rows,
                f"<tr><td>95% confidence interval</td><td>{_text(interval)}</td></tr>",
                f"<tr><td>Interval method</td><td>{_text(payload.get('confidence_interval_method', ''))}</td></tr>",
                f"<tr><td>Evaluation scope</td><td>{_text(payload.get('scope', ''))}</td></tr>",
            ],
            label="Energy assembly",
        )
        + '<p class="context-note">This is a fixed-parameter sampled estimate. It does not claim a global optimum or quantum advantage.</p>'
        + "</div>"
    )


def _render_noise_request(value: object) -> str:
    """Render the requested NoiseModel and SimulationOptions without raw JSON."""
    if not isinstance(value, Mapping):
        return ""
    noise_model = value.get("noise_model")
    requested_options = value.get("requested_options")
    model_id = (
        noise_model.get("noise_model_id", "")
        if isinstance(noise_model, Mapping)
        else "none"
    )
    option_rows = []
    if isinstance(requested_options, Mapping):
        for key in (
            "method",
            "integrator",
            "device",
            "dtype",
            "workers",
            "trajectories",
            "max_memory_bytes",
            "memory_fraction",
            "rtol",
            "atol",
            "max_steps",
            "seed",
        ):
            if key in requested_options:
                option_rows.append(
                    "<tr>"
                    f"<td>{_text(_humanize(key))}</td>"
                    f"<td>{_compact_value(requested_options[key])}</td>"
                    "</tr>"
                )
    return (
        '<div class="visual-group noise-execution"><h3>Objective execution request</h3>'
        '<div class="domain-summary">'
        f"<span><strong>{_text(value.get('execution_mode', ''))}</strong> execution mode</span>"
        f"<span><strong>{_text(model_id)}</strong> noise model</span>"
        f"<span><strong>{_text(value.get('requested_seed', ''))}</strong> requested seed</span>"
        f"<span><code>{_short_hash(value.get('noise_model_hash'))}</code> model hash</span>"
        "</div>"
        + _render_noise_channels(noise_model)
        + (
            _table(
                ("Setting", "Value"),
                option_rows,
                label="Requested simulation options",
            )
            if option_rows
            else ""
        )
        + "</div>"
    )


def _render_noise_execution(value: object, *, title: str) -> str:
    """Render one saved objective or final-sampling execution context."""
    if not isinstance(value, Mapping) or not value:
        return ""
    plan = value.get("simulation_plan")
    report = value.get("noise_report")
    plan = plan if isinstance(plan, Mapping) else {}
    report = report if isinstance(report, Mapping) else {}
    estimate = plan.get("estimate")
    estimate = estimate if isinstance(estimate, Mapping) else {}
    seed = value.get("effective_seed", value.get("seed"))
    shots = value.get("backend_shots", value.get("shots"))
    estimator = value.get("estimator_kind", "sampling")
    source_kind = value.get("source_kind", "terminal_counts")
    overview = (
        '<div class="domain-summary">'
        f"<span><strong>{_text(value.get('execution_mode', ''))}</strong> execution mode</span>"
        f"<span><strong>{_text(plan.get('method_selected', report.get('method', '')))}</strong> method</span>"
        f"<span><strong>{_text(estimator)}</strong> estimator</span>"
        f"<span><strong>{_text(source_kind)}</strong> source kind</span>"
        f"<span><strong>{_text(seed)}</strong> effective seed</span>"
        f"<span><strong>{_text(shots)}</strong> Backend shots</span>"
        f"<span><code>{_text(value.get('backend_job_id', ''))}</code> Backend Job</span>"
        "</div>"
    )
    plan_rows = [
        ("Method", plan.get("method_selected")),
        ("Integrator", plan.get("integrator_selected")),
        ("State representation", plan.get("state_representation")),
        ("Logical sites", plan.get("logical_sites")),
        ("Hilbert dimension", plan.get("hilbert_dimension")),
        ("Device", plan.get("device")),
        ("Dtype", plan.get("dtype")),
        ("Workers", plan.get("workers")),
        ("Trajectories", plan.get("trajectories")),
        ("Estimated peak memory", _format_bytes(estimate.get("estimated_peak_bytes"))),
        ("Options hash", plan.get("options_hash")),
        ("Plan hash", value.get("simulation_plan_hash")),
    ]
    report_rows = []
    records = report.get("records", ())
    for record in cast(Sequence[Any], records) if _is_sequence(records) else ():
        if not isinstance(record, Mapping):
            continue
        report_rows.append(
            "<tr>"
            f"<td><code>{_text(record.get('channel_id', ''))}</code></td>"
            f"<td>{_text(record.get('channel_type', ''))}</td>"
            f"<td>{_text(record.get('injection_point', ''))}</td>"
            f"<td>{_text(record.get('truthfulness', ''))}</td>"
            f"<td>{_compact_value(record.get('targets'))}</td>"
            f"<td><code>{_short_hash(record.get('input_state_hash'))}</code></td>"
            f"<td><code>{_short_hash(record.get('output_state_hash'))}</code></td>"
            "</tr>"
        )
    report_summary = ""
    if report:
        report_summary = (
            '<div class="domain-summary">'
            f"<span><strong>{_safe_int(report.get('physical_application_count'))}</strong> physical applications</span>"
            f"<span><strong>{_safe_int(report.get('measurement_application_count'))}</strong> measurement applications</span>"
            f"<span><strong>{_text(report.get('truthfulness', ''))}</strong> truthfulness</span>"
            f"<span><code>{_short_hash(value.get('noise_report_hash'))}</code> report hash</span>"
            "</div>"
        )
    return (
        f'<div class="visual-group noise-execution"><h3>{_text(title)}</h3>'
        + overview
        + _render_noise_channels(value.get("noise_model"))
        + _table(
            ("Setting", "Value"),
            [
                f"<tr><td>{_text(label)}</td><td>{_compact_value(item)}</td></tr>"
                for label, item in plan_rows
                if item is not None
            ],
            label="Simulation plan",
        )
        + report_summary
        + (
            _table(
                (
                    "Channel",
                    "Type",
                    "Injection point",
                    "Truthfulness",
                    "Targets",
                    "Input state",
                    "Output state",
                ),
                report_rows,
                label="Noise applications",
            )
            if report_rows
            else ""
        )
        + _render_observable_uncertainty(value.get("observable_standard_errors"))
        + "</div>"
    )


def _render_noise_channels(value: object) -> str:
    if not isinstance(value, Mapping):
        return '<p class="empty-note">No physical NoiseModel was requested.</p>'
    channels = value.get("channels", ())
    rows = []
    for channel in cast(Sequence[Any], channels) if _is_sequence(channels) else ():
        if not isinstance(channel, Mapping):
            continue
        rows.append(
            "<tr>"
            f"<td><code>{_text(channel.get('channel_id', ''))}</code></td>"
            f"<td>{_text(channel.get('channel_type', ''))}</td>"
            f"<td>{_text(channel.get('model', ''))}</td>"
            f"<td>{_text(channel.get('injection_point', ''))}</td>"
            f"<td>{_compact_value(channel.get('targets'))}</td>"
            f"<td>{_compact_value(channel.get('parameters'))}</td>"
            "</tr>"
        )
    return _table(
        ("Channel", "Type", "Model", "Injection point", "Targets", "Parameters"),
        rows,
        label="Noise channels",
    )


def _render_algorithm_objective_execution(value: object) -> str:
    """Render exact/noisy evidence or finite-shot group evidence by type."""
    if not isinstance(value, Mapping):
        return ""
    if value.get("measurement_kind") != "qubit_wise_commuting_pauli":
        return _render_noise_execution(value, title="Selected objective execution")
    groups = value.get("groups", ())
    rows = []
    details = []
    for group in cast(Sequence[Any], groups) if _is_sequence(groups) else ():
        if not isinstance(group, Mapping):
            continue
        rows.append(
            "<tr>"
            f"<td>{_safe_int(group.get('group_index'))}</td>"
            f"<td>{_text(group.get('stage', ''))}</td>"
            f"<td>{_text(group.get('seed', ''))}</td>"
            f"<td>{_safe_int(group.get('shots'))}</td>"
            f"<td><code>{_text(group.get('backend_job_id', ''))}</code></td>"
            f"<td><code>{_text(group.get('result_id', ''))}</code></td>"
            f"<td>{_format_number(group.get('energy_mean'))}</td>"
            f"<td>{_format_number(group.get('energy_standard_error'))}</td>"
            "</tr>"
        )
        details.append(_render_sampled_qwc_execution(group))
    return (
        '<div class="visual-group sampled-objective-execution">'
        "<h3>Sampled objective execution</h3>"
        '<div class="domain-summary">'
        f"<span><strong>{_text(value.get('execution_mode', ''))}</strong> execution mode</span>"
        f"<span><strong>{_text(value.get('simulation_method', ''))}</strong> simulation method</span>"
        f"<span><strong>{_safe_int(value.get('backend_execution_count'))}</strong> Backend executions</span>"
        f"<span><strong>{_safe_int(value.get('total_shots'))}</strong> shots</span>"
        f"<span><strong>{_format_number(value.get('raw_energy'))}</strong> raw energy</span>"
        f"<span><strong>{_format_number(value.get('mitigated_energy'))}</strong> mitigated energy</span>"
        f"<span><strong>{_format_number(value.get('energy_standard_error'))}</strong> energy standard error</span>"
        f"<span><code>{_short_hash(value.get('measurement_plan_hash'))}</code> plan hash</span>"
        "</div>"
        + _table(
            (
                "Group",
                "Stage",
                "Seed",
                "Shots",
                "Backend Job",
                "Result",
                "Energy mean",
                "Standard error",
            ),
            rows,
            label="Sampled objective execution",
        )
        + "</div>"
        + "".join(details)
    )


def _render_sampled_qwc_execution(group: Mapping[str, Any]) -> str:
    """Render raw counts and typed execution evidence for one physical QWC Job."""
    evidence = group.get("execution_evidence")
    evidence_hash = (
        evidence.get("evidence_hash") if isinstance(evidence, Mapping) else None
    )
    rows = [
        (
            "Raw counts",
            _compact_value(group.get("counts")),
        ),
        (
            "Backend Job",
            f"<code>{_text(group.get('backend_job_id', ''))}</code>",
        ),
        (
            "Result",
            f"<code>{_text(group.get('result_id', ''))}</code>",
        ),
        (
            "Evidence hash",
            f"<code>{_short_hash(evidence_hash)}</code>",
        ),
    ]
    summary = (
        '<div class="visual-group sampled-qwc-execution">'
        "<h3>QWC group execution evidence</h3>"
        '<div class="domain-summary">'
        f"<span><strong>{_safe_int(group.get('group_index'))}</strong> group</span>"
        f"<span><strong>{_text(group.get('stage', ''))}</strong> measurement stage</span>"
        f"<span><strong>{_safe_int(group.get('shots'))}</strong> shots</span>"
        f"<span><strong>{_format_number(group.get('energy_standard_error'))}</strong> standard error</span>"
        "</div>"
        + _table(
            ("Field", "Value"),
            [
                f"<tr><td>{_text(label)}</td><td>{rendered}</td></tr>"
                for label, rendered in rows
            ],
            label="QWC group execution evidence",
        )
        + "</div>"
    )
    return summary + _render_noise_execution(evidence, title="QWC group execution")


def _render_observable_uncertainty(value: object) -> str:
    if not isinstance(value, Mapping) or not value:
        return ""
    rows = [
        f"<tr><td><code>{_text(name)}</code></td><td>{_format_number(error)}</td></tr>"
        for name, error in value.items()
    ]
    return _table(
        ("Observable", "Standard error"),
        rows,
        label="Observable uncertainty",
    )


def _render_algorithm_validation(payload: Mapping[str, Any]) -> str:
    checks = payload.get("checks", ())
    rows = []
    if _is_sequence(checks):
        for check in checks:
            if not isinstance(check, Mapping):
                continue
            rows.append(
                "<tr>"
                f"<td>{_text(check.get('name', ''))}</td>"
                f"<td>{_status_badge(str(check.get('status', '')))}</td>"
                f"<td>{_compact_value(check.get('value'))}</td>"
                "</tr>"
            )
    return (
        '<div class="visual-group"><h3>Consistency checks</h3>'
        + _table(
            ("Check", "Status", "Value"),
            rows,
            label="Consistency checks",
        )
        + "</div>"
    )


def _render_algorithm_plan(payload: Mapping[str, Any]) -> str:
    optimizer = payload.get("optimizer", {})
    ansatz = payload.get("ansatz")
    rows = []
    if isinstance(optimizer, Mapping):
        for key in (
            "method",
            "max_iterations",
            "max_evaluations",
            "max_backend_executions",
            "starts",
            "initialization",
            "tolerance",
            "seed",
            "bounds",
            "options",
            "gradient",
            "spsa",
        ):
            if key in optimizer:
                rows.append(
                    f"<tr><td>{_text(_humanize(key))}</td>"
                    f"<td>{_compact_value(optimizer[key])}</td></tr>"
                )
    overview = (
        '<div class="domain-summary">'
        f"<span><strong>{_text(payload.get('ansatz_kind', ''))}</strong> ansatz</span>"
        f"<span><strong>{_safe_int(payload.get('layers'))}</strong> layers</span>"
        f"<span><strong>{_sequence_length(payload.get('parameter_names'))}</strong> parameters</span>"
        f"<span><strong>{_compact_value(payload.get('resolved_seed'))}</strong> seed</span>"
        "</div>"
    )
    repeated = payload.get("repeated_layer_experiment")
    repeated_html = (
        _render_repeated_layer_experiment_config(repeated)
        if isinstance(repeated, Mapping)
        else ""
    )
    sampling_benchmark = payload.get("vqe_sampling_benchmark")
    sampling_benchmark_html = (
        _render_vqe_sampling_benchmark_config(sampling_benchmark)
        if isinstance(sampling_benchmark, Mapping)
        else ""
    )
    stability = payload.get("vqe_stability")
    stability_html = (
        _render_vqe_stability_config(stability)
        if isinstance(stability, Mapping)
        else ""
    )
    return (
        overview
        + repeated_html
        + sampling_benchmark_html
        + stability_html
        + (_render_ansatz_contract(ansatz) if isinstance(ansatz, Mapping) else "")
        + '<div class="visual-group"><h3>Optimizer configuration</h3>'
        + _table(
            ("Setting", "Value"),
            rows,
            label="Optimizer configuration",
        )
        + "</div>"
        + _render_gradient_plan(payload.get("gradient_plan"))
        + _render_pauli_measurement_plan(payload.get("measurement_plan"))
        + _render_algorithm_objective_request(payload.get("objective_request"))
    )


def _render_algorithm_objective_request(value: object) -> str:
    """Render an estimator-specific request without inventing noise fields."""
    if not isinstance(value, Mapping):
        return ""
    if value.get("measurement_kind") == "qubit_wise_commuting_pauli":
        adaptive = value.get("allocation") == "pilot_variance"
        rows = [
            ("Estimator kind", value.get("estimator_kind")),
            ("Measurement kind", value.get("measurement_kind")),
            ("Grouping", value.get("grouping")),
            ("Allocation", value.get("allocation")),
            ("QWC groups", value.get("group_count")),
            ("Reference shots / group", value.get("shots_per_group")),
            (
                "Pilot group shots" if adaptive else "Actual group shots",
                value.get("shots_by_group"),
            ),
            ("Final group shots", value.get("final_shots_by_group")),
            ("Shots per objective", value.get("total_shots_per_evaluation")),
            (
                "Backend executions per objective",
                value.get("backend_executions_per_evaluation"),
            ),
            ("Measurement plan", value.get("measurement_plan_id")),
            ("Plan hash", value.get("measurement_plan_hash")),
            ("Simulation method", value.get("simulation_method")),
            ("Backend", value.get("backend_id")),
            ("Options hash", value.get("requested_options_hash")),
        ]
        mitigation = value.get("readout_mitigation")
        if isinstance(mitigation, Mapping):
            rows.extend(
                (
                    ("Readout mitigation", mitigation.get("method")),
                    ("Calibration source", mitigation.get("calibration_source")),
                    ("Calibration hash", mitigation.get("calibration_hash")),
                    ("Condition numbers", mitigation.get("condition_numbers")),
                    (
                        "Total condition number",
                        mitigation.get("total_condition_number"),
                    ),
                    (
                        "Condition number limit",
                        mitigation.get("max_condition_number"),
                    ),
                )
            )
        return (
            '<div class="visual-group sampled-objective-request">'
            "<h3>Sampled objective request</h3>"
            + _table(
                ("Setting", "Value"),
                [
                    f"<tr><td>{_text(label)}</td><td>{_compact_value(item)}</td></tr>"
                    for label, item in rows
                ],
                label="Sampled objective request",
            )
            + "</div>"
            + _render_noise_request(value)
        )
    return _render_noise_request(value)


def _render_pauli_measurement_plan(value: object) -> str:
    """Render the finite-shot QWC plan used by sampled VQE optimization."""
    if not isinstance(value, Mapping):
        return ""
    config = value.get("config", {})
    config = config if isinstance(config, Mapping) else {}
    adaptive = config.get("allocation") == "pilot_variance"
    groups = value.get("groups", ())
    shots_by_group = value.get("shots_by_group", ())
    shot_values = (
        cast(Sequence[Any], shots_by_group) if _is_sequence(shots_by_group) else ()
    )
    rows = []
    for group_position, group in enumerate(
        cast(Sequence[Any], groups) if _is_sequence(groups) else ()
    ):
        if not isinstance(group, Mapping):
            continue
        group_shots = (
            shot_values[group_position] if group_position < len(shot_values) else None
        )
        rows.append(
            "<tr>"
            f"<td>{_safe_int(group.get('group_index'))}</td>"
            f"<td>{_compact_value(group.get('basis_by_target'))}</td>"
            f"<td>{_sequence_length(group.get('terms'))}</td>"
            f"<td>{_safe_int(group_shots)}</td>"
            "</tr>"
        )
    return (
        '<div class="visual-group"><h3>Finite-shot Pauli measurement plan</h3>'
        '<div class="domain-summary">'
        f"<span><strong>{_sequence_length(groups)}</strong> QWC groups</span>"
        f"<span><strong>{_text(config.get('allocation', ''))}</strong> allocation</span>"
        f"<span><strong>{_safe_int(config.get('shots_per_group'))}</strong> Reference shots / group</span>"
        f"<span><strong>{_compact_value(shots_by_group)}</strong> "
        f"{'Pilot group shots' if adaptive else 'Actual group shots'}</span>"
        f"<span><strong>{_safe_int(value.get('total_shots'))}</strong> shots per objective</span>"
        f"<span><strong>{_safe_int(value.get('backend_execution_count'))}</strong> Backend executions per objective</span>"
        "</div>"
        + _table(
            (
                "Group",
                "Local basis",
                "Hamiltonian terms",
                "Pilot shots" if adaptive else "Shots",
            ),
            rows,
            label="Finite-shot Pauli measurement groups",
        )
        + "</div>"
    )


def _render_gradient_plan(value: object) -> str:
    """Render the shared parameter-shift plan without exposing raw JSON."""
    if not isinstance(value, Mapping):
        return ""
    occurrences = value.get("occurrences", ())
    repeat_policy = value.get("repeat_policy", {})
    repeat_policy = repeat_policy if isinstance(repeat_policy, Mapping) else {}
    rows = []
    for item in cast(Sequence[Any], occurrences) if _is_sequence(occurrences) else ():
        if not isinstance(item, Mapping):
            continue
        rows.append(
            "<tr>"
            f"<td><code>{_text(item.get('occurrence_id', ''))}</code></td>"
            f"<td>{_safe_int(item.get('gate_index'))}</td>"
            f"<td><code>{_text(item.get('gate_name', ''))}</code></td>"
            f"<td>{_compact_value(item.get('targets'))}</td>"
            f"<td>{_format_number(item.get('affine_offset'))}</td>"
            f"<td>{_compact_value(item.get('coefficients'))}</td>"
            "</tr>"
        )
    return (
        '<div class="visual-group"><h3>Gradient plan</h3>'
        '<div class="domain-summary">'
        f"<span><strong>{_text(value.get('method', ''))}</strong> method</span>"
        f"<span><strong>{_safe_int(value.get('occurrence_count'))}</strong> occurrences</span>"
        f"<span><strong>{_safe_int(value.get('expected_objective_evaluation_count'))}</strong> objective evaluations per gradient</span>"
        f"<span><strong>{_format_number(value.get('shift'))}</strong> shift</span>"
        f"<span><strong>{_text(repeat_policy.get('mode', ''))}</strong> repeat mode</span>"
        f"<span><strong>{_safe_int(repeat_policy.get('minimum_repeat_count'))}</strong> minimum repeats</span>"
        f"<span><strong>{_safe_int(repeat_policy.get('maximum_repeat_count'))}</strong> maximum repeats</span>"
        f"<span><strong>{_format_number(repeat_policy.get('uncertainty_norm_target'))}</strong> gradient uncertainty target</span>"
        "</div>"
        + _table(
            (
                "Occurrence",
                "Gate index",
                "Gate",
                "Targets",
                "Affine offset",
                "Coefficients",
            ),
            rows,
            label="Gradient occurrences",
        )
        + "</div>"
    )


def _render_ansatz_contract(
    ansatz: Mapping[str, Any],
    *,
    spec_hash: Any = None,
) -> str:
    """Render the construction and migration facts of one saved Ansatz."""
    rows = [
        (
            "Ansatz kind",
            ansatz.get("ansatz_kind", ""),
        ),
        ("Layers", ansatz.get("layers", "")),
        ("Logical order", ansatz.get("logical_order", ())),
        ("Parameters", ansatz.get("parameter_names", ())),
        ("Required gates", ansatz.get("required_gates", ())),
        ("Layer transfer", ansatz.get("layer_transfer", "")),
        ("Circuit hash", ansatz.get("circuit_hash", "")),
    ]
    if spec_hash is not None:
        rows.append(("Spec hash", spec_hash))
    rows.append(("Definition", ansatz.get("definition", {})))
    return (
        '<div class="visual-group"><h3>Ansatz contract</h3>'
        + _table(
            ("Setting", "Value"),
            [
                f"<tr><td>{_text(label)}</td><td>{_compact_value(value)}</td></tr>"
                for label, value in rows
            ],
            label="Ansatz contract",
        )
        + "</div>"
    )


def _render_algorithm_execution(payload: Mapping[str, Any]) -> str:
    evaluations = payload.get("evaluations", ())
    if not _is_sequence(evaluations):
        evaluations = ()
    termination = payload.get("termination", {})
    starts = payload.get("starts", ())
    status = termination.get("reason", "") if isinstance(termination, Mapping) else ""
    overview = (
        '<div class="domain-summary">'
        f"<span><strong>{_safe_int(payload.get('evaluation_count'))}</strong> evaluations</span>"
        f"<span><strong>{_safe_int(payload.get('backend_result_count'))}</strong> Backend Results</span>"
        f"<span><strong>{_safe_int(payload.get('objective_backend_execution_count'))}</strong> objective Backend executions</span>"
        f"<span><strong>{_safe_int(payload.get('objective_total_shots'))}</strong> objective shots</span>"
        f"<span><strong>{_sequence_length(starts)}</strong> starts</span>"
        f"<span><strong>{_text(payload.get('selected_start_index', ''))}</strong> selected start</span>"
        f"<span><strong>{_text(status)}</strong> termination</span>"
        f"<span><strong>{_format_duration(payload.get('total_wall_time_seconds'))}</strong> objective wall time</span>"
        "</div>"
    )
    rows = []
    for item in cast(Sequence[Any], evaluations):
        if not isinstance(item, Mapping):
            continue
        execution = item.get("execution", {})
        execution = execution if isinstance(execution, Mapping) else {}
        rows.append(
            "<tr>"
            f"<td>{_text(item.get('evaluation_index', ''))}</td>"
            f"<td>{_compact_value(item.get('energy'))}</td>"
            f"<td>{_compact_value(item.get('energy_standard_error'))}</td>"
            f"<td>{_compact_value(item.get('parameters'))}</td>"
            f"<td><code>{_text(item.get('result_id', ''))}</code></td>"
            f"<td>{_safe_int(item.get('backend_execution_count'))}</td>"
            f"<td>{_safe_int(item.get('total_shots'))}</td>"
            f"<td>{_text(execution.get('execution_mode', ''))}</td>"
            f"<td>{_text(execution.get('method', ''))}</td>"
            f"<td>{_text(execution.get('estimator', ''))}</td>"
            f"<td>{_text(execution.get('effective_seed', ''))}</td>"
            f"<td>{_format_duration(item.get('wall_time_seconds'))}</td>"
            "</tr>"
        )
    fallback = _table(
        (
            "Evaluation",
            "Energy",
            "Energy standard error",
            "Parameters",
            "Result",
            "Backend executions",
            "Shots",
            "Execution mode",
            "Method",
            "Estimator",
            "Effective seed",
            "Wall time",
        ),
        rows,
        label="Objective evaluations",
    )
    chart = (
        '<div class="visual-group"><h3>Objective history</h3>'
        + render_objective_history_bokeh_html(
            cast(Sequence[Any], evaluations),
            best_evaluation_index=_safe_int(payload.get("best_evaluation_index")),
            baseline_energy=_finite_number(payload.get("baseline_energy")),
            identity_hint=str(payload.get("best_evaluation_index", "algorithm")),
            fallback_html=fallback,
        )
        + "</div>"
    )
    repeated = payload.get("repeated_layer_experiment")
    repeated_html = (
        _render_repeated_vqe_execution(repeated)
        if isinstance(repeated, Mapping)
        else ""
    )
    sampling_benchmark = payload.get("vqe_sampling_benchmark")
    sampling_benchmark_html = (
        _render_vqe_sampling_benchmark_execution(sampling_benchmark)
        if isinstance(sampling_benchmark, Mapping)
        else ""
    )
    stability = payload.get("vqe_stability")
    stability_html = (
        _render_vqe_stability_execution(stability)
        if isinstance(stability, Mapping)
        else ""
    )
    return (
        repeated_html
        + sampling_benchmark_html
        + stability_html
        + overview
        + _render_optimization_starts(
            starts,
            selected_start_index=_safe_int(payload.get("selected_start_index")),
        )
        + _render_workflow_cost(payload.get("workflow_cost"))
        + _render_adam_history(payload.get("adam"))
        + chart
        + _render_sampled_selection(payload.get("sampled_selection"))
        + _render_gradient_history(payload.get("gradient"))
        + '<div class="visual-group"><h3>Evaluation evidence</h3>'
        + fallback
        + "</div>"
        + _render_algorithm_objective_execution(payload.get("objective_execution"))
    )


def _render_sampled_selection(value: object) -> str:
    """Render independent confirmation evidence saved after sampled optimization."""
    if not isinstance(value, Mapping):
        return ""
    candidates = value.get("candidates", ())
    if not _is_sequence(candidates):
        return ""
    rounds = value.get("rounds", ())
    rounds = rounds if _is_sequence(rounds) else ()
    rows = []
    for item in cast(Sequence[Any], candidates):
        if not isinstance(item, Mapping):
            continue
        rank = _safe_int(item.get("candidate_rank"))
        rank_label = (
            f"{rank} (selected)"
            if rank == _safe_int(value.get("selected_candidate_rank"))
            else str(rank)
        )
        rows.append(
            "<tr>"
            f"<td>{_text(rank_label)}</td>"
            f"<td>{_safe_int(item.get('source_evaluation_index'))}</td>"
            f"<td>{_format_number(item.get('observed_energy'))}</td>"
            f"<td>{_format_number(item.get('confirmation_mean'))}</td>"
            f"<td>{_format_number(item.get('energy_standard_error'))}</td>"
            f"<td>{_format_number(item.get('confidence_interval_low'))} &ndash; "
            f"{_format_number(item.get('confidence_interval_high'))}</td>"
            f"<td>{_safe_int(item.get('repeat_count'))}</td>"
            f"<td>{_safe_int(item.get('total_shots'))}</td>"
            f"<td>{_safe_int(item.get('backend_execution_count'))}</td>"
            "</tr>"
        )
    fallback = _table(
        (
            "Candidate",
            "Source evaluation",
            "Observed energy",
            "Confirmation mean",
            "Standard error",
            "Confidence interval",
            "Repeats",
            "Shots",
            "Backend executions",
        ),
        rows,
        label="Independent candidate confirmation",
    )
    round_rows = []
    for item in cast(Sequence[Any], rounds):
        if not isinstance(item, Mapping):
            continue
        measured = item.get("measured_candidate_ranks", ())
        repeat_counts = item.get("repeat_counts", ())
        measured_label = (
            ", ".join(str(_safe_int(rank)) for rank in measured)
            if _is_sequence(measured)
            else ""
        )
        repeat_label = (
            ", ".join(str(_safe_int(count)) for count in repeat_counts)
            if _is_sequence(repeat_counts)
            else ""
        )
        round_rows.append(
            "<tr>"
            f"<td>{_safe_int(item.get('round_index'))}</td>"
            f"<td>{_text(measured_label)}</td>"
            f"<td>{_text(repeat_label)}</td>"
            f"<td>{_safe_int(item.get('selected_candidate_rank'))}</td>"
            f"<td>{_text(item.get('runner_up_candidate_rank', ''))}</td>"
            f"<td>{_format_number(item.get('difference_confidence_interval_low'))} &ndash; "
            f"{_format_number(item.get('difference_confidence_interval_high'))}</td>"
            f"<td>{_text(item.get('status', ''))}</td>"
            f"<td>{_safe_int(item.get('incremental_shots'))} / "
            f"{_safe_int(item.get('total_shots'))}</td>"
            f"<td>{_safe_int(item.get('incremental_backend_execution_count'))} / "
            f"{_safe_int(item.get('backend_execution_count'))}</td>"
            "</tr>"
        )
    round_table = _table(
        (
            "Look",
            "Measured candidates",
            "Repeat counts",
            "Selected",
            "Runner-up",
            "Difference interval",
            "Status",
            "Shots (look / cumulative)",
            "Backend executions (look / cumulative)",
        ),
        round_rows,
        label="Confirmation looks",
    )
    comparison = (
        f"<span><strong>{_safe_int(value.get('selected_candidate_rank'))}</strong> selected candidate</span>"
        f"<span><strong>{_text(value.get('runner_up_candidate_rank', ''))}</strong> runner-up</span>"
        f"<span><strong>{_format_number(value.get('energy_difference'))}</strong> mean difference</span>"
        f"<span><strong>{_format_number(value.get('difference_standard_error'))}</strong> difference standard error</span>"
        f"<span><strong>{_format_number(value.get('difference_confidence_interval_low'))} &ndash; {_format_number(value.get('difference_confidence_interval_high'))}</strong> difference interval</span>"
    )
    return (
        '<div class="visual-group sampled-selection"><h3>Independent candidate confirmation</h3>'
        '<div class="domain-summary">'
        f"<span><strong>{_text(value.get('mode', ''))}</strong> confirmation mode</span>"
        f"<span><strong>{_text(value.get('status', ''))}</strong> selection status</span>"
        f"<span><strong>{_text(value.get('stop_reason', ''))}</strong> stop reason</span>"
        f"<span><strong>{_safe_int(value.get('actual_look_count'))} / {_safe_int(value.get('planned_look_count'))}</strong> actual / planned looks</span>"
        f"<span><strong>{_format_number(value.get('nominal_confidence_level'))}</strong> nominal confidence</span>"
        f"<span><strong>{_format_number(value.get('decision_confidence_level'))}</strong> decision confidence</span>"
        f"<span><strong>{_sequence_length(candidates)}</strong> candidates</span>"
        f"<span><strong>{_text(value.get('confirmation_allocation', ''))}</strong> allocation</span>"
        f"<span><strong>{_safe_int(value.get('confirmation_shots_per_group'))}</strong> Reference shots / group</span>"
        f"<span><strong>{_compact_value(value.get('confirmation_shots_by_group'))}</strong> "
        f"{'Pilot group shots' if value.get('confirmation_allocation') == 'pilot_variance' else 'Actual group shots'}</span>"
        f"<span><strong>{_safe_int(value.get('total_shots'))}</strong> confirmation shots</span>"
        f"<span><strong>{_safe_int(value.get('backend_execution_count'))}</strong> confirmation Backend executions</span>"
        f"{comparison}"
        "</div>"
        + render_objective_history_bokeh_html(
            cast(Sequence[Any], candidates),
            best_evaluation_index=_safe_int(value.get("selected_candidate_rank")),
            baseline_energy=None,
            identity_hint=str(
                value.get("selected_source_evaluation_index", "selection")
            ),
            fallback_html=fallback,
            energy_label="Confirmation mean",
            running_best_label="Lowest confirmation mean",
            best_label="Selected candidate",
            x_axis_label="candidate rank",
            aria_label="Independent candidate confirmation",
        )
        + fallback
        + round_table
        + "</div>"
    )


def _render_repeated_vqe_execution(payload: Mapping[str, Any]) -> str:
    selected = payload.get("selected_run")
    selected = selected if isinstance(selected, Mapping) else {}
    return (
        '<div class="visual-group"><h3>Repeated VQE execution cost</h3>'
        '<div class="domain-summary">'
        f"<span><strong>{_safe_int(payload.get('executed_layer_count'))}</strong> executed layers</span>"
        f"<span><strong>{_safe_int(payload.get('total_optimization_count'))}</strong> optimizations</span>"
        f"<span><strong>{_safe_int(payload.get('total_evaluation_count'))}</strong> objective evaluations</span>"
        f"<span><strong>{_safe_int(payload.get('total_gradient_evaluation_count'))}</strong> gradient evaluations</span>"
        f"<span><strong>{_safe_int(payload.get('total_backend_execution_count'))}</strong> Backend executions</span>"
        f"<span><strong>{_safe_int(payload.get('total_final_sampling_count'))}</strong> final sampling Jobs</span>"
        "</div>"
        "<h3>Selected VQE run</h3>"
        + _table(
            ("Field", "Value"),
            [
                f"<tr><td>{_text(_humanize(key))}</td><td>{_compact_value(value)}</td></tr>"
                for key, value in selected.items()
            ],
            label="Selected VQE run",
        )
        + "</div>"
    )


def _render_workflow_cost(value: object) -> str:
    """Render objective, gradient, confirmation, and final sampling separately."""
    if not isinstance(value, Mapping):
        return ""
    categories = value.get("categories", {})
    if not isinstance(categories, Mapping):
        return ""
    rows = []
    for name in ("objective", "gradient", "candidate_confirmation", "final_sampling"):
        item = categories.get(name, {})
        if not isinstance(item, Mapping):
            continue
        rows.append(
            "<tr>"
            f"<td>{_text(_humanize(name))}</td>"
            f"<td>{_safe_int(item.get('backend_execution_count'))}</td>"
            f"<td>{_safe_int(item.get('shots'))}</td>"
            "</tr>"
        )
    return (
        '<div class="visual-group"><h3>Workflow cost ledger</h3>'
        '<div class="domain-summary">'
        f"<span><strong>{_safe_int(value.get('total_backend_execution_count'))}</strong> total Backend executions</span>"
        f"<span><strong>{_safe_int(value.get('total_shots'))}</strong> workflow shots</span>"
        "</div>"
        + _table(
            ("Cost category", "Backend executions", "Shots"),
            rows,
            label="Workflow cost ledger",
        )
        + "</div>"
    )


def _render_adam_history(value: object) -> str:
    """Render saved Adam state while keeping moments distinct from uncertainty."""
    if not isinstance(value, Mapping):
        return ""
    iterations = value.get("iterations", ())
    if not _is_sequence(iterations):
        return ""
    rows = []
    for item in cast(Sequence[Any], iterations):
        if not isinstance(item, Mapping):
            continue
        rows.append(
            "<tr>"
            f"<td>{_safe_int(item.get('start_index'))}</td>"
            f"<td>{_safe_int(item.get('iteration_index'))}</td>"
            f"<td>{_format_number(item.get('center_objective'))}</td>"
            f"<td>{_format_number(item.get('updated_objective'))}</td>"
            f"<td>{_compact_value(item.get('gradient'))}</td>"
            f"<td>{_compact_value(item.get('gradient_standard_errors'))}</td>"
            f"<td>{_format_number(item.get('gradient_uncertainty_norm'))}</td>"
            f"<td>{_safe_int(item.get('gradient_repeat_count'))}</td>"
            f"<td>{_text(item.get('gradient_repeat_stop_reason', ''))}</td>"
            f"<td>{_compact_value(item.get('first_moment'))}</td>"
            f"<td>{_compact_value(item.get('second_moment'))}</td>"
            f"<td>{_compact_value(item.get('bias_corrected_first_moment'))}</td>"
            f"<td>{_compact_value(item.get('bias_corrected_second_moment'))}</td>"
            f"<td>{_compact_value(item.get('step'))}</td>"
            f"<td>{_compact_value(item.get('updated_parameters'))}</td>"
            f"<td>{_format_number(item.get('update_norm'))}</td>"
            f"<td>{_text(item.get('projection_applied', False))}</td>"
            f"<td>{_safe_int(item.get('gradient_backend_execution_count'))}</td>"
            f"<td>{_safe_int(item.get('gradient_total_shots'))}</td>"
            "</tr>"
        )
    starts = value.get("starts", ())
    stopping_rows = []
    for item in cast(Sequence[Any], starts) if _is_sequence(starts) else ():
        if not isinstance(item, Mapping):
            continue
        termination = item.get("termination", {})
        termination = termination if isinstance(termination, Mapping) else {}
        evidence = item.get("stopping_evidence")
        evidence = evidence if isinstance(evidence, Mapping) else {}
        config = evidence.get("config", {})
        config = config if isinstance(config, Mapping) else {}
        stopping_rows.append(
            "<tr>"
            f"<td>{_safe_int(item.get('start_index'))}</td>"
            f"<td>{_text(termination.get('reason', ''))}</td>"
            f"<td>{_text(termination.get('success', False))}</td>"
            f"<td>{_safe_int(termination.get('nit'))}</td>"
            f"<td>{_text(evidence.get('status', ''))}</td>"
            f"<td>{_format_number(config.get('update_norm_tolerance'))}</td>"
            f"<td>{_format_number(config.get('gradient_uncertainty_norm_tolerance'))}</td>"
            f"<td>{_compact_value(evidence.get('update_norms'))}</td>"
            f"<td>{_compact_value(evidence.get('gradient_uncertainty_norms'))}</td>"
            f"<td>{_compact_value(evidence.get('gradient_repeat_counts'))}</td>"
            f"<td>{_compact_value(evidence.get('gradient_repeat_stop_reasons'))}</td>"
            "</tr>"
        )
    return (
        '<div class="visual-group"><h3>Adam update trajectory</h3>'
        '<div class="domain-summary">'
        f"<span><strong>{_safe_int(value.get('iteration_count'))}</strong> Adam iterations</span>"
        f"<span><strong>{_safe_int(value.get('start_count'))}</strong> optimizer starts</span>"
        "</div>"
        '<p class="empty-note">Adam second moment is optimizer state, not sampled-gradient variance. Statistical uncertainty is reported by gradient covariance and standard error.</p>'
        + _table(
            (
                "Start",
                "Iteration",
                "Center objective",
                "Updated objective",
                "Gradient",
                "Gradient standard error",
                "Gradient uncertainty norm",
                "Gradient repeats",
                "Gradient repeat stop",
                "First moment",
                "Second moment",
                "Bias-corrected first moment",
                "Bias-corrected second moment",
                "Step",
                "Updated parameters",
                "Update norm",
                "Bounds projection",
                "Gradient Backend executions",
                "Gradient shots",
            ),
            rows,
            label="Adam update trajectory",
        )
        + '<details class="raw-details"><summary>Adam termination and stopping</summary>'
        + _table(
            (
                "Start",
                "Termination",
                "Success",
                "Iterations",
                "Stopping status",
                "Update norm tolerance",
                "Gradient uncertainty target",
                "Window update norms",
                "Window gradient uncertainty",
                "Window gradient repeats",
                "Window repeat stop reasons",
            ),
            stopping_rows,
            label="Adam termination and stopping",
        )
        + "</details></div>"
    )


def _render_gradient_uncertainty(value: object) -> str:
    """Render one covariance/correlation matrix from a saved gradient."""
    if not isinstance(value, Mapping):
        return ""
    covariance = value.get("covariance", {})
    correlation = value.get("correlation", {})
    standard_errors = value.get("standard_errors", {})
    if not isinstance(covariance, Mapping) or not isinstance(correlation, Mapping):
        return ""
    rows = []
    for left, raw_row in covariance.items():
        row = raw_row if isinstance(raw_row, Mapping) else {}
        correlation_row = correlation.get(left, {})
        correlation_row = (
            correlation_row if isinstance(correlation_row, Mapping) else {}
        )
        for right, covariance_value in row.items():
            rows.append(
                "<tr>"
                f"<td><code>{_text(left)}</code></td>"
                f"<td><code>{_text(right)}</code></td>"
                f"<td>{_format_number(covariance_value)}</td>"
                f"<td>{_format_number(correlation_row.get(right))}</td>"
                "</tr>"
            )
    return (
        '<div class="visual-group"><h3>Gradient uncertainty</h3>'
        '<div class="domain-summary">'
        f"<span><strong>{_compact_value(standard_errors)}</strong> gradient standard errors</span>"
        f"<span><strong>{_format_number(value.get('uncertainty_norm'))}</strong> gradient uncertainty norm</span>"
        f"<span><strong>{_format_number(value.get('uncertainty_norm_target'))}</strong> gradient uncertainty target</span>"
        f"<span><strong>{_text(value.get('uncertainty_target_status', ''))}</strong> uncertainty target status</span>"
        f"<span><strong>{_safe_int(value.get('repeat_count'))}</strong> repeats</span>"
        f"<span><strong>{_text(value.get('repeat_stop_reason', ''))}</strong> repeat stop reason</span>"
        f"<span><strong>{_safe_int(value.get('gradient_shots'))}</strong> gradient shots</span>"
        "</div>"
        + _table(
            ("Parameter", "Parameter pair", "Covariance", "Correlation"),
            rows,
            label="Gradient covariance and correlation",
        )
        + "</div>"
    )


def _render_gradient_history(value: object) -> str:
    """Render saved gradient costs, trajectories, and occurrence evidence."""
    if not isinstance(value, Mapping):
        return ""
    cost = value.get("cost", {})
    history = value.get("history", ())
    if not isinstance(cost, Mapping) or not _is_sequence(history):
        return ""
    component_rows = []
    shift_rows = []
    repeat_rows = []
    matrix_rows = []
    for item in cast(Sequence[Any], history):
        if not isinstance(item, Mapping):
            continue
        component_rows.append(
            "<tr>"
            f"<td>{_safe_int(item.get('gradient_index'))}</td>"
            f"<td>{_text(item.get('repeat_mode', ''))}</td>"
            f"<td>{_safe_int(item.get('repeat_count'))} / {_safe_int(item.get('minimum_repeat_count'))}-{_safe_int(item.get('maximum_repeat_count'))}</td>"
            f"<td>{_format_number(item.get('uncertainty_norm_target'))}</td>"
            f"<td>{_format_number(item.get('uncertainty_norm'))}</td>"
            f"<td>{_text(item.get('uncertainty_target_status', ''))}</td>"
            f"<td>{_text(item.get('repeat_stop_reason', ''))}</td>"
            f"<td>{_format_number(item.get('backend_execution_limit'))}</td>"
            f"<td>{_format_number(item.get('l2_norm'))}</td>"
            f"<td>{_compact_value(item.get('parameter_bind'))}</td>"
            f"<td>{_compact_value(item.get('components'))}</td>"
            f"<td>{_compact_value(item.get('standard_errors'))}</td>"
            f"<td>{_safe_int(item.get('backend_execution_count'))}</td>"
            f"<td>{_safe_int(item.get('total_shots'))}</td>"
            "</tr>"
        )
        covariance = item.get("covariance", {})
        correlation = item.get("correlation", {})
        if isinstance(covariance, Mapping) and isinstance(correlation, Mapping):
            for left, raw_row in covariance.items():
                row = raw_row if isinstance(raw_row, Mapping) else {}
                correlation_row = correlation.get(left, {})
                correlation_row = (
                    correlation_row if isinstance(correlation_row, Mapping) else {}
                )
                for right, covariance_value in row.items():
                    matrix_rows.append(
                        "<tr>"
                        f"<td>{_safe_int(item.get('gradient_index'))}</td>"
                        f"<td><code>{_text(left)}</code></td>"
                        f"<td><code>{_text(right)}</code></td>"
                        f"<td>{_format_number(covariance_value)}</td>"
                        f"<td>{_format_number(correlation_row.get(right))}</td>"
                        "</tr>"
                    )
        evidence = item.get("shift_evidence", ())
        for pair in cast(Sequence[Any], evidence) if _is_sequence(evidence) else ():
            if not isinstance(pair, Mapping):
                continue
            shift_rows.append(
                "<tr>"
                f"<td>{_safe_int(item.get('gradient_index'))}</td>"
                f"<td><code>{_text(pair.get('occurrence_id', ''))}</code></td>"
                f"<td><code>{_text(pair.get('gate_name', ''))}</code></td>"
                f"<td>{_compact_value(pair.get('targets'))}</td>"
                f"<td>{_compact_value(pair.get('coefficients'))}</td>"
                f"<td>{_format_number(pair.get('positive_energy'))}</td>"
                f"<td>{_format_number(pair.get('positive_energy_standard_error'))}</td>"
                f"<td>{_format_number(pair.get('negative_energy'))}</td>"
                f"<td>{_format_number(pair.get('negative_energy_standard_error'))}</td>"
                f"<td>{_format_number(pair.get('energy_difference'))}</td>"
                f"<td>{_format_number(pair.get('gate_derivative'))}</td>"
                f"<td>{_format_number(pair.get('gate_derivative_standard_error'))}</td>"
                f"<td>{_format_number(pair.get('gate_derivative_variance'))}</td>"
                f"<td>{_safe_int(pair.get('repeat_count'))}</td>"
                f"<td>{_safe_int(pair.get('backend_execution_count'))}</td>"
                f"<td>{_safe_int(pair.get('total_shots'))}</td>"
                "</tr>"
            )
        repeats = item.get("repeat_evidence", ())
        for repeat in cast(Sequence[Any], repeats) if _is_sequence(repeats) else ():
            if not isinstance(repeat, Mapping):
                continue
            pairs = repeat.get("shift_pairs", ())
            for pair in cast(Sequence[Any], pairs) if _is_sequence(pairs) else ():
                if not isinstance(pair, Mapping):
                    continue
                repeat_rows.append(
                    "<tr>"
                    f"<td>{_safe_int(item.get('gradient_index'))}</td>"
                    f"<td>{_safe_int(repeat.get('repeat_index'))}</td>"
                    f"<td><code>{_text(pair.get('occurrence_id', ''))}</code></td>"
                    f"<td>{_safe_int(pair.get('positive_evaluation_index'))}</td>"
                    f"<td>{_format_number(pair.get('positive_energy'))}</td>"
                    f"<td>{_format_number(pair.get('positive_energy_standard_error'))}</td>"
                    f"<td>{_safe_int(pair.get('negative_evaluation_index'))}</td>"
                    f"<td>{_format_number(pair.get('negative_energy'))}</td>"
                    f"<td>{_format_number(pair.get('negative_energy_standard_error'))}</td>"
                    f"<td>{_format_number(pair.get('gate_derivative'))}</td>"
                    f"<td>{_format_number(pair.get('gate_derivative_variance'))}</td>"
                    f"<td>{_safe_int(pair.get('backend_execution_count'))}</td>"
                    f"<td>{_safe_int(pair.get('total_shots'))}</td>"
                    "</tr>"
                )
    component_table = _table(
        (
            "Gradient callback",
            "Repeat mode",
            "Actual / configured repeats",
            "Gradient uncertainty target",
            "Gradient uncertainty norm",
            "Uncertainty target status",
            "Repeat stop reason",
            "Backend execution limit",
            "L2 norm",
            "Parameters",
            "Gradient components",
            "Gradient standard error",
            "Backend executions",
            "Shots",
        ),
        component_rows,
        label="Gradient components",
    )
    chart = render_gradient_history_bokeh_html(
        cast(Sequence[Any], history),
        identity_hint="parameter-shift-gradient-history",
        fallback_html=component_table,
    )
    return (
        '<div class="visual-group"><h3>Gradient history</h3>'
        '<div class="domain-summary">'
        f"<span><strong>{_safe_int(cost.get('objective_evaluation_count'))}</strong> nfev</span>"
        f"<span><strong>{_safe_int(cost.get('gradient_evaluation_count'))}</strong> njev</span>"
        f"<span><strong>{_safe_int(cost.get('shift_job_count'))}</strong> shift Jobs</span>"
        f"<span><strong>{_safe_int(cost.get('gradient_shots'))}</strong> gradient shots</span>"
        f"<span><strong>{_safe_int(cost.get('backend_execution_count'))}</strong> Backend executions</span>"
        "</div>"
        + _render_algorithm_objective_request(value.get("execution_request"))
        + chart
        + component_table
        + '<details class="raw-details"><summary>Gradient covariance and correlation</summary>'
        + _table(
            (
                "Gradient callback",
                "Parameter",
                "Parameter pair",
                "Covariance",
                "Correlation",
            ),
            matrix_rows,
            label="Gradient covariance and correlation",
        )
        + "</details>"
        + '<details class="raw-details"><summary>Per-repeat shift evidence</summary>'
        + _table(
            (
                "Gradient callback",
                "Repeat",
                "Occurrence",
                "Positive evaluation",
                "Positive energy",
                "Positive energy standard error",
                "Negative evaluation",
                "Negative energy",
                "Negative energy standard error",
                "Gate derivative",
                "Derivative variance",
                "Backend executions",
                "Shots",
            ),
            repeat_rows,
            label="Per-repeat shift evidence",
        )
        + "</details>"
        + '<details class="raw-details"><summary>Pooled shift evidence</summary>'
        + _table(
            (
                "Gradient callback",
                "Occurrence",
                "Gate",
                "Targets",
                "Coefficients",
                "Positive energy",
                "Positive energy standard error",
                "Negative energy",
                "Negative energy standard error",
                "Energy difference",
                "Gate derivative",
                "Derivative standard error",
                "Derivative variance",
                "Repeats",
                "Backend executions",
                "Shots",
            ),
            shift_rows,
            label="Pooled shift evidence",
        )
        + "</details></div>"
    )


def _render_optimization_starts(
    starts: object,
    *,
    selected_start_index: int,
) -> str:
    """Render one auditable row for each independent optimizer start."""
    if not _is_sequence(starts) or not starts:
        return ""
    rows = []
    for item in cast(Sequence[Any], starts):
        if not isinstance(item, Mapping):
            continue
        start_index = _safe_int(item.get("start_index"))
        evaluation_start = _safe_int(item.get("evaluation_start_index"))
        evaluation_count = _safe_int(item.get("evaluation_count"))
        evaluation_end = evaluation_start + max(0, evaluation_count - 1)
        termination = item.get("termination", {})
        reason = (
            termination.get("reason", "") if isinstance(termination, Mapping) else ""
        )
        label = (
            f"{start_index} (selected)"
            if start_index == selected_start_index
            else str(start_index)
        )
        rows.append(
            "<tr>"
            f"<td>{_text(label)}</td>"
            f"<td>{_text(item.get('initialization', ''))}</td>"
            f"<td>{_text(item.get('seed', ''))}</td>"
            f"<td>{evaluation_start}-{evaluation_end}</td>"
            f"<td>{_text(item.get('best_evaluation_index', ''))}</td>"
            f"<td>{_format_number(item.get('best_objective'))}</td>"
            f"<td>{_text(reason)}</td>"
            "</tr>"
        )
    return (
        '<div class="visual-group"><h3>Optimization starts</h3>'
        + _table(
            (
                "Start",
                "Initialization",
                "Seed",
                "Evaluation range",
                "Best evaluation",
                "Best objective",
                "Termination",
            ),
            rows,
            label="Optimization starts",
        )
        + "</div>"
        + _render_spsa_iterations(starts)
    )


def _render_spsa_iterations(starts: object) -> str:
    """Render native SPSA evidence already embedded in optimizer starts."""
    if not _is_sequence(starts):
        return ""
    rows = []
    estimate_rows = []
    iteration_count = 0
    objective_repeats = 1
    spsa_config: Mapping[str, Any] = {}
    calibration_evidence_rows = []
    calibration_direction_rows = []
    stopping_evidence_rows = []
    stopping_check_rows = []
    for start in cast(Sequence[Any], starts):
        if not isinstance(start, Mapping):
            continue
        candidate_config = start.get("spsa_config")
        if not spsa_config and isinstance(candidate_config, Mapping):
            spsa_config = candidate_config
        start_index = _safe_int(start.get("start_index"))
        calibration_evidence = start.get("spsa_learning_rate_calibration")
        if isinstance(calibration_evidence, Mapping):
            calibration_directions = calibration_evidence.get("directions", ())
            direction_values = (
                cast(Sequence[Any], calibration_directions)
                if _is_sequence(calibration_directions)
                else ()
            )
            calibration_evidence_rows.append(
                "<tr>"
                f"<td>{start_index}</td>"
                f"<td>{len(direction_values)}</td>"
                f"<td>{_format_number(calibration_evidence.get('perturbation'))}</td>"
                f"<td>{_format_number(calibration_evidence.get('gradient_rms'))}</td>"
                f"<td>{_format_number(calibration_evidence.get('target_update_rms'))}</td>"
                f"<td>{_format_number(calibration_evidence.get('derived_learning_rate'))}</td>"
                f"<td>{_text(calibration_evidence.get('projection_applied', ''))}</td>"
                "</tr>"
            )
            for direction in direction_values:
                if not isinstance(direction, Mapping):
                    continue
                plus_estimate = direction.get("plus_estimate")
                minus_estimate = direction.get("minus_estimate")
                plus = plus_estimate if isinstance(plus_estimate, Mapping) else {}
                minus = minus_estimate if isinstance(minus_estimate, Mapping) else {}
                calibration_direction_rows.append(
                    "<tr>"
                    f"<td>{start_index}</td>"
                    f"<td>{_safe_int(direction.get('direction_index'))}</td>"
                    f"<td>{_compact_value(direction.get('perturbation_vector'))}</td>"
                    f"<td>{_format_number(plus.get('pooled_objective'))}</td>"
                    f"<td>{_format_number(minus.get('pooled_objective'))}</td>"
                    f"<td>{_compact_value(direction.get('gradient_estimate'))}</td>"
                    f"<td>{_text(plus.get('evaluation_offsets', ()))}</td>"
                    f"<td>{_text(minus.get('evaluation_offsets', ()))}</td>"
                    "</tr>"
                )
                for role, calibration_estimate in (
                    ("calibration_plus", plus),
                    ("calibration_minus", minus),
                ):
                    offsets = calibration_estimate.get("evaluation_offsets", ())
                    repeat_count = (
                        len(cast(Sequence[Any], offsets))
                        if _is_sequence(offsets)
                        else 0
                    )
                    objective_repeats = max(objective_repeats, repeat_count)
                    estimate_rows.append(
                        "<tr>"
                        f"<td>{start_index}</td>"
                        f"<td>{_text(role)}</td>"
                        f"<td>{_text('calibration')}</td>"
                        f"<td>{_safe_int(direction.get('direction_index'))}</td>"
                        f"<td>{repeat_count}</td>"
                        f"<td>{_format_number(calibration_estimate.get('pooled_objective'))}</td>"
                        f"<td>{_format_number(calibration_estimate.get('pooled_standard_error'))}</td>"
                        f"<td>{_text(calibration_estimate.get('stop_reason', ''))}</td>"
                        f"<td>{_text(offsets)}</td>"
                        "</tr>"
                    )
        stopping_evidence = start.get("spsa_stopping_evidence")
        termination = start.get("termination")
        termination_reason = (
            termination.get("reason", "") if isinstance(termination, Mapping) else ""
        )
        if isinstance(stopping_evidence, Mapping):
            stopping_evidence_rows.append(
                "<tr>"
                f"<td>{start_index}</td>"
                f"<td>{_text(stopping_evidence.get('status', ''))}</td>"
                f"<td>{_compact_value(stopping_evidence.get('window_iteration_indices', ()))}</td>"
                f"<td>{_compact_value(stopping_evidence.get('objective_proxy_values', ()))}</td>"
                f"<td>{_format_number(start.get('final_objective'))}</td>"
                f"<td>{_text(termination_reason)}</td>"
                f"<td>{_safe_int(start.get('evaluation_count'))}</td>"
                f"<td>{_safe_int(start.get('backend_execution_count'))}</td>"
                "</tr>"
            )
            checks = stopping_evidence.get("checks", ())
            for check in cast(Sequence[Any], checks) if _is_sequence(checks) else ():
                if not isinstance(check, Mapping):
                    continue
                stopping_check_rows.append(
                    "<tr>"
                    f"<td>{start_index}</td>"
                    f"<td>{_text(check.get('name', ''))}</td>"
                    f"<td>{_text(check.get('status', ''))}</td>"
                    f"<td>{_format_number(check.get('observed_value'))}</td>"
                    f"<td>{_format_number(check.get('threshold'))}</td>"
                    f"<td>{_safe_int(check.get('sample_count'))}</td>"
                    "</tr>"
                )
        for role, iteration_label, estimate in (
            ("initial", "-", start.get("spsa_initial_estimate")),
        ):
            if not isinstance(estimate, Mapping):
                continue
            offsets = estimate.get("evaluation_offsets", ())
            repeat_count = (
                len(cast(Sequence[Any], offsets)) if _is_sequence(offsets) else 0
            )
            objective_repeats = max(objective_repeats, repeat_count)
            estimate_rows.append(
                "<tr>"
                f"<td>{start_index}</td>"
                f"<td>{_text(role)}</td>"
                f"<td>{_text(iteration_label)}</td>"
                f"<td>{_text('-')}</td>"
                f"<td>{repeat_count}</td>"
                f"<td>{_format_number(estimate.get('pooled_objective'))}</td>"
                f"<td>{_format_number(estimate.get('pooled_standard_error'))}</td>"
                f"<td>{_text(estimate.get('stop_reason', ''))}</td>"
                f"<td>{_text(offsets)}</td>"
                "</tr>"
            )
        iterations = start.get("spsa_iterations", ())
        if not _is_sequence(iterations):
            iterations = ()
        for iteration in cast(Sequence[Any], iterations):
            if not isinstance(iteration, Mapping):
                continue
            iteration_count += 1
            directions = iteration.get("directions", ())
            if not _is_sequence(directions):
                directions = ()
            for direction in cast(Sequence[Any], directions):
                if not isinstance(direction, Mapping):
                    continue
                direction_index = _safe_int(direction.get("direction_index"))
                plus_estimate = direction.get("plus_estimate")
                minus_estimate = direction.get("minus_estimate")
                for role, estimate in (
                    ("plus", plus_estimate),
                    ("minus", minus_estimate),
                ):
                    if not isinstance(estimate, Mapping):
                        continue
                    estimate_offsets = estimate.get("evaluation_offsets", ())
                    repeat_count = (
                        len(cast(Sequence[Any], estimate_offsets))
                        if _is_sequence(estimate_offsets)
                        else 0
                    )
                    objective_repeats = max(objective_repeats, repeat_count)
                    estimate_rows.append(
                        "<tr>"
                        f"<td>{start_index}</td>"
                        f"<td>{_text(role)}</td>"
                        f"<td>{_safe_int(iteration.get('iteration_index'))}</td>"
                        f"<td>{direction_index}</td>"
                        f"<td>{repeat_count}</td>"
                        f"<td>{_format_number(estimate.get('pooled_objective'))}</td>"
                        f"<td>{_format_number(estimate.get('pooled_standard_error'))}</td>"
                        f"<td>{_text(estimate.get('stop_reason', ''))}</td>"
                        f"<td>{_text(estimate_offsets)}</td>"
                        "</tr>"
                    )
                plus_offsets = (
                    plus_estimate.get("evaluation_offsets", ())
                    if isinstance(plus_estimate, Mapping)
                    else ()
                )
                minus_offsets = (
                    minus_estimate.get("evaluation_offsets", ())
                    if isinstance(minus_estimate, Mapping)
                    else ()
                )
                offsets = f"{_text(plus_offsets)} / {_text(minus_offsets)}"
                rows.append(
                    "<tr>"
                    f"<td>{_safe_int(start.get('start_index'))}</td>"
                    f"<td>{_safe_int(iteration.get('iteration_index'))}</td>"
                    f"<td>{direction_index}</td>"
                    f"<td>{_format_number(iteration.get('learning_rate'))}</td>"
                    f"<td>{_format_number(iteration.get('perturbation'))}</td>"
                    f"<td>{_format_number(direction.get('plus_objective'))}</td>"
                    f"<td>{_format_number(direction.get('plus_energy_standard_error'))}</td>"
                    f"<td>{_format_number(direction.get('minus_objective'))}</td>"
                    f"<td>{_format_number(direction.get('minus_energy_standard_error'))}</td>"
                    f"<td>{_compact_value(direction.get('gradient_estimate'))}</td>"
                    f"<td>{_compact_value(iteration.get('gradient_estimate'))}</td>"
                    f"<td>{_compact_value(iteration.get('gradient_standard_error'))}</td>"
                    f"<td>{_format_number(iteration.get('update_norm'))}</td>"
                    f"<td>{_text(iteration.get('projection_applied', ''))}</td>"
                    f"<td>{_text(offsets)}</td>"
                    "</tr>"
                )
        final_estimate = start.get("spsa_final_estimate")
        if isinstance(final_estimate, Mapping):
            final_offsets = final_estimate.get("evaluation_offsets", ())
            final_repeat_count = (
                len(cast(Sequence[Any], final_offsets))
                if _is_sequence(final_offsets)
                else 0
            )
            objective_repeats = max(objective_repeats, final_repeat_count)
            estimate_rows.append(
                "<tr>"
                f"<td>{start_index}</td>"
                f"<td>{_text('final')}</td>"
                f"<td>{_text('-')}</td>"
                f"<td>{_text('-')}</td>"
                f"<td>{final_repeat_count}</td>"
                f"<td>{_format_number(final_estimate.get('pooled_objective'))}</td>"
                f"<td>{_format_number(final_estimate.get('pooled_standard_error'))}</td>"
                f"<td>{_text(final_estimate.get('stop_reason', ''))}</td>"
                f"<td>{_text(final_offsets)}</td>"
                "</tr>"
            )
    if not rows:
        return ""
    repeat_mode = (
        "adaptive" if spsa_config.get("max_objective_repeats") is not None else "fixed"
    )
    minimum_repeats = _safe_int(spsa_config.get("objective_repeats", 1))
    maximum_repeats = _safe_int(
        spsa_config.get("max_objective_repeats", minimum_repeats)
    )
    stopping_config = spsa_config.get("stopping")
    calibration_config = spsa_config.get("learning_rate_calibration")
    calibration_html = ""
    if isinstance(calibration_config, Mapping) and calibration_evidence_rows:
        calibration_settings = (
            ("Calibration directions", calibration_config.get("directions")),
            ("Target update RMS", calibration_config.get("target_update_rms")),
            ("Gradient RMS floor", calibration_config.get("gradient_rms_floor")),
            ("Maximum learning rate", calibration_config.get("max_learning_rate")),
        )
        calibration_html = (
            '<div class="visual-group"><h3>SPSA learning-rate calibration</h3>'
            '<p class="section-note">Calibration uses complete pre-iteration '
            "directions and adds real objective and Backend cost. It calibrates "
            "only the local learning-rate scale and does not prove convergence or "
            "improvement.</p>"
            + _table(
                ("Setting", "Value"),
                [
                    f"<tr><td>{_text(label)}</td><td>{_compact_value(value)}</td></tr>"
                    for label, value in calibration_settings
                    if value is not None
                ],
                label="SPSA learning-rate calibration",
            )
            + _table(
                (
                    "Start",
                    "Calibration directions",
                    "Perturbation",
                    "Gradient RMS",
                    "Target update RMS",
                    "Derived learning rate",
                    "Projection applied",
                ),
                calibration_evidence_rows,
                label="Calibration evidence",
            )
            + _table(
                (
                    "Start",
                    "Direction",
                    "Perturbation vector",
                    "Plus objective",
                    "Minus objective",
                    "Direction gradient",
                    "Plus offsets",
                    "Minus offsets",
                ),
                calibration_direction_rows,
                label="Calibration direction evidence",
            )
            + "</div>"
        )
    stopping_html = ""
    if isinstance(stopping_config, Mapping) and stopping_evidence_rows:
        settings = (
            ("Window size", stopping_config.get("window_size")),
            ("Minimum iterations", stopping_config.get("min_iterations")),
            (
                "Objective range tolerance",
                stopping_config.get("objective_range_tolerance"),
            ),
            ("Update norm tolerance", stopping_config.get("update_norm_tolerance")),
            (
                "Gradient norm tolerance",
                stopping_config.get("gradient_norm_tolerance"),
            ),
            (
                "Gradient standard error norm tolerance",
                stopping_config.get("gradient_standard_error_norm_tolerance"),
            ),
            (
                "Sampled standard error tolerance",
                stopping_config.get("sampled_standard_error_tolerance"),
            ),
        )
        stopping_html = (
            '<div class="visual-group"><h3>SPSA online stability stopping</h3>'
            '<p class="section-note">Online checks use pre-final iteration evidence. '
            "The final center is evaluated separately. Meeting these engineering "
            "thresholds does not prove convergence or optimality.</p>"
            + _table(
                ("Setting", "Value"),
                [
                    f"<tr><td>{_text(label)}</td><td>{_compact_value(value)}</td></tr>"
                    for label, value in settings
                    if value is not None
                ],
                label="SPSA stopping configuration",
            )
            + _table(
                (
                    "Start",
                    "Stopping status",
                    "Window iterations",
                    "Objective proxies",
                    "Final center objective",
                    "Termination",
                    "Evaluations",
                    "Backend executions",
                ),
                stopping_evidence_rows,
                label="SPSA stopping evidence",
            )
            + _table(
                (
                    "Start",
                    "Check",
                    "Status",
                    "Observed",
                    "Threshold",
                    "Samples",
                ),
                stopping_check_rows,
                label="SPSA stopping checks",
            )
            + "</div>"
        )
    return (
        calibration_html
        + stopping_html
        + '<div class="visual-group"><h3>SPSA iteration history</h3>'
        '<div class="domain-summary">'
        f"<span><strong>{iteration_count}</strong> SPSA iterations</span>"
        f"<span><strong>{_safe_int(spsa_config.get('directions_per_iteration', 1))}</strong> directions per iteration</span>"
        f"<span><strong>{_text(repeat_mode)}</strong> repeat mode</span>"
        f"<span><strong>{minimum_repeats}</strong> minimum objective repeats</span>"
        f"<span><strong>{maximum_repeats}</strong> maximum objective repeats</span>"
        f"<span><strong>{objective_repeats}</strong> objective repeats</span>"
        f"<span><strong>{_format_number(spsa_config.get('objective_standard_error_target'))}</strong> standard error target</span>"
        "</div>"
        + _table(
            (
                "Start",
                "Role",
                "Iteration",
                "Direction",
                "Actual repeats",
                "Pooled objective",
                "Pooled standard error",
                "Repeat stop reason",
                "Evaluation offsets",
            ),
            estimate_rows,
            label="SPSA objective repeat decisions",
        )
        + _table(
            (
                "Start",
                "Iteration",
                "Direction",
                "Learning rate",
                "Perturbation",
                "Pooled plus objective",
                "Pooled plus standard error",
                "Pooled minus objective",
                "Pooled minus standard error",
                "Direction gradient",
                "Averaged gradient",
                "Gradient standard error",
                "Update norm",
                "Projection",
                "Evaluation offsets",
            ),
            rows,
            label="SPSA iteration history",
        )
        + "</div>"
    )


def _render_algorithm_state(payload: Mapping[str, Any]) -> str:
    contributions = payload.get("contributions", ())
    rows = []
    if _is_sequence(contributions):
        for item in contributions:
            if not isinstance(item, Mapping):
                continue
            rows.append(
                "<tr>"
                f"<td><code>{_text(item.get('term_id', ''))}</code></td>"
                f"<td>{_text(item.get('observable_name', ''))}</td>"
                f"<td>{_compact_value(item.get('coefficient'))}</td>"
                f"<td>{_compact_value(item.get('expectation'))}</td>"
                f"<td>{_compact_value(item.get('contribution'))}</td>"
                "</tr>"
            )
    overview = (
        '<div class="domain-summary">'
        f"<span><strong>{_text(payload.get('estimator', ''))}</strong> estimator</span>"
        f"<span><strong>{_text(payload.get('source_kind', ''))}</strong> source</span>"
        f"<span><strong>{_format_number(payload.get('energy_standard_error'))}</strong> energy standard error</span>"
        f"<span><code>{_short_hash(payload.get('observable_source_hash'))}</code> source hash</span>"
        "</div>"
    )
    return (
        overview
        + '<div class="visual-group"><h3>Hamiltonian contributions</h3>'
        + _table(
            ("Term", "Observable", "Coefficient", "Expectation", "Contribution"),
            rows,
            label="Hamiltonian contributions",
        )
        + "</div>"
        + _render_observable_uncertainty(payload.get("observable_standard_errors"))
    )


def _render_algorithm_measurement(payload: Mapping[str, Any]) -> str:
    parts = [
        _render_counts(payload),
        _render_cardinality_subspace(payload.get("cardinality_subspace")),
    ]
    candidate_status = str(payload.get("candidate_status", "unavailable"))
    if candidate_status != "available":
        parts.append(
            '<div class="unavailable-block"><strong>Problem candidate is not applicable</strong>'
            "<p>The workflow has no typed optimization Problem to decode.</p></div>"
        )
    else:
        parts.append(
            '<div class="algorithm-columns">'
            + _render_candidate(
                payload.get("most_probable_candidate"),
                title="Most probable candidate",
            )
            + _render_candidate(
                payload.get("best_observed_candidate"),
                title="Best observed candidate",
            )
            + "</div>"
        )
    parts.append(
        _render_noise_execution(
            payload.get("sampling_execution"),
            title="Final sampling execution",
        )
    )
    return "".join(parts)


def _render_cardinality_subspace(value: Any) -> str:
    """Render the observed fixed-weight invariant without recomputing counts."""
    if not isinstance(value, Mapping):
        return ""
    constraints = value.get("constraints", ())
    rows = []
    for item in cast(Sequence[Any], constraints) if _is_sequence(constraints) else ():
        if not isinstance(item, Mapping):
            continue
        rows.append(
            "<tr>"
            f"<td>{_safe_int(item.get('constraint_index'))}</td>"
            f"<td><code>{_compact_value(item.get('qubits'))}</code></td>"
            f"<td>{_safe_int(item.get('target_weight'))}</td>"
            f"<td>{_format_number(item.get('preservation_rate'))}</td>"
            f"<td>{_text(item.get('preserved_shots', ''))}</td>"
            f"<td>{_text(item.get('violating_shots', ''))}</td>"
            f"<td><code>{_compact_value(item.get('weight_probabilities'))}</code></td>"
            "</tr>"
        )
    shot_summary = (
        f"<span><strong>{_safe_int(value.get('preserved_shots'))}</strong> preserved shots</span>"
        f"<span><strong>{_safe_int(value.get('violating_shots'))}</strong> violating shots</span>"
        if value.get("shots") is not None
        else ""
    )
    return (
        '<div class="visual-group cardinality-subspace">'
        "<h3>Fixed-cardinality subspace</h3>"
        '<div class="domain-summary">'
        f"<span><strong>{_text(value.get('status', ''))}</strong> observed status</span>"
        f"<span><strong>{_format_number(value.get('preservation_rate'))}</strong> preservation rate</span>"
        f"<span><strong>{_text(value.get('source_kind', ''))}</strong> evidence source</span>"
        f"{shot_summary}"
        "</div>"
        + _table(
            (
                "Group",
                "Qubits",
                "Target weight",
                "Preservation rate",
                "Preserved shots",
                "Violating shots",
                "Observed weights",
            ),
            rows,
            label="Fixed-cardinality subspace evidence",
        )
        + "</div>"
    )


def _render_algorithm_analysis(payload: Mapping[str, Any]) -> str:
    repeated = payload.get("repeated_layer_experiment")
    repeated_html = (
        _render_repeated_layer_experiment_analysis(repeated)
        if isinstance(repeated, Mapping)
        else ""
    )
    sampling_benchmark = payload.get("vqe_sampling_benchmark")
    sampling_benchmark_html = (
        _render_vqe_sampling_benchmark_analysis(sampling_benchmark)
        if isinstance(sampling_benchmark, Mapping)
        else ""
    )
    stability = payload.get("vqe_stability")
    stability_html = (
        _render_vqe_stability_analysis(stability)
        if isinstance(stability, Mapping)
        else ""
    )
    overview = (
        '<div class="domain-summary">'
        f"<span><strong>{_compact_value(payload.get('best_energy'))}</strong> best objective estimate</span>"
        f"<span><strong>{_safe_int(payload.get('best_evaluation_index'))}</strong> best source evaluation</span>"
        f"<span><strong>{_compact_value(payload.get('selected_energy'))}</strong> final selected energy</span>"
        f"<span><strong>{_safe_int(payload.get('selected_evaluation_index'))}</strong> final selected evaluation</span>"
        f"<span><strong>{_text(payload.get('optimality_claim', ''))}</strong> optimality</span>"
        "</div>"
    )
    candidate = payload.get("best_observed_candidate")
    baseline = payload.get("baseline")
    candidate_status = str(payload.get("candidate_status", "unavailable"))
    if candidate_status != "available" or not isinstance(candidate, Mapping):
        candidate_html = (
            '<div class="unavailable-block"><strong>Problem candidate is not applicable</strong>'
            "<p>The Hamiltonian was not supplied as a typed Problem.</p></div>"
        )
    else:
        candidate_html = _render_candidate(
            candidate,
            title="Best observed candidate",
        )
    if not isinstance(baseline, Mapping):
        baseline_html = (
            '<div class="unavailable-block"><strong>Classical baseline is not applicable</strong>'
            "<p>No typed Problem baseline is available.</p></div>"
        )
    else:
        baseline_html = (
            '<div class="visual-group"><h3>Classical baseline</h3>'
            + _render_value(baseline, key_hint="baseline")
            + "</div>"
        )
    return (
        repeated_html
        + sampling_benchmark_html
        + stability_html
        + overview
        + '<div class="algorithm-columns">'
        + candidate_html
        + baseline_html
        + "</div>"
        + '<div class="visual-group"><h3>Candidate gap</h3>'
        + _render_value(payload.get("candidate_gap", {}), key_hint="candidate_gap")
        + "</div>"
    )


def _render_candidate(value: Any, *, title: str) -> str:
    if not isinstance(value, Mapping):
        return (
            f'<div class="visual-group"><h3>{_text(title)}</h3>'
            '<p class="empty-note">Candidate unavailable.</p></div>'
        )
    summary = (
        '<div class="domain-summary">'
        f"<span><strong>{_text(value.get('bitstring', ''))}</strong> bitstring</span>"
        f"<span><strong>{_compact_value(value.get('objective_value'))}</strong> objective</span>"
        f"<span><strong>{_safe_int(value.get('count'))}</strong> counts</span>"
        f"<span><strong>{_compact_value(value.get('probability'))}</strong> probability</span>"
        "</div>"
    )
    return (
        f'<div class="visual-group"><h3>{_text(title)}</h3>'
        + summary
        + _render_value(value.get("decoded", {}), key_hint="decoded")
        + "</div>"
    )


def _render_analog_design(payload: Mapping[str, Any]) -> str:
    register = payload.get("register_visualization")
    pulses = payload.get("pulse_timeline")
    parts: list[str] = []
    if isinstance(register, Mapping):
        parts.append(_render_register(register))
    if isinstance(pulses, Mapping):
        parts.append(_render_pulses(pulses))
    addressing = _render_site_addressing_timeline(
        payload.get("site_addressing_timeline")
    )
    if not parts and not addressing:
        return '<p class="empty-note">No register or control timeline facts.</p>'
    visuals = (
        parts[0]
        if len(parts) == 1
        else f'<div class="analog-visual-grid">{"".join(parts)}</div>'
        if parts
        else ""
    )
    return (
        visuals
        + _render_register_snapshot(payload.get("register_snapshot"))
        + addressing
        + _render_site_phase_patterns(payload.get("site_phase_patterns"))
    )


def _render_register_snapshot(value: Any) -> str:
    if not isinstance(value, Mapping):
        return ""
    return (
        '<div class="visual-group register-snapshot"><h3>Register snapshot</h3>'
        + _render_value(value, key_hint="register_snapshot")
        + "</div>"
    )


def _render_site_phase_patterns(value: Any) -> str:
    if not _is_sequence(value):
        return ""
    rows = []
    for pattern in cast(Sequence[Any], value):
        if not isinstance(pattern, Mapping):
            continue
        sites = pattern.get("site_ids", ())
        offsets = pattern.get("offsets", ())
        pairs = (
            ", ".join(
                f"{site}: {_format_number(offset)} {pattern.get('unit', '')}"
                for site, offset in zip(
                    cast(Sequence[Any], sites), cast(Sequence[Any], offsets)
                )
            )
            if _is_sequence(sites) and _is_sequence(offsets)
            else ""
        )
        rows.append(
            "<tr>"
            f"<td><code>{_text(pattern.get('control_id', ''))}</code></td>"
            f"<td>{_text(pairs)}</td>"
            f"<td><code>{_short_hash(pattern.get('phase_pattern_hash'))}</code></td>"
            "</tr>"
        )
    if not rows:
        return ""
    return (
        '<div class="visual-group site-phase-patterns"><h3>Site phase patterns</h3>'
        + _table(
            ("Control", "Site offsets", "Pattern hash"),
            rows,
            label="Site phase patterns",
        )
        + "</div>"
    )


def _render_site_addressing_timeline(value: Any) -> str:
    if not _is_sequence(value):
        return ""
    rows = []
    for timeline in cast(Sequence[Any], value):
        if not isinstance(timeline, Mapping):
            continue
        frames = timeline.get("frames")
        if not _is_sequence(frames):
            continue
        control = str(timeline.get("control_id", timeline.get("control_kind", "")))
        unit = str(timeline.get("time_unit", ""))
        source_kind = _humanize(str(timeline.get("source_kind", "")))
        addressing_hash = timeline.get("addressing_hash")
        for frame in cast(Sequence[Any], frames):
            if not isinstance(frame, Mapping):
                continue
            start = _format_number(frame.get("start"))
            stop = _format_number(frame.get("stop"))
            interval = f"[{start}, {stop}{']' if frame.get('is_last') else ')'} {unit}"
            active = frame.get("active_sites")
            sites = []
            if _is_sequence(active):
                for site in cast(Sequence[Any], active):
                    if not isinstance(site, Mapping):
                        continue
                    sites.append(
                        f"{site.get('site_id', '')}: {_format_number(site.get('weight'))}"
                    )
            rows.append(
                "<tr>"
                f"<td><code>{_text(control)}</code></td>"
                f"<td>{_safe_int(frame.get('frame_index'))}</td>"
                f"<td>{_text(interval)}</td>"
                f"<td>{_text(', '.join(sites) if sites else 'All off')}</td>"
                f"<td>{_text(source_kind)}</td>"
                f"<td><code>{_short_hash(addressing_hash)}</code></td>"
                "</tr>"
            )
    if not rows:
        return ""
    return (
        '<div class="visual-group site-addressing"><h3>Site addressing timeline</h3>'
        + _table(
            (
                "Control",
                "Frame",
                "Interval",
                "Active sites / weights",
                "Source kind",
                "Addressing hash",
            ),
            rows,
            label="Site addressing timeline",
        )
        + "</div>"
    )


def _render_register(register: Mapping[str, Any]) -> str:
    sites = register.get("sites", ())
    if not _is_sequence(sites):
        return ""
    valid_sites = [
        site
        for site in sites
        if isinstance(site, Mapping)
        and _finite_number(site.get("x")) is not None
        and _finite_number(site.get("y")) is not None
    ]
    if not valid_sites:
        return '<p class="empty-note">Atom register contains no plottable sites.</p>'
    xs = [float(site["x"]) for site in valid_sites]
    ys = [float(site["y"]) for site in valid_sites]
    x_low, x_high = _extent(xs)
    y_low, y_high = _extent(ys)
    # Use a square plot area and one shared coordinate span so one micrometer
    # occupies the same number of pixels on both axes.
    common_span = max(x_high - x_low, y_high - y_low)
    x_mid = (x_low + x_high) / 2
    y_mid = (y_low + y_high) / 2
    x_low, x_high = x_mid - common_span / 2, x_mid + common_span / 2
    y_low, y_high = y_mid - common_span / 2, y_mid + common_span / 2
    width, height, pad = 400.0, 400.0, 48.0
    circles = []
    present_statuses: list[str] = []
    for site in valid_sites:
        x = pad + (float(site["x"]) - x_low) / (x_high - x_low) * (width - 2 * pad)
        y = (
            height
            - pad
            - (float(site["y"]) - y_low) / (y_high - y_low) * (height - 2 * pad)
        )
        filled = bool(site.get("filled"))
        status = str(site.get("status", "filled" if filled else "vacant"))
        if status not in present_statuses:
            present_statuses.append(status)
        label = site.get("atom_id") or site.get("site_id") or "site"
        detail = (
            f"{label}: x={_format_number(site['x'])}, "
            f"y={_format_number(site['y'])}, status={status}, "
            f"target={bool(site.get('is_target', True))}"
        )
        circles.append(
            f'<g><circle cx="{x:.3f}" cy="{y:.3f}" r="9" '
            f'class="atom status-{_text(status)}"><title>{_text(detail)}</title></circle>'
            f'<text x="{x:.3f}" y="{y + 26:.3f}" text-anchor="middle">{_text(label)}</text></g>'
        )
    unit = register.get("coordinate_unit", "")
    status_labels = {
        "filled": "Filled",
        "vacant": "Vacant",
        "defect": "Defect",
        "loading_failed": "Loading failed",
    }
    legend = "".join(
        f'<span><i class="legend-dot status-{_text(status)}"></i>'
        f"{_text(status_labels.get(status, _humanize(status)))}</span>"
        for status in present_statuses
    )
    fallback = f"""<div class="visual-group">
  <h3>Atom arrangement</h3>
  <div class="plot-frame"><svg class="register-plot" viewBox="0 0 400 400" width="400" height="400" role="img" aria-label="Atom arrangement with {len(valid_sites)} sites">
    <title>Atom arrangement</title><desc>Filled and empty atom sites plotted by x and y coordinates.</desc>
    <line class="axis" x1="48" y1="352" x2="352" y2="352"/><line class="axis" x1="48" y1="48" x2="48" y2="352"/>
    <text x="200" y="392" text-anchor="middle">x ({_text(unit)})</text><text x="14" y="200" transform="rotate(-90 14 200)" text-anchor="middle">y ({_text(unit)})</text>
    {"".join(circles)}
  </svg></div>
  <div class="legend">{legend}<span>{len(valid_sites)} sites</span></div>
</div>"""
    return (
        '<div class="visual-group"><h3>Atom arrangement</h3>'
        + render_register_bokeh_html(register, fallback_html=fallback)
        + f'<div class="legend">{legend}'
        f"<span>{len(valid_sites)} sites</span></div></div>"
    )


def _render_pulses(pulses: Mapping[str, Any]) -> str:
    channels = pulses.get("channels", ())
    if not _is_sequence(channels):
        return ""
    default_time_unit = str(pulses.get("time_unit", ""))
    rendered = [
        _render_pulse_channel(channel, default_time_unit=default_time_unit)
        for channel in channels
        if isinstance(channel, Mapping)
    ]
    fallback = (
        '<div class="visual-group"><h3>Control waveforms</h3>'
        f'<div class="pulse-stack">{"".join(rendered)}</div></div>'
    )
    if not rendered:
        return fallback
    return (
        '<div class="visual-group"><h3>Control waveforms</h3>'
        + render_pulse_bokeh_html(pulses, fallback_html=fallback)
        + "</div>"
    )


def _render_pulse_channel(
    channel: Mapping[str, Any],
    *,
    default_time_unit: str = "",
) -> str:
    channel_id = str(channel.get("channel_id", "channel"))
    channel_label = _humanize(channel_id)
    points = _channel_points(channel)
    value_unit = str(channel.get("value_unit", ""))
    time_unit = str(channel.get("time_unit", default_time_unit))
    if not points:
        return (
            '<div class="pulse-row">'
            f'<div class="pulse-meta"><strong>{_text(channel_label)}</strong><span>No plottable samples</span></div>'
            "</div>"
        )
    times = [point[0] for point in points]
    values = [point[1] for point in points]
    duration = channel.get("duration", max(times))
    x_low, x_high = _extent(times, minimum_zero=True)
    y_low, y_high = _extent(values)
    width, height = 720.0, 150.0
    left, right, top, bottom = 62.0, 18.0, 20.0, 32.0
    coords = [
        (
            left + (time - x_low) / (x_high - x_low) * (width - left - right),
            height
            - bottom
            - (value - y_low) / (y_high - y_low) * (height - top - bottom),
        )
        for time, value in points
    ]
    polyline = " ".join(f"{x:.3f},{y:.3f}" for x, y in coords)
    dots = "".join(
        f'<circle cx="{x:.3f}" cy="{y:.3f}" r="3"><title>t={_format_number(t)} {_text(time_unit)}, value={_format_number(v)} {_text(value_unit)}</title></circle>'
        for (x, y), (t, v) in zip(coords, points)
    )
    site_ids = channel.get("site_ids")
    weights = channel.get("site_weights")
    addressing_times = channel.get("addressing_times")
    addressing_weights = channel.get("addressing_weights")
    address = ""
    if (
        _is_sequence(addressing_times)
        and _is_sequence(addressing_weights)
        and len(cast(Sequence[Any], addressing_times)) > 1
    ):
        frame_count = len(cast(Sequence[Any], addressing_times))
        source_kind = _humanize(str(channel.get("addressing_source_kind", "")))
        address = (
            f"<span>{frame_count} addressing frames / {_text(source_kind)} / "
            f"<code>{_short_hash(channel.get('addressing_hash'))}</code></span>"
        )
    elif _is_sequence(site_ids) and _is_sequence(weights):
        pairs = ", ".join(
            f"{site}: {_format_number(weight)}"
            for site, weight in zip(
                cast(Sequence[Any], site_ids),
                cast(Sequence[Any], weights),
            )
        )
        address = f"<span>Site pattern / {_text(pairs)}</span>"
    return f"""<div class="pulse-row">
  <div class="pulse-meta"><strong>{_text(channel_label)}</strong><span>{_text(str(channel.get("waveform_kind", "control")))} / duration {_format_number(duration)} {_text(time_unit)}</span>{address}</div>
  <div class="plot-frame"><svg class="pulse-plot" viewBox="0 0 720 150" width="720" height="150" role="img" aria-label="{_attr(channel_label)} waveform">
    <title>{_text(channel_label)} waveform</title><desc>Control value over time.</desc>
    <line class="axis" x1="62" y1="118" x2="702" y2="118"/><line class="axis" x1="62" y1="20" x2="62" y2="118"/>
    <text x="382" y="145" text-anchor="middle">time ({_text(time_unit)})</text><text x="8" y="72" transform="rotate(-90 8 72)" text-anchor="middle">{_text(value_unit or "value")}</text>
    <polyline points="{polyline}"/>{dots}
  </svg></div>
</div>"""


def _channel_points(channel: Mapping[str, Any]) -> list[tuple[float, float]]:
    raw_points = channel.get("points", ())
    points: list[tuple[float, float]] = []
    if _is_sequence(raw_points):
        for point in raw_points:
            if not isinstance(point, Mapping):
                continue
            time = _finite_number(point.get("time"))
            value = _finite_number(point.get("value"))
            if time is not None and value is not None:
                points.append((time, value))
    if points:
        return points
    raw_segments = channel.get("segments", ())
    if _is_sequence(raw_segments):
        for segment in raw_segments:
            if not isinstance(segment, Mapping):
                continue
            start = _finite_number(segment.get("start"))
            stop = _finite_number(segment.get("stop"))
            value = _finite_number(segment.get("value"))
            if start is not None and stop is not None and value is not None:
                points.extend(((start, value), (stop, value)))
    return points


def _render_sweep_parameters(payload: Mapping[str, Any]) -> str:
    axes = payload.get("parameter_axes", {})
    bindings = payload.get("bindings", ())
    axis_rows = []
    if isinstance(axes, Mapping):
        for name in sorted(axes, key=str):
            values = axes[name]
            axis_rows.append(
                "<tr>"
                f"<td><code>{_text(name)}</code></td>"
                f"<td>{_sequence_length(values)}</td><td>{_compact_value(values)}</td>"
                "</tr>"
            )
    binding_rows = []
    if _is_sequence(bindings):
        for binding in bindings:
            if not isinstance(binding, Mapping):
                continue
            binding_rows.append(
                "<tr>"
                f"<td>{_text(binding.get('scan_index', ''))}</td>"
                f"<td><code>{_text(binding.get('parameter_bind_id', ''))}</code></td>"
                f"<td>{_compact_value(binding.get('values'))}</td>"
                f"<td>{_text(binding.get('compile_required', ''))}</td>"
                "</tr>"
            )
    return (
        '<div class="domain-summary">'
        f"<span><strong>{_safe_int(payload.get('bind_count'))}</strong> scan points</span>"
        f"<span><strong>{_sequence_length(payload.get('parameter_names'))}</strong> parameters</span>"
        "</div>"
        + _table(("Parameter", "Values", "Axis"), axis_rows, label="Parameter axes")
        + _table(
            ("Index", "Bind", "Values", "Recompile"),
            binding_rows,
            label="Parameter bindings",
        )
    )


def _render_batch_parameters(payload: Mapping[str, Any]) -> str:
    binds = payload.get("parameter_binds", ())
    rows = []
    if _is_sequence(binds):
        for item in binds:
            if not isinstance(item, Mapping):
                continue
            rows.append(
                "<tr>"
                f"<td>{_text(item.get('item_index', ''))}</td>"
                f"<td><code>{_text(item.get('parameter_bind_id', ''))}</code></td>"
                f"<td><code>{_short_hash(item.get('parameter_bind_hash'))}</code></td>"
                "</tr>"
            )
    note = payload.get("parameter_values_unavailable_reason")
    return (
        '<div class="domain-summary">'
        f"<span><strong>{_safe_int(payload.get('item_count'))}</strong> batch items</span>"
        f"<span><code>{_short_hash(payload.get('compiled_program_hash'))}</code> compiled program</span>"
        "</div>"
        + (f'<p class="context-note">{_text(note)}</p>' if note else "")
        + _table(("Index", "Parameter bind", "Bind hash"), rows, label="Batch inputs")
    )


def _render_validation(payload: Mapping[str, Any]) -> str:
    by_severity = payload.get("by_severity", {})
    by_stage = payload.get("by_stage", {})
    summary = (
        '<div class="domain-summary">'
        f"<span><strong>{_safe_int(payload.get('diagnostic_count'))}</strong> diagnostics</span>"
        f"<span>{_compact_value(by_severity)} by severity</span>"
        f"<span>{_compact_value(by_stage)} by stage</span>"
        "</div>"
    )
    control = payload.get("control_constraint_diagnostics")
    if not _is_sequence(control):
        return summary
    rows = []
    for item in cast(Sequence[Any], control):
        if not isinstance(item, Mapping):
            continue
        rows.append(
            "<tr>"
            f"<td><code>{_text(item.get('code', ''))}</code></td>"
            f"<td>{_status_badge(str(item.get('severity', '')))}</td>"
            f"<td>{_text(item.get('message', ''))}</td>"
            f"<td><code>{_text(item.get('object_path', ''))}</code></td>"
            "</tr>"
        )
    return summary + (
        '<div class="visual-group control-diagnostics"><h3>Control constraint diagnostics</h3>'
        + _table(
            ("Code", "Severity", "Message", "Path"),
            rows,
            label="Control constraint diagnostics",
        )
        + "</div>"
        if rows
        else ""
    )


def _render_plan(payload: Mapping[str, Any]) -> str:
    metrics = []
    for key in (
        "plan_hash",
        "failure_policy",
        "program_kind",
        "compiled_program_hash",
        "backend_id",
    ):
        if key in payload:
            metrics.append(
                f"<span><strong>{_text(_humanize(key))}</strong> {_compact_value(payload[key])}</span>"
            )
    resource = payload.get("resource_plan", payload.get("resource_estimate"))
    if isinstance(resource, Mapping):
        for key in (
            "selected_workers",
            "estimated_peak_bytes",
            "budget_bytes",
            "method",
        ):
            if key in resource:
                metrics.append(
                    f"<span><strong>{_text(_humanize(key))}</strong> {_compact_value(resource[key])}</span>"
                )
    summary = f'<div class="domain-summary">{"".join(metrics)}</div>' if metrics else ""
    schedules = payload.get("control_schedules")
    if not _is_sequence(schedules):
        return summary
    rows = []
    for item in cast(Sequence[Any], schedules):
        if not isinstance(item, Mapping):
            continue
        schedule = item.get("schedule")
        if not isinstance(schedule, Mapping):
            continue
        operations = schedule.get("operations", ())
        if not _is_sequence(operations):
            continue
        for operation in cast(Sequence[Any], operations):
            if not isinstance(operation, Mapping):
                continue
            interval = (
                f"[{_format_number(operation.get('start_time'))}, "
                f"{_format_number(operation.get('end_time'))}]"
            )
            rows.append(
                "<tr>"
                f"<td><code>{_text(item.get('block_id', ''))}</code></td>"
                f"<td><code>{_text(operation.get('operation_id', ''))}</code></td>"
                f"<td><code>{_text(operation.get('channel_id', ''))}</code></td>"
                f"<td>{_text(interval)}</td>"
                f"<td>{_compact_value(operation.get('target_site_ids'))}</td>"
                f"<td><code>{_short_hash(operation.get('waveform_hash'))}</code></td>"
                "</tr>"
            )
    return summary + (
        '<div class="visual-group control-schedules"><h3>Control schedules</h3>'
        + _table(
            (
                "Block",
                "Operation",
                "Channel",
                "Interval",
                "Target sites",
                "Waveform hash",
            ),
            rows,
            label="Control schedules",
        )
        + "</div>"
        if rows
        else ""
    )


def _render_execution(payload: Mapping[str, Any]) -> str:
    counts = payload.get("counts")
    items = payload.get("items")
    parts = [
        _render_key_metrics(payload),
        _render_program_lineage(payload),
        _render_resource_usage(payload.get("resource_usage")),
    ]
    if isinstance(counts, Mapping):
        parts.append(_render_status_counts(counts))
    if _is_sequence(items):
        parts.append(_render_item_table(cast(Sequence[Any], items)))
    parts.append(
        _render_algorithm_objective_execution(payload.get("objective_execution"))
    )
    return "".join(parts)


def _render_program_lineage(payload: Mapping[str, Any]) -> str:
    """Render source/runtime Program identity when an orchestrator exposes both."""
    source_hash = payload.get("source_program_hash")
    runtime_hash = payload.get("runtime_program_hash")
    if source_hash is None or runtime_hash is None:
        return ""
    rows = [
        (
            "Source Program",
            f"<code>{_text(source_hash)}</code>",
        ),
        (
            "Runtime Program",
            f"<code>{_text(runtime_hash)}</code>",
        ),
        (
            "Lineage",
            _text(payload.get("program_lineage", "")),
        ),
    ]
    return (
        '<div class="visual-group program-lineage"><h3>Program lineage</h3>'
        + _table(
            ("Identity", "Value"),
            [
                f"<tr><td>{_text(label)}</td><td>{value}</td></tr>"
                for label, value in rows
            ],
            label="Program lineage",
        )
        + "</div>"
    )


def _render_resource_usage(value: Any) -> str:
    """Render execution resources as readable facts instead of inline JSON."""
    if value is None:
        return ""
    if not isinstance(value, Mapping):
        return (
            '<div class="visual-group resource-usage"><h3>Resource usage</h3>'
            '<p class="context-note">Structured resource usage is unavailable.</p>'
            "</div>"
        )

    labels = {
        "measurement_status": "Measurement status",
        "measurement_scope": "Measurement scope",
        "wall_time_seconds": "Wall time",
        "estimated_peak_bytes": "Estimated peak memory",
        "actual_peak_rss_bytes": "Actual peak RSS",
        "baseline_peak_rss_bytes": "Baseline peak RSS",
        "incremental_peak_rss_bytes": "Incremental peak RSS",
        "estimate_error_fraction": "Estimate error",
        "estimate_within_tolerance": "Estimate within tolerance",
        "rss_semantics": "RSS semantics",
    }
    rows = []
    for key, label in labels.items():
        if key not in value:
            continue
        rows.append(
            "<tr>"
            f"<td>{_text(label)}</td>"
            f"<td>{_format_resource_value(key, value[key])}</td>"
            "</tr>"
        )
    if not rows:
        return (
            '<div class="visual-group resource-usage"><h3>Resource usage</h3>'
            '<p class="context-note">No standard resource measurements are available.</p>'
            "</div>"
        )
    return (
        '<div class="visual-group resource-usage"><h3>Resource usage</h3>'
        + _table(("Metric", "Value"), rows, label="Resource usage")
        + "</div>"
    )


def _format_resource_value(key: str, value: Any) -> str:
    """Apply experiment-facing units while raw values remain in provenance."""
    if key.endswith("_bytes"):
        return _text(_format_bytes(value))
    if key.endswith("_seconds"):
        return _text(_format_duration(value))
    if key.endswith("_fraction"):
        number = _finite_number(value)
        return _text("unavailable" if number is None else f"{number * 100:.2f}%")
    if isinstance(value, bool):
        return _text("Yes" if value else "No")
    if key in {"measurement_scope", "measurement_status", "rss_semantics"}:
        return _text(_humanize(str(value)))
    return _compact_value(value)


def _render_state(payload: Mapping[str, Any]) -> str:
    parts: list[str] = []
    transitions = payload.get("state_transitions")
    if _is_sequence(transitions) and transitions:
        rows = []
        for item in cast(Sequence[Any], transitions):
            if not isinstance(item, Mapping):
                continue
            rows.append(
                "<tr>"
                f"<td><code>{_text(item.get('block_id', ''))}</code></td>"
                f"<td>{_text(item.get('program_kind', ''))}</td>"
                f"<td><code>{_text(item.get('kernel', ''))}</code></td>"
                f"<td><code>{_short_hash(item.get('input_state_hash'))}</code></td>"
                f"<td><code>{_short_hash(item.get('output_state_hash'))}</code></td>"
                "</tr>"
            )
        parts.append(
            _table(
                ("Block", "Type", "Kernel", "Input state", "Output state"),
                rows,
                label="Hybrid state handoff",
            )
        )
    else:
        items = payload.get("items")
        if _is_sequence(items):
            parts.append(_render_reference_table(cast(Sequence[Any], items)))
        else:
            parts.append(
                _render_key_metrics(
                    {
                        key: value
                        for key, value in payload.items()
                        if key
                        not in {
                            "dynamic_addressing_consumers",
                            "site_phase_pattern_consumers",
                            "register_snapshots",
                        }
                    }
                )
            )
    consumers = _render_dynamic_addressing_consumers(
        payload.get("dynamic_addressing_consumers")
    )
    if consumers:
        parts.append(consumers)
    snapshots = payload.get("register_snapshots")
    if _is_sequence(snapshots):
        for snapshot in cast(Sequence[Any], snapshots):
            parts.append(_render_register_snapshot(snapshot))
    phase_consumers = _render_site_phase_pattern_consumers(
        payload.get("site_phase_pattern_consumers")
    )
    if phase_consumers:
        parts.append(phase_consumers)
    return "".join(parts)


def _render_site_phase_pattern_consumers(value: Any) -> str:
    if not _is_sequence(value):
        return ""
    rows = []
    for item in cast(Sequence[Any], value):
        if not isinstance(item, Mapping):
            continue
        rows.append(
            "<tr>"
            f"<td><code>{_text(item.get('block_id', ''))}</code></td>"
            f"<td>{_text(item.get('consumer', ''))}</td>"
            f"<td>{_safe_int(item.get('term_index'))}</td>"
            f"<td>{_compact_value(item.get('site_ids'))}</td>"
            f"<td>{_compact_value(item.get('offsets'))} {_text(item.get('unit', ''))}</td>"
            f"<td><code>{_short_hash(item.get('phase_pattern_hash'))}</code></td>"
            "</tr>"
        )
    if not rows:
        return ""
    return (
        '<div class="visual-group phase-pattern-consumers"><h3>Site phase pattern consumers</h3>'
        + _table(
            ("Block", "Consumer", "Term", "Sites", "Offsets", "Pattern hash"),
            rows,
            label="Site phase pattern consumers",
        )
        + "</div>"
    )


def _render_dynamic_addressing_consumers(value: Any) -> str:
    if not _is_sequence(value):
        return ""
    rows = []
    for item in cast(Sequence[Any], value):
        if not isinstance(item, Mapping):
            continue
        control = f"{item.get('control_kind', '')}_{item.get('term_index', 0)}"
        duration = f"{_format_number(item.get('duration'))} {_text(str(item.get('time_unit', '')))}"
        frames = f"{_safe_int(item.get('frame_count'))} frames"
        rows.append(
            "<tr>"
            f"<td><code>{_text(item.get('block_id', ''))}</code></td>"
            f"<td>{_text(item.get('consumer', ''))}</td>"
            f"<td><code>{_text(control)}</code></td>"
            f"<td>{_text(frames)}</td>"
            f"<td>{duration}</td>"
            f"<td>{_text(_humanize(str(item.get('source_kind', ''))))}</td>"
            f"<td><code>{_short_hash(item.get('addressing_hash'))}</code></td>"
            "</tr>"
        )
    if not rows:
        return ""
    return (
        '<div class="visual-group dynamic-addressing-consumers"><h3>Dynamic addressing consumers</h3>'
        + _table(
            (
                "Block",
                "Consumer",
                "Control",
                "Frames",
                "Duration",
                "Source kind",
                "Addressing hash",
            ),
            rows,
            label="Dynamic addressing consumers",
        )
        + "</div>"
    )


def _render_measurement(profile: str, payload: Mapping[str, Any]) -> str:
    if profile == "sweep":
        series = payload.get("series")
        if isinstance(series, Mapping):
            value_key = (
                "probability" if _series_has_value(series, "probability") else "count"
            )
            return _render_line_chart(
                series,
                value_key=value_key,
                title=f"Outcome {value_key} by scan point",
            ) + _render_measurement_items(payload.get("items"))
    if profile == "comparison":
        sources = payload.get("sources")
        if isinstance(sources, Mapping):
            return "".join(
                '<div class="comparison-source">'
                f"<h3>{_text(label)}</h3>{_render_counts(source, identity_hint=f'comparison.{label}')}"
                "</div>"
                for label, source in sorted(
                    sources.items(), key=lambda item: str(item[0])
                )
                if isinstance(source, Mapping)
            )
    if profile == "batch":
        return _render_counts(
            {"counts": payload.get("aggregate_counts", {})}
        ) + _render_item_table(
            cast(Sequence[Any], payload.get("items"))
            if _is_sequence(payload.get("items"))
            else ()
        )
    return (
        _render_counts(payload)
        + _render_cardinality_subspace(payload.get("cardinality_subspace"))
        + _render_measurement_contract(payload)
    )


def _render_analysis(profile: str, payload: Mapping[str, Any]) -> str:
    if profile == "sweep":
        series = payload.get("series")
        if isinstance(series, Mapping):
            return _render_line_chart(
                series,
                value_key="value",
                title="Observable value by scan point",
            )
    if profile == "comparison":
        comparisons = payload.get("comparisons")
        if isinstance(comparisons, Mapping):
            rows = []
            for label, comparison in sorted(
                comparisons.items(), key=lambda item: str(item[0])
            ):
                rows.append(
                    "<tr>"
                    f"<td>{_text(label)}</td><td>{_compact_value(comparison)}</td>"
                    "</tr>"
                )
            return _table(("Candidate", "Delta"), rows, label="Comparison deltas")
    observable_batch = payload.get("observable_batch")
    batch_html = ""
    if isinstance(observable_batch, Mapping) and _is_sequence(
        observable_batch.get("items")
    ):
        rows = []
        for raw_item in cast(Sequence[Any], observable_batch["items"]):
            if not isinstance(raw_item, Mapping):
                continue
            observable = raw_item.get("observable")
            name = (
                observable.get("name") if isinstance(observable, Mapping) else "unknown"
            )
            rows.append(
                "<tr>"
                f"<td><code>{_text(name)}</code></td>"
                f"<td>{_compact_value(raw_item.get('expectation'))}</td>"
                f"<td>{_compact_value(raw_item.get('variance'))}</td>"
                f"<td>{_compact_value(raw_item.get('standard_error'))}</td>"
                f"<td>{_compact_value(raw_item.get('sample_count'))}</td>"
                f"<td>{_text(raw_item.get('source_kind'))}</td>"
                "</tr>"
            )
        batch_html = _table(
            ("Observable", "Expectation", "Variance", "SE", "N", "Source"),
            rows,
            label="Observable batch",
        )
    observables = payload.get("observables")
    if isinstance(observables, Mapping):
        rows = [
            f"<tr><td><code>{_text(name)}</code></td><td>{_compact_value(value)}</td></tr>"
            for name, value in sorted(
                observables.items(), key=lambda item: str(item[0])
            )
        ]
        return batch_html + _table(
            ("Observable", "Value"), rows, label="Built-in observables"
        )
    if batch_html:
        return batch_html
    return _render_key_metrics(payload)


def _render_counts(
    payload: Mapping[str, Any],
    *,
    identity_hint: str = "measurement",
) -> str:
    counts = payload.get("counts", {})
    probabilities = payload.get("probabilities")
    if not isinstance(counts, Mapping) or not counts:
        return '<p class="empty-note">No count outcomes available.</p>'
    normalized = [(str(key), _safe_int(value)) for key, value in counts.items()]
    normalized.sort(key=lambda item: (-item[1], item[0]))
    limit = 24
    shown = normalized[:limit]
    maximum = max((value for _, value in shown), default=1) or 1
    bars = []
    for outcome, count in shown:
        probability = None
        if isinstance(probabilities, Mapping):
            probability = _finite_number(probabilities.get(outcome))
        width = count / maximum * 100.0
        bars.append(
            '<div class="histogram-row">'
            f'<code>{_text(outcome)}</code><div class="bar-track"><div class="bar-fill" style="width:{width:.4f}%"></div></div>'
            f"<span>{count}"
            + (
                f" / {_format_number(probability * 100)}%"
                if probability is not None
                else ""
            )
            + "</span></div>"
        )
    note = (
        f'<p class="context-note">Showing top {limit} of {len(normalized)} outcomes.</p>'
        if len(normalized) > limit
        else ""
    )
    fallback = (
        '<div class="visual-group"><h3>Measurement distribution</h3>'
        f'<div class="histogram" role="img" aria-label="Counts for {len(normalized)} outcomes">{"".join(bars)}</div></div>'
    )
    return (
        '<div class="visual-group"><h3>Measurement distribution</h3>'
        + render_counts_bokeh_html(
            payload,
            identity_hint=identity_hint,
            fallback_html=fallback,
        )
        + note
        + "</div>"
    )


def _render_line_chart(
    series: Mapping[str, Any],
    *,
    value_key: str,
    title: str,
) -> str:
    normalized: list[tuple[str, list[tuple[float, float]]]] = []
    for label, raw_points in sorted(series.items(), key=lambda item: str(item[0])):
        if not _is_sequence(raw_points):
            continue
        points = []
        for raw in raw_points:
            if not isinstance(raw, Mapping):
                continue
            x = _finite_number(raw.get("scan_index"))
            y = _finite_number(raw.get(value_key))
            if x is not None and y is not None:
                points.append((x, y))
        if points:
            normalized.append((str(label), points))
    if not normalized:
        return (
            f'<p class="empty-note">No numeric {_text(value_key)} trend available.</p>'
        )
    displayed = normalized[:8]
    all_x = [x for _, points in displayed for x, _ in points]
    all_y = [y for _, points in displayed for _, y in points]
    x_low, x_high = _extent(all_x)
    y_low, y_high = _extent(all_y)
    width, height = 760.0, 300.0
    left, right, top, bottom = 62.0, 24.0, 24.0, 42.0
    paths = []
    legends = []
    for index, (label, points) in enumerate(displayed):
        color = _SERIES_COLORS[index % len(_SERIES_COLORS)]
        coords = [
            (
                left + (x - x_low) / (x_high - x_low) * (width - left - right),
                height
                - bottom
                - (y - y_low) / (y_high - y_low) * (height - top - bottom),
            )
            for x, y in points
        ]
        polyline = " ".join(f"{x:.3f},{y:.3f}" for x, y in coords)
        dots = "".join(
            f'<circle cx="{x:.3f}" cy="{y:.3f}" r="3" style="fill:{color}"><title>{_text(label)} / x={_format_number(source_x)} / {_text(value_key)}={_format_number(source_y)}</title></circle>'
            for (x, y), (source_x, source_y) in zip(coords, points)
        )
        paths.append(f'<polyline points="{polyline}" style="stroke:{color}"/>{dots}')
        legends.append(f'<span><i style="background:{color}"></i>{_text(label)}</span>')
    note = (
        f'<p class="context-note">Showing 8 of {len(normalized)} series; all values remain in source facts.</p>'
        if len(normalized) > 8
        else ""
    )
    fallback = f"""<div class="visual-group"><h3>{_text(title)}</h3>
  <div class="plot-frame"><svg class="trend-plot" viewBox="0 0 760 300" role="img" aria-label="{_attr(title)}">
    <title>{_text(title)}</title><desc>Multiple series over scan index.</desc>
    <line class="axis" x1="62" y1="258" x2="736" y2="258"/><line class="axis" x1="62" y1="24" x2="62" y2="258"/>
    <text x="399" y="294" text-anchor="middle">scan index</text><text x="10" y="150" transform="rotate(-90 10 150)" text-anchor="middle">{_text(value_key)}</text>
    {"".join(paths)}
  </svg></div><div class="legend">{"".join(legends)}</div></div>"""
    return (
        f'<div class="visual-group"><h3>{_text(title)}</h3>'
        + render_trend_bokeh_html(
            series,
            value_key=value_key,
            title=title,
            fallback_html=fallback,
        )
        + note
        + "</div>"
    )


def _render_measurement_items(value: Any) -> str:
    if not _is_sequence(value):
        return ""
    rows = []
    for item in value:
        if not isinstance(item, Mapping):
            continue
        rows.append(
            "<tr>"
            f"<td>{_text(item.get('scan_index', ''))}</td>"
            f"<td>{_compact_value(item.get('parameters'))}</td>"
            f"<td>{_text(item.get('state', ''))}</td>"
            f"<td>{_compact_value(item.get('counts'))}</td>"
            "</tr>"
        )
    return _table(
        ("Index", "Parameters", "State", "Counts"),
        rows,
        label="Scan point measurements",
    )


def _render_measurement_contract(payload: Mapping[str, Any]) -> str:
    rows = []
    for key in (
        "shots",
        "bit_ordering",
        "occupation_encoding",
        "measurement",
        "measurement_projection",
    ):
        if key in payload and payload[key] is not None:
            rows.append(
                f"<tr><td>{_text(_humanize(key))}</td><td>{_compact_value(payload[key])}</td></tr>"
            )
    return (
        _table(("Measurement fact", "Value"), rows, label="Measurement contract")
        if rows
        else ""
    )


def _render_status_counts(counts: Mapping[str, Any]) -> str:
    parts = []
    for name, value in sorted(counts.items(), key=lambda item: str(item[0])):
        parts.append(
            f"<div><span>{_text(_humanize(name))}</span><strong>{_safe_int(value)}</strong></div>"
        )
    return f'<div class="status-counts">{"".join(parts)}</div>'


def _render_item_table(items: Sequence[Any]) -> str:
    rows = []
    for item in items:
        if not isinstance(item, Mapping):
            continue
        index = item.get("item_index", item.get("scan_index", ""))
        status = item.get("status", item.get("state", ""))
        identity = item.get("parameter_bind_id", item.get("block_id", ""))
        result_id = item.get(
            "result_id", item.get("backend_job_id", item.get("job_id"))
        )
        rows.append(
            "<tr>"
            f"<td>{_text(index)}</td><td><code>{_text(identity)}</code></td>"
            f"<td>{_status_badge(str(status))}</td><td><code>{_text(result_id or '')}</code></td>"
            "</tr>"
        )
    return _table(
        ("Index", "Identity", "Status", "Result / job"), rows, label="Execution items"
    )


def _render_reference_table(items: Sequence[Any]) -> str:
    rows = []
    for item in items:
        if not isinstance(item, Mapping):
            continue
        index = item.get("item_index", item.get("scan_index", ""))
        rows.append(
            "<tr>"
            f"<td>{_text(index)}</td><td>{_status_badge(str(item.get('status', item.get('state', ''))))}</td>"
            f"<td><code>{_text(item.get('result_id') or '')}</code></td>"
            f"<td><code>{_short_hash(item.get('result_hash'))}</code></td>"
            f"<td>{_compact_value(item.get('references'))}</td>"
            "</tr>"
        )
    return _table(
        ("Index", "State", "Result", "Hash", "References"),
        rows,
        label="Result references",
    )


def _render_key_metrics(payload: Mapping[str, Any]) -> str:
    keys = (
        "state",
        "status",
        "target_id",
        "seed",
        "backend_id",
        "failure_policy",
        "trace_id",
        "truthfulness",
    )
    metrics = [
        f"<span><strong>{_text(_humanize(key))}</strong> {_compact_value(payload[key])}</span>"
        for key in keys
        if key in payload and payload[key] is not None
    ]
    return f'<div class="domain-summary">{"".join(metrics)}</div>' if metrics else ""


def _render_diagnostics(section: ExperimentSectionIR) -> str:
    if not section.diagnostics:
        return ""
    rows = [
        "<tr>"
        f"<td>{_status_badge(diagnostic.severity)}</td>"
        f"<td><code>{_text(diagnostic.code)}</code></td>"
        f"<td>{_text(diagnostic.stage)}</td><td>{_text(diagnostic.message)}</td>"
        "</tr>"
        for diagnostic in section.diagnostics
    ]
    return (
        '<div class="diagnostics"><h3>Diagnostics</h3>'
        + _table(
            ("Severity", "Code", "Stage", "Message"),
            rows,
            label="Diagnostics",
        )
        + "</div>"
    )


def _render_value(value: Any, *, key_hint: str = "value") -> str:
    if isinstance(value, Mapping):
        rows = "".join(
            f'<div class="fact-row"><dt>{_text(_humanize(str(key)))}</dt>'
            f"<dd>{_render_value(item, key_hint=str(key))}</dd></div>"
            for key, item in sorted(value.items(), key=lambda pair: str(pair[0]))
        )
        return f'<dl class="fact-list">{rows}</dl>'
    if _is_sequence(value):
        if not value:
            return '<span class="muted">empty</span>'
        return (
            '<ol class="value-list">'
            + "".join(
                f"<li>{_render_value(item, key_hint=key_hint)}</li>" for item in value
            )
            + "</ol>"
        )
    if value is None:
        return '<span class="muted">unavailable</span>'
    if isinstance(value, bool):
        return _text(str(value).lower())
    if isinstance(value, (int, float)):
        return _text(_format_number(value))
    if "hash" in key_hint.lower() or key_hint.lower().endswith("_id"):
        return f"<code>{_text(value)}</code>"
    return _text(value)


def _table(headers: Sequence[str], rows: Sequence[str], *, label: str) -> str:
    if not rows:
        return ""
    head = "".join(f"<th>{_text(header)}</th>" for header in headers)
    return (
        f'<div class="table-wrap"><table aria-label="{_attr(label)}">'
        f"<thead><tr>{head}</tr></thead><tbody>{''.join(rows)}</tbody></table></div>"
    )


def _status_badge(status: str) -> str:
    normalized = status.lower().replace("_", "-")
    semantic_status = {
        "stable": "passed",
        "unstable": "failed",
        "insufficient-evidence": "warning",
    }.get(normalized, normalized)
    known = {
        "available",
        "completed",
        "passed",
        "ok",
        "warning",
        "partially-completed",
        "running",
        "queued",
        "cancelled",
        "error",
        "failed",
        "unavailable",
    }
    css_status = semantic_status if semantic_status in known else "neutral"
    return (
        f'<span class="status-badge status-{_attr(css_status)}">{_text(status)}</span>'
    )


def _compact_value(value: Any) -> str:
    if value is None:
        return '<span class="muted">unavailable</span>'
    if isinstance(value, Mapping):
        return _text(stable_json(value))
    if _is_sequence(value):
        return _text(", ".join(str(item) for item in value))
    if isinstance(value, float):
        return _text(_format_number(value))
    return _text(value)


def _language_script() -> str:
    translations = json.dumps(
        _ZH_TRANSLATIONS,
        ensure_ascii=True,
        sort_keys=True,
        separators=(",", ":"),
    )
    template = """<script>(function(){
const translations=__TRANSLATIONS__;
const selector=document.getElementById("report-language");
const root=document.querySelector("main.report-shell");
if(!selector||!root){return;}
const originalText=new WeakMap();
const originalAttributes=new WeakMap();
const originalTitle=document.title;
const skipped=new Set(["SCRIPT","STYLE","CODE","PRE","NOSCRIPT"]);
function translatedText(value,language){
  if(language!=="zh"){return value;}
  const leading=value.match(/^\\s*/)[0];
  const trailing=value.match(/\\s*$/)[0];
  const key=value.trim();
  return leading+(translations[key]||key)+trailing;
}
function applyLanguage(language){
  document.documentElement.lang=language==="zh"?"zh-CN":"en";
  document.title=language==="zh"?(translations[originalTitle]||originalTitle):originalTitle;
  const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);
  let node;
  while((node=walker.nextNode())){
    const parent=node.parentElement;
    if(!parent||skipped.has(parent.tagName)){continue;}
    if(!originalText.has(node)){originalText.set(node,node.nodeValue||"");}
    node.nodeValue=translatedText(originalText.get(node),language);
  }
  root.querySelectorAll("[aria-label],[title]").forEach((element)=>{
    let saved=originalAttributes.get(element);
    if(!saved){
      saved={ariaLabel:element.getAttribute("aria-label"),title:element.getAttribute("title")};
      originalAttributes.set(element,saved);
    }
    if(saved.ariaLabel!==null){
      element.setAttribute("aria-label",language==="zh"?(translations[saved.ariaLabel]||saved.ariaLabel):saved.ariaLabel);
    }
    if(saved.title!==null){
      element.setAttribute("title",language==="zh"?(translations[saved.title]||saved.title):saved.title);
    }
  });
}
selector.addEventListener("change",()=>applyLanguage(selector.value));
applyLanguage(selector.value);
})();</script>"""
    return template.replace("__TRANSLATIONS__", translations)


def _embedded_json(report: ExperimentReportIR) -> str:
    # HTML parsers recognize script end tags before JSON parsing. Escaping these
    # characters keeps untrusted titles and metadata inside the data block.
    text = json.dumps(
        report.to_dict(),
        ensure_ascii=True,
        sort_keys=True,
        separators=(",", ":"),
    )
    return (
        text.replace("&", "\\u0026")
        .replace("<", "\\u003c")
        .replace(">", "\\u003e")
        .replace("\u2028", "\\u2028")
        .replace("\u2029", "\\u2029")
    )


def _series_has_value(series: Mapping[str, Any], key: str) -> bool:
    return any(
        isinstance(point, Mapping) and _finite_number(point.get(key)) is not None
        for raw_points in series.values()
        if _is_sequence(raw_points)
        for point in raw_points
    )


def _extent(
    values: Sequence[float],
    *,
    minimum_zero: bool = False,
) -> tuple[float, float]:
    low = min(values)
    high = max(values)
    if minimum_zero:
        low = min(low, 0.0)
    if low == high:
        padding = max(abs(low) * 0.1, 0.5)
        return low - padding, high + padding
    padding = (high - low) * 0.06
    return low - padding, high + padding


def _finite_number(value: Any) -> float | None:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    number = float(value)
    return number if math.isfinite(number) else None


def _is_sequence(value: Any) -> bool:
    return isinstance(value, Sequence) and not isinstance(value, (str, bytes))


def _sequence_length(value: Any) -> int:
    return len(value) if _is_sequence(value) else 0


def _safe_int(value: Any) -> int:
    if isinstance(value, bool):
        return 0
    if isinstance(value, (int, float)) and math.isfinite(float(value)):
        return int(value)
    return 0


def _format_number(value: Any) -> str:
    number = _finite_number(value)
    return "unavailable" if number is None else f"{number:.8g}"


def _format_bytes(value: Any) -> str:
    number = _finite_number(value)
    if number is None or number < 0.0:
        return "unavailable"
    units = ("B", "KiB", "MiB", "GiB", "TiB")
    unit_index = 0
    while number >= 1024.0 and unit_index < len(units) - 1:
        number /= 1024.0
        unit_index += 1
    precision = 0 if unit_index == 0 else 2
    return f"{number:.{precision}f} {units[unit_index]}"


def _format_duration(value: Any) -> str:
    seconds = _finite_number(value)
    if seconds is None or seconds < 0.0:
        return "unavailable"
    if seconds < 0.001:
        return f"{seconds * 1_000_000:.2f} us"
    if seconds < 1.0:
        return f"{seconds * 1000:.2f} ms"
    return f"{seconds:.3f} s"


def _short_hash(value: Any) -> str:
    text = "" if value is None else str(value)
    return _text(text if len(text) <= 16 else f"{text[:12]}...")


def _humanize(value: str) -> str:
    return value.replace("_", " ").strip().capitalize()


def _stage_label(stage: str) -> str:
    return {
        "design": "Design",
        "validate": "Validate",
        "plan": "Plan / compile",
        "execute": "Execute",
        "state": "State / noise",
        "measure": "Measure",
        "analyze": "Analyze / compare",
    }.get(stage, _humanize(stage))


def _text(value: Any) -> str:
    return escape(str(value), quote=False)


def _attr(value: Any) -> str:
    return escape(str(value), quote=True)


_STYLES = """
:root{color-scheme:light dark;--bg:#f4f6f5;--surface:#ffffff;--surface-soft:#edf1ef;--text:#19201d;--muted:#5c6963;--border:#cbd3cf;--accent:#087f8c;--accent-soft:#d9eff1;--success:#19724b;--success-soft:#dff1e7;--warning:#a35d00;--warning-soft:#fff0d6;--danger:#b33a3a;--danger-soft:#f9dddd;--series-1:#087f8c;--series-2:#b35900;--series-3:#4772b3;--series-4:#8a4f9e;--series-5:#22805f;--series-6:#bd3f6a;font-family:Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;font-size:16px;letter-spacing:0}
@media(prefers-color-scheme:dark){:root{--bg:#111512;--surface:#1a201c;--surface-soft:#242c27;--text:#edf3ef;--muted:#aebbb4;--border:#3b4740;--accent:#58c4cd;--accent-soft:#17383b;--success:#70c99b;--success-soft:#18382a;--warning:#f1b85d;--warning-soft:#3b2b13;--danger:#ef8c8c;--danger-soft:#442020;--series-1:#58c4cd;--series-2:#f1a75d;--series-3:#82a8e1;--series-4:#c594d2;--series-5:#70c99b;--series-6:#e37ba4}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text)}.report-shell{max-width:1180px;margin:0 auto;background:var(--surface)}.report-header{padding:40px clamp(20px,5vw,64px) 30px;border-bottom:1px solid var(--border)}.report-kicker{color:var(--accent);font-size:.8rem;font-weight:500;text-transform:uppercase}.report-title-row{display:flex;align-items:flex-start;justify-content:space-between;gap:24px;margin-top:8px}.report-title-row h1{font-size:2rem;line-height:1.2;margin:0;font-weight:500}.report-title-row p{color:var(--muted);margin:8px 0 0}.header-status{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.profile-badge,.status-badge{display:inline-flex;align-items:center;min-height:26px;padding:3px 9px;border-radius:999px;border:1px solid var(--border);font-size:.78rem;font-weight:500}.profile-badge{background:var(--accent-soft);color:var(--text);border-color:var(--accent)}.status-available,.status-completed,.status-ok,.status-passed{background:var(--success-soft);color:var(--success);border-color:var(--success)}.status-warning,.status-partial-failed,.status-partially-completed,.status-running,.status-submitted,.status-cancelled{background:var(--warning-soft);color:var(--warning);border-color:var(--warning)}.status-error,.status-failed{background:var(--danger-soft);color:var(--danger);border-color:var(--danger)}.status-unavailable,.status-neutral{background:var(--surface-soft);color:var(--muted)}.report-summary{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:1px;background:var(--border);border:1px solid var(--border);margin-top:28px}.report-summary>div{background:var(--surface);padding:14px;min-width:0}.report-summary span{display:block;color:var(--muted);font-size:.78rem;margin-bottom:5px}.report-summary strong{font-weight:500}.report-summary code{display:block;overflow-wrap:anywhere;font-size:.72rem}.lifecycle{display:grid;grid-template-columns:repeat(7,minmax(0,1fr));border-bottom:1px solid var(--border);background:var(--surface-soft);padding:0 clamp(12px,3vw,36px)}.lifecycle a{color:var(--text);text-decoration:none;padding:13px 8px;font-size:.72rem;text-align:center;border-bottom:3px solid transparent}.lifecycle a:hover,.lifecycle a:focus{border-bottom-color:var(--accent)}.lifecycle a span{display:block;color:var(--muted);margin-bottom:2px}.stage-section,.source-index{padding:34px clamp(20px,5vw,64px);border-bottom:1px solid var(--border);scroll-margin-top:12px}.stage-heading{display:grid;grid-template-columns:42px 1fr auto;align-items:start;gap:14px;margin-bottom:24px}.stage-index{color:var(--accent);font-variant-numeric:tabular-nums;font-weight:500}.stage-name{color:var(--muted);font-size:.75rem;text-transform:uppercase}.stage-heading h2,.source-index h2{font-size:1.25rem;margin:3px 0 0;font-weight:500}.visual-group{margin:26px 0}.visual-group h3,.diagnostics h3,.evidence h3{font-size:1rem;font-weight:500;margin:0 0 12px}.domain-summary{display:flex;flex-wrap:wrap;gap:10px 24px;padding:13px 0;border-top:1px solid var(--border);border-bottom:1px solid var(--border);margin:12px 0 22px}.domain-summary span{color:var(--muted)}.domain-summary strong{color:var(--text);font-weight:500;margin-right:5px}.algorithm-columns{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:28px;align-items:start}.algorithm-columns>*{min-width:0}.experiment-block{padding:18px 0;border-top:1px solid var(--border)}.block-label{font-size:.82rem;color:var(--muted);margin-bottom:16px}.plot-frame{max-width:100%;overflow:hidden}.plot-frame svg{display:block;width:100%;height:auto;max-height:390px}.bokeh-plot{width:100%;max-width:100%;overflow:hidden}.bokeh-register{min-height:380px}.bokeh-pulse{min-height:570px}.bokeh-counts{min-height:360px}.bokeh-trend{min-height:340px}.bokeh-objective{min-height:360px}.bokeh-problem-metrics{min-height:340px}.bokeh-parameters{min-height:360px}.bokeh-problem-comparison{min-height:380px}.axis{stroke:var(--border);stroke-width:1}.register-plot text,.pulse-plot text,.trend-plot text{fill:var(--muted);font-size:12px}.atom{stroke-width:2}.atom.filled{fill:var(--accent);stroke:var(--text)}.atom.empty{fill:var(--surface);stroke:var(--muted)}.legend{display:flex;flex-wrap:wrap;gap:10px 20px;color:var(--muted);font-size:.8rem;margin-top:8px}.legend span{display:inline-flex;align-items:center;gap:6px}.legend i,.legend-dot{display:inline-block;width:10px;height:10px;border-radius:50%;background:var(--muted)}.legend-dot.filled{background:var(--accent)}.legend-dot.empty{background:var(--surface);border:1px solid var(--muted)}.pulse-stack{display:grid;gap:18px}.pulse-row{border-top:1px solid var(--border);padding-top:14px}.pulse-meta{display:flex;flex-wrap:wrap;gap:5px 18px;align-items:baseline;margin-bottom:4px}.pulse-meta strong{font-weight:500}.pulse-meta span{color:var(--muted);font-size:.8rem}.pulse-plot polyline,.trend-plot polyline{fill:none;stroke:var(--accent);stroke-width:2}.pulse-plot circle{fill:var(--accent)}.table-wrap{max-width:100%;overflow-x:auto;margin:14px 0 22px}table{width:100%;border-collapse:collapse;font-size:.86rem}th{text-align:left;color:var(--muted);font-weight:500;background:var(--surface-soft)}th,td{padding:10px 12px;border-bottom:1px solid var(--border);vertical-align:top;overflow-wrap:anywhere}code{font-family:"SFMono-Regular",Consolas,monospace;font-size:.82em;overflow-wrap:anywhere}.status-counts{display:grid;grid-template-columns:repeat(auto-fit,minmax(110px,1fr));gap:1px;background:var(--border);border:1px solid var(--border);margin:16px 0}.status-counts div{background:var(--surface);padding:12px}.status-counts span{display:block;color:var(--muted);font-size:.75rem}.status-counts strong{display:block;font-size:1.25rem;font-weight:500;margin-top:3px}.histogram{display:grid;gap:8px}.histogram-row{display:grid;grid-template-columns:minmax(54px,auto) minmax(100px,1fr) minmax(90px,auto);gap:10px;align-items:center}.histogram-row>span{text-align:right;color:var(--muted);font-variant-numeric:tabular-nums}.bar-track{height:14px;background:var(--surface-soft);border:1px solid var(--border)}.bar-fill{height:100%;background:var(--accent)}.unavailable-block{border-left:4px solid var(--muted);background:var(--surface-soft);padding:16px 18px}.unavailable-block strong{font-weight:500}.unavailable-block p{color:var(--muted);margin:6px 0 0}.empty-note,.context-note{color:var(--muted);font-size:.86rem}.diagnostics{margin-top:24px}.evidence{margin-top:28px;border-top:1px solid var(--border);padding-top:15px}.evidence summary{cursor:pointer;color:var(--muted);font-size:.84rem}.fact-list{margin:16px 0 0}.fact-row{display:grid;grid-template-columns:minmax(130px,220px) 1fr;gap:16px;padding:8px 0;border-bottom:1px solid var(--border)}.fact-row dt{color:var(--muted)}.fact-row dd{margin:0;min-width:0;overflow-wrap:anywhere}.value-list{margin:0;padding-left:20px}.value-list li{padding:3px 0}.source-paths{padding-left:20px}.muted{color:var(--muted)}.comparison-source{padding:14px 0;border-top:1px solid var(--border)}.comparison-source h3{font-size:1rem;font-weight:500}.source-index h2{margin-bottom:18px}footer{padding:24px clamp(20px,5vw,64px);color:var(--muted);font-size:.78rem;background:var(--surface-soft)}
.report-topline{display:flex;align-items:center;justify-content:space-between;gap:18px}.language-control{display:flex;align-items:center;gap:8px;color:var(--muted);font-size:.78rem}.language-control select{min-height:32px;padding:4px 30px 4px 9px;border:1px solid var(--border);border-radius:4px;background:var(--surface);color:var(--text);font:inherit}
.atom.status-filled{fill:var(--accent);stroke:var(--text)}.atom.status-vacant{fill:var(--surface);stroke:var(--muted)}.atom.status-defect{fill:#dc2626;stroke:#7f1d1d}.atom.status-loading_failed{fill:#d97706;stroke:#78350f}.legend-dot.status-filled{background:var(--accent)}.legend-dot.status-vacant{background:var(--surface);border:1px solid var(--muted)}.legend-dot.status-defect{background:#dc2626}.legend-dot.status-loading_failed{background:#d97706}
.fact-list,.fact-row,.fact-row dt,.fact-row dd,.value-list,.value-list li,.source-paths{min-width:0;max-width:100%}.fact-row{grid-template-columns:minmax(130px,220px) minmax(0,1fr)}.fact-row dt,.value-list li,.source-paths li,.source-paths code{overflow-wrap:anywhere;word-break:break-word}
.fact-row .fact-row{grid-template-columns:minmax(0,1fr);gap:4px}
.domain-summary>*{min-width:0;max-width:100%;overflow-wrap:anywhere;word-break:break-word}
.report-shell{width:100%;max-width:none;margin:0}.analog-visual-grid{display:grid;grid-template-columns:minmax(320px,.8fr) minmax(500px,1.2fr);gap:32px;align-items:start}.analog-visual-grid>.visual-group{min-width:0;margin-top:12px}.bokeh-pulse{min-height:400px}
.problem-grid,.design-duo{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:32px;align-items:start}.problem-grid>*,.design-duo>*{min-width:0}.problem-native{margin-top:30px;padding-top:24px;border-top:1px solid var(--border)}
.circuit-scroll{max-width:100%;overflow-x:auto;border:1px solid var(--border);background:var(--surface-soft)}.circuit-diagram{display:block;min-width:100%;height:auto}.circuit-wire,.circuit-link{stroke:var(--muted);stroke-width:1.5}.circuit-control{fill:var(--text)}.circuit-target,.circuit-gate,.circuit-measure{fill:var(--surface);stroke:var(--accent);stroke-width:2}.circuit-target-mark{stroke:var(--accent);stroke-width:2}.circuit-label{fill:var(--text);font-size:12px}.circuit-gate-label{fill:var(--text);font-size:11px;text-anchor:middle;font-weight:600}
@media(max-width:960px){.analog-visual-grid,.problem-grid,.design-duo{grid-template-columns:minmax(0,1fr);gap:12px}}
@media(max-width:780px){.report-title-row{display:block}.header-status{margin-top:16px}.report-summary{grid-template-columns:repeat(2,minmax(0,1fr))}.lifecycle{grid-template-columns:repeat(4,minmax(0,1fr))}.stage-heading{grid-template-columns:32px 1fr}.stage-heading>.status-badge{grid-column:2;justify-self:start}.algorithm-columns{grid-template-columns:minmax(0,1fr);gap:8px}.fact-row{grid-template-columns:1fr;gap:4px}.histogram-row{grid-template-columns:52px 1fr}.histogram-row>span{grid-column:2}}
@media(max-width:430px){.report-topline{align-items:flex-start;flex-direction:column}.report-header,.stage-section,.source-index{padding-left:16px;padding-right:16px}.report-title-row h1{font-size:1.55rem}.report-summary{grid-template-columns:1fr}.lifecycle{grid-template-columns:repeat(2,minmax(0,1fr));padding:0 8px}.stage-heading{gap:8px}.domain-summary{display:grid;gap:8px}.pulse-meta{display:grid}.histogram-row{grid-template-columns:44px 1fr;gap:7px}th,td{padding:8px}.profile-badge,.status-badge{font-size:.72rem}}
"""
