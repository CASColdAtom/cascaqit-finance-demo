"""Standard report for the paired VQE sampling-strategy benchmark."""

from __future__ import annotations

from dataclasses import replace
from typing import Any

from cascaqit.algorithms.vqe_sampling_benchmark import VQESamplingBenchmarkResult
from cascaqit.visualization.algorithm_report import build_algorithm_experiment_report
from cascaqit.visualization.experiment import ExperimentReportIR

__all__ = ["build_vqe_sampling_benchmark_report"]


def build_vqe_sampling_benchmark_report(
    source: VQESamplingBenchmarkResult,
    *,
    title: str = "VQE sampling strategy benchmark",
) -> ExperimentReportIR:
    """Render saved paired runs without invoking a Backend or optimizer."""
    if not isinstance(source, VQESamplingBenchmarkResult):
        raise TypeError("source must be VQESamplingBenchmarkResult.")
    snapshot = source.to_dict()
    exact_reference = source.runs[0].result
    report = build_algorithm_experiment_report(
        exact_reference,
        report_id=(
            "algorithm_report.vqe-sampling-benchmark."
            f"{source.benchmark_id.rsplit('.', 1)[-1]}"
        ),
        title=title,
    )
    payload = _benchmark_payload(source)
    source_paths = (
        "VQESamplingBenchmarkResult.config",
        "VQESamplingBenchmarkResult.runs",
        "VQESamplingBenchmarkResult.statistics",
    )
    sections = []
    for section in report.sections:
        section_payload = dict(section.payload)
        if section.section_id == "algorithm.validate":
            checks = list(section_payload.get("checks", ()))
            checks.extend(
                (
                    {
                        "name": "Complete paired strategy matrix",
                        "status": "passed",
                        "value": len(source.runs),
                    },
                    {
                        "name": "Independent exact diagnostics",
                        "status": "passed",
                        "value": sum(
                            run.exact_check is not None for run in source.runs
                        ),
                    },
                    {
                        "name": "Optimality and advantage claims",
                        "status": "passed",
                        "value": "not_claimed",
                    },
                )
            )
            section_payload["checks"] = checks
        elif section.section_id == "algorithm.plan":
            section_payload["vqe_sampling_benchmark"] = payload["configuration"]
        elif section.section_id == "algorithm.execute":
            section_payload["vqe_sampling_benchmark"] = {
                "runs": payload["runs"],
                "cost_totals": payload["cost_totals"],
            }
        elif section.section_id == "algorithm.analyze":
            section_payload["vqe_sampling_benchmark"] = payload
        sections.append(
            replace(
                section,
                payload=section_payload,
                source_paths=(*section.source_paths, *source_paths),
            )
        )
    result = replace(
        report,
        source_kind="VQESamplingBenchmark",
        source_ids=(source.benchmark_id,),
        source_hashes={source.benchmark_id: source.stable_hash()},
        sections=tuple(sections),
        metadata={
            **report.metadata,
            "benchmark_id": source.benchmark_id,
            "repeat_count": source.config.repeats,
            "strategy_count": len(source.statistics),
            "backend_called": False,
            "optimizer_called": False,
        },
    )
    if source.to_dict() != snapshot:
        raise ValueError("VQE sampling benchmark report mutated its source result.")
    return result


def _benchmark_payload(source: VQESamplingBenchmarkResult) -> dict[str, Any]:
    config = source.config
    runs = [
        {
            "run_id": run.run_id,
            "strategy": run.strategy,
            "repeat_index": run.repeat_index,
            "paired_seed": run.paired_seed,
            "selected_estimator_energy": run.selected_estimator_energy,
            "exact_selected_energy": run.exact_selected_energy,
            "exact_reference_energy": run.exact_reference_energy,
            "estimator_error": run.estimator_error,
            "paired_exact_reference_gap": run.paired_exact_reference_gap,
            "objective_evaluation_count": run.objective_evaluation_count,
            "objective_backend_execution_count": (
                run.objective_backend_execution_count
            ),
            "objective_shots": run.objective_shots,
            "confirmation_backend_execution_count": (
                run.confirmation_backend_execution_count
            ),
            "confirmation_shots": run.confirmation_shots,
            "final_sampling_backend_execution_count": (
                run.final_sampling_backend_execution_count
            ),
            "final_sampling_shots": run.final_sampling_shots,
            "diagnostic_exact_backend_execution_count": (
                run.diagnostic_exact_backend_execution_count
            ),
            "objective_budget_utilization": run.objective_budget_utilization,
            "result_hash": run.result.stable_hash(),
            "exact_check_result_id": (
                None if run.exact_check is None else run.exact_check.result_id
            ),
        }
        for run in source.runs
    ]
    statistics = [
        {
            key: value
            for key, value in item.to_dict().items()
            if key not in {"runs", "schema_version"}
        }
        for item in source.statistics
    ]
    return {
        "benchmark_id": source.benchmark_id,
        "algorithm_id": source.algorithm_id,
        "hamiltonian_hash": source.hamiltonian_hash,
        "ansatz_hash": source.ansatz_hash,
        "logical_order": list(source.logical_order),
        "configuration": {
            "repeats": config.repeats,
            "objective_evaluation_budget": config.objective_evaluation_budget,
            "optimizer": config.optimizer.to_dict(),
            "measurement": config.measurement.to_dict(),
            "sampled_selection": config.sampled_selection.to_dict(),
            "fixed_objective_repeats": config.fixed_objective_repeats,
            "adaptive_objective_repeats": config.adaptive_objective_repeats,
            "adaptive_max_objective_repeats": (config.adaptive_max_objective_repeats),
            "adaptive_standard_error_target": (config.adaptive_standard_error_target),
            "final_shots": config.final_shots,
            "confidence_level": config.confidence_level,
            "root_seed": config.root_seed,
            "comparison_boundary": (
                "Exact is a paired same-Ansatz reference, not a ground-state, "
                "global-optimum, or quantum-advantage claim."
            ),
        },
        "runs": runs,
        "statistics": statistics,
        "cost_totals": {
            "objective_backend_executions": sum(
                run.objective_backend_execution_count for run in source.runs
            ),
            "confirmation_backend_executions": sum(
                run.confirmation_backend_execution_count for run in source.runs
            ),
            "final_sampling_backend_executions": sum(
                run.final_sampling_backend_execution_count for run in source.runs
            ),
            "diagnostic_exact_backend_executions": sum(
                run.diagnostic_exact_backend_execution_count for run in source.runs
            ),
            "objective_shots": sum(run.objective_shots for run in source.runs),
            "confirmation_shots": sum(run.confirmation_shots for run in source.runs),
            "final_sampling_shots": sum(
                run.final_sampling_shots for run in source.runs
            ),
        },
        "optimality_claim": source.optimality_claim,
        "quantum_advantage_claim": "not_claimed",
    }
