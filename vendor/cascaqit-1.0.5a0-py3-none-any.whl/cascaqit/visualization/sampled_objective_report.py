"""Standard report for one finite-shot VQE objective evaluation."""

from __future__ import annotations

from cascaqit.algorithms import SampledObjectiveEvaluationIR
from cascaqit.visualization.experiment import ExperimentReportIR, ExperimentSectionIR
from cascaqit.visualization.noisy_optimization_report import (
    build_sampled_objective_execution_payload,
    build_sampled_objective_request_payload,
)

__all__ = ["build_sampled_objective_experiment_report"]

_NORMAL_95_Z = 1.959963984540054


def build_sampled_objective_experiment_report(
    source: SampledObjectiveEvaluationIR,
    *,
    report_id: str | None = None,
    title: str | None = None,
) -> ExperimentReportIR:
    """Build seven lifecycle views from saved measurement evidence only."""
    if not isinstance(source, SampledObjectiveEvaluationIR):
        raise TypeError("source must be SampledObjectiveEvaluationIR.")
    before = source.to_dict()
    plan = source.plan
    terms = sorted(
        (term for group in plan.groups for term in group.terms),
        key=lambda term: term.term_index,
    )
    observable_batch = source.observable_batch
    observable_by_name = {item.name: item for item in observable_batch.items}
    confidence_radius = _NORMAL_95_Z * source.energy_standard_error

    pooled_groups = source.pooled_group_statistics
    mitigated_groups = {
        item.group_index: item for item in source.mitigated_group_statistics
    }
    raw_term_errors = {
        term_id: error
        for group in pooled_groups
        for term_id, error in group.term_standard_errors.items()
    }
    mitigated_term_errors = {
        term_id: error
        for group in source.mitigated_group_statistics
        for term_id, error in group.term_standard_errors.items()
    }
    adaptive = source.adaptive_allocation
    objective_request = build_sampled_objective_request_payload(source)
    objective_execution = build_sampled_objective_execution_payload(source)
    sections = (
        ExperimentSectionIR(
            section_id="sampled_objective.design",
            stage="design",
            title="Hamiltonian and source Circuit",
            status="available",
            payload={
                "algorithm_kind": "vqe_sampled_fixed_point",
                "hamiltonian": {
                    "hamiltonian_id": plan.hamiltonian_id,
                    "hash": plan.hamiltonian_hash,
                    "constant": plan.constant,
                    "logical_order": list(plan.logical_order),
                    "term_count": len(terms),
                    "terms": [
                        {
                            "term_index": term.term_index,
                            "term_id": term.term_id,
                            "coefficient": term.coefficient,
                            "observable_name": term.observable.name,
                            "targets": list(term.observable.targets),
                            "bases": [basis.value for basis in term.observable.bases],
                        }
                        for term in terms
                    ],
                },
                "ansatz": {
                    "ansatz_kind": "source_circuit",
                    "logical_order": list(plan.logical_order),
                    "parameter_names": list(source.parameter_bind.values),
                    "circuit_hash": plan.source_circuit_hash,
                },
            },
            source_paths=(
                "SampledObjectiveEvaluationIR.plan.hamiltonian_hash",
                "SampledObjectiveEvaluationIR.plan.groups",
                "SampledObjectiveEvaluationIR.plan.source_circuit_hash",
                "SampledObjectiveEvaluationIR.parameter_bind.values",
            ),
        ),
        ExperimentSectionIR(
            section_id="sampled_objective.validate",
            stage="validate",
            title="Measurement evidence consistency",
            status="available",
            payload={
                "checks": [
                    {
                        "name": "Hamiltonian term partition",
                        "status": "passed",
                        "value": [term.term_index for term in terms],
                    },
                    {
                        "name": "Measurement group coverage",
                        "status": "passed",
                        "value": len(plan.groups),
                    },
                    {
                        "name": "Counts and shots",
                        "status": "passed",
                        "value": source.total_shots,
                    },
                    {
                        "name": "Backend Result coverage",
                        "status": "passed",
                        "value": len(source.result_ids),
                    },
                    {
                        "name": "Count-derived statistics",
                        "status": "passed",
                        "value": source.energy,
                    },
                ],
            },
            source_paths=(
                "SampledObjectiveEvaluationIR.plan.plan_hash",
                "SampledObjectiveEvaluationIR.group_results",
                "SampledObjectiveEvaluationIR.energy",
            ),
        ),
        ExperimentSectionIR(
            section_id="sampled_objective.plan",
            stage="plan",
            title="QWC measurement plan",
            status="available",
            payload={
                "plan_id": plan.plan_id,
                "plan_hash": plan.plan_hash,
                "grouping": plan.config.grouping,
                "allocation": plan.config.allocation,
                "shots_per_group": plan.config.shots_per_group,
                "pilot_shots_per_group": plan.config.pilot_shots_per_group,
                "shots_by_group": list(plan.shots_by_group),
                "final_shots_by_group": list(source.final_shots_by_group),
                "adaptive_allocation": (
                    None if adaptive is None else adaptive.to_dict()
                ),
                "total_shots": plan.total_shots,
                "backend_execution_count": plan.backend_execution_count,
                "required_gates": list(plan.required_gates),
                "resolved_seed": source.metadata.get("root_seed"),
                "parameter_bind": source.parameter_bind.to_dict(),
                "objective_request": objective_request,
                "groups": [
                    {
                        "group_index": group.group_index,
                        "basis_by_target": {
                            target: basis.value
                            for target, basis in group.basis_by_target.items()
                        },
                        "term_ids": [term.term_id for term in group.terms],
                        "term_indices": list(group.term_indices),
                        "shots": plan.shots_by_group[group.group_index],
                        "final_shots": source.final_shots_by_group[
                            group.group_index
                        ],
                    }
                    for group in plan.groups
                ],
            },
            source_paths=(
                "SampledObjectiveEvaluationIR.plan",
                "SampledObjectiveEvaluationIR.parameter_bind",
                "SampledObjectiveEvaluationIR.metadata.root_seed",
            ),
        ),
        ExperimentSectionIR(
            section_id="sampled_objective.execute",
            stage="execute",
            title="Measurement group execution",
            status="available",
            payload={
                "evaluation_id": source.evaluation_id,
                "evaluation_index": source.evaluation_index,
                "evaluation_count": 1,
                "backend_result_count": len(source.result_ids),
                "backend_execution_count": source.backend_execution_count,
                "total_wall_time_seconds": source.wall_time_seconds,
                "parameters": dict(source.parameter_bind.values),
                "objective_execution": objective_execution,
                "group_executions": [
                    {
                        "group_index": item.group.group_index,
                        "stage": (
                            "static"
                            if adaptive is None
                            else (
                                "pilot"
                                if index < len(source.group_results)
                                else "adaptive"
                            )
                        ),
                        "seed": item.seed,
                        "shots": item.shots,
                        "backend_id": item.backend_id,
                        "backend_job_id": item.backend_job_id,
                        "result_id": item.result_id,
                        "result_hash": item.result_hash,
                        "program_hash": item.program_hash,
                        "wall_time_seconds": item.wall_time_seconds,
                    }
                    for index, item in enumerate(source.all_group_results)
                ],
            },
            source_paths=(
                "SampledObjectiveEvaluationIR.group_results",
                "SampledObjectiveEvaluationIR.wall_time_seconds",
            ),
        ),
        ExperimentSectionIR(
            section_id="sampled_objective.state",
            stage="state",
            title="Pauli expectations and energy contributions",
            status="available",
            payload={
                "estimator": source.estimator_kind,
                "source_kind": observable_batch.source_kind.value,
                "observable_source_hash": source.measurement_source_hash,
                "contributions": [
                    {
                        **contribution.to_dict(),
                        "standard_error": observable_by_name[
                            contribution.observable_name
                        ].standard_error,
                    }
                    for contribution in source.contributions
                ],
                "raw_contributions": [
                    {
                        **contribution.to_dict(),
                        "standard_error": raw_term_errors[contribution.term_id],
                    }
                    for contribution in source.raw_contributions
                ],
                "mitigated_contributions": [
                    {
                        **contribution.to_dict(),
                        "standard_error": mitigated_term_errors[
                            contribution.term_id
                        ],
                    }
                    for contribution in source.mitigated_contributions
                ],
                "observable_standard_errors": {
                    item.name: item.standard_error for item in observable_batch.items
                },
            },
            source_paths=(
                "SampledObjectiveEvaluationIR.contributions",
                "SampledObjectiveEvaluationIR.raw_contributions",
                "SampledObjectiveEvaluationIR.mitigated_contributions",
                "SampledObjectiveEvaluationIR.observable_batch",
                "SampledObjectiveEvaluationIR.measurement_source_hash",
            ),
        ),
        ExperimentSectionIR(
            section_id="sampled_objective.measure",
            stage="measure",
            title="Grouped counts and covariance-aware uncertainty",
            status="available",
            payload={
                "total_shots": source.total_shots,
                "allocation": plan.config.allocation,
                "shots_per_group": plan.config.shots_per_group,
                "shots_by_group": list(source.final_shots_by_group),
                "pilot_shots_by_group": (
                    None if adaptive is None else list(adaptive.pilot_shots_by_group)
                ),
                "additional_shots_by_group": (
                    None
                    if adaptive is None
                    else list(adaptive.additional_shots_by_group)
                ),
                "allocation_weights": (
                    None if adaptive is None else list(adaptive.allocation_weights)
                ),
                "allocation_fallback": (
                    None if adaptive is None else adaptive.fallback
                ),
                "groups": [
                    {
                        "group_index": group.group_index,
                        "basis_by_target": {
                            target: basis.value
                            for target, basis in group.basis_by_target.items()
                        },
                        "term_ids": [term.term_id for term in group.terms],
                        "shots": estimate.shots,
                        "counts": dict(estimate.counts),
                        "term_expectations": dict(estimate.term_expectations),
                        "term_standard_errors": dict(
                            estimate.term_standard_errors
                        ),
                        "energy_mean": estimate.energy_mean,
                        "energy_standard_error": estimate.energy_standard_error,
                        "raw_statistics": {
                            "energy_mean": estimate.energy_mean,
                            "energy_standard_error": estimate.energy_standard_error,
                            "term_expectations": dict(estimate.term_expectations),
                            "term_standard_errors": dict(
                                estimate.term_standard_errors
                            ),
                        },
                        "mitigated_statistics": (
                            None
                            if group.group_index not in mitigated_groups
                            else mitigated_groups[group.group_index].to_dict()
                        ),
                        "seeds": [
                            item.seed
                            for item in source.all_group_results
                            if item.group.group_index == group.group_index
                        ],
                        "result_ids": [
                            item.result_id
                            for item in source.all_group_results
                            if item.group.group_index == group.group_index
                        ],
                    }
                    for group, estimate in zip(plan.groups, pooled_groups)
                ],
            },
            source_paths=(
                "SampledObjectiveEvaluationIR.group_results.counts",
                "SampledObjectiveEvaluationIR.group_results.term_expectations",
                "SampledObjectiveEvaluationIR.group_results.energy_standard_error",
                "SampledObjectiveEvaluationIR.mitigated_group_statistics",
            ),
        ),
        ExperimentSectionIR(
            section_id="sampled_objective.analyze",
            stage="analyze",
            title="Sampled energy estimate",
            status="available",
            payload={
                "energy": source.energy,
                "energy_standard_error": source.energy_standard_error,
                "estimator_kind": source.estimator_kind,
                "raw_energy": source.raw_energy,
                "raw_energy_standard_error": source.raw_energy_standard_error,
                "raw_confidence_interval_low": (
                    source.raw_energy
                    - _NORMAL_95_Z * source.raw_energy_standard_error
                ),
                "raw_confidence_interval_high": (
                    source.raw_energy
                    + _NORMAL_95_Z * source.raw_energy_standard_error
                ),
                "mitigated_energy": source.mitigated_energy,
                "mitigated_energy_standard_error": (
                    source.mitigated_energy_standard_error
                ),
                "mitigated_confidence_interval_low": (
                    None
                    if source.mitigated_energy is None
                    or source.mitigated_energy_standard_error is None
                    else source.mitigated_energy
                    - _NORMAL_95_Z * source.mitigated_energy_standard_error
                ),
                "mitigated_confidence_interval_high": (
                    None
                    if source.mitigated_energy is None
                    or source.mitigated_energy_standard_error is None
                    else source.mitigated_energy
                    + _NORMAL_95_Z * source.mitigated_energy_standard_error
                ),
                "readout_mitigation": objective_request["readout_mitigation"],
                "confidence_level": 0.95,
                "confidence_interval_method": "normal_approximation",
                "confidence_interval_low": source.energy - confidence_radius,
                "confidence_interval_high": source.energy + confidence_radius,
                "constant": plan.constant,
                "group_energy_sum": sum(
                    item.energy_mean for item in pooled_groups
                ),
                "optimality_claim": "not_claimed",
                "quantum_advantage_claim": "not_claimed",
                "scope": "fixed_parameter_sampled_evaluation",
            },
            source_paths=(
                "SampledObjectiveEvaluationIR.energy",
                "SampledObjectiveEvaluationIR.energy_standard_error",
                "SampledObjectiveEvaluationIR.raw_energy",
                "SampledObjectiveEvaluationIR.mitigated_energy",
                "SampledObjectiveEvaluationIR.plan.constant",
            ),
        ),
    )
    report = ExperimentReportIR(
        report_id=report_id or f"sampled_objective_report.{source.evaluation_id}",
        title="Sampled VQE energy" if title is None else title,
        profile="algorithm",
        source_kind="SampledObjectiveEvaluation",
        source_ids=(source.evaluation_id,),
        source_hashes={source.evaluation_id: source.stable_hash()},
        sections=sections,
        metadata={
            "algorithm_kind": "vqe",
            "evaluation_scope": "fixed_parameter",
            "backend_called": False,
            "optimizer_called": False,
        },
    )
    if source.to_dict() != before:
        raise ValueError("Sampled objective report mutated its source evaluation.")
    return report
