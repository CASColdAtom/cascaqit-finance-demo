"""Standard Algorithm report for saved VQE stability diagnostics."""

from __future__ import annotations

from dataclasses import replace
from typing import Any

from cascaqit.algorithms.vqe_stability import VQEStabilityDiagnosticResult
from cascaqit.visualization.algorithm_report import build_algorithm_experiment_report
from cascaqit.visualization.experiment import ExperimentReportIR

__all__ = ["build_vqe_stability_report"]


def build_vqe_stability_report(
    source: VQEStabilityDiagnosticResult,
    *,
    title: str = "VQE stability and stopping diagnosis",
) -> ExperimentReportIR:
    """Render saved diagnostics without invoking a Backend or optimizer."""
    if not isinstance(source, VQEStabilityDiagnosticResult):
        raise TypeError("source must be VQEStabilityDiagnosticResult.")
    snapshot = source.to_dict()
    report = build_algorithm_experiment_report(
        source.source_result,
        report_id=f"algorithm_report.{source.diagnostic_id}",
        title=title,
    )
    payload = _stability_payload(source)
    source_paths = (
        "VQEStabilityDiagnosticResult.config",
        "VQEStabilityDiagnosticResult.starts",
        "VQEStabilityDiagnosticResult.status",
        "VQEStabilityDiagnosticResult.source_result",
    )
    sections = []
    for section in report.sections:
        section_payload = dict(section.payload)
        status = section.status
        if section.section_id == "algorithm.validate":
            checks = list(section_payload.get("checks", ()))
            checks.extend(
                (
                    {
                        "name": "Read-only source diagnosis",
                        "status": "passed",
                        "value": source.source_result_hash,
                    },
                    {
                        "name": "Selected-start stability evidence",
                        "status": (
                            "passed" if source.status == "stable" else "warning"
                        ),
                        "value": source.status,
                    },
                    {
                        "name": "Optimality and convergence claims",
                        "status": "passed",
                        "value": "not_claimed",
                    },
                )
            )
            section_payload["checks"] = checks
        elif section.section_id == "algorithm.plan":
            section_payload["vqe_stability"] = payload["configuration"]
        elif section.section_id == "algorithm.execute":
            section_payload["vqe_stability"] = {
                "diagnostic_id": source.diagnostic_id,
                "selected_start_index": source.selected_start_index,
                "status": source.status,
                "starts": payload["starts"],
            }
        elif section.section_id == "algorithm.analyze":
            section_payload["vqe_stability"] = payload
            if source.status != "stable":
                status = "warning"
        sections.append(
            replace(
                section,
                status=status,
                payload=section_payload,
                source_paths=(*section.source_paths, *source_paths),
            )
        )
    result = replace(
        report,
        source_kind="VQEStabilityDiagnostic",
        source_ids=(source.diagnostic_id,),
        source_hashes={source.diagnostic_id: source.stable_hash()},
        sections=tuple(sections),
        metadata={
            **report.metadata,
            "diagnostic_id": source.diagnostic_id,
            "stability_status": source.status,
            "source_result_hash": source.source_result_hash,
            "backend_called": False,
            "optimizer_called": False,
            "optimality_claim": "not_claimed",
            "convergence_claim": "not_claimed",
        },
    )
    if source.to_dict() != snapshot:
        raise ValueError("VQE stability report mutated its source diagnosis.")
    return result


def _stability_payload(source: VQEStabilityDiagnosticResult) -> dict[str, Any]:
    starts = []
    for start in source.starts:
        starts.append(
            {
                "start_index": start.start_index,
                "selected": start.selected,
                "evaluator_kind": start.evaluator_kind,
                "status": start.status,
                "iteration_count": start.iteration_count,
                "window_iteration_indices": list(start.window_iteration_indices),
                "objective_proxy_values": list(start.objective_proxy_values),
                "objective_window_values": list(start.objective_window_values),
                "update_norm_window": list(start.update_norm_window),
                "gradient_norm_window": list(start.gradient_norm_window),
                "sampled_standard_errors": list(start.sampled_standard_errors),
                "sampled_repeat_counts": list(start.sampled_repeat_counts),
                "sampled_repeat_stop_reasons": list(
                    start.sampled_repeat_stop_reasons
                ),
                "checks": [item.to_dict() for item in start.checks],
                "termination": start.termination.to_dict(),
                "evaluation_count": start.evaluation_count,
                "backend_execution_count": start.backend_execution_count,
                "max_evaluations": start.max_evaluations,
                "max_backend_executions": start.max_backend_executions,
                "source_start_hash": start.source_start_hash,
            }
        )
    return {
        "diagnostic_id": source.diagnostic_id,
        "source_result_hash": source.source_result_hash,
        "status": source.status,
        "selected_start_index": source.selected_start_index,
        "configuration": source.config.to_dict(),
        "starts": starts,
        "optimality_claim": source.optimality_claim,
        "convergence_claim": source.convergence_claim,
        "interpretation_boundary": (
            "Stable means the selected terminal window satisfies configured "
            "engineering thresholds. It is not a ground-state, global-optimum, "
            "strict-convergence, or quantum-advantage claim."
        ),
    }
