"""Visualization data contracts for offline plotting helpers."""

from __future__ import annotations

from cascaqit.visualization.algorithm_report import build_algorithm_experiment_report
from cascaqit.visualization.api import ExperimentReport, visualize
from cascaqit.visualization.comparison_report import (
    build_comparison_experiment_report,
)
from cascaqit.visualization.experiment import (
    EXPERIMENT_STAGE_ORDER,
    ExperimentProfile,
    ExperimentReportIR,
    ExperimentSectionIR,
    ExperimentSectionStatus,
    ExperimentStage,
    unavailable_experiment_section,
)
from cascaqit.visualization.gradient_report import build_gradient_experiment_report
from cascaqit.visualization.html_report import render_experiment_report_html
from cascaqit.visualization.models import (
    CountsHistogramVisualizationIR,
    HybridTimelineReportSectionIR,
    HybridTimelineVisualizationIR,
    PulseTimelineVisualizationIR,
    RegisterVisualizationIR,
    VisualizationSpecIR,
    build_counts_histogram,
    build_hybrid_timeline_report_section,
    build_hybrid_timeline_visualization,
    build_pulse_timeline,
    build_register_visualization,
)
from cascaqit.visualization.problem_layer_experiment_report import (
    build_problem_layer_experiment_report,
)
from cascaqit.visualization.problem_repeated_layer_experiment_report import (
    build_problem_repeated_layer_experiment_report,
)
from cascaqit.visualization.problem_report import build_problem_experiment_report
from cascaqit.visualization.renderers import (
    VisualizationArtifactIR,
    render_counts_histogram_bokeh,
    render_counts_histogram_html,
    render_hybrid_timeline_bokeh,
    render_hybrid_timeline_html,
    render_pulse_timeline_bokeh,
    render_pulse_timeline_html,
    render_register_bokeh,
    render_register_svg,
    render_visualization,
)
from cascaqit.visualization.result_report import build_result_experiment_report
from cascaqit.visualization.sampled_objective_report import (
    build_sampled_objective_experiment_report,
)
from cascaqit.visualization.scan_batch_report import (
    build_batch_experiment_report,
    build_sweep_experiment_report,
)
from cascaqit.visualization.vqe_repeated_layer_experiment_report import (
    build_vqe_repeated_layer_experiment_report,
)
from cascaqit.visualization.vqe_sampling_benchmark_report import (
    build_vqe_sampling_benchmark_report,
)
from cascaqit.visualization.vqe_stability_report import build_vqe_stability_report

__all__ = [
    "EXPERIMENT_STAGE_ORDER",
    "CountsHistogramVisualizationIR",
    "ExperimentProfile",
    "ExperimentReport",
    "ExperimentReportIR",
    "ExperimentSectionIR",
    "ExperimentSectionStatus",
    "ExperimentStage",
    "HybridTimelineReportSectionIR",
    "HybridTimelineVisualizationIR",
    "PulseTimelineVisualizationIR",
    "RegisterVisualizationIR",
    "VisualizationArtifactIR",
    "VisualizationSpecIR",
    "build_counts_histogram",
    "build_gradient_experiment_report",
    "build_algorithm_experiment_report",
    "build_vqe_stability_report",
    "build_batch_experiment_report",
    "build_comparison_experiment_report",
    "build_hybrid_timeline_report_section",
    "build_hybrid_timeline_visualization",
    "build_pulse_timeline",
    "build_register_visualization",
    "build_result_experiment_report",
    "build_problem_experiment_report",
    "build_problem_layer_experiment_report",
    "build_problem_repeated_layer_experiment_report",
    "build_sampled_objective_experiment_report",
    "build_sweep_experiment_report",
    "build_vqe_repeated_layer_experiment_report",
    "build_vqe_sampling_benchmark_report",
    "render_counts_histogram_bokeh",
    "render_counts_histogram_html",
    "render_experiment_report_html",
    "render_hybrid_timeline_bokeh",
    "render_hybrid_timeline_html",
    "render_pulse_timeline_bokeh",
    "render_pulse_timeline_html",
    "render_register_bokeh",
    "render_register_svg",
    "render_visualization",
    "unavailable_experiment_section",
    "visualize",
]
