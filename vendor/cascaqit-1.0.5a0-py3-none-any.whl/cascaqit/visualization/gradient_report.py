"""Standard read-only reports derived from saved parameter-shift evidence."""

from __future__ import annotations

import math
from collections.abc import Mapping, Sequence
from typing import Any

from cascaqit.algorithms import (
    ObjectiveEvaluationIR,
    ObjectiveGradientIR,
    OptimizerTerminationIR,
    SampledObjectiveEvaluationIR,
)
from cascaqit.visualization.experiment import ExperimentReportIR, ExperimentSectionIR
from cascaqit.visualization.noisy_optimization_report import (
    build_objective_request_payload,
    build_sampled_objective_request_payload,
)

__all__ = ["build_gradient_experiment_report", "build_gradient_report_payload"]


def build_gradient_report_payload(
    gradients: Sequence[ObjectiveGradientIR],
    *,
    termination: OptimizerTerminationIR | None = None,
) -> dict[str, Any] | None:
    """Summarize saved gradients without planning or executing new work."""
    if not gradients:
        return None
    first = gradients[0]
    plan = first.plan
    occurrence_by_id = {
        occurrence.occurrence_id: occurrence for occurrence in plan.occurrences
    }
    history: list[dict[str, Any]] = []
    for gradient in gradients:
        shift_evidence = []
        for pair in gradient.pooled_shift_pairs:
            occurrence = occurrence_by_id[pair.occurrence_id]
            shift_evidence.append(
                {
                    "occurrence_id": occurrence.occurrence_id,
                    "gate_index": occurrence.gate_index,
                    "gate_name": occurrence.gate_name,
                    "targets": list(occurrence.targets),
                    "affine_offset": occurrence.affine_offset,
                    "coefficients": dict(occurrence.coefficients),
                    "positive_energy": pair.positive_energy,
                    "positive_energy_standard_error": (
                        pair.positive_energy_standard_error
                    ),
                    "negative_energy": pair.negative_energy,
                    "negative_energy_standard_error": (
                        pair.negative_energy_standard_error
                    ),
                    "energy_difference": pair.energy_difference,
                    "gate_derivative": pair.gate_derivative,
                    "gate_derivative_standard_error": (
                        pair.gate_derivative_standard_error
                    ),
                    "gate_derivative_variance": pair.gate_derivative_variance,
                    "repeat_count": pair.repeat_count,
                    "source_pair_hashes": list(pair.source_pair_hashes),
                    "objective_evaluation_count": 2 * pair.repeat_count,
                    "backend_execution_count": pair.backend_execution_count,
                    "total_shots": pair.total_shots,
                }
            )
        repeat_evidence = []
        for repeat in gradient.repeats:
            repeat_evidence.append(
                {
                    "repeat_index": repeat.repeat_index,
                    "repeat_hash": repeat.repeat_hash,
                    "objective_evaluation_count": repeat.objective_evaluation_count,
                    "backend_execution_count": repeat.backend_execution_count,
                    "total_shots": repeat.total_shots,
                    "shift_pairs": [
                        {
                            "occurrence_id": pair.occurrence_id,
                            "pair_hash": pair.pair_hash,
                            "positive_evaluation_index": (
                                pair.positive_evaluation.evaluation_index
                            ),
                            "negative_evaluation_index": (
                                pair.negative_evaluation.evaluation_index
                            ),
                            "positive_energy": pair.positive_evaluation.energy,
                            "positive_energy_standard_error": (
                                _energy_standard_error(pair.positive_evaluation)
                            ),
                            "negative_energy": pair.negative_evaluation.energy,
                            "negative_energy_standard_error": (
                                _energy_standard_error(pair.negative_evaluation)
                            ),
                            "energy_difference": pair.energy_difference,
                            "gate_derivative": pair.gate_derivative,
                            "gate_derivative_variance": (
                                pair.gate_derivative_variance
                            ),
                            "gate_derivative_standard_error": (
                                pair.gate_derivative_standard_error
                            ),
                            "backend_execution_count": (
                                pair.backend_execution_count
                            ),
                            "total_shots": pair.total_shots,
                        }
                        for pair in repeat.shift_pairs
                    ],
                }
            )
        covariance = {
            name: dict(row) for name, row in gradient.gradient_covariance.items()
        }
        history.append(
            {
                "gradient_index": gradient.gradient_index,
                "gradient_id": gradient.gradient_id,
                "gradient_hash": gradient.gradient_hash,
                "parameter_bind": dict(gradient.parameter_bind.values),
                "components": dict(gradient.gradient),
                "standard_errors": dict(gradient.gradient_standard_errors),
                "uncertainty_norm": gradient.uncertainty_norm,
                "repeat_mode": gradient.config.repeat_mode,
                "minimum_repeat_count": gradient.config.repeats,
                "maximum_repeat_count": gradient.config.effective_max_repeats,
                "uncertainty_norm_target": (
                    gradient.config.uncertainty_norm_target
                ),
                "uncertainty_target_status": _uncertainty_target_status(gradient),
                "max_objective_evaluations": (
                    gradient.config.max_objective_evaluations
                ),
                "backend_execution_limit": gradient.backend_execution_limit,
                "repeat_count": gradient.repeat_count,
                "repeat_stop_reason": gradient.repeat_stop_reason,
                "covariance": covariance,
                "correlation": _correlation_matrix(covariance),
                "parameter_contributions": {
                    name: dict(contributions)
                    for name, contributions in gradient.parameter_contributions.items()
                },
                "l2_norm": gradient.l2_norm,
                "objective_evaluation_count": gradient.objective_evaluation_count,
                "backend_execution_count": gradient.backend_execution_count,
                "total_shots": gradient.total_shots,
                "repeat_evidence": repeat_evidence,
                "shift_evidence": shift_evidence,
            }
        )
    gradient_objective_count = sum(
        item.objective_evaluation_count for item in gradients
    )
    gradient_backend_count = sum(item.backend_execution_count for item in gradients)
    gradient_shots = sum(item.total_shots for item in gradients)
    return {
        "plan": {
            "method": plan.method,
            "plan_hash": plan.plan_hash,
            "source_circuit_hash": plan.source_circuit_hash,
            "hamiltonian_hash": plan.hamiltonian_hash,
            "parameter_names": list(plan.parameter_names),
            "occurrence_count": len(plan.occurrences),
            "shift": plan.shift,
            "prefactor": plan.prefactor,
            "expected_objective_evaluation_count": (
                plan.expected_objective_evaluation_count
            ),
            "occurrences": [
                {
                    "occurrence_id": item.occurrence_id,
                    "gate_index": item.gate_index,
                    "gate_name": item.gate_name,
                    "targets": list(item.targets),
                    "affine_offset": item.affine_offset,
                    "coefficients": dict(item.coefficients),
                }
                for item in plan.occurrences
            ],
            "repeat_policy": {
                "mode": first.config.repeat_mode,
                "minimum_repeat_count": first.config.repeats,
                "maximum_repeat_count": first.config.effective_max_repeats,
                "uncertainty_norm_target": first.config.uncertainty_norm_target,
                "max_objective_evaluations": (
                    first.config.max_objective_evaluations
                ),
            },
        },
        "execution_request": _gradient_execution_request(first),
        "cost": {
            # Preserve the optimizer-wide counters consumed by existing reports.
            "objective_evaluation_count": (
                gradient_objective_count if termination is None else termination.nfev
            ),
            "gradient_evaluation_count": (
                len(gradients) if termination is None else termination.njev
            ),
            "gradient_callback_count": len(gradients),
            "shift_job_count": gradient_backend_count,
            "backend_execution_count": (
                gradient_backend_count
                if termination is None
                else termination.backend_execution_count
            ),
            # These counters isolate the parameter-shift work from objective,
            # confirmation, and final sampling costs in a full workflow report.
            "gradient_objective_evaluation_count": gradient_objective_count,
            "gradient_backend_execution_count": gradient_backend_count,
            "gradient_shots": gradient_shots,
        },
        "history": history,
    }


def build_gradient_experiment_report(
    gradient: ObjectiveGradientIR,
    *,
    report_id: str | None = None,
    title: str | None = None,
) -> ExperimentReportIR:
    """Build the seven-stage fixed-parameter gradient report from one result."""
    if not isinstance(gradient, ObjectiveGradientIR):
        raise TypeError("gradient must be ObjectiveGradientIR.")
    before = gradient.to_dict()
    payload = build_gradient_report_payload((gradient,))
    assert payload is not None
    latest = payload["history"][0]
    sections = (
        ExperimentSectionIR(
            section_id="gradient.design",
            stage="design",
            title="Objective gradient design",
            status="available",
            payload={
                "gradient_id": gradient.gradient_id,
                "source_circuit_hash": gradient.plan.source_circuit_hash,
                "hamiltonian_hash": gradient.plan.hamiltonian_hash,
                "parameter_names": list(gradient.plan.parameter_names),
            },
            source_paths=("ObjectiveGradientIR.plan",),
        ),
        ExperimentSectionIR(
            section_id="gradient.validate",
            stage="validate",
            title="Gradient evidence consistency",
            status="available",
            payload={
                "checks": [
                    {"name": "Gradient hash", "status": "passed"},
                    {"name": "Plan hash", "status": "passed"},
                    {"name": "Covariance matrix", "status": "passed"},
                ]
            },
            source_paths=("ObjectiveGradientIR.gradient_hash",),
        ),
        ExperimentSectionIR(
            section_id="gradient.plan",
            stage="plan",
            title="Parameter-shift plan",
            status="available",
            payload={
                "gradient_plan": payload["plan"],
                "objective_request": payload["execution_request"],
            },
            source_paths=(
                "ObjectiveGradientIR.plan",
                "ObjectiveGradientIR.config",
                "ObjectiveGradientIR.repeats",
            ),
        ),
        ExperimentSectionIR(
            section_id="gradient.execute",
            stage="execute",
            title="Shift-pair execution",
            status="available",
            payload={"gradient": payload},
            source_paths=("ObjectiveGradientIR.repeats",),
        ),
        ExperimentSectionIR(
            section_id="gradient.state",
            stage="state",
            title="Estimator and runtime identity",
            status="available",
            payload=payload["execution_request"],
            source_paths=("ObjectiveGradientIR.repeats.shift_pairs",),
        ),
        ExperimentSectionIR(
            section_id="gradient.measure",
            stage="measure",
            title="Gradient uncertainty",
            status="available",
            payload={
                "standard_errors": latest["standard_errors"],
                "covariance": latest["covariance"],
                "correlation": latest["correlation"],
                "uncertainty_norm": latest["uncertainty_norm"],
                "uncertainty_norm_target": latest["uncertainty_norm_target"],
                "uncertainty_target_status": latest[
                    "uncertainty_target_status"
                ],
                "repeat_count": latest["repeat_count"],
                "repeat_stop_reason": latest["repeat_stop_reason"],
                "gradient_shots": payload["cost"]["gradient_shots"],
            },
            source_paths=(
                "ObjectiveGradientIR.config",
                "ObjectiveGradientIR.gradient_covariance",
                "ObjectiveGradientIR.repeat_stop_reason",
            ),
        ),
        ExperimentSectionIR(
            section_id="gradient.analyze",
            stage="analyze",
            title="Gradient result",
            status="available",
            payload={
                "components": latest["components"],
                "standard_errors": latest["standard_errors"],
                "uncertainty_norm": latest["uncertainty_norm"],
                "uncertainty_norm_target": latest["uncertainty_norm_target"],
                "uncertainty_target_status": latest[
                    "uncertainty_target_status"
                ],
                "repeat_count": latest["repeat_count"],
                "repeat_stop_reason": latest["repeat_stop_reason"],
                "l2_norm": latest["l2_norm"],
                "gradient_hash": latest["gradient_hash"],
            },
            source_paths=(
                "ObjectiveGradientIR.gradient",
                "ObjectiveGradientIR.l2_norm",
                "ObjectiveGradientIR.repeat_stop_reason",
            ),
        ),
    )
    report = ExperimentReportIR(
        report_id=report_id or f"gradient_report.{gradient.gradient_id}",
        title=title or "Fixed-parameter objective gradient",
        profile="algorithm",
        source_kind="ObjectiveGradientIR",
        source_ids=(gradient.gradient_id,),
        source_hashes={gradient.gradient_id: gradient.stable_hash()},
        sections=sections,
    )
    if gradient.to_dict() != before:
        raise ValueError("Gradient report generation mutated ObjectiveGradientIR.")
    return report


def _gradient_execution_request(gradient: ObjectiveGradientIR) -> dict[str, Any]:
    evaluation = gradient.repeats[0].shift_pairs[0].positive_evaluation
    if isinstance(evaluation, SampledObjectiveEvaluationIR):
        return build_sampled_objective_request_payload(evaluation)
    request = build_objective_request_payload(evaluation.execution_evidence)
    return {
        **request,
        "estimator_kind": evaluation.execution_evidence.estimator_kind.value,
        "measurement_kind": "exact_observable_expectation",
        "readout_mitigation": None,
    }


def _uncertainty_target_status(gradient: ObjectiveGradientIR) -> str:
    """State whether the saved adaptive target was configured and reached."""
    target = gradient.config.uncertainty_norm_target
    if target is None:
        return "not_configured"
    return "reached" if gradient.uncertainty_norm <= target else "not_reached"


def _energy_standard_error(
    evaluation: ObjectiveEvaluationIR | SampledObjectiveEvaluationIR,
) -> float | None:
    if isinstance(evaluation, SampledObjectiveEvaluationIR):
        return evaluation.energy_standard_error
    return None


def _correlation_matrix(
    covariance: Mapping[str, Mapping[str, float]],
) -> dict[str, dict[str, float]]:
    names = tuple(covariance)
    correlation: dict[str, dict[str, float]] = {}
    for left in names:
        left_error = math.sqrt(max(0.0, covariance[left][left]))
        row: dict[str, float] = {}
        for right in names:
            right_error = math.sqrt(max(0.0, covariance[right][right]))
            denominator = left_error * right_error
            row[right] = (
                1.0
                if left == right and denominator == 0.0
                else (
                    0.0 if denominator == 0.0 else covariance[left][right] / denominator
                )
            )
        correlation[left] = row
    return correlation
