"""Standard report for standalone VQE repeated layer experiments."""

from __future__ import annotations

from dataclasses import replace
from typing import Any

from cascaqit.algorithms.vqe_layer_experiment import (
    VQE_LAYER_OBJECTIVE_TOLERANCE,
    VQERepeatedLayerExperimentResult,
    vqe_layer_objective,
)
from cascaqit.visualization.algorithm_report import (
    build_algorithm_experiment_report,
)
from cascaqit.visualization.experiment import ExperimentReportIR

__all__ = ["build_vqe_repeated_layer_experiment_report"]


def build_vqe_repeated_layer_experiment_report(
    source: VQERepeatedLayerExperimentResult,
    *,
    title: str = "VQE repeated layer experiment",
) -> ExperimentReportIR:
    """Render every stored VQE repeat without calling Backend or optimizer code."""
    if not isinstance(source, VQERepeatedLayerExperimentResult):
        raise TypeError("source must be VQERepeatedLayerExperimentResult.")
    snapshot = source.to_dict()
    selected = source.selected_result
    report = build_algorithm_experiment_report(
        selected,
        report_id=(
            "algorithm_report.vqe-repeated-layer-experiment."
            f"{source.experiment_id.rsplit('.', 1)[-1]}"
        ),
        title=title,
    )
    payload = _repeated_layer_payload(source)
    experiment_paths = (
        "VQERepeatedLayerExperimentResult.steps",
        "VQERepeatedLayerExperimentResult.selected_step_index",
        "VQERepeatedLayerExperimentResult.stop_reason",
        "VQERepeatedLayerExperimentResult.optimizer",
        "VQERepeatedLayerExperimentResult.metadata",
    )
    sections = []
    for section in report.sections:
        section_payload = dict(section.payload)
        if section.section_id == "algorithm.validate":
            checks = list(section_payload.get("checks", ()))
            checks.extend(
                (
                    {
                        "name": "Repeated run completeness",
                        "status": "passed",
                        "value": source.total_optimization_count,
                    },
                    {
                        "name": "Deterministic seed uniqueness",
                        "status": "passed",
                        "value": len(
                            {
                                run.seed
                                for step in source.steps
                                for run in step.statistics.runs
                            }
                        ),
                    },
                    {
                        "name": "Same-repeat layer transfer",
                        "status": "passed",
                        "value": source.metadata["warm_start"],
                    },
                )
            )
            section_payload["checks"] = checks
        elif section.section_id == "algorithm.plan":
            section_payload["repeated_layer_experiment"] = {
                key: payload[key]
                for key in (
                    "max_layers",
                    "repeats",
                    "confidence_level",
                    "min_improvement",
                    "numeric_tolerance",
                    "patience",
                    "final_shots",
                    "seed",
                    "selection_rule",
                    "warm_start",
                    "layer_objective_source",
                    "measurement",
                    "sampled_selection",
                )
            }
        elif section.section_id == "algorithm.execute":
            section_payload["repeated_layer_experiment"] = {
                key: payload[key]
                for key in (
                    "executed_layer_count",
                    "total_optimization_count",
                    "total_evaluation_count",
                    "total_gradient_evaluation_count",
                    "total_backend_execution_count",
                    "total_confirmation_backend_execution_count",
                    "total_workflow_backend_execution_count",
                    "total_objective_shots",
                    "total_confirmation_shots",
                    "total_final_sampling_shots",
                    "total_workflow_shots",
                    "total_final_sampling_count",
                    "selected_run",
                )
            }
        elif section.section_id == "algorithm.analyze":
            section_payload["repeated_layer_experiment"] = payload
        sections.append(
            replace(
                section,
                payload=section_payload,
                source_paths=(
                    *_selected_result_paths(section.source_paths),
                    *experiment_paths,
                ),
            )
        )
    result = replace(
        report,
        source_kind="VQERepeatedLayerExperiment",
        source_ids=(source.experiment_id,),
        source_hashes={source.experiment_id: source.stable_hash()},
        sections=tuple(sections),
        metadata={
            **report.metadata,
            "experiment_id": source.experiment_id,
            "selected_layers": source.selected_layers,
            "selected_run_id": source.selected_run.run_id,
            "selected_repeat_index": source.selected_run.repeat_index,
            "stop_reason": source.stop_reason,
            "total_optimization_count": source.total_optimization_count,
            "total_evaluation_count": source.total_evaluation_count,
            "total_backend_execution_count": (
                source.total_backend_execution_count
            ),
            "backend_called": False,
            "optimizer_called": False,
        },
    )
    if source.to_dict() != snapshot:
        raise ValueError("VQE repeated layer report mutated its source experiment.")
    return result


def _repeated_layer_payload(
    source: VQERepeatedLayerExperimentResult,
) -> dict[str, Any]:
    selected = source.selected_run
    return {
        "experiment_id": source.experiment_id,
        "algorithm_id": source.algorithm_id,
        "hamiltonian_hash": source.hamiltonian_hash,
        "max_layers": source.max_layers,
        "executed_layer_count": len(source.steps),
        "repeats": source.repeats,
        "selected_layers": source.selected_layers,
        "selected_step_index": source.selected_step_index,
        "stop_reason": source.stop_reason,
        "confidence_level": source.confidence_level,
        "min_improvement": source.min_improvement,
        "numeric_tolerance": VQE_LAYER_OBJECTIVE_TOLERANCE,
        "patience": source.patience,
        "final_shots": source.final_shots,
        "seed": source.seed,
        "total_optimization_count": source.total_optimization_count,
        "total_evaluation_count": source.total_evaluation_count,
        "total_gradient_evaluation_count": sum(
            result.termination.njev for result in source.results
        ),
        "total_backend_execution_count": source.total_backend_execution_count,
        "total_confirmation_backend_execution_count": (
            source.total_confirmation_backend_execution_count
        ),
        "total_workflow_backend_execution_count": (
            source.total_workflow_backend_execution_count
        ),
        "total_objective_shots": source.total_objective_shots,
        "total_confirmation_shots": source.total_confirmation_shots,
        "total_final_sampling_shots": source.total_final_sampling_shots,
        "total_workflow_shots": source.total_workflow_shots,
        "total_final_sampling_count": len(source.results),
        "selection_rule": source.metadata["selection_rule"],
        "warm_start": source.metadata["warm_start"],
        "layer_objective_source": source.metadata["layer_objective_source"],
        "measurement": (
            None if source.measurement is None else source.measurement.to_dict()
        ),
        "sampled_selection": (
            None
            if source.sampled_selection is None
            else source.sampled_selection.to_dict()
        ),
        "optimality_claim": "not_claimed",
        "selected_run": {
            "run_id": selected.run_id,
            "repeat_index": selected.repeat_index,
            "seed": selected.seed,
            "algorithm_run_id": selected.result.algorithm_run_id,
            "best_energy": vqe_layer_objective(selected.result),
            "result_hash": selected.result.stable_hash(),
            "final_result_id": (
                None
                if selected.result.final_result is None
                else selected.result.final_result.result_id
            ),
        },
        "steps": [
            {
                "layers": step.layers,
                "repeat_objectives": list(step.statistics.objectives),
                "run_ids": [run.run_id for run in step.statistics.runs],
                "run_seeds": [run.seed for run in step.statistics.runs],
                "algorithm_run_ids": [
                    run.result.algorithm_run_id for run in step.statistics.runs
                ],
                "sample_count": step.statistics.sample_count,
                "mean_objective": step.statistics.mean_objective,
                "sample_variance": step.statistics.sample_variance,
                "standard_error": step.statistics.standard_error,
                "confidence_interval_low": (
                    step.statistics.confidence_interval_low
                ),
                "confidence_interval_high": (
                    step.statistics.confidence_interval_high
                ),
                "comparison": (
                    None
                    if step.comparison is None
                    else step.comparison.to_dict()
                ),
                "material_improvement": step.material_improvement,
                "incumbent_layer": step.incumbent_layer,
                "no_improvement_count": step.no_improvement_count,
                "optimization_count": len(step.statistics.runs),
                "evaluation_count": sum(
                    len(run.result.evaluations)
                    for run in step.statistics.runs
                ),
                "gradient_evaluation_count": sum(
                    run.result.termination.njev
                    for run in step.statistics.runs
                ),
                "backend_execution_count": sum(
                    int(run.result.termination.backend_execution_count or 0)
                    for run in step.statistics.runs
                ),
                "final_sampling_count": len(step.statistics.runs),
            }
            for step in source.steps
        ],
    }


def _selected_result_paths(paths: tuple[str, ...]) -> tuple[str, ...]:
    prefix = "VariationalResult"
    selected_prefix = "VQERepeatedLayerExperimentResult.selected_result"
    return tuple(
        f"{selected_prefix}{path[len(prefix):]}"
        if path == prefix or path.startswith(f"{prefix}.")
        else path
        for path in paths
    )
