"""Standard report for repeated statistical Problem layer experiments."""

from __future__ import annotations

from dataclasses import replace
from typing import Any

from cascaqit.problems.layer_experiment import PROBLEM_LAYER_OBJECTIVE_TOLERANCE
from cascaqit.problems.repeated_layer_experiment import (
    ProblemRepeatedLayerExperimentResult,
)
from cascaqit.visualization.experiment import ExperimentReportIR
from cascaqit.visualization.problem_comparison_report import (
    build_problem_comparison_experiment_report,
)

__all__ = ["build_problem_repeated_layer_experiment_report"]


def build_problem_repeated_layer_experiment_report(
    source: ProblemRepeatedLayerExperimentResult,
    *,
    title: str = "Problem repeated layer experiment",
) -> ExperimentReportIR:
    """Render stored repeated executions without running the optimizer again."""
    if not isinstance(source, ProblemRepeatedLayerExperimentResult):
        raise TypeError("source must be ProblemRepeatedLayerExperimentResult.")
    snapshot = source.to_dict()
    report = build_problem_comparison_experiment_report(
        source.comparison_sources(),
        report_id=(
            "problem_report.repeated-layer-experiment."
            f"{source.experiment_id.rsplit('.', 1)[-1]}"
        ),
        title=title,
    )
    payload = _repeated_layer_payload(source)
    sections = []
    for section in report.sections:
        section_payload = dict(section.payload)
        if section.section_id == "problem-comparison.validate":
            section_payload["repeated_layer_experiment"] = {
                key: payload[key]
                for key in (
                    "max_layers",
                    "repeats",
                    "confidence_level",
                    "min_improvement",
                    "numeric_tolerance",
                    "patience",
                    "requested_shots",
                    "seed",
                    "selection_rule",
                    "layer_objective_source",
                    "measurement",
                    "sampled_selection",
                )
            }
        elif section.section_id == "problem-comparison.execute":
            section_payload["repeated_layer_experiment"] = {
                "executed_layer_count": payload["executed_layer_count"],
                "total_optimization_count": payload["total_optimization_count"],
                "total_evaluation_count": payload["total_evaluation_count"],
                "total_backend_execution_count": payload[
                    "total_backend_execution_count"
                ],
                "total_confirmation_backend_execution_count": payload[
                    "total_confirmation_backend_execution_count"
                ],
                "total_workflow_backend_execution_count": payload[
                    "total_workflow_backend_execution_count"
                ],
                "total_objective_shots": payload["total_objective_shots"],
                "total_confirmation_shots": payload[
                    "total_confirmation_shots"
                ],
                "total_final_sampling_shots": payload[
                    "total_final_sampling_shots"
                ],
                "total_workflow_shots": payload["total_workflow_shots"],
                "warm_start": payload["warm_start"],
            }
        elif section.section_id == "problem-comparison.analyze":
            section_payload["repeated_layer_experiment"] = payload
        sections.append(replace(section, payload=section_payload))
    result = replace(
        report,
        source_kind="ProblemRepeatedLayerExperiment",
        sections=tuple(sections),
        metadata={
            **report.metadata,
            "experiment_id": source.experiment_id,
            "selected_layers": source.selected_layers,
            "stop_reason": source.stop_reason,
            "total_optimization_count": source.total_optimization_count,
            "total_evaluation_count": source.total_evaluation_count,
            "backend_called": False,
            "optimizer_called": False,
        },
    )
    if source.to_dict() != snapshot:
        raise ValueError("Repeated layer report mutated its source experiment.")
    return result


def _repeated_layer_payload(
    source: ProblemRepeatedLayerExperimentResult,
) -> dict[str, Any]:
    return {
        "experiment_id": source.experiment_id,
        "max_layers": source.max_layers,
        "executed_layer_count": len(source.steps),
        "repeats": source.repeats,
        "selected_layers": source.selected_layers,
        "selected_step_index": source.selected_step_index,
        "stop_reason": source.stop_reason,
        "confidence_level": source.confidence_level,
        "min_improvement": source.min_improvement,
        "numeric_tolerance": PROBLEM_LAYER_OBJECTIVE_TOLERANCE,
        "patience": source.patience,
        "requested_shots": source.requested_shots,
        "seed": source.seed,
        "total_optimization_count": source.total_optimization_count,
        "total_evaluation_count": source.total_evaluation_count,
        "total_backend_execution_count": source.total_backend_execution_count,
        "total_confirmation_backend_execution_count": (
            source.total_confirmation_backend_execution_count
        ),
        "total_workflow_backend_execution_count": (
            source.total_workflow_backend_execution_count
        ),
        "total_objective_shots": source.total_objective_shots,
        "total_confirmation_shots": source.total_confirmation_shots,
        "total_final_sampling_shots": source.total_final_sampling_shots,
        "total_workflow_shots": source.total_workflow_shots,
        "selection_rule": source.metadata["selection_rule"],
        "warm_start": source.metadata["warm_start"],
        "layer_objective_source": source.metadata["layer_objective_source"],
        "measurement": (
            None if source.measurement is None else source.measurement.to_dict()
        ),
        "sampled_selection": (
            None
            if source.sampled_selection is None
            else source.sampled_selection.to_dict()
        ),
        "optimality_claim": "not_claimed",
        "steps": [
            {
                "layers": step.layers,
                "repeat_objectives": list(step.statistics.objectives),
                "run_ids": [run.run_id for run in step.statistics.runs],
                "run_seeds": [run.seed for run in step.statistics.runs],
                "sample_count": step.statistics.sample_count,
                "mean_objective": step.statistics.mean_objective,
                "sample_variance": step.statistics.sample_variance,
                "standard_error": step.statistics.standard_error,
                "confidence_interval_low": (
                    step.statistics.confidence_interval_low
                ),
                "confidence_interval_high": (
                    step.statistics.confidence_interval_high
                ),
                "comparison": (
                    None
                    if step.comparison is None
                    else step.comparison.to_dict()
                ),
                "material_improvement": step.material_improvement,
                "incumbent_layer": step.incumbent_layer,
                "no_improvement_count": step.no_improvement_count,
                "optimization_count": len(step.statistics.runs),
                "evaluation_count": sum(
                    run.execution.optimization.evaluation_count
                    for run in step.statistics.runs
                    if run.execution.optimization is not None
                ),
            }
            for step in source.steps
        ],
    }
