"""Read-only report projections for saved Adam optimizer evidence."""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any

from cascaqit.algorithms import (
    ObjectiveGradientIR,
    OptimizationStartIR,
    SampledObjectiveEvaluationIR,
)

__all__ = ["build_adam_report_payload", "build_workflow_cost_payload"]


def build_adam_report_payload(
    starts: Sequence[OptimizationStartIR],
    evaluations: Sequence[Any],
) -> dict[str, Any] | None:
    """Project saved Adam iterations without invoking an optimizer or Backend."""
    iterations: list[dict[str, Any]] = []
    start_payloads: list[dict[str, Any]] = []
    for start in starts:
        if not start.adam_iterations:
            continue
        start_payloads.append(
            {
                "start_index": start.start_index,
                "seed": start.seed,
                "termination": start.termination.to_dict(),
                "stopping_evidence": (
                    None
                    if start.adam_stopping_evidence is None
                    else start.adam_stopping_evidence.to_dict()
                ),
            }
        )
        for item in start.adam_iterations:
            center = evaluations[item.center_objective_evaluation_index]
            updated = evaluations[item.updated_objective_evaluation_index]
            iterations.append(
                {
                    **item.to_dict(),
                    "start_index": start.start_index,
                    "center_objective": _energy(center),
                    "center_objective_standard_error": _energy_standard_error(center),
                    "updated_objective": _energy(updated),
                    "updated_objective_standard_error": _energy_standard_error(updated),
                }
            )
    if not iterations:
        return None
    return {
        "iteration_count": len(iterations),
        "start_count": len(start_payloads),
        "starts": start_payloads,
        "iterations": iterations,
        # Adam v_t records squared-gradient optimizer state.  It is deliberately
        # labelled separately from the finite-shot covariance saved on each row.
        "second_moment_semantics": "optimizer_state_not_sampling_variance",
    }


def build_workflow_cost_payload(
    *,
    objective_backend_executions: int,
    objective_shots: int,
    gradients: Sequence[ObjectiveGradientIR],
    confirmation_backend_executions: int = 0,
    confirmation_shots: int = 0,
    final_sampling_backend_executions: int = 0,
    final_sampling_shots: int = 0,
) -> dict[str, Any]:
    """Build one consistent objective/gradient/confirmation/final cost ledger."""
    gradient_backend_executions = sum(
        item.backend_execution_count for item in gradients
    )
    gradient_shots = sum(item.total_shots for item in gradients)
    categories = {
        "objective": {
            "backend_execution_count": objective_backend_executions,
            "shots": objective_shots,
        },
        "gradient": {
            "backend_execution_count": gradient_backend_executions,
            "shots": gradient_shots,
        },
        "candidate_confirmation": {
            "backend_execution_count": confirmation_backend_executions,
            "shots": confirmation_shots,
        },
        "final_sampling": {
            "backend_execution_count": final_sampling_backend_executions,
            "shots": final_sampling_shots,
        },
    }
    return {
        "categories": categories,
        "total_backend_execution_count": sum(
            item["backend_execution_count"] for item in categories.values()
        ),
        "total_shots": sum(item["shots"] for item in categories.values()),
    }


def _energy_standard_error(
    evaluation: Any,
) -> float | None:
    if isinstance(evaluation, SampledObjectiveEvaluationIR):
        return evaluation.energy_standard_error
    return None


def _energy(evaluation: Any) -> float:
    if hasattr(evaluation, "energy"):
        return float(evaluation.energy)
    return float(evaluation.objective_value)
