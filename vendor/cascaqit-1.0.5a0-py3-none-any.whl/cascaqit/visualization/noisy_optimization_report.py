"""Build report payloads for saved variational noise execution evidence."""

from __future__ import annotations

from typing import Any

from cascaqit.algorithms import (
    ObjectiveExecutionEvidenceIR,
    SampledObjectiveEvaluationIR,
)

__all__ = [
    "build_objective_execution_payload",
    "build_objective_request_payload",
    "build_objective_summary_payload",
    "build_sampled_objective_execution_payload",
    "build_sampled_objective_request_payload",
]


def build_objective_request_payload(
    evidence: ObjectiveExecutionEvidenceIR,
) -> dict[str, Any]:
    """Return the user request facts that selected one objective execution path."""
    _require_evidence(evidence)
    return {
        "execution_mode": "noisy" if evidence.noise_model is not None else "ideal",
        "noise_model": (
            None if evidence.noise_model is None else evidence.noise_model.to_dict()
        ),
        "noise_model_hash": (
            None
            if evidence.noise_model is None
            else evidence.noise_model.stable_hash()
        ),
        "requested_options": (
            None
            if evidence.requested_options is None
            else evidence.requested_options.to_dict()
        ),
        "requested_seed": evidence.requested_seed,
    }


def build_objective_summary_payload(
    evidence: ObjectiveExecutionEvidenceIR,
) -> dict[str, Any]:
    """Return compact per-evaluation facts for an optimization history table."""
    _require_evidence(evidence)
    return {
        "execution_mode": "noisy" if evidence.noise_model is not None else "ideal",
        "method": evidence.simulation_plan.method_selected,
        "estimator": evidence.estimator_kind.value,
        "source_kind": evidence.source_kind.value,
        "effective_seed": evidence.effective_seed,
        "backend_job_id": evidence.backend_job_id,
        "backend_shots": evidence.backend_shots,
        "noise_model_hash": (
            None
            if evidence.noise_model is None
            else evidence.noise_model.stable_hash()
        ),
        "evidence_hash": evidence.evidence_hash,
    }


def build_objective_execution_payload(
    evidence: ObjectiveExecutionEvidenceIR,
) -> dict[str, Any]:
    """Return all typed facts needed by the standard visible execution view."""
    payload = evidence.to_dict()
    payload["execution_mode"] = (
        "noisy" if evidence.noise_model is not None else "ideal"
    )
    payload["noise_model_hash"] = (
        None
        if evidence.noise_model is None
        else evidence.noise_model.stable_hash()
    )
    payload["simulation_plan_hash"] = evidence.simulation_plan.stable_hash()
    payload["noise_report_hash"] = (
        None
        if evidence.noise_report is None
        else evidence.noise_report.stable_hash()
    )
    return payload


def build_sampled_objective_request_payload(
    evaluation: SampledObjectiveEvaluationIR,
) -> dict[str, Any]:
    """Return the run-level request shared by every sampled QWC group."""
    _require_sampled_evaluation(evaluation)
    noise = evaluation.noise_model
    options = evaluation.requested_options
    return {
        "execution_mode": "noisy" if noise is not None else "ideal",
        "estimator_kind": evaluation.estimator_kind,
        "measurement_kind": "qubit_wise_commuting_pauli",
        "grouping": evaluation.plan.config.grouping,
        "allocation": evaluation.plan.config.allocation,
        "shots_per_group": evaluation.plan.config.shots_per_group,
        "shots_by_group": list(evaluation.plan.shots_by_group),
        "final_shots_by_group": list(evaluation.final_shots_by_group),
        "pilot_shots_per_group": evaluation.plan.config.pilot_shots_per_group,
        "adaptive_allocation": (
            None
            if evaluation.adaptive_allocation is None
            else evaluation.adaptive_allocation.to_dict()
        ),
        "group_count": len(evaluation.plan.groups),
        "total_shots_per_evaluation": evaluation.total_shots,
        "backend_executions_per_evaluation": evaluation.backend_execution_count,
        "measurement_plan_id": evaluation.plan.plan_id,
        "measurement_plan_hash": evaluation.plan.plan_hash,
        "noise_model": None if noise is None else noise.to_dict(),
        "noise_model_hash": None if noise is None else noise.stable_hash(),
        "requested_options": None if options is None else options.to_dict(),
        "requested_options_hash": (
            None if options is None else options.stable_hash()
        ),
        "requested_seed": evaluation.metadata["root_seed"],
        "simulation_method": evaluation.simulation_method,
        "backend_id": evaluation.backend_id,
        "readout_mitigation": _readout_mitigation_payload(evaluation),
    }


def build_sampled_objective_execution_payload(
    evaluation: SampledObjectiveEvaluationIR,
) -> dict[str, Any]:
    """Return selected sampled objective facts with every physical group Job."""
    _require_sampled_evaluation(evaluation)
    adaptive = evaluation.adaptive_allocation is not None
    return {
        "execution_mode": (
            "noisy" if evaluation.noise_model is not None else "ideal"
        ),
        "estimator_kind": evaluation.estimator_kind,
        "measurement_kind": "qubit_wise_commuting_pauli",
        "backend_id": evaluation.backend_id,
        "simulation_method": evaluation.simulation_method,
        "backend_execution_count": evaluation.backend_execution_count,
        "total_shots": evaluation.total_shots,
        "energy": evaluation.energy,
        "energy_standard_error": evaluation.energy_standard_error,
        "raw_energy": evaluation.raw_energy,
        "raw_energy_standard_error": evaluation.raw_energy_standard_error,
        "mitigated_energy": evaluation.mitigated_energy,
        "mitigated_energy_standard_error": (
            evaluation.mitigated_energy_standard_error
        ),
        "readout_mitigation": _readout_mitigation_payload(evaluation),
        "measurement_plan_hash": evaluation.plan.plan_hash,
        "groups": [
            {
                "group_index": item.group.group_index,
                "stage": (
                    "static"
                    if not adaptive
                    else (
                        "pilot"
                        if index < len(evaluation.group_results)
                        else "additional"
                    )
                ),
                "seed": item.seed,
                "shots": item.shots,
                "counts": dict(item.counts),
                "backend_id": item.backend_id,
                "backend_job_id": item.backend_job_id,
                "result_id": item.result_id,
                "result_hash": item.result_hash,
                "program_hash": item.program_hash,
                "energy_mean": item.energy_mean,
                "energy_standard_error": item.energy_standard_error,
                "execution_evidence": build_objective_execution_payload(
                    item.execution_evidence
                ),
            }
            for index, item in enumerate(evaluation.all_group_results)
        ],
    }


def _readout_mitigation_payload(
    evaluation: SampledObjectiveEvaluationIR,
) -> dict[str, Any] | None:
    """返回报告需要的校准身份与数值稳定性，不复制完整响应矩阵。"""
    config = evaluation.plan.config.mitigation
    if config is None:
        return None
    calibration = config.calibration
    return {
        "method": config.method,
        "calibration_id": calibration.calibration_id,
        "calibration_hash": calibration.calibration_hash,
        "calibration_source": calibration.source,
        "logical_order": list(calibration.logical_order),
        "condition_numbers": dict(calibration.condition_numbers),
        "total_condition_number": calibration.total_condition_number,
        "max_condition_number": config.max_condition_number,
    }


def _require_evidence(evidence: ObjectiveExecutionEvidenceIR) -> None:
    if not isinstance(evidence, ObjectiveExecutionEvidenceIR):
        raise TypeError("evidence must be ObjectiveExecutionEvidenceIR.")


def _require_sampled_evaluation(evaluation: SampledObjectiveEvaluationIR) -> None:
    if not isinstance(evaluation, SampledObjectiveEvaluationIR):
        raise TypeError("evaluation must be SampledObjectiveEvaluationIR.")
