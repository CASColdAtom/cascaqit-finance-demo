"""Build the standard Algorithm Profile from one VariationalResult."""

from __future__ import annotations

from typing import Any

from cascaqit.algorithms import (
    ObjectiveEvaluationIR,
    OptimizationStartIR,
    OptimizerConfig,
    SampledObjectiveEvaluationIR,
    SampledSelectionIR,
    VariationalResult,
)
from cascaqit.visualization.adam_report import (
    build_adam_report_payload,
    build_workflow_cost_payload,
)
from cascaqit.visualization.experiment import ExperimentReportIR, ExperimentSectionIR
from cascaqit.visualization.gradient_report import build_gradient_report_payload
from cascaqit.visualization.noisy_optimization_report import (
    build_objective_execution_payload,
    build_objective_request_payload,
    build_objective_summary_payload,
    build_sampled_objective_execution_payload,
    build_sampled_objective_request_payload,
)

__all__ = [
    "build_algorithm_experiment_report",
    "build_optimization_start_payloads",
    "build_sampled_selection_payload",
]


def build_algorithm_experiment_report(
    result: VariationalResult[Any],
    *,
    report_id: str | None = None,
    title: str | None = None,
) -> ExperimentReportIR:
    """Derive seven lifecycle views without executing or mutating the workflow."""
    if not isinstance(result, VariationalResult):
        raise TypeError("result must be VariationalResult.")
    before = result.to_dict()
    best = result.best_evaluation
    best_start = next(
        start
        for start in result.optimization_starts
        if start.best_evaluation_index == result.best_evaluation_index
    )
    selected = result.selected_evaluation
    final = result.final_result
    baseline_energy = (
        None
        if result.baseline is None or result.baseline.status != "available"
        else result.baseline.objective_value
    )
    gradient = build_gradient_report_payload(
        result.gradients,
        termination=result.termination,
    )
    sampled_selection = _sampled_selection_payload(result)
    adam = build_adam_report_payload(result.optimization_starts, result.evaluations)
    workflow_cost = build_workflow_cost_payload(
        objective_backend_executions=sum(
            _evaluation_backend_execution_count(evaluation)
            for evaluation in result.evaluations
        ),
        objective_shots=sum(
            _evaluation_total_shots(evaluation) for evaluation in result.evaluations
        ),
        gradients=result.gradients,
        confirmation_backend_executions=(
            0
            if result.sampled_selection is None
            else result.sampled_selection.backend_execution_count
        ),
        confirmation_shots=(
            0
            if result.sampled_selection is None
            else result.sampled_selection.total_shots
        ),
        final_sampling_backend_executions=0 if final is None else 1,
        final_sampling_shots=0 if final is None else final.shots,
    )
    objective_request = _objective_request_payload(best)
    objective_execution = _objective_execution_payload(best)
    sections = (
        ExperimentSectionIR(
            section_id="algorithm.design",
            stage="design",
            title="Algorithm and Hamiltonian design",
            status="available",
            payload={
                "algorithm_kind": result.algorithm_kind,
                "algorithm_run_id": result.algorithm_run_id,
                "problem_id": result.problem_id,
                "problem_hash": result.problem_hash,
                "hamiltonian": {
                    "hamiltonian_id": result.hamiltonian.hamiltonian_id,
                    "hash": result.hamiltonian.stable_hash(),
                    "constant": result.hamiltonian.constant,
                    "logical_order": list(result.hamiltonian.logical_order),
                    "term_count": len(result.hamiltonian.terms),
                    "terms": [
                        {
                            "term_id": term.term_id,
                            "coefficient": term.coefficient,
                            "observable_name": term.observable.name,
                            "targets": list(term.observable.targets),
                            "bases": [basis.value for basis in term.observable.bases],
                        }
                        for term in result.hamiltonian.terms
                    ],
                },
                "ansatz": result.ansatz.to_dict(),
            },
            source_paths=(
                "VariationalResult.hamiltonian",
                "VariationalResult.ansatz",
                "VariationalResult.problem_id",
                "VariationalResult.problem_hash",
            ),
        ),
        ExperimentSectionIR(
            section_id="algorithm.validate",
            stage="validate",
            title="Workflow consistency",
            status="available",
            payload={
                "diagnostic_count": 0,
                "by_severity": {},
                "by_stage": {},
                "checks": [
                    {
                        "name": "Hamiltonian continuity",
                        "status": "passed",
                        "value": result.hamiltonian.stable_hash(),
                    },
                    {
                        "name": "Parameter layout",
                        "status": "passed",
                        "value": list(result.ansatz.parameter_names),
                    },
                    {
                        "name": "Objective history",
                        "status": "passed",
                        "value": len(result.evaluations),
                    },
                    {
                        "name": "Optimizer nfev alignment",
                        "status": "passed",
                        "value": result.termination.nfev,
                    },
                    {
                        "name": "Optimizer njev alignment",
                        "status": "passed",
                        "value": result.termination.njev,
                    },
                    {
                        "name": "Backend execution cost",
                        "status": "passed",
                        "value": result.termination.backend_execution_count,
                    },
                    {
                        "name": "Final sampling evidence",
                        "status": "passed" if final is not None else "unavailable",
                        "value": None if final is None else final.result_id,
                    },
                ],
            },
            source_paths=(
                "VariationalResult.evaluations",
                "VariationalResult.termination.nfev",
                "VariationalResult.final_result",
            ),
        ),
        ExperimentSectionIR(
            section_id="algorithm.plan",
            stage="plan",
            title="Ansatz and optimizer plan",
            status="available",
            payload={
                "ansatz": result.ansatz.to_dict(),
                "ansatz_id": result.ansatz.ansatz_id,
                "ansatz_kind": result.ansatz.ansatz_kind,
                "layers": result.ansatz.layers,
                "logical_order": list(result.ansatz.logical_order),
                "parameter_names": list(result.ansatz.parameter_names),
                "optimizer": result.optimizer.to_dict(),
                "initial_parameters": list(
                    result.metadata.get("initial_parameters", ())
                ),
                "resolved_seed": result.metadata.get("resolved_seed"),
                "start_count": len(result.optimization_starts),
                "selected_start_index": result.selected_start_index,
                "gradient_plan": None if gradient is None else gradient["plan"],
                "objective_request": objective_request,
                "measurement_plan": (
                    best.plan.to_dict()
                    if isinstance(best, SampledObjectiveEvaluationIR)
                    else None
                ),
            },
            source_paths=(
                "VariationalResult.ansatz",
                "VariationalResult.optimizer",
                "VariationalResult.metadata.initial_parameters",
                "VariationalResult.metadata.resolved_seed",
                "VariationalResult.best_evaluation.execution_evidence.noise_model",
                "VariationalResult.best_evaluation.execution_evidence.requested_options",
            ),
        ),
        ExperimentSectionIR(
            section_id="algorithm.execute",
            stage="execute",
            title="Optimization execution",
            status="available" if result.termination.success else "warning",
            payload={
                "termination": result.termination.to_dict(),
                "evaluation_count": len(result.evaluations),
                "backend_result_count": len(
                    {
                        result_id
                        for evaluation in result.evaluations
                        for result_id in _evaluation_result_ids(evaluation)
                    }
                ),
                "objective_backend_execution_count": sum(
                    _evaluation_backend_execution_count(evaluation)
                    for evaluation in result.evaluations
                ),
                "objective_total_shots": sum(
                    _evaluation_total_shots(evaluation)
                    for evaluation in result.evaluations
                ),
                "total_wall_time_seconds": sum(
                    evaluation.wall_time_seconds for evaluation in result.evaluations
                ),
                "best_evaluation_index": result.best_evaluation_index,
                "selected_start_index": result.selected_start_index,
                "starts": build_optimization_start_payloads(
                    result.optimization_starts,
                    result.evaluations,
                    optimizer=result.optimizer,
                ),
                "baseline_energy": baseline_energy,
                "gradient": gradient,
                "adam": adam,
                "workflow_cost": workflow_cost,
                "evaluations": [
                    _evaluation_payload(evaluation, result.ansatz.parameter_names)
                    for evaluation in result.evaluations
                ],
                "spsa_iterations": _spsa_iteration_payloads(
                    result.optimization_starts,
                    result.evaluations,
                ),
                "sampled_selection": sampled_selection,
                "objective_execution": objective_execution,
            },
            source_paths=(
                "VariationalResult.optimizer",
                "VariationalResult.evaluations",
                "VariationalResult.best_evaluation_index",
                "VariationalResult.optimization_starts",
                "VariationalResult.selected_start_index",
                "VariationalResult.termination",
                "VariationalResult.gradients",
                "VariationalResult.optimization_starts.adam_iterations",
                "VariationalResult.sampled_selection",
                "VariationalResult.evaluations.execution_evidence",
            ),
        ),
        ExperimentSectionIR(
            section_id="algorithm.state",
            stage="state",
            title="Objective state evidence",
            status="available",
            payload={
                "best_evaluation_id": best.evaluation_id,
                "estimator": (
                    best.estimator_kind
                    if isinstance(best, SampledObjectiveEvaluationIR)
                    else best.metadata.get("estimator")
                ),
                "source_kind": best.observable_batch.source_kind.value,
                "observable_set_hash": best.observable_batch.observable_set_hash,
                "observable_source_hash": best.observable_batch.source_hash,
                "hamiltonian_hash": (
                    best.plan.hamiltonian_hash
                    if isinstance(best, SampledObjectiveEvaluationIR)
                    else best.hamiltonian_hash
                ),
                "constant": (
                    best.plan.constant
                    if isinstance(best, SampledObjectiveEvaluationIR)
                    else best.constant
                ),
                "contributions": [
                    contribution.to_dict() for contribution in best.contributions
                ],
                "state_bytes_read": False,
                "observable_standard_errors": _observable_standard_errors(best),
                "energy_standard_error": (
                    best.energy_standard_error
                    if isinstance(best, SampledObjectiveEvaluationIR)
                    else None
                ),
            },
            source_paths=(
                "VariationalResult.best_evaluation.observable_batch",
                "VariationalResult.best_evaluation.contributions",
                "VariationalResult.best_evaluation.hamiltonian_hash",
                "VariationalResult.best_evaluation.execution_evidence.observable_standard_errors",
            ),
        ),
        _measurement_section(result),
        ExperimentSectionIR(
            section_id="algorithm.analyze",
            stage="analyze",
            title="Candidate and baseline analysis",
            status="available",
            payload={
                "best_evaluation_index": result.best_evaluation_index,
                "best_evaluation_id": best.evaluation_id,
                "best_energy": best_start.best_objective,
                "best_source_energy": best.energy,
                "best_energy_kind": result.metadata.get(
                    "objective_selection_rule",
                    "minimum_observed_energy",
                ),
                "best_parameters": {
                    name: best.parameter_bind.values[name]
                    for name in result.ansatz.parameter_names
                },
                "selected_evaluation_index": selected.evaluation_index,
                "selected_evaluation_id": selected.evaluation_id,
                "selected_energy": selected.energy,
                "selected_parameters": {
                    name: selected.parameter_bind.values[name]
                    for name in result.ansatz.parameter_names
                },
                "sampled_selection": sampled_selection,
                "most_probable_candidate": _optional_dict(
                    result.most_probable_candidate
                ),
                "best_observed_candidate": _optional_dict(
                    result.best_observed_candidate
                ),
                "candidate_status": result.metadata.get(
                    "candidate_status",
                    "unavailable",
                ),
                "baseline": _optional_dict(result.baseline),
                "candidate_gap": _plain_mapping(
                    result.metadata.get("candidate_gap", {})
                ),
                "final_sampling": _plain_mapping(
                    result.metadata.get("final_sampling", {})
                ),
                "optimality_claim": result.optimality_claim,
            },
            source_paths=(
                "VariationalResult.best_evaluation",
                "VariationalResult.selected_evaluation",
                "VariationalResult.sampled_selection",
                "VariationalResult.most_probable_candidate",
                "VariationalResult.best_observed_candidate",
                "VariationalResult.baseline",
                "VariationalResult.metadata.candidate_gap",
                "VariationalResult.metadata.final_sampling",
            ),
        ),
    )
    source_ids, source_hashes = _source_identity(result)
    report = ExperimentReportIR(
        report_id=report_id or f"algorithm_report.{result.algorithm_run_id}",
        title=title or f"{result.algorithm_kind.upper()} workflow result",
        profile="algorithm",
        source_kind="VariationalResult",
        source_ids=source_ids,
        source_hashes=source_hashes,
        sections=sections,
        metadata={
            "derived_view": True,
            "source_variational_result_mutated": False,
            "objective_recomputed": False,
            "state_bytes_read": False,
            "artifact_bytes_read": False,
            "backend_called": False,
            "network_accessed": False,
        },
    )
    if result.to_dict() != before:
        raise ValueError("Algorithm report construction mutated VariationalResult.")
    return report


def _measurement_section(result: VariationalResult[Any]) -> ExperimentSectionIR:
    final = result.final_result
    if final is None:
        return ExperimentSectionIR(
            section_id="algorithm.measure",
            stage="measure",
            title="Final sampling",
            status="unavailable",
            unavailable_reason="No final sampling ResultIR is available.",
        )
    return ExperimentSectionIR(
        section_id="algorithm.measure",
        stage="measure",
        title="Final sampling",
        status="available",
        payload={
            "result_id": final.result_id,
            "result_hash": final.stable_hash(),
            "program_hash": final.program_hash,
            "shots": final.shots,
            "counts": dict(final.counts),
            "probabilities": (
                None if final.probabilities is None else dict(final.probabilities)
            ),
            "sample_count": len(final.samples),
            "bit_ordering": dict(final.bit_ordering),
            "most_probable_candidate": _optional_dict(result.most_probable_candidate),
            "best_observed_candidate": _optional_dict(result.best_observed_candidate),
            "candidate_status": result.metadata.get(
                "candidate_status",
                "unavailable",
            ),
            "sampling_execution": _plain_mapping(
                result.metadata.get("final_sampling", {})
            ),
            "cardinality_subspace": _optional_dict(result.cardinality_subspace),
        },
        source_paths=(
            "VariationalResult.final_result.counts",
            "VariationalResult.final_result.shots",
            "VariationalResult.final_result.bit_ordering",
            "VariationalResult.most_probable_candidate",
            "VariationalResult.best_observed_candidate",
            "VariationalResult.metadata.final_sampling",
            "VariationalResult.cardinality_subspace",
        ),
    )


def _source_identity(
    result: VariationalResult[Any],
) -> tuple[tuple[str, ...], dict[str, str]]:
    pairs = [
        (result.algorithm_run_id, result.stable_hash()),
        (result.hamiltonian.hamiltonian_id, result.hamiltonian.stable_hash()),
        (result.best_evaluation.evaluation_id, result.best_evaluation.stable_hash()),
    ]
    if result.final_result is not None:
        pairs.append((result.final_result.result_id, result.final_result.stable_hash()))
    if result.sampled_selection is not None:
        pairs.append(
            (
                f"{result.algorithm_run_id}.sampled_selection",
                result.sampled_selection.stable_hash(),
            )
        )
        pairs.extend(
            (evaluation.evaluation_id, evaluation.stable_hash())
            for candidate in result.sampled_selection.candidates
            for evaluation in candidate.evaluations
        )
    source_ids = tuple(source_id for source_id, _ in pairs)
    if len(source_ids) != len(set(source_ids)):
        raise ValueError("Algorithm report source identities must be unique.")
    return source_ids, dict(pairs)


def _sampled_selection_payload(
    result: VariationalResult[Any],
) -> dict[str, Any] | None:
    """Describe saved confirmation evidence without executing new measurements."""
    return build_sampled_selection_payload(
        result.sampled_selection,
        result.evaluations,
    )


def build_sampled_selection_payload(
    selection: SampledSelectionIR | None,
    evaluations: tuple[ObjectiveEvaluationIR | SampledObjectiveEvaluationIR, ...],
) -> dict[str, Any] | None:
    """Project saved confirmation evidence for Algorithm and Problem reports."""
    if selection is None:
        return None
    confirmation_plan = selection.candidates[0].evaluations[0].plan
    candidates = []
    for candidate in selection.candidates:
        source = evaluations[candidate.source_evaluation_index]
        candidates.append(
            {
                "candidate_rank": candidate.candidate_rank,
                # Bokeh's objective-history renderer consumes this generic key.
                "evaluation_index": candidate.candidate_rank,
                "source_evaluation_index": candidate.source_evaluation_index,
                "source_evaluation_id": candidate.source_evaluation_id,
                "source_parameter_bind_hash": candidate.source_parameter_bind_hash,
                "observed_energy": source.energy,
                "energy": candidate.energy,
                "confirmation_mean": candidate.energy,
                "energy_standard_error": candidate.energy_standard_error,
                "confidence_interval_low": candidate.confidence_interval_low,
                "confidence_interval_high": candidate.confidence_interval_high,
                "confidence_level": candidate.confidence_level,
                "parameters": dict(source.parameter_bind.values),
                "result_id": candidate.evaluations[0].result_ids[0],
                "confirmation_evaluation_ids": [
                    evaluation.evaluation_id for evaluation in candidate.evaluations
                ],
                "repeat_count": len(candidate.evaluations),
                "total_shots": candidate.total_shots,
                "backend_execution_count": candidate.backend_execution_count,
                "selected": (
                    candidate.candidate_rank == selection.selected_candidate_rank
                ),
            }
        )
    rounds = []
    previous_shots = 0
    previous_executions = 0
    for round_item in selection.rounds:
        rounds.append(
            {
                "round_index": round_item.round_index,
                "measured_candidate_ranks": list(round_item.measured_candidate_ranks),
                "repeat_counts": list(round_item.repeat_counts),
                "selected_candidate_rank": round_item.selected_candidate_rank,
                "runner_up_candidate_rank": (round_item.runner_up_candidate_rank),
                "energy_difference": round_item.energy_difference,
                "difference_standard_error": (round_item.difference_standard_error),
                "difference_confidence_interval_low": (
                    round_item.difference_confidence_interval_low
                ),
                "difference_confidence_interval_high": (
                    round_item.difference_confidence_interval_high
                ),
                "status": round_item.status,
                "incremental_shots": round_item.total_shots - previous_shots,
                "incremental_backend_execution_count": (
                    round_item.backend_execution_count - previous_executions
                ),
                "total_shots": round_item.total_shots,
                "backend_execution_count": (round_item.backend_execution_count),
            }
        )
        previous_shots = round_item.total_shots
        previous_executions = round_item.backend_execution_count
    return {
        "config": selection.config.to_dict(),
        "mode": selection.config.mode,
        "planned_look_count": selection.config.planned_look_count,
        "actual_look_count": len(selection.rounds),
        "nominal_confidence_level": selection.config.confidence_level,
        "decision_confidence_level": selection.decision_confidence_level,
        "root_seed": selection.root_seed,
        "evaluation_start_index": selection.evaluation_start_index,
        "confirmation_shots_per_group": (selection.confirmation_shots_per_group),
        "confirmation_allocation": confirmation_plan.config.allocation,
        "confirmation_shots_by_group": list(confirmation_plan.shots_by_group),
        "candidates": candidates,
        "rounds": rounds,
        "selected_candidate_rank": selection.selected_candidate_rank,
        "selected_source_evaluation_index": (
            selection.selected_source_evaluation_index
        ),
        "runner_up_candidate_rank": selection.runner_up_candidate_rank,
        "energy_difference": selection.energy_difference,
        "difference_standard_error": selection.difference_standard_error,
        "difference_confidence_interval_low": (
            selection.difference_confidence_interval_low
        ),
        "difference_confidence_interval_high": (
            selection.difference_confidence_interval_high
        ),
        "status": selection.status,
        "stop_reason": selection.stop_reason,
        "total_shots": selection.total_shots,
        "backend_execution_count": selection.backend_execution_count,
        "selection_rule": selection.selection_rule,
        "confidence_interval_method": selection.confidence_interval_method,
    }


def _objective_request_payload(
    evaluation: ObjectiveEvaluationIR | SampledObjectiveEvaluationIR,
) -> dict[str, Any]:
    """Describe the estimator request without assuming exact-state evidence."""
    if isinstance(evaluation, ObjectiveEvaluationIR):
        return build_objective_request_payload(evaluation.execution_evidence)
    return build_sampled_objective_request_payload(evaluation)


def _objective_execution_payload(
    evaluation: ObjectiveEvaluationIR | SampledObjectiveEvaluationIR,
) -> dict[str, Any]:
    """Summarize one exact execution or a complete grouped measurement plan."""
    if isinstance(evaluation, ObjectiveEvaluationIR):
        return build_objective_execution_payload(evaluation.execution_evidence)
    return build_sampled_objective_execution_payload(evaluation)


def _evaluation_payload(
    evaluation: ObjectiveEvaluationIR | SampledObjectiveEvaluationIR,
    parameter_names: tuple[str, ...],
) -> dict[str, Any]:
    """Build one optimization-history row with estimator-specific evidence."""
    common = {
        "evaluation_index": evaluation.evaluation_index,
        "evaluation_id": evaluation.evaluation_id,
        "energy": evaluation.energy,
        "parameters": {
            name: evaluation.parameter_bind.values[name] for name in parameter_names
        },
        "parameter_bind_hash": evaluation.parameter_bind.parameter_bind_hash,
        "observable_source_hash": evaluation.observable_batch.source_hash,
        "wall_time_seconds": evaluation.wall_time_seconds,
    }
    if isinstance(evaluation, ObjectiveEvaluationIR):
        return {
            **common,
            "estimator_kind": evaluation.execution_evidence.estimator_kind.value,
            "energy_standard_error": None,
            "total_shots": 0,
            "backend_execution_count": 1,
            "result_id": evaluation.result_id,
            "result_hash": evaluation.result_hash,
            "result_ids": [evaluation.result_id],
            "result_hashes": [evaluation.result_hash],
            "cache_hit": evaluation.cache_hit,
            "execution": build_objective_summary_payload(evaluation.execution_evidence),
        }
    return {
        **common,
        "estimator_kind": evaluation.estimator_kind,
        "energy_standard_error": evaluation.energy_standard_error,
        "raw_energy": evaluation.raw_energy,
        "raw_energy_standard_error": evaluation.raw_energy_standard_error,
        "mitigated_energy": evaluation.mitigated_energy,
        "mitigated_energy_standard_error": (
            evaluation.mitigated_energy_standard_error
        ),
        "total_shots": evaluation.total_shots,
        "backend_execution_count": evaluation.backend_execution_count,
        "result_id": evaluation.result_ids[0],
        "result_hash": evaluation.result_hashes[0],
        "result_ids": list(evaluation.result_ids),
        "result_hashes": list(evaluation.result_hashes),
        "cache_hit": False,
        "execution": _objective_execution_payload(evaluation),
    }


def _spsa_iteration_payloads(
    starts: tuple[OptimizationStartIR, ...],
    evaluations: tuple[ObjectiveEvaluationIR | SampledObjectiveEvaluationIR, ...],
) -> list[dict[str, Any]]:
    """Attach sampled uncertainty to every direction in each SPSA update."""
    payloads: list[dict[str, Any]] = []
    for start in starts:
        for iteration in start.spsa_iterations:
            directions: list[dict[str, Any]] = []
            for direction in iteration.directions:
                plus_index = (
                    start.evaluation_start_index + direction.plus_evaluation_offset
                )
                minus_index = (
                    start.evaluation_start_index + direction.minus_evaluation_offset
                )
                plus = evaluations[plus_index]
                minus = evaluations[minus_index]
                directions.append(
                    {
                        **direction.to_dict(),
                        "plus_evaluation_index": plus_index,
                        "minus_evaluation_index": minus_index,
                        "plus_energy_standard_error": (
                            direction.plus_estimate.pooled_standard_error
                            if direction.plus_estimate.repeat_count > 1
                            else (
                                plus.energy_standard_error
                                if isinstance(plus, SampledObjectiveEvaluationIR)
                                else None
                            )
                        ),
                        "minus_energy_standard_error": (
                            direction.minus_estimate.pooled_standard_error
                            if direction.minus_estimate.repeat_count > 1
                            else (
                                minus.energy_standard_error
                                if isinstance(minus, SampledObjectiveEvaluationIR)
                                else None
                            )
                        ),
                    }
                )
            payloads.append(
                {
                    **iteration.to_dict(),
                    "start_index": start.start_index,
                    "directions": directions,
                }
            )
    return payloads


def build_optimization_start_payloads(
    starts: tuple[OptimizationStartIR, ...],
    evaluations: tuple[ObjectiveEvaluationIR | SampledObjectiveEvaluationIR, ...],
    *,
    optimizer: OptimizerConfig | None = None,
) -> list[dict[str, Any]]:
    """Embed per-pair uncertainty in the start shape consumed by HTML reports."""
    uncertainty_by_key = {
        (item["start_index"], item["iteration_index"]): item
        for item in _spsa_iteration_payloads(starts, evaluations)
    }
    payloads: list[dict[str, Any]] = []
    for start in starts:
        data = start.to_dict()
        data["spsa_config"] = (
            None
            if optimizer is None or optimizer.spsa is None
            else optimizer.spsa.to_dict()
        )
        data["spsa_iterations"] = [
            uncertainty_by_key[(start.start_index, iteration.iteration_index)]
            for iteration in start.spsa_iterations
        ]
        payloads.append(data)
    return payloads


def _evaluation_result_ids(
    evaluation: ObjectiveEvaluationIR | SampledObjectiveEvaluationIR,
) -> tuple[str, ...]:
    if isinstance(evaluation, SampledObjectiveEvaluationIR):
        return evaluation.result_ids
    return (evaluation.result_id,)


def _evaluation_backend_execution_count(
    evaluation: ObjectiveEvaluationIR | SampledObjectiveEvaluationIR,
) -> int:
    if isinstance(evaluation, SampledObjectiveEvaluationIR):
        return evaluation.backend_execution_count
    return 1


def _evaluation_total_shots(
    evaluation: ObjectiveEvaluationIR | SampledObjectiveEvaluationIR,
) -> int:
    if isinstance(evaluation, SampledObjectiveEvaluationIR):
        return evaluation.total_shots
    return 0


def _observable_standard_errors(
    evaluation: ObjectiveEvaluationIR | SampledObjectiveEvaluationIR,
) -> dict[str, float]:
    if isinstance(evaluation, ObjectiveEvaluationIR):
        return dict(evaluation.execution_evidence.observable_standard_errors)
    return {
        term_id: error
        for group in evaluation.group_results
        for term_id, error in group.term_standard_errors.items()
    }


def _optional_dict(value: Any) -> dict[str, Any] | None:
    if value is None:
        return None
    data = value.to_dict()
    if not isinstance(data, dict):
        raise TypeError("Algorithm report source must serialize to an object.")
    return data


def _plain_mapping(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict) and not hasattr(value, "items"):
        return {}
    return {str(key): _plain_value(item) for key, item in value.items()}


def _plain_value(value: Any) -> Any:
    if hasattr(value, "items"):
        return _plain_mapping(value)
    if isinstance(value, (tuple, list)):
        return [_plain_value(item) for item in value]
    return value
