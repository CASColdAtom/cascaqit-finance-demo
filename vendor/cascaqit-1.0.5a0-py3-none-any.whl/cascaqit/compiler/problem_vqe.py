"""Digital VQE lowering from one shared Problem analysis."""

from __future__ import annotations

from dataclasses import dataclass

from cascaqit.algorithms import (
    VQE,
    CardinalityPreservingAnsatz,
    HardwareEfficientAnsatz,
)
from cascaqit.algorithms.problem_projection import problem_to_pauli_hamiltonian
from cascaqit.compiler.problem_digital import (
    DigitalLoweringArtifacts,
    _digital_term_mapping,
)
from cascaqit.digital import Circuit
from cascaqit.exceptions import CapabilityError
from cascaqit.parameters import ParameterSchemaIR
from cascaqit.problems.analysis import ProblemAnalysisResult
from cascaqit.problems.optimization import OptimizationProblem
from cascaqit.targets import TargetSpec

__all__ = ["DigitalVQELowerer"]


@dataclass(frozen=True)
class DigitalVQELowerer:
    """Reuse built-in or explicit VQE Ansatz under the unified compiler."""

    def lower(
        self,
        problem: OptimizationProblem,
        *,
        analysis: ProblemAnalysisResult,
        layers: int,
        mis_penalty: float,
        target: TargetSpec,
        mwis_penalty: float | None = None,
        ansatz: (
            HardwareEfficientAnsatz
            | CardinalityPreservingAnsatz
            | Circuit
            | None
        ) = None,
    ) -> DigitalLoweringArtifacts:
        """Build the canonical VQE Circuit and conserved Digital term mapping."""
        if not isinstance(analysis, ProblemAnalysisResult):
            raise TypeError("analysis must be ProblemAnalysisResult.")
        feasibility = analysis.mapping_plan.feasibility_for("digital")
        if not feasibility.feasible:
            raise ValueError("Digital lowering requires a feasible mapping plan.")

        # VQE 的公开构造器不直接接收 Graph/MIS，但共享 Problem projection
        # 已能把它们转换成与 analysis 相同的 Pauli Hamiltonian。传入该
        # Hamiltonian 可复用现有 VQE 数学，同时保留 Unified decoder。
        hamiltonian = problem_to_pauli_hamiltonian(
            problem,
            mis_penalty=mis_penalty,
            mwis_penalty=mwis_penalty,
        )
        if (
            hamiltonian.stable_hash()
            != analysis.logical_hamiltonian.pauli_hamiltonian_hash
        ):
            raise ValueError("VQE and shared analysis Hamiltonians do not match.")
        vqe = VQE(hamiltonian, layers=layers, ansatz=ansatz)
        source = vqe.build_circuit()
        spec = vqe.ansatz_spec()
        _validate_target_gates(target, spec.required_gates)

        # 重新组合只增加 Unified Problem 来源信息，不复制或修改 Ansatz 门序列。
        program = Circuit(
            source.qubits,
            program_id=source.program_id,
            metadata={
                "algorithm": "vqe",
                "algorithm_id": vqe.algorithm_id,
                "layers": layers,
                "analysis_hash": analysis.analysis_hash,
                "problem_hash": analysis.canonical_problem.problem_hash,
                "logical_hamiltonian_hash": (
                    analysis.logical_hamiltonian.stable_hash()
                ),
                "lowerer": "DigitalVQELowerer",
                "ansatz_kind": spec.ansatz_kind,
                "ansatz_spec_hash": spec.spec_hash,
                "required_gates": list(spec.required_gates),
            },
        ).compose(source)
        return DigitalLoweringArtifacts(
            program=program,
            hamiltonian=hamiltonian,
            ansatz=spec,
            parameter_schema=ParameterSchemaIR.from_parameters(program.parameters),
            term_mapping=_digital_term_mapping(analysis),
        )


def _validate_target_gates(target: TargetSpec, required_gates: tuple[str, ...]) -> None:
    if not isinstance(target, TargetSpec):
        raise TypeError("target must be TargetSpec.")
    typed = target.typed_capabilities
    unsupported = tuple(
        gate
        for gate in required_gates
        if typed is None
        or typed.digital_gate_status(gate)
        not in {"supported", "experimental", "ir_only"}
    )
    if unsupported:
        raise CapabilityError(
            "VQE ansatz requires Digital gates unsupported by this Target: "
            + ", ".join(unsupported)
            + ".",
            code="PROBLEM_VQE_ANSATZ_GATE_UNSUPPORTED",
            stage="compilation",
            object_path="problem.compile.digital.vqe.ansatz.required_gates",
            metadata={
                "target_id": target.target_id,
                "unsupported_gates": list(unsupported),
                "required_gates": list(required_gates),
            },
        )
