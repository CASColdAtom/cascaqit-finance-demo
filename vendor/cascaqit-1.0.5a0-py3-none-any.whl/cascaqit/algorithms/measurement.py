"""Qubit-wise commuting Pauli measurement plans for sampled VQE energy."""

from __future__ import annotations

import hashlib
import math
import re
from collections.abc import Iterable, Mapping
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Any, Literal, cast

from cascaqit.algorithms.models import (
    HamiltonianContributionIR,
    HamiltonianTerm,
    PauliHamiltonian,
)
from cascaqit.algorithms.noisy_execution import (
    ObjectiveExecutionEvidenceIR,
    build_objective_execution_evidence,
    validate_sampled_variational_request,
)
from cascaqit.algorithms.readout_mitigation import (
    ReadoutMitigatedContributionIR,
    ReadoutMitigatedGroupStatisticsIR,
    ReadoutMitigationConfig,
    compute_readout_mitigated_group_statistics,
    validate_readout_mitigation,
)
from cascaqit.digital import Circuit
from cascaqit.native_ir.base import IRMixin, stable_json
from cascaqit.observables import (
    Observable,
    ObservableBatchResultIR,
    ObservableEstimatorKind,
    ObservableResultIR,
    ObservableSet,
    ObservableSourceKind,
    PauliBasis,
)
from cascaqit.parameters import ParameterBindIR, ParameterSchemaIR
from cascaqit.results import ResultIR
from cascaqit.simulators import (
    LocalBackend,
    NoiseModel,
    SimulationExecutionPlan,
    SimulationOptions,
)

__all__ = [
    "AdaptiveShotAllocationIR",
    "PauliMeasurementConfig",
    "PauliMeasurementGroupIR",
    "PauliMeasurementGroupResultIR",
    "PauliMeasurementPlanIR",
    "PauliMeasurementTermIR",
    "SampledObjectiveEvaluationIR",
    "build_group_measurement_circuit",
    "build_pauli_measurement_plan",
    "derive_measurement_group_seed",
    "derive_adaptive_measurement_group_seed",
    "execute_sampled_objective_evaluation",
]

MEASUREMENT_SCHEMA_VERSION = "cascaqit.algorithms.pauli_measurement.v5"
# Allocation changes the plan schema, but existing uniform requests must retain
# their established deterministic counts. Seed derivation therefore has its own
# stable namespace and does not inherit serialization-version churn.
_MEASUREMENT_SEED_NAMESPACE = "cascaqit.algorithms.pauli_measurement.v1"
_ADAPTIVE_MEASUREMENT_SEED_NAMESPACE = (
    "cascaqit.algorithms.pauli_measurement.pilot_variance.v1"
)
_DIGEST_PATTERN = re.compile(r"[0-9a-f]{64}")
_FLOAT_TOLERANCE = 1e-12
_REQUIRED_GATE_ORDER = ("h", "sdg", "measure")


@dataclass(frozen=True)
class PauliMeasurementConfig(IRMixin):
    """Shot budget and allocation for qubit-wise commuting Pauli groups.

    ``shots_per_group`` is the actual per-group count under ``uniform``. Under
    ``coefficient_l1`` and ``pilot_variance`` it defines the same total
    objective budget. The former allocates it before execution from Hamiltonian
    coefficients; the latter reserves a pilot stage and allocates the remainder
    from observed group-energy variance.
    """

    shots_per_group: int = 1024
    grouping: Literal["qubit_wise_commuting"] = "qubit_wise_commuting"
    allocation: Literal["uniform", "coefficient_l1", "pilot_variance"] = "uniform"
    pilot_shots_per_group: int | None = None
    mitigation: ReadoutMitigationConfig | None = None
    schema_version: str = MEASUREMENT_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if (
            not isinstance(self.shots_per_group, int)
            or isinstance(self.shots_per_group, bool)
            or self.shots_per_group < 2
        ):
            raise ValueError("shots_per_group must be an integer of at least two.")
        if self.grouping != "qubit_wise_commuting":
            raise ValueError("grouping must be qubit_wise_commuting.")
        if self.allocation not in {"uniform", "coefficient_l1", "pilot_variance"}:
            raise ValueError(
                "allocation must be uniform, coefficient_l1, or pilot_variance."
            )
        if self.allocation != "pilot_variance":
            if self.pilot_shots_per_group is not None:
                raise ValueError(
                    "pilot_shots_per_group is only valid for pilot_variance."
                )
        else:
            pilot = self.resolved_pilot_shots_per_group
            if pilot < 2 or pilot > self.shots_per_group - 2:
                raise ValueError(
                    "pilot_shots_per_group must leave at least two additional "
                    "shots per group."
                )
        if self.mitigation is not None and not isinstance(
            self.mitigation,
            ReadoutMitigationConfig,
        ):
            raise TypeError("mitigation must be ReadoutMitigationConfig or None.")
        _require_schema(self.schema_version)

    @property
    def resolved_pilot_shots_per_group(self) -> int:
        """Return the explicit pilot size used by a two-stage measurement."""
        if self.pilot_shots_per_group is not None:
            if not isinstance(self.pilot_shots_per_group, int) or isinstance(
                self.pilot_shots_per_group, bool
            ):
                raise ValueError("pilot_shots_per_group must be an integer.")
            return self.pilot_shots_per_group
        return max(2, min(32, self.shots_per_group // 4))

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> PauliMeasurementConfig:
        """Restore a sampled-measurement configuration."""
        return cls(
            shots_per_group=data.get("shots_per_group", 1024),
            grouping=data.get("grouping", "qubit_wise_commuting"),
            allocation=data.get("allocation", "uniform"),
            pilot_shots_per_group=data.get("pilot_shots_per_group"),
            mitigation=(
                None
                if data.get("mitigation") is None
                else ReadoutMitigationConfig.from_dict(
                    _mapping(data["mitigation"], "mitigation")
                )
            ),
            schema_version=str(data.get("schema_version", MEASUREMENT_SCHEMA_VERSION)),
        )

    @classmethod
    def from_json(cls, text: str) -> PauliMeasurementConfig:
        """Restore a sampled-measurement configuration from JSON."""
        return cls.from_dict(_json_object(text, "PauliMeasurementConfig"))


@dataclass(frozen=True)
class PauliMeasurementTermIR(IRMixin):
    """One Hamiltonian term assigned to a measurement group."""

    term_index: int
    term_id: str
    coefficient: float
    observable: Observable
    schema_version: str = MEASUREMENT_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_non_negative_int(self.term_index, "term_index")
        _require_text(self.term_id, "term_id")
        coefficient = _finite_float(self.coefficient, "coefficient")
        if coefficient == 0.0:
            raise ValueError("measurement term coefficient must be non-zero.")
        if not isinstance(self.observable, Observable):
            raise TypeError("observable must be Observable.")
        _require_schema(self.schema_version)
        object.__setattr__(self, "coefficient", coefficient)

    @classmethod
    def create(
        cls,
        term: HamiltonianTerm,
        *,
        term_index: int,
    ) -> PauliMeasurementTermIR:
        """Copy one canonical Hamiltonian term into a measurement plan."""
        if not isinstance(term, HamiltonianTerm):
            raise TypeError("term must be HamiltonianTerm.")
        return cls(
            term_index=term_index,
            term_id=term.term_id,
            coefficient=term.coefficient,
            observable=term.observable,
        )

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> PauliMeasurementTermIR:
        """Restore one planned measurement term."""
        return cls(
            term_index=data["term_index"],
            term_id=data["term_id"],
            coefficient=data["coefficient"],
            observable=Observable.from_dict(_mapping(data["observable"], "observable")),
            schema_version=str(data.get("schema_version", MEASUREMENT_SCHEMA_VERSION)),
        )


@dataclass(frozen=True)
class PauliMeasurementGroupIR(IRMixin):
    """One qubit-wise commuting group and its shared local measurement basis."""

    group_index: int
    logical_order: tuple[str, ...]
    basis_by_target: Mapping[str, PauliBasis]
    terms: tuple[PauliMeasurementTermIR, ...]
    schema_version: str = MEASUREMENT_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_non_negative_int(self.group_index, "group_index")
        order = tuple(self.logical_order)
        _require_unique_text(order, "logical_order")
        basis: dict[str, PauliBasis] = {}
        if set(self.basis_by_target) != set(order):
            raise ValueError("basis_by_target must cover the complete logical order.")
        for target in order:
            try:
                basis[target] = PauliBasis(self.basis_by_target[target])
            except (TypeError, ValueError) as exc:
                raise ValueError(
                    "measurement basis must contain I, X, Y, or Z."
                ) from exc
        terms = tuple(self.terms)
        if not terms or any(
            not isinstance(term, PauliMeasurementTermIR) for term in terms
        ):
            raise ValueError("terms must contain PauliMeasurementTermIR values.")
        indices = tuple(term.term_index for term in terms)
        if tuple(sorted(indices)) != indices or len(indices) != len(set(indices)):
            raise ValueError("group term indices must be unique and increasing.")
        for term in terms:
            for factor in term.observable.terms:
                planned = basis[factor.target]
                if factor.basis is not PauliBasis.I and planned is not factor.basis:
                    raise ValueError(
                        "group basis must match every non-identity Pauli factor."
                    )
        _require_schema(self.schema_version)
        object.__setattr__(self, "logical_order", order)
        object.__setattr__(self, "basis_by_target", MappingProxyType(basis))
        object.__setattr__(self, "terms", terms)

    @property
    def term_indices(self) -> tuple[int, ...]:
        """Return canonical Hamiltonian indices assigned to this group."""
        return tuple(term.term_index for term in self.terms)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> PauliMeasurementGroupIR:
        """Restore one QWC measurement group."""
        raw_terms = _sequence(data["terms"], "terms")
        return cls(
            group_index=data["group_index"],
            logical_order=tuple(_sequence(data["logical_order"], "logical_order")),
            basis_by_target={
                str(target): PauliBasis(value)
                for target, value in _mapping(
                    data["basis_by_target"], "basis_by_target"
                ).items()
            },
            terms=tuple(
                PauliMeasurementTermIR.from_dict(_mapping(item, "term"))
                for item in raw_terms
            ),
            schema_version=str(data.get("schema_version", MEASUREMENT_SCHEMA_VERSION)),
        )


@dataclass(frozen=True)
class PauliMeasurementPlanIR(IRMixin):
    """Stable QWC grouping and executable budget for one VQE Hamiltonian.

    For static allocation, ``shots_by_group`` is the final group budget. For
    ``pilot_variance``, it is the first-stage pilot budget because the final
    allocation does not exist until pilot counts have been observed. In both
    cases ``total_shots`` and ``backend_execution_count`` describe the complete
    objective evaluation.
    """

    plan_id: str
    plan_hash: str
    source_circuit_hash: str
    hamiltonian_hash: str
    hamiltonian_id: str
    constant: float
    logical_order: tuple[str, ...]
    config: PauliMeasurementConfig
    groups: tuple[PauliMeasurementGroupIR, ...]
    shots_by_group: tuple[int, ...]
    required_gates: tuple[str, ...]
    backend_execution_count: int
    total_shots: int
    schema_version: str = MEASUREMENT_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_text(self.plan_id, "plan_id")
        _require_digest(self.plan_hash, "plan_hash")
        _require_digest(self.source_circuit_hash, "source_circuit_hash")
        _require_digest(self.hamiltonian_hash, "hamiltonian_hash")
        _require_text(self.hamiltonian_id, "hamiltonian_id")
        constant = _finite_float(self.constant, "constant")
        order = tuple(self.logical_order)
        _require_unique_text(order, "logical_order")
        if not isinstance(self.config, PauliMeasurementConfig):
            raise TypeError("config must be PauliMeasurementConfig.")
        if self.config.mitigation is not None:
            validate_readout_mitigation(self.config.mitigation, order)
        groups = tuple(self.groups)
        if not groups or any(
            not isinstance(group, PauliMeasurementGroupIR) for group in groups
        ):
            raise ValueError("groups must contain PauliMeasurementGroupIR values.")
        if tuple(group.group_index for group in groups) != tuple(range(len(groups))):
            raise ValueError("measurement group indices must be contiguous.")
        if any(group.logical_order != order for group in groups):
            raise ValueError("measurement groups must share the plan logical order.")
        term_indices = tuple(
            term.term_index for group in groups for term in group.terms
        )
        if tuple(sorted(term_indices)) != tuple(range(len(term_indices))):
            raise ValueError("measurement groups must partition all Hamiltonian terms.")
        shots = tuple(self.shots_by_group)
        if len(shots) != len(groups) or any(
            not isinstance(value, int) or isinstance(value, bool) or value < 2
            for value in shots
        ):
            raise ValueError(
                "shots_by_group must contain one integer of at least two per group."
            )
        expected_shots = _allocate_group_shots(groups, self.config)
        if shots != expected_shots:
            raise ValueError("shots_by_group does not match the allocation strategy.")
        required = tuple(self.required_gates)
        expected_required = _required_gates(groups)
        if required != expected_required:
            raise ValueError("required_gates do not match measurement bases.")
        expected_execution_count = len(groups) * (
            2 if self.config.allocation == "pilot_variance" else 1
        )
        if self.backend_execution_count != expected_execution_count:
            raise ValueError(
                "backend_execution_count must match the allocation stages."
            )
        expected_total_shots = len(groups) * self.config.shots_per_group
        if self.total_shots != expected_total_shots:
            raise ValueError("total_shots must match the objective shot budget.")
        _require_schema(self.schema_version)
        object.__setattr__(self, "constant", constant)
        object.__setattr__(self, "logical_order", order)
        object.__setattr__(self, "groups", groups)
        object.__setattr__(self, "shots_by_group", shots)
        object.__setattr__(self, "required_gates", required)
        expected_hash = _measurement_plan_hash(self)
        if self.plan_hash != expected_hash:
            raise ValueError("plan_hash does not match Pauli measurement facts.")
        if self.plan_id != f"pauli.measurement.{expected_hash[:20]}":
            raise ValueError("plan_id does not match plan_hash.")

    @classmethod
    def create(
        cls,
        *,
        source_circuit_hash: str,
        hamiltonian: PauliHamiltonian,
        config: PauliMeasurementConfig,
        groups: tuple[PauliMeasurementGroupIR, ...],
    ) -> PauliMeasurementPlanIR:
        """Create a hashed plan after grouping has been validated."""
        shots_by_group = _allocate_group_shots(groups, config)
        values: dict[str, Any] = {
            "source_circuit_hash": source_circuit_hash,
            "hamiltonian_hash": hamiltonian.stable_hash(),
            "hamiltonian_id": hamiltonian.hamiltonian_id,
            "constant": hamiltonian.constant,
            "logical_order": hamiltonian.logical_order,
            "config": config,
            "groups": groups,
            "shots_by_group": shots_by_group,
            "required_gates": _required_gates(groups),
            "backend_execution_count": len(groups)
            * (2 if config.allocation == "pilot_variance" else 1),
            "total_shots": len(groups) * config.shots_per_group,
            "schema_version": MEASUREMENT_SCHEMA_VERSION,
        }
        digest = _measurement_plan_hash(values)
        return cls(
            plan_id=f"pauli.measurement.{digest[:20]}",
            plan_hash=digest,
            **values,
        )

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> PauliMeasurementPlanIR:
        """Restore and revalidate a Pauli measurement plan."""
        return cls(
            plan_id=data["plan_id"],
            plan_hash=data["plan_hash"],
            source_circuit_hash=data["source_circuit_hash"],
            hamiltonian_hash=data["hamiltonian_hash"],
            hamiltonian_id=data["hamiltonian_id"],
            constant=data["constant"],
            logical_order=tuple(_sequence(data["logical_order"], "logical_order")),
            config=PauliMeasurementConfig.from_dict(_mapping(data["config"], "config")),
            groups=tuple(
                PauliMeasurementGroupIR.from_dict(_mapping(item, "group"))
                for item in _sequence(data["groups"], "groups")
            ),
            shots_by_group=tuple(
                data_item
                for data_item in _sequence(data["shots_by_group"], "shots_by_group")
            ),
            required_gates=tuple(
                str(item)
                for item in _sequence(data["required_gates"], "required_gates")
            ),
            backend_execution_count=data["backend_execution_count"],
            total_shots=data["total_shots"],
            schema_version=str(data.get("schema_version", MEASUREMENT_SCHEMA_VERSION)),
        )

    @classmethod
    def from_json(cls, text: str) -> PauliMeasurementPlanIR:
        """Restore a Pauli measurement plan from JSON."""
        return cls.from_dict(_json_object(text, "PauliMeasurementPlanIR"))


@dataclass(frozen=True)
class PauliMeasurementGroupResultIR(IRMixin):
    """Counts and covariance-aware energy statistics for one QWC group Job."""

    group_result_id: str
    group_result_hash: str
    group: PauliMeasurementGroupIR
    seed: int
    shots: int
    counts: Mapping[str, int]
    term_expectations: Mapping[str, float]
    term_standard_errors: Mapping[str, float]
    energy_mean: float
    energy_standard_error: float
    backend_id: str
    backend_job_id: str
    result_id: str
    result_hash: str
    program_hash: str
    wall_time_seconds: float
    execution_evidence: ObjectiveExecutionEvidenceIR
    schema_version: str = MEASUREMENT_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_text(self.group_result_id, "group_result_id")
        _require_digest(self.group_result_hash, "group_result_hash")
        if not isinstance(self.group, PauliMeasurementGroupIR):
            raise TypeError("group must be PauliMeasurementGroupIR.")
        _require_seed(self.seed, "seed")
        if (
            not isinstance(self.shots, int)
            or isinstance(self.shots, bool)
            or self.shots < 2
        ):
            raise ValueError("shots must be an integer of at least two.")
        counts = _normalize_counts(
            self.counts,
            logical_width=len(self.group.logical_order),
        )
        if sum(counts.values()) != self.shots:
            raise ValueError("counts must sum to shots.")
        expected = _group_statistics(self.group, counts, shots=self.shots)
        expectations = _float_mapping(self.term_expectations, "term_expectations")
        errors = _float_mapping(
            self.term_standard_errors,
            "term_standard_errors",
            non_negative=True,
        )
        if not _mapping_close(expectations, expected[0]):
            raise ValueError("term_expectations do not match group counts.")
        if not _mapping_close(errors, expected[1]):
            raise ValueError("term_standard_errors do not match group counts.")
        energy = _finite_float(self.energy_mean, "energy_mean")
        energy_error = _finite_non_negative_float(
            self.energy_standard_error,
            "energy_standard_error",
        )
        if not math.isclose(energy, expected[2], rel_tol=0.0, abs_tol=_FLOAT_TOLERANCE):
            raise ValueError("energy_mean does not match group counts.")
        if not math.isclose(
            energy_error,
            expected[3],
            rel_tol=0.0,
            abs_tol=_FLOAT_TOLERANCE,
        ):
            raise ValueError("energy_standard_error does not match group counts.")
        for name in ("backend_id", "backend_job_id", "result_id"):
            _require_text(getattr(self, name), name)
        for name in ("result_hash", "program_hash"):
            _require_digest(getattr(self, name), name)
        if not isinstance(self.execution_evidence, ObjectiveExecutionEvidenceIR):
            raise TypeError("execution_evidence must be ObjectiveExecutionEvidenceIR.")
        evidence = self.execution_evidence
        if evidence.requested_seed != self.seed or evidence.effective_seed != self.seed:
            raise ValueError("execution evidence seed must match the group seed.")
        if evidence.backend_shots != self.shots or evidence.sample_count != self.shots:
            raise ValueError("execution evidence shots must match group shots.")
        if evidence.backend_id != self.backend_id:
            raise ValueError("execution evidence backend id must match the group.")
        if evidence.backend_job_id != self.backend_job_id:
            raise ValueError("execution evidence Backend Job must match the group.")
        if (
            evidence.result_id != self.result_id
            or evidence.result_hash != self.result_hash
        ):
            raise ValueError(
                "execution evidence Result mismatch invalidates group_result_hash."
            )
        if evidence.metadata.get("program_hash") != self.program_hash:
            raise ValueError("execution evidence program hash must match the group.")
        if evidence.estimator_kind is not ObservableEstimatorKind.SAMPLE_MEAN:
            raise ValueError("group execution evidence must use sample_mean.")
        if evidence.source_kind is not ObservableSourceKind.MEASUREMENT_PLAN:
            raise ValueError("group execution evidence must use measurement_plan.")
        expected_errors = {
            term.observable.name: errors[term.term_id] for term in self.group.terms
        }
        if not _mapping_close(evidence.observable_standard_errors, expected_errors):
            raise ValueError(
                "execution evidence standard errors must match group counts."
            )
        wall = _finite_non_negative_float(self.wall_time_seconds, "wall_time_seconds")
        _require_schema(self.schema_version)
        object.__setattr__(self, "counts", MappingProxyType(counts))
        object.__setattr__(self, "term_expectations", MappingProxyType(expectations))
        object.__setattr__(self, "term_standard_errors", MappingProxyType(errors))
        object.__setattr__(self, "energy_mean", energy)
        object.__setattr__(self, "energy_standard_error", energy_error)
        object.__setattr__(self, "wall_time_seconds", wall)
        expected_hash = _group_result_hash(self)
        if self.group_result_hash != expected_hash:
            raise ValueError("group_result_hash does not match group execution facts.")
        if self.group_result_id != f"pauli.group.result.{expected_hash[:20]}":
            raise ValueError("group_result_id does not match group_result_hash.")

    @classmethod
    def create(
        cls,
        *,
        group: PauliMeasurementGroupIR,
        seed: int,
        result: ResultIR,
        backend_id: str,
        backend_job_id: str,
        noise: NoiseModel | None,
        options: SimulationOptions | None,
    ) -> PauliMeasurementGroupResultIR:
        """Create checked group evidence from one completed Backend Result."""
        if not isinstance(result, ResultIR):
            raise TypeError("result must be ResultIR.")
        statistics = _group_statistics(group, result.counts, shots=result.shots)
        usage = result.resource_usage()
        observable_batch = _group_observable_batch(
            group,
            statistics=statistics,
            shots=result.shots,
            source_hash=result.stable_hash(),
        )
        execution_evidence = build_objective_execution_evidence(
            result=result,
            observable_batch=observable_batch,
            noise=noise,
            options=options,
            requested_seed=seed,
            backend_id=backend_id,
            backend_job_id=backend_job_id,
        )
        values: dict[str, Any] = {
            "group": group,
            "seed": seed,
            "shots": result.shots,
            "counts": dict(result.counts),
            "term_expectations": statistics[0],
            "term_standard_errors": statistics[1],
            "energy_mean": statistics[2],
            "energy_standard_error": statistics[3],
            "backend_id": backend_id,
            "backend_job_id": backend_job_id,
            "result_id": result.result_id,
            "result_hash": result.stable_hash(),
            "program_hash": result.program_hash,
            "wall_time_seconds": 0.0 if usage is None else usage.wall_time_seconds,
            "execution_evidence": execution_evidence,
            "schema_version": MEASUREMENT_SCHEMA_VERSION,
        }
        digest = _group_result_hash(values)
        return cls(
            group_result_id=f"pauli.group.result.{digest[:20]}",
            group_result_hash=digest,
            **values,
        )

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> PauliMeasurementGroupResultIR:
        """Restore group execution evidence and recompute sampled statistics."""
        return cls(
            group_result_id=data["group_result_id"],
            group_result_hash=data["group_result_hash"],
            group=PauliMeasurementGroupIR.from_dict(_mapping(data["group"], "group")),
            seed=data["seed"],
            shots=data["shots"],
            counts={
                str(key): value
                for key, value in _mapping(data["counts"], "counts").items()
            },
            term_expectations={
                str(key): value
                for key, value in _mapping(
                    data["term_expectations"], "term_expectations"
                ).items()
            },
            term_standard_errors={
                str(key): value
                for key, value in _mapping(
                    data["term_standard_errors"], "term_standard_errors"
                ).items()
            },
            energy_mean=data["energy_mean"],
            energy_standard_error=data["energy_standard_error"],
            backend_id=data["backend_id"],
            backend_job_id=data["backend_job_id"],
            result_id=data["result_id"],
            result_hash=data["result_hash"],
            program_hash=data["program_hash"],
            wall_time_seconds=data["wall_time_seconds"],
            execution_evidence=ObjectiveExecutionEvidenceIR.from_dict(
                _mapping(data["execution_evidence"], "execution_evidence")
            ),
            schema_version=str(data.get("schema_version", MEASUREMENT_SCHEMA_VERSION)),
        )


@dataclass(frozen=True)
class AdaptiveShotAllocationIR(IRMixin):
    """Runtime allocation derived from a complete pilot measurement stage."""

    allocation_hash: str
    pilot_shots_by_group: tuple[int, ...]
    pilot_energy_variances: tuple[float, ...]
    allocation_weights: tuple[float, ...]
    additional_shots_by_group: tuple[int, ...]
    final_shots_by_group: tuple[int, ...]
    fallback: Literal["none", "coefficient_l1"]
    total_shots: int
    backend_execution_count: int
    schema_version: str = MEASUREMENT_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_digest(self.allocation_hash, "allocation_hash")
        pilot = _shot_tuple(self.pilot_shots_by_group, "pilot_shots_by_group")
        additional = _shot_tuple(
            self.additional_shots_by_group,
            "additional_shots_by_group",
        )
        final = _shot_tuple(self.final_shots_by_group, "final_shots_by_group")
        if not pilot or len(pilot) != len(additional) or len(pilot) != len(final):
            raise ValueError(
                "adaptive allocation groups must have equal non-zero size."
            )
        if final != tuple(left + right for left, right in zip(pilot, additional)):
            raise ValueError("final_shots_by_group must combine both stages.")
        variances = _non_negative_float_tuple(
            self.pilot_energy_variances,
            "pilot_energy_variances",
            expected_size=len(pilot),
        )
        weights = _non_negative_float_tuple(
            self.allocation_weights,
            "allocation_weights",
            expected_size=len(pilot),
        )
        if not any(weight > 0.0 for weight in weights):
            raise ValueError("allocation_weights must contain a positive value.")
        if self.fallback not in {"none", "coefficient_l1"}:
            raise ValueError("fallback must be none or coefficient_l1.")
        if self.fallback == "none" and not _float_sequence_close(
            weights,
            tuple(math.sqrt(value) for value in variances),
        ):
            raise ValueError("allocation_weights must match pilot variances.")
        if self.fallback == "coefficient_l1" and any(
            value > _FLOAT_TOLERANCE for value in variances
        ):
            raise ValueError("coefficient_l1 fallback requires zero pilot variance.")
        if self.total_shots != sum(final):
            raise ValueError("total_shots must match final_shots_by_group.")
        if self.backend_execution_count != 2 * len(final):
            raise ValueError("backend_execution_count must cover both stages.")
        _require_schema(self.schema_version)
        object.__setattr__(self, "pilot_shots_by_group", pilot)
        object.__setattr__(self, "pilot_energy_variances", variances)
        object.__setattr__(self, "allocation_weights", weights)
        object.__setattr__(self, "additional_shots_by_group", additional)
        object.__setattr__(self, "final_shots_by_group", final)
        expected_hash = _adaptive_allocation_hash(self)
        if self.allocation_hash != expected_hash:
            raise ValueError(
                "allocation_hash does not match adaptive allocation facts."
            )

    @classmethod
    def create(
        cls,
        *,
        plan: PauliMeasurementPlanIR,
        pilot_results: tuple[PauliMeasurementGroupResultIR, ...],
    ) -> AdaptiveShotAllocationIR:
        """Derive the second-stage allocation from pilot group statistics."""
        if plan.config.allocation != "pilot_variance":
            raise ValueError("adaptive allocation requires pilot_variance plan.")
        if len(pilot_results) != len(plan.groups):
            raise ValueError("pilot_results must cover every plan group.")
        for group, result, shots in zip(
            plan.groups,
            pilot_results,
            plan.shots_by_group,
        ):
            if result.group != group or result.shots != shots:
                raise ValueError("pilot_results must follow the measurement plan.")

        if plan.config.mitigation is None:
            variances = tuple(
                result.energy_standard_error**2 * result.shots
                for result in pilot_results
            )
        else:
            # 第二阶段 shots 必须按最终 active objective 的方差分配。这里直接
            # 从 pilot raw counts 计算缓解后样本方差，不修改任何 Backend 证据。
            mitigated_pilot = tuple(
                compute_readout_mitigated_group_statistics(
                    group,
                    result.counts,
                    shots=result.shots,
                    config=plan.config.mitigation,
                    source_group_result_hashes=(result.group_result_hash,),
                )
                for group, result in zip(plan.groups, pilot_results)
            )
            variances = tuple(
                item.energy_standard_error**2 * item.shots for item in mitigated_pilot
            )
        standard_deviations = tuple(math.sqrt(value) for value in variances)
        if any(value > _FLOAT_TOLERANCE for value in standard_deviations):
            weights = standard_deviations
            fallback: Literal["none", "coefficient_l1"] = "none"
        else:
            weights = tuple(
                sum(abs(term.coefficient) for term in group.terms)
                for group in plan.groups
            )
            fallback = "coefficient_l1"
        lower_bounds = tuple(value + 2 for value in plan.shots_by_group)
        final = _allocate_weighted_budget(
            weights,
            total_budget=plan.total_shots,
            lower_bounds=lower_bounds,
        )
        additional = tuple(
            value - pilot for value, pilot in zip(final, plan.shots_by_group)
        )
        values: dict[str, Any] = {
            "pilot_shots_by_group": plan.shots_by_group,
            "pilot_energy_variances": variances,
            "allocation_weights": weights,
            "additional_shots_by_group": additional,
            "final_shots_by_group": final,
            "fallback": fallback,
            "total_shots": plan.total_shots,
            "backend_execution_count": plan.backend_execution_count,
            "schema_version": MEASUREMENT_SCHEMA_VERSION,
        }
        digest = _adaptive_allocation_hash(values)
        return cls(allocation_hash=digest, **values)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> AdaptiveShotAllocationIR:
        """Restore runtime allocation evidence."""
        return cls(
            allocation_hash=data["allocation_hash"],
            pilot_shots_by_group=tuple(
                _sequence(data["pilot_shots_by_group"], "pilot_shots_by_group")
            ),
            pilot_energy_variances=tuple(
                _sequence(data["pilot_energy_variances"], "pilot_energy_variances")
            ),
            allocation_weights=tuple(
                _sequence(data["allocation_weights"], "allocation_weights")
            ),
            additional_shots_by_group=tuple(
                _sequence(
                    data["additional_shots_by_group"],
                    "additional_shots_by_group",
                )
            ),
            final_shots_by_group=tuple(
                _sequence(data["final_shots_by_group"], "final_shots_by_group")
            ),
            fallback=data["fallback"],
            total_shots=data["total_shots"],
            backend_execution_count=data["backend_execution_count"],
            schema_version=str(data.get("schema_version", MEASUREMENT_SCHEMA_VERSION)),
        )

    @classmethod
    def from_json(cls, text: str) -> AdaptiveShotAllocationIR:
        """Restore runtime allocation evidence from JSON."""
        return cls.from_dict(_json_object(text, "AdaptiveShotAllocationIR"))


@dataclass(frozen=True)
class SampledObjectiveEvaluationIR(IRMixin):
    """One sampled VQE energy assembled from complete QWC group executions."""

    evaluation_id: str
    evaluation_index: int
    parameter_bind: ParameterBindIR
    plan: PauliMeasurementPlanIR
    group_results: tuple[PauliMeasurementGroupResultIR, ...]
    additional_group_results: tuple[PauliMeasurementGroupResultIR, ...]
    adaptive_allocation: AdaptiveShotAllocationIR | None
    raw_contributions: tuple[HamiltonianContributionIR, ...]
    raw_energy: float
    raw_energy_standard_error: float
    mitigated_group_statistics: tuple[ReadoutMitigatedGroupStatisticsIR, ...]
    mitigated_contributions: tuple[ReadoutMitigatedContributionIR, ...]
    mitigated_energy: float | None
    mitigated_energy_standard_error: float | None
    contributions: tuple[
        HamiltonianContributionIR | ReadoutMitigatedContributionIR,
        ...,
    ]
    energy: float
    energy_standard_error: float
    total_shots: int
    backend_execution_count: int
    wall_time_seconds: float
    metadata: Mapping[str, Any] = field(default_factory=dict)
    schema_version: str = MEASUREMENT_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_text(self.evaluation_id, "evaluation_id")
        _require_non_negative_int(self.evaluation_index, "evaluation_index")
        if not isinstance(self.parameter_bind, ParameterBindIR):
            raise TypeError("parameter_bind must be ParameterBindIR.")
        if not self.parameter_bind.verify_hash():
            raise ValueError("parameter_bind_hash does not match values.")
        if not isinstance(self.plan, PauliMeasurementPlanIR):
            raise TypeError("plan must be PauliMeasurementPlanIR.")
        pilot_results = tuple(self.group_results)
        if len(pilot_results) != len(self.plan.groups) or any(
            not isinstance(item, PauliMeasurementGroupResultIR)
            for item in pilot_results
        ):
            raise ValueError("group_results must cover every plan group.")
        for expected_group, result in zip(self.plan.groups, pilot_results):
            if result.group != expected_group:
                raise ValueError("group_results must follow the measurement plan.")
            if result.shots != self.plan.shots_by_group[expected_group.group_index]:
                raise ValueError("group result shots must match the measurement plan.")
        additional_results = tuple(self.additional_group_results)
        allocation = self.adaptive_allocation
        if self.plan.config.allocation == "pilot_variance":
            if not isinstance(allocation, AdaptiveShotAllocationIR):
                raise ValueError(
                    "pilot_variance evaluation requires adaptive allocation."
                )
            expected_allocation = AdaptiveShotAllocationIR.create(
                plan=self.plan,
                pilot_results=pilot_results,
            )
            if allocation != expected_allocation:
                raise ValueError(
                    "adaptive allocation does not match pilot measurement results."
                )
            if len(additional_results) != len(self.plan.groups) or any(
                not isinstance(item, PauliMeasurementGroupResultIR)
                for item in additional_results
            ):
                raise ValueError(
                    "additional_group_results must cover every plan group."
                )
            for expected_group, result, shots in zip(
                self.plan.groups,
                additional_results,
                allocation.additional_shots_by_group,
            ):
                if result.group != expected_group or result.shots != shots:
                    raise ValueError(
                        "additional group results must match adaptive allocation."
                    )
        elif allocation is not None or additional_results:
            raise ValueError(
                "static measurement must not contain adaptive allocation evidence."
            )
        pooled = _pooled_group_statistics(
            self.plan.groups,
            pilot_results,
            additional_results,
        )
        expected_raw_contributions = _sampled_contributions(self.plan.groups, pooled)
        raw_contributions = tuple(self.raw_contributions)
        if raw_contributions != expected_raw_contributions:
            raise ValueError("raw_contributions do not match raw group counts.")
        raw_energy = _finite_float(self.raw_energy, "raw_energy")
        expected_raw_energy = self.plan.constant + sum(
            item.energy_mean for item in pooled
        )
        if not math.isclose(
            raw_energy,
            expected_raw_energy,
            rel_tol=0.0,
            abs_tol=_FLOAT_TOLERANCE,
        ):
            raise ValueError("raw_energy does not match raw group counts.")
        raw_error = _finite_non_negative_float(
            self.raw_energy_standard_error,
            "raw_energy_standard_error",
        )
        expected_raw_error = math.sqrt(
            sum(item.energy_standard_error**2 for item in pooled)
        )
        if not math.isclose(
            raw_error,
            expected_raw_error,
            rel_tol=0.0,
            abs_tol=_FLOAT_TOLERANCE,
        ):
            raise ValueError(
                "raw_energy_standard_error does not match raw group errors."
            )

        mitigation = self.plan.config.mitigation
        mitigated_groups = tuple(self.mitigated_group_statistics)
        mitigated_contributions = tuple(self.mitigated_contributions)
        mitigated_energy = self.mitigated_energy
        mitigated_error = self.mitigated_energy_standard_error
        expected_active_contributions: tuple[
            HamiltonianContributionIR | ReadoutMitigatedContributionIR,
            ...,
        ]
        if mitigation is None:
            if (
                mitigated_groups
                or mitigated_contributions
                or mitigated_energy is not None
                or mitigated_error is not None
            ):
                raise ValueError(
                    "raw sampled evaluation must not contain mitigated statistics."
                )
            expected_active_contributions = expected_raw_contributions
            expected_active_energy = expected_raw_energy
            expected_active_error = expected_raw_error
        else:
            expected_mitigated_groups = _mitigated_group_statistics(
                self.plan.groups,
                pooled,
                pilot_results,
                additional_results,
                mitigation,
            )
            if mitigated_groups != expected_mitigated_groups:
                raise ValueError(
                    "mitigated_group_statistics do not match raw group counts."
                )
            expected_mitigated_contributions = _mitigated_contributions(
                self.plan.groups,
                expected_mitigated_groups,
            )
            if mitigated_contributions != expected_mitigated_contributions:
                raise ValueError(
                    "mitigated_contributions do not match mitigated groups."
                )
            if mitigated_energy is None or mitigated_error is None:
                raise ValueError(
                    "mitigated evaluation requires energy and standard error."
                )
            mitigated_energy = _finite_float(
                mitigated_energy,
                "mitigated_energy",
            )
            mitigated_error = _finite_non_negative_float(
                mitigated_error,
                "mitigated_energy_standard_error",
            )
            expected_mitigated_energy = self.plan.constant + sum(
                item.energy_mean for item in expected_mitigated_groups
            )
            expected_mitigated_error = math.sqrt(
                sum(item.energy_standard_error**2 for item in expected_mitigated_groups)
            )
            if not math.isclose(
                mitigated_energy,
                expected_mitigated_energy,
                rel_tol=0.0,
                abs_tol=_FLOAT_TOLERANCE,
            ):
                raise ValueError(
                    "mitigated_energy does not match mitigated group statistics."
                )
            if not math.isclose(
                mitigated_error,
                expected_mitigated_error,
                rel_tol=0.0,
                abs_tol=_FLOAT_TOLERANCE,
            ):
                raise ValueError(
                    "mitigated_energy_standard_error does not match group errors."
                )
            expected_active_contributions = expected_mitigated_contributions
            expected_active_energy = expected_mitigated_energy
            expected_active_error = expected_mitigated_error

        contributions = tuple(self.contributions)
        if contributions != expected_active_contributions:
            raise ValueError("contributions do not match the active estimator.")
        energy = _finite_float(self.energy, "energy")
        if not math.isclose(
            energy,
            expected_active_energy,
            rel_tol=0.0,
            abs_tol=_FLOAT_TOLERANCE,
        ):
            raise ValueError("energy does not match the active estimator.")
        error = _finite_non_negative_float(
            self.energy_standard_error,
            "energy_standard_error",
        )
        if not math.isclose(
            error,
            expected_active_error,
            rel_tol=0.0,
            abs_tol=_FLOAT_TOLERANCE,
        ):
            raise ValueError(
                "energy_standard_error does not match the active estimator."
            )
        all_results = pilot_results + additional_results
        expected_shots = sum(result.shots for result in all_results)
        if (
            self.total_shots != expected_shots
            or self.total_shots != self.plan.total_shots
        ):
            raise ValueError("total_shots must match all group executions.")
        if (
            self.backend_execution_count != len(all_results)
            or self.backend_execution_count != self.plan.backend_execution_count
        ):
            raise ValueError("backend_execution_count must match group results.")
        wall = _finite_non_negative_float(self.wall_time_seconds, "wall_time_seconds")
        metadata = dict(self.metadata)
        root_seed = metadata.get("root_seed")
        _require_seed(root_seed, "metadata root_seed")
        root_seed = cast(int, root_seed)
        if metadata.get("measurement_plan_hash") != self.plan.plan_hash:
            raise ValueError("metadata measurement plan hash must match the plan.")
        if tuple(metadata.get("result_ids", ())) != self.result_ids:
            raise ValueError("metadata result ids must match group results.")
        if tuple(metadata.get("result_hashes", ())) != self.result_hashes:
            raise ValueError("metadata result hashes must match group results.")
        for group_result in pilot_results:
            expected_seed = derive_measurement_group_seed(
                root_seed,
                evaluation_index=self.evaluation_index,
                group_index=group_result.group.group_index,
            )
            if group_result.seed != expected_seed:
                raise ValueError("group seed does not match sampled objective seed.")
        for group_result in additional_results:
            expected_seed = derive_adaptive_measurement_group_seed(
                root_seed,
                evaluation_index=self.evaluation_index,
                group_index=group_result.group.group_index,
            )
            if group_result.seed != expected_seed:
                raise ValueError(
                    "additional group seed does not match sampled objective seed."
                )
        first_evidence = all_results[0].execution_evidence
        if any(
            result.execution_evidence.noise_model != first_evidence.noise_model
            or result.execution_evidence.requested_options
            != first_evidence.requested_options
            or result.execution_evidence.simulation_plan.method_selected
            != first_evidence.simulation_plan.method_selected
            or result.execution_evidence.backend_id != first_evidence.backend_id
            for result in all_results[1:]
        ):
            raise ValueError(
                "all sampled objective groups must use one execution context."
            )
        noise_hash = (
            None
            if first_evidence.noise_model is None
            else first_evidence.noise_model.stable_hash()
        )
        options_hash = (
            None
            if first_evidence.requested_options is None
            else first_evidence.requested_options.stable_hash()
        )
        if metadata.get("noise_model_hash") != noise_hash:
            raise ValueError("metadata noise model hash must match group evidence.")
        if metadata.get("requested_options_hash") != options_hash:
            raise ValueError("metadata options hash must match group evidence.")
        calibration_hash = (
            None if mitigation is None else mitigation.calibration.calibration_hash
        )
        if metadata.get("readout_calibration_hash") != calibration_hash:
            raise ValueError(
                "metadata readout calibration hash must match measurement config."
            )
        _require_schema(self.schema_version)
        object.__setattr__(self, "group_results", pilot_results)
        object.__setattr__(self, "additional_group_results", additional_results)
        object.__setattr__(self, "raw_contributions", raw_contributions)
        object.__setattr__(self, "raw_energy", raw_energy)
        object.__setattr__(self, "raw_energy_standard_error", raw_error)
        object.__setattr__(self, "mitigated_group_statistics", mitigated_groups)
        object.__setattr__(self, "mitigated_contributions", mitigated_contributions)
        object.__setattr__(self, "mitigated_energy", mitigated_energy)
        object.__setattr__(
            self,
            "mitigated_energy_standard_error",
            mitigated_error,
        )
        object.__setattr__(self, "contributions", contributions)
        object.__setattr__(self, "energy", energy)
        object.__setattr__(self, "energy_standard_error", error)
        object.__setattr__(self, "wall_time_seconds", wall)
        object.__setattr__(self, "metadata", MappingProxyType(metadata))

    @property
    def estimator_kind(
        self,
    ) -> Literal["sample_mean", "readout_mitigated_sample_mean"]:
        """Return the estimator semantics used for every Hamiltonian term."""
        return (
            "sample_mean"
            if self.plan.config.mitigation is None
            else "readout_mitigated_sample_mean"
        )

    @property
    def measurement_source_hash(self) -> str:
        """Return the composite source identity shared by derived observables."""
        material = {
            "plan_hash": self.plan.plan_hash,
            "group_result_hashes": [
                result.group_result_hash for result in self.all_group_results
            ],
        }
        return hashlib.sha256(stable_json(material).encode("utf-8")).hexdigest()

    @property
    def observable_batch(self) -> ObservableBatchResultIR:
        """Rebuild raw physical term estimates from the measurement source.

        ``ObservableResultIR`` 约束期望值位于物理区间 ``[-1, 1]``，而线性逆
        缓解允许 quasi estimate 超出该区间。因此缓解结果保存在专用 typed
        statistics 中，这里的 Observable batch 始终忠实表示 raw counts。
        """
        source_hash = self.measurement_source_hash
        items_by_index: dict[int, ObservableResultIR] = {}
        pooled = _pooled_group_statistics(
            self.plan.groups,
            self.group_results,
            self.additional_group_results,
        )
        for group, estimate in zip(self.plan.groups, pooled):
            for term in group.terms:
                expectation = estimate.term_expectations[term.term_id]
                items_by_index[term.term_index] = ObservableResultIR(
                    observable=term.observable,
                    expectation=expectation,
                    variance=max(0.0, 1.0 - expectation * expectation),
                    standard_error=estimate.term_standard_errors[term.term_id],
                    sample_count=estimate.shots,
                    source_kind=ObservableSourceKind.MEASUREMENT_PLAN,
                    source_hash=source_hash,
                    estimator_kind=ObservableEstimatorKind.SAMPLE_MEAN,
                )
        ordered = tuple(items_by_index[index] for index in range(len(items_by_index)))
        return ObservableBatchResultIR.from_results(
            ObservableSet(item.observable for item in ordered),
            ordered,
        )

    @property
    def result_ids(self) -> tuple[str, ...]:
        """Return Backend Result ids in group order."""
        return tuple(result.result_id for result in self.all_group_results)

    @property
    def result_hashes(self) -> tuple[str, ...]:
        """Return Backend Result hashes in group order."""
        return tuple(result.result_hash for result in self.all_group_results)

    @property
    def all_group_results(self) -> tuple[PauliMeasurementGroupResultIR, ...]:
        """Return pilot/static results followed by optional second-stage results."""
        return self.group_results + self.additional_group_results

    @property
    def noise_model(self) -> NoiseModel | None:
        """Return the NoiseModel shared by every physical measurement group."""
        return self.all_group_results[0].execution_evidence.noise_model

    @property
    def requested_options(self) -> SimulationOptions | None:
        """Return the SimulationOptions shared by every measurement group."""
        return self.all_group_results[0].execution_evidence.requested_options

    @property
    def simulation_method(self) -> str:
        """Return the simulator method shared by every measurement group."""
        return self.all_group_results[
            0
        ].execution_evidence.simulation_plan.method_selected

    @property
    def backend_id(self) -> str:
        """Return the Backend identity shared by every measurement group."""
        return self.all_group_results[0].execution_evidence.backend_id

    @property
    def execution_evidence_hashes(self) -> tuple[str, ...]:
        """Return every Backend group evidence hash in physical execution order."""
        return tuple(
            result.execution_evidence.evidence_hash for result in self.all_group_results
        )

    @property
    def final_shots_by_group(self) -> tuple[int, ...]:
        """Return the actual group totals used by the final energy estimator."""
        if self.adaptive_allocation is None:
            return self.plan.shots_by_group
        return self.adaptive_allocation.final_shots_by_group

    @property
    def pooled_group_statistics(self) -> tuple[_PooledGroupStatistics, ...]:
        """Return final count-derived estimates after pooling all stages."""
        return _pooled_group_statistics(
            self.plan.groups,
            self.group_results,
            self.additional_group_results,
        )

    @classmethod
    def create(
        cls,
        *,
        evaluation_id: str,
        evaluation_index: int,
        parameter_bind: ParameterBindIR,
        plan: PauliMeasurementPlanIR,
        group_results: tuple[PauliMeasurementGroupResultIR, ...],
        additional_group_results: tuple[PauliMeasurementGroupResultIR, ...] = (),
        adaptive_allocation: AdaptiveShotAllocationIR | None = None,
        metadata: Mapping[str, Any] | None = None,
    ) -> SampledObjectiveEvaluationIR:
        """Assemble one sampled energy after all planned groups complete."""
        pooled = _pooled_group_statistics(
            plan.groups,
            group_results,
            additional_group_results,
        )
        raw_contributions = _sampled_contributions(plan.groups, pooled)
        raw_energy = plan.constant + sum(item.energy_mean for item in pooled)
        raw_error = math.sqrt(sum(item.energy_standard_error**2 for item in pooled))
        mitigation = plan.config.mitigation
        active_contributions: tuple[
            HamiltonianContributionIR | ReadoutMitigatedContributionIR,
            ...,
        ]
        if mitigation is None:
            mitigated_groups: tuple[ReadoutMitigatedGroupStatisticsIR, ...] = ()
            mitigated_contributions: tuple[ReadoutMitigatedContributionIR, ...] = ()
            mitigated_energy = None
            mitigated_error = None
            active_contributions = raw_contributions
            active_energy = raw_energy
            active_error = raw_error
        else:
            mitigated_groups = _mitigated_group_statistics(
                plan.groups,
                pooled,
                group_results,
                additional_group_results,
                mitigation,
            )
            mitigated_contributions = _mitigated_contributions(
                plan.groups,
                mitigated_groups,
            )
            mitigated_energy = plan.constant + sum(
                item.energy_mean for item in mitigated_groups
            )
            mitigated_error = math.sqrt(
                sum(item.energy_standard_error**2 for item in mitigated_groups)
            )
            active_contributions = mitigated_contributions
            active_energy = mitigated_energy
            active_error = mitigated_error
        return cls(
            evaluation_id=evaluation_id,
            evaluation_index=evaluation_index,
            parameter_bind=parameter_bind,
            plan=plan,
            group_results=group_results,
            additional_group_results=additional_group_results,
            adaptive_allocation=adaptive_allocation,
            raw_contributions=raw_contributions,
            raw_energy=raw_energy,
            raw_energy_standard_error=raw_error,
            mitigated_group_statistics=mitigated_groups,
            mitigated_contributions=mitigated_contributions,
            mitigated_energy=mitigated_energy,
            mitigated_energy_standard_error=mitigated_error,
            contributions=active_contributions,
            energy=active_energy,
            energy_standard_error=active_error,
            total_shots=sum(
                item.shots for item in group_results + additional_group_results
            ),
            backend_execution_count=len(group_results + additional_group_results),
            wall_time_seconds=sum(
                item.wall_time_seconds
                for item in group_results + additional_group_results
            ),
            metadata={} if metadata is None else metadata,
        )

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> SampledObjectiveEvaluationIR:
        """Restore a sampled objective and recompute all count-derived facts."""
        plan = PauliMeasurementPlanIR.from_dict(_mapping(data["plan"], "plan"))
        contributions: tuple[
            HamiltonianContributionIR | ReadoutMitigatedContributionIR,
            ...,
        ]
        if plan.config.mitigation is None:
            contributions = tuple(
                HamiltonianContributionIR.from_dict(_mapping(item, "contribution"))
                for item in _sequence(data["contributions"], "contributions")
            )
        else:
            contributions = tuple(
                ReadoutMitigatedContributionIR.from_dict(
                    _mapping(item, "mitigated_contribution")
                )
                for item in _sequence(data["contributions"], "contributions")
            )
        return cls(
            evaluation_id=data["evaluation_id"],
            evaluation_index=data["evaluation_index"],
            parameter_bind=ParameterBindIR.from_dict(
                _mapping(data["parameter_bind"], "parameter_bind")
            ),
            plan=plan,
            group_results=tuple(
                PauliMeasurementGroupResultIR.from_dict(_mapping(item, "group_result"))
                for item in _sequence(data["group_results"], "group_results")
            ),
            additional_group_results=tuple(
                PauliMeasurementGroupResultIR.from_dict(_mapping(item, "group_result"))
                for item in _sequence(
                    data.get("additional_group_results", ()),
                    "additional_group_results",
                )
            ),
            adaptive_allocation=(
                None
                if data.get("adaptive_allocation") is None
                else AdaptiveShotAllocationIR.from_dict(
                    _mapping(data["adaptive_allocation"], "adaptive_allocation")
                )
            ),
            raw_contributions=tuple(
                HamiltonianContributionIR.from_dict(_mapping(item, "contribution"))
                for item in _sequence(
                    data["raw_contributions"],
                    "raw_contributions",
                )
            ),
            raw_energy=data["raw_energy"],
            raw_energy_standard_error=data["raw_energy_standard_error"],
            mitigated_group_statistics=tuple(
                ReadoutMitigatedGroupStatisticsIR.from_dict(
                    _mapping(item, "mitigated_group_statistics")
                )
                for item in _sequence(
                    data.get("mitigated_group_statistics", ()),
                    "mitigated_group_statistics",
                )
            ),
            mitigated_contributions=tuple(
                ReadoutMitigatedContributionIR.from_dict(
                    _mapping(item, "mitigated_contribution")
                )
                for item in _sequence(
                    data.get("mitigated_contributions", ()),
                    "mitigated_contributions",
                )
            ),
            mitigated_energy=data.get("mitigated_energy"),
            mitigated_energy_standard_error=data.get("mitigated_energy_standard_error"),
            contributions=contributions,
            energy=data["energy"],
            energy_standard_error=data["energy_standard_error"],
            total_shots=data["total_shots"],
            backend_execution_count=data["backend_execution_count"],
            wall_time_seconds=data["wall_time_seconds"],
            metadata=dict(_mapping(data.get("metadata", {}), "metadata")),
            schema_version=str(data.get("schema_version", MEASUREMENT_SCHEMA_VERSION)),
        )

    @classmethod
    def from_json(cls, text: str) -> SampledObjectiveEvaluationIR:
        """Restore a sampled objective from JSON."""
        return cls.from_dict(_json_object(text, "SampledObjectiveEvaluationIR"))


def build_pauli_measurement_plan(
    circuit: Circuit,
    hamiltonian: PauliHamiltonian,
    *,
    config: PauliMeasurementConfig | None = None,
) -> PauliMeasurementPlanIR:
    """Greedily partition Hamiltonian terms into stable QWC groups."""
    if not isinstance(circuit, Circuit):
        raise TypeError("circuit must be Circuit.")
    if not isinstance(hamiltonian, PauliHamiltonian):
        raise TypeError("hamiltonian must be PauliHamiltonian.")
    effective = PauliMeasurementConfig() if config is None else config
    if not isinstance(effective, PauliMeasurementConfig):
        raise TypeError("config must be PauliMeasurementConfig or None.")
    if circuit.measurements:
        raise ValueError("sampled VQE source Circuit must not contain measurements.")
    logical_order = tuple(circuit.qubits)
    if logical_order != hamiltonian.logical_order:
        raise ValueError("Circuit qubits must match the Hamiltonian logical order.")

    grouped_terms: list[list[PauliMeasurementTermIR]] = []
    grouped_bases: list[dict[str, PauliBasis]] = []
    for term_index, term in enumerate(hamiltonian.terms):
        planned = PauliMeasurementTermIR.create(term, term_index=term_index)
        term_basis = _observable_basis(term.observable, logical_order)
        destination = None
        for group_index, group_basis in enumerate(grouped_bases):
            if _qwc_compatible(group_basis, term_basis):
                destination = group_index
                break
        if destination is None:
            grouped_terms.append([planned])
            grouped_bases.append(dict(term_basis))
        else:
            grouped_terms[destination].append(planned)
            _merge_basis(grouped_bases[destination], term_basis)

    groups = tuple(
        PauliMeasurementGroupIR(
            group_index=index,
            logical_order=logical_order,
            basis_by_target=basis,
            terms=tuple(terms),
        )
        for index, (basis, terms) in enumerate(zip(grouped_bases, grouped_terms))
    )
    return PauliMeasurementPlanIR.create(
        source_circuit_hash=circuit.structural_hash(),
        hamiltonian=hamiltonian,
        config=effective,
        groups=groups,
    )


def build_group_measurement_circuit(
    circuit: Circuit,
    group: PauliMeasurementGroupIR,
    *,
    plan: PauliMeasurementPlanIR,
    program_id: str | None = None,
) -> Circuit:
    """Append the exact local basis rotations and terminal measurements."""
    if not isinstance(circuit, Circuit):
        raise TypeError("circuit must be Circuit.")
    if not isinstance(group, PauliMeasurementGroupIR):
        raise TypeError("group must be PauliMeasurementGroupIR.")
    if not isinstance(plan, PauliMeasurementPlanIR):
        raise TypeError("plan must be PauliMeasurementPlanIR.")
    if group not in plan.groups:
        raise ValueError("group must belong to plan.")
    if not circuit.is_bound:
        raise ValueError("measurement Circuit requires bound source parameters.")
    if circuit.measurements:
        raise ValueError("measurement Circuit source must not contain measurements.")
    logical_order = tuple(circuit.qubits)
    if logical_order != plan.logical_order:
        raise ValueError("measurement Circuit logical order does not match plan.")
    effective_program_id = program_id or (
        f"{circuit.program_id}.measurement-group-{group.group_index}"
    )
    measured = Circuit(circuit.qubits, program_id=effective_program_id).compose(circuit)
    for target in plan.logical_order:
        basis = group.basis_by_target[target]
        if basis is PauliBasis.X:
            measured.h(target)
        elif basis is PauliBasis.Y:
            # Operations are applied left-to-right: H S† is represented by
            # appending S† and then H, so U† Z U equals Pauli Y.
            measured.sdg(target).h(target)
    measured.measure_all(key=f"measurement.group.{group.group_index}")
    return measured


def derive_measurement_group_seed(
    root_seed: int,
    *,
    evaluation_index: int,
    group_index: int,
) -> int:
    """Derive an independent reproducible seed for one group Backend Job."""
    _require_seed(root_seed, "root_seed")
    _require_non_negative_int(evaluation_index, "evaluation_index")
    _require_non_negative_int(group_index, "group_index")
    material = stable_json(
        {
            "namespace": _MEASUREMENT_SEED_NAMESPACE,
            "root_seed": root_seed,
            "evaluation_index": evaluation_index,
            "group_index": group_index,
        }
    )
    return int.from_bytes(hashlib.sha256(material.encode("utf-8")).digest()[:8], "big")


def derive_adaptive_measurement_group_seed(
    root_seed: int,
    *,
    evaluation_index: int,
    group_index: int,
) -> int:
    """Derive the independent seed for one post-pilot group execution."""
    _require_seed(root_seed, "root_seed")
    _require_non_negative_int(evaluation_index, "evaluation_index")
    _require_non_negative_int(group_index, "group_index")
    material = stable_json(
        {
            "namespace": _ADAPTIVE_MEASUREMENT_SEED_NAMESPACE,
            "root_seed": root_seed,
            "evaluation_index": evaluation_index,
            "group_index": group_index,
        }
    )
    return int.from_bytes(hashlib.sha256(material.encode("utf-8")).digest()[:8], "big")


def execute_sampled_objective_evaluation(
    *,
    algorithm_id: str,
    algorithm_run_id: str | None,
    evaluation_index: int,
    circuit: Circuit,
    parameter_names: tuple[str, ...],
    parameters: Mapping[str, float] | Iterable[float],
    hamiltonian: PauliHamiltonian,
    measurement: PauliMeasurementConfig,
    backend: LocalBackend | None,
    seed: int | None,
    noise: NoiseModel | None = None,
    options: SimulationOptions | None = None,
) -> SampledObjectiveEvaluationIR:
    """Execute all planned QWC groups and assemble one sampled VQE energy."""
    from cascaqit.algorithms.execution import normalize_parameter_values

    _require_non_negative_int(evaluation_index, "evaluation_index")
    _require_text(algorithm_id, "algorithm_id")
    run_id = algorithm_id if algorithm_run_id is None else algorithm_run_id
    _require_text(run_id, "algorithm_run_id")
    if not isinstance(measurement, PauliMeasurementConfig):
        raise TypeError("measurement must be PauliMeasurementConfig.")
    if backend is None:
        execution_backend = LocalBackend(seed=seed)
    elif isinstance(backend, LocalBackend):
        execution_backend = backend
    else:
        raise TypeError("backend must be LocalBackend or None.")
    if seed is not None:
        _require_seed(seed, "seed")
    selected_seed = (
        seed
        if seed is not None
        else (
            execution_backend.seed
            if execution_backend.seed is not None
            else (None if options is None else options.seed)
        )
    )
    root_seed = 0 if selected_seed is None else selected_seed
    _require_seed(root_seed, "effective seed")

    declared_names = tuple(parameter.name for parameter in circuit.parameters)
    if declared_names != parameter_names:
        raise ValueError("Circuit parameter order must match the ansatz declaration.")
    values = normalize_parameter_values(parameters, parameter_names)
    plan = build_pauli_measurement_plan(circuit, hamiltonian, config=measurement)
    schema = ParameterSchemaIR.from_parameters(circuit.parameters)
    parameter_bind = ParameterBindIR.create(
        parameter_bind_id=f"{run_id}.sampled.bind.{evaluation_index:06d}",
        parameter_schema=schema,
        values=values,
        metadata={
            "algorithm": "vqe",
            "algorithm_id": algorithm_id,
            "evaluation_index": evaluation_index,
            "measurement_plan_hash": plan.plan_hash,
        },
    )
    bound = circuit.bind(values)

    # All circuits are synthesized before the first Job is evaluated. Basis and
    # parameter errors therefore cannot leave a partially executed measurement plan.
    group_circuits = tuple(
        build_group_measurement_circuit(
            bound,
            group,
            plan=plan,
            program_id=(
                f"program.{run_id}.sampled.{evaluation_index:06d}."
                f"group.{group.group_index:03d}"
            ),
        )
        for group in plan.groups
    )
    additional_group_circuits = (
        tuple(
            build_group_measurement_circuit(
                bound,
                group,
                plan=plan,
                program_id=(
                    f"program.{run_id}.sampled.{evaluation_index:06d}."
                    f"adaptive-group.{group.group_index:03d}"
                ),
            )
            for group in plan.groups
        )
        if plan.config.allocation == "pilot_variance"
        else ()
    )
    group_seeds = tuple(
        derive_measurement_group_seed(
            root_seed,
            evaluation_index=evaluation_index,
            group_index=group.group_index,
        )
        for group in plan.groups
    )
    additional_group_seeds = tuple(
        derive_adaptive_measurement_group_seed(
            root_seed,
            evaluation_index=evaluation_index,
            group_index=group.group_index,
        )
        for group in plan.groups
    )
    # Preflight every synthesized Circuit before executing the first Job. This is
    # necessary because QWC groups can have different basis-rotation gate sets.
    group_execution_plans = tuple(
        validate_sampled_variational_request(
            measured,
            noise=noise,
            options=options,
            backend=execution_backend,
            seed=group_seed,
        )
        for measured, group_seed in zip(group_circuits, group_seeds)
    )
    additional_execution_plans = tuple(
        validate_sampled_variational_request(
            measured,
            noise=noise,
            options=options,
            backend=execution_backend,
            seed=group_seed,
        )
        for measured, group_seed in zip(
            additional_group_circuits,
            additional_group_seeds,
        )
    )
    group_results: list[PauliMeasurementGroupResultIR] = []
    for group, measured, group_shots, group_seed, expected_execution_plan in zip(
        plan.groups,
        group_circuits,
        plan.shots_by_group,
        group_seeds,
        group_execution_plans,
    ):
        job = execution_backend.run(
            measured,
            shots=group_shots,
            seed=group_seed,
            job_id=(
                f"{run_id}.sampled.{evaluation_index:06d}.group.{group.group_index:03d}"
            ),
            noise=noise,
            options=options,
        )
        result = job.result()
        status = job.status()
        completed_group = PauliMeasurementGroupResultIR.create(
            group=group,
            seed=group_seed,
            result=result,
            backend_id=status.backend_id,
            backend_job_id=status.job_id,
            noise=noise,
            options=options,
        )
        _require_execution_plan_match(
            completed_group.execution_evidence.simulation_plan,
            expected_execution_plan,
        )
        group_results.append(completed_group)
    completed = tuple(group_results)
    adaptive_allocation = (
        AdaptiveShotAllocationIR.create(plan=plan, pilot_results=completed)
        if plan.config.allocation == "pilot_variance"
        else None
    )
    additional_results: list[PauliMeasurementGroupResultIR] = []
    if adaptive_allocation is not None:
        for group, measured, group_shots, group_seed, expected_execution_plan in zip(
            plan.groups,
            additional_group_circuits,
            adaptive_allocation.additional_shots_by_group,
            additional_group_seeds,
            additional_execution_plans,
        ):
            job = execution_backend.run(
                measured,
                shots=group_shots,
                seed=group_seed,
                job_id=(
                    f"{run_id}.sampled.{evaluation_index:06d}.adaptive-group."
                    f"{group.group_index:03d}"
                ),
                noise=noise,
                options=options,
            )
            result = job.result()
            status = job.status()
            completed_group = PauliMeasurementGroupResultIR.create(
                group=group,
                seed=group_seed,
                result=result,
                backend_id=status.backend_id,
                backend_job_id=status.job_id,
                noise=noise,
                options=options,
            )
            _require_execution_plan_match(
                completed_group.execution_evidence.simulation_plan,
                expected_execution_plan,
            )
            additional_results.append(completed_group)
    additional = tuple(additional_results)
    all_results = completed + additional
    return SampledObjectiveEvaluationIR.create(
        evaluation_id=f"{run_id}.sampled.{evaluation_index:06d}",
        evaluation_index=evaluation_index,
        parameter_bind=parameter_bind,
        plan=plan,
        group_results=completed,
        additional_group_results=additional,
        adaptive_allocation=adaptive_allocation,
        metadata={
            "algorithm": "vqe",
            "algorithm_id": algorithm_id,
            "algorithm_run_id": run_id,
            "root_seed": root_seed,
            "measurement_plan_hash": plan.plan_hash,
            "result_ids": [item.result_id for item in all_results],
            "result_hashes": [item.result_hash for item in all_results],
            "noise_model_hash": None if noise is None else noise.stable_hash(),
            "requested_options_hash": (
                None if options is None else options.stable_hash()
            ),
            "readout_calibration_hash": (
                None
                if plan.config.mitigation is None
                else plan.config.mitigation.calibration.calibration_hash
            ),
        },
    )


def _observable_basis(
    observable: Observable,
    logical_order: tuple[str, ...],
) -> dict[str, PauliBasis]:
    basis = {target: PauliBasis.I for target in logical_order}
    for factor in observable.terms:
        if factor.target not in basis:
            raise ValueError(
                "Observable target is outside the Hamiltonian logical order."
            )
        if factor.basis is not PauliBasis.I:
            basis[factor.target] = factor.basis
    return basis


def _qwc_compatible(
    left: Mapping[str, PauliBasis],
    right: Mapping[str, PauliBasis],
) -> bool:
    return all(
        left[target] is PauliBasis.I
        or right[target] is PauliBasis.I
        or left[target] is right[target]
        for target in left
    )


def _merge_basis(
    destination: dict[str, PauliBasis],
    source: Mapping[str, PauliBasis],
) -> None:
    for target, basis in source.items():
        if destination[target] is PauliBasis.I:
            destination[target] = basis


def _required_gates(groups: tuple[PauliMeasurementGroupIR, ...]) -> tuple[str, ...]:
    required = {"measure"}
    for group in groups:
        if PauliBasis.X in group.basis_by_target.values():
            required.add("h")
        if PauliBasis.Y in group.basis_by_target.values():
            required.update({"sdg", "h"})
    return tuple(name for name in _REQUIRED_GATE_ORDER if name in required)


def _allocate_group_shots(
    groups: tuple[PauliMeasurementGroupIR, ...],
    config: PauliMeasurementConfig,
) -> tuple[int, ...]:
    """Allocate a fixed total budget without changing the QWC Job count.

    For one group ``g``, the single-shot group energy is bounded in magnitude
    by the L1 norm of its coefficients. Allocating shots in proportion to that
    norm therefore minimizes the corresponding continuous worst-case variance
    bound. A two-shot lower bound keeps every sample variance well-defined.
    """
    if not groups:
        return ()
    if config.allocation == "uniform":
        return tuple(config.shots_per_group for _ in groups)
    if config.allocation == "pilot_variance":
        return tuple(config.resolved_pilot_shots_per_group for _ in groups)

    total_budget = len(groups) * config.shots_per_group
    weights = tuple(
        sum(abs(term.coefficient) for term in group.terms) for group in groups
    )
    return _allocate_weighted_budget(
        weights,
        total_budget=total_budget,
        lower_bounds=tuple(2 for _ in groups),
    )


def _allocate_weighted_budget(
    weights: tuple[float, ...],
    *,
    total_budget: int,
    lower_bounds: tuple[int, ...],
) -> tuple[int, ...]:
    """Allocate integer shots for a separable variance proxy.

    The continuous optimum for ``sum(weight**2 / shots)`` assigns shots in
    proportion to ``weight``. Lower bounds are applied before integer remainder
    shots are placed by their exact marginal reduction of that proxy.
    """
    if not weights or len(weights) != len(lower_bounds):
        raise ValueError("weights and lower_bounds must have equal non-zero size.")
    if any(not math.isfinite(value) or value < 0.0 for value in weights):
        raise ValueError("allocation weights must be finite and non-negative.")
    if not any(value > 0.0 for value in weights):
        raise ValueError("allocation weights must contain a positive value.")
    if any(
        not isinstance(value, int) or isinstance(value, bool) or value < 2
        for value in lower_bounds
    ):
        raise ValueError("allocation lower bounds must be integers of at least two.")
    if total_budget < sum(lower_bounds):
        raise ValueError("total budget cannot satisfy allocation lower bounds.")

    # Solve the continuous allocation with lower bounds by removing groups
    # whose proportional share would be below their required stage minimum.
    active = set(range(len(weights)))
    targets = [float(value) for value in lower_bounds]
    remaining_budget = total_budget
    while active:
        active_weight = sum(weights[index] for index in active)
        scale = remaining_budget / active_weight
        below_minimum = tuple(
            index
            for index in sorted(active)
            if scale * weights[index] < lower_bounds[index]
        )
        if not below_minimum:
            for index in active:
                targets[index] = scale * weights[index]
            break
        for index in below_minimum:
            active.remove(index)
            remaining_budget -= lower_bounds[index]

    allocated = [
        max(lower_bound, math.floor(value))
        for value, lower_bound in zip(targets, lower_bounds)
    ]
    remainder = total_budget - sum(allocated)
    for _ in range(remainder):
        # Adding one shot to n samples reduces the coefficient-only variance
        # bound by weight^2 / (n * (n + 1)). Ties prefer the lower group index.
        index = max(
            range(len(weights)),
            key=lambda item: (
                weights[item] ** 2 / (allocated[item] * (allocated[item] + 1)),
                -item,
            ),
        )
        allocated[index] += 1
    return tuple(allocated)


@dataclass(frozen=True)
class _PooledGroupStatistics:
    """Count-derived group estimate after one or two Backend executions."""

    shots: int
    counts: Mapping[str, int]
    term_expectations: Mapping[str, float]
    term_standard_errors: Mapping[str, float]
    energy_mean: float
    energy_standard_error: float


def _pooled_group_statistics(
    groups: tuple[PauliMeasurementGroupIR, ...],
    initial_results: tuple[PauliMeasurementGroupResultIR, ...],
    additional_results: tuple[PauliMeasurementGroupResultIR, ...],
) -> tuple[_PooledGroupStatistics, ...]:
    """Merge stage counts per group and recompute every statistical fact."""
    if len(initial_results) != len(groups):
        raise ValueError("initial results must cover every measurement group.")
    if additional_results and len(additional_results) != len(groups):
        raise ValueError("additional results must cover every measurement group.")
    pooled: list[_PooledGroupStatistics] = []
    for index, group in enumerate(groups):
        executions = [initial_results[index]]
        if additional_results:
            executions.append(additional_results[index])
        counts: dict[str, int] = {}
        for execution in executions:
            if execution.group != group:
                raise ValueError("group executions must follow measurement groups.")
            for bitstring, count in execution.counts.items():
                counts[bitstring] = counts.get(bitstring, 0) + count
        shots = sum(execution.shots for execution in executions)
        statistics = _group_statistics(group, counts, shots=shots)
        pooled.append(
            _PooledGroupStatistics(
                shots=shots,
                counts=MappingProxyType(dict(sorted(counts.items()))),
                term_expectations=MappingProxyType(statistics[0]),
                term_standard_errors=MappingProxyType(statistics[1]),
                energy_mean=statistics[2],
                energy_standard_error=statistics[3],
            )
        )
    return tuple(pooled)


def _mitigated_group_statistics(
    groups: tuple[PauliMeasurementGroupIR, ...],
    pooled: tuple[_PooledGroupStatistics, ...],
    initial_results: tuple[PauliMeasurementGroupResultIR, ...],
    additional_results: tuple[PauliMeasurementGroupResultIR, ...],
    mitigation: ReadoutMitigationConfig,
) -> tuple[ReadoutMitigatedGroupStatisticsIR, ...]:
    """从每组池化后的 raw counts 重算缓解统计与来源 hash。"""
    output: list[ReadoutMitigatedGroupStatisticsIR] = []
    for index, (group, estimate) in enumerate(zip(groups, pooled)):
        source_hashes = [initial_results[index].group_result_hash]
        if additional_results:
            source_hashes.append(additional_results[index].group_result_hash)
        output.append(
            compute_readout_mitigated_group_statistics(
                group,
                estimate.counts,
                shots=estimate.shots,
                config=mitigation,
                source_group_result_hashes=tuple(source_hashes),
            )
        )
    return tuple(output)


def _group_statistics(
    group: PauliMeasurementGroupIR,
    raw_counts: Mapping[str, int],
    *,
    shots: int,
) -> tuple[dict[str, float], dict[str, float], float, float]:
    counts = _normalize_counts(raw_counts, logical_width=len(group.logical_order))
    if sum(counts.values()) != shots:
        raise ValueError("counts must sum to shots.")
    index_by_target = {
        target: index for index, target in enumerate(group.logical_order)
    }
    sums = {term.term_id: 0.0 for term in group.terms}
    group_sum = 0.0
    group_square_sum = 0.0
    for bitstring, count in counts.items():
        group_value = 0.0
        for term in group.terms:
            value = 1
            for factor in term.observable.terms:
                if factor.basis is not PauliBasis.I:
                    value *= (
                        1 if bitstring[index_by_target[factor.target]] == "0" else -1
                    )
            sums[term.term_id] += value * count
            group_value += term.coefficient * value
        group_sum += group_value * count
        group_square_sum += group_value * group_value * count
    expectations = {term_id: value / shots for term_id, value in sums.items()}
    term_errors = {
        term_id: math.sqrt(max(0.0, 1.0 - value * value) / (shots - 1))
        for term_id, value in expectations.items()
    }
    energy_mean = group_sum / shots
    centered_sum = max(0.0, group_square_sum - shots * energy_mean * energy_mean)
    sample_variance = centered_sum / (shots - 1)
    energy_standard_error = math.sqrt(sample_variance / shots)
    return expectations, term_errors, energy_mean, energy_standard_error


def _group_observable_batch(
    group: PauliMeasurementGroupIR,
    *,
    statistics: tuple[dict[str, float], dict[str, float], float, float],
    shots: int,
    source_hash: str,
) -> ObservableBatchResultIR:
    """Build the sampled observable facts owned by one QWC Backend Result."""
    expectations, errors, _, _ = statistics
    items = tuple(
        ObservableResultIR(
            observable=term.observable,
            expectation=expectations[term.term_id],
            variance=max(0.0, 1.0 - expectations[term.term_id] ** 2),
            standard_error=errors[term.term_id],
            sample_count=shots,
            source_kind=ObservableSourceKind.MEASUREMENT_PLAN,
            source_hash=source_hash,
            estimator_kind=ObservableEstimatorKind.SAMPLE_MEAN,
        )
        for term in group.terms
    )
    return ObservableBatchResultIR.from_results(
        ObservableSet(item.observable for item in items),
        items,
    )


def _require_execution_plan_match(
    actual: SimulationExecutionPlan,
    expected: SimulationExecutionPlan,
) -> None:
    """Reject numerical plan drift while allowing fresh host telemetry."""
    if actual.execution_contract() != expected.execution_contract():
        raise RuntimeError(
            "Sampled objective SimulationPlan changed between preflight and execution."
        )


def _sampled_contributions(
    groups: tuple[PauliMeasurementGroupIR, ...],
    estimates: tuple[_PooledGroupStatistics, ...],
) -> tuple[HamiltonianContributionIR, ...]:
    indexed: dict[int, HamiltonianContributionIR] = {}
    for group, estimate in zip(groups, estimates):
        for term in group.terms:
            expectation = estimate.term_expectations[term.term_id]
            indexed[term.term_index] = HamiltonianContributionIR(
                term_id=term.term_id,
                observable_name=term.observable.name,
                coefficient=term.coefficient,
                expectation=expectation,
                contribution=term.coefficient * expectation,
            )
    return tuple(indexed[index] for index in range(len(indexed)))


def _mitigated_contributions(
    groups: tuple[PauliMeasurementGroupIR, ...],
    estimates: tuple[ReadoutMitigatedGroupStatisticsIR, ...],
) -> tuple[ReadoutMitigatedContributionIR, ...]:
    """按 Hamiltonian term order 构造允许 quasi expectation 的贡献。"""
    indexed: dict[int, ReadoutMitigatedContributionIR] = {}
    for group, estimate in zip(groups, estimates):
        for term in group.terms:
            expectation = estimate.term_expectations[term.term_id]
            indexed[term.term_index] = ReadoutMitigatedContributionIR(
                term_id=term.term_id,
                observable_name=term.observable.name,
                coefficient=term.coefficient,
                expectation=expectation,
                contribution=term.coefficient * expectation,
            )
    return tuple(indexed[index] for index in range(len(indexed)))


def _measurement_plan_hash(value: PauliMeasurementPlanIR | Mapping[str, Any]) -> str:
    if isinstance(value, PauliMeasurementPlanIR):
        material = {
            key: getattr(value, key)
            for key in (
                "source_circuit_hash",
                "hamiltonian_hash",
                "hamiltonian_id",
                "constant",
                "logical_order",
                "config",
                "groups",
                "shots_by_group",
                "required_gates",
                "backend_execution_count",
                "total_shots",
                "schema_version",
            )
        }
    else:
        material = dict(value)
    return hashlib.sha256(stable_json(material).encode("utf-8")).hexdigest()


def _group_result_hash(
    value: PauliMeasurementGroupResultIR | Mapping[str, Any],
) -> str:
    fields = (
        "group",
        "seed",
        "shots",
        "counts",
        "term_expectations",
        "term_standard_errors",
        "energy_mean",
        "energy_standard_error",
        "backend_id",
        "backend_job_id",
        "result_id",
        "result_hash",
        "program_hash",
        "wall_time_seconds",
        "execution_evidence",
        "schema_version",
    )
    material = (
        {key: getattr(value, key) for key in fields}
        if isinstance(value, PauliMeasurementGroupResultIR)
        else dict(value)
    )
    return hashlib.sha256(stable_json(material).encode("utf-8")).hexdigest()


def _adaptive_allocation_hash(
    value: AdaptiveShotAllocationIR | Mapping[str, Any],
) -> str:
    fields = (
        "pilot_shots_by_group",
        "pilot_energy_variances",
        "allocation_weights",
        "additional_shots_by_group",
        "final_shots_by_group",
        "fallback",
        "total_shots",
        "backend_execution_count",
        "schema_version",
    )
    material = (
        {key: getattr(value, key) for key in fields}
        if isinstance(value, AdaptiveShotAllocationIR)
        else dict(value)
    )
    return hashlib.sha256(stable_json(material).encode("utf-8")).hexdigest()


def _normalize_counts(
    value: Mapping[str, int],
    *,
    logical_width: int,
) -> dict[str, int]:
    if not isinstance(value, Mapping):
        raise TypeError("counts must be a mapping.")
    counts: dict[str, int] = {}
    for bitstring, count in value.items():
        if (
            not isinstance(bitstring, str)
            or len(bitstring) != logical_width
            or any(bit not in {"0", "1"} for bit in bitstring)
        ):
            raise ValueError("counts keys must match the logical bit width.")
        if not isinstance(count, int) or isinstance(count, bool) or count <= 0:
            raise ValueError("counts values must be positive integers.")
        counts[bitstring] = count
    if not counts:
        raise ValueError("counts must not be empty.")
    return dict(sorted(counts.items()))


def _float_mapping(
    value: Mapping[str, float],
    name: str,
    *,
    non_negative: bool = False,
) -> dict[str, float]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{name} must be a mapping.")
    output: dict[str, float] = {}
    for key, raw in value.items():
        _require_text(key, f"{name} key")
        output[key] = (
            _finite_non_negative_float(raw, f"{name}.{key}")
            if non_negative
            else _finite_float(raw, f"{name}.{key}")
        )
    return output


def _mapping_close(left: Mapping[str, float], right: Mapping[str, float]) -> bool:
    return set(left) == set(right) and all(
        math.isclose(left[key], right[key], rel_tol=0.0, abs_tol=_FLOAT_TOLERANCE)
        for key in left
    )


def _shot_tuple(value: Iterable[int], name: str) -> tuple[int, ...]:
    shots = tuple(value)
    if any(
        not isinstance(item, int) or isinstance(item, bool) or item < 2
        for item in shots
    ):
        raise ValueError(f"{name} must contain integers of at least two.")
    return shots


def _non_negative_float_tuple(
    value: Iterable[float],
    name: str,
    *,
    expected_size: int,
) -> tuple[float, ...]:
    values = tuple(
        _finite_non_negative_float(item, f"{name}[{index}]")
        for index, item in enumerate(value)
    )
    if len(values) != expected_size:
        raise ValueError(f"{name} must match the measurement group count.")
    return values


def _float_sequence_close(
    left: tuple[float, ...],
    right: tuple[float, ...],
) -> bool:
    return len(left) == len(right) and all(
        math.isclose(a, b, rel_tol=0.0, abs_tol=_FLOAT_TOLERANCE)
        for a, b in zip(left, right)
    )


def _require_text(value: object, name: str) -> None:
    if not isinstance(value, str) or not value.strip() or value != value.strip():
        raise ValueError(f"{name} must be a non-empty trimmed string.")


def _require_unique_text(values: tuple[str, ...], name: str) -> None:
    if (
        not values
        or any(
            not isinstance(value, str) or not value.strip() or value != value.strip()
            for value in values
        )
        or len(values) != len(set(values))
    ):
        raise ValueError(f"{name} must contain unique non-empty strings.")


def _require_non_negative_int(value: object, name: str) -> None:
    if not isinstance(value, int) or isinstance(value, bool) or value < 0:
        raise ValueError(f"{name} must be a non-negative integer.")


def _require_seed(value: object, name: str) -> None:
    _require_non_negative_int(value, name)


def _finite_float(value: object, name: str) -> float:
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        raise TypeError(f"{name} must be a real number.")
    number = float(value)
    if not math.isfinite(number):
        raise ValueError(f"{name} must be finite.")
    return number


def _finite_non_negative_float(value: object, name: str) -> float:
    number = _finite_float(value, name)
    if number < 0.0:
        raise ValueError(f"{name} must be non-negative.")
    return number


def _require_digest(value: object, name: str) -> None:
    if not isinstance(value, str) or _DIGEST_PATTERN.fullmatch(value) is None:
        raise ValueError(f"{name} must be a lowercase SHA-256 digest.")


def _require_schema(value: object) -> None:
    if value != MEASUREMENT_SCHEMA_VERSION:
        raise ValueError(f"Unsupported Pauli measurement schema: {value!r}.")


def _mapping(value: object, name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{name} must be an object.")
    return value


def _sequence(value: object, name: str) -> tuple[Any, ...]:
    if not isinstance(value, (list, tuple)):
        raise TypeError(f"{name} must be an array.")
    return tuple(value)


def _json_object(text: str, name: str) -> Mapping[str, Any]:
    import json

    data = json.loads(text)
    if not isinstance(data, Mapping):
        raise TypeError(f"{name} JSON must contain an object.")
    return data
