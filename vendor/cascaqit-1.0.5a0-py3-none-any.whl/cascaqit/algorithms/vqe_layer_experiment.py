"""Repeated layer experiments for standalone VQE."""

from __future__ import annotations

import hashlib
import json
import math
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field, replace
from os import PathLike
from typing import TYPE_CHECKING, Any, Literal

from cascaqit.algorithms._layer_statistics import (
    confidence_level as _confidence_level,
)
from cascaqit.algorithms._layer_statistics import (
    derive_layer_run_seed,
    paired_improvement_summary,
    sample_summary,
)
from cascaqit.algorithms.ansatz import transfer_vqe_parameters
from cascaqit.algorithms.measurement import (
    PauliMeasurementConfig,
    SampledObjectiveEvaluationIR,
)
from cascaqit.algorithms.models import OptimizerConfig, VariationalResult
from cascaqit.algorithms.sampled_selection import SampledSelectionConfig
from cascaqit.native_ir.base import IRMixin, stable_json

if TYPE_CHECKING:
    from cascaqit.visualization import ExperimentReport

__all__ = [
    "VQE_LAYER_EXPERIMENT_SCHEMA_VERSION",
    "VQELayerStatisticsIR",
    "VQEPairedImprovementIR",
    "VQERepeatedLayerExperimentResult",
    "VQERepeatedLayerRunIR",
    "VQERepeatedLayerStepIR",
    "build_vqe_repeated_layer_experiment_result",
    "derive_vqe_layer_run_seed",
]

VQE_LAYER_EXPERIMENT_SCHEMA_VERSION = "cascaqit.algorithms.vqe_layer_experiment.v2"
VQE_LAYER_OBJECTIVE_TOLERANCE = 1e-12
_STATISTIC_TOLERANCE = 1e-12


def vqe_layer_objective(result: VariationalResult[Any]) -> float:
    """Return the layer-selection estimator for one completed VQE run."""
    if result.sampled_selection is not None:
        return float(result.sampled_selection.selected_candidate.energy)
    return float(result.selected_evaluation.energy)


@dataclass(frozen=True)
class VQERepeatedLayerRunIR(IRMixin):
    """One complete standalone VQE optimization in a layer experiment."""

    run_id: str
    layers: int
    repeat_index: int
    seed: int
    result: VariationalResult[Any]
    schema_version: str = VQE_LAYER_EXPERIMENT_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_schema(self.schema_version)
        _positive_int(self.layers, "layers")
        _non_negative_int(self.repeat_index, "repeat_index")
        _non_negative_int(self.seed, "seed")
        if not isinstance(self.result, VariationalResult):
            raise TypeError("result must be VariationalResult.")
        if self.result.algorithm_kind != "vqe":
            raise ValueError("repeated VQE runs require VQE results.")
        if self.result.ansatz.layers != self.layers:
            raise ValueError("result ansatz layer count does not match layers.")
        expected = _run_id(
            layers=self.layers,
            repeat_index=self.repeat_index,
            seed=self.seed,
            result_hash=self.result.stable_hash(),
        )
        if self.run_id != expected:
            raise ValueError("run_id does not match the repeated VQE run facts.")

    @classmethod
    def create(
        cls,
        *,
        layers: int,
        repeat_index: int,
        seed: int,
        result: VariationalResult[Any],
    ) -> VQERepeatedLayerRunIR:
        """Create one run with a deterministic identity."""
        return cls(
            run_id=_run_id(
                layers=layers,
                repeat_index=repeat_index,
                seed=seed,
                result_hash=result.stable_hash(),
            ),
            layers=layers,
            repeat_index=repeat_index,
            seed=seed,
            result=result,
        )

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> VQERepeatedLayerRunIR:
        """Restore one repeated VQE run from JSON-compatible data."""
        return cls(
            run_id=str(data["run_id"]),
            layers=int(data["layers"]),
            repeat_index=int(data["repeat_index"]),
            seed=int(data["seed"]),
            result=VariationalResult.from_dict(_mapping(data["result"], "result")),
            schema_version=str(
                data.get("schema_version", VQE_LAYER_EXPERIMENT_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class VQELayerStatisticsIR(IRMixin):
    """Recomputable objective statistics for all VQE repeats at one layer."""

    layers: int
    runs: tuple[VQERepeatedLayerRunIR, ...]
    sample_count: int
    mean_objective: float
    sample_variance: float
    standard_error: float
    confidence_level: float
    confidence_interval_low: float
    confidence_interval_high: float
    schema_version: str = VQE_LAYER_EXPERIMENT_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_schema(self.schema_version)
        _positive_int(self.layers, "layers")
        object.__setattr__(self, "runs", tuple(self.runs))
        if len(self.runs) < 2:
            raise ValueError("layer statistics require at least two repeated runs.")
        if any(not isinstance(run, VQERepeatedLayerRunIR) for run in self.runs):
            raise TypeError("runs must contain VQERepeatedLayerRunIR values.")
        if any(run.layers != self.layers for run in self.runs):
            raise ValueError("all repeated runs must match statistics layers.")
        if tuple(run.repeat_index for run in self.runs) != tuple(range(len(self.runs))):
            raise ValueError("run repeat_index values must be contiguous from zero.")
        if len({run.seed for run in self.runs}) != len(self.runs):
            raise ValueError("run seeds must be unique within one layer.")
        level = _confidence_level(self.confidence_level)
        object.__setattr__(self, "confidence_level", level)
        expected = sample_summary(self.objectives, confidence=level)
        if self.sample_count != len(self.runs):
            raise ValueError("sample_count does not match runs.")
        _require_statistic(self.mean_objective, expected.mean, "mean_objective")
        _require_statistic(self.sample_variance, expected.variance, "sample_variance")
        _require_statistic(
            self.standard_error, expected.standard_error, "standard_error"
        )
        _require_statistic(
            self.confidence_interval_low,
            expected.interval_low,
            "confidence_interval_low",
        )
        _require_statistic(
            self.confidence_interval_high,
            expected.interval_high,
            "confidence_interval_high",
        )

    @classmethod
    def create(
        cls,
        runs: Sequence[VQERepeatedLayerRunIR],
        *,
        confidence_level: float,
    ) -> VQELayerStatisticsIR:
        """Build checked layer statistics from completed VQE runs."""
        normalized = tuple(runs)
        if not normalized:
            raise ValueError("runs must not be empty.")
        level = _confidence_level(confidence_level)
        summary = sample_summary(
            tuple(vqe_layer_objective(run.result) for run in normalized),
            confidence=level,
        )
        return cls(
            layers=normalized[0].layers,
            runs=normalized,
            sample_count=len(normalized),
            mean_objective=summary.mean,
            sample_variance=summary.variance,
            standard_error=summary.standard_error,
            confidence_level=level,
            confidence_interval_low=summary.interval_low,
            confidence_interval_high=summary.interval_high,
        )

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> VQELayerStatisticsIR:
        """Restore VQE layer statistics and recheck every derived value."""
        return cls(
            layers=int(data["layers"]),
            runs=tuple(
                VQERepeatedLayerRunIR.from_dict(_mapping(item, "run"))
                for item in _sequence(data["runs"], "runs")
            ),
            sample_count=int(data["sample_count"]),
            mean_objective=float(data["mean_objective"]),
            sample_variance=float(data["sample_variance"]),
            standard_error=float(data["standard_error"]),
            confidence_level=float(data["confidence_level"]),
            confidence_interval_low=float(data["confidence_interval_low"]),
            confidence_interval_high=float(data["confidence_interval_high"]),
            schema_version=str(
                data.get("schema_version", VQE_LAYER_EXPERIMENT_SCHEMA_VERSION)
            ),
        )

    @property
    def objectives(self) -> tuple[float, ...]:
        """Return the independently comparable objective for every repeat."""
        return tuple(vqe_layer_objective(run.result) for run in self.runs)


@dataclass(frozen=True)
class VQEPairedImprovementIR(IRMixin):
    """Paired objective decrease from an incumbent to a deeper VQE layer."""

    incumbent_layer: int
    candidate_layer: int
    differences: tuple[float, ...]
    sample_count: int
    mean_improvement: float
    sample_variance: float
    standard_error: float
    confidence_level: float
    lower_confidence_bound: float
    schema_version: str = VQE_LAYER_EXPERIMENT_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_schema(self.schema_version)
        _positive_int(self.incumbent_layer, "incumbent_layer")
        _positive_int(self.candidate_layer, "candidate_layer")
        if self.incumbent_layer >= self.candidate_layer:
            raise ValueError("incumbent_layer must be shallower than candidate_layer.")
        object.__setattr__(
            self,
            "differences",
            tuple(_finite(value, "difference") for value in self.differences),
        )
        if len(self.differences) < 2:
            raise ValueError("paired improvement requires at least two differences.")
        level = _confidence_level(self.confidence_level)
        object.__setattr__(self, "confidence_level", level)
        expected = paired_improvement_summary(
            self.differences,
            confidence=level,
        )
        if self.sample_count != len(self.differences):
            raise ValueError("sample_count does not match paired differences.")
        _require_statistic(self.mean_improvement, expected.mean, "mean_improvement")
        _require_statistic(self.sample_variance, expected.variance, "sample_variance")
        _require_statistic(
            self.standard_error, expected.standard_error, "standard_error"
        )
        _require_statistic(
            self.lower_confidence_bound,
            expected.interval_low,
            "lower_confidence_bound",
        )

    @classmethod
    def create(
        cls,
        incumbent: VQELayerStatisticsIR,
        candidate: VQELayerStatisticsIR,
        *,
        confidence_level: float,
    ) -> VQEPairedImprovementIR:
        """Compare two layers by their stable repeat indices."""
        if not isinstance(incumbent, VQELayerStatisticsIR) or not isinstance(
            candidate, VQELayerStatisticsIR
        ):
            raise TypeError("incumbent and candidate must be VQE layer statistics.")
        if incumbent.layers >= candidate.layers:
            raise ValueError("incumbent must be shallower than candidate.")
        if incumbent.sample_count != candidate.sample_count:
            raise ValueError("paired layers must have the same sample count.")
        differences = tuple(
            left - right
            for left, right in zip(incumbent.objectives, candidate.objectives)
        )
        summary = paired_improvement_summary(
            differences,
            confidence=_confidence_level(confidence_level),
        )
        return cls(
            incumbent_layer=incumbent.layers,
            candidate_layer=candidate.layers,
            differences=differences,
            sample_count=len(differences),
            mean_improvement=summary.mean,
            sample_variance=summary.variance,
            standard_error=summary.standard_error,
            confidence_level=float(confidence_level),
            lower_confidence_bound=summary.interval_low,
        )

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> VQEPairedImprovementIR:
        """Restore paired VQE improvement evidence."""
        return cls(
            incumbent_layer=int(data["incumbent_layer"]),
            candidate_layer=int(data["candidate_layer"]),
            differences=tuple(float(item) for item in data["differences"]),
            sample_count=int(data["sample_count"]),
            mean_improvement=float(data["mean_improvement"]),
            sample_variance=float(data["sample_variance"]),
            standard_error=float(data["standard_error"]),
            confidence_level=float(data["confidence_level"]),
            lower_confidence_bound=float(data["lower_confidence_bound"]),
            schema_version=str(
                data.get("schema_version", VQE_LAYER_EXPERIMENT_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class VQERepeatedLayerStepIR(IRMixin):
    """One VQE layer's repeated evidence and selection state."""

    layers: int
    statistics: VQELayerStatisticsIR
    comparison: VQEPairedImprovementIR | None
    material_improvement: bool
    incumbent_layer: int
    no_improvement_count: int
    schema_version: str = VQE_LAYER_EXPERIMENT_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_schema(self.schema_version)
        _positive_int(self.layers, "layers")
        if not isinstance(self.statistics, VQELayerStatisticsIR):
            raise TypeError("statistics must be VQELayerStatisticsIR.")
        if self.statistics.layers != self.layers:
            raise ValueError("statistics layer count does not match step layers.")
        if self.comparison is not None and not isinstance(
            self.comparison, VQEPairedImprovementIR
        ):
            raise TypeError("comparison must be VQEPairedImprovementIR or None.")
        if not isinstance(self.material_improvement, bool):
            raise TypeError("material_improvement must be boolean.")
        _positive_int(self.incumbent_layer, "incumbent_layer")
        if self.incumbent_layer > self.layers:
            raise ValueError("incumbent_layer cannot exceed the executed layer.")
        _non_negative_int(self.no_improvement_count, "no_improvement_count")

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> VQERepeatedLayerStepIR:
        """Restore one repeated VQE layer step."""
        raw_comparison = data.get("comparison")
        return cls(
            layers=int(data["layers"]),
            statistics=VQELayerStatisticsIR.from_dict(
                _mapping(data["statistics"], "statistics")
            ),
            comparison=(
                None
                if raw_comparison is None
                else VQEPairedImprovementIR.from_dict(
                    _mapping(raw_comparison, "comparison")
                )
            ),
            material_improvement=data["material_improvement"],
            incumbent_layer=int(data["incumbent_layer"]),
            no_improvement_count=int(data["no_improvement_count"]),
            schema_version=str(
                data.get("schema_version", VQE_LAYER_EXPERIMENT_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class VQERepeatedLayerExperimentResult(IRMixin):
    """Completed standalone VQE layer search with recomputable evidence."""

    experiment_id: str
    algorithm_id: str
    hamiltonian_hash: str
    logical_order: tuple[str, ...]
    optimizer: OptimizerConfig
    max_layers: int
    repeats: int
    confidence_level: float
    min_improvement: float
    patience: int
    final_shots: int
    seed: int
    measurement: PauliMeasurementConfig | None
    sampled_selection: SampledSelectionConfig | None
    steps: tuple[VQERepeatedLayerStepIR, ...]
    selected_step_index: int
    stop_reason: Literal["max_layers_reached", "patience_exhausted"]
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = VQE_LAYER_EXPERIMENT_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_schema(self.schema_version)
        _require_text(self.experiment_id, "experiment_id")
        _require_text(self.algorithm_id, "algorithm_id")
        _require_digest(self.hamiltonian_hash, "hamiltonian_hash")
        object.__setattr__(self, "logical_order", tuple(self.logical_order))
        _require_unique_text(self.logical_order, "logical_order")
        _validate_base_optimizer(self.optimizer)
        _positive_int(self.max_layers, "max_layers")
        if not isinstance(self.repeats, int) or isinstance(self.repeats, bool):
            raise TypeError("repeats must be an integer.")
        if self.repeats < 2:
            raise ValueError("repeats must be at least two.")
        object.__setattr__(
            self, "confidence_level", _confidence_level(self.confidence_level)
        )
        threshold = _finite(self.min_improvement, "min_improvement")
        if threshold < 0.0:
            raise ValueError("min_improvement must be non-negative.")
        object.__setattr__(self, "min_improvement", threshold)
        _positive_int(self.patience, "patience")
        _positive_int(self.final_shots, "final_shots")
        _non_negative_int(self.seed, "seed")
        if self.measurement is not None and not isinstance(
            self.measurement, PauliMeasurementConfig
        ):
            raise TypeError("measurement must be PauliMeasurementConfig or None.")
        if self.sampled_selection is not None and not isinstance(
            self.sampled_selection, SampledSelectionConfig
        ):
            raise TypeError(
                "sampled_selection must be SampledSelectionConfig or None."
            )
        if (self.measurement is None) != (self.sampled_selection is None):
            raise ValueError(
                "measurement and sampled_selection must be configured together."
            )
        object.__setattr__(self, "steps", tuple(self.steps))
        if not self.steps:
            raise ValueError("steps must contain at least one executed layer.")
        if len(self.steps) > self.max_layers:
            raise ValueError("executed layer count cannot exceed max_layers.")
        if tuple(step.layers for step in self.steps) != tuple(
            range(1, len(self.steps) + 1)
        ):
            raise ValueError("steps must contain contiguous layers starting at one.")
        if any(step.statistics.sample_count != self.repeats for step in self.steps):
            raise ValueError("every layer must contain the configured repeat count.")
        if (
            not isinstance(self.selected_step_index, int)
            or isinstance(self.selected_step_index, bool)
            or not 0 <= self.selected_step_index < len(self.steps)
        ):
            raise ValueError("selected_step_index is outside steps.")
        if self.stop_reason not in {"max_layers_reached", "patience_exhausted"}:
            raise ValueError(f"Unsupported stop_reason: {self.stop_reason!r}.")
        expected_metadata = {
            "selection_rule": "paired_student_t_lower_confidence_bound",
            "warm_start": "previous_layer_same_repeat_index",
            "global_optimality_claim": False,
            "layer_objective_source": (
                "optimizer_selected_energy"
                if self.measurement is None
                else "independent_confirmation_mean"
            ),
        }
        if not isinstance(self.metadata, dict) or any(
            self.metadata.get(key) != value for key, value in expected_metadata.items()
        ):
            raise ValueError("repeated VQE layer experiment metadata is invalid.")
        object.__setattr__(self, "metadata", dict(self.metadata))
        self._validate_run_facts()
        expected_steps, expected_selected, expected_reason = _step_evidence(
            tuple(step.statistics for step in self.steps),
            max_layers=self.max_layers,
            confidence_level=self.confidence_level,
            min_improvement=self.min_improvement,
            patience=self.patience,
        )
        if self.steps != expected_steps:
            raise ValueError("repeated VQE step evidence does not match results.")
        if self.selected_step_index != expected_selected:
            raise ValueError("selected_step_index does not match statistical evidence.")
        if self.stop_reason != expected_reason:
            raise ValueError("stop_reason does not match repeated VQE history.")
        expected_id = _experiment_id(
            self.steps,
            optimizer=self.optimizer,
            max_layers=self.max_layers,
            repeats=self.repeats,
            confidence_level=self.confidence_level,
            min_improvement=self.min_improvement,
            patience=self.patience,
            final_shots=self.final_shots,
            seed=self.seed,
            measurement=self.measurement,
            sampled_selection=self.sampled_selection,
        )
        if self.experiment_id != expected_id:
            raise ValueError("experiment_id does not match repeated VQE facts.")

    @property
    def selected_layers(self) -> int:
        """Return the shallowest layer supported by the configured evidence."""
        return self.steps[self.selected_step_index].layers

    @property
    def selected_statistics(self) -> VQELayerStatisticsIR:
        """Return all repeated runs and statistics at the selected layer."""
        return self.steps[self.selected_step_index].statistics

    @property
    def selected_run(self) -> VQERepeatedLayerRunIR:
        """Return the lowest-objective run at the statistically selected layer."""
        return min(
            self.selected_statistics.runs,
            key=lambda run: (
                vqe_layer_objective(run.result),
                run.repeat_index,
            ),
        )

    @property
    def selected_result(self) -> VariationalResult[Any]:
        """Return the complete VQE result chosen to represent the selected layer."""
        return self.selected_run.result

    @property
    def results(self) -> tuple[VariationalResult[Any], ...]:
        """Return every complete VQE result in layer and repeat order."""
        return tuple(run.result for step in self.steps for run in step.statistics.runs)

    @property
    def total_optimization_count(self) -> int:
        """Return the number of complete optimizer runs."""
        return len(self.results)

    @property
    def total_evaluation_count(self) -> int:
        """Return objective evaluations across every complete VQE run."""
        return sum(len(result.evaluations) for result in self.results)

    @property
    def total_backend_execution_count(self) -> int:
        """Return objective and gradient Backend executions, excluding final samples."""
        return sum(
            int(result.termination.backend_execution_count or 0)
            for result in self.results
        )

    @property
    def total_confirmation_backend_execution_count(self) -> int:
        """Return Backend executions used for independent candidate confirmation."""
        return sum(
            0
            if result.sampled_selection is None
            else result.sampled_selection.backend_execution_count
            for result in self.results
        )

    @property
    def total_workflow_backend_execution_count(self) -> int:
        """Return optimization, confirmation and final-sampling executions."""
        return (
            self.total_backend_execution_count
            + self.total_confirmation_backend_execution_count
            + sum(result.final_result is not None for result in self.results)
        )

    @property
    def total_objective_shots(self) -> int:
        """Return shots consumed by sampled optimizer objective evaluations."""
        return sum(
            evaluation.total_shots
            for result in self.results
            for evaluation in result.evaluations
            if isinstance(evaluation, SampledObjectiveEvaluationIR)
        )

    @property
    def total_gradient_shots(self) -> int:
        """Return finite-shot parameter-shift samples across every VQE run."""
        return sum(
            gradient.total_shots
            for result in self.results
            for gradient in result.gradients
        )

    @property
    def total_confirmation_shots(self) -> int:
        """Return shots consumed by independent candidate confirmation."""
        return sum(
            0
            if result.sampled_selection is None
            else result.sampled_selection.total_shots
            for result in self.results
        )

    @property
    def total_final_sampling_shots(self) -> int:
        """Return shots consumed by final computational-basis sampling."""
        return sum(
            0 if result.final_result is None else result.final_result.shots
            for result in self.results
        )

    @property
    def total_workflow_shots(self) -> int:
        """Return shots across optimization, confirmation and final sampling."""
        return (
            self.total_objective_shots
            + self.total_gradient_shots
            + self.total_confirmation_shots
            + self.total_final_sampling_shots
        )

    def report(
        self,
        output: str | PathLike[str] | None = None,
        *,
        language: Literal["en", "zh"] = "en",
        title: str | None = None,
    ) -> ExperimentReport:
        """Build and optionally save the standard VQE layer experiment report."""
        from cascaqit.visualization import visualize

        report = visualize(self, profile="algorithm", title=title)
        if output is not None:
            report.save(output, language=language)
        return report

    def _validate_run_facts(self) -> None:
        seen_seeds: set[int] = set()
        definition: Mapping[str, Any] | None = None
        for step_index, step in enumerate(self.steps):
            previous = None if step_index == 0 else self.steps[step_index - 1]
            for run in step.statistics.runs:
                result = run.result
                if result.hamiltonian.stable_hash() != self.hamiltonian_hash:
                    raise ValueError("repeated VQE runs must share the Hamiltonian.")
                if result.hamiltonian.logical_order != self.logical_order:
                    raise ValueError("repeated VQE runs must share logical_order.")
                if (
                    result.evaluations[0].metadata.get("algorithm_id")
                    != self.algorithm_id
                ):
                    raise ValueError("repeated VQE runs must share algorithm_id.")
                if (
                    result.final_result is None
                    or result.final_result.shots != self.final_shots
                ):
                    raise ValueError("repeated VQE runs must share final_shots.")
                if self.measurement is None:
                    if result.sampled_selection is not None or isinstance(
                        result.evaluations[0], SampledObjectiveEvaluationIR
                    ):
                        raise ValueError(
                            "exact repeated VQE cannot contain sampled evidence."
                        )
                else:
                    if result.sampled_selection is None or not isinstance(
                        result.evaluations[0], SampledObjectiveEvaluationIR
                    ):
                        raise ValueError(
                            "sampled repeated VQE requires sampled selection evidence."
                        )
                    if result.evaluations[0].plan.config != self.measurement:
                        raise ValueError(
                            "sampled repeated VQE measurement does not match config."
                        )
                    if result.sampled_selection.config != self.sampled_selection:
                        raise ValueError(
                            "sampled repeated VQE selection does not match config."
                        )
                if result.ansatz.layer_transfer != "append_last_layer":
                    raise ValueError("repeated VQE runs require a transferable Ansatz.")
                if definition is None:
                    definition = result.ansatz.definition
                elif result.ansatz.definition != definition:
                    raise ValueError(
                        "repeated VQE runs must share one Ansatz definition."
                    )
                normalized_optimizer = replace(
                    result.optimizer,
                    seed=None,
                    bounds=(),
                    initialization="random",
                )
                if normalized_optimizer != self.optimizer:
                    raise ValueError("repeated VQE optimizer does not match config.")
                expected_seed = derive_vqe_layer_run_seed(
                    self.seed,
                    layers=step.layers,
                    repeat_index=run.repeat_index,
                )
                if run.seed != expected_seed or result.optimizer.seed != expected_seed:
                    raise ValueError(
                        "run seed does not match deterministic derivation."
                    )
                if run.seed in seen_seeds:
                    raise ValueError(
                        "derived run seeds must be unique in an experiment."
                    )
                seen_seeds.add(run.seed)
                if not result.optimization_starts:
                    raise ValueError("repeated VQE runs must retain optimizer starts.")
                first_start = result.optimization_starts[0]
                if previous is None:
                    if first_start.initialization != "explicit":
                        raise ValueError(
                            "first-layer VQE repeats require seeded explicit starts."
                        )
                    continue
                if first_start.initialization != "layerwise":
                    raise ValueError("later VQE repeats require layerwise starts.")
                prior = previous.statistics.runs[run.repeat_index].result
                expected_parameters = transfer_vqe_parameters(
                    prior.ansatz,
                    result.ansatz,
                    prior.selected_evaluation.parameter_bind.values,
                )
                if not _parameter_maps_close(
                    expected_parameters,
                    first_start.initial_parameters,
                ):
                    raise ValueError(
                        "layerwise start does not derive from the same repeat index."
                    )

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> VQERepeatedLayerExperimentResult:
        """Restore a repeated standalone VQE experiment."""
        return cls(
            experiment_id=str(data["experiment_id"]),
            algorithm_id=str(data["algorithm_id"]),
            hamiltonian_hash=str(data["hamiltonian_hash"]),
            logical_order=tuple(str(item) for item in data["logical_order"]),
            optimizer=OptimizerConfig.from_dict(
                _mapping(data["optimizer"], "optimizer")
            ),
            max_layers=int(data["max_layers"]),
            repeats=int(data["repeats"]),
            confidence_level=float(data["confidence_level"]),
            min_improvement=float(data["min_improvement"]),
            patience=int(data["patience"]),
            final_shots=int(data["final_shots"]),
            seed=int(data["seed"]),
            measurement=(
                None
                if data.get("measurement") is None
                else PauliMeasurementConfig.from_dict(
                    _mapping(data["measurement"], "measurement")
                )
            ),
            sampled_selection=(
                None
                if data.get("sampled_selection") is None
                else SampledSelectionConfig.from_dict(
                    _mapping(data["sampled_selection"], "sampled_selection")
                )
            ),
            steps=tuple(
                VQERepeatedLayerStepIR.from_dict(_mapping(item, "step"))
                for item in _sequence(data["steps"], "steps")
            ),
            selected_step_index=int(data["selected_step_index"]),
            stop_reason=data["stop_reason"],
            metadata=dict(_mapping(data.get("metadata", {}), "metadata")),
            schema_version=str(
                data.get("schema_version", VQE_LAYER_EXPERIMENT_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> VQERepeatedLayerExperimentResult:
        """Restore a repeated standalone VQE experiment from JSON."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError(
                "VQERepeatedLayerExperimentResult JSON must contain an object."
            )
        return cls.from_dict(data)


def derive_vqe_layer_run_seed(
    root_seed: int,
    *,
    layers: int,
    repeat_index: int,
) -> int:
    """Derive the stable seed for one standalone VQE layer and repeat."""
    return derive_layer_run_seed(
        root_seed,
        layers=layers,
        repeat_index=repeat_index,
        namespace=VQE_LAYER_EXPERIMENT_SCHEMA_VERSION,
    )


def build_vqe_repeated_layer_experiment_result(
    runs_by_layer: Sequence[Sequence[VQERepeatedLayerRunIR]],
    *,
    algorithm_id: str,
    optimizer: OptimizerConfig,
    max_layers: int,
    repeats: int,
    confidence_level: float,
    min_improvement: float,
    patience: int,
    final_shots: int,
    seed: int,
    measurement: PauliMeasurementConfig | None = None,
    sampled_selection: SampledSelectionConfig | None = None,
) -> VQERepeatedLayerExperimentResult:
    """Build a checked experiment from completed standalone VQE runs."""
    if not isinstance(runs_by_layer, Sequence) or isinstance(
        runs_by_layer, (str, bytes)
    ):
        raise TypeError("runs_by_layer must be a sequence of layer runs.")
    normalized = tuple(tuple(layer_runs) for layer_runs in runs_by_layer)
    if not normalized or any(not layer_runs for layer_runs in normalized):
        raise ValueError("runs_by_layer must contain completed layer runs.")
    statistics = tuple(
        VQELayerStatisticsIR.create(
            layer_runs,
            confidence_level=confidence_level,
        )
        for layer_runs in normalized
    )
    steps, selected_step_index, stop_reason = _step_evidence(
        statistics,
        max_layers=max_layers,
        confidence_level=confidence_level,
        min_improvement=min_improvement,
        patience=patience,
    )
    baseline = normalized[0][0].result
    return VQERepeatedLayerExperimentResult(
        experiment_id=_experiment_id(
            steps,
            optimizer=optimizer,
            max_layers=max_layers,
            repeats=repeats,
            confidence_level=confidence_level,
            min_improvement=min_improvement,
            patience=patience,
            final_shots=final_shots,
            seed=seed,
            measurement=measurement,
            sampled_selection=sampled_selection,
        ),
        algorithm_id=algorithm_id,
        hamiltonian_hash=baseline.hamiltonian.stable_hash(),
        logical_order=baseline.hamiltonian.logical_order,
        optimizer=optimizer,
        max_layers=max_layers,
        repeats=repeats,
        confidence_level=confidence_level,
        min_improvement=min_improvement,
        patience=patience,
        final_shots=final_shots,
        seed=seed,
        measurement=measurement,
        sampled_selection=sampled_selection,
        steps=steps,
        selected_step_index=selected_step_index,
        stop_reason=stop_reason,
        metadata={
            "selection_rule": "paired_student_t_lower_confidence_bound",
            "warm_start": "previous_layer_same_repeat_index",
            "global_optimality_claim": False,
            "layer_objective_source": (
                "optimizer_selected_energy"
                if measurement is None
                else "independent_confirmation_mean"
            ),
        },
    )


def _step_evidence(
    statistics: tuple[VQELayerStatisticsIR, ...],
    *,
    max_layers: int,
    confidence_level: float,
    min_improvement: float,
    patience: int,
) -> tuple[
    tuple[VQERepeatedLayerStepIR, ...],
    int,
    Literal["max_layers_reached", "patience_exhausted"],
]:
    _positive_int(max_layers, "max_layers")
    level = _confidence_level(confidence_level)
    threshold = _finite(min_improvement, "min_improvement")
    if threshold < 0.0:
        raise ValueError("min_improvement must be non-negative.")
    _positive_int(patience, "patience")
    if not statistics:
        raise ValueError("statistics must not be empty.")
    if len(statistics) > max_layers:
        raise ValueError("statistics count cannot exceed max_layers.")
    steps: list[VQERepeatedLayerStepIR] = []
    selected_index = 0
    no_improvement_count = 0
    for index, item in enumerate(statistics):
        layers = index + 1
        if item.layers != layers:
            raise ValueError("statistics must use contiguous layers starting at one.")
        if index == 0:
            comparison = None
            material = True
        else:
            comparison = VQEPairedImprovementIR.create(
                statistics[selected_index],
                item,
                confidence_level=level,
            )
            lower = comparison.lower_confidence_bound
            material = lower > VQE_LAYER_OBJECTIVE_TOLERANCE and lower >= threshold
            if material:
                selected_index = index
                no_improvement_count = 0
            else:
                no_improvement_count += 1
        steps.append(
            VQERepeatedLayerStepIR(
                layers=layers,
                statistics=item,
                comparison=comparison,
                material_improvement=material,
                incumbent_layer=selected_index + 1,
                no_improvement_count=no_improvement_count,
            )
        )
        if no_improvement_count >= patience and index + 1 < len(statistics):
            raise ValueError("statistics continue after configured early stop.")
    if no_improvement_count >= patience:
        reason: Literal["max_layers_reached", "patience_exhausted"] = (
            "patience_exhausted"
        )
    elif len(statistics) == max_layers:
        reason = "max_layers_reached"
    else:
        raise ValueError(
            "incomplete repeated VQE runs do not satisfy a stop condition."
        )
    return tuple(steps), selected_index, reason


def _validate_base_optimizer(optimizer: OptimizerConfig) -> None:
    if not isinstance(optimizer, OptimizerConfig):
        raise TypeError("optimizer must be OptimizerConfig.")
    if optimizer.seed is not None:
        raise ValueError("repeated VQE optimizer seed must be None.")
    if optimizer.bounds:
        raise ValueError("repeated VQE optimizer bounds must be empty.")
    if optimizer.initialization != "random":
        raise ValueError("repeated VQE optimizer initialization must be random.")


def _experiment_id(
    steps: tuple[VQERepeatedLayerStepIR, ...],
    *,
    optimizer: OptimizerConfig,
    max_layers: int,
    repeats: int,
    confidence_level: float,
    min_improvement: float,
    patience: int,
    final_shots: int,
    seed: int,
    measurement: PauliMeasurementConfig | None,
    sampled_selection: SampledSelectionConfig | None,
) -> str:
    digest = hashlib.sha256(
        stable_json(
            {
                "run_ids": tuple(
                    run.run_id for step in steps for run in step.statistics.runs
                ),
                "optimizer": optimizer,
                "max_layers": max_layers,
                "repeats": repeats,
                "confidence_level": confidence_level,
                "min_improvement": min_improvement,
                "patience": patience,
                "final_shots": final_shots,
                "seed": seed,
                "measurement": measurement,
                "sampled_selection": sampled_selection,
            }
        ).encode("utf-8")
    ).hexdigest()[:20]
    return f"vqe.repeated-layer-experiment.{digest}"


def _run_id(
    *,
    layers: int,
    repeat_index: int,
    seed: int,
    result_hash: str,
) -> str:
    digest = hashlib.sha256(
        stable_json(
            {
                "layers": layers,
                "repeat_index": repeat_index,
                "seed": seed,
                "result_hash": result_hash,
            }
        ).encode("utf-8")
    ).hexdigest()[:20]
    return f"vqe.layer-run.{digest}"


def _parameter_maps_close(
    left: Mapping[str, float],
    right: Mapping[str, float],
) -> bool:
    return left.keys() == right.keys() and all(
        math.isclose(float(left[name]), float(right[name]), rel_tol=0.0, abs_tol=1e-12)
        for name in left
    )


def _mapping(value: object, name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{name} must be a mapping.")
    return value


def _sequence(value: object, name: str) -> Sequence[Any]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        raise TypeError(f"{name} must be a sequence.")
    return value


def _finite(value: object, name: str) -> float:
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        raise TypeError(f"{name} must be a real number.")
    normalized = float(value)
    if not math.isfinite(normalized):
        raise ValueError(f"{name} must be finite.")
    return normalized


def _require_statistic(actual: object, expected: float, name: str) -> None:
    normalized = _finite(actual, name)
    if not math.isclose(
        normalized,
        expected,
        rel_tol=_STATISTIC_TOLERANCE,
        abs_tol=_STATISTIC_TOLERANCE,
    ):
        raise ValueError(f"{name} does not match repeated VQE run evidence.")


def _positive_int(value: object, name: str) -> None:
    if not isinstance(value, int) or isinstance(value, bool) or value <= 0:
        raise ValueError(f"{name} must be a positive integer.")


def _non_negative_int(value: object, name: str) -> None:
    if not isinstance(value, int) or isinstance(value, bool) or value < 0:
        raise ValueError(f"{name} must be a non-negative integer.")


def _require_text(value: object, name: str) -> None:
    if not isinstance(value, str) or not value.strip() or value != value.strip():
        raise ValueError(f"{name} must be a non-empty trimmed string.")


def _require_unique_text(values: tuple[str, ...], name: str) -> None:
    if not values or any(not isinstance(value, str) or not value for value in values):
        raise ValueError(f"{name} must contain non-empty strings.")
    if len(values) != len(set(values)):
        raise ValueError(f"{name} must not contain duplicates.")


def _require_digest(value: object, name: str) -> None:
    if (
        not isinstance(value, str)
        or len(value) != 64
        or any(character not in "0123456789abcdef" for character in value)
    ):
        raise ValueError(f"{name} must be a lowercase SHA-256 digest.")


def _require_schema(value: str) -> None:
    if value != VQE_LAYER_EXPERIMENT_SCHEMA_VERSION:
        raise ValueError(f"Unsupported VQE layer experiment schema: {value!r}.")
