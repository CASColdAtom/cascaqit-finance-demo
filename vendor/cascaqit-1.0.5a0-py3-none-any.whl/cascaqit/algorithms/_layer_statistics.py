"""Shared deterministic statistics for repeated variational layer experiments."""

from __future__ import annotations

import hashlib
import math
from dataclasses import dataclass

from scipy.stats import t as student_t  # type: ignore[import-untyped]

from cascaqit.native_ir.base import stable_json


@dataclass(frozen=True)
class LayerSampleSummary:
    """Computed sample moments and confidence bounds."""

    mean: float
    variance: float
    standard_error: float
    interval_low: float
    interval_high: float


def confidence_level(value: object) -> float:
    """Validate the confidence level shared by every layer experiment."""
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        raise TypeError("confidence_level must be a real number.")
    normalized = float(value)
    if not math.isfinite(normalized):
        raise ValueError("confidence_level must be finite.")
    if not 0.5 < normalized < 1.0:
        raise ValueError("confidence_level must be greater than 0.5 and below 1.0.")
    return normalized


def sample_summary(
    values: tuple[float, ...],
    *,
    confidence: float,
) -> LayerSampleSummary:
    """Compute an unbiased sample variance and a two-sided Student-t interval."""
    if len(values) < 2:
        raise ValueError("sample statistics require at least two values.")
    normalized = tuple(_finite(value, "sample value") for value in values)
    level = confidence_level(confidence)
    mean = math.fsum(normalized) / len(normalized)
    squared = math.fsum((value - mean) ** 2 for value in normalized)
    variance = squared / (len(normalized) - 1)
    standard_error = math.sqrt(variance / len(normalized))
    critical = float(student_t.ppf((1.0 + level) / 2.0, len(normalized) - 1))
    if not math.isfinite(critical):
        raise ValueError("confidence interval critical value must be finite.")
    margin = critical * standard_error
    return LayerSampleSummary(
        mean=mean,
        variance=variance,
        standard_error=standard_error,
        interval_low=mean - margin,
        interval_high=mean + margin,
    )


def paired_improvement_summary(
    differences: tuple[float, ...],
    *,
    confidence: float,
) -> LayerSampleSummary:
    """Compute the one-sided lower bound for paired objective decreases."""
    base = sample_summary(differences, confidence=confidence)
    critical = float(student_t.ppf(confidence, len(differences) - 1))
    if not math.isfinite(critical):
        raise ValueError("paired critical value must be finite.")
    return LayerSampleSummary(
        mean=base.mean,
        variance=base.variance,
        standard_error=base.standard_error,
        interval_low=base.mean - critical * base.standard_error,
        interval_high=math.inf,
    )


def derive_layer_run_seed(
    root_seed: int,
    *,
    layers: int,
    repeat_index: int,
    namespace: str,
) -> int:
    """Derive a stable, order-independent 32-bit seed for one repeated run."""
    _non_negative_int(root_seed, "root_seed")
    _positive_int(layers, "layers")
    _non_negative_int(repeat_index, "repeat_index")
    if not isinstance(namespace, str) or not namespace.strip():
        raise ValueError("namespace must be a non-empty string.")
    # Python hash() 会受进程随机化影响；稳定 JSON 与 SHA-256 保证跨进程、
    # 跨平台以及不同调度顺序仍得到同一个实验 seed。
    digest = hashlib.sha256(
        stable_json(
            {
                "namespace": namespace,
                "root_seed": root_seed,
                "layers": layers,
                "repeat_index": repeat_index,
            }
        ).encode("utf-8")
    ).digest()
    return int.from_bytes(digest[:4], byteorder="big", signed=False)


def _finite(value: object, name: str) -> float:
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        raise TypeError(f"{name} must be a real number.")
    normalized = float(value)
    if not math.isfinite(normalized):
        raise ValueError(f"{name} must be finite.")
    return normalized


def _positive_int(value: object, name: str) -> None:
    if not isinstance(value, int) or isinstance(value, bool) or value <= 0:
        raise ValueError(f"{name} must be a positive integer.")


def _non_negative_int(value: object, name: str) -> None:
    if not isinstance(value, int) or isinstance(value, bool) or value < 0:
        raise ValueError(f"{name} must be a non-negative integer.")
