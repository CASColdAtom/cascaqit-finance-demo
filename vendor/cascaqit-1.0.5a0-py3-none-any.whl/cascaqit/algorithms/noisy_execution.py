"""带噪变分 objective 的执行证据与确定性预检。"""

from __future__ import annotations

import hashlib
import math
import re
from collections.abc import Mapping
from dataclasses import dataclass, field, replace
from types import MappingProxyType
from typing import Any, Literal, cast

from cascaqit.digital import Circuit
from cascaqit.exceptions import CapabilityError
from cascaqit.native_ir.base import IRMixin, stable_json
from cascaqit.observables import (
    ObservableBatchResultIR,
    ObservableEstimatorKind,
    ObservableSourceKind,
)
from cascaqit.results import ResultIR
from cascaqit.simulators.local_backend import LocalBackend
from cascaqit.simulators.physical_noise import NoiseModel, NoiseReport
from cascaqit.simulators.planning import (
    SimulationExecutionPlan,
    SimulationOptions,
    SimulationPlanner,
    SimulationPlanningRequest,
)

__all__ = ["ObjectiveExecutionEvidenceIR"]

NOISY_EXECUTION_SCHEMA_VERSION = "cascaqit.algorithms.noisy_execution.v1"
_DIGEST_PATTERN = re.compile(r"[0-9a-f]{64}")
_DIGITAL_PHYSICAL_CHANNELS = frozenset(
    {"preparation", "gate", "idle", "crosstalk"}
)
_DIGITAL_MEASUREMENT_CHANNELS = frozenset({"readout"})
_DIGITAL_UNSUPPORTED_CHANNELS = frozenset({"dephasing", "boundary", "atom_loss"})


@dataclass(frozen=True)
class ObjectiveExecutionEvidenceIR(IRMixin):
    """一次 objective 对应的模拟方法、噪声和 Backend 来源事实。"""

    evidence_id: str
    evidence_hash: str
    noise_model: NoiseModel | None
    requested_options: SimulationOptions | None
    simulation_plan: SimulationExecutionPlan
    noise_report: NoiseReport | None
    estimator_kind: ObservableEstimatorKind
    source_kind: ObservableSourceKind
    sample_count: int | None
    observable_standard_errors: Mapping[str, float]
    requested_seed: int | None
    effective_seed: int
    backend_id: str
    backend_job_id: str
    backend_shots: int
    result_id: str
    result_hash: str
    metadata: Mapping[str, Any] = field(default_factory=dict)
    schema_version: str = NOISY_EXECUTION_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_text(self.evidence_id, "evidence_id")
        _require_digest(self.evidence_hash, "evidence_hash")
        if self.noise_model is not None and not isinstance(
            self.noise_model, NoiseModel
        ):
            raise TypeError("noise_model must be NoiseModel or None.")
        if self.requested_options is not None and not isinstance(
            self.requested_options, SimulationOptions
        ):
            raise TypeError("requested_options must be SimulationOptions or None.")
        if not isinstance(self.simulation_plan, SimulationExecutionPlan):
            raise TypeError("simulation_plan must be SimulationExecutionPlan.")
        if self.noise_report is not None and not isinstance(
            self.noise_report, NoiseReport
        ):
            raise TypeError("noise_report must be NoiseReport or None.")

        estimator = _enum_value(
            self.estimator_kind,
            ObservableEstimatorKind,
            "estimator_kind",
        )
        source = _enum_value(self.source_kind, ObservableSourceKind, "source_kind")
        object.__setattr__(self, "estimator_kind", estimator)
        object.__setattr__(self, "source_kind", source)
        _validate_estimator_plan(estimator, source, self.simulation_plan)

        if self.sample_count is not None and (
            not isinstance(self.sample_count, int)
            or isinstance(self.sample_count, bool)
            or self.sample_count < 2
        ):
            raise ValueError("sample_count must be at least two or None.")
        if estimator in {
            ObservableEstimatorKind.EXACT_STATE,
            ObservableEstimatorKind.EXACT_DENSITY,
        }:
            if self.sample_count is not None:
                raise ValueError("exact objective evidence cannot define sample_count.")
        elif self.sample_count is None:
            raise ValueError("sampled objective evidence requires sample_count.")

        errors: dict[str, float] = {}
        for name, value in self.observable_standard_errors.items():
            _require_text(name, "observable name")
            error = _finite_non_negative_float(value, f"standard error for {name}")
            if estimator in {
                ObservableEstimatorKind.EXACT_STATE,
                ObservableEstimatorKind.EXACT_DENSITY,
            } and error != 0.0:
                raise ValueError(
                    "exact objective evidence must have zero standard error."
                )
            errors[name] = error
        if not errors:
            raise ValueError("observable_standard_errors must not be empty.")
        object.__setattr__(
            self,
            "observable_standard_errors",
            MappingProxyType(errors),
        )

        if self.requested_seed is not None:
            _require_seed(self.requested_seed, "requested_seed")
        _require_seed(self.effective_seed, "effective_seed")
        if self.effective_seed != self.simulation_plan.seed:
            raise ValueError("effective_seed must match the SimulationPlan seed.")
        if (
            self.requested_seed is not None
            and self.requested_seed != self.effective_seed
        ):
            raise ValueError("an explicit requested_seed must be the effective seed.")

        resolved_options = replace(
            self.requested_options or SimulationOptions(),
            seed=self.effective_seed,
        )
        if resolved_options.stable_hash() != self.simulation_plan.options_hash:
            raise ValueError(
                "requested options do not match SimulationPlan options_hash."
            )

        if self.noise_model is None:
            if self.simulation_plan.noisy or self.noise_report is not None:
                raise ValueError(
                    "ideal evidence cannot contain noisy plan/report facts."
                )
        else:
            if not self.simulation_plan.noisy or self.noise_report is None:
                raise ValueError(
                    "noisy evidence requires a noisy plan and NoiseReport."
                )
            if self.noise_report.noise_model_id != self.noise_model.noise_model_id:
                raise ValueError("NoiseReport model id does not match NoiseModel.")
            if self.noise_report.noise_model_hash != self.noise_model.stable_hash():
                raise ValueError("NoiseReport model hash does not match NoiseModel.")
            if self.noise_report.method != self.simulation_plan.method_selected:
                raise ValueError("NoiseReport method must match SimulationPlan method.")

        for name in ("backend_id", "backend_job_id", "result_id"):
            _require_text(getattr(self, name), name)
        if (
            not isinstance(self.backend_shots, int)
            or isinstance(self.backend_shots, bool)
            or self.backend_shots < 0
        ):
            raise ValueError("backend_shots must be a non-negative integer.")
        if self.noise_model is not None and self.backend_shots <= 0:
            raise ValueError(
                "noisy objective evidence requires positive backend_shots."
            )
        _require_digest(self.result_hash, "result_hash")
        object.__setattr__(self, "metadata", MappingProxyType(dict(self.metadata)))

        expected_hash = _evidence_hash(self)
        if self.evidence_hash != expected_hash:
            raise ValueError("evidence_hash does not match objective execution facts.")
        if self.evidence_id != f"objective.execution.{expected_hash[:20]}":
            raise ValueError("evidence_id does not match evidence_hash.")

    @classmethod
    def create(
        cls,
        *,
        noise_model: NoiseModel | None,
        requested_options: SimulationOptions | None,
        simulation_plan: SimulationExecutionPlan,
        noise_report: NoiseReport | None,
        observable_batch: ObservableBatchResultIR,
        requested_seed: int | None,
        backend_id: str,
        backend_job_id: str,
        backend_shots: int,
        result_id: str,
        result_hash: str,
        metadata: Mapping[str, Any] | None = None,
    ) -> ObjectiveExecutionEvidenceIR:
        """从已校验的 Backend 与 Observable 事实创建稳定证据。"""
        estimator, source, sample_count, standard_errors = _batch_facts(
            observable_batch
        )
        values: dict[str, Any] = {
            "noise_model": noise_model,
            "requested_options": requested_options,
            "simulation_plan": simulation_plan,
            "noise_report": noise_report,
            "estimator_kind": estimator,
            "source_kind": source,
            "sample_count": sample_count,
            "observable_standard_errors": standard_errors,
            "requested_seed": requested_seed,
            "effective_seed": simulation_plan.seed,
            "backend_id": backend_id,
            "backend_job_id": backend_job_id,
            "backend_shots": backend_shots,
            "result_id": result_id,
            "result_hash": result_hash,
            "metadata": {} if metadata is None else dict(metadata),
            "schema_version": NOISY_EXECUTION_SCHEMA_VERSION,
        }
        digest = _evidence_hash(values)
        return cls(
            evidence_id=f"objective.execution.{digest[:20]}",
            evidence_hash=digest,
            **values,
        )

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ObjectiveExecutionEvidenceIR:
        """从 JSON 兼容数据恢复，并重新校验全部派生身份。"""
        raw_noise = data.get("noise_model")
        raw_options = data.get("requested_options")
        raw_report = data.get("noise_report")
        return cls(
            evidence_id=str(data["evidence_id"]),
            evidence_hash=str(data["evidence_hash"]),
            noise_model=(
                None
                if raw_noise is None
                else NoiseModel.from_dict(dict(_mapping(raw_noise, "noise_model")))
            ),
            requested_options=(
                None
                if raw_options is None
                else SimulationOptions.from_dict(
                    dict(_mapping(raw_options, "requested_options"))
                )
            ),
            simulation_plan=SimulationExecutionPlan.from_dict(
                dict(_mapping(data["simulation_plan"], "simulation_plan"))
            ),
            noise_report=(
                None
                if raw_report is None
                else NoiseReport.from_dict(_mapping(raw_report, "noise_report"))
            ),
            estimator_kind=ObservableEstimatorKind(data["estimator_kind"]),
            source_kind=ObservableSourceKind(data["source_kind"]),
            sample_count=data.get("sample_count"),
            observable_standard_errors={
                str(name): value
                for name, value in _mapping(
                    data["observable_standard_errors"],
                    "observable_standard_errors",
                ).items()
            },
            requested_seed=data.get("requested_seed"),
            effective_seed=data["effective_seed"],
            backend_id=str(data["backend_id"]),
            backend_job_id=str(data["backend_job_id"]),
            backend_shots=data["backend_shots"],
            result_id=str(data["result_id"]),
            result_hash=str(data["result_hash"]),
            metadata=dict(_mapping(data.get("metadata", {}), "metadata")),
            schema_version=str(
                data.get("schema_version", NOISY_EXECUTION_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> ObjectiveExecutionEvidenceIR:
        """从 JSON 文本恢复执行证据。"""
        import json

        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("ObjectiveExecutionEvidenceIR JSON must contain an object.")
        return cls.from_dict(data)


def validate_noisy_variational_request(
    circuit: Circuit,
    *,
    noise: NoiseModel,
    options: SimulationOptions | None,
    backend: LocalBackend | None,
    seed: int | None,
) -> SimulationExecutionPlan:
    """在第一个 optimizer Job 前冻结并校验 Digital density 执行计划。"""
    if not isinstance(circuit, Circuit):
        raise TypeError("circuit must be Circuit.")
    if not isinstance(noise, NoiseModel):
        raise TypeError("noise must be canonical NoiseModel.")
    if options is not None and not isinstance(options, SimulationOptions):
        raise TypeError("options must be SimulationOptions or None.")
    if backend is not None and not isinstance(backend, LocalBackend):
        raise TypeError("backend must be LocalBackend or None.")
    if seed is not None:
        _require_seed(seed, "seed")

    channel_types = _validate_digital_noise_channels(noise)
    if not channel_types & _DIGITAL_PHYSICAL_CHANNELS:
        raise CapabilityError(
            "Noisy variational objectives require a physical state channel; readout "
            "alone changes only terminal samples.",
            code="ALGORITHM_NOISY_PHYSICAL_CHANNEL_REQUIRED",
            stage="optimization",
            object_path="algorithm.noise.channels",
        )

    requested_options = options or SimulationOptions()
    if requested_options.method not in {"auto", "density_matrix"}:
        raise CapabilityError(
            "Noisy variational optimization currently requires density_matrix.",
            code="ALGORITHM_NOISY_METHOD_UNSUPPORTED",
            stage="optimization",
            object_path="algorithm.options.method",
            metadata={"requested_method": requested_options.method},
        )
    effective_seed = _resolve_seed(seed=seed, backend=backend, options=options)
    resolved_options = replace(requested_options, seed=effective_seed)

    # 单个 Circuit 的物理噪声会被 LocalBackend 包装成单块 HybridProgram；预规划
    # 使用相同 program_kind，才能让 plan identity 与真实 Result 完全一致。
    plan = SimulationPlanner().plan(
        SimulationPlanningRequest(
            program_kind="hybrid",
            logical_sites=len(circuit.qubits),
            noisy=True,
            requires_trajectory=False,
            time_integration_required=False,
            options=resolved_options,
        )
    )
    if plan.method_selected != "density_matrix":
        raise CapabilityError(
            "Resource planning did not select deterministic density_matrix execution.",
            code="ALGORITHM_NOISY_DENSITY_REQUIRED",
            stage="optimization",
            object_path="algorithm.simulation_plan.method_selected",
            metadata={
                "selected_method": plan.method_selected,
                "simulation_plan": plan.to_dict(),
                "large_array_allocated": False,
            },
        )
    return plan


def validate_sampled_variational_request(
    circuit: Circuit,
    *,
    noise: NoiseModel | None,
    options: SimulationOptions | None,
    backend: LocalBackend | None,
    seed: int | None,
) -> SimulationExecutionPlan:
    """在 sampled objective 执行前冻结单个 QWC Circuit 的模拟计划。

    sampled objective 与 exact-density objective 的关键差异是 readout-only
    NoiseModel 具有可观测效果，而且 counts estimator 可以建立在 state-vector、
    density-matrix 或 trajectory 模拟结果之上。因此这里保留独立预检入口，避免
    放宽 exact objective 原有的物理语义。
    """
    if not isinstance(circuit, Circuit):
        raise TypeError("circuit must be Circuit.")
    if noise is not None and not isinstance(noise, NoiseModel):
        raise TypeError("noise must be canonical NoiseModel or None.")
    if options is not None and not isinstance(options, SimulationOptions):
        raise TypeError("options must be SimulationOptions or None.")
    if backend is not None and not isinstance(backend, LocalBackend):
        raise TypeError("backend must be LocalBackend or None.")
    if seed is not None:
        _require_seed(seed, "seed")

    effective_seed = _resolve_seed(seed=seed, backend=backend, options=options)
    requested_options = options or SimulationOptions()
    resolved_options = replace(requested_options, seed=effective_seed)
    if noise is None:
        return SimulationPlanner().plan(
            SimulationPlanningRequest(
                program_kind="digital",
                logical_sites=len(circuit.qubits),
                noisy=False,
                requires_trajectory=False,
                time_integration_required=False,
                options=resolved_options,
            )
        )

    _validate_digital_noise_channels(noise)
    if requested_options.method not in {"auto", "density_matrix", "trajectory"}:
        raise CapabilityError(
            "Noisy sampled VQE requires density_matrix or trajectory execution.",
            code="ALGORITHM_SAMPLED_NOISY_METHOD_UNSUPPORTED",
            stage="optimization",
            object_path="algorithm.options.method",
            metadata={"requested_method": requested_options.method},
        )
    plan = SimulationPlanner().plan(
        SimulationPlanningRequest(
            # LocalBackend wraps a noisy standalone Circuit in a Digital-only
            # HybridProgram. Matching that kind keeps preflight and Result plans
            # byte-for-byte comparable.
            program_kind="hybrid",
            logical_sites=len(circuit.qubits),
            noisy=True,
            requires_trajectory=noise.requires_trajectory,
            time_integration_required=False,
            options=resolved_options,
        )
    )
    if plan.method_selected not in {"density_matrix", "trajectory"}:
        raise CapabilityError(
            "Noisy sampled VQE planning selected an unsupported method.",
            code="ALGORITHM_SAMPLED_NOISY_METHOD_UNSUPPORTED",
            stage="optimization",
            object_path="algorithm.simulation_plan.method_selected",
            metadata={
                "selected_method": plan.method_selected,
                "simulation_plan": plan.to_dict(),
                "large_array_allocated": False,
            },
        )

    # Recreate LocalBackend's public wrapping semantics without allocating a
    # simulation state. This validates gate presence, crosstalk schedule refs and
    # all target/channel prerequisites for every synthesized QWC Circuit.
    from cascaqit.hybrid import HybridProgram
    from cascaqit.simulators import validate_physical_noise_bundle

    digital = circuit.to_program()
    measurement_free = replace(
        digital,
        circuit=replace(digital.circuit, measurements=()),
    )
    wrapper = (
        HybridProgram(f"noise.preflight.{measurement_free.program_id}")
        .digital("digital", measurement_free)
        .measure_all()
    )
    prepared = wrapper.prepare(
        shots=2,
        seed=effective_seed,
        bundle_id=f"sampled.preflight.{measurement_free.program_id}",
    )
    if prepared.bundle is None:
        raise CapabilityError(
            "Sampled VQE measurement Circuit failed noisy preflight.",
            code="ALGORITHM_SAMPLED_NOISY_PROGRAM_INVALID",
            stage="optimization",
            object_path="algorithm.measurement_circuit",
            metadata={
                "diagnostics": [item.to_dict() for item in prepared.diagnostics],
                "large_array_allocated": False,
            },
        )
    validate_physical_noise_bundle(
        prepared.bundle,
        noise,
        method=cast(Literal["density_matrix", "trajectory"], plan.method_selected),
    )
    return plan


def build_objective_execution_evidence(
    *,
    result: ResultIR,
    observable_batch: ObservableBatchResultIR,
    noise: NoiseModel | None,
    options: SimulationOptions | None,
    requested_seed: int | None,
    backend_id: str,
    backend_job_id: str,
) -> ObjectiveExecutionEvidenceIR:
    """把 Backend Result metadata 转成可恢复、可防篡改的算法层证据。"""
    if not isinstance(result, ResultIR):
        raise TypeError("result must be ResultIR.")
    if not isinstance(observable_batch, ObservableBatchResultIR):
        raise TypeError("observable_batch must be ObservableBatchResultIR.")
    plan_data = _mapping(
        result.metadata.get("simulation_plan"),
        "result.metadata.simulation_plan",
    )
    plan = SimulationExecutionPlan.from_dict(dict(plan_data))
    plan_hash = result.metadata.get("simulation_plan_hash")
    if plan_hash != plan.stable_hash():
        raise ValueError("Result simulation_plan_hash does not match SimulationPlan.")

    report: NoiseReport | None = None
    if noise is not None:
        report = NoiseReport.from_dict(
            _mapping(
                result.metadata.get("noise_report"),
                "result.metadata.noise_report",
            )
        )
        if result.metadata.get("noise_report_hash") != report.stable_hash():
            raise ValueError("Result noise_report_hash does not match NoiseReport.")
        if result.metadata.get("noise_model_hash") != noise.stable_hash():
            raise ValueError("Result noise_model_hash does not match NoiseModel.")
    elif result.metadata.get("noise_report") is not None:
        raise ValueError("Ideal objective Result cannot contain NoiseReport metadata.")

    return ObjectiveExecutionEvidenceIR.create(
        noise_model=noise,
        requested_options=options,
        simulation_plan=plan,
        noise_report=report,
        observable_batch=observable_batch,
        requested_seed=requested_seed,
        backend_id=backend_id,
        backend_job_id=backend_job_id,
        backend_shots=result.shots,
        result_id=result.result_id,
        result_hash=result.stable_hash(),
        metadata={
            "program_hash": result.program_hash,
            "simulation_truthfulness": result.metadata.get(
                "simulation_truthfulness"
            ),
        },
    )


def _batch_facts(
    batch: ObservableBatchResultIR,
) -> tuple[
    ObservableEstimatorKind,
    ObservableSourceKind,
    int | None,
    dict[str, float],
]:
    estimators = {item.estimator_kind for item in batch.items}
    sample_counts = {item.sample_count for item in batch.items}
    if len(estimators) != 1 or len(sample_counts) != 1:
        raise ValueError("Observable batch must use one estimator and sample count.")
    return (
        batch.items[0].estimator_kind,
        batch.source_kind,
        batch.items[0].sample_count,
        {item.name: item.standard_error for item in batch.items},
    )


def _validate_estimator_plan(
    estimator: ObservableEstimatorKind,
    source: ObservableSourceKind,
    plan: SimulationExecutionPlan,
) -> None:
    if (
        estimator is ObservableEstimatorKind.SAMPLE_MEAN
        and source is ObservableSourceKind.MEASUREMENT_PLAN
    ):
        # QWC measurement produces a finite-shot estimator regardless of whether
        # the state source was ideal, density-matrix, or trajectory simulation.
        return
    expected = {
        "state_vector": (
            ObservableEstimatorKind.EXACT_STATE,
            ObservableSourceKind.STATE_VECTOR,
        ),
        "subspace": (
            ObservableEstimatorKind.EXACT_STATE,
            ObservableSourceKind.SUBSPACE,
        ),
        "density_matrix": (
            ObservableEstimatorKind.EXACT_DENSITY,
            ObservableSourceKind.DENSITY_MATRIX,
        ),
        "trajectory": (
            ObservableEstimatorKind.TRAJECTORY_MEAN,
            ObservableSourceKind.TRAJECTORY_BATCH,
        ),
    }[plan.method_selected]
    if (estimator, source) != expected:
        raise ValueError(
            "Observable estimator/source do not match SimulationPlan method."
        )


def _validate_digital_noise_channels(noise: NoiseModel) -> frozenset[str]:
    """Validate the channel subset shared by exact and sampled Digital VQE."""
    channel_types: frozenset[str] = frozenset(
        channel.channel_type for channel in noise.channels
    )
    unsupported = sorted(channel_types & _DIGITAL_UNSUPPORTED_CHANNELS)
    if unsupported:
        raise CapabilityError(
            "NoiseModel contains channels unavailable to Digital variational "
            "execution.",
            code="ALGORITHM_NOISY_CHANNEL_UNSUPPORTED",
            stage="optimization",
            object_path="algorithm.noise.channels",
            metadata={"unsupported_channel_types": unsupported},
        )
    unknown = sorted(
        channel_types - _DIGITAL_PHYSICAL_CHANNELS - _DIGITAL_MEASUREMENT_CHANNELS
    )
    if unknown:
        raise CapabilityError(
            "NoiseModel contains unknown Digital variational channels.",
            code="ALGORITHM_NOISY_CHANNEL_UNSUPPORTED",
            stage="optimization",
            object_path="algorithm.noise.channels",
            metadata={"unsupported_channel_types": unknown},
        )
    return channel_types


def _evidence_hash(value: ObjectiveExecutionEvidenceIR | Mapping[str, Any]) -> str:
    if isinstance(value, ObjectiveExecutionEvidenceIR):
        payload = {
            key: item
            for key, item in value.to_dict().items()
            if key not in {"evidence_id", "evidence_hash"}
        }
    else:
        payload = dict(value)
    return hashlib.sha256(stable_json(payload).encode("utf-8")).hexdigest()


def _resolve_seed(
    *,
    seed: int | None,
    backend: LocalBackend | None,
    options: SimulationOptions | None,
) -> int:
    for candidate in (
        seed,
        None if backend is None else backend.seed,
        None if options is None else options.seed,
        0,
    ):
        if candidate is not None:
            return candidate
    raise AssertionError("deterministic seed fallback is unreachable")


def _mapping(value: object, field_name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{field_name} must be a mapping.")
    return value


def _require_text(value: object, field_name: str) -> None:
    if not isinstance(value, str) or not value.strip() or value != value.strip():
        raise ValueError(f"{field_name} must be a non-empty trimmed string.")


def _require_digest(value: object, field_name: str) -> None:
    if not isinstance(value, str) or _DIGEST_PATTERN.fullmatch(value) is None:
        raise ValueError(f"{field_name} must be a lowercase SHA-256 digest.")


def _require_seed(value: object, field_name: str) -> None:
    if not isinstance(value, int) or isinstance(value, bool) or value < 0:
        raise ValueError(f"{field_name} must be a non-negative integer.")


def _finite_non_negative_float(value: object, field_name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{field_name} must be a real number.")
    number = float(value)
    if not math.isfinite(number) or number < 0.0:
        raise ValueError(f"{field_name} must be finite and non-negative.")
    return number


def _enum_value(value: object, enum_type: type[Any], field_name: str) -> Any:
    try:
        return enum_type(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{field_name} is unsupported.") from exc
