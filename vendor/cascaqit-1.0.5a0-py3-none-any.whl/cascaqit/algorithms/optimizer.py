"""Shared scalar optimization loops for executable variational algorithms."""

from __future__ import annotations

import math
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from typing import Literal, TypeVar, Union, cast

import numpy as np
from numpy.typing import NDArray
from scipy.optimize import OptimizeResult, minimize  # type: ignore[import-untyped]

from cascaqit.algorithms.adam import (
    AdamIterationIR,
    AdamStoppingEvidenceIR,
    validate_adam_iteration_sequence,
)
from cascaqit.algorithms.execution import ParameterValues, normalize_parameter_values
from cascaqit.algorithms.gradient import (
    ObjectiveGradientIR,
    build_parameter_shift_plan,
)
from cascaqit.algorithms.measurement import (
    PauliMeasurementConfig,
    SampledObjectiveEvaluationIR,
    build_pauli_measurement_plan,
)
from cascaqit.algorithms.models import (
    AnsatzSpecIR,
    ObjectiveEvaluationIR,
    OptimizationStartIR,
    OptimizerConfig,
    OptimizerTerminationIR,
    PauliHamiltonian,
    SPSADirectionIR,
    SPSAIterationIR,
    SPSALearningRateCalibrationIR,
    SPSAObjectiveEstimateIR,
    SPSAStoppingCheckIR,
    SPSAStoppingConfig,
    SPSAStoppingEvidenceIR,
    VariationalResult,
    build_cardinality_subspace_evidence,
    rank_spsa_source_evaluation_indices,
)
from cascaqit.algorithms.noisy_execution import validate_noisy_variational_request
from cascaqit.algorithms.sampled_selection import (
    SampledSelectionConfig,
    SampledSelectionIR,
    execute_sampled_candidate_selection,
)
from cascaqit.algorithms.sampling import execute_final_sampling
from cascaqit.digital import Circuit
from cascaqit.problems import OptimizationProblem
from cascaqit.simulators import LocalBackend, NoiseModel, SimulationOptions

AlgorithmKind = Literal["qaoa", "vqe", "qaa"]
VariationalObjectiveEvaluationIR = Union[
    ObjectiveEvaluationIR,
    SampledObjectiveEvaluationIR,
]
VariationalObjectiveT = TypeVar(
    "VariationalObjectiveT",
    ObjectiveEvaluationIR,
    SampledObjectiveEvaluationIR,
)
ObjectiveEvaluator = Callable[..., VariationalObjectiveT]
GradientEvaluator = Callable[..., ObjectiveGradientIR]
CircuitBuilder = Callable[[], Circuit]
ScalarObjective = Callable[[tuple[float, ...], int], float]
ScalarGradient = Callable[..., Union[tuple[float, ...], ObjectiveGradientIR]]
SPSAObjectiveStopReason = Literal[
    "fixed_repeats",
    "target_reached",
    "max_repeats_reached",
    "budget_exhausted",
]

__all__ = [
    "ScalarOptimizationOutcome",
    "OptimizationStartPlan",
    "aggregate_optimizer_termination",
    "build_optimization_start_plans",
    "derive_spsa_stopping_evidence",
    "run_adam_optimization",
    "run_scalar_optimization",
    "run_spsa_optimization",
    "run_variational_optimization",
    "seeded_initial_point",
]


@dataclass(frozen=True)
class ScalarOptimizationOutcome:
    """Normalized optimizer result shared by algorithm and Problem workflows."""

    initial_parameters: tuple[float, ...]
    final_parameters: tuple[float, ...]
    final_objective: float
    objective_values: tuple[float, ...]
    best_evaluation_index: int
    termination: OptimizerTerminationIR
    gradient_values: tuple[tuple[float, ...], ...] = ()
    adam_iterations: tuple[AdamIterationIR, ...] = ()
    adam_stopping_evidence: AdamStoppingEvidenceIR | None = None
    spsa_iterations: tuple[SPSAIterationIR, ...] = ()
    objective_estimates: tuple[SPSAObjectiveEstimateIR, ...] = ()
    spsa_learning_rate_calibration: SPSALearningRateCalibrationIR | None = None
    spsa_stopping_evidence: SPSAStoppingEvidenceIR | None = None


@dataclass(frozen=True)
class OptimizationStartPlan:
    """Resolved deterministic initial point for one optimizer start."""

    start_index: int
    seed: int
    initialization: Literal["random", "explicit", "layerwise", "schema_default"]
    parameters: tuple[float, ...]


def derive_spsa_stopping_evidence(
    iterations: Sequence[SPSAIterationIR],
    config: SPSAStoppingConfig,
) -> SPSAStoppingEvidenceIR:
    """Derive the last online stopping decision without executing an objective."""
    if not isinstance(config, SPSAStoppingConfig):
        raise TypeError("config must be SPSAStoppingConfig.")
    if any(not isinstance(item, SPSAIterationIR) for item in iterations):
        raise TypeError("iterations must contain SPSAIterationIR values.")
    saved = tuple(iterations)
    window = saved[-config.window_size :]
    indices = tuple(item.iteration_index for item in window)
    proxies = tuple(
        math.fsum(
            (direction.plus_objective + direction.minus_objective) / 2.0
            for direction in item.directions
        )
        / len(item.directions)
        for item in window
    )
    enough = len(saved) >= config.min_iterations and len(window) == config.window_size
    update_norms = tuple(item.update_norm for item in window)
    gradient_norms = tuple(
        math.sqrt(math.fsum(value * value for value in item.gradient_estimate.values()))
        for item in window
    )
    checks: list[SPSAStoppingCheckIR] = [
        SPSAStoppingCheckIR.create(
            name="objective_range",
            observed_value=(max(proxies) - min(proxies) if enough else None),
            threshold=config.objective_range_tolerance,
            sample_count=len(proxies),
        ),
        SPSAStoppingCheckIR.create(
            name="update_norm",
            observed_value=max(update_norms) if enough else None,
            threshold=config.update_norm_tolerance,
            sample_count=len(update_norms),
        ),
        SPSAStoppingCheckIR.create(
            name="gradient_norm",
            observed_value=max(gradient_norms) if enough else None,
            threshold=config.gradient_norm_tolerance,
            sample_count=len(gradient_norms),
        ),
    ]
    if config.gradient_standard_error_norm_tolerance is not None:
        gradient_errors = tuple(
            item.gradient_standard_error for item in window
        )
        available_gradient_errors = tuple(
            value for value in gradient_errors if value is not None
        )
        gradient_error_norms = tuple(
            math.sqrt(math.fsum(value * value for value in error.values()))
            for error in available_gradient_errors
        )
        checks.append(
            SPSAStoppingCheckIR.create(
                name="gradient_standard_error_norm",
                observed_value=(
                    max(gradient_error_norms)
                    if enough and len(gradient_error_norms) == len(window)
                    else None
                ),
                threshold=config.gradient_standard_error_norm_tolerance,
                sample_count=len(gradient_error_norms),
            )
        )
    if config.sampled_standard_error_tolerance is not None:
        sampled_errors = tuple(
            estimate.pooled_standard_error
            for item in window
            for direction in item.directions
            for estimate in (direction.plus_estimate, direction.minus_estimate)
        )
        available_sampled_errors = tuple(
            value for value in sampled_errors if value is not None
        )
        checks.append(
            SPSAStoppingCheckIR.create(
                name="sampled_standard_error",
                observed_value=(
                    max(available_sampled_errors)
                    if enough
                    and len(available_sampled_errors) == len(sampled_errors)
                    else None
                ),
                threshold=config.sampled_standard_error_tolerance,
                sample_count=len(available_sampled_errors),
            )
        )
    statuses = {check.status for check in checks}
    if "unavailable" in statuses:
        status: Literal[
            "insufficient_evidence",
            "thresholds_not_met",
            "stability_reached",
        ] = "insufficient_evidence"
    elif "failed" in statuses:
        status = "thresholds_not_met"
    else:
        status = "stability_reached"
    return SPSAStoppingEvidenceIR(
        status=status,
        window_iteration_indices=indices,
        objective_proxy_values=proxies,
        checks=tuple(checks),
    )


class _OptimizationBudgetExhausted(Exception):
    """Internal control signal raised before a callback can exceed its budget."""

    def __init__(
        self,
        reason: Literal[
            "max_evaluations",
            "max_gradient_evaluations",
            "max_backend_executions",
        ],
    ) -> None:
        super().__init__(reason)
        self.reason = reason


def build_optimization_start_plans(
    *,
    algorithm_kind: AlgorithmKind,
    layers: int,
    parameter_names: tuple[str, ...],
    optimizer: OptimizerConfig,
    initial_parameters: ParameterValues | None,
    seed: int,
    default_initial_parameters: tuple[float, ...] | None = None,
) -> tuple[OptimizationStartPlan, ...]:
    """Resolve every start before the first Backend evaluation.

    Start zero preserves a caller-supplied, layer-wise, or schema-default point.
    Remaining starts are independent seeded points over the declared domain. This
    keeps retries reproducible and makes the total Backend budget explicit as
    ``starts * per-start budget``.
    """
    if algorithm_kind not in {"qaoa", "vqe", "qaa"}:
        raise ValueError(f"Unsupported algorithm kind: {algorithm_kind!r}.")
    if not isinstance(layers, int) or isinstance(layers, bool) or layers <= 0:
        raise ValueError("layers must be a positive integer.")
    if not isinstance(optimizer, OptimizerConfig):
        raise TypeError("optimizer must be OptimizerConfig.")
    if not isinstance(seed, int) or isinstance(seed, bool) or seed < 0:
        raise ValueError("seed must be a non-negative integer.")
    if not parameter_names or len(parameter_names) != len(set(parameter_names)):
        raise ValueError("parameter_names must be non-empty and unique.")
    _validate_bounds(optimizer, parameter_names)

    first: tuple[float, ...] | None = None
    first_kind: Literal["random", "explicit", "layerwise", "schema_default"]
    if optimizer.initialization == "layerwise":
        if initial_parameters is None:
            raise ValueError("layerwise initialization requires initial parameters.")
        if not isinstance(initial_parameters, Mapping):
            raise TypeError("layerwise initial_parameters must be a parameter mapping.")
        if algorithm_kind == "qaa":
            raise ValueError("layerwise initialization is not available for QAA.")
        if algorithm_kind == "qaoa":
            first = _qaoa_layerwise_initial_point(
                layers=layers,
                parameter_names=parameter_names,
                previous_parameters=initial_parameters,
            )
        else:
            # VQE 的层结构由 Ansatz 契约拥有。优化器只校验调用方已经迁移好的
            # 当前层完整参数，不再从 RY/RZ 名称反推 qubit、层数或旋转轴。
            normalized = normalize_parameter_values(initial_parameters, parameter_names)
            first = tuple(normalized[name] for name in parameter_names)
        first_kind = "layerwise"
    elif initial_parameters is not None:
        normalized = normalize_parameter_values(initial_parameters, parameter_names)
        first = tuple(normalized[name] for name in parameter_names)
        first_kind = "explicit"
    elif default_initial_parameters is not None:
        first = tuple(float(value) for value in default_initial_parameters)
        if len(first) != len(parameter_names):
            raise ValueError("default_initial_parameters must match parameter_names.")
        first_kind = "schema_default"
    else:
        first_kind = "random"

    plans: list[OptimizationStartPlan] = []
    for start_index in range(optimizer.starts):
        start_seed = _optimization_start_seed(seed, start_index)
        if start_index == 0 and first is not None:
            point = first
            initialization = first_kind
        else:
            point = seeded_initial_point(
                algorithm_kind=algorithm_kind,
                layers=layers,
                parameter_count=len(parameter_names),
                seed=start_seed,
                bounds=optimizer.bounds,
            )
            initialization = "random"
        _validate_initial_point(
            point,
            parameter_names=parameter_names,
            bounds=optimizer.bounds,
        )
        plans.append(
            OptimizationStartPlan(
                start_index=start_index,
                seed=start_seed,
                initialization=initialization,
                parameters=point,
            )
        )
    return tuple(plans)


def aggregate_optimizer_termination(
    starts: tuple[OptimizationStartIR, ...],
    *,
    selected_start_index: int,
) -> OptimizerTerminationIR:
    """Build one total-budget termination summary from per-start evidence."""
    if not starts:
        raise ValueError("starts must not be empty.")
    if (
        not isinstance(selected_start_index, int)
        or isinstance(selected_start_index, bool)
        or not 0 <= selected_start_index < len(starts)
    ):
        raise ValueError("selected_start_index is outside starts.")
    selected = starts[selected_start_index].termination
    if len(starts) == 1:
        return selected
    nit_values = tuple(item.termination.nit for item in starts)
    return OptimizerTerminationIR(
        method=selected.method,
        success=selected.success,
        status=selected.status,
        message=(
            f"Completed {len(starts)} optimizer starts; selected start "
            f"{selected_start_index}. {selected.message}"
        ),
        nfev=sum(item.evaluation_count for item in starts),
        njev=sum(item.gradient_count for item in starts),
        backend_execution_count=sum(
            item.backend_execution_count or 0 for item in starts
        ),
        nit=(
            None
            if any(value is None for value in nit_values)
            else sum(value for value in nit_values if value is not None)
        ),
        reason=selected.reason,
    )


def run_scalar_optimization(
    *,
    parameter_names: tuple[str, ...],
    objective: ScalarObjective,
    optimizer: OptimizerConfig,
    initial_parameters: tuple[float, ...],
    gradient: ScalarGradient | None = None,
    gradient_backend_execution_count: int = 0,
    objective_backend_execution_count: int = 1,
    seed: int | None = None,
    objective_resampling_supported: bool = False,
    objective_evaluation_index_offset: int = 0,
    gradient_index_offset: int = 0,
    sampled_gradient: bool = False,
) -> ScalarOptimizationOutcome:
    """Run one scalar minimization while retaining every objective evaluation.

    Callers own the domain-specific evaluation evidence. This function owns only
    parameter-shape validation, SciPy option translation, termination semantics,
    and the stable rule used to select the lowest observed objective. It always
    executes exactly one supplied initial point; higher-level owners expand
    ``OptimizerConfig.starts`` before calling it.
    """
    if not isinstance(optimizer, OptimizerConfig):
        raise TypeError("optimizer must be OptimizerConfig.")
    if optimizer.method == "ADAM":
        if gradient is None:
            raise ValueError("ADAM requires an ObjectiveGradientIR callback.")
        return run_adam_optimization(
            parameter_names=parameter_names,
            objective=objective,
            gradient=gradient,
            optimizer=optimizer,
            initial_parameters=initial_parameters,
            gradient_backend_execution_count=gradient_backend_execution_count,
            objective_backend_execution_count=objective_backend_execution_count,
            objective_evaluation_index_offset=objective_evaluation_index_offset,
            gradient_index_offset=gradient_index_offset,
            sampled_gradient=sampled_gradient,
        )
    if optimizer.method == "SPSA":
        if gradient is not None or gradient_backend_execution_count != 0:
            raise ValueError("SPSA does not accept an external gradient callback.")
        if seed is None:
            raise ValueError("SPSA requires a deterministic start seed.")
        assert optimizer.spsa is not None
        if optimizer.spsa.objective_repeats > 1 and not objective_resampling_supported:
            raise ValueError(
                "SPSA objective_repeats greater than 1 require sampled VQE."
            )
        if (
            optimizer.spsa.stopping is not None
            and optimizer.spsa.stopping.sampled_standard_error_tolerance is not None
            and not objective_resampling_supported
        ):
            raise ValueError(
                "sampled standard-error stopping requires a sampled objective."
            )
        return run_spsa_optimization(
            parameter_names=parameter_names,
            objective=objective,
            optimizer=optimizer,
            initial_parameters=initial_parameters,
            seed=seed,
            objective_backend_execution_count=objective_backend_execution_count,
            objective_resampling_supported=objective_resampling_supported,
        )

    if not parameter_names or any(
        not isinstance(name, str) or not name.strip() for name in parameter_names
    ):
        raise ValueError("parameter_names must contain non-empty strings.")
    if len(parameter_names) != len(set(parameter_names)):
        raise ValueError("parameter_names must be unique.")
    if not callable(objective):
        raise TypeError("objective must be callable.")
    if not isinstance(optimizer, OptimizerConfig):
        raise TypeError("optimizer must be OptimizerConfig.")
    if optimizer.gradient is None:
        if gradient is not None:
            raise ValueError("gradient callback requires optimizer GradientConfig.")
    elif not callable(gradient):
        raise ValueError("gradient optimizer requires a gradient callback.")
    if (
        not isinstance(objective_backend_execution_count, int)
        or isinstance(objective_backend_execution_count, bool)
        or objective_backend_execution_count <= 0
    ):
        raise ValueError(
            "objective_backend_execution_count must be a positive integer."
        )
    if (
        not isinstance(gradient_backend_execution_count, int)
        or isinstance(gradient_backend_execution_count, bool)
        or gradient_backend_execution_count < 0
    ):
        raise ValueError(
            "gradient_backend_execution_count must be a non-negative integer."
        )
    if optimizer.gradient is not None and gradient_backend_execution_count <= 0:
        raise ValueError(
            "gradient optimizer requires a positive Backend cost per gradient."
        )
    if len(initial_parameters) != len(parameter_names):
        raise ValueError("initial parameters must match parameter_names.")
    point = tuple(float(value) for value in initial_parameters)
    if any(not math.isfinite(value) for value in point):
        raise ValueError("initial parameters must be finite.")

    _validate_bounds(optimizer, parameter_names)
    _validate_cobyla_budget(optimizer, parameter_count=len(parameter_names))
    if (
        optimizer.gradient is not None
        and optimizer.max_backend_executions is not None
        and optimizer.max_backend_executions
        < objective_backend_execution_count + gradient_backend_execution_count
    ):
        raise ValueError(
            "max_backend_executions must cover the initial objective and one "
            "complete gradient."
        )
    for index, (value, bound) in enumerate(zip(point, optimizer.bounds)):
        lower, upper = bound
        if not lower <= value <= upper:
            raise ValueError(
                f"initial parameter '{parameter_names[index]}' is outside optimizer "
                "bounds."
            )

    objective_values: list[float] = []
    objective_points: list[tuple[float, ...]] = []
    gradient_values: list[tuple[float, ...]] = []
    callback_error: Exception | None = None

    def backend_execution_count() -> int:
        return len(objective_values) * objective_backend_execution_count + (
            len(gradient_values) * gradient_backend_execution_count
        )

    def scipy_objective(values: NDArray[np.float64]) -> float:
        nonlocal callback_error
        if callback_error is not None:
            return float(np.finfo(np.float64).max / 4.0)
        try:
            if (
                optimizer.method == "L-BFGS-B"
                and optimizer.max_evaluations is not None
                and len(objective_values) >= optimizer.max_evaluations
            ):
                raise _OptimizationBudgetExhausted("max_evaluations")
            if (
                optimizer.max_backend_executions is not None
                and backend_execution_count() + objective_backend_execution_count
                > optimizer.max_backend_executions
            ):
                raise _OptimizationBudgetExhausted("max_backend_executions")
            raw = tuple(float(value) for value in values)
            if any(not math.isfinite(value) for value in raw):
                raise ValueError("optimizer parameters must remain finite.")
            # Legacy COBYLA treats bounds as inequality constraints and may probe
            # outside them while building its initial simplex. Projecting the point
            # keeps strict Parameter domains executable while preserving one real
            # domain evaluation for every SciPy function evaluation.
            normalized = _project_to_bounds(raw, optimizer.bounds)
            value = float(objective(normalized, len(objective_values)))
            if not math.isfinite(value):
                raise ValueError("objective must return a finite value.")
            objective_values.append(value)
            objective_points.append(normalized)
            return value
        except Exception as error:
            # SciPy 1.13's Fortran COBYLA callback cannot safely propagate Python
            # exceptions through F2PY. Defer the original exception until minimize
            # returns; subsequent callbacks receive a finite sentinel and perform no
            # additional domain work.
            callback_error = error
            return float(np.finfo(np.float64).max / 4.0)

    def scipy_gradient(values: NDArray[np.float64]) -> NDArray[np.float64]:
        nonlocal callback_error
        if callback_error is not None:
            return np.zeros(len(parameter_names), dtype=np.float64)
        try:
            assert optimizer.gradient is not None
            assert gradient is not None
            if (
                optimizer.gradient.max_evaluations is not None
                and len(gradient_values) >= optimizer.gradient.max_evaluations
            ):
                raise _OptimizationBudgetExhausted("max_gradient_evaluations")
            if (
                optimizer.max_backend_executions is not None
                and backend_execution_count() + gradient_backend_execution_count
                > optimizer.max_backend_executions
            ):
                raise _OptimizationBudgetExhausted("max_backend_executions")
            raw = tuple(float(value) for value in values)
            if any(not math.isfinite(value) for value in raw):
                raise ValueError("optimizer parameters must remain finite.")
            normalized = _project_to_bounds(raw, optimizer.bounds)
            raw_gradient = gradient(normalized, len(gradient_values))
            if isinstance(raw_gradient, ObjectiveGradientIR):
                raise TypeError(
                    "L-BFGS-B gradient callback must return numeric components."
                )
            computed = tuple(float(value) for value in raw_gradient)
            if len(computed) != len(parameter_names):
                raise ValueError("gradient must match the optimizer parameter count.")
            if any(not math.isfinite(value) for value in computed):
                raise ValueError("gradient must contain only finite values.")
            gradient_values.append(computed)
            return np.asarray(computed, dtype=np.float64)
        except Exception as error:
            callback_error = error
            return np.zeros(len(parameter_names), dtype=np.float64)

    scipy_options, cobyla_limit_reason = _scipy_options(optimizer)
    scipy_result = minimize(
        scipy_objective,
        np.asarray(point, dtype=np.float64),
        method=optimizer.method,
        jac=scipy_gradient if optimizer.gradient is not None else None,
        bounds=optimizer.bounds or None,
        tol=optimizer.tolerance,
        options=scipy_options,
    )
    if callback_error is not None and not isinstance(
        callback_error,
        _OptimizationBudgetExhausted,
    ):
        raise callback_error
    nfev = len(objective_values)
    njev = len(gradient_values)
    if callback_error is None and int(scipy_result.nfev) != nfev:
        raise RuntimeError("SciPy nfev does not match the recorded objective history.")
    scipy_njev = int(scipy_result.get("njev", 0))
    if callback_error is None and scipy_njev != njev:
        raise RuntimeError("SciPy njev does not match the recorded gradient history.")
    if not objective_values:
        raise RuntimeError("SciPy completed without evaluating the objective.")
    best_index = min(
        range(len(objective_values)),
        key=lambda index: (objective_values[index], index),
    )
    backend_count = backend_execution_count()
    if isinstance(callback_error, _OptimizationBudgetExhausted):
        final_parameters = objective_points[-1]
        final_objective = objective_values[-1]
        termination = OptimizerTerminationIR(
            method=optimizer.method,
            success=False,
            status=1,
            message=f"CASCAQit stopped at {callback_error.reason}.",
            nfev=nfev,
            njev=njev,
            backend_execution_count=backend_count,
            nit=None,
            reason=callback_error.reason,
        )
    else:
        final_parameters = _project_to_bounds(
            tuple(float(value) for value in scipy_result.x),
            optimizer.bounds,
        )
        final_objective = float(scipy_result.fun)
        termination = _termination(
            scipy_result,
            config=optimizer,
            nfev=nfev,
            njev=njev,
            backend_execution_count=backend_count,
            cobyla_limit_reason=cobyla_limit_reason,
        )
    return ScalarOptimizationOutcome(
        initial_parameters=point,
        final_parameters=final_parameters,
        final_objective=final_objective,
        objective_values=tuple(objective_values),
        best_evaluation_index=best_index,
        termination=termination,
        gradient_values=tuple(gradient_values),
    )


def run_adam_optimization(
    *,
    parameter_names: tuple[str, ...],
    objective: ScalarObjective,
    gradient: ScalarGradient,
    optimizer: OptimizerConfig,
    initial_parameters: tuple[float, ...],
    gradient_backend_execution_count: int,
    objective_backend_execution_count: int = 1,
    objective_evaluation_index_offset: int = 0,
    gradient_index_offset: int = 0,
    sampled_gradient: bool = False,
) -> ScalarOptimizationOutcome:
    """Run one native Adam start with auditable gradients and atomic budgets.

    A complete iteration owns one full ``ObjectiveGradientIR`` followed by the
    objective at the projected update. Budget checks happen before either
    callback, so a resource limit cannot leave a gradient-only half iteration.
    """
    if not isinstance(optimizer, OptimizerConfig) or optimizer.method != "ADAM":
        raise ValueError("run_adam_optimization requires an ADAM OptimizerConfig.")
    if not isinstance(sampled_gradient, bool):
        raise TypeError("sampled_gradient must be bool.")
    if not parameter_names or any(
        not isinstance(name, str) or not name.strip() for name in parameter_names
    ):
        raise ValueError("parameter_names must contain non-empty strings.")
    if len(parameter_names) != len(set(parameter_names)):
        raise ValueError("parameter_names must be unique.")
    if not callable(objective):
        raise TypeError("objective must be callable.")
    if not callable(gradient):
        raise TypeError("gradient must be callable.")
    if (
        not isinstance(objective_backend_execution_count, int)
        or isinstance(objective_backend_execution_count, bool)
        or objective_backend_execution_count <= 0
    ):
        raise ValueError(
            "objective_backend_execution_count must be a positive integer."
        )
    if (
        not isinstance(gradient_backend_execution_count, int)
        or isinstance(gradient_backend_execution_count, bool)
        or gradient_backend_execution_count <= 0
    ):
        raise ValueError("gradient_backend_execution_count must be a positive integer.")
    for value, name in (
        (objective_evaluation_index_offset, "objective_evaluation_index_offset"),
        (gradient_index_offset, "gradient_index_offset"),
    ):
        if not isinstance(value, int) or isinstance(value, bool) or value < 0:
            raise ValueError(f"{name} must be a non-negative integer.")

    assert optimizer.gradient is not None
    assert optimizer.adam is not None
    if (
        optimizer.adam.stopping is not None
        and optimizer.adam.stopping.gradient_uncertainty_norm_tolerance is not None
        and not sampled_gradient
    ):
        raise ValueError(
            "gradient uncertainty stopping requires sampled VQE gradients."
        )
    _validate_bounds(optimizer, parameter_names)
    point = tuple(float(value) for value in initial_parameters)
    _validate_initial_point(
        point,
        parameter_names=parameter_names,
        bounds=optimizer.bounds,
    )

    # The first resource-consuming callback is allowed only when the declared
    # limits can fund the initial objective and one complete Adam iteration.
    minimum_backend_cost = (
        2 * objective_backend_execution_count + gradient_backend_execution_count
    )
    if optimizer.max_evaluations is not None and optimizer.max_evaluations < 2:
        raise ValueError(
            "the ADAM evaluation budget must cover the initial and updated "
            "objectives of one complete iteration."
        )
    if (
        optimizer.gradient.max_evaluations is not None
        and optimizer.gradient.max_evaluations < 1
    ):
        raise ValueError("the ADAM gradient budget must cover one complete iteration.")
    if (
        optimizer.max_backend_executions is not None
        and optimizer.max_backend_executions < minimum_backend_cost
    ):
        raise ValueError(
            "max_backend_executions must cover the initial objective and one "
            "complete ADAM iteration."
        )

    objective_values: list[float] = []
    gradient_values: list[tuple[float, ...]] = []
    iterations: list[AdamIterationIR] = []
    first_moment = {name: 0.0 for name in parameter_names}
    second_moment = {name: 0.0 for name in parameter_names}
    bounds = {name: bound for name, bound in zip(parameter_names, optimizer.bounds)}

    def evaluate(values: tuple[float, ...]) -> float:
        value = float(objective(values, len(objective_values)))
        if not math.isfinite(value):
            raise ValueError("objective must return a finite value.")
        objective_values.append(value)
        return value

    evaluate(point)
    stopping_evidence: AdamStoppingEvidenceIR | None = None
    termination_reason: Literal[
        "stability_reached",
        "max_iterations",
        "max_evaluations",
        "max_gradient_evaluations",
        "max_backend_executions",
    ] = "max_iterations"

    while True:
        if len(iterations) >= optimizer.max_iterations:
            termination_reason = "max_iterations"
            break
        if (
            optimizer.max_evaluations is not None
            and len(objective_values) + 1 > optimizer.max_evaluations
        ):
            termination_reason = "max_evaluations"
            break
        if (
            optimizer.gradient.max_evaluations is not None
            and len(iterations) + 1 > optimizer.gradient.max_evaluations
        ):
            termination_reason = "max_gradient_evaluations"
            break
        current_backend_count = len(
            objective_values
        ) * objective_backend_execution_count + sum(
            item.gradient_backend_execution_count for item in iterations
        )
        if (
            optimizer.max_backend_executions is not None
            and current_backend_count
            + gradient_backend_execution_count
            + objective_backend_execution_count
            > optimizer.max_backend_executions
        ):
            termination_reason = "max_backend_executions"
            break

        local_gradient_index = len(iterations)
        if optimizer.gradient.repeat_mode == "adaptive":
            available_gradient_backend: int | None = None
            if optimizer.max_backend_executions is not None:
                available_gradient_backend = (
                    optimizer.max_backend_executions
                    - current_backend_count
                    - objective_backend_execution_count
                )
            computed = gradient(
                point,
                local_gradient_index,
                max_backend_executions=available_gradient_backend,
            )
        else:
            computed = gradient(point, local_gradient_index)
        if not isinstance(computed, ObjectiveGradientIR):
            raise TypeError("ADAM gradient callback must return ObjectiveGradientIR.")
        expected_gradient_index = gradient_index_offset + local_gradient_index
        if computed.gradient_index != expected_gradient_index:
            raise ValueError("ADAM gradient index does not match callback order.")
        if tuple(computed.gradient) != parameter_names:
            raise ValueError("ADAM gradient parameters must match parameter_names.")
        if computed.backend_execution_count < gradient_backend_execution_count:
            raise ValueError("ADAM gradient Backend cost is below its minimum plan.")
        if (
            optimizer.max_backend_executions is not None
            and current_backend_count
            + computed.backend_execution_count
            + objective_backend_execution_count
            > optimizer.max_backend_executions
        ):
            raise ValueError("ADAM gradient exceeded its allocated Backend budget.")
        if set(computed.parameter_bind.values) != set(parameter_names) or any(
            not math.isclose(
                computed.parameter_bind.values[name],
                point[index],
                rel_tol=0.0,
                abs_tol=1e-12,
            )
            for index, name in enumerate(parameter_names)
        ):
            raise ValueError("ADAM gradient parameters do not match the center point.")

        component_values = tuple(computed.gradient[name] for name in parameter_names)
        iteration = AdamIterationIR.create(
            iteration_index=local_gradient_index,
            config=optimizer.adam,
            center_objective_evaluation_index=(
                objective_evaluation_index_offset + len(objective_values) - 1
            ),
            updated_objective_evaluation_index=(
                objective_evaluation_index_offset + len(objective_values)
            ),
            center_parameters=dict(zip(parameter_names, point)),
            gradient_index=computed.gradient_index,
            gradient_hash=computed.gradient_hash,
            gradient=computed.gradient,
            gradient_covariance=computed.gradient_covariance,
            gradient_standard_errors=computed.gradient_standard_errors,
            gradient_uncertainty_norm=computed.uncertainty_norm,
            gradient_repeat_count=computed.repeat_count,
            gradient_repeat_stop_reason=computed.repeat_stop_reason,
            previous_first_moment=first_moment,
            previous_second_moment=second_moment,
            bounds=bounds,
            gradient_objective_evaluation_count=(computed.objective_evaluation_count),
            gradient_backend_execution_count=computed.backend_execution_count,
            gradient_total_shots=computed.total_shots,
        )
        updated_point = tuple(
            iteration.updated_parameters[name] for name in parameter_names
        )
        evaluate(updated_point)
        iterations.append(iteration)
        gradient_values.append(component_values)
        point = updated_point
        first_moment = dict(iteration.first_moment)
        second_moment = dict(iteration.second_moment)

        if optimizer.adam.stopping is not None:
            stopping_evidence = AdamStoppingEvidenceIR.create(
                iterations,
                optimizer.adam.stopping,
            )
            if stopping_evidence.status == "stability_reached":
                termination_reason = "stability_reached"
                break

    saved_iterations = validate_adam_iteration_sequence(iterations)
    if stopping_evidence is not None:
        expected_stopping = AdamStoppingEvidenceIR.create(
            saved_iterations,
            stopping_evidence.config,
        )
        if stopping_evidence != expected_stopping:
            raise RuntimeError("ADAM stopping evidence changed after execution.")
    best_index = min(
        range(len(objective_values)),
        key=lambda index: (objective_values[index], index),
    )
    backend_count = len(objective_values) * objective_backend_execution_count + sum(
        item.gradient_backend_execution_count for item in saved_iterations
    )
    success = termination_reason == "stability_reached"
    message = (
        "ADAM projected update norm reached the configured stability window."
        if success
        else f"ADAM stopped at {termination_reason}."
    )
    return ScalarOptimizationOutcome(
        initial_parameters=tuple(float(value) for value in initial_parameters),
        final_parameters=point,
        final_objective=objective_values[-1],
        objective_values=tuple(objective_values),
        best_evaluation_index=best_index,
        termination=OptimizerTerminationIR(
            method="ADAM",
            success=success,
            status=0 if success else 1,
            message=message,
            nfev=len(objective_values),
            njev=len(saved_iterations),
            backend_execution_count=backend_count,
            nit=len(saved_iterations),
            reason=termination_reason,
        ),
        gradient_values=tuple(gradient_values),
        adam_iterations=saved_iterations,
        adam_stopping_evidence=stopping_evidence,
    )


def run_spsa_optimization(
    *,
    parameter_names: tuple[str, ...],
    objective: ScalarObjective,
    optimizer: OptimizerConfig,
    initial_parameters: tuple[float, ...],
    seed: int,
    objective_backend_execution_count: int = 1,
    objective_resampling_supported: bool = False,
) -> ScalarOptimizationOutcome:
    """Run one native SPSA start with atomic multi-direction budgets.

    The evaluation order is an externally validated invariant: initial center,
    each iteration's ordered complete plus/minus directions, then the final
    updated center. Keeping the final center as a real objective evaluation
    distinguishes the returned optimizer point from the best perturbation point
    observed along the way.
    """
    if not parameter_names or any(
        not isinstance(name, str) or not name.strip() for name in parameter_names
    ):
        raise ValueError("parameter_names must contain non-empty strings.")
    if len(parameter_names) != len(set(parameter_names)):
        raise ValueError("parameter_names must be unique.")
    if not callable(objective):
        raise TypeError("objective must be callable.")
    if not isinstance(optimizer, OptimizerConfig) or optimizer.method != "SPSA":
        raise ValueError("run_spsa_optimization requires an SPSA OptimizerConfig.")
    if not isinstance(seed, int) or isinstance(seed, bool) or seed < 0:
        raise ValueError("seed must be a non-negative integer.")
    if (
        not isinstance(objective_backend_execution_count, int)
        or isinstance(objective_backend_execution_count, bool)
        or objective_backend_execution_count <= 0
    ):
        raise ValueError(
            "objective_backend_execution_count must be a positive integer."
        )
    if len(initial_parameters) != len(parameter_names):
        raise ValueError("initial parameters must match parameter_names.")
    point = tuple(float(value) for value in initial_parameters)
    if any(not math.isfinite(value) for value in point):
        raise ValueError("initial parameters must be finite.")
    _validate_bounds(optimizer, parameter_names)
    for index, (value, bound) in enumerate(zip(point, optimizer.bounds)):
        lower, upper = bound
        if not lower <= value <= upper:
            raise ValueError(
                f"initial parameter '{parameter_names[index]}' is outside optimizer "
                "bounds."
            )

    config = optimizer.spsa
    assert config is not None
    stopping = config.stopping
    if (
        stopping is not None
        and stopping.sampled_standard_error_tolerance is not None
        and not objective_resampling_supported
    ):
        raise ValueError(
            "sampled standard-error stopping requires a sampled objective."
        )
    adaptive_repeats = config.objective_repeat_mode == "adaptive"
    evaluation_limit: int | None = None
    budget_limit_reason: Literal[
        "max_evaluations",
        "max_backend_executions",
    ] | None = None
    if adaptive_repeats:
        evaluation_limit, budget_limit_reason = _spsa_adaptive_evaluation_budget(
            optimizer,
            objective_backend_execution_count=objective_backend_execution_count,
        )
        iteration_limit = optimizer.max_iterations
        limit_reason: Literal[
            "max_iterations",
            "max_evaluations",
            "max_backend_executions",
        ] = "max_iterations"
    else:
        iteration_limit, limit_reason = _spsa_iteration_budget(
            optimizer,
            objective_backend_execution_count=objective_backend_execution_count,
        )
    if stopping is not None and iteration_limit < stopping.min_iterations:
        raise ValueError(
            "the SPSA evaluation budget must cover stopping min_iterations."
        )
    if stopping is not None and evaluation_limit is not None:
        calibration_budget_directions = (
            0
            if config.learning_rate_calibration is None
            else config.learning_rate_calibration.directions
        )
        minimum_stopping_evaluations = config.objective_repeats * (
            2
            + 2 * calibration_budget_directions
            + 2 * config.directions_per_iteration * stopping.min_iterations
        )
        if evaluation_limit < minimum_stopping_evaluations:
            raise ValueError(
                "the adaptive SPSA budget must cover stopping min_iterations."
            )
    rng = np.random.default_rng(seed)
    objective_values: list[float] = []
    objective_points: list[tuple[float, ...]] = []
    iterations: list[SPSAIterationIR] = []
    estimates: list[SPSAObjectiveEstimateIR] = []

    def evaluate_once(values: tuple[float, ...]) -> tuple[int, float]:
        offset = len(objective_values)
        value = float(objective(values, offset))
        if not math.isfinite(value):
            raise ValueError("objective must return a finite value.")
        objective_points.append(values)
        objective_values.append(value)
        return offset, value

    def has_capacity(additional: int, *, reserve: int = 0) -> bool:
        return evaluation_limit is None or (
            len(objective_values) + additional + reserve <= evaluation_limit
        )

    def target_reached(values: list[float]) -> bool:
        target = config.objective_standard_error_target
        assert target is not None
        estimate = SPSAObjectiveEstimateIR.create(
            role="initial",
            evaluation_offsets=tuple(range(len(values))),
            objective_values=tuple(values),
            stop_reason="target_reached",
        )
        assert estimate.pooled_standard_error is not None
        return estimate.pooled_standard_error <= target

    def build_estimate(
        role: Literal["initial", "plus", "minus", "final"],
        offsets: list[int],
        values_for_estimate: list[float],
        stop_reason: SPSAObjectiveStopReason,
    ) -> SPSAObjectiveEstimateIR:
        estimate = SPSAObjectiveEstimateIR.create(
            role=role,
            evaluation_offsets=tuple(offsets),
            objective_values=tuple(values_for_estimate),
            stop_reason=stop_reason,
        )
        estimates.append(estimate)
        return estimate

    def evaluate_fixed(
        values: tuple[float, ...],
        role: Literal["initial", "plus", "minus", "final"],
    ) -> SPSAObjectiveEstimateIR:
        offsets: list[int] = []
        values_for_estimate: list[float] = []
        for _ in range(config.objective_repeats):
            offset, value = evaluate_once(values)
            offsets.append(offset)
            values_for_estimate.append(value)
        return build_estimate(
            role,
            offsets,
            values_for_estimate,
            "fixed_repeats",
        )

    def evaluate_adaptive_center(
        values: tuple[float, ...],
        role: Literal["initial", "final"],
        *,
        reserve: int,
    ) -> SPSAObjectiveEstimateIR:
        offsets: list[int] = []
        values_for_estimate: list[float] = []
        for _ in range(config.objective_repeats):
            offset, value = evaluate_once(values)
            offsets.append(offset)
            values_for_estimate.append(value)
        stop_reason: SPSAObjectiveStopReason
        while True:
            if target_reached(values_for_estimate):
                stop_reason = "target_reached"
                break
            if len(offsets) >= config.effective_max_objective_repeats:
                stop_reason = "max_repeats_reached"
                break
            if not has_capacity(1, reserve=reserve):
                stop_reason = "budget_exhausted"
                break
            offset, value = evaluate_once(values)
            offsets.append(offset)
            values_for_estimate.append(value)
        return build_estimate(
            role,
            offsets,
            values_for_estimate,
            stop_reason,
        )

    def evaluate_adaptive_pair(
        plus_values: tuple[float, ...],
        minus_values: tuple[float, ...],
        *,
        reserve: int,
    ) -> tuple[SPSAObjectiveEstimateIR, SPSAObjectiveEstimateIR]:
        plus_offsets: list[int] = []
        minus_offsets: list[int] = []
        plus_objectives: list[float] = []
        minus_objectives: list[float] = []
        for _ in range(config.objective_repeats):
            offset, value = evaluate_once(plus_values)
            plus_offsets.append(offset)
            plus_objectives.append(value)
        for _ in range(config.objective_repeats):
            offset, value = evaluate_once(minus_values)
            minus_offsets.append(offset)
            minus_objectives.append(value)
        stop_reason: SPSAObjectiveStopReason
        while True:
            if target_reached(plus_objectives) and target_reached(minus_objectives):
                stop_reason = "target_reached"
                break
            if len(plus_offsets) >= config.effective_max_objective_repeats:
                stop_reason = "max_repeats_reached"
                break
            if not has_capacity(2, reserve=reserve):
                stop_reason = "budget_exhausted"
                break
            offset, value = evaluate_once(plus_values)
            plus_offsets.append(offset)
            plus_objectives.append(value)
            offset, value = evaluate_once(minus_values)
            minus_offsets.append(offset)
            minus_objectives.append(value)
        plus_estimate = build_estimate(
            "plus",
            plus_offsets,
            plus_objectives,
            stop_reason,
        )
        minus_estimate = build_estimate(
            "minus",
            minus_offsets,
            minus_objectives,
            stop_reason,
        )
        return plus_estimate, minus_estimate

    def evaluate_direction(
        center_values: tuple[float, ...],
        perturbation: float,
        direction_index: int,
        *,
        reserve: int,
    ) -> tuple[
        SPSADirectionIR,
        tuple[float, ...],
        tuple[float, ...],
        tuple[float, ...],
        tuple[float, ...],
    ]:
        """Execute one complete direction and retain raw/projected points."""
        delta = tuple(
            int(value)
            for value in rng.choice(
                np.asarray((-1, 1), dtype=np.int8),
                size=len(parameter_names),
            )
        )
        raw_plus = tuple(
            value + perturbation * direction
            for value, direction in zip(center_values, delta)
        )
        raw_minus = tuple(
            value - perturbation * direction
            for value, direction in zip(center_values, delta)
        )
        plus = _project_to_bounds(raw_plus, optimizer.bounds)
        minus = _project_to_bounds(raw_minus, optimizer.bounds)
        if all(
            math.isclose(plus_value, minus_value, rel_tol=0.0, abs_tol=1e-15)
            for plus_value, minus_value in zip(plus, minus)
        ):
            raise ValueError("SPSA direction is degenerate after bounds projection.")
        if adaptive_repeats:
            plus_estimate, minus_estimate = evaluate_adaptive_pair(
                plus,
                minus,
                reserve=reserve,
            )
        else:
            plus_estimate = evaluate_fixed(plus, "plus")
            minus_estimate = evaluate_fixed(minus, "minus")
        objective_difference = (
            plus_estimate.pooled_objective - minus_estimate.pooled_objective
        )
        direction_gradient = tuple(
            objective_difference / (2.0 * perturbation) * direction
            for direction in delta
        )
        direction = SPSADirectionIR(
            direction_index=direction_index,
            perturbation_vector=dict(zip(parameter_names, delta)),
            plus_parameters=dict(zip(parameter_names, plus)),
            minus_parameters=dict(zip(parameter_names, minus)),
            plus_estimate=plus_estimate,
            minus_estimate=minus_estimate,
            gradient_estimate=dict(zip(parameter_names, direction_gradient)),
        )
        return direction, raw_plus, plus, raw_minus, minus

    direction_count = config.directions_per_iteration
    calibration_config = config.learning_rate_calibration
    calibration_direction_count = (
        0 if calibration_config is None else calibration_config.directions
    )
    required_iteration_count = 1 if stopping is None else stopping.min_iterations

    # 初始中心之后为完整校准、所需正式轮次和最终中心保留最小预算。
    if adaptive_repeats:
        evaluate_adaptive_center(
            point,
            "initial",
            reserve=(
                2 * calibration_direction_count
                + 2 * direction_count * required_iteration_count
                + 1
            )
            * config.objective_repeats,
        )
    else:
        evaluate_fixed(point, "initial")

    calibration_evidence: SPSALearningRateCalibrationIR | None = None
    learning_rate_scale = config.learning_rate
    if calibration_config is not None:
        calibration_direction_evidence: list[SPSADirectionIR] = []
        calibration_projected = False
        for calibration_index in range(calibration_direction_count):
            remaining_calibration = (
                calibration_direction_count - calibration_index - 1
            )
            direction, raw_plus, plus, raw_minus, minus = evaluate_direction(
                point,
                config.perturbation,
                calibration_index,
                reserve=(
                    2 * remaining_calibration
                    + 2 * direction_count * required_iteration_count
                    + 1
                )
                * config.objective_repeats,
            )
            calibration_direction_evidence.append(direction)
            calibration_projected = calibration_projected or any(
                raw != projected
                for raw_values, projected_values in (
                    (raw_plus, plus),
                    (raw_minus, minus),
                )
                for raw, projected in zip(raw_values, projected_values)
            )
        calibration_gradient = tuple(
            math.fsum(values) / calibration_direction_count
            for values in zip(
                *(
                    tuple(direction.gradient_estimate.values())
                    for direction in calibration_direction_evidence
                )
            )
        )
        gradient_rms = math.sqrt(
            math.fsum(value * value for value in calibration_gradient)
            / len(calibration_gradient)
        )
        if gradient_rms < calibration_config.gradient_rms_floor:
            raise ValueError(
                "SPSA calibration gradient RMS is below gradient_rms_floor."
            )
        learning_rate_scale = (
            calibration_config.target_update_rms
            * (1.0 + config.stability_constant) ** config.learning_rate_exponent
            / gradient_rms
        )
        if (
            calibration_config.max_learning_rate is not None
            and learning_rate_scale > calibration_config.max_learning_rate
        ):
            raise ValueError(
                "derived SPSA learning rate exceeds max_learning_rate."
            )
        calibration_evidence = SPSALearningRateCalibrationIR(
            parameter_names=parameter_names,
            center_parameters=dict(zip(parameter_names, point)),
            perturbation=config.perturbation,
            directions=tuple(calibration_direction_evidence),
            gradient_estimate=dict(zip(parameter_names, calibration_gradient)),
            gradient_rms=gradient_rms,
            target_update_rms=calibration_config.target_update_rms,
            derived_learning_rate=learning_rate_scale,
            projection_applied=calibration_projected,
        )
    assert learning_rate_scale is not None
    center = point
    converged = False
    stability_reached = False
    stopped_by_budget = False
    stopping_evidence: SPSAStoppingEvidenceIR | None = None
    for iteration_index in range(iteration_limit):
        if adaptive_repeats and not has_capacity(
            2 * direction_count * config.objective_repeats,
            reserve=config.objective_repeats,
        ):
            stopped_by_budget = True
            break
        learning_rate = (
            learning_rate_scale
            / (iteration_index + 1 + config.stability_constant)
            ** config.learning_rate_exponent
        )
        perturbation = (
            config.perturbation / (iteration_index + 1) ** config.perturbation_exponent
        )
        directions: list[SPSADirectionIR] = []
        direction_gradients: list[tuple[float, ...]] = []
        projected_direction_points: list[
            tuple[
                tuple[float, ...],
                tuple[float, ...],
                tuple[float, ...],
                tuple[float, ...],
            ]
        ] = []
        for direction_index in range(direction_count):
            remaining_direction_count = direction_count - direction_index - 1
            remaining_required_iterations = (
                0
                if stopping is None
                else max(0, stopping.min_iterations - iteration_index - 1)
            )
            direction, raw_plus, plus, raw_minus, minus = evaluate_direction(
                center,
                perturbation,
                direction_index,
                reserve=(
                    2 * remaining_direction_count
                    + 2 * direction_count * remaining_required_iterations
                    + 1
                )
                * config.objective_repeats,
            )
            direction_gradients.append(tuple(direction.gradient_estimate.values()))
            projected_direction_points.append((raw_plus, plus, raw_minus, minus))
            directions.append(direction)
        gradient_estimate = tuple(
            math.fsum(values) / direction_count
            for values in zip(*direction_gradients)
        )
        gradient_standard_error = (
            None
            if direction_count == 1
            else tuple(
                math.sqrt(
                    math.fsum((value - mean) ** 2 for value in values)
                    / (direction_count - 1)
                )
                / math.sqrt(direction_count)
                for values, mean in zip(
                    zip(*direction_gradients),
                    gradient_estimate,
                )
            )
        )
        unprojected = tuple(
            value - learning_rate * gradient
            for value, gradient in zip(center, gradient_estimate)
        )
        updated = _project_to_bounds(unprojected, optimizer.bounds)
        update_norm = math.sqrt(
            sum((new - old) ** 2 for old, new in zip(center, updated))
        )
        projection_applied = any(
            raw != projected
            for raw_values, projected_values in (
                *(
                    pair
                    for raw_plus, plus, raw_minus, minus
                    in projected_direction_points
                    for pair in ((raw_plus, plus), (raw_minus, minus))
                ),
                (unprojected, updated),
            )
            for raw, projected in zip(raw_values, projected_values)
        )
        iterations.append(
            SPSAIterationIR(
                iteration_index=iteration_index,
                learning_rate=learning_rate,
                perturbation=perturbation,
                center_parameters=dict(zip(parameter_names, center)),
                directions=tuple(directions),
                gradient_estimate=dict(zip(parameter_names, gradient_estimate)),
                gradient_standard_error=(
                    None
                    if gradient_standard_error is None
                    else dict(
                        zip(parameter_names, gradient_standard_error)
                    )
                ),
                unprojected_parameters=dict(zip(parameter_names, unprojected)),
                updated_parameters=dict(zip(parameter_names, updated)),
                update_norm=update_norm,
                projection_applied=projection_applied,
            )
        )
        center = updated
        if stopping is not None:
            stopping_evidence = derive_spsa_stopping_evidence(iterations, stopping)
        if update_norm <= optimizer.tolerance:
            converged = True
            break
        if (
            stopping_evidence is not None
            and stopping_evidence.status == "stability_reached"
        ):
            stability_reached = True
            break

    if adaptive_repeats:
        final_estimate = evaluate_adaptive_center(center, "final", reserve=0)
    else:
        final_estimate = evaluate_fixed(center, "final")
    final_objective = final_estimate.pooled_objective
    best_estimate = min(
        estimates,
        key=lambda item: (item.pooled_objective, item.source_evaluation_offset),
    )
    best_index = best_estimate.source_evaluation_offset
    if converged:
        reason: Literal[
            "completed",
            "stability_reached",
            "max_iterations",
            "max_evaluations",
            "max_backend_executions",
        ] = "completed"
        message = "SPSA update norm reached the configured tolerance."
        status = 0
    elif stability_reached:
        reason = "stability_reached"
        message = "SPSA online stability thresholds were reached."
        status = 0
    elif stopped_by_budget:
        assert budget_limit_reason is not None
        reason = budget_limit_reason
        message = f"SPSA stopped at {budget_limit_reason}."
        status = 1
    else:
        reason = limit_reason
        message = f"SPSA stopped at {limit_reason}."
        status = 1
    termination = OptimizerTerminationIR(
        method="SPSA",
        success=converged or stability_reached,
        status=status,
        message=message,
        nfev=len(objective_values),
        nit=len(iterations),
        reason=reason,
        backend_execution_count=(
            len(objective_values) * objective_backend_execution_count
        ),
    )
    return ScalarOptimizationOutcome(
        initial_parameters=point,
        final_parameters=center,
        final_objective=final_objective,
        objective_values=tuple(objective_values),
        best_evaluation_index=best_index,
        termination=termination,
        spsa_iterations=tuple(iterations),
        objective_estimates=tuple(estimates),
        spsa_learning_rate_calibration=calibration_evidence,
        spsa_stopping_evidence=stopping_evidence,
    )


def _spsa_adaptive_evaluation_budget(
    optimizer: OptimizerConfig,
    *,
    objective_backend_execution_count: int,
) -> tuple[
    int | None,
    Literal["max_evaluations", "max_backend_executions"] | None,
]:
    """Resolve the hard evaluation cap for adaptive SPSA resampling."""
    config = optimizer.spsa
    assert config is not None
    calibration_directions = (
        0
        if config.learning_rate_calibration is None
        else config.learning_rate_calibration.directions
    )
    minimum_evaluations = (
        2
        + 2 * calibration_directions
        + 2 * config.directions_per_iteration
    ) * config.objective_repeats
    limits: list[
        tuple[int, Literal["max_evaluations", "max_backend_executions"]]
    ] = []
    if optimizer.max_evaluations is not None:
        if optimizer.max_evaluations < minimum_evaluations:
            raise ValueError(
                f"max_evaluations must be at least {minimum_evaluations} for one "
                "complete SPSA iteration."
            )
        limits.append((optimizer.max_evaluations, "max_evaluations"))
    if optimizer.max_backend_executions is not None:
        available_evaluations = (
            optimizer.max_backend_executions // objective_backend_execution_count
        )
        if available_evaluations < minimum_evaluations:
            minimum = minimum_evaluations * objective_backend_execution_count
            raise ValueError(
                f"max_backend_executions must cover at least {minimum_evaluations} "
                "objective evaluations for one complete SPSA iteration "
                f"({minimum} Backend executions)."
            )
        limits.append((available_evaluations, "max_backend_executions"))
    if not limits:
        return None, None
    return min(limits, key=lambda item: item[0])


def _spsa_iteration_budget(
    optimizer: OptimizerConfig,
    *,
    objective_backend_execution_count: int = 1,
) -> tuple[
    int,
    Literal["max_iterations", "max_evaluations", "max_backend_executions"],
]:
    """Resolve complete SPSA pairs before the first objective evaluation."""
    limits: list[
        tuple[
            int,
            Literal["max_iterations", "max_evaluations", "max_backend_executions"],
        ]
    ] = [(optimizer.max_iterations, "max_iterations")]
    budget_limits: tuple[
        tuple[
            int | None,
            Literal["max_evaluations", "max_backend_executions"],
        ],
        ...,
    ] = ((optimizer.max_evaluations, "max_evaluations"),)
    for budget, budget_reason in budget_limits:
        if budget is None:
            continue
        repeats = optimizer.spsa.objective_repeats if optimizer.spsa is not None else 1
        direction_count = (
            optimizer.spsa.directions_per_iteration
            if optimizer.spsa is not None
            else 1
        )
        calibration_directions = (
            0
            if optimizer.spsa is None
            or optimizer.spsa.learning_rate_calibration is None
            else optimizer.spsa.learning_rate_calibration.directions
        )
        base_evaluations = (2 + 2 * calibration_directions) * repeats
        minimum_evaluations = base_evaluations + 2 * direction_count * repeats
        if budget < minimum_evaluations:
            raise ValueError(
                f"{budget_reason} must be at least {minimum_evaluations} for one "
                "complete SPSA iteration."
            )
        limits.append(
            (
                (budget - base_evaluations) // (2 * direction_count * repeats),
                budget_reason,
            )
        )
    if optimizer.max_backend_executions is not None:
        available_evaluations = (
            optimizer.max_backend_executions // objective_backend_execution_count
        )
        repeats = optimizer.spsa.objective_repeats if optimizer.spsa is not None else 1
        direction_count = (
            optimizer.spsa.directions_per_iteration
            if optimizer.spsa is not None
            else 1
        )
        calibration_directions = (
            0
            if optimizer.spsa is None
            or optimizer.spsa.learning_rate_calibration is None
            else optimizer.spsa.learning_rate_calibration.directions
        )
        base_evaluations = (2 + 2 * calibration_directions) * repeats
        minimum_evaluations = base_evaluations + 2 * direction_count * repeats
        if available_evaluations < minimum_evaluations:
            minimum = minimum_evaluations * objective_backend_execution_count
            raise ValueError(
                f"max_backend_executions must cover at least {minimum_evaluations} "
                "objective "
                "evaluations for one complete SPSA iteration "
                f"({minimum} Backend executions)."
            )
        limits.append(
            (
                (available_evaluations - base_evaluations)
                // (2 * direction_count * repeats),
                "max_backend_executions",
            )
        )
    # 列表顺序也是并列限制的优先级：显式总迭代数优先，其次求值预算，
    # 最后 Backend 预算。无论预算奇偶，都只返回可完整执行的扰动对数量。
    iteration_limit, reason = min(limits, key=lambda item: item[0])
    return iteration_limit, reason


def _project_to_bounds(
    values: tuple[float, ...],
    bounds: tuple[tuple[float, float], ...],
) -> tuple[float, ...]:
    """Project one SciPy point onto the declared closed parameter domain."""
    if not bounds:
        return values
    return tuple(
        min(max(value, lower), upper) for value, (lower, upper) in zip(values, bounds)
    )


def _start_spsa_estimates(
    start: OptimizationStartIR,
) -> tuple[SPSAObjectiveEstimateIR, ...]:
    """Return one start's logical SPSA estimates in execution order."""
    if start.spsa_initial_estimate is None or start.spsa_final_estimate is None:
        return ()
    return (
        start.spsa_initial_estimate,
        *(
            estimate
            for calibration in (start.spsa_learning_rate_calibration,)
            if calibration is not None
            for direction in calibration.directions
            for estimate in (direction.plus_estimate, direction.minus_estimate)
        ),
        *(
            estimate
            for iteration in start.spsa_iterations
            for direction in iteration.directions
            for estimate in (direction.plus_estimate, direction.minus_estimate)
        ),
        start.spsa_final_estimate,
    )


def run_variational_optimization(
    *,
    algorithm_kind: AlgorithmKind,
    algorithm_id: str,
    layers: int,
    parameter_names: tuple[str, ...],
    hamiltonian: PauliHamiltonian,
    ansatz: AnsatzSpecIR,
    evaluator: ObjectiveEvaluator[VariationalObjectiveT],
    circuit_builder: CircuitBuilder,
    gradient_evaluator: GradientEvaluator | None = None,
    problem: OptimizationProblem | None = None,
    mis_penalty: float = 2.0,
    mwis_penalty: float | None = None,
    backend: LocalBackend | None = None,
    optimizer: OptimizerConfig | None = None,
    initial_parameters: ParameterValues | None = None,
    algorithm_run_id: str | None = None,
    final_shots: int = 2048,
    noise: NoiseModel | None = None,
    options: SimulationOptions | None = None,
    measurement: PauliMeasurementConfig | None = None,
    sampled_selection: SampledSelectionConfig | None = None,
) -> VariationalResult[VariationalObjectiveT]:
    """Optimize real objectives, optionally confirm candidates, then sample.

    The returned history is the source of truth for the observed minimum. The
    optimizer's final point is retained as termination metadata because it may not
    be the minimum point observed during the complete callback history. Final
    sampling is a separate Job and never changes optimizer objective history.
    Sampled confirmation, when requested, also remains outside that history.
    """
    if algorithm_kind not in {"qaoa", "vqe"}:
        raise ValueError(f"Unsupported algorithm kind: {algorithm_kind!r}.")
    variational_kind = cast(Literal["qaoa", "vqe"], algorithm_kind)
    if not isinstance(algorithm_id, str) or not algorithm_id.strip():
        raise ValueError("algorithm_id must be a non-empty string.")
    if not isinstance(layers, int) or isinstance(layers, bool) or layers <= 0:
        raise ValueError("layers must be a positive integer.")
    if not isinstance(hamiltonian, PauliHamiltonian):
        raise TypeError("hamiltonian must be PauliHamiltonian.")
    if not isinstance(ansatz, AnsatzSpecIR):
        raise TypeError("ansatz must be AnsatzSpecIR.")
    if ansatz.parameter_names != parameter_names:
        raise ValueError("parameter_names must match the ansatz declaration.")
    if ansatz.logical_order != hamiltonian.logical_order:
        raise ValueError("ansatz and Hamiltonian logical order must match.")
    if not callable(evaluator):
        raise TypeError("evaluator must be callable.")
    if not callable(circuit_builder):
        raise TypeError("circuit_builder must be callable.")
    if (
        not isinstance(final_shots, int)
        or isinstance(final_shots, bool)
        or final_shots <= 0
    ):
        raise ValueError("final_shots must be a positive integer.")

    config = OptimizerConfig() if optimizer is None else optimizer
    if not isinstance(config, OptimizerConfig):
        raise TypeError("optimizer must be OptimizerConfig or None.")
    if backend is not None and not isinstance(backend, LocalBackend):
        raise TypeError("backend must be LocalBackend or None.")
    if noise is not None and not isinstance(noise, NoiseModel):
        raise TypeError("noise must be NoiseModel or None.")
    if options is not None and not isinstance(options, SimulationOptions):
        raise TypeError("options must be SimulationOptions or None.")
    if measurement is not None and not isinstance(measurement, PauliMeasurementConfig):
        raise TypeError("measurement must be PauliMeasurementConfig or None.")
    if sampled_selection is not None and not isinstance(
        sampled_selection,
        SampledSelectionConfig,
    ):
        raise TypeError("sampled_selection must be SampledSelectionConfig or None.")
    if sampled_selection is not None and measurement is None:
        raise ValueError("sampled_selection requires finite-shot VQE measurement.")
    if measurement is not None:
        if variational_kind != "vqe":
            raise ValueError("finite-shot Pauli measurement is available only for VQE.")
        if config.method not in {"SPSA", "ADAM"}:
            raise ValueError("finite-shot VQE optimization requires SPSA or ADAM.")
        if config.method == "SPSA" and config.gradient is not None:
            raise ValueError("finite-shot SPSA does not accept gradients.")
    run_id = algorithm_id if algorithm_run_id is None else algorithm_run_id
    if not isinstance(run_id, str) or not run_id.strip() or run_id != run_id.strip():
        raise ValueError("algorithm_run_id must be a non-empty trimmed string.")

    resolved_seed = _resolve_seed(config, backend)
    plans = build_optimization_start_plans(
        algorithm_kind=variational_kind,
        layers=layers,
        parameter_names=parameter_names,
        optimizer=config,
        initial_parameters=initial_parameters,
        seed=resolved_seed,
    )
    execution_backend = backend or LocalBackend(seed=resolved_seed)
    optimization_circuit = circuit_builder()
    if not isinstance(optimization_circuit, Circuit):
        raise TypeError("circuit_builder must return Circuit.")
    measurement_plan = (
        None
        if measurement is None
        else build_pauli_measurement_plan(
            optimization_circuit,
            hamiltonian,
            config=measurement,
        )
    )
    if sampled_selection is not None:
        assert measurement is not None
        confirmation_plan = build_pauli_measurement_plan(
            optimization_circuit,
            hamiltonian,
            config=sampled_selection.resolved_measurement(measurement),
        )
        initial_confirmation_cost = (
            sampled_selection.candidate_count
            * sampled_selection.repeats_per_candidate
            * confirmation_plan.backend_execution_count
        )
        if (
            sampled_selection.max_backend_executions is not None
            and sampled_selection.max_backend_executions < initial_confirmation_cost
        ):
            raise ValueError(
                "sampled selection max_backend_executions must cover the complete "
                "initial confirmation look "
                f"({initial_confirmation_cost} Backend executions)."
            )
    if noise is not None and measurement is None:
        # 优化器级预检保证 readout-only、trajectory 和资源不支持等配置在
        # SciPy 发起第一个 objective callback 前确定性失败。
        validate_noisy_variational_request(
            optimization_circuit,
            noise=noise,
            options=options,
            backend=execution_backend,
            seed=resolved_seed,
        )
    gradient_plan = None
    gradient_backend_execution_count = 0
    if config.gradient is not None:
        if not callable(gradient_evaluator):
            raise ValueError("gradient optimizer requires a gradient evaluator.")
        # Build the complete plan before the first objective Job. This also fixes
        # the per-gradient Backend cost used by every start's atomic budget check.
        gradient_plan = build_parameter_shift_plan(
            optimization_circuit,
            hamiltonian,
            config=config.gradient,
        )
        gradient_backend_execution_count = (
            gradient_plan.expected_objective_evaluation_count
            * (
                1
                if measurement_plan is None
                else measurement_plan.backend_execution_count
            )
            * config.gradient.repeats
        )
    history: list[VariationalObjectiveT] = []
    gradient_history: list[ObjectiveGradientIR] = []
    start_results: list[OptimizationStartIR] = []
    for plan in plans:
        evaluation_start_index: int = len(history)
        gradient_start_index: int = len(gradient_history)
        start_seed: int = plan.seed

        def objective(
            values: tuple[float, ...],
            evaluation_index: int,
            *,
            _offset: int = evaluation_start_index,
            _seed: int = start_seed,
        ) -> float:
            # Each callback owns a unique global index, Backend Job and ResultIR.
            if measurement is None:
                evaluation = evaluator(
                    values,
                    backend=execution_backend,
                    evaluation_index=_offset + evaluation_index,
                    algorithm_run_id=run_id,
                    seed=_seed,
                    noise=noise,
                    options=options,
                )
            else:
                evaluation = evaluator(
                    values,
                    backend=execution_backend,
                    evaluation_index=_offset + evaluation_index,
                    algorithm_run_id=run_id,
                    seed=_seed,
                    measurement=measurement,
                    noise=noise,
                    options=options,
                )
            expected_type = (
                ObjectiveEvaluationIR
                if measurement is None
                else SampledObjectiveEvaluationIR
            )
            if not isinstance(evaluation, expected_type):
                raise TypeError("objective evaluator returned an incompatible IR type.")
            history.append(evaluation)
            return evaluation.energy

        def gradient(
            values: tuple[float, ...],
            gradient_index: int,
            *,
            max_backend_executions: int | None = None,
            _offset: int = gradient_start_index,
            _seed: int = start_seed,
        ) -> tuple[float, ...] | ObjectiveGradientIR:
            assert gradient_evaluator is not None
            assert config.gradient is not None
            assert gradient_plan is not None
            objective_offset = sum(
                item.objective_evaluation_count for item in gradient_history
            )
            if measurement is None:
                computed = gradient_evaluator(
                    values,
                    backend=execution_backend,
                    gradient_index=_offset + gradient_index,
                    objective_evaluation_offset=objective_offset,
                    max_backend_executions=max_backend_executions,
                    algorithm_run_id=run_id,
                    seed=_seed,
                    config=config.gradient,
                    noise=noise,
                    options=options,
                )
            else:
                computed = gradient_evaluator(
                    values,
                    backend=execution_backend,
                    gradient_index=_offset + gradient_index,
                    objective_evaluation_offset=objective_offset,
                    max_backend_executions=max_backend_executions,
                    algorithm_run_id=run_id,
                    seed=_seed,
                    config=config.gradient,
                    measurement=measurement,
                    noise=noise,
                    options=options,
                )
            if computed.plan_hash != gradient_plan.plan_hash:
                raise RuntimeError(
                    "gradient callback plan changed during optimization."
                )
            maximum_gradient_backend_count = (
                gradient_backend_execution_count
                // config.gradient.repeats
                * config.gradient.effective_max_repeats
            )
            if not (
                gradient_backend_execution_count
                <= computed.backend_execution_count
                <= maximum_gradient_backend_count
            ):
                raise RuntimeError(
                    "gradient Backend cost is outside the planned repeat range."
                )
            gradient_history.append(computed)
            if config.method == "ADAM":
                return computed
            return tuple(computed.gradient[name] for name in parameter_names)

        outcome = run_scalar_optimization(
            parameter_names=parameter_names,
            objective=objective,
            optimizer=config,
            initial_parameters=plan.parameters,
            gradient=gradient if config.gradient is not None else None,
            gradient_backend_execution_count=gradient_backend_execution_count,
            objective_backend_execution_count=(
                1
                if measurement_plan is None
                else measurement_plan.backend_execution_count
            ),
            seed=plan.seed,
            objective_resampling_supported=measurement is not None,
            objective_evaluation_index_offset=evaluation_start_index,
            gradient_index_offset=gradient_start_index,
            sampled_gradient=measurement is not None,
        )
        if outcome.termination.nfev != len(history) - evaluation_start_index:
            raise RuntimeError(
                "optimizer nfev does not match its Backend evaluation history."
            )
        global_best_index = evaluation_start_index + outcome.best_evaluation_index
        if outcome.termination.njev != len(gradient_history) - gradient_start_index:
            raise RuntimeError(
                "optimizer njev does not match its Backend gradient history."
            )
        start_results.append(
            OptimizationStartIR(
                start_index=plan.start_index,
                seed=plan.seed,
                initialization=plan.initialization,
                evaluation_start_index=evaluation_start_index,
                evaluation_count=outcome.termination.nfev,
                best_evaluation_index=global_best_index,
                initial_parameters=dict(
                    zip(parameter_names, outcome.initial_parameters)
                ),
                final_parameters=dict(zip(parameter_names, outcome.final_parameters)),
                final_objective=outcome.final_objective,
                best_objective=(
                    min(
                        outcome.objective_estimates,
                        key=lambda item: (
                            item.pooled_objective,
                            item.source_evaluation_offset,
                        ),
                    ).pooled_objective
                    if outcome.objective_estimates
                    else history[global_best_index].energy
                ),
                termination=outcome.termination,
                gradient_start_index=gradient_start_index,
                gradient_count=outcome.termination.njev,
                backend_execution_count=outcome.termination.backend_execution_count,
                adam_iterations=outcome.adam_iterations,
                adam_stopping_evidence=outcome.adam_stopping_evidence,
                spsa_iterations=outcome.spsa_iterations,
                spsa_initial_estimate=(
                    outcome.objective_estimates[0]
                    if outcome.objective_estimates
                    else None
                ),
                spsa_final_estimate=(
                    outcome.objective_estimates[-1]
                    if outcome.objective_estimates
                    else None
                ),
                spsa_learning_rate_calibration=(
                    outcome.spsa_learning_rate_calibration
                ),
                spsa_stopping_evidence=outcome.spsa_stopping_evidence,
            )
        )

    selected_start = min(
        start_results,
        key=lambda item: (item.best_objective, item.best_evaluation_index),
    )
    best_evaluation_index = selected_start.best_evaluation_index
    selected_start_index = selected_start.start_index
    starts = tuple(start_results)
    termination = aggregate_optimizer_termination(
        starts,
        selected_start_index=selected_start_index,
    )
    selected_start = starts[selected_start_index]
    selection_result: SampledSelectionIR | None = None
    selected_evaluation_index = best_evaluation_index
    if sampled_selection is not None:
        assert measurement is not None
        selection_result = execute_sampled_candidate_selection(
            algorithm_id=algorithm_id,
            algorithm_run_id=run_id,
            circuit=optimization_circuit,
            parameter_names=parameter_names,
            hamiltonian=hamiltonian,
            history=cast(tuple[SampledObjectiveEvaluationIR, ...], tuple(history)),
            config=sampled_selection,
            optimization_measurement=measurement,
            backend=execution_backend,
            root_seed=resolved_seed,
            ranked_source_indices=(
                rank_spsa_source_evaluation_indices(starts)
                if config.method == "SPSA"
                else tuple(
                    item.evaluation_index
                    for item in sorted(
                        cast(
                            tuple[SampledObjectiveEvaluationIR, ...],
                            tuple(history),
                        ),
                        key=lambda item: (item.energy, item.evaluation_index),
                    )
                )
            ),
            noise=noise,
            options=options,
        )
        selected_evaluation_index = selection_result.selected_source_evaluation_index
    sampling_start = next(
        item
        for item in starts
        if item.evaluation_start_index
        <= selected_evaluation_index
        < item.evaluation_start_index + item.evaluation_count
    )
    sampling = execute_final_sampling(
        circuit=optimization_circuit,
        best_evaluation=history[selected_evaluation_index],
        backend=execution_backend,
        algorithm_run_id=run_id,
        shots=final_shots,
        seed=sampling_start.seed,
        problem=problem,
        mis_penalty=mis_penalty,
        mwis_penalty=mwis_penalty,
        noise=noise,
        options=options,
    )
    return VariationalResult(
        algorithm_run_id=run_id,
        algorithm_kind=variational_kind,
        hamiltonian=hamiltonian,
        ansatz=ansatz,
        optimizer=config,
        evaluations=tuple(history),
        best_evaluation_index=best_evaluation_index,
        termination=termination,
        gradients=tuple(gradient_history),
        optimization_starts=starts,
        selected_start_index=selected_start_index,
        sampled_selection=selection_result,
        final_result=sampling.result,
        most_probable_candidate=sampling.most_probable_candidate,
        best_observed_candidate=sampling.best_observed_candidate,
        baseline=sampling.baseline,
        cardinality_subspace=build_cardinality_subspace_evidence(
            ansatz,
            sampling.result,
        ),
        problem_id=hamiltonian.source_problem_id,
        problem_hash=hamiltonian.source_problem_hash,
        metadata={
            "algorithm_id": algorithm_id,
            "resolved_seed": resolved_seed,
            "initial_parameters": tuple(selected_start.initial_parameters.values()),
            "optimizer_final_parameters": tuple(
                selected_start.final_parameters.values()
            ),
            "optimizer_final_energy": selected_start.final_objective,
            "start_count": len(starts),
            "selected_start_index": selected_start_index,
            "backend_result_ids": tuple(
                result_id
                for item in history
                for result_id in (
                    (item.result_id,)
                    if isinstance(item, ObjectiveEvaluationIR)
                    else item.result_ids
                )
            ),
            "objective_estimator": (
                history[0].execution_evidence.estimator_kind.value
                if isinstance(history[0], ObjectiveEvaluationIR)
                else history[0].estimator_kind
            ),
            "objective_simulation_method": (
                history[0].execution_evidence.simulation_plan.method_selected
                if isinstance(history[0], ObjectiveEvaluationIR)
                else "finite_shot_pauli_measurement"
            ),
            "objective_noise_model_hash": (
                None if noise is None else noise.stable_hash()
            ),
            "objective_total_shots": sum(
                item.total_shots
                if isinstance(item, SampledObjectiveEvaluationIR)
                else 0
                for item in history
            ),
            "gradient_total_shots": sum(
                item.total_shots for item in gradient_history
            ),
            "objective_energy_standard_errors": tuple(
                item.energy_standard_error
                if isinstance(item, SampledObjectiveEvaluationIR)
                else None
                for item in history
            ),
            "objective_repeats": (
                config.spsa.objective_repeats if config.spsa is not None else 1
            ),
            **(
                {
                    "objective_repeat_mode": "adaptive",
                    "max_objective_repeats": config.spsa.max_objective_repeats,
                    "objective_standard_error_target": (
                        config.spsa.objective_standard_error_target
                    ),
                    "objective_repeat_counts": tuple(
                        estimate.repeat_count
                        for start in starts
                        for estimate in _start_spsa_estimates(start)
                    ),
                }
                if config.spsa is not None
                and config.spsa.objective_repeat_mode == "adaptive"
                else {}
            ),
            "objective_pooled_estimates": tuple(
                estimate.to_dict()
                for start in starts
                for estimate in _start_spsa_estimates(start)
            ),
            "objective_selection_rule": (
                selection_result.selection_rule
                if selection_result is not None
                else (
                    (
                        "minimum_pooled_sample_mean"
                        if measurement is not None
                        and config.spsa is not None
                        and config.spsa.objective_repeats > 1
                        else "minimum_observed_sample_mean"
                    )
                    if measurement is not None
                    else "minimum_observed_energy"
                )
            ),
            "selected_evaluation_index": selected_evaluation_index,
            "confirmation_backend_execution_count": (
                0
                if selection_result is None
                else selection_result.backend_execution_count
            ),
            "confirmation_total_shots": (
                0 if selection_result is None else selection_result.total_shots
            ),
            "workflow_backend_execution_count": (
                (termination.backend_execution_count or 0)
                + (
                    0
                    if selection_result is None
                    else selection_result.backend_execution_count
                )
                + 1
            ),
            "workflow_total_shots": (
                sum(
                    item.total_shots
                    if isinstance(item, SampledObjectiveEvaluationIR)
                    else 0
                    for item in history
                )
                + sum(item.total_shots for item in gradient_history)
                + (0 if selection_result is None else selection_result.total_shots)
                + final_shots
            ),
            **sampling.metadata,
        },
    )


def _validate_bounds(
    config: OptimizerConfig,
    parameter_names: tuple[str, ...],
) -> None:
    if config.bounds and len(config.bounds) != len(parameter_names):
        raise ValueError("optimizer bounds must match ansatz parameter count.")


def _validate_cobyla_budget(
    config: OptimizerConfig,
    *,
    parameter_count: int,
) -> None:
    """Reject a budget too small to initialize COBYLA consistently."""
    if config.method != "COBYLA":
        return
    limit, _ = _cobyla_limit(config)
    minimum = parameter_count + 2
    if limit < minimum:
        raise ValueError(
            "COBYLA objective evaluation budget must be at least "
            f"parameter_count + 2 ({minimum}); received {limit}."
        )


def _resolve_seed(config: OptimizerConfig, backend: LocalBackend | None) -> int:
    if config.seed is not None:
        return config.seed
    if backend is not None and backend.seed is not None:
        return backend.seed
    return 0


def _validate_initial_point(
    point: tuple[float, ...],
    *,
    parameter_names: tuple[str, ...],
    bounds: tuple[tuple[float, float], ...],
) -> None:
    if len(point) != len(parameter_names):
        raise ValueError("initial parameters must match parameter_names.")
    if any(not math.isfinite(value) for value in point):
        raise ValueError("initial parameters must be finite.")
    for index, (value, bound) in enumerate(zip(point, bounds)):
        lower, upper = bound
        if not lower <= value <= upper:
            raise ValueError(
                f"initial parameter '{parameter_names[index]}' is outside optimizer "
                "bounds."
            )


def _optimization_start_seed(seed: int, start_index: int) -> int:
    """Keep start zero backward-compatible and derive every later seed."""
    if start_index == 0:
        return seed
    sequence = np.random.SeedSequence((seed, 2_000_003, start_index))
    return int(sequence.generate_state(1, dtype=np.uint32)[0])


def _qaoa_layerwise_initial_point(
    *,
    layers: int,
    parameter_names: tuple[str, ...],
    previous_parameters: Mapping[str, float],
) -> tuple[float, ...]:
    """Interpolate exactly one shallower canonical QAOA parameter set."""
    if layers <= 1:
        raise ValueError("layerwise initialization requires target layers > 1.")
    previous = _finite_previous_parameters(previous_parameters)
    previous_layers = layers - 1

    expected_target = tuple(f"gamma_{index}" for index in range(layers)) + tuple(
        f"beta_{index}" for index in range(layers)
    )
    expected_previous = tuple(
        f"gamma_{index}" for index in range(previous_layers)
    ) + tuple(f"beta_{index}" for index in range(previous_layers))
    if parameter_names != expected_target:
        raise ValueError(
            "layerwise QAOA requires canonical gamma/beta parameter names."
        )
    if set(previous) != set(expected_previous):
        raise ValueError("layerwise QAOA requires exactly the p-1 layer parameters.")
    old_positions = np.linspace(0.0, 1.0, previous_layers)
    new_positions = np.linspace(0.0, 1.0, layers)
    gammas = np.interp(
        new_positions,
        old_positions,
        [previous[f"gamma_{index}"] for index in range(previous_layers)],
    )
    betas = np.interp(
        new_positions,
        old_positions,
        [previous[f"beta_{index}"] for index in range(previous_layers)],
    )
    values = {
        **{f"gamma_{index}": float(value) for index, value in enumerate(gammas)},
        **{f"beta_{index}": float(value) for index, value in enumerate(betas)},
    }
    return tuple(values[name] for name in parameter_names)


def _finite_previous_parameters(
    values: Mapping[str, float],
) -> dict[str, float]:
    normalized: dict[str, float] = {}
    for name, value in values.items():
        if not isinstance(name, str) or not name.strip():
            raise ValueError("previous parameter names must be non-empty strings.")
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            raise TypeError(f"previous parameter '{name}' must be a real number.")
        normalized_value = float(value)
        if not math.isfinite(normalized_value):
            raise ValueError(f"previous parameter '{name}' must be finite.")
        normalized[name] = normalized_value
    return normalized


def seeded_initial_point(
    *,
    algorithm_kind: AlgorithmKind,
    layers: int,
    parameter_count: int,
    seed: int,
    bounds: tuple[tuple[float, float], ...],
) -> tuple[float, ...]:
    # Include the frozen algorithm shape in the seed stream so changing the
    # algorithm or p-layer count cannot silently reuse an unrelated initial point.
    kind_offset = 0 if algorithm_kind == "qaoa" else 1_000_003
    sequence = np.random.SeedSequence((seed, kind_offset, layers, parameter_count))
    rng = np.random.default_rng(sequence)
    if bounds:
        # Explicit user bounds are also the initialization domain; this keeps an
        # omitted initial point useful even for narrow, problem-specific ranges.
        values = np.asarray(
            [rng.uniform(lower, upper) for lower, upper in bounds],
            dtype=np.float64,
        )
    elif algorithm_kind == "qaoa":
        gamma_count = layers
        gammas = rng.uniform(-math.pi, math.pi, size=gamma_count)
        betas = rng.uniform(-math.pi / 2.0, math.pi / 2.0, size=gamma_count)
        values = np.concatenate((gammas, betas))
    elif algorithm_kind == "vqe":
        values = rng.uniform(-math.pi, math.pi, size=parameter_count)
    else:
        raise ValueError("QAA seeded initialization requires explicit bounds.")
    return tuple(float(value) for value in values)


def _scipy_options(
    config: OptimizerConfig,
) -> tuple[dict[str, bool | int | float], Literal["max_iterations", "max_evaluations"]]:
    options = dict(config.options)
    cobyla_limit_reason: Literal["max_iterations", "max_evaluations"] = "max_iterations"
    if config.method == "COBYLA":
        # SciPy COBYLA names its function-evaluation budget `maxiter` across
        # both the legacy Fortran and current PRIMA implementations.
        limit, cobyla_limit_reason = _cobyla_limit(config)
        options["maxiter"] = limit
    elif config.method == "L-BFGS-B":
        options["maxiter"] = config.max_iterations
        if config.max_evaluations is not None:
            options["maxfun"] = config.max_evaluations
    else:
        options["maxiter"] = config.max_iterations
        if config.max_evaluations is not None:
            options["maxfev"] = config.max_evaluations
    return options, cobyla_limit_reason


def _cobyla_limit(
    config: OptimizerConfig,
) -> tuple[int, Literal["max_iterations", "max_evaluations"]]:
    """Return COBYLA's effective evaluation limit and public reason."""
    if (
        config.max_evaluations is not None
        and config.max_evaluations <= config.max_iterations
    ):
        return config.max_evaluations, "max_evaluations"
    return config.max_iterations, "max_iterations"


def _termination(
    result: OptimizeResult,
    *,
    config: OptimizerConfig,
    nfev: int,
    njev: int = 0,
    backend_execution_count: int | None = None,
    cobyla_limit_reason: Literal["max_iterations", "max_evaluations"],
) -> OptimizerTerminationIR:
    success = bool(result.success)
    nit_value = result.get("nit")
    nit = None if nit_value is None else int(nit_value)
    if success:
        reason: Literal[
            "completed",
            "max_iterations",
            "max_evaluations",
            "max_gradient_evaluations",
            "max_backend_executions",
            "failed",
        ] = "completed"
    elif config.method == "COBYLA":
        evaluation_limit, _ = _cobyla_limit(config)
        reason = cobyla_limit_reason if nfev >= evaluation_limit else "failed"
    elif config.max_evaluations is not None and nfev >= config.max_evaluations:
        reason = "max_evaluations"
    elif nit is not None and nit >= config.max_iterations:
        reason = "max_iterations"
    else:
        reason = "failed"
    return OptimizerTerminationIR(
        method=config.method,
        success=success,
        status=int(result.status),
        message=str(result.message),
        nfev=nfev,
        njev=njev,
        backend_execution_count=backend_execution_count,
        nit=nit,
        reason=reason,
    )
