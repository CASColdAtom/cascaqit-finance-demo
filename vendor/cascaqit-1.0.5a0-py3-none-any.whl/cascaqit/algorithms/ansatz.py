"""Canonical VQE ansatz definitions and deterministic circuit construction."""

from __future__ import annotations

import math
import re
from collections.abc import Mapping
from dataclasses import dataclass, field
from numbers import Real
from types import MappingProxyType
from typing import Any, Literal, Union, cast

from cascaqit.algorithms.models import AnsatzSpecIR
from cascaqit.digital import Circuit
from cascaqit.native_ir.base import IRMixin, stable_json
from cascaqit.parameters import ParameterSchemaIR

__all__ = [
    "BuiltAnsatz",
    "CardinalityConstraint",
    "CardinalityPreservingAnsatz",
    "HardwareEfficientAnsatz",
    "build_vqe_ansatz",
    "transfer_vqe_parameters",
]

RotationAxis = Literal["rx", "ry", "rz"]
EntanglementTopology = Literal["linear", "circular"]

_DIGEST_PATTERN = re.compile(r"[0-9a-f]{64}")
_ROTATION_AXES = frozenset({"rx", "ry", "rz"})
_ENTANGLEMENT_TOPOLOGIES = frozenset({"linear", "circular"})


@dataclass(frozen=True)
class CardinalityConstraint(IRMixin):
    """One qubit group whose computational-basis weight stays fixed."""

    qubits: tuple[str, ...]
    weight: int
    schema_version: str = "cascaqit.algorithms.cardinality_constraint.v1"

    def __post_init__(self) -> None:
        qubits = tuple(self.qubits)
        if not qubits or any(
            not isinstance(qubit, str) or not qubit.strip() or qubit != qubit.strip()
            for qubit in qubits
        ):
            raise ValueError("constraint qubits must contain non-empty trimmed names.")
        if len(qubits) != len(set(qubits)):
            raise ValueError("constraint qubits must not contain duplicates.")
        if (
            not isinstance(self.weight, int)
            or isinstance(self.weight, bool)
            or not 0 <= self.weight <= len(qubits)
        ):
            raise ValueError("constraint weight must be between zero and group size.")
        if not isinstance(self.schema_version, str) or not self.schema_version.strip():
            raise ValueError("schema_version must be a non-empty string.")
        object.__setattr__(self, "qubits", qubits)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CardinalityConstraint:
        """Restore one fixed-weight group from JSON-compatible data."""
        raw_qubits = data.get("qubits", ())
        if not isinstance(raw_qubits, (list, tuple)):
            raise TypeError("constraint qubits must be an array.")
        return cls(
            qubits=tuple(raw_qubits),
            weight=data["weight"],
            schema_version=str(
                data.get(
                    "schema_version",
                    "cascaqit.algorithms.cardinality_constraint.v1",
                )
            ),
        )


@dataclass(frozen=True)
class CardinalityPreservingAnsatz(IRMixin):
    """Serializable VQE ansatz restricted to declared fixed-weight groups."""

    constraints: tuple[CardinalityConstraint, ...]
    free_rotation_axes: tuple[RotationAxis, ...] = ("ry",)
    entanglement: EntanglementTopology = "linear"
    definition_kind: Literal["cardinality_preserving"] = field(
        default="cardinality_preserving",
        init=False,
    )
    schema_version: str = "cascaqit.algorithms.vqe_ansatz.v2"

    def __post_init__(self) -> None:
        constraints = tuple(self.constraints)
        if not constraints:
            raise ValueError(
                "constraints must contain at least one fixed-weight group."
            )
        if any(not isinstance(item, CardinalityConstraint) for item in constraints):
            raise TypeError("constraints must contain CardinalityConstraint values.")
        constrained_qubits = tuple(
            qubit for constraint in constraints for qubit in constraint.qubits
        )
        if len(constrained_qubits) != len(set(constrained_qubits)):
            raise ValueError("fixed-weight groups must not overlap.")

        axes = tuple(self.free_rotation_axes)
        if len(axes) != len(set(axes)):
            raise ValueError("free_rotation_axes must not contain duplicates.")
        unsupported = tuple(axis for axis in axes if axis not in _ROTATION_AXES)
        if unsupported:
            raise ValueError(
                f"Unsupported VQE free rotation axis: {unsupported[0]!r}."
            )
        if self.entanglement not in _ENTANGLEMENT_TOPOLOGIES:
            raise ValueError(
                f"Unsupported VQE entanglement topology: {self.entanglement!r}."
            )
        if not isinstance(self.schema_version, str) or not self.schema_version.strip():
            raise ValueError("schema_version must be a non-empty string.")
        object.__setattr__(self, "constraints", constraints)
        object.__setattr__(self, "free_rotation_axes", axes)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CardinalityPreservingAnsatz:
        """Restore a fixed-cardinality definition from JSON-compatible data."""
        if data.get("definition_kind") != "cardinality_preserving":
            raise ValueError("definition_kind must be cardinality_preserving.")
        raw_constraints = data.get("constraints", ())
        if not isinstance(raw_constraints, (list, tuple)):
            raise TypeError("constraints must be an array.")
        raw_axes = data.get("free_rotation_axes", ("ry",))
        if not isinstance(raw_axes, (list, tuple)):
            raise TypeError("free_rotation_axes must be an array.")
        constraints: list[CardinalityConstraint] = []
        for item in raw_constraints:
            if not isinstance(item, Mapping):
                raise TypeError("constraints must contain objects.")
            constraints.append(CardinalityConstraint.from_dict(dict(item)))
        return cls(
            constraints=tuple(constraints),
            free_rotation_axes=cast(tuple[RotationAxis, ...], tuple(raw_axes)),
            entanglement=cast(
                EntanglementTopology,
                data.get("entanglement", "linear"),
            ),
            schema_version=str(
                data.get("schema_version", "cascaqit.algorithms.vqe_ansatz.v2")
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> CardinalityPreservingAnsatz:
        """Restore a fixed-cardinality definition from JSON text."""
        import json

        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("CardinalityPreservingAnsatz JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class HardwareEfficientAnsatz(IRMixin):
    """Serializable structure of the built-in VQE ansatz."""

    rotation_axes: tuple[RotationAxis, ...] = ("ry", "rz")
    entanglement: EntanglementTopology = "linear"
    definition_kind: Literal["hardware_efficient"] = field(
        default="hardware_efficient",
        init=False,
    )
    schema_version: str = "cascaqit.algorithms.vqe_ansatz.v1"

    def __post_init__(self) -> None:
        axes = tuple(self.rotation_axes)
        if not axes:
            raise ValueError("rotation_axes must not be empty.")
        if len(axes) != len(set(axes)):
            raise ValueError("rotation_axes must not contain duplicates.")
        unsupported = tuple(axis for axis in axes if axis not in _ROTATION_AXES)
        if unsupported:
            raise ValueError(f"Unsupported VQE rotation axis: {unsupported[0]!r}.")
        if self.entanglement not in _ENTANGLEMENT_TOPOLOGIES:
            raise ValueError(
                f"Unsupported VQE entanglement topology: {self.entanglement!r}."
            )
        if not isinstance(self.schema_version, str) or not self.schema_version.strip():
            raise ValueError("schema_version must be a non-empty string.")
        object.__setattr__(self, "rotation_axes", axes)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> HardwareEfficientAnsatz:
        """Restore a hardware-efficient definition from JSON-compatible data."""
        if data.get("definition_kind", "hardware_efficient") != "hardware_efficient":
            raise ValueError("definition_kind must be hardware_efficient.")
        raw_axes = data.get("rotation_axes", ("ry", "rz"))
        if not isinstance(raw_axes, (list, tuple)):
            raise TypeError("rotation_axes must be an array.")
        return cls(
            rotation_axes=cast(tuple[RotationAxis, ...], tuple(raw_axes)),
            entanglement=cast(
                EntanglementTopology,
                data.get("entanglement", "linear"),
            ),
            schema_version=str(
                data.get("schema_version", "cascaqit.algorithms.vqe_ansatz.v1")
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> HardwareEfficientAnsatz:
        """Restore a hardware-efficient definition from JSON text."""
        import json

        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("HardwareEfficientAnsatz JSON must contain an object.")
        return cls.from_dict(data)


VQEAnsatzDefinition = Union[HardwareEfficientAnsatz, CardinalityPreservingAnsatz]


@dataclass(frozen=True, init=False)
class BuiltAnsatz:
    """Validated circuit snapshot and the facts used to construct it."""

    _circuit: Circuit = field(repr=False)
    parameter_schema: ParameterSchemaIR
    spec: AnsatzSpecIR
    definition: VQEAnsatzDefinition | None = None

    def __init__(
        self,
        *,
        circuit: Circuit,
        parameter_schema: ParameterSchemaIR,
        spec: AnsatzSpecIR,
        definition: VQEAnsatzDefinition | None = None,
    ) -> None:
        object.__setattr__(self, "_circuit", circuit)
        object.__setattr__(self, "parameter_schema", parameter_schema)
        object.__setattr__(self, "spec", spec)
        object.__setattr__(self, "definition", definition)
        self.__post_init__()

    @property
    def circuit(self) -> Circuit:
        """Return an independent copy of the validated Circuit snapshot."""
        return self._circuit.snapshot()

    def __post_init__(self) -> None:
        if not isinstance(self._circuit, Circuit):
            raise TypeError("circuit must be Circuit.")
        if not isinstance(self.parameter_schema, ParameterSchemaIR):
            raise TypeError("parameter_schema must be ParameterSchemaIR.")
        if not isinstance(self.spec, AnsatzSpecIR):
            raise TypeError("spec must be AnsatzSpecIR.")
        snapshot = self._circuit.snapshot()
        parameter_names = tuple(
            parameter.name for parameter in self.parameter_schema.parameters
        )
        if parameter_names != tuple(
            parameter.name for parameter in snapshot.parameters
        ):
            raise ValueError("parameter_schema does not match the ansatz Circuit.")
        if self.spec.parameter_names != parameter_names:
            raise ValueError("Ansatz spec does not match the parameter schema.")
        if self.spec.logical_order != snapshot.qubits:
            raise ValueError("Ansatz spec does not match Circuit logical_order.")
        if self.spec.circuit_hash != snapshot.structural_hash():
            raise ValueError("Ansatz spec circuit_hash does not match the Circuit.")
        required_gates = tuple(dict.fromkeys(snapshot.gate_names))
        if self.spec.required_gates != required_gates:
            raise ValueError("Ansatz spec required_gates do not match the Circuit.")
        if self.definition is None:
            if self.spec.ansatz_kind != "custom":
                raise ValueError("A built-in ansatz requires its definition.")
            expected_custom = {
                "definition_kind": "custom",
                "circuit_hash": snapshot.structural_hash(),
                "circuit": snapshot.structural_payload(),
            }
            if stable_json(self.spec.definition) != stable_json(expected_custom):
                raise ValueError("Custom ansatz spec does not match its Circuit.")
        else:
            expected_kind = _definition_ansatz_kind(self.definition)
            if self.spec.ansatz_kind != expected_kind:
                raise ValueError("Built-in definition does not match ansatz_kind.")
            if stable_json(self.spec.definition) != stable_json(self.definition):
                raise ValueError("Ansatz spec does not match its definition.")
        object.__setattr__(self, "_circuit", snapshot)

    def fresh_circuit(self) -> Circuit:
        """Return an independent Circuit for one build or execution."""
        return self._circuit.snapshot()


def build_vqe_ansatz(
    *,
    logical_order: tuple[str, ...],
    layers: int,
    algorithm_id: str,
    hamiltonian_hash: str,
    ansatz: VQEAnsatzDefinition | Circuit | None = None,
) -> BuiltAnsatz:
    """Build and cross-check one built-in or explicit VQE ansatz."""
    order = tuple(logical_order)
    _validate_build_identity(order, layers, algorithm_id, hamiltonian_hash)
    definition: VQEAnsatzDefinition | None
    if ansatz is None or isinstance(ansatz, HardwareEfficientAnsatz):
        definition = ansatz or HardwareEfficientAnsatz()
        circuit = _build_hardware_efficient_circuit(
            logical_order=order,
            layers=layers,
            algorithm_id=algorithm_id,
            hamiltonian_hash=hamiltonian_hash,
            definition=definition,
        )
        ansatz_kind: Literal[
            "hardware_efficient", "cardinality_preserving", "custom"
        ] = "hardware_efficient"
        definition_payload: dict[str, Any] = definition.to_dict()
        layer_transfer: Literal["append_last_layer", "unsupported"] = (
            "append_last_layer"
        )
        initial_state = "computational_zero"
    elif isinstance(ansatz, CardinalityPreservingAnsatz):
        definition = ansatz
        circuit = _build_cardinality_preserving_circuit(
            logical_order=order,
            layers=layers,
            algorithm_id=algorithm_id,
            hamiltonian_hash=hamiltonian_hash,
            definition=definition,
        )
        ansatz_kind = "cardinality_preserving"
        definition_payload = definition.to_dict()
        layer_transfer = "append_last_layer"
        initial_state = "fixed_cardinality_computational_basis"
    elif isinstance(ansatz, Circuit):
        _validate_custom_circuit(ansatz, order)
        definition = None
        # compose() 会复制参数和门；后续修改用户传入的 Circuit 不会改变本次实验。
        circuit = Circuit(
            order,
            program_id=f"program.{algorithm_id}",
            metadata={
                "algorithm": "vqe",
                "algorithm_id": algorithm_id,
                "layers": layers,
                "hamiltonian_hash": hamiltonian_hash,
                "ansatz_kind": "custom",
            },
        ).compose(ansatz)
        ansatz_kind = "custom"
        definition_payload = {
            "definition_kind": "custom",
            "circuit_hash": circuit.structural_hash(),
            "circuit": circuit.structural_payload(),
        }
        layer_transfer = "unsupported"
        initial_state = "custom_circuit"
    else:
        raise TypeError(
            "ansatz must be HardwareEfficientAnsatz, "
            "CardinalityPreservingAnsatz, Circuit, or None."
        )

    parameter_schema = ParameterSchemaIR.from_parameters(circuit.parameters)
    parameter_names = tuple(item.name for item in parameter_schema.parameters)
    required_gates = tuple(dict.fromkeys(circuit.gate_names))
    circuit_hash = circuit.structural_hash()
    descriptive_metadata: dict[str, Any] = {
        "hamiltonian_hash": hamiltonian_hash,
        "initial_state": initial_state,
    }
    if isinstance(definition, HardwareEfficientAnsatz):
        descriptive_metadata.update(
            {
                "rotation_order": "_then_".join(
                    axis.upper() for axis in definition.rotation_axes
                ),
                "entanglement": f"{definition.entanglement}_cx",
            }
        )
    elif isinstance(definition, CardinalityPreservingAnsatz):
        constrained = {
            qubit
            for constraint in definition.constraints
            for qubit in constraint.qubits
        }
        descriptive_metadata.update(
            {
                "constraint_count": len(definition.constraints),
                "constrained_qubit_count": len(constrained),
                "free_qubit_count": len(order) - len(constrained),
                "free_rotation_order": "_then_".join(
                    axis.upper() for axis in definition.free_rotation_axes
                ),
                "entanglement": f"{definition.entanglement}_cz",
                "preserved_invariant": "declared_group_hamming_weight",
            }
        )
    spec = AnsatzSpecIR(
        ansatz_id=f"ansatz.{algorithm_id}",
        ansatz_kind=ansatz_kind,
        layers=layers,
        logical_order=order,
        parameter_names=parameter_names,
        circuit_hash=circuit_hash,
        definition=MappingProxyType(definition_payload),
        required_gates=required_gates,
        layer_transfer=layer_transfer,
        metadata=descriptive_metadata,
    )
    return BuiltAnsatz(
        circuit=circuit,
        parameter_schema=parameter_schema,
        spec=spec,
        definition=definition,
    )


def transfer_vqe_parameters(
    previous: BuiltAnsatz | AnsatzSpecIR,
    current: BuiltAnsatz | AnsatzSpecIR,
    values: Mapping[str, float],
) -> dict[str, float]:
    """把内置 VQE Ansatz 的参数显式迁移到相邻的下一层。

    迁移规则属于 Ansatz，而不是通用优化器。已有层逐名保留；新增层按
    qubit 和旋转轴复制前一层的值，以保持既有 layer-wise 数值行为。
    """
    previous_spec = _transfer_spec(previous, "previous")
    current_spec = _transfer_spec(current, "current")
    previous_definition = _transfer_definition(previous_spec, "previous")
    current_definition = _transfer_definition(current_spec, "current")
    if previous_definition != current_definition:
        raise ValueError("VQE layer transfer requires the same ansatz definition.")
    if previous_spec.logical_order != current_spec.logical_order:
        raise ValueError("VQE layer transfer requires the same logical_order.")
    if current_spec.layers != previous_spec.layers + 1:
        raise ValueError("VQE layer transfer requires adjacent layer counts.")

    previous_names = _definition_parameter_names(
        previous_spec.logical_order,
        previous_spec.layers,
        previous_definition,
    )
    current_names = _definition_parameter_names(
        current_spec.logical_order,
        current_spec.layers,
        current_definition,
    )
    if previous_spec.parameter_names != previous_names:
        raise ValueError("previous VQE parameter schema does not match its definition.")
    if current_spec.parameter_names != current_names:
        raise ValueError("current VQE parameter schema does not match its definition.")
    if not isinstance(values, Mapping):
        raise TypeError("values must be a parameter mapping.")
    if len(values) != len(previous_names) or set(values) != set(previous_names):
        raise ValueError("values must exactly match the previous VQE parameters.")

    transferred: dict[str, float] = {}
    for name in previous_names:
        value = values[name]
        if not isinstance(value, Real) or isinstance(value, bool):
            raise TypeError(f"VQE parameter '{name}' must be a real number.")
        normalized = float(value)
        if not math.isfinite(normalized):
            raise ValueError(f"VQE parameter '{name}' must be finite.")
        transferred[name] = normalized

    new_layer = current_spec.layers - 1
    source_layer = new_layer - 1
    for target_name in _definition_layer_parameter_names(
        current_spec.logical_order,
        new_layer,
        current_definition,
    ):
        source_name = _replace_parameter_layer(
            target_name,
            source_layer=source_layer,
            definition=current_definition,
        )
        transferred[target_name] = transferred[source_name]
    if tuple(transferred) != current_names:
        raise RuntimeError("VQE layer transfer lost the current parameter order.")
    return transferred


def _transfer_spec(
    value: BuiltAnsatz | AnsatzSpecIR,
    name: str,
) -> AnsatzSpecIR:
    if isinstance(value, BuiltAnsatz):
        return value.spec
    if isinstance(value, AnsatzSpecIR):
        return value
    raise TypeError(f"{name} must be BuiltAnsatz or AnsatzSpecIR.")


def _transfer_definition(
    spec: AnsatzSpecIR,
    name: str,
) -> VQEAnsatzDefinition:
    if spec.ansatz_kind not in {"hardware_efficient", "cardinality_preserving"}:
        raise ValueError(f"{name} VQE ansatz does not support layer transfer.")
    if spec.layer_transfer != "append_last_layer":
        raise ValueError(f"{name} VQE ansatz does not declare layer transfer.")
    try:
        definition = dict(spec.definition)
        if spec.ansatz_kind == "hardware_efficient":
            return HardwareEfficientAnsatz.from_dict(definition)
        return CardinalityPreservingAnsatz.from_dict(definition)
    except (TypeError, ValueError) as error:
        raise ValueError(f"{name} VQE ansatz definition is invalid.") from error


def _hardware_parameter_names(
    logical_order: tuple[str, ...],
    layers: int,
    definition: HardwareEfficientAnsatz,
) -> tuple[str, ...]:
    return tuple(
        f"{axis}_{layer}_{qubit_index}"
        for layer in range(layers)
        for qubit_index in range(len(logical_order))
        for axis in definition.rotation_axes
    )


def _definition_parameter_names(
    logical_order: tuple[str, ...],
    layers: int,
    definition: VQEAnsatzDefinition,
) -> tuple[str, ...]:
    """Return the full parameter schema owned by one built-in definition."""
    if isinstance(definition, HardwareEfficientAnsatz):
        return _hardware_parameter_names(logical_order, layers, definition)
    return tuple(
        name
        for layer in range(layers)
        for name in _cardinality_layer_parameter_names(
            logical_order,
            layer,
            definition,
        )
    )


def _definition_layer_parameter_names(
    logical_order: tuple[str, ...],
    layer: int,
    definition: VQEAnsatzDefinition,
) -> tuple[str, ...]:
    if isinstance(definition, HardwareEfficientAnsatz):
        return tuple(
            f"{axis}_{layer}_{qubit_index}"
            for qubit_index in range(len(logical_order))
            for axis in definition.rotation_axes
        )
    return _cardinality_layer_parameter_names(logical_order, layer, definition)


def _replace_parameter_layer(
    name: str,
    *,
    source_layer: int,
    definition: VQEAnsatzDefinition,
) -> str:
    if isinstance(definition, HardwareEfficientAnsatz):
        axis, _, qubit_index = name.split("_", 2)
        return f"{axis}_{source_layer}_{qubit_index}"
    parts = name.split("_")
    if parts[0] == "givens":
        return f"givens_{source_layer}_{parts[2]}_{parts[3]}"
    return f"{parts[0]}_{source_layer}_{parts[2]}"


def _build_hardware_efficient_circuit(
    *,
    logical_order: tuple[str, ...],
    layers: int,
    algorithm_id: str,
    hamiltonian_hash: str,
    definition: HardwareEfficientAnsatz,
) -> Circuit:
    parameter_names = _hardware_parameter_names(logical_order, layers, definition)
    circuit = Circuit(
        logical_order,
        program_id=f"program.{algorithm_id}",
        metadata={
            "algorithm": "vqe",
            "algorithm_id": algorithm_id,
            "layers": layers,
            "hamiltonian_hash": hamiltonian_hash,
            "parameter_order": list(parameter_names),
            "ansatz_kind": "hardware_efficient",
            "rotation_order": "_then_".join(
                axis.upper() for axis in definition.rotation_axes
            ),
            "entanglement": f"{definition.entanglement}_cx",
            "definition_hash": definition.stable_hash(),
        },
    )
    parameters = {name: circuit.parameter(name) for name in parameter_names}
    for layer in range(layers):
        for qubit_index, qubit in enumerate(logical_order):
            for axis in definition.rotation_axes:
                rotation = getattr(circuit, axis)
                rotation(parameters[f"{axis}_{layer}_{qubit_index}"], qubit)
        for left, right in zip(logical_order, logical_order[1:]):
            circuit.cx(left, right)
        # 两个 qubit 的首尾边与线性边相同，不能重复施加 CX。
        if definition.entanglement == "circular" and len(logical_order) > 2:
            circuit.cx(logical_order[-1], logical_order[0])
    return circuit


def _build_cardinality_preserving_circuit(
    *,
    logical_order: tuple[str, ...],
    layers: int,
    algorithm_id: str,
    hamiltonian_hash: str,
    definition: CardinalityPreservingAnsatz,
) -> Circuit:
    _validate_cardinality_definition_against_order(definition, logical_order)
    parameter_names = _definition_parameter_names(logical_order, layers, definition)
    if not parameter_names:
        raise ValueError(
            "CardinalityPreservingAnsatz must contain a non-trivial group or "
            "at least one free-qubit rotation."
        )
    circuit = Circuit(
        logical_order,
        program_id=f"program.{algorithm_id}",
        metadata={
            "algorithm": "vqe",
            "algorithm_id": algorithm_id,
            "layers": layers,
            "hamiltonian_hash": hamiltonian_hash,
            "parameter_order": list(parameter_names),
            "ansatz_kind": "cardinality_preserving",
            "initial_state": "fixed_cardinality_computational_basis",
            "entanglement": f"{definition.entanglement}_cz",
            "preserved_invariant": "declared_group_hamming_weight",
            "definition_hash": definition.stable_hash(),
        },
    )
    parameters = {name: circuit.parameter(name) for name in parameter_names}

    # 每组从一个确定的可行计算基态出发。后续门只在 |01> 与 |10> 间搬运
    # 振幅或添加对角相位，因此每个分组的粒子数在理想执行中严格不变。
    for constraint in definition.constraints:
        for qubit in constraint.qubits[: constraint.weight]:
            circuit.x(qubit)

    constrained = {
        qubit for constraint in definition.constraints for qubit in constraint.qubits
    }
    free_qubits = tuple(
        (index, qubit)
        for index, qubit in enumerate(logical_order)
        if qubit not in constrained
    )
    for layer in range(layers):
        for constraint_index, constraint in enumerate(definition.constraints):
            if constraint.weight in {0, len(constraint.qubits)}:
                continue
            for edge_index, (left, right) in enumerate(
                _topology_edges(constraint.qubits, definition.entanglement)
            ):
                theta = parameters[
                    f"givens_{layer}_{constraint_index}_{edge_index}"
                ]
                _append_givens_rotation(circuit, left, right, theta)

        for logical_index, qubit in free_qubits:
            for axis in definition.free_rotation_axes:
                rotation = getattr(circuit, axis)
                rotation(parameters[f"{axis}_{layer}_{logical_index}"], qubit)

        # CZ 对计算基是对角门，既能在各块之间建立相位关联，又不会改变
        # 任一受约束分组的 Hamming weight。
        for left, right in _topology_edges(logical_order, definition.entanglement):
            circuit.cz(left, right)
    return circuit


def _append_givens_rotation(
    circuit: Circuit,
    left: str,
    right: str,
    theta: Any,
) -> None:
    """Append a number-preserving two-qubit Givens rotation."""
    circuit.cx(left, right)
    # CRY(theta, control=right, target=left) is decomposed into the gate set
    # already supported by Circuit. The two outer CX gates turn it into a
    # rotation of only the {|01>, |10>} subspace and leave |00>, |11> fixed.
    circuit.ry(theta / 2.0, left)
    circuit.cx(right, left)
    circuit.ry(-theta / 2.0, left)
    circuit.cx(right, left)
    circuit.cx(left, right)


def _cardinality_layer_parameter_names(
    logical_order: tuple[str, ...],
    layer: int,
    definition: CardinalityPreservingAnsatz,
) -> tuple[str, ...]:
    names: list[str] = []
    for constraint_index, constraint in enumerate(definition.constraints):
        if constraint.weight in {0, len(constraint.qubits)}:
            continue
        names.extend(
            f"givens_{layer}_{constraint_index}_{edge_index}"
            for edge_index, _ in enumerate(
                _topology_edges(constraint.qubits, definition.entanglement)
            )
        )
    constrained = {
        qubit for constraint in definition.constraints for qubit in constraint.qubits
    }
    names.extend(
        f"{axis}_{layer}_{logical_index}"
        for logical_index, qubit in enumerate(logical_order)
        if qubit not in constrained
        for axis in definition.free_rotation_axes
    )
    return tuple(names)


def _topology_edges(
    qubits: tuple[str, ...],
    topology: EntanglementTopology,
) -> tuple[tuple[str, str], ...]:
    edges = list(zip(qubits, qubits[1:]))
    # 两个 qubit 的首尾边与线性边相同，不能重复施加。
    if topology == "circular" and len(qubits) > 2:
        edges.append((qubits[-1], qubits[0]))
    return tuple(edges)


def _validate_cardinality_definition_against_order(
    definition: CardinalityPreservingAnsatz,
    logical_order: tuple[str, ...],
) -> None:
    logical_qubits = set(logical_order)
    unknown = tuple(
        qubit
        for constraint in definition.constraints
        for qubit in constraint.qubits
        if qubit not in logical_qubits
    )
    if unknown:
        raise ValueError(
            "Cardinality constraint references qubits outside logical_order: "
            + ", ".join(unknown)
            + "."
        )


def _definition_ansatz_kind(
    definition: VQEAnsatzDefinition,
) -> Literal["hardware_efficient", "cardinality_preserving"]:
    if isinstance(definition, HardwareEfficientAnsatz):
        return "hardware_efficient"
    if isinstance(definition, CardinalityPreservingAnsatz):
        return "cardinality_preserving"
    raise TypeError("definition must be a built-in VQE ansatz definition.")


def _validate_build_identity(
    logical_order: tuple[str, ...],
    layers: int,
    algorithm_id: str,
    hamiltonian_hash: str,
) -> None:
    if not logical_order or any(
        not isinstance(item, str) or not item for item in logical_order
    ):
        raise ValueError("logical_order must contain non-empty qubit names.")
    if len(logical_order) != len(set(logical_order)):
        raise ValueError("logical_order must not contain duplicates.")
    if not isinstance(layers, int) or isinstance(layers, bool) or layers <= 0:
        raise ValueError("layers must be a positive integer.")
    if not isinstance(algorithm_id, str) or not algorithm_id.strip():
        raise ValueError("algorithm_id must be a non-empty string.")
    if algorithm_id != algorithm_id.strip():
        raise ValueError("algorithm_id must not contain surrounding whitespace.")
    if not isinstance(hamiltonian_hash, str) or not _DIGEST_PATTERN.fullmatch(
        hamiltonian_hash
    ):
        raise ValueError("hamiltonian_hash must be a SHA-256 digest.")


def _validate_custom_circuit(circuit: Circuit, logical_order: tuple[str, ...]) -> None:
    if circuit.qubits != logical_order:
        raise ValueError("custom ansatz qubits must match Hamiltonian logical_order.")
    if circuit.measurements:
        raise ValueError("custom VQE ansatz cannot contain terminal measurements.")
    if not circuit.parameters or circuit.is_bound:
        raise ValueError("custom VQE ansatz requires referenced parameters.")
    declared = tuple(parameter.name for parameter in circuit.parameters)
    if circuit.referenced_parameter_names != declared:
        raise ValueError("custom VQE ansatz parameters must all be referenced.")
