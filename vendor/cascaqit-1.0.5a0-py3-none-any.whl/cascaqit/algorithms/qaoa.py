"""Executable QAOA ansatz and single-objective evaluation."""

from __future__ import annotations

from dataclasses import dataclass, field

from cascaqit.algorithms.execution import (
    ParameterValues,
    execute_objective_evaluation,
)
from cascaqit.algorithms.gradient import (
    GradientConfig,
    ObjectiveGradientIR,
    execute_parameter_shift_gradient,
)
from cascaqit.algorithms.models import (
    AnsatzSpecIR,
    ObjectiveEvaluationIR,
    OptimizerConfig,
    PauliHamiltonian,
    VariationalResult,
)
from cascaqit.algorithms.optimizer import run_variational_optimization
from cascaqit.algorithms.problem_projection import problem_to_pauli_hamiltonian
from cascaqit.digital import Circuit
from cascaqit.observables import PauliBasis
from cascaqit.parameters import ParameterSchemaIR
from cascaqit.problems import OptimizationProblem
from cascaqit.simulators import LocalBackend, NoiseModel, SimulationOptions

__all__ = ["QAOA"]


@dataclass(frozen=True)
class QAOA:
    """Build and evaluate a standard p-layer QAOA problem ansatz."""

    problem: OptimizationProblem
    layers: int = 1
    mis_penalty: float = 2.0
    mwis_penalty: float | None = None
    algorithm_id: str | None = None
    _hamiltonian: PauliHamiltonian = field(init=False, repr=False)

    def __post_init__(self) -> None:
        if (
            not isinstance(self.layers, int)
            or isinstance(self.layers, bool)
            or self.layers <= 0
        ):
            raise ValueError("layers must be a positive integer.")
        hamiltonian = problem_to_pauli_hamiltonian(
            self.problem,
            mis_penalty=self.mis_penalty,
            mwis_penalty=self.mwis_penalty,
        )
        _validate_qaoa_hamiltonian(hamiltonian)
        algorithm_id = self.algorithm_id or f"qaoa.{hamiltonian.source_problem_id}"
        if (
            not isinstance(algorithm_id, str)
            or not algorithm_id.strip()
            or algorithm_id != algorithm_id.strip()
        ):
            raise ValueError("algorithm_id must be a non-empty trimmed string.")
        object.__setattr__(self, "algorithm_id", algorithm_id)
        object.__setattr__(self, "_hamiltonian", hamiltonian)

    @property
    def hamiltonian(self) -> PauliHamiltonian:
        """Return the deterministic problem Hamiltonian."""
        return self._hamiltonian

    @property
    def parameter_names(self) -> tuple[str, ...]:
        """Return gamma parameters followed by beta parameters."""
        return tuple(f"gamma_{index}" for index in range(self.layers)) + tuple(
            f"beta_{index}" for index in range(self.layers)
        )

    def build_circuit(self) -> Circuit:
        """Build a fresh canonical parameterized QAOA circuit."""
        circuit = Circuit(
            self.hamiltonian.logical_order,
            program_id=f"program.{self.algorithm_id}",
            metadata={
                "algorithm": "qaoa",
                "algorithm_id": self.algorithm_id,
                "layers": self.layers,
                "hamiltonian_hash": self.hamiltonian.stable_hash(),
                "parameter_order": list(self.parameter_names),
                "cost_decomposition": "Z:RZ;ZZ:CX-RZ-CX",
                "mixer": "RX",
            },
        )
        gammas = tuple(
            circuit.parameter(f"gamma_{index}") for index in range(self.layers)
        )
        betas = tuple(
            circuit.parameter(f"beta_{index}") for index in range(self.layers)
        )
        for qubit in self.hamiltonian.logical_order:
            circuit.h(qubit)
        for layer in range(self.layers):
            gamma = gammas[layer]
            for term in self.hamiltonian.terms:
                targets = term.observable.targets
                angle = (2.0 * term.coefficient) * gamma
                if len(targets) == 1:
                    circuit.rz(angle, targets[0])
                    continue
                left, right = targets
                circuit.cx(left, right)
                circuit.rz(angle, right)
                circuit.cx(left, right)
            beta = betas[layer]
            for qubit in self.hamiltonian.logical_order:
                circuit.rx(2.0 * beta, qubit)
        return circuit

    def ansatz_spec(self) -> AnsatzSpecIR:
        """Return the stable QAOA ansatz declaration used by later workflows."""
        return AnsatzSpecIR(
            ansatz_id=f"ansatz.{self.algorithm_id}",
            ansatz_kind="qaoa",
            layers=self.layers,
            logical_order=self.hamiltonian.logical_order,
            parameter_names=self.parameter_names,
            metadata={
                "hamiltonian_hash": self.hamiltonian.stable_hash(),
                "initial_state": "uniform_superposition",
                "cost_decomposition": "Z:RZ;ZZ:CX-RZ-CX",
                "mixer": "RX",
            },
        )

    def parameter_schema(self) -> ParameterSchemaIR:
        """Return the canonical schema declared by the QAOA Circuit."""
        return ParameterSchemaIR.from_parameters(self.build_circuit().parameters)

    def evaluate(
        self,
        parameters: ParameterValues,
        *,
        backend: LocalBackend | None = None,
        evaluation_index: int = 0,
        algorithm_run_id: str | None = None,
        seed: int | None = None,
        noise: NoiseModel | None = None,
        options: SimulationOptions | None = None,
    ) -> ObjectiveEvaluationIR:
        """通过一个 LocalBackend Job 执行 ideal 或 density-noisy QAOA objective。"""
        return execute_objective_evaluation(
            algorithm_kind="qaoa",
            algorithm_id=str(self.algorithm_id),
            algorithm_run_id=algorithm_run_id,
            evaluation_index=evaluation_index,
            circuit=self.build_circuit(),
            parameter_names=self.parameter_names,
            parameters=parameters,
            hamiltonian=self.hamiltonian,
            backend=backend,
            seed=seed,
            noise=noise,
            options=options,
        )

    def gradient(
        self,
        parameters: ParameterValues,
        *,
        backend: LocalBackend | None = None,
        gradient_index: int = 0,
        objective_evaluation_offset: int = 0,
        max_backend_executions: int | None = None,
        algorithm_run_id: str | None = None,
        seed: int | None = None,
        config: GradientConfig | None = None,
        noise: NoiseModel | None = None,
        options: SimulationOptions | None = None,
    ) -> ObjectiveGradientIR:
        """Execute the exact parameter-shift gradient of one QAOA objective."""
        return execute_parameter_shift_gradient(
            algorithm_kind="qaoa",
            algorithm_id=str(self.algorithm_id),
            algorithm_run_id=algorithm_run_id,
            gradient_index=gradient_index,
            objective_evaluation_offset=objective_evaluation_offset,
            max_backend_executions=max_backend_executions,
            circuit=self.build_circuit(),
            parameter_names=self.parameter_names,
            parameters=parameters,
            hamiltonian=self.hamiltonian,
            backend=backend,
            seed=seed,
            config=config,
            noise=noise,
            options=options,
        )

    def run(
        self,
        *,
        backend: LocalBackend | None = None,
        optimizer: OptimizerConfig | None = None,
        initial_parameters: ParameterValues | None = None,
        algorithm_run_id: str | None = None,
        final_shots: int = 2048,
        noise: NoiseModel | None = None,
        options: SimulationOptions | None = None,
    ) -> VariationalResult:
        """Optimize QAOA and final-sample the minimum observed parameters."""
        return run_variational_optimization(
            algorithm_kind="qaoa",
            algorithm_id=str(self.algorithm_id),
            layers=self.layers,
            parameter_names=self.parameter_names,
            hamiltonian=self.hamiltonian,
            ansatz=self.ansatz_spec(),
            evaluator=self.evaluate,
            circuit_builder=self.build_circuit,
            gradient_evaluator=self.gradient,
            problem=self.problem,
            mis_penalty=self.mis_penalty,
            mwis_penalty=self.mwis_penalty,
            backend=backend,
            optimizer=optimizer,
            initial_parameters=initial_parameters,
            algorithm_run_id=algorithm_run_id,
            final_shots=final_shots,
            noise=noise,
            options=options,
        )


def _validate_qaoa_hamiltonian(hamiltonian: PauliHamiltonian) -> None:
    for term in hamiltonian.terms:
        bases = term.observable.bases
        if bases not in {
            (PauliBasis.Z,),
            (PauliBasis.Z, PauliBasis.Z),
        }:
            raise ValueError("QAOA supports only one- and two-target Pauli-Z terms.")
