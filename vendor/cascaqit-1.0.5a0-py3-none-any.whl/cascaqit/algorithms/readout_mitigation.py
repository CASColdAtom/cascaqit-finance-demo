"""Tensor-product readout mitigation contracts and statistical estimators."""

from __future__ import annotations

import hashlib
import json
import math
import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import TYPE_CHECKING, Any, Literal, Union

import numpy as np
from numpy.typing import NDArray

from cascaqit.native_ir.base import IRMixin, stable_json
from cascaqit.observables import PauliBasis

if TYPE_CHECKING:
    from cascaqit.algorithms.measurement import PauliMeasurementGroupIR

__all__ = [
    "READOUT_MITIGATION_SCHEMA_VERSION",
    "ReadoutCalibration",
    "ReadoutCalibrationMatrixIR",
    "ReadoutMitigatedGroupStatisticsIR",
    "ReadoutMitigatedContributionIR",
    "ReadoutMitigationConfig",
    "compute_readout_mitigated_group_statistics",
    "validate_readout_mitigation",
]

READOUT_MITIGATION_SCHEMA_VERSION = "cascaqit.algorithms.readout_mitigation.v1"
_DIGEST_PATTERN = re.compile(r"[0-9a-f]{64}")
_FLOAT_TOLERANCE = 1e-12
ProbabilityInput = Union[float, Mapping[str, float]]


@dataclass(frozen=True)
class ReadoutCalibrationMatrixIR(IRMixin):
    """一个量子位的读出响应矩阵，方向固定为 ``P(measured | prepared)``。

    字段名沿用条件概率记法：``p01`` 表示制备 0 后测得 1 的概率，
    ``p10`` 表示制备 1 后测得 0 的概率。用于线性代数时，矩阵的行是
    measured state，列是 prepared/true state。
    """

    target: str
    p00: float
    p01: float
    p10: float
    p11: float
    schema_version: str = READOUT_MITIGATION_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_text(self.target, "target")
        probabilities = tuple(
            _probability(getattr(self, name), name)
            for name in ("p00", "p01", "p10", "p11")
        )
        p00, p01, p10, p11 = probabilities
        if not math.isclose(p00 + p01, 1.0, rel_tol=0.0, abs_tol=_FLOAT_TOLERANCE):
            raise ValueError("readout probabilities for prepared 0 must sum to one.")
        if not math.isclose(p10 + p11, 1.0, rel_tol=0.0, abs_tol=_FLOAT_TOLERANCE):
            raise ValueError("readout probabilities for prepared 1 must sum to one.")
        _require_schema(self.schema_version)
        for name, value in zip(("p00", "p01", "p10", "p11"), probabilities):
            object.__setattr__(self, name, value)

    @classmethod
    def from_error_probabilities(
        cls,
        target: str,
        *,
        p01: float,
        p10: float,
    ) -> ReadoutCalibrationMatrixIR:
        """由两种方向的读出错误率构造归一化响应矩阵。"""
        error_01 = _probability(p01, "p01")
        error_10 = _probability(p10, "p10")
        return cls(
            target=target,
            p00=1.0 - error_01,
            p01=error_01,
            p10=error_10,
            p11=1.0 - error_10,
        )

    @property
    def response_matrix(self) -> tuple[tuple[float, float], tuple[float, float]]:
        """返回 ``A[m, t] = P(measured=m | true=t)`` 的矩阵。"""
        return ((self.p00, self.p10), (self.p01, self.p11))

    @property
    def determinant(self) -> float:
        """返回响应矩阵行列式。"""
        return self.p00 * self.p11 - self.p10 * self.p01

    @property
    def condition_number(self) -> float:
        """返回响应矩阵的 2-范数条件数。"""
        return float(np.linalg.cond(np.asarray(self.response_matrix, dtype=float)))

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ReadoutCalibrationMatrixIR:
        """从字典恢复并重新校验一个响应矩阵。"""
        return cls(
            target=data["target"],
            p00=data["p00"],
            p01=data["p01"],
            p10=data["p10"],
            p11=data["p11"],
            schema_version=str(
                data.get("schema_version", READOUT_MITIGATION_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> ReadoutCalibrationMatrixIR:
        """从 JSON 恢复一个响应矩阵。"""
        return cls.from_dict(_json_object(text, "ReadoutCalibrationMatrixIR"))


@dataclass(frozen=True)
class ReadoutCalibration(IRMixin):
    """按 logical order 冻结的逐量子位读出校准。"""

    calibration_id: str
    calibration_hash: str
    logical_order: tuple[str, ...]
    matrices: tuple[ReadoutCalibrationMatrixIR, ...]
    source: str
    metadata: Mapping[str, Any] = field(default_factory=dict)
    schema_version: str = READOUT_MITIGATION_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_text(self.calibration_id, "calibration_id")
        _require_digest(self.calibration_hash, "calibration_hash")
        logical_order = tuple(self.logical_order)
        _require_unique_text(logical_order, "logical_order")
        matrices = tuple(self.matrices)
        if len(matrices) != len(logical_order) or any(
            not isinstance(item, ReadoutCalibrationMatrixIR) for item in matrices
        ):
            raise ValueError("matrices must cover every logical qubit exactly once.")
        if tuple(item.target for item in matrices) != logical_order:
            raise ValueError("calibration matrices must follow logical_order.")
        _require_text(self.source, "source")
        metadata = MappingProxyType(dict(self.metadata))
        _require_schema(self.schema_version)
        object.__setattr__(self, "logical_order", logical_order)
        object.__setattr__(self, "matrices", matrices)
        object.__setattr__(self, "metadata", metadata)
        expected_hash = _calibration_hash(self)
        if self.calibration_hash != expected_hash:
            raise ValueError("calibration_hash does not match calibration facts.")
        if self.calibration_id != f"readout.calibration.{expected_hash[:20]}":
            raise ValueError("calibration_id does not match calibration_hash.")

    @classmethod
    def from_probabilities(
        cls,
        *,
        logical_order: Sequence[str],
        p01: ProbabilityInput,
        p10: ProbabilityInput | None = None,
        source: str,
        metadata: Mapping[str, Any] | None = None,
    ) -> ReadoutCalibration:
        """由逐量子位或统一错误率构造校准。

        ``p10`` 省略时采用与 ``p01`` 相同的对称错误率。映射输入必须精确
        覆盖 logical order，避免遗漏量子位后静默套用错误校准。
        """
        order = tuple(logical_order)
        _require_unique_text(order, "logical_order")
        errors_01 = _resolve_probability_input(p01, order, "p01")
        errors_10 = _resolve_probability_input(
            p01 if p10 is None else p10,
            order,
            "p10",
        )
        matrices = tuple(
            ReadoutCalibrationMatrixIR.from_error_probabilities(
                target,
                p01=errors_01[target],
                p10=errors_10[target],
            )
            for target in order
        )
        values: dict[str, Any] = {
            "logical_order": order,
            "matrices": matrices,
            "source": source,
            "metadata": {} if metadata is None else dict(metadata),
            "schema_version": READOUT_MITIGATION_SCHEMA_VERSION,
        }
        digest = _calibration_hash(values)
        return cls(
            calibration_id=f"readout.calibration.{digest[:20]}",
            calibration_hash=digest,
            **values,
        )

    @property
    def condition_numbers(self) -> Mapping[str, float]:
        """返回每个逻辑量子位的响应矩阵条件数。"""
        return MappingProxyType(
            {item.target: item.condition_number for item in self.matrices}
        )

    @property
    def total_condition_number(self) -> float:
        """返回张量积响应矩阵的条件数。

        2-范数下 Kronecker product（克罗内克积）的条件数等于各因子的
        条件数乘积，因此无需构造指数大小的完整矩阵。
        """
        return math.prod(item.condition_number for item in self.matrices)

    def matrix_for(self, target: str) -> ReadoutCalibrationMatrixIR:
        """返回指定 logical qubit 的响应矩阵。"""
        for matrix in self.matrices:
            if matrix.target == target:
                return matrix
        raise KeyError(target)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ReadoutCalibration:
        """从字典恢复并重新校验校准 hash。"""
        return cls(
            calibration_id=data["calibration_id"],
            calibration_hash=data["calibration_hash"],
            logical_order=tuple(_sequence(data["logical_order"], "logical_order")),
            matrices=tuple(
                ReadoutCalibrationMatrixIR.from_dict(_mapping(item, "matrix"))
                for item in _sequence(data["matrices"], "matrices")
            ),
            source=data["source"],
            metadata=dict(_mapping(data.get("metadata", {}), "metadata")),
            schema_version=str(
                data.get("schema_version", READOUT_MITIGATION_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> ReadoutCalibration:
        """从 JSON 恢复读出校准。"""
        return cls.from_dict(_json_object(text, "ReadoutCalibration"))


@dataclass(frozen=True)
class ReadoutMitigationConfig(IRMixin):
    """配置 tensor-product linear-inverse 读出误差缓解。"""

    calibration: ReadoutCalibration
    method: Literal["tensor_product_linear_inverse"] = "tensor_product_linear_inverse"
    max_condition_number: float = 100.0
    schema_version: str = READOUT_MITIGATION_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if not isinstance(self.calibration, ReadoutCalibration):
            raise TypeError("calibration must be ReadoutCalibration.")
        if self.method != "tensor_product_linear_inverse":
            raise ValueError("method must be tensor_product_linear_inverse.")
        limit = _finite_positive_float(
            self.max_condition_number,
            "max_condition_number",
        )
        _require_schema(self.schema_version)
        _validate_matrix_condition(self.calibration, limit)
        object.__setattr__(self, "max_condition_number", limit)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ReadoutMitigationConfig:
        """从字典恢复缓解配置。"""
        return cls(
            calibration=ReadoutCalibration.from_dict(
                _mapping(data["calibration"], "calibration")
            ),
            method=data.get("method", "tensor_product_linear_inverse"),
            max_condition_number=data.get("max_condition_number", 100.0),
            schema_version=str(
                data.get("schema_version", READOUT_MITIGATION_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> ReadoutMitigationConfig:
        """从 JSON 恢复缓解配置。"""
        return cls.from_dict(_json_object(text, "ReadoutMitigationConfig"))


@dataclass(frozen=True)
class ReadoutMitigatedContributionIR(IRMixin):
    """一个允许 quasi expectation 超出物理 Pauli 区间的能量贡献。"""

    term_id: str
    observable_name: str
    coefficient: float
    expectation: float
    contribution: float
    schema_version: str = READOUT_MITIGATION_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_text(self.term_id, "term_id")
        _require_text(self.observable_name, "observable_name")
        coefficient = _finite_float(self.coefficient, "coefficient")
        expectation = _finite_float(self.expectation, "expectation")
        contribution = _finite_float(self.contribution, "contribution")
        if not math.isclose(
            contribution,
            coefficient * expectation,
            rel_tol=0.0,
            abs_tol=_FLOAT_TOLERANCE,
        ):
            raise ValueError(
                "contribution must equal coefficient times mitigated expectation."
            )
        _require_schema(self.schema_version)
        object.__setattr__(self, "coefficient", coefficient)
        object.__setattr__(self, "expectation", expectation)
        object.__setattr__(self, "contribution", contribution)

    @classmethod
    def from_dict(
        cls,
        data: Mapping[str, Any],
    ) -> ReadoutMitigatedContributionIR:
        """从字典恢复缓解后的能量贡献。"""
        return cls(
            term_id=data["term_id"],
            observable_name=data["observable_name"],
            coefficient=data["coefficient"],
            expectation=data["expectation"],
            contribution=data["contribution"],
            schema_version=str(
                data.get("schema_version", READOUT_MITIGATION_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> ReadoutMitigatedContributionIR:
        """从 JSON 恢复缓解后的能量贡献。"""
        return cls.from_dict(_json_object(text, "ReadoutMitigatedContributionIR"))


@dataclass(frozen=True)
class ReadoutMitigatedGroupStatisticsIR(IRMixin):
    """由一组 raw counts 派生的缓解后 QWC 统计。"""

    statistics_hash: str
    group_index: int
    shots: int
    calibration_hash: str
    source_group_result_hashes: tuple[str, ...]
    term_expectations: Mapping[str, float]
    term_standard_errors: Mapping[str, float]
    energy_mean: float
    energy_standard_error: float
    variance_amplification: float | None
    schema_version: str = READOUT_MITIGATION_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_digest(self.statistics_hash, "statistics_hash")
        _require_non_negative_int(self.group_index, "group_index")
        if (
            not isinstance(self.shots, int)
            or isinstance(self.shots, bool)
            or self.shots < 2
        ):
            raise ValueError("shots must be an integer of at least two.")
        _require_digest(self.calibration_hash, "calibration_hash")
        hashes = tuple(self.source_group_result_hashes)
        for digest in hashes:
            _require_digest(digest, "source_group_result_hash")
        expectations = _float_mapping(self.term_expectations, "term_expectations")
        errors = _float_mapping(
            self.term_standard_errors,
            "term_standard_errors",
            non_negative=True,
        )
        if expectations.keys() != errors.keys():
            raise ValueError("term expectation and error keys must match.")
        energy = _finite_float(self.energy_mean, "energy_mean")
        energy_error = _finite_non_negative_float(
            self.energy_standard_error,
            "energy_standard_error",
        )
        amplification = self.variance_amplification
        if amplification is not None:
            amplification = _finite_non_negative_float(
                amplification,
                "variance_amplification",
            )
        _require_schema(self.schema_version)
        object.__setattr__(self, "source_group_result_hashes", hashes)
        object.__setattr__(self, "term_expectations", MappingProxyType(expectations))
        object.__setattr__(self, "term_standard_errors", MappingProxyType(errors))
        object.__setattr__(self, "energy_mean", energy)
        object.__setattr__(self, "energy_standard_error", energy_error)
        object.__setattr__(self, "variance_amplification", amplification)
        if self.statistics_hash != _statistics_hash(self):
            raise ValueError("statistics_hash does not match mitigated statistics.")

    @classmethod
    def create(
        cls,
        *,
        group_index: int,
        shots: int,
        calibration_hash: str,
        source_group_result_hashes: tuple[str, ...],
        term_expectations: Mapping[str, float],
        term_standard_errors: Mapping[str, float],
        energy_mean: float,
        energy_standard_error: float,
        variance_amplification: float | None,
    ) -> ReadoutMitigatedGroupStatisticsIR:
        """构造带稳定 hash 的缓解统计。"""
        values: dict[str, Any] = {
            "group_index": group_index,
            "shots": shots,
            "calibration_hash": calibration_hash,
            "source_group_result_hashes": source_group_result_hashes,
            "term_expectations": dict(term_expectations),
            "term_standard_errors": dict(term_standard_errors),
            "energy_mean": energy_mean,
            "energy_standard_error": energy_standard_error,
            "variance_amplification": variance_amplification,
            "schema_version": READOUT_MITIGATION_SCHEMA_VERSION,
        }
        return cls(statistics_hash=_statistics_hash(values), **values)

    @classmethod
    def from_dict(
        cls,
        data: Mapping[str, Any],
    ) -> ReadoutMitigatedGroupStatisticsIR:
        """从字典恢复并校验缓解统计 hash。"""
        return cls(
            statistics_hash=data["statistics_hash"],
            group_index=data["group_index"],
            shots=data["shots"],
            calibration_hash=data["calibration_hash"],
            source_group_result_hashes=tuple(
                str(item)
                for item in _sequence(
                    data.get("source_group_result_hashes", ()),
                    "source_group_result_hashes",
                )
            ),
            term_expectations={
                str(key): value
                for key, value in _mapping(
                    data["term_expectations"], "term_expectations"
                ).items()
            },
            term_standard_errors={
                str(key): value
                for key, value in _mapping(
                    data["term_standard_errors"], "term_standard_errors"
                ).items()
            },
            energy_mean=data["energy_mean"],
            energy_standard_error=data["energy_standard_error"],
            variance_amplification=data.get("variance_amplification"),
            schema_version=str(
                data.get("schema_version", READOUT_MITIGATION_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> ReadoutMitigatedGroupStatisticsIR:
        """从 JSON 恢复缓解后的组统计。"""
        return cls.from_dict(_json_object(text, "ReadoutMitigatedGroupStatisticsIR"))


def validate_readout_mitigation(
    config: ReadoutMitigationConfig,
    logical_order: Sequence[str],
) -> None:
    """校验缓解配置与待测程序的 logical order 一致。"""
    if not isinstance(config, ReadoutMitigationConfig):
        raise TypeError("config must be ReadoutMitigationConfig.")
    order = tuple(logical_order)
    _require_unique_text(order, "logical_order")
    if config.calibration.logical_order != order:
        raise ValueError(
            "readout calibration logical_order does not match the program."
        )
    _validate_matrix_condition(config.calibration, config.max_condition_number)


def compute_readout_mitigated_group_statistics(
    group: PauliMeasurementGroupIR,
    raw_counts: Mapping[str, int],
    *,
    shots: int,
    config: ReadoutMitigationConfig,
    source_group_result_hashes: tuple[str, ...] = (),
) -> ReadoutMitigatedGroupStatisticsIR:
    """从 raw QWC counts 计算线性逆缓解后的组统计。

    每个 Pauli 项先把真实本征值向量 ``f`` 变换为观测样本权重
    ``g=A^{-T}f``。随后在同一条 raw bitstring 上计算全部项和组能量，
    从而保留项间协方差。此过程允许负权重和超出物理概率范围的值。
    """
    from cascaqit.algorithms.measurement import PauliMeasurementGroupIR

    if not isinstance(group, PauliMeasurementGroupIR):
        raise TypeError("group must be PauliMeasurementGroupIR.")
    validate_readout_mitigation(config, group.logical_order)
    counts = _normalize_counts(raw_counts, logical_width=len(group.logical_order))
    if sum(counts.values()) != shots:
        raise ValueError("raw_counts must sum to shots.")
    if not isinstance(shots, int) or isinstance(shots, bool) or shots < 2:
        raise ValueError("shots must be an integer of at least two.")

    corrected_vectors: dict[str, tuple[NDArray[np.float64], ...]] = {}
    for term in group.terms:
        factor_by_target = {
            factor.target: factor.basis for factor in term.observable.terms
        }
        vectors: list[NDArray[np.float64]] = []
        for target in group.logical_order:
            basis = factor_by_target.get(target, PauliBasis.I)
            true_values = (
                np.asarray((1.0, 1.0), dtype=float)
                if basis is PauliBasis.I
                else np.asarray((1.0, -1.0), dtype=float)
            )
            response = np.asarray(
                config.calibration.matrix_for(target).response_matrix,
                dtype=float,
            )
            # q=A p，因此 f^T p=(A^{-T}f)^T q。使用 solve 避免显式求逆。
            vectors.append(np.linalg.solve(response.T, true_values))
        corrected_vectors[term.term_id] = tuple(vectors)

    term_sums = {term.term_id: 0.0 for term in group.terms}
    term_square_sums = {term.term_id: 0.0 for term in group.terms}
    group_sum = 0.0
    group_square_sum = 0.0
    raw_group_sum = 0.0
    raw_group_square_sum = 0.0
    for bitstring, count in counts.items():
        corrected_group_value = 0.0
        raw_group_value = 0.0
        for term in group.terms:
            corrected_value = 1.0
            raw_value = 1.0
            factor_by_target = {
                factor.target: factor.basis for factor in term.observable.terms
            }
            for axis, target in enumerate(group.logical_order):
                bit = 0 if bitstring[axis] == "0" else 1
                corrected_value *= corrected_vectors[term.term_id][axis][bit]
                if factor_by_target.get(target, PauliBasis.I) is not PauliBasis.I:
                    raw_value *= 1.0 if bit == 0 else -1.0
            term_sums[term.term_id] += corrected_value * count
            term_square_sums[term.term_id] += corrected_value**2 * count
            corrected_group_value += term.coefficient * corrected_value
            raw_group_value += term.coefficient * raw_value
        group_sum += corrected_group_value * count
        group_square_sum += corrected_group_value**2 * count
        raw_group_sum += raw_group_value * count
        raw_group_square_sum += raw_group_value**2 * count

    expectations = {term_id: total / shots for term_id, total in term_sums.items()}
    errors = {
        term_id: _standard_error(total, term_square_sums[term_id], shots)
        for term_id, total in term_sums.items()
    }
    energy_mean = group_sum / shots
    energy_standard_error = _standard_error(group_sum, group_square_sum, shots)
    raw_variance = _sample_variance(raw_group_sum, raw_group_square_sum, shots)
    mitigated_variance = _sample_variance(group_sum, group_square_sum, shots)
    amplification = (
        None if raw_variance <= _FLOAT_TOLERANCE else mitigated_variance / raw_variance
    )
    return ReadoutMitigatedGroupStatisticsIR.create(
        group_index=group.group_index,
        shots=shots,
        calibration_hash=config.calibration.calibration_hash,
        source_group_result_hashes=source_group_result_hashes,
        term_expectations=expectations,
        term_standard_errors=errors,
        energy_mean=energy_mean,
        energy_standard_error=energy_standard_error,
        variance_amplification=amplification,
    )


def _standard_error(total: float, square_total: float, shots: int) -> float:
    return math.sqrt(_sample_variance(total, square_total, shots) / shots)


def _sample_variance(total: float, square_total: float, shots: int) -> float:
    centered = max(0.0, square_total - total * total / shots)
    return centered / (shots - 1)


def _validate_matrix_condition(
    calibration: ReadoutCalibration,
    max_condition_number: float,
) -> None:
    for matrix in calibration.matrices:
        if math.isclose(
            matrix.determinant,
            0.0,
            rel_tol=0.0,
            abs_tol=_FLOAT_TOLERANCE,
        ):
            raise ValueError(
                f"readout calibration matrix for {matrix.target!r} is singular."
            )
        condition = matrix.condition_number
        if not math.isfinite(condition) or condition > max_condition_number:
            raise ValueError(
                "readout calibration matrix condition number exceeds "
                f"max_condition_number for {matrix.target!r}."
            )
    total = calibration.total_condition_number
    if not math.isfinite(total) or total > max_condition_number:
        raise ValueError(
            "tensor-product readout calibration condition number exceeds "
            "max_condition_number."
        )


def _calibration_hash(value: Any) -> str:
    material = _without_keys(value, {"calibration_id", "calibration_hash"})
    return hashlib.sha256(stable_json(material).encode("utf-8")).hexdigest()


def _statistics_hash(value: Any) -> str:
    return hashlib.sha256(
        stable_json(_without_keys(value, {"statistics_hash"})).encode("utf-8")
    ).hexdigest()


def _without_keys(value: Any, omitted: set[str]) -> dict[str, Any]:
    if isinstance(value, Mapping):
        data = dict(value)
    elif isinstance(value, IRMixin):
        data = value.to_dict()
    else:
        data = {
            item.name: getattr(value, item.name)
            for item in value.__dataclass_fields__.values()
        }
    return {key: item for key, item in data.items() if key not in omitted}


def _resolve_probability_input(
    value: ProbabilityInput,
    logical_order: tuple[str, ...],
    name: str,
) -> dict[str, float]:
    if isinstance(value, Mapping):
        if set(value) != set(logical_order):
            raise ValueError(f"{name} mapping must exactly cover logical_order.")
        return {
            target: _probability(value[target], f"{name}.{target}")
            for target in logical_order
        }
    probability = _probability(value, name)
    return {target: probability for target in logical_order}


def _normalize_counts(
    raw_counts: Mapping[str, int],
    *,
    logical_width: int,
) -> dict[str, int]:
    if not isinstance(raw_counts, Mapping):
        raise TypeError("raw_counts must be a mapping.")
    counts: dict[str, int] = {}
    for bitstring, count in raw_counts.items():
        if (
            not isinstance(bitstring, str)
            or len(bitstring) != logical_width
            or set(bitstring) - {"0", "1"}
        ):
            raise ValueError("raw_counts keys must be fixed-width bitstrings.")
        if not isinstance(count, int) or isinstance(count, bool) or count <= 0:
            raise ValueError("raw_counts values must be positive integers.")
        counts[bitstring] = count
    if not counts:
        raise ValueError("raw_counts must not be empty.")
    return dict(sorted(counts.items()))


def _float_mapping(
    value: Mapping[str, Any],
    name: str,
    *,
    non_negative: bool = False,
) -> dict[str, float]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{name} must be a mapping.")
    output: dict[str, float] = {}
    for key, item in value.items():
        _require_text(key, f"{name} key")
        number = _finite_float(item, f"{name}.{key}")
        if non_negative and number < 0.0:
            raise ValueError(f"{name}.{key} must be non-negative.")
        output[key] = number
    return output


def _probability(value: Any, name: str) -> float:
    number = _finite_float(value, name)
    if not 0.0 <= number <= 1.0:
        raise ValueError(f"{name} must be between zero and one.")
    return number


def _finite_float(value: Any, name: str) -> float:
    if isinstance(value, bool):
        raise TypeError(f"{name} must be a finite real number.")
    try:
        number = float(value)
    except (TypeError, ValueError) as exc:
        raise TypeError(f"{name} must be a finite real number.") from exc
    if not math.isfinite(number):
        raise ValueError(f"{name} must be finite.")
    return number


def _finite_non_negative_float(value: Any, name: str) -> float:
    number = _finite_float(value, name)
    if number < 0.0:
        raise ValueError(f"{name} must be non-negative.")
    return number


def _finite_positive_float(value: Any, name: str) -> float:
    number = _finite_float(value, name)
    if number <= 0.0:
        raise ValueError(f"{name} must be positive.")
    return number


def _require_non_negative_int(value: Any, name: str) -> None:
    if not isinstance(value, int) or isinstance(value, bool) or value < 0:
        raise ValueError(f"{name} must be a non-negative integer.")


def _require_text(value: Any, name: str) -> None:
    if not isinstance(value, str) or not value.strip() or value != value.strip():
        raise ValueError(f"{name} must be a non-empty trimmed string.")


def _require_unique_text(values: tuple[str, ...], name: str) -> None:
    if not values:
        raise ValueError(f"{name} must not be empty.")
    for value in values:
        _require_text(value, name)
    if len(values) != len(set(values)):
        raise ValueError(f"{name} must contain unique values.")


def _require_digest(value: Any, name: str) -> None:
    if not isinstance(value, str) or _DIGEST_PATTERN.fullmatch(value) is None:
        raise ValueError(f"{name} must be a lowercase SHA-256 digest.")


def _require_schema(value: str) -> None:
    if value != READOUT_MITIGATION_SCHEMA_VERSION:
        raise ValueError(f"Unsupported readout mitigation schema version: {value!r}.")


def _mapping(value: Any, name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{name} must be a mapping.")
    return value


def _sequence(value: Any, name: str) -> Sequence[Any]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        raise TypeError(f"{name} must be a sequence.")
    return value


def _json_object(text: str, name: str) -> Mapping[str, Any]:
    data = json.loads(text)
    if not isinstance(data, Mapping):
        raise TypeError(f"{name} JSON must contain an object.")
    return data
