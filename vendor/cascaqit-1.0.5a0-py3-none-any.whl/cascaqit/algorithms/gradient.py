"""Parameter-shift planning and auditable gradient result contracts."""

from __future__ import annotations

import hashlib
import json
import math
import re
from collections.abc import Mapping
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Any, Literal, NoReturn, Union, cast

from cascaqit.algorithms.execution import (
    ParameterValues,
    execute_objective_evaluation,
    normalize_parameter_values,
)
from cascaqit.algorithms.measurement import (
    PauliMeasurementConfig,
    SampledObjectiveEvaluationIR,
    _group_statistics,
    build_group_measurement_circuit,
    build_pauli_measurement_plan,
    derive_adaptive_measurement_group_seed,
    derive_measurement_group_seed,
    execute_sampled_objective_evaluation,
)
from cascaqit.algorithms.models import (
    ObjectiveEvaluationIR,
    PauliHamiltonian,
)
from cascaqit.algorithms.noisy_execution import (
    validate_noisy_variational_request,
    validate_sampled_variational_request,
)
from cascaqit.algorithms.readout_mitigation import (
    compute_readout_mitigated_group_statistics,
)
from cascaqit.digital import Circuit, GateParameterOccurrence
from cascaqit.exceptions import CapabilityError
from cascaqit.native_ir.base import IRMixin, stable_json
from cascaqit.parameters import ParameterBindIR, ParameterSchemaIR
from cascaqit.parameters.canonical import Expression, Parameter
from cascaqit.simulators import LocalBackend, NoiseModel, SimulationOptions

__all__ = [
    "GradientConfig",
    "GradientRepeatIR",
    "ObjectiveGradientIR",
    "ParameterShiftOccurrenceIR",
    "ParameterShiftPlanIR",
    "PooledShiftPairIR",
    "ShiftPairEvaluationIR",
    "build_parameter_shift_plan",
    "execute_parameter_shift_gradient",
]

GRADIENT_SCHEMA_VERSION = "cascaqit.algorithms.gradient.v3"
_DIGEST_PATTERN = re.compile(r"[0-9a-f]{64}")
_TOLERANCE = 1e-12
_STANDARD_SHIFT = math.pi / 2.0
_STANDARD_PREFACTOR = 0.5

GradientObjectiveEvaluationIR = Union[
    ObjectiveEvaluationIR,
    SampledObjectiveEvaluationIR,
]


@dataclass(frozen=True)
class GradientConfig(IRMixin):
    """Parameter-shift method and complete-gradient repeat policy."""

    method: Literal["parameter_shift"] = "parameter_shift"
    shift: float = _STANDARD_SHIFT
    prefactor: float = _STANDARD_PREFACTOR
    max_evaluations: int | None = None
    max_objective_evaluations: int | None = None
    repeats: int = 1
    max_repeats: int | None = None
    uncertainty_norm_target: float | None = None
    schema_version: str = GRADIENT_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.method != "parameter_shift":
            raise ValueError("gradient method must be parameter_shift.")
        shift = _finite_float(self.shift, "shift")
        prefactor = _finite_float(self.prefactor, "prefactor")
        if not math.isclose(shift, _STANDARD_SHIFT, rel_tol=0.0, abs_tol=1e-15):
            raise ValueError("parameter-shift shift must equal pi/2.")
        if not math.isclose(
            prefactor,
            _STANDARD_PREFACTOR,
            rel_tol=0.0,
            abs_tol=1e-15,
        ):
            raise ValueError("parameter-shift prefactor must equal 0.5.")
        if self.max_evaluations is not None and (
            not isinstance(self.max_evaluations, int)
            or isinstance(self.max_evaluations, bool)
            or self.max_evaluations <= 0
        ):
            raise ValueError("max_evaluations must be a positive integer or None.")
        if self.max_objective_evaluations is not None:
            _require_positive_int(
                self.max_objective_evaluations,
                "max_objective_evaluations",
            )
        _require_positive_int(self.repeats, "repeats")
        if (self.max_repeats is None) != (self.uncertainty_norm_target is None):
            raise ValueError(
                "max_repeats and uncertainty_norm_target must be provided together."
            )
        if self.max_repeats is not None:
            _require_positive_int(self.max_repeats, "max_repeats")
            if self.repeats < 2:
                raise ValueError(
                    "adaptive gradient repeats require repeats to be at least 2."
                )
            if self.max_repeats <= self.repeats:
                raise ValueError("max_repeats must be greater than repeats.")
            target = _finite_float(
                self.uncertainty_norm_target,
                "uncertainty_norm_target",
            )
            if target <= 0.0:
                raise ValueError("uncertainty_norm_target must be positive.")
            object.__setattr__(self, "uncertainty_norm_target", target)
        object.__setattr__(self, "shift", shift)
        object.__setattr__(self, "prefactor", prefactor)

    @property
    def repeat_mode(self) -> Literal["fixed", "adaptive"]:
        """Return whether the executor uses a fixed or bounded adaptive policy."""
        return "adaptive" if self.max_repeats is not None else "fixed"

    @property
    def effective_max_repeats(self) -> int:
        """Return the configured hard repeat ceiling."""
        return self.repeats if self.max_repeats is None else self.max_repeats

    def to_dict(self) -> dict[str, Any]:
        """Keep the default Gate AC payload compact and byte-compatible."""
        data = super().to_dict()
        if self.repeats == 1:
            data.pop("repeats", None)
        if self.max_repeats is None:
            data.pop("max_repeats", None)
            data.pop("uncertainty_norm_target", None)
        if self.max_objective_evaluations is None:
            data.pop("max_objective_evaluations", None)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> GradientConfig:
        """Restore gradient configuration from JSON-compatible data."""
        return cls(
            method=data.get("method", "parameter_shift"),
            shift=data.get("shift", _STANDARD_SHIFT),
            prefactor=data.get("prefactor", _STANDARD_PREFACTOR),
            max_evaluations=data.get("max_evaluations"),
            max_objective_evaluations=data.get("max_objective_evaluations"),
            repeats=data.get("repeats", 1),
            max_repeats=data.get("max_repeats"),
            uncertainty_norm_target=data.get("uncertainty_norm_target"),
            schema_version=str(data.get("schema_version", GRADIENT_SCHEMA_VERSION)),
        )

    @classmethod
    def from_json(cls, text: str) -> GradientConfig:
        """Restore gradient configuration from JSON text."""
        return cls.from_dict(_json_object(text, "GradientConfig"))


@dataclass(frozen=True)
class ParameterShiftOccurrenceIR(IRMixin):
    """One supported gate occurrence and its two shifted Circuit identities."""

    occurrence_id: str
    gate_index: int
    gate_id: str
    gate_name: Literal["rx", "ry", "rz"]
    targets: tuple[str, ...]
    parameter_name: Literal["theta"]
    affine_offset: float
    coefficients: Mapping[str, float]
    positive_circuit_hash: str
    negative_circuit_hash: str
    schema_version: str = GRADIENT_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_text(self.occurrence_id, "occurrence_id")
        _require_non_negative_int(self.gate_index, "gate_index")
        _require_text(self.gate_id, "gate_id")
        if self.gate_name not in {"rx", "ry", "rz"}:
            raise ValueError("gradient occurrence gate_name must be rx, ry, or rz.")
        targets = tuple(str(target) for target in self.targets)
        if len(targets) != 1 or not targets[0]:
            raise ValueError("gradient occurrence must contain one target.")
        object.__setattr__(self, "targets", targets)
        if self.parameter_name != "theta":
            raise ValueError("gradient occurrence parameter_name must be theta.")
        object.__setattr__(
            self,
            "affine_offset",
            _finite_float(self.affine_offset, "affine_offset"),
        )
        coefficients = _finite_mapping(self.coefficients, "coefficients")
        if not coefficients:
            raise ValueError("gradient occurrence coefficients must not be empty.")
        object.__setattr__(self, "coefficients", coefficients)
        _require_digest(self.positive_circuit_hash, "positive_circuit_hash")
        _require_digest(self.negative_circuit_hash, "negative_circuit_hash")
        if self.positive_circuit_hash == self.negative_circuit_hash:
            raise ValueError("positive and negative Circuit hashes must differ.")

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ParameterShiftOccurrenceIR:
        """Restore one planned occurrence from JSON-compatible data."""
        return cls(
            occurrence_id=data["occurrence_id"],
            gate_index=data["gate_index"],
            gate_id=data["gate_id"],
            gate_name=data["gate_name"],
            targets=tuple(_sequence(data["targets"], "targets")),
            parameter_name=data["parameter_name"],
            affine_offset=data["affine_offset"],
            coefficients=_mapping(data["coefficients"], "coefficients"),
            positive_circuit_hash=data["positive_circuit_hash"],
            negative_circuit_hash=data["negative_circuit_hash"],
            schema_version=str(data.get("schema_version", GRADIENT_SCHEMA_VERSION)),
        )


@dataclass(frozen=True)
class ParameterShiftPlanIR(IRMixin):
    """Complete side-effect-free parameter-shift execution plan."""

    source_circuit_hash: str
    hamiltonian_hash: str
    logical_order: tuple[str, ...]
    parameter_names: tuple[str, ...]
    occurrences: tuple[ParameterShiftOccurrenceIR, ...]
    shift: float = _STANDARD_SHIFT
    prefactor: float = _STANDARD_PREFACTOR
    expected_objective_evaluation_count: int = 0
    plan_hash: str = ""
    method: Literal["parameter_shift"] = "parameter_shift"
    schema_version: str = GRADIENT_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_digest(self.source_circuit_hash, "source_circuit_hash")
        _require_digest(self.hamiltonian_hash, "hamiltonian_hash")
        logical_order = _unique_text_tuple(self.logical_order, "logical_order")
        parameter_names = _unique_text_tuple(self.parameter_names, "parameter_names")
        object.__setattr__(self, "logical_order", logical_order)
        object.__setattr__(self, "parameter_names", parameter_names)
        occurrences = tuple(self.occurrences)
        if not occurrences or any(
            not isinstance(item, ParameterShiftOccurrenceIR) for item in occurrences
        ):
            raise ValueError("occurrences must contain planned parameter shifts.")
        occurrence_ids = tuple(item.occurrence_id for item in occurrences)
        if len(occurrence_ids) != len(set(occurrence_ids)):
            raise ValueError("gradient occurrence ids must be unique.")
        if tuple(item.gate_index for item in occurrences) != tuple(
            sorted(item.gate_index for item in occurrences)
        ):
            raise ValueError("gradient occurrences must follow Circuit gate order.")
        for occurrence in occurrences:
            if not set(occurrence.coefficients).issubset(parameter_names):
                raise ValueError("occurrence coefficients contain unknown parameters.")
        covered = {
            name for occurrence in occurrences for name in occurrence.coefficients
        }
        if covered != set(parameter_names):
            raise ValueError(
                "every plan parameter must have an occurrence coefficient."
            )
        object.__setattr__(self, "occurrences", occurrences)
        if self.method != "parameter_shift":
            raise ValueError("gradient plan method must be parameter_shift.")
        GradientConfig(method=self.method, shift=self.shift, prefactor=self.prefactor)
        expected_count = 2 * len(occurrences)
        if self.expected_objective_evaluation_count != expected_count:
            raise ValueError(
                "expected_objective_evaluation_count must equal two per occurrence."
            )
        if not self.plan_hash:
            object.__setattr__(self, "plan_hash", self.compute_plan_hash())
        else:
            _require_digest(self.plan_hash, "plan_hash")
            if not self.verify_hash():
                raise ValueError("plan_hash does not match the gradient plan.")

    def compute_plan_hash(self) -> str:
        """Hash all executable plan facts except the embedded hash itself."""
        return hashlib.sha256(
            stable_json(self._hash_payload()).encode("utf-8")
        ).hexdigest()

    def verify_hash(self) -> bool:
        """Return whether the embedded plan hash matches current facts."""
        return self.plan_hash == self.compute_plan_hash()

    def _hash_payload(self) -> dict[str, Any]:
        return {
            "source_circuit_hash": self.source_circuit_hash,
            "hamiltonian_hash": self.hamiltonian_hash,
            "logical_order": self.logical_order,
            "parameter_names": self.parameter_names,
            "occurrences": self.occurrences,
            "shift": self.shift,
            "prefactor": self.prefactor,
            "expected_objective_evaluation_count": (
                self.expected_objective_evaluation_count
            ),
            "method": self.method,
            "schema_version": self.schema_version,
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ParameterShiftPlanIR:
        """Restore and verify a plan from JSON-compatible data."""
        return cls(
            source_circuit_hash=data["source_circuit_hash"],
            hamiltonian_hash=data["hamiltonian_hash"],
            logical_order=tuple(_sequence(data["logical_order"], "logical_order")),
            parameter_names=tuple(
                _sequence(data["parameter_names"], "parameter_names")
            ),
            occurrences=tuple(
                ParameterShiftOccurrenceIR.from_dict(_mapping(item, "occurrence"))
                for item in _sequence(data["occurrences"], "occurrences")
            ),
            shift=data["shift"],
            prefactor=data["prefactor"],
            expected_objective_evaluation_count=data[
                "expected_objective_evaluation_count"
            ],
            plan_hash=data["plan_hash"],
            method=data.get("method", "parameter_shift"),
            schema_version=str(data.get("schema_version", GRADIENT_SCHEMA_VERSION)),
        )

    @classmethod
    def from_json(cls, text: str) -> ParameterShiftPlanIR:
        """Restore and verify a plan from JSON text."""
        return cls.from_dict(_json_object(text, "ParameterShiftPlanIR"))


@dataclass(frozen=True)
class ShiftPairEvaluationIR(IRMixin):
    """Positive and negative Objective evaluations for one occurrence."""

    occurrence_id: str
    positive_circuit_hash: str
    negative_circuit_hash: str
    positive_evaluation: GradientObjectiveEvaluationIR
    negative_evaluation: GradientObjectiveEvaluationIR
    energy_difference: float
    prefactor: float
    gate_derivative: float
    gate_derivative_variance: float
    gate_derivative_standard_error: float
    objective_evaluation_count: int = 2
    backend_execution_count: int = 2
    total_shots: int = 0
    schema_version: str = GRADIENT_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_text(self.occurrence_id, "occurrence_id")
        _require_digest(self.positive_circuit_hash, "positive_circuit_hash")
        _require_digest(self.negative_circuit_hash, "negative_circuit_hash")
        if not isinstance(
            self.positive_evaluation,
            (ObjectiveEvaluationIR, SampledObjectiveEvaluationIR),
        ) or not isinstance(
            self.negative_evaluation,
            (ObjectiveEvaluationIR, SampledObjectiveEvaluationIR),
        ):
            raise TypeError(
                "shift pair evaluations must be exact or sampled objective IR."
            )
        if _evaluation_hamiltonian_hash(
            self.positive_evaluation
        ) != _evaluation_hamiltonian_hash(self.negative_evaluation):
            raise ValueError("shift pair Hamiltonian hashes must match.")
        _require_matching_execution_context(
            (self.positive_evaluation, self.negative_evaluation)
        )
        difference = self.positive_evaluation.energy - self.negative_evaluation.energy
        if not math.isclose(
            _finite_float(self.energy_difference, "energy_difference"),
            difference,
            rel_tol=0.0,
            abs_tol=_TOLERANCE,
        ):
            raise ValueError(
                "energy_difference must match positive minus negative energy."
            )
        prefactor = _finite_float(self.prefactor, "prefactor")
        derivative = prefactor * difference
        if not math.isclose(
            _finite_float(self.gate_derivative, "gate_derivative"),
            derivative,
            rel_tol=0.0,
            abs_tol=_TOLERANCE,
        ):
            raise ValueError(
                "gate_derivative must equal prefactor * energy_difference."
            )
        variance = _shift_pair_variance(
            self.positive_evaluation,
            self.negative_evaluation,
            prefactor=prefactor,
        )
        if not math.isclose(
            _finite_non_negative_float(
                self.gate_derivative_variance,
                "gate_derivative_variance",
            ),
            variance,
            rel_tol=0.0,
            abs_tol=_TOLERANCE,
        ):
            raise ValueError(
                "gate_derivative_variance must match the two objective errors."
            )
        standard_error = math.sqrt(variance)
        if not math.isclose(
            _finite_non_negative_float(
                self.gate_derivative_standard_error,
                "gate_derivative_standard_error",
            ),
            standard_error,
            rel_tol=0.0,
            abs_tol=_TOLERANCE,
        ):
            raise ValueError(
                "gate_derivative_standard_error must match derivative variance."
            )
        if self.objective_evaluation_count != 2:
            raise ValueError("each shift pair must record two objective evaluations.")
        expected_backend_count = sum(
            _evaluation_backend_execution_count(evaluation)
            for evaluation in (self.positive_evaluation, self.negative_evaluation)
        )
        if self.backend_execution_count != expected_backend_count:
            raise ValueError(
                "shift pair backend_execution_count must match objective evidence."
            )
        expected_shots = sum(
            _evaluation_total_shots(evaluation)
            for evaluation in (self.positive_evaluation, self.negative_evaluation)
        )
        if self.total_shots != expected_shots:
            raise ValueError("shift pair total_shots must match objective evidence.")
        object.__setattr__(self, "energy_difference", difference)
        object.__setattr__(self, "prefactor", prefactor)
        object.__setattr__(self, "gate_derivative", derivative)
        object.__setattr__(self, "gate_derivative_variance", variance)
        object.__setattr__(
            self,
            "gate_derivative_standard_error",
            standard_error,
        )

    @classmethod
    def create(
        cls,
        *,
        occurrence: ParameterShiftOccurrenceIR,
        positive_evaluation: GradientObjectiveEvaluationIR,
        negative_evaluation: GradientObjectiveEvaluationIR,
        prefactor: float,
    ) -> ShiftPairEvaluationIR:
        """Build one pair while deriving all arithmetic fields."""
        difference = positive_evaluation.energy - negative_evaluation.energy
        variance = _shift_pair_variance(
            positive_evaluation,
            negative_evaluation,
            prefactor=prefactor,
        )
        return cls(
            occurrence_id=occurrence.occurrence_id,
            positive_circuit_hash=occurrence.positive_circuit_hash,
            negative_circuit_hash=occurrence.negative_circuit_hash,
            positive_evaluation=positive_evaluation,
            negative_evaluation=negative_evaluation,
            energy_difference=difference,
            prefactor=prefactor,
            gate_derivative=prefactor * difference,
            gate_derivative_variance=variance,
            gate_derivative_standard_error=math.sqrt(variance),
            backend_execution_count=sum(
                _evaluation_backend_execution_count(evaluation)
                for evaluation in (positive_evaluation, negative_evaluation)
            ),
            total_shots=sum(
                _evaluation_total_shots(evaluation)
                for evaluation in (positive_evaluation, negative_evaluation)
            ),
        )

    @property
    def pair_hash(self) -> str:
        """Return a stable identity for this complete positive/negative pair."""
        return hashlib.sha256(stable_json(self).encode("utf-8")).hexdigest()

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ShiftPairEvaluationIR:
        """Restore and verify one shift pair."""
        return cls(
            occurrence_id=data["occurrence_id"],
            positive_circuit_hash=data["positive_circuit_hash"],
            negative_circuit_hash=data["negative_circuit_hash"],
            positive_evaluation=_gradient_objective_evaluation_from_dict(
                _mapping(data["positive_evaluation"], "positive_evaluation")
            ),
            negative_evaluation=_gradient_objective_evaluation_from_dict(
                _mapping(data["negative_evaluation"], "negative_evaluation")
            ),
            energy_difference=data["energy_difference"],
            prefactor=data["prefactor"],
            gate_derivative=data["gate_derivative"],
            gate_derivative_variance=data["gate_derivative_variance"],
            gate_derivative_standard_error=data["gate_derivative_standard_error"],
            objective_evaluation_count=data["objective_evaluation_count"],
            backend_execution_count=data["backend_execution_count"],
            total_shots=data["total_shots"],
            schema_version=str(data.get("schema_version", GRADIENT_SCHEMA_VERSION)),
        )


@dataclass(frozen=True)
class GradientRepeatIR(IRMixin):
    """One complete parameter-shift gradient repeat in plan occurrence order."""

    repeat_index: int
    plan_hash: str
    shift_pairs: tuple[ShiftPairEvaluationIR, ...]
    objective_evaluation_count: int
    backend_execution_count: int
    total_shots: int
    repeat_hash: str = ""
    schema_version: str = GRADIENT_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_non_negative_int(self.repeat_index, "repeat_index")
        _require_digest(self.plan_hash, "plan_hash")
        pairs = tuple(self.shift_pairs)
        if not pairs or any(
            not isinstance(pair, ShiftPairEvaluationIR) for pair in pairs
        ):
            raise TypeError(
                "shift_pairs must contain complete ShiftPairEvaluationIR values."
            )
        occurrence_ids = tuple(pair.occurrence_id for pair in pairs)
        if len(occurrence_ids) != len(set(occurrence_ids)):
            raise ValueError("one gradient repeat cannot duplicate an occurrence.")
        _require_matching_execution_context(
            tuple(
                evaluation
                for pair in pairs
                for evaluation in (
                    pair.positive_evaluation,
                    pair.negative_evaluation,
                )
            )
        )
        expected_objectives = sum(pair.objective_evaluation_count for pair in pairs)
        if self.objective_evaluation_count != expected_objectives:
            raise ValueError(
                "repeat objective_evaluation_count must match its shift pairs."
            )
        expected_backend = sum(pair.backend_execution_count for pair in pairs)
        if self.backend_execution_count != expected_backend:
            raise ValueError(
                "repeat backend_execution_count must match its shift pairs."
            )
        expected_shots = sum(pair.total_shots for pair in pairs)
        if self.total_shots != expected_shots:
            raise ValueError("repeat total_shots must match its shift pairs.")
        object.__setattr__(self, "shift_pairs", pairs)
        if not self.repeat_hash:
            object.__setattr__(self, "repeat_hash", self.compute_repeat_hash())
        else:
            _require_digest(self.repeat_hash, "repeat_hash")
            if not self.verify_hash():
                raise ValueError("repeat_hash does not match gradient repeat facts.")

    @classmethod
    def create(
        cls,
        *,
        repeat_index: int,
        plan: ParameterShiftPlanIR,
        shift_pairs: tuple[ShiftPairEvaluationIR, ...],
    ) -> GradientRepeatIR:
        """Build one repeat after verifying full plan coverage and ordering."""
        pairs = tuple(shift_pairs)
        expected_ids = tuple(item.occurrence_id for item in plan.occurrences)
        if tuple(pair.occurrence_id for pair in pairs) != expected_ids:
            raise ValueError(
                "gradient repeat shift_pairs must cover the plan in occurrence order."
            )
        for occurrence, pair in zip(plan.occurrences, pairs):
            if (
                pair.positive_circuit_hash != occurrence.positive_circuit_hash
                or pair.negative_circuit_hash != occurrence.negative_circuit_hash
                or not math.isclose(
                    pair.prefactor,
                    plan.prefactor,
                    rel_tol=0.0,
                    abs_tol=_TOLERANCE,
                )
            ):
                raise ValueError(
                    "gradient repeat shift_pairs must match the planned circuits "
                    "and prefactor."
                )
        return cls(
            repeat_index=repeat_index,
            plan_hash=plan.plan_hash,
            shift_pairs=pairs,
            objective_evaluation_count=sum(
                pair.objective_evaluation_count for pair in pairs
            ),
            backend_execution_count=sum(pair.backend_execution_count for pair in pairs),
            total_shots=sum(pair.total_shots for pair in pairs),
        )

    def compute_repeat_hash(self) -> str:
        """Hash the repeat without the embedded hash field."""
        payload = {
            "repeat_index": self.repeat_index,
            "plan_hash": self.plan_hash,
            "shift_pairs": self.shift_pairs,
            "objective_evaluation_count": self.objective_evaluation_count,
            "backend_execution_count": self.backend_execution_count,
            "total_shots": self.total_shots,
            "schema_version": self.schema_version,
        }
        return hashlib.sha256(stable_json(payload).encode("utf-8")).hexdigest()

    def verify_hash(self) -> bool:
        """Return whether the repeat hash matches all source evidence."""
        return self.repeat_hash == self.compute_repeat_hash()

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> GradientRepeatIR:
        """Restore one complete gradient repeat."""
        return cls(
            repeat_index=data["repeat_index"],
            plan_hash=data["plan_hash"],
            shift_pairs=tuple(
                ShiftPairEvaluationIR.from_dict(_mapping(item, "shift_pair"))
                for item in _sequence(data["shift_pairs"], "shift_pairs")
            ),
            objective_evaluation_count=data["objective_evaluation_count"],
            backend_execution_count=data["backend_execution_count"],
            total_shots=data["total_shots"],
            repeat_hash=data["repeat_hash"],
            schema_version=str(data.get("schema_version", GRADIENT_SCHEMA_VERSION)),
        )

    @classmethod
    def from_json(cls, text: str) -> GradientRepeatIR:
        """Restore one complete gradient repeat from JSON."""
        return cls.from_dict(_json_object(text, "GradientRepeatIR"))


@dataclass(frozen=True)
class PooledShiftPairIR(IRMixin):
    """One occurrence derivative pooled from complete independent repeats."""

    occurrence_id: str
    source_pair_hashes: tuple[str, ...]
    positive_energy: float
    positive_energy_standard_error: float
    negative_energy: float
    negative_energy_standard_error: float
    energy_difference: float
    prefactor: float
    gate_derivative: float
    gate_derivative_variance: float
    gate_derivative_standard_error: float
    repeat_count: int
    backend_execution_count: int
    total_shots: int
    schema_version: str = GRADIENT_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_text(self.occurrence_id, "occurrence_id")
        hashes = tuple(self.source_pair_hashes)
        if not hashes:
            raise ValueError("source_pair_hashes must not be empty.")
        for source_hash in hashes:
            _require_digest(source_hash, "source_pair_hash")
        if len(hashes) != len(set(hashes)):
            raise ValueError("source_pair_hashes must be unique.")
        if self.repeat_count != len(hashes):
            raise ValueError("repeat_count must match source_pair_hashes.")
        positive_energy = _finite_float(self.positive_energy, "positive_energy")
        negative_energy = _finite_float(self.negative_energy, "negative_energy")
        positive_error = _finite_non_negative_float(
            self.positive_energy_standard_error,
            "positive_energy_standard_error",
        )
        negative_error = _finite_non_negative_float(
            self.negative_energy_standard_error,
            "negative_energy_standard_error",
        )
        difference = positive_energy - negative_energy
        if not math.isclose(
            _finite_float(self.energy_difference, "energy_difference"),
            difference,
            rel_tol=0.0,
            abs_tol=_TOLERANCE,
        ):
            raise ValueError("energy_difference must match pooled shift energies.")
        prefactor = _finite_float(self.prefactor, "prefactor")
        derivative = prefactor * difference
        if not math.isclose(
            _finite_float(self.gate_derivative, "gate_derivative"),
            derivative,
            rel_tol=0.0,
            abs_tol=_TOLERANCE,
        ):
            raise ValueError("gate_derivative must match pooled energy difference.")
        variance = (
            prefactor
            * prefactor
            * (positive_error * positive_error + negative_error * negative_error)
        )
        if not math.isclose(
            _finite_non_negative_float(
                self.gate_derivative_variance,
                "gate_derivative_variance",
            ),
            variance,
            rel_tol=0.0,
            abs_tol=_TOLERANCE,
        ):
            raise ValueError("gate_derivative_variance must match pooled errors.")
        standard_error = math.sqrt(variance)
        if not math.isclose(
            _finite_non_negative_float(
                self.gate_derivative_standard_error,
                "gate_derivative_standard_error",
            ),
            standard_error,
            rel_tol=0.0,
            abs_tol=_TOLERANCE,
        ):
            raise ValueError(
                "gate_derivative_standard_error must match pooled variance."
            )
        _require_positive_int(self.repeat_count, "repeat_count")
        _require_positive_int(
            self.backend_execution_count,
            "backend_execution_count",
        )
        _require_non_negative_int(self.total_shots, "total_shots")
        object.__setattr__(self, "source_pair_hashes", hashes)
        object.__setattr__(self, "positive_energy", positive_energy)
        object.__setattr__(self, "negative_energy", negative_energy)
        object.__setattr__(self, "positive_energy_standard_error", positive_error)
        object.__setattr__(self, "negative_energy_standard_error", negative_error)
        object.__setattr__(self, "energy_difference", difference)
        object.__setattr__(self, "prefactor", prefactor)
        object.__setattr__(self, "gate_derivative", derivative)
        object.__setattr__(self, "gate_derivative_variance", variance)
        object.__setattr__(
            self,
            "gate_derivative_standard_error",
            standard_error,
        )

    @classmethod
    def create(
        cls,
        *,
        occurrence: ParameterShiftOccurrenceIR,
        source_pairs: tuple[ShiftPairEvaluationIR, ...],
    ) -> PooledShiftPairIR:
        """Pool one occurrence across repeats without discarding source evidence."""
        pairs = tuple(source_pairs)
        if not pairs or any(
            pair.occurrence_id != occurrence.occurrence_id for pair in pairs
        ):
            raise ValueError("source_pairs must cover one planned occurrence.")
        if any(pair.prefactor != pairs[0].prefactor for pair in pairs):
            raise ValueError("source_pairs must share one parameter-shift prefactor.")
        evaluations = tuple(
            evaluation
            for pair in pairs
            for evaluation in (pair.positive_evaluation, pair.negative_evaluation)
        )
        _require_matching_execution_context(evaluations)
        positive_energy, positive_error = _pool_shift_objectives(
            tuple(pair.positive_evaluation for pair in pairs)
        )
        negative_energy, negative_error = _pool_shift_objectives(
            tuple(pair.negative_evaluation for pair in pairs)
        )
        prefactor = pairs[0].prefactor
        difference = positive_energy - negative_energy
        variance = (
            prefactor
            * prefactor
            * (positive_error * positive_error + negative_error * negative_error)
        )
        return cls(
            occurrence_id=occurrence.occurrence_id,
            source_pair_hashes=tuple(pair.pair_hash for pair in pairs),
            positive_energy=positive_energy,
            positive_energy_standard_error=positive_error,
            negative_energy=negative_energy,
            negative_energy_standard_error=negative_error,
            energy_difference=difference,
            prefactor=prefactor,
            gate_derivative=prefactor * difference,
            gate_derivative_variance=variance,
            gate_derivative_standard_error=math.sqrt(variance),
            repeat_count=len(pairs),
            backend_execution_count=sum(pair.backend_execution_count for pair in pairs),
            total_shots=sum(pair.total_shots for pair in pairs),
        )

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> PooledShiftPairIR:
        """Restore pooled occurrence statistics."""
        return cls(
            occurrence_id=data["occurrence_id"],
            source_pair_hashes=tuple(
                _sequence(data["source_pair_hashes"], "source_pair_hashes")
            ),
            positive_energy=data["positive_energy"],
            positive_energy_standard_error=data["positive_energy_standard_error"],
            negative_energy=data["negative_energy"],
            negative_energy_standard_error=data["negative_energy_standard_error"],
            energy_difference=data["energy_difference"],
            prefactor=data["prefactor"],
            gate_derivative=data["gate_derivative"],
            gate_derivative_variance=data["gate_derivative_variance"],
            gate_derivative_standard_error=data["gate_derivative_standard_error"],
            repeat_count=data["repeat_count"],
            backend_execution_count=data["backend_execution_count"],
            total_shots=data["total_shots"],
            schema_version=str(data.get("schema_version", GRADIENT_SCHEMA_VERSION)),
        )

    @classmethod
    def from_json(cls, text: str) -> PooledShiftPairIR:
        """Restore pooled occurrence statistics from JSON."""
        return cls.from_dict(_json_object(text, "PooledShiftPairIR"))


def _pool_shift_objectives(
    evaluations: tuple[GradientObjectiveEvaluationIR, ...],
) -> tuple[float, float]:
    """Pool one shifted Circuit at QWC-group level across independent repeats.

    每个 sampled evaluation 可能已经包含 pilot 和 additional 两个 stage。
    evaluation 会先在内部合并这两个 stage；这里再按 QWC group 合并所有
    repeat 的 raw counts，并从合并结果重算 raw 或 mitigated 统计。这样既
    保留组内 Pauli 项协方差，也不会把不同 QWC group 当成同一随机变量。
    """
    if not evaluations:
        raise ValueError("shift objective evaluations must not be empty.")
    _require_matching_execution_context(evaluations)
    exact = all(isinstance(item, ObjectiveEvaluationIR) for item in evaluations)
    sampled = all(
        isinstance(item, SampledObjectiveEvaluationIR) for item in evaluations
    )
    if exact:
        if len(evaluations) != 1:
            raise ValueError("exact gradients do not support repeated objectives.")
        return evaluations[0].energy, 0.0
    if not sampled:
        raise TypeError("pooled shift objectives cannot mix estimator types.")

    sampled_evaluations = cast(
        tuple[SampledObjectiveEvaluationIR, ...],
        evaluations,
    )
    first = sampled_evaluations[0]
    group_count = len(first.plan.groups)
    if any(len(item.plan.groups) != group_count for item in sampled_evaluations):
        raise ValueError("sampled gradient repeats must share QWC group count.")
    if any(
        not math.isclose(
            item.plan.constant,
            first.plan.constant,
            rel_tol=0.0,
            abs_tol=_TOLERANCE,
        )
        for item in sampled_evaluations[1:]
    ):
        raise ValueError("sampled gradient repeats must share Hamiltonian constant.")

    mitigation = first.plan.config.mitigation
    group_estimates: list[tuple[float, float]] = []
    for group_index in range(group_count):
        group = first.plan.groups[group_index]
        pooled_counts: dict[str, int] = {}
        pooled_shots = 0
        for evaluation in sampled_evaluations:
            if evaluation.plan.config.mitigation != mitigation:
                raise ValueError(
                    "sampled gradient repeats must share readout mitigation."
                )
            if evaluation.plan.groups[group_index] != group:
                raise ValueError(
                    "sampled gradient repeats must share QWC groups and bases."
                )
            raw_estimate = evaluation.pooled_group_statistics[group_index]
            pooled_shots += raw_estimate.shots
            for bitstring, count in raw_estimate.counts.items():
                pooled_counts[bitstring] = pooled_counts.get(bitstring, 0) + count
        if mitigation is None:
            _, _, mean, standard_error = _group_statistics(
                group,
                pooled_counts,
                shots=pooled_shots,
            )
        else:
            mitigated_estimate = compute_readout_mitigated_group_statistics(
                group,
                pooled_counts,
                shots=pooled_shots,
                config=mitigation,
            )
            mean = mitigated_estimate.energy_mean
            standard_error = mitigated_estimate.energy_standard_error
        group_estimates.append((mean, standard_error))
    return (
        first.plan.constant + math.fsum(item[0] for item in group_estimates),
        math.sqrt(math.fsum(item[1] * item[1] for item in group_estimates)),
    )


@dataclass(frozen=True)
class ObjectiveGradientIR(IRMixin):
    """Self-contained gradient reconstructed from complete repeated evidence."""

    gradient_id: str
    gradient_index: int
    config: GradientConfig
    plan: ParameterShiftPlanIR
    plan_hash: str
    parameter_bind: ParameterBindIR
    repeats: tuple[GradientRepeatIR, ...]
    pooled_shift_pairs: tuple[PooledShiftPairIR, ...]
    repeat_count: int
    repeat_stop_reason: Literal[
        "fixed_repeats",
        "target_reached",
        "max_repeats_reached",
        "evaluation_budget_exhausted",
        "backend_budget_exhausted",
    ]
    backend_execution_limit: int | None
    parameter_contributions: Mapping[str, Mapping[str, float]]
    gradient: Mapping[str, float]
    gradient_covariance: Mapping[str, Mapping[str, float]]
    gradient_standard_errors: Mapping[str, float]
    uncertainty_norm: float
    l2_norm: float
    objective_evaluation_count: int
    backend_execution_count: int
    total_shots: int
    gradient_hash: str = ""
    metadata: Mapping[str, Any] = field(default_factory=dict)
    schema_version: str = GRADIENT_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_text(self.gradient_id, "gradient_id")
        _require_non_negative_int(self.gradient_index, "gradient_index")
        if not isinstance(self.config, GradientConfig):
            raise TypeError("config must be GradientConfig.")
        if (
            not isinstance(self.plan, ParameterShiftPlanIR)
            or not self.plan.verify_hash()
        ):
            raise ValueError("plan must be a verified ParameterShiftPlanIR.")
        if self.plan_hash != self.plan.plan_hash:
            raise ValueError("plan_hash must match the embedded gradient plan.")
        if (
            not isinstance(self.parameter_bind, ParameterBindIR)
            or not self.parameter_bind.verify_hash()
        ):
            raise ValueError("parameter_bind must contain a verified hash.")
        if set(self.parameter_bind.values) != set(self.plan.parameter_names):
            raise ValueError("parameter_bind values must match plan parameter_names.")
        repeats = tuple(self.repeats)
        if not repeats or any(
            not isinstance(repeat, GradientRepeatIR) for repeat in repeats
        ):
            raise TypeError("repeats must contain complete GradientRepeatIR values.")
        if tuple(repeat.repeat_index for repeat in repeats) != tuple(
            range(len(repeats))
        ):
            raise ValueError(
                "gradient repeat indices must be contiguous and zero-based."
            )
        if any(repeat.plan_hash != self.plan_hash for repeat in repeats):
            raise ValueError("gradient repeats must reference the embedded plan.")
        expected_occurrence_ids = tuple(
            occurrence.occurrence_id for occurrence in self.plan.occurrences
        )
        for repeat in repeats:
            if tuple(pair.occurrence_id for pair in repeat.shift_pairs) != (
                expected_occurrence_ids
            ):
                raise ValueError(
                    "every gradient repeat must cover the plan in occurrence order."
                )
            for occurrence, pair in zip(self.plan.occurrences, repeat.shift_pairs):
                if (
                    pair.positive_circuit_hash != occurrence.positive_circuit_hash
                    or pair.negative_circuit_hash != occurrence.negative_circuit_hash
                    or pair.prefactor != self.plan.prefactor
                ):
                    raise ValueError("gradient repeat shift pairs must match the plan.")

        # 恢复时跨全部 repeat 校验物理和估计上下文，防止只替换某次 repeat 的
        # NoiseModel、options、measurement config 或 readout calibration。
        _require_matching_execution_context(
            tuple(
                evaluation
                for repeat in repeats
                for pair in repeat.shift_pairs
                for evaluation in (pair.positive_evaluation, pair.negative_evaluation)
            )
        )
        for repeat in repeats:
            for pair in repeat.shift_pairs:
                for evaluation in (
                    pair.positive_evaluation,
                    pair.negative_evaluation,
                ):
                    if (
                        _evaluation_hamiltonian_hash(evaluation)
                        != self.plan.hamiltonian_hash
                    ):
                        raise ValueError(
                            "shift evaluation Hamiltonian hash must match plan."
                        )
                    if (
                        evaluation.parameter_bind.parameter_schema_hash
                        != self.parameter_bind.parameter_schema_hash
                    ):
                        raise ValueError(
                            "shift evaluation parameter schema must match "
                            "gradient bind."
                        )
                    if dict(evaluation.parameter_bind.values) != dict(
                        self.parameter_bind.values
                    ):
                        raise ValueError(
                            "shift evaluation parameter values must match "
                            "gradient bind."
                        )

        pooled_pairs = tuple(self.pooled_shift_pairs)
        expected_pooled_pairs = _pool_gradient_repeats(self.plan, repeats)
        if pooled_pairs != expected_pooled_pairs:
            raise ValueError(
                "pooled_shift_pairs must be reconstructed from all gradient repeats."
            )
        if self.repeat_count != len(repeats):
            raise ValueError("repeat_count must match repeats.")
        backend_limit = self.backend_execution_limit
        if backend_limit is not None:
            _require_positive_int(backend_limit, "backend_execution_limit")
        _validate_gradient_repeat_stop(
            self.config,
            repeat_count=len(repeats),
            stop_reason=self.repeat_stop_reason,
            uncertainty_norm=self.uncertainty_norm,
            objectives_per_repeat=self.plan.expected_objective_evaluation_count,
            backend_execution_limit=backend_limit,
            backend_executions_per_repeat=repeats[0].backend_execution_count,
        )
        (
            expected_contributions,
            expected_gradient,
            expected_covariance,
            expected_standard_errors,
        ) = _derive_parameter_gradient_statistics(self.plan, pooled_pairs)
        contributions = _nested_finite_mapping(
            self.parameter_contributions,
            "parameter_contributions",
        )
        _require_nested_close(contributions, expected_contributions)
        gradient = _finite_mapping(self.gradient, "gradient")
        _require_mapping_close(gradient, expected_gradient, "gradient")
        covariance = _nested_finite_mapping(
            self.gradient_covariance,
            "gradient_covariance",
        )
        _require_nested_close(covariance, expected_covariance)
        standard_errors = _finite_mapping(
            self.gradient_standard_errors,
            "gradient_standard_errors",
        )
        if any(value < 0.0 for value in standard_errors.values()):
            raise ValueError("gradient_standard_errors must be non-negative.")
        _require_mapping_close(
            standard_errors,
            expected_standard_errors,
            "gradient_standard_errors",
        )
        expected_uncertainty_norm = math.sqrt(
            math.fsum(
                expected_covariance[name][name] for name in self.plan.parameter_names
            )
        )
        if not math.isclose(
            _finite_non_negative_float(self.uncertainty_norm, "uncertainty_norm"),
            expected_uncertainty_norm,
            rel_tol=0.0,
            abs_tol=_TOLERANCE,
        ):
            raise ValueError("uncertainty_norm must equal sqrt(trace(covariance)).")
        norm = math.sqrt(sum(value * value for value in expected_gradient.values()))
        if not math.isclose(
            _finite_float(self.l2_norm, "l2_norm"),
            norm,
            rel_tol=0.0,
            abs_tol=_TOLERANCE,
        ):
            raise ValueError("l2_norm must match reconstructed gradient components.")
        expected_objective_count = sum(
            repeat.objective_evaluation_count for repeat in repeats
        )
        if self.objective_evaluation_count != expected_objective_count:
            raise ValueError("objective_evaluation_count must match gradient repeats.")
        expected_backend_count = sum(
            repeat.backend_execution_count for repeat in repeats
        )
        if self.backend_execution_count != expected_backend_count:
            raise ValueError("backend_execution_count must match gradient repeats.")
        expected_shots = sum(repeat.total_shots for repeat in repeats)
        if self.total_shots != expected_shots:
            raise ValueError("total_shots must match gradient repeats.")
        object.__setattr__(self, "repeats", repeats)
        object.__setattr__(self, "pooled_shift_pairs", pooled_pairs)
        object.__setattr__(self, "parameter_contributions", contributions)
        object.__setattr__(self, "gradient", gradient)
        object.__setattr__(self, "gradient_covariance", covariance)
        object.__setattr__(self, "gradient_standard_errors", standard_errors)
        object.__setattr__(self, "uncertainty_norm", expected_uncertainty_norm)
        object.__setattr__(self, "l2_norm", norm)
        object.__setattr__(self, "backend_execution_limit", backend_limit)
        object.__setattr__(self, "metadata", _freeze_mapping(self.metadata))
        if not self.gradient_hash:
            object.__setattr__(self, "gradient_hash", self.compute_gradient_hash())
        else:
            _require_digest(self.gradient_hash, "gradient_hash")
            if not self.verify_hash():
                raise ValueError("gradient_hash does not match gradient result facts.")

    @classmethod
    def create(
        cls,
        *,
        gradient_id: str,
        gradient_index: int,
        config: GradientConfig,
        plan: ParameterShiftPlanIR,
        parameter_bind: ParameterBindIR,
        repeats: tuple[GradientRepeatIR, ...],
        repeat_stop_reason: Literal[
            "fixed_repeats",
            "target_reached",
            "max_repeats_reached",
            "evaluation_budget_exhausted",
            "backend_budget_exhausted",
        ],
        backend_execution_limit: int | None = None,
        metadata: Mapping[str, Any] | None = None,
    ) -> ObjectiveGradientIR:
        """Derive pooled statistics, complete costs, and result hash."""
        repeated = tuple(repeats)
        pooled_pairs = _pool_gradient_repeats(plan, repeated)
        contributions, gradient, covariance, standard_errors = (
            _derive_parameter_gradient_statistics(plan, pooled_pairs)
        )
        uncertainty_norm = math.sqrt(
            math.fsum(covariance[name][name] for name in plan.parameter_names)
        )
        return cls(
            gradient_id=gradient_id,
            gradient_index=gradient_index,
            config=config,
            plan=plan,
            plan_hash=plan.plan_hash,
            parameter_bind=parameter_bind,
            repeats=repeated,
            pooled_shift_pairs=pooled_pairs,
            repeat_count=len(repeated),
            repeat_stop_reason=repeat_stop_reason,
            backend_execution_limit=backend_execution_limit,
            parameter_contributions=contributions,
            gradient=gradient,
            gradient_covariance=covariance,
            gradient_standard_errors=standard_errors,
            uncertainty_norm=uncertainty_norm,
            l2_norm=math.sqrt(sum(value * value for value in gradient.values())),
            objective_evaluation_count=sum(
                repeat.objective_evaluation_count for repeat in repeated
            ),
            backend_execution_count=sum(
                repeat.backend_execution_count for repeat in repeated
            ),
            total_shots=sum(repeat.total_shots for repeat in repeated),
            metadata={} if metadata is None else metadata,
        )

    def compute_gradient_hash(self) -> str:
        """Hash all saved gradient evidence except the embedded hash itself."""
        return hashlib.sha256(
            stable_json(self._hash_payload()).encode("utf-8")
        ).hexdigest()

    def verify_hash(self) -> bool:
        """Return whether the embedded gradient hash matches saved evidence."""
        return self.gradient_hash == self.compute_gradient_hash()

    def _hash_payload(self) -> dict[str, Any]:
        return {
            "gradient_id": self.gradient_id,
            "gradient_index": self.gradient_index,
            "config": self.config,
            "plan": self.plan,
            "plan_hash": self.plan_hash,
            "parameter_bind": self.parameter_bind,
            "repeats": self.repeats,
            "pooled_shift_pairs": self.pooled_shift_pairs,
            "repeat_count": self.repeat_count,
            "repeat_stop_reason": self.repeat_stop_reason,
            "backend_execution_limit": self.backend_execution_limit,
            "parameter_contributions": self.parameter_contributions,
            "gradient": self.gradient,
            "gradient_covariance": self.gradient_covariance,
            "gradient_standard_errors": self.gradient_standard_errors,
            "uncertainty_norm": self.uncertainty_norm,
            "l2_norm": self.l2_norm,
            "objective_evaluation_count": self.objective_evaluation_count,
            "backend_execution_count": self.backend_execution_count,
            "total_shots": self.total_shots,
            "metadata": self.metadata,
            "schema_version": self.schema_version,
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ObjectiveGradientIR:
        """Restore and fully recompute a repeated gradient result."""
        return cls(
            gradient_id=data["gradient_id"],
            gradient_index=data["gradient_index"],
            config=GradientConfig.from_dict(_mapping(data["config"], "config")),
            plan=ParameterShiftPlanIR.from_dict(_mapping(data["plan"], "plan")),
            plan_hash=data["plan_hash"],
            parameter_bind=ParameterBindIR.from_dict(
                _mapping(data["parameter_bind"], "parameter_bind")
            ),
            repeats=tuple(
                GradientRepeatIR.from_dict(_mapping(item, "repeat"))
                for item in _sequence(data["repeats"], "repeats")
            ),
            pooled_shift_pairs=tuple(
                PooledShiftPairIR.from_dict(_mapping(item, "pooled_shift_pair"))
                for item in _sequence(
                    data["pooled_shift_pairs"],
                    "pooled_shift_pairs",
                )
            ),
            repeat_count=data["repeat_count"],
            repeat_stop_reason=data["repeat_stop_reason"],
            backend_execution_limit=data.get("backend_execution_limit"),
            parameter_contributions=_mapping(
                data["parameter_contributions"],
                "parameter_contributions",
            ),
            gradient=_mapping(data["gradient"], "gradient"),
            gradient_covariance=_mapping(
                data["gradient_covariance"],
                "gradient_covariance",
            ),
            gradient_standard_errors=_mapping(
                data["gradient_standard_errors"],
                "gradient_standard_errors",
            ),
            uncertainty_norm=data["uncertainty_norm"],
            l2_norm=data["l2_norm"],
            objective_evaluation_count=data["objective_evaluation_count"],
            backend_execution_count=data["backend_execution_count"],
            total_shots=data["total_shots"],
            gradient_hash=data["gradient_hash"],
            metadata=_mapping(data.get("metadata", {}), "metadata"),
            schema_version=str(data.get("schema_version", GRADIENT_SCHEMA_VERSION)),
        )

    @classmethod
    def from_json(cls, text: str) -> ObjectiveGradientIR:
        """Restore and fully recompute a gradient result from JSON."""
        return cls.from_dict(_json_object(text, "ObjectiveGradientIR"))


def _pool_gradient_repeats(
    plan: ParameterShiftPlanIR,
    repeats: tuple[GradientRepeatIR, ...],
) -> tuple[PooledShiftPairIR, ...]:
    """Pool every planned occurrence across complete repeats."""
    if not repeats:
        raise ValueError("gradient repeats must not be empty.")
    return tuple(
        PooledShiftPairIR.create(
            occurrence=occurrence,
            source_pairs=tuple(
                repeat.shift_pairs[occurrence_index] for repeat in repeats
            ),
        )
        for occurrence_index, occurrence in enumerate(plan.occurrences)
    )


def _validate_gradient_repeat_stop(
    config: GradientConfig,
    *,
    repeat_count: int,
    stop_reason: str,
    uncertainty_norm: float,
    objectives_per_repeat: int,
    backend_execution_limit: int | None,
    backend_executions_per_repeat: int,
) -> None:
    """Recompute whether repeat count, target, budget, and stop reason agree."""
    if repeat_count < config.repeats or repeat_count > config.effective_max_repeats:
        raise ValueError("repeat_count is outside the configured repeat bounds.")
    if (
        backend_execution_limit is not None
        and repeat_count * backend_executions_per_repeat > backend_execution_limit
    ):
        raise ValueError("gradient repeats exceed backend_execution_limit.")
    if config.repeat_mode == "fixed":
        if repeat_count != config.repeats or stop_reason != "fixed_repeats":
            raise ValueError("fixed repeat mode must complete the configured repeats.")
        return
    assert config.max_repeats is not None
    assert config.uncertainty_norm_target is not None
    target_reached = uncertainty_norm <= config.uncertainty_norm_target
    if stop_reason == "target_reached":
        if not target_reached:
            raise ValueError("target_reached requires uncertainty at or below target.")
        return
    if target_reached:
        raise ValueError("adaptive repeats must stop when the target is reached.")
    if stop_reason == "max_repeats_reached":
        if repeat_count != config.max_repeats:
            raise ValueError("max_repeats_reached requires the configured maximum.")
        return
    if stop_reason == "evaluation_budget_exhausted":
        if config.max_objective_evaluations is None:
            raise ValueError(
                "evaluation budget stop requires max_objective_evaluations."
            )
        remaining = (
            config.max_objective_evaluations
            - repeat_count * objectives_per_repeat
        )
        if remaining < 0 or remaining >= objectives_per_repeat:
            raise ValueError(
                "evaluation budget stop requires no room for another full repeat."
            )
        return
    if stop_reason != "backend_budget_exhausted":
        raise ValueError("unsupported gradient repeat stop reason.")
    if backend_execution_limit is None:
        raise ValueError("backend budget stop requires backend_execution_limit.")
    remaining_backend = (
        backend_execution_limit - repeat_count * backend_executions_per_repeat
    )
    if remaining_backend < 0 or remaining_backend >= backend_executions_per_repeat:
        raise ValueError(
            "backend budget stop requires no room for another full repeat."
        )


def _derive_parameter_gradient_statistics(
    plan: ParameterShiftPlanIR,
    shift_pairs: tuple[ShiftPairEvaluationIR | PooledShiftPairIR, ...],
) -> tuple[
    dict[str, dict[str, float]],
    dict[str, float],
    dict[str, dict[str, float]],
    dict[str, float],
]:
    """Propagate independent occurrence derivatives into parameter statistics.

    一个 gate occurrence 可以由多个外部参数的仿射表达式共同控制，因此同一
    occurrence 的随机导数会同时进入多个参数分量。这里保留完整协方差，而不是
    只计算各分量误差后丢失非对角项。
    """
    if len(shift_pairs) != len(plan.occurrences):
        raise ValueError("shift_pairs must cover every planned occurrence.")
    if tuple(pair.occurrence_id for pair in shift_pairs) != tuple(
        occurrence.occurrence_id for occurrence in plan.occurrences
    ):
        raise ValueError("shift_pairs must follow the planned occurrence order.")

    contributions: dict[str, dict[str, float]] = {
        name: {} for name in plan.parameter_names
    }
    for occurrence, pair in zip(plan.occurrences, shift_pairs):
        for name, coefficient in occurrence.coefficients.items():
            contributions[name][occurrence.occurrence_id] = (
                coefficient * pair.gate_derivative
            )
    gradient = {
        name: math.fsum(contributions[name].values()) for name in plan.parameter_names
    }

    covariance = _derive_parameter_gradient_covariance(
        plan,
        {pair.occurrence_id: pair.gate_derivative_variance for pair in shift_pairs},
    )
    standard_errors = {
        name: math.sqrt(max(0.0, covariance[name][name]))
        for name in plan.parameter_names
    }
    return contributions, gradient, covariance, standard_errors


def _derive_parameter_gradient_covariance(
    plan: ParameterShiftPlanIR,
    occurrence_variances: Mapping[str, float],
) -> dict[str, dict[str, float]]:
    """Apply the affine chain rule to independent occurrence variances."""
    expected_ids = tuple(item.occurrence_id for item in plan.occurrences)
    if set(occurrence_variances) != set(expected_ids):
        raise ValueError("occurrence_variances must cover the gradient plan.")
    variances = {
        occurrence_id: _finite_non_negative_float(
            occurrence_variances[occurrence_id],
            f"occurrence_variances[{occurrence_id}]",
        )
        for occurrence_id in expected_ids
    }
    covariance: dict[str, dict[str, float]] = {}
    for row_name in plan.parameter_names:
        row: dict[str, float] = {}
        for column_name in plan.parameter_names:
            row[column_name] = math.fsum(
                occurrence.coefficients.get(row_name, 0.0)
                * occurrence.coefficients.get(column_name, 0.0)
                * variances[occurrence.occurrence_id]
                for occurrence in plan.occurrences
            )
        covariance[row_name] = row
    return covariance


def _shift_pair_variance(
    positive: GradientObjectiveEvaluationIR,
    negative: GradientObjectiveEvaluationIR,
    *,
    prefactor: float,
) -> float:
    """Return independent positive/negative objective variance.

    正负 shift 分别提交独立 Backend Job，因此不引入共同随机数协方差。
    exact estimator 的标准误为零；sampled estimator 使用当前 active
    raw/mitigated energy 的标准误。
    """
    if not isinstance(
        positive,
        (ObjectiveEvaluationIR, SampledObjectiveEvaluationIR),
    ) or not isinstance(
        negative,
        (ObjectiveEvaluationIR, SampledObjectiveEvaluationIR),
    ):
        raise TypeError("shift pair evaluations must be exact or sampled objective IR.")
    positive_error = _evaluation_energy_standard_error(positive)
    negative_error = _evaluation_energy_standard_error(negative)
    return (
        prefactor
        * prefactor
        * (positive_error * positive_error + negative_error * negative_error)
    )


def _evaluation_backend_execution_count(
    evaluation: GradientObjectiveEvaluationIR,
) -> int:
    """Return the physical Backend Job count of one objective evaluation."""
    if isinstance(evaluation, ObjectiveEvaluationIR):
        return 1
    if isinstance(evaluation, SampledObjectiveEvaluationIR):
        return evaluation.backend_execution_count
    raise TypeError("gradient evaluation must be exact or sampled objective IR.")


def _evaluation_total_shots(evaluation: GradientObjectiveEvaluationIR) -> int:
    """Return finite measurement shots while keeping exact objectives at zero."""
    if isinstance(evaluation, ObjectiveEvaluationIR):
        return 0
    if isinstance(evaluation, SampledObjectiveEvaluationIR):
        return evaluation.total_shots
    raise TypeError("gradient evaluation must be exact or sampled objective IR.")


def _gradient_objective_evaluation_from_dict(
    data: Mapping[str, Any],
) -> GradientObjectiveEvaluationIR:
    """Restore the exact/sampled discriminated union without a compatibility tag.

    两种 IR 已有互斥的必需字段。这里拒绝模糊 payload，而不是用缺省值猜测
    类型，避免被篡改的 sampled 证据退化成 exact 证据。
    """
    exact_shape = {"hamiltonian_hash", "observable_batch", "execution_evidence"}
    sampled_shape = {"plan", "group_results", "energy_standard_error"}
    is_exact = exact_shape.issubset(data)
    is_sampled = sampled_shape.issubset(data)
    if is_exact == is_sampled:
        raise ValueError(
            "shift evaluation must contain one unambiguous exact or sampled IR."
        )
    if is_exact:
        return ObjectiveEvaluationIR.from_dict(data)
    return SampledObjectiveEvaluationIR.from_dict(data)


def _evaluation_hamiltonian_hash(
    evaluation: GradientObjectiveEvaluationIR,
) -> str:
    if isinstance(evaluation, ObjectiveEvaluationIR):
        return evaluation.hamiltonian_hash
    if isinstance(evaluation, SampledObjectiveEvaluationIR):
        return evaluation.plan.hamiltonian_hash
    raise TypeError("gradient evaluation must be exact or sampled objective IR.")


def _evaluation_energy_standard_error(
    evaluation: GradientObjectiveEvaluationIR,
) -> float:
    """Return the active estimator error used by parameter-shift propagation."""
    if isinstance(evaluation, ObjectiveEvaluationIR):
        # exact-state 和 exact-density 都是确定性 Observable，不把 Backend 为
        # 生命周期记录的 shots 误当成测量抽样误差。
        return 0.0
    if isinstance(evaluation, SampledObjectiveEvaluationIR):
        return evaluation.energy_standard_error
    raise TypeError("gradient evaluation must be exact or sampled objective IR.")


def _evaluation_estimator(evaluation: GradientObjectiveEvaluationIR) -> str:
    if isinstance(evaluation, ObjectiveEvaluationIR):
        return evaluation.execution_evidence.estimator_kind.value
    if isinstance(evaluation, SampledObjectiveEvaluationIR):
        return evaluation.estimator_kind
    raise TypeError("gradient evaluation must be exact or sampled objective IR.")


def _evaluation_simulation_method(
    evaluation: GradientObjectiveEvaluationIR,
) -> str:
    if isinstance(evaluation, ObjectiveEvaluationIR):
        return evaluation.execution_evidence.simulation_plan.method_selected
    if isinstance(evaluation, SampledObjectiveEvaluationIR):
        return evaluation.simulation_method
    raise TypeError("gradient evaluation must be exact or sampled objective IR.")


def build_parameter_shift_plan(
    circuit: Circuit,
    hamiltonian: PauliHamiltonian,
    *,
    config: GradientConfig | None = None,
) -> ParameterShiftPlanIR:
    """Validate every parameter occurrence and build a Backend-free plan."""
    if not isinstance(circuit, Circuit):
        raise TypeError("circuit must be Circuit.")
    if not isinstance(hamiltonian, PauliHamiltonian):
        raise TypeError("hamiltonian must be PauliHamiltonian.")
    selected_config = GradientConfig() if config is None else config
    if not isinstance(selected_config, GradientConfig):
        raise TypeError("config must be GradientConfig or None.")
    if circuit.qubits != hamiltonian.logical_order:
        _raise_capability(
            "Circuit qubits must match Hamiltonian logical_order.",
            code="GRADIENT_LOGICAL_ORDER_MISMATCH",
            metadata={
                "circuit_qubits": list(circuit.qubits),
                "hamiltonian_logical_order": list(hamiltonian.logical_order),
            },
        )
    parameter_names = tuple(parameter.name for parameter in circuit.parameters)
    if not parameter_names:
        _raise_capability(
            "Gradient planning requires at least one Circuit parameter.",
            code="GRADIENT_PARAMETER_EMPTY",
        )

    planned: list[ParameterShiftOccurrenceIR] = []
    for occurrence in circuit.parameter_occurrences():
        dependencies = _occurrence_dependencies(occurrence)
        if not set(dependencies).intersection(parameter_names):
            continue
        if not occurrence.supported or occurrence.affine_form is None:
            _raise_capability(
                "Circuit contains a parameter occurrence unsupported by gradients.",
                code="GRADIENT_OCCURRENCE_UNSUPPORTED",
                metadata={
                    "occurrence_id": occurrence.occurrence_id,
                    "gate_name": occurrence.gate_name,
                    "parameter_name": occurrence.parameter_name,
                    "unsupported_reason": occurrence.unsupported_reason,
                },
            )
        form = occurrence.affine_form
        assert form is not None
        positive = circuit.shift_parameter_occurrence(
            occurrence.occurrence_id,
            selected_config.shift,
        )
        negative = circuit.shift_parameter_occurrence(
            occurrence.occurrence_id,
            -selected_config.shift,
        )
        planned.append(
            ParameterShiftOccurrenceIR(
                occurrence_id=occurrence.occurrence_id,
                gate_index=occurrence.gate_index,
                gate_id=occurrence.gate_id,
                gate_name=cast(
                    Literal["rx", "ry", "rz"],
                    occurrence.gate_name,
                ),
                targets=occurrence.targets,
                parameter_name="theta",
                affine_offset=form.offset,
                coefficients=form.coefficients,
                positive_circuit_hash=positive.structural_hash(),
                negative_circuit_hash=negative.structural_hash(),
            )
        )
    covered = {name for item in planned for name in item.coefficients}
    missing = tuple(name for name in parameter_names if name not in covered)
    if missing:
        _raise_capability(
            "Every Circuit parameter must affect a supported gradient occurrence.",
            code="GRADIENT_PARAMETER_UNUSED",
            metadata={"parameter_names": list(missing)},
        )
    return ParameterShiftPlanIR(
        source_circuit_hash=circuit.structural_hash(),
        hamiltonian_hash=hamiltonian.stable_hash(),
        logical_order=hamiltonian.logical_order,
        parameter_names=parameter_names,
        occurrences=tuple(planned),
        shift=selected_config.shift,
        prefactor=selected_config.prefactor,
        expected_objective_evaluation_count=2 * len(planned),
    )


def _preflight_sampled_shifted_circuits(
    *,
    shifted_circuits: tuple[tuple[Circuit, Circuit], ...],
    evaluation_indices: tuple[int, ...],
    parameter_names: tuple[str, ...],
    values: Mapping[str, float],
    hamiltonian: PauliHamiltonian,
    measurement: PauliMeasurementConfig,
    backend: LocalBackend,
    seed: int | None,
    noise: NoiseModel | None,
    options: SimulationOptions | None,
    gradient_run_id: str,
) -> None:
    """Preflight every sampled shift and QWC stage before the first Job.

    `execute_sampled_objective_evaluation` 仍会在单次 objective 内再次预检，
    这里负责更高一层的梯度原子性：后面的 negative shift、pilot second stage
    或不同 basis group 若不受支持，整个梯度在零 Job 状态失败。
    """
    flattened = tuple(circuit for pair in shifted_circuits for circuit in pair)
    if len(flattened) != len(evaluation_indices):
        raise ValueError("sampled gradient preflight indices do not match shifts.")
    selected_seed = (
        seed
        if seed is not None
        else (
            backend.seed
            if backend.seed is not None
            else (None if options is None else options.seed)
        )
    )
    root_seed = 0 if selected_seed is None else selected_seed

    for circuit, evaluation_index in zip(flattened, evaluation_indices):
        declared_names = tuple(parameter.name for parameter in circuit.parameters)
        if declared_names != parameter_names:
            raise ValueError(
                "shifted Circuit parameter order must match the ansatz declaration."
            )
        plan = build_pauli_measurement_plan(
            circuit,
            hamiltonian,
            config=measurement,
        )
        bound = circuit.bind(values)
        group_circuits = tuple(
            build_group_measurement_circuit(
                bound,
                group,
                plan=plan,
                program_id=(
                    f"program.{gradient_run_id}.sampled.{evaluation_index:06d}."
                    f"group.{group.group_index:03d}"
                ),
            )
            for group in plan.groups
        )
        group_seeds = tuple(
            derive_measurement_group_seed(
                root_seed,
                evaluation_index=evaluation_index,
                group_index=group.group_index,
            )
            for group in plan.groups
        )
        for measured, group_seed in zip(group_circuits, group_seeds):
            validate_sampled_variational_request(
                measured,
                noise=noise,
                options=options,
                backend=backend,
                seed=group_seed,
            )

        if measurement.allocation != "pilot_variance":
            continue
        # pilot-variance 会为每个 group 提交第二个独立 Job。尽管测量 basis
        # 相同，仍按其真实 program identity 和 seed 完整预检第二阶段。
        additional_circuits = tuple(
            build_group_measurement_circuit(
                bound,
                group,
                plan=plan,
                program_id=(
                    f"program.{gradient_run_id}.sampled.{evaluation_index:06d}."
                    f"adaptive-group.{group.group_index:03d}"
                ),
            )
            for group in plan.groups
        )
        additional_seeds = tuple(
            derive_adaptive_measurement_group_seed(
                root_seed,
                evaluation_index=evaluation_index,
                group_index=group.group_index,
            )
            for group in plan.groups
        )
        for measured, group_seed in zip(additional_circuits, additional_seeds):
            validate_sampled_variational_request(
                measured,
                noise=noise,
                options=options,
                backend=backend,
                seed=group_seed,
            )


def execute_parameter_shift_gradient(
    *,
    algorithm_kind: Literal["qaoa", "vqe"],
    algorithm_id: str,
    algorithm_run_id: str | None,
    gradient_index: int,
    circuit: Circuit,
    parameter_names: tuple[str, ...],
    parameters: ParameterValues,
    hamiltonian: PauliHamiltonian,
    backend: LocalBackend | None,
    seed: int | None,
    config: GradientConfig | None = None,
    measurement: PauliMeasurementConfig | None = None,
    noise: NoiseModel | None = None,
    options: SimulationOptions | None = None,
    objective_evaluation_offset: int = 0,
    max_backend_executions: int | None = None,
) -> ObjectiveGradientIR:
    """执行一次 exact 或 finite-shot occurrence-level 参数移位梯度。"""
    if algorithm_kind not in {"qaoa", "vqe"}:
        raise ValueError("algorithm_kind must be qaoa or vqe.")
    _require_text(algorithm_id, "algorithm_id")
    _require_non_negative_int(gradient_index, "gradient_index")
    run_id = algorithm_id if algorithm_run_id is None else algorithm_run_id
    _require_text(run_id, "algorithm_run_id")
    if backend is not None and not isinstance(backend, LocalBackend):
        raise TypeError("backend must be LocalBackend or None.")
    if not isinstance(circuit, Circuit):
        raise TypeError("circuit must be Circuit.")
    if not isinstance(hamiltonian, PauliHamiltonian):
        raise TypeError("hamiltonian must be PauliHamiltonian.")
    if not isinstance(parameter_names, tuple) or any(
        not isinstance(name, str) for name in parameter_names
    ):
        raise TypeError("parameter_names must be a tuple of strings.")
    if measurement is not None and not isinstance(
        measurement,
        PauliMeasurementConfig,
    ):
        raise TypeError("measurement must be PauliMeasurementConfig or None.")
    if measurement is not None and algorithm_kind != "vqe":
        raise ValueError("finite-shot parameter-shift gradient requires VQE.")

    declared_names = tuple(parameter.name for parameter in circuit.parameters)
    if declared_names != parameter_names:
        raise ValueError("Circuit parameter order must match the ansatz declaration.")
    values = normalize_parameter_values(parameters, parameter_names)
    selected_config = GradientConfig() if config is None else config
    if not isinstance(selected_config, GradientConfig):
        raise TypeError("config must be GradientConfig or None.")
    _require_non_negative_int(
        objective_evaluation_offset,
        "objective_evaluation_offset",
    )
    if max_backend_executions is not None:
        _require_positive_int(max_backend_executions, "max_backend_executions")
    if measurement is None and (
        selected_config.repeats != 1
        or selected_config.repeat_mode == "adaptive"
    ):
        raise ValueError("exact gradients require one fixed repeat.")
    plan = build_parameter_shift_plan(
        circuit,
        hamiltonian,
        config=selected_config,
    )
    objectives_per_repeat = plan.expected_objective_evaluation_count
    minimum_objectives = selected_config.repeats * objectives_per_repeat
    if (
        selected_config.max_objective_evaluations is not None
        and selected_config.max_objective_evaluations < minimum_objectives
    ):
        raise ValueError(
            "max_objective_evaluations cannot complete the configured "
            "minimum repeats."
        )

    # 构造并核对全部正负线路后才允许提交第一个 Job，避免计划漂移或不支持
    # occurrence 产生部分梯度证据。
    occurrences_by_id = {
        occurrence.occurrence_id: occurrence
        for occurrence in circuit.parameter_occurrences()
    }
    shifted_circuits: list[tuple[Circuit, Circuit]] = []
    for planned in plan.occurrences:
        if planned.occurrence_id not in occurrences_by_id:
            raise ValueError("gradient plan contains an unknown Circuit occurrence.")
        positive = circuit.shift_parameter_occurrence(
            planned.occurrence_id,
            plan.shift,
        )
        negative = circuit.shift_parameter_occurrence(
            planned.occurrence_id,
            -plan.shift,
        )
        if (
            positive.structural_hash() != planned.positive_circuit_hash
            or negative.structural_hash() != planned.negative_circuit_hash
        ):
            raise ValueError("shifted Circuit hashes do not match the gradient plan.")
        shifted_circuits.append((positive, negative))

    backend_executions_per_objective = 1
    if measurement is not None:
        backend_executions_per_objective = build_pauli_measurement_plan(
            shifted_circuits[0][0],
            hamiltonian,
            config=measurement,
        ).backend_execution_count
    backend_executions_per_repeat = (
        objectives_per_repeat * backend_executions_per_objective
    )
    minimum_backend_executions = (
        selected_config.repeats * backend_executions_per_repeat
    )
    if (
        max_backend_executions is not None
        and max_backend_executions < minimum_backend_executions
    ):
        raise ValueError(
            "max_backend_executions cannot complete the configured minimum repeats."
        )

    selected_backend = LocalBackend(seed=seed) if backend is None else backend
    if measurement is None and noise is not None:
        # 完整 shift 计划已经构造并核对，但此时尚未提交任何 Job。用未绑定源线路
        # 预检即可冻结方法与资源选择；所有 shift 线路保持相同 qubit/gate 结构。
        validate_noisy_variational_request(
            circuit,
            noise=noise,
            options=options,
            backend=selected_backend,
            seed=seed,
        )
    gradient_run_id = f"{run_id}.gradient.{gradient_index:06d}"
    parameter_schema = ParameterSchemaIR.from_parameters(circuit.parameters)
    parameter_bind = ParameterBindIR.create(
        parameter_bind_id=f"{gradient_run_id}.bind",
        parameter_schema=parameter_schema,
        values=values,
        metadata={
            "algorithm": algorithm_kind,
            "algorithm_id": algorithm_id,
            "algorithm_run_id": run_id,
            "gradient_index": gradient_index,
        },
    )

    # offset 由调用方在一个 algorithm run 内单调维护。每个 repeat 开始前先预检
    # 完整正负 shift 与所有 QWC stage，预算也只按完整 repeat 消耗。
    repeats: list[GradientRepeatIR] = []
    stop_reason: Literal[
        "fixed_repeats",
        "target_reached",
        "max_repeats_reached",
        "evaluation_budget_exhausted",
        "backend_budget_exhausted",
    ]
    for repeat_index in range(selected_config.effective_max_repeats):
        evaluation_base = (
            objective_evaluation_offset + repeat_index * objectives_per_repeat
        )
        evaluation_indices = tuple(
            evaluation_base + index for index in range(objectives_per_repeat)
        )
        if measurement is not None:
            _preflight_sampled_shifted_circuits(
                shifted_circuits=tuple(shifted_circuits),
                evaluation_indices=evaluation_indices,
                parameter_names=parameter_names,
                values=values,
                hamiltonian=hamiltonian,
                measurement=measurement,
                backend=selected_backend,
                seed=seed,
                noise=noise,
                options=options,
                gradient_run_id=gradient_run_id,
            )
        shift_pairs: list[ShiftPairEvaluationIR] = []
        for occurrence_index, (planned, shifted) in enumerate(
            zip(plan.occurrences, shifted_circuits)
        ):
            positive_index = evaluation_base + 2 * occurrence_index
            negative_index = positive_index + 1
            positive, negative = shifted
            positive_evaluation: GradientObjectiveEvaluationIR
            negative_evaluation: GradientObjectiveEvaluationIR
            if measurement is None:
                positive_evaluation = execute_objective_evaluation(
                    algorithm_kind=algorithm_kind,
                    algorithm_id=algorithm_id,
                    algorithm_run_id=gradient_run_id,
                    evaluation_index=positive_index,
                    circuit=positive,
                    parameter_names=parameter_names,
                    parameters=values,
                    hamiltonian=hamiltonian,
                    backend=selected_backend,
                    seed=seed,
                    noise=noise,
                    options=options,
                )
                negative_evaluation = execute_objective_evaluation(
                    algorithm_kind=algorithm_kind,
                    algorithm_id=algorithm_id,
                    algorithm_run_id=gradient_run_id,
                    evaluation_index=negative_index,
                    circuit=negative,
                    parameter_names=parameter_names,
                    parameters=values,
                    hamiltonian=hamiltonian,
                    backend=selected_backend,
                    seed=seed,
                    noise=noise,
                    options=options,
                )
            else:
                positive_evaluation = execute_sampled_objective_evaluation(
                    algorithm_id=algorithm_id,
                    algorithm_run_id=gradient_run_id,
                    evaluation_index=positive_index,
                    circuit=positive,
                    parameter_names=parameter_names,
                    parameters=values,
                    hamiltonian=hamiltonian,
                    measurement=measurement,
                    backend=selected_backend,
                    seed=seed,
                    noise=noise,
                    options=options,
                )
                negative_evaluation = execute_sampled_objective_evaluation(
                    algorithm_id=algorithm_id,
                    algorithm_run_id=gradient_run_id,
                    evaluation_index=negative_index,
                    circuit=negative,
                    parameter_names=parameter_names,
                    parameters=values,
                    hamiltonian=hamiltonian,
                    measurement=measurement,
                    backend=selected_backend,
                    seed=seed,
                    noise=noise,
                    options=options,
                )
            shift_pairs.append(
                ShiftPairEvaluationIR.create(
                    occurrence=planned,
                    positive_evaluation=positive_evaluation,
                    negative_evaluation=negative_evaluation,
                    prefactor=plan.prefactor,
                )
            )
        repeats.append(
            GradientRepeatIR.create(
                repeat_index=repeat_index,
                plan=plan,
                shift_pairs=tuple(shift_pairs),
            )
        )
        if selected_config.repeat_mode == "fixed":
            if len(repeats) == selected_config.repeats:
                stop_reason = "fixed_repeats"
                break
            continue
        if len(repeats) < selected_config.repeats:
            continue
        pooled = _pool_gradient_repeats(plan, tuple(repeats))
        _, _, covariance, _ = _derive_parameter_gradient_statistics(plan, pooled)
        uncertainty_norm = math.sqrt(
            math.fsum(covariance[name][name] for name in plan.parameter_names)
        )
        assert selected_config.uncertainty_norm_target is not None
        if uncertainty_norm <= selected_config.uncertainty_norm_target:
            stop_reason = "target_reached"
            break
        if len(repeats) == selected_config.effective_max_repeats:
            stop_reason = "max_repeats_reached"
            break
        if (
            selected_config.max_objective_evaluations is not None
            and (len(repeats) + 1) * objectives_per_repeat
            > selected_config.max_objective_evaluations
        ):
            stop_reason = "evaluation_budget_exhausted"
            break
        if (
            max_backend_executions is not None
            and (len(repeats) + 1) * backend_executions_per_repeat
            > max_backend_executions
        ):
            stop_reason = "backend_budget_exhausted"
            break
    else:  # pragma: no cover - every validated mode stops at its hard ceiling
        raise RuntimeError("gradient repeat loop did not produce a stop reason.")

    first_pair = repeats[0].shift_pairs[0]
    gradient = ObjectiveGradientIR.create(
        gradient_id=gradient_run_id,
        gradient_index=gradient_index,
        config=selected_config,
        plan=plan,
        parameter_bind=parameter_bind,
        repeats=tuple(repeats),
        repeat_stop_reason=stop_reason,
        backend_execution_limit=max_backend_executions,
        metadata={
            "algorithm": algorithm_kind,
            "algorithm_id": algorithm_id,
            "algorithm_run_id": run_id,
            "gradient_index": gradient_index,
            "repeat_count": len(repeats),
            "backend_execution_count": sum(
                repeat.backend_execution_count for repeat in repeats
            ),
            "total_shots": sum(repeat.total_shots for repeat in repeats),
            "seed": seed,
            "estimator": _evaluation_estimator(first_pair.positive_evaluation),
            "simulation_method": _evaluation_simulation_method(
                first_pair.positive_evaluation
            ),
            "noise_model_hash": None if noise is None else noise.stable_hash(),
            "requested_options_hash": (
                None if options is None else options.stable_hash()
            ),
            "measurement": None if measurement is None else measurement.to_dict(),
            "measurement_plan_hashes": tuple(
                evaluation.plan.plan_hash
                for repeat in repeats
                for pair in repeat.shift_pairs
                for evaluation in (pair.positive_evaluation, pair.negative_evaluation)
                if isinstance(evaluation, SampledObjectiveEvaluationIR)
            ),
        },
    )
    return gradient


def _require_matching_execution_context(
    evaluations: tuple[GradientObjectiveEvaluationIR, ...],
) -> None:
    """校验一组 shift objective 使用相同的物理与估计上下文。"""
    if not evaluations:
        raise ValueError("gradient execution context requires evaluations.")
    expected = _execution_context(evaluations[0])
    for evaluation in evaluations[1:]:
        if _execution_context(evaluation) != expected:
            raise ValueError(
                "shift evaluations must share NoiseModel, requested options, "
                "simulation method, estimator, Backend, and measurement/readout "
                "identity."
            )


def _execution_context(
    evaluation: GradientObjectiveEvaluationIR,
) -> tuple[object, ...]:
    if isinstance(evaluation, ObjectiveEvaluationIR):
        evidence = evaluation.execution_evidence
        return (
            "exact",
            None
            if evidence.noise_model is None
            else evidence.noise_model.stable_hash(),
            None
            if evidence.requested_options is None
            else evidence.requested_options.stable_hash(),
            evidence.simulation_plan.method_selected,
            evidence.estimator_kind,
            evidence.source_kind,
            evidence.backend_id,
        )
    if isinstance(evaluation, SampledObjectiveEvaluationIR):
        evidence = evaluation.all_group_results[0].execution_evidence
        return (
            "sampled",
            stable_json(evaluation.plan.config),
            evaluation.plan.hamiltonian_hash,
            evaluation.plan.logical_order,
            None
            if evaluation.noise_model is None
            else evaluation.noise_model.stable_hash(),
            None
            if evaluation.requested_options is None
            else evaluation.requested_options.stable_hash(),
            evaluation.simulation_method,
            evaluation.estimator_kind,
            evidence.source_kind,
            evaluation.backend_id,
        )
    raise TypeError("gradient evaluation must be exact or sampled objective IR.")


def _occurrence_dependencies(occurrence: GateParameterOccurrence) -> tuple[str, ...]:
    value = occurrence.parameter_value
    if isinstance(value, Parameter):
        return (value.name,)
    if isinstance(value, Expression):
        return value.dependencies
    return ()


def _raise_capability(
    message: str,
    *,
    code: str,
    metadata: Mapping[str, Any] | None = None,
) -> NoReturn:
    raise CapabilityError(
        message,
        code=code,
        object_path="algorithms.gradient.plan",
        suggestion="Use symbolic affine RX, RY, or RZ parameters only.",
        metadata={} if metadata is None else dict(metadata),
    )


def _finite_float(value: object, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{name} must be a real number.")
    normalized = float(value)
    if not math.isfinite(normalized):
        raise ValueError(f"{name} must be finite.")
    return normalized


def _finite_non_negative_float(value: object, name: str) -> float:
    """Return one finite non-negative float while rejecting booleans."""
    normalized = _finite_float(value, name)
    if normalized < 0.0:
        raise ValueError(f"{name} must be non-negative.")
    return normalized


def _finite_mapping(value: object, name: str) -> Mapping[str, float]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{name} must be a mapping.")
    normalized: dict[str, float] = {}
    for raw_key, raw_value in value.items():
        key = str(raw_key)
        _require_text(key, f"{name} key")
        normalized[key] = _finite_float(raw_value, f"{name}[{key}]")
    return MappingProxyType(normalized)


def _nested_finite_mapping(
    value: object,
    name: str,
) -> Mapping[str, Mapping[str, float]]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{name} must be a mapping.")
    return MappingProxyType(
        {
            str(key): _finite_mapping(item, f"{name}[{key}]")
            for key, item in value.items()
        }
    )


def _freeze_mapping(value: Mapping[str, Any]) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError("metadata must be a mapping.")
    return MappingProxyType(
        {str(key): _freeze_value(item) for key, item in sorted(value.items())}
    )


def _freeze_value(value: Any) -> Any:
    if isinstance(value, Mapping):
        return _freeze_mapping(value)
    if isinstance(value, (list, tuple)):
        return tuple(_freeze_value(item) for item in value)
    return value


def _require_mapping_close(
    actual: Mapping[str, float],
    expected: Mapping[str, float],
    name: str,
) -> None:
    if set(actual) != set(expected) or any(
        not math.isclose(actual[key], expected[key], rel_tol=0.0, abs_tol=_TOLERANCE)
        for key in expected
    ):
        raise ValueError(f"{name} does not match reconstructed values.")


def _require_nested_close(
    actual: Mapping[str, Mapping[str, float]],
    expected: Mapping[str, Mapping[str, float]],
) -> None:
    if set(actual) != set(expected):
        raise ValueError("parameter_contributions keys do not match plan parameters.")
    for name in expected:
        _require_mapping_close(
            actual[name],
            expected[name],
            f"parameter_contributions[{name}]",
        )


def _unique_text_tuple(value: object, name: str) -> tuple[str, ...]:
    values = tuple(str(item) for item in _sequence(value, name))
    if not values:
        raise ValueError(f"{name} must not be empty.")
    for item in values:
        _require_text(item, name)
    if len(values) != len(set(values)):
        raise ValueError(f"{name} values must be unique.")
    return values


def _require_text(value: object, name: str) -> None:
    if not isinstance(value, str) or not value.strip() or value != value.strip():
        raise ValueError(f"{name} must be a non-empty trimmed string.")


def _require_digest(value: object, name: str) -> None:
    if not isinstance(value, str) or _DIGEST_PATTERN.fullmatch(value) is None:
        raise ValueError(f"{name} must be a lowercase SHA-256 digest.")


def _require_non_negative_int(value: object, name: str) -> None:
    if not isinstance(value, int) or isinstance(value, bool) or value < 0:
        raise ValueError(f"{name} must be a non-negative integer.")


def _require_positive_int(value: object, name: str) -> None:
    if not isinstance(value, int) or isinstance(value, bool) or value <= 0:
        raise ValueError(f"{name} must be a positive integer.")


def _mapping(value: object, name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{name} must be an object.")
    return value


def _sequence(value: object, name: str) -> tuple[Any, ...]:
    if not isinstance(value, (list, tuple)):
        raise TypeError(f"{name} must be an array.")
    return tuple(value)


def _json_object(text: str, name: str) -> Mapping[str, Any]:
    data = json.loads(text)
    if not isinstance(data, dict):
        raise TypeError(f"{name} JSON must contain an object.")
    return data
