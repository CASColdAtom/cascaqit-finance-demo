"""Read-only stability diagnostics for completed native-SPSA VQE runs."""

from __future__ import annotations

import hashlib
import json
import math
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from os import PathLike
from typing import TYPE_CHECKING, Any, Literal, cast

from cascaqit.algorithms.measurement import SampledObjectiveEvaluationIR
from cascaqit.algorithms.models import (
    OptimizationStartIR,
    OptimizerTerminationIR,
    VariationalResult,
)
from cascaqit.native_ir.base import IRMixin, canonicalize, stable_json

if TYPE_CHECKING:
    from cascaqit.visualization import ExperimentReport

__all__ = [
    "VQE_STABILITY_SCHEMA_VERSION",
    "VQEStabilityCheckIR",
    "VQEStabilityConfig",
    "VQEStabilityDiagnosticResult",
    "VQEStartStabilityDiagnosticIR",
    "diagnose_vqe_stability",
]

VQE_STABILITY_SCHEMA_VERSION = "cascaqit.algorithms.vqe_stability.v1"
VQEStabilityStatus = Literal["stable", "unstable", "insufficient_evidence"]
VQEStabilityCheckStatus = Literal["passed", "failed", "unavailable"]
VQEEvaluatorKind = Literal["exact", "sampled"]
VQEStabilityCheckName = Literal[
    "objective_range",
    "update_norm",
    "gradient_norm",
    "sampled_uncertainty",
]

_CHECK_NAMES = frozenset(
    ("objective_range", "update_norm", "gradient_norm", "sampled_uncertainty")
)
_CHECK_STATUSES = frozenset(("passed", "failed", "unavailable"))
_STABILITY_STATUSES = frozenset(
    ("stable", "unstable", "insufficient_evidence")
)
_REPEAT_STOP_REASONS = frozenset(
    ("fixed_repeats", "target_reached", "max_repeats_reached", "budget_exhausted")
)


@dataclass(frozen=True)
class VQEStabilityConfig(IRMixin):
    """Thresholds for one read-only terminal-window stability diagnosis."""

    window_size: int = 3
    min_iterations: int = 3
    objective_range_tolerance: float = 1e-3
    update_norm_tolerance: float = 1e-3
    gradient_norm_tolerance: float = 1e-2
    sampled_standard_error_tolerance: float = 5e-2
    schema_version: str = VQE_STABILITY_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_positive_int(self.window_size, "window_size")
        _require_positive_int(self.min_iterations, "min_iterations")
        if self.min_iterations < self.window_size:
            raise ValueError("min_iterations must be at least window_size.")
        for name in (
            "objective_range_tolerance",
            "update_norm_tolerance",
            "gradient_norm_tolerance",
            "sampled_standard_error_tolerance",
        ):
            value = _finite_float(getattr(self, name), name)
            if value <= 0.0:
                raise ValueError(f"{name} must be positive.")
            object.__setattr__(self, name, value)
        if self.schema_version != VQE_STABILITY_SCHEMA_VERSION:
            raise ValueError("Unsupported VQE stability schema version.")

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> VQEStabilityConfig:
        """Restore a stability configuration from JSON-compatible data."""
        return cls(
            window_size=data.get("window_size", 3),
            min_iterations=data.get("min_iterations", 3),
            objective_range_tolerance=data.get("objective_range_tolerance", 1e-3),
            update_norm_tolerance=data.get("update_norm_tolerance", 1e-3),
            gradient_norm_tolerance=data.get("gradient_norm_tolerance", 1e-2),
            sampled_standard_error_tolerance=data.get(
                "sampled_standard_error_tolerance", 5e-2
            ),
            schema_version=str(
                data.get("schema_version", VQE_STABILITY_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> VQEStabilityConfig:
        """Restore a stability configuration from JSON text."""
        return cls.from_dict(_json_object(text, "VQEStabilityConfig"))


@dataclass(frozen=True)
class VQEStabilityCheckIR(IRMixin):
    """One threshold check and the exact scalar evidence used by it."""

    name: VQEStabilityCheckName
    status: VQEStabilityCheckStatus
    observed_value: float | None
    threshold: float
    sample_count: int
    schema_version: str = VQE_STABILITY_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.name not in _CHECK_NAMES:
            raise ValueError(f"Unsupported VQE stability check: {self.name!r}.")
        if self.status not in _CHECK_STATUSES:
            raise ValueError(f"Unsupported VQE check status: {self.status!r}.")
        threshold = _finite_float(self.threshold, "threshold")
        if threshold <= 0.0:
            raise ValueError("threshold must be positive.")
        _require_non_negative_int(self.sample_count, "sample_count")
        if self.status == "unavailable":
            if self.observed_value is not None:
                raise ValueError("unavailable checks cannot have an observed value.")
        else:
            observed = _finite_float(self.observed_value, "observed_value")
            if observed < 0.0:
                raise ValueError("observed_value must be non-negative.")
            expected = "passed" if observed <= threshold else "failed"
            if self.status != expected:
                raise ValueError(
                    "check status must match observed value and threshold."
                )
            object.__setattr__(self, "observed_value", observed)
        object.__setattr__(self, "threshold", threshold)
        if self.schema_version != VQE_STABILITY_SCHEMA_VERSION:
            raise ValueError("Unsupported VQE stability schema version.")

    @classmethod
    def create(
        cls,
        *,
        name: VQEStabilityCheckName,
        observed_value: float | None,
        threshold: float,
        sample_count: int,
    ) -> VQEStabilityCheckIR:
        """Build a check whose status is derived from its scalar evidence."""
        status: VQEStabilityCheckStatus
        if observed_value is None:
            status = "unavailable"
        else:
            status = "passed" if observed_value <= threshold else "failed"
        return cls(
            name=name,
            status=status,
            observed_value=observed_value,
            threshold=threshold,
            sample_count=sample_count,
        )

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> VQEStabilityCheckIR:
        """Restore one stability check from JSON-compatible data."""
        return cls(
            name=cast(VQEStabilityCheckName, data["name"]),
            status=cast(VQEStabilityCheckStatus, data["status"]),
            observed_value=data.get("observed_value"),
            threshold=data["threshold"],
            sample_count=data["sample_count"],
            schema_version=str(
                data.get("schema_version", VQE_STABILITY_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class VQEStartStabilityDiagnosticIR(IRMixin):
    """Terminal stability evidence for exactly one optimizer start."""

    start_index: int
    source_start_hash: str
    selected: bool
    evaluator_kind: VQEEvaluatorKind
    status: VQEStabilityStatus
    iteration_count: int
    window_iteration_indices: tuple[int, ...]
    objective_proxy_values: tuple[float, ...]
    objective_window_values: tuple[float, ...]
    update_norm_window: tuple[float, ...]
    gradient_norm_window: tuple[float, ...]
    sampled_standard_errors: tuple[float | None, ...]
    sampled_repeat_counts: tuple[int, ...]
    sampled_repeat_stop_reasons: tuple[str, ...]
    checks: tuple[VQEStabilityCheckIR, ...]
    termination: OptimizerTerminationIR
    evaluation_count: int
    backend_execution_count: int
    max_evaluations: int | None
    max_backend_executions: int | None
    schema_version: str = VQE_STABILITY_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_non_negative_int(self.start_index, "start_index")
        _require_digest(self.source_start_hash, "source_start_hash")
        if not isinstance(self.selected, bool):
            raise TypeError("selected must be bool.")
        if self.evaluator_kind not in {"exact", "sampled"}:
            raise ValueError(f"Unsupported evaluator_kind: {self.evaluator_kind!r}.")
        if self.status not in _STABILITY_STATUSES:
            raise ValueError(f"Unsupported stability status: {self.status!r}.")
        _require_positive_int(self.iteration_count, "iteration_count")
        indices = _int_tuple(self.window_iteration_indices, "window_iteration_indices")
        if (
            not indices
            or any(index < 0 for index in indices)
            or tuple(sorted(indices)) != indices
            or len(set(indices)) != len(indices)
        ):
            raise ValueError("window_iteration_indices must be unique and ordered.")
        if indices[-1] >= self.iteration_count:
            raise ValueError("window iteration index exceeds iteration_count.")
        for name in (
            "objective_proxy_values",
            "objective_window_values",
            "update_norm_window",
            "gradient_norm_window",
        ):
            values = _float_tuple(getattr(self, name), name)
            if not values:
                raise ValueError(f"{name} must not be empty.")
            if name in {"update_norm_window", "gradient_norm_window"} and any(
                value < 0.0 for value in values
            ):
                raise ValueError(f"{name} must contain non-negative values.")
            object.__setattr__(self, name, values)
        if len(self.update_norm_window) != len(indices) or len(
            self.gradient_norm_window
        ) != len(indices):
            raise ValueError("norm windows must match window_iteration_indices.")
        if len(self.objective_proxy_values) != self.iteration_count + 1:
            raise ValueError("objective proxy trajectory must end with final center.")
        if len(self.objective_window_values) != len(indices) + 1:
            raise ValueError(
                "objective window must cover terminal iterations and final center."
            )
        standard_errors = tuple(
            None if value is None else _finite_float(value, "sampled_standard_error")
            for value in self.sampled_standard_errors
        )
        if any(value is not None and value < 0.0 for value in standard_errors):
            raise ValueError("sampled standard errors must be non-negative.")
        repeat_counts = _int_tuple(self.sampled_repeat_counts, "sampled_repeat_counts")
        if any(value <= 0 for value in repeat_counts):
            raise ValueError("sampled repeat counts must be positive.")
        repeat_reasons = tuple(str(value) for value in self.sampled_repeat_stop_reasons)
        if any(value not in _REPEAT_STOP_REASONS for value in repeat_reasons):
            raise ValueError("sampled repeat stop reason is unsupported.")
        if self.evaluator_kind == "exact":
            if standard_errors or repeat_counts or repeat_reasons:
                raise ValueError("exact diagnostics cannot contain sampled evidence.")
        elif not (
            len(standard_errors) == len(repeat_counts) == len(repeat_reasons)
        ):
            raise ValueError("sampled uncertainty and repeat facts must align.")
        object.__setattr__(self, "sampled_standard_errors", standard_errors)
        object.__setattr__(self, "sampled_repeat_counts", repeat_counts)
        object.__setattr__(self, "sampled_repeat_stop_reasons", repeat_reasons)
        if not isinstance(self.checks, tuple):
            object.__setattr__(self, "checks", tuple(self.checks))
        if any(not isinstance(item, VQEStabilityCheckIR) for item in self.checks):
            raise TypeError("checks must contain VQEStabilityCheckIR values.")
        expected_names = (
            ("objective_range", "update_norm", "gradient_norm")
            if self.evaluator_kind == "exact"
            else (
                "objective_range",
                "update_norm",
                "gradient_norm",
                "sampled_uncertainty",
            )
        )
        if tuple(item.name for item in self.checks) != expected_names:
            raise ValueError("stability checks must use the canonical order.")
        if not isinstance(self.termination, OptimizerTerminationIR):
            raise TypeError("termination must be OptimizerTerminationIR.")
        _require_positive_int(self.evaluation_count, "evaluation_count")
        _require_positive_int(self.backend_execution_count, "backend_execution_count")
        if self.evaluation_count != self.termination.nfev:
            raise ValueError("evaluation_count must match termination nfev.")
        if self.backend_execution_count != self.termination.backend_execution_count:
            raise ValueError("Backend count must match termination evidence.")
        for name in ("max_evaluations", "max_backend_executions"):
            value = getattr(self, name)
            if value is not None:
                _require_positive_int(value, name)
        if self.schema_version != VQE_STABILITY_SCHEMA_VERSION:
            raise ValueError("Unsupported VQE stability schema version.")

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> VQEStartStabilityDiagnosticIR:
        """Restore one start diagnostic from JSON-compatible data."""
        return cls(
            start_index=data["start_index"],
            source_start_hash=str(data["source_start_hash"]),
            selected=data["selected"],
            evaluator_kind=cast(VQEEvaluatorKind, data["evaluator_kind"]),
            status=cast(VQEStabilityStatus, data["status"]),
            iteration_count=data["iteration_count"],
            window_iteration_indices=tuple(data["window_iteration_indices"]),
            objective_proxy_values=tuple(data["objective_proxy_values"]),
            objective_window_values=tuple(data["objective_window_values"]),
            update_norm_window=tuple(data["update_norm_window"]),
            gradient_norm_window=tuple(data["gradient_norm_window"]),
            sampled_standard_errors=tuple(data.get("sampled_standard_errors", ())),
            sampled_repeat_counts=tuple(data.get("sampled_repeat_counts", ())),
            sampled_repeat_stop_reasons=tuple(
                data.get("sampled_repeat_stop_reasons", ())
            ),
            checks=tuple(
                VQEStabilityCheckIR.from_dict(_mapping(item, "check"))
                for item in _sequence(data["checks"], "checks")
            ),
            termination=OptimizerTerminationIR.from_dict(
                _mapping(data["termination"], "termination")
            ),
            evaluation_count=data["evaluation_count"],
            backend_execution_count=data["backend_execution_count"],
            max_evaluations=data.get("max_evaluations"),
            max_backend_executions=data.get("max_backend_executions"),
            schema_version=str(
                data.get("schema_version", VQE_STABILITY_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class VQEStabilityDiagnosticResult(IRMixin):
    """Restorable VQE stability diagnosis grounded in one complete result."""

    diagnostic_id: str
    source_result_hash: str
    source_result: VariationalResult[Any]
    config: VQEStabilityConfig
    starts: tuple[VQEStartStabilityDiagnosticIR, ...]
    selected_start_index: int
    status: VQEStabilityStatus
    optimality_claim: Literal["not_claimed"] = "not_claimed"
    convergence_claim: Literal["not_claimed"] = "not_claimed"
    schema_version: str = VQE_STABILITY_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _validate_source_result(self.source_result)
        if not isinstance(self.config, VQEStabilityConfig):
            raise TypeError("config must be VQEStabilityConfig.")
        actual_hash = self.source_result.stable_hash()
        if self.source_result_hash != actual_hash:
            raise ValueError("source_result_hash must match the source result.")
        _require_digest(self.source_result_hash, "source_result_hash")
        expected_id = _diagnostic_id(actual_hash, self.config)
        if self.diagnostic_id != expected_id:
            raise ValueError("diagnostic_id must match source result and config.")
        if not isinstance(self.starts, tuple):
            object.__setattr__(self, "starts", tuple(self.starts))
        if any(
            not isinstance(item, VQEStartStabilityDiagnosticIR)
            for item in self.starts
        ):
            raise TypeError("starts must contain VQEStartStabilityDiagnosticIR values.")
        expected_starts = _derive_start_diagnostics(self.source_result, self.config)
        if canonicalize(self.starts) != canonicalize(expected_starts):
            raise ValueError("start diagnostics must match recomputed source evidence.")
        expected_selected = self.source_result.selected_start_index
        assert expected_selected is not None
        if self.selected_start_index != expected_selected:
            raise ValueError("selected_start_index must match the source result.")
        selected = next(
            item for item in expected_starts if item.start_index == expected_selected
        )
        if self.status != selected.status:
            raise ValueError("overall status must match the selected start.")
        if self.optimality_claim != "not_claimed":
            raise ValueError("VQE stability diagnostics cannot claim optimality.")
        if self.convergence_claim != "not_claimed":
            raise ValueError("VQE stability diagnostics cannot claim convergence.")
        if self.schema_version != VQE_STABILITY_SCHEMA_VERSION:
            raise ValueError("Unsupported VQE stability schema version.")

    @classmethod
    def create(
        cls,
        source_result: VariationalResult[Any],
        config: VQEStabilityConfig,
    ) -> VQEStabilityDiagnosticResult:
        """Derive and freeze a complete diagnosis from saved result evidence."""
        _validate_source_result(source_result)
        if not isinstance(config, VQEStabilityConfig):
            raise TypeError("config must be VQEStabilityConfig.")
        source_hash = source_result.stable_hash()
        starts = _derive_start_diagnostics(source_result, config)
        selected_index = source_result.selected_start_index
        assert selected_index is not None
        selected = next(item for item in starts if item.start_index == selected_index)
        return cls(
            diagnostic_id=_diagnostic_id(source_hash, config),
            source_result_hash=source_hash,
            source_result=source_result,
            config=config,
            starts=starts,
            selected_start_index=selected_index,
            status=selected.status,
        )

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> VQEStabilityDiagnosticResult:
        """Restore a diagnosis and reject altered source or derived evidence."""
        return cls(
            diagnostic_id=str(data["diagnostic_id"]),
            source_result_hash=str(data["source_result_hash"]),
            source_result=VariationalResult.from_dict(
                _mapping(data["source_result"], "source_result")
            ),
            config=VQEStabilityConfig.from_dict(_mapping(data["config"], "config")),
            starts=tuple(
                VQEStartStabilityDiagnosticIR.from_dict(_mapping(item, "start"))
                for item in _sequence(data["starts"], "starts")
            ),
            selected_start_index=data["selected_start_index"],
            status=cast(VQEStabilityStatus, data["status"]),
            optimality_claim=cast(
                Literal["not_claimed"], data.get("optimality_claim", "not_claimed")
            ),
            convergence_claim=cast(
                Literal["not_claimed"],
                data.get("convergence_claim", "not_claimed"),
            ),
            schema_version=str(
                data.get("schema_version", VQE_STABILITY_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> VQEStabilityDiagnosticResult:
        """Restore a diagnosis from JSON text."""
        return cls.from_dict(_json_object(text, "VQEStabilityDiagnosticResult"))

    def report(
        self,
        output: str | PathLike[str] | None = None,
        *,
        language: Literal["en", "zh"] = "en",
        title: str | None = None,
    ) -> ExperimentReport:
        """Build and optionally save the standard stability report."""
        from cascaqit.visualization import visualize

        report = visualize(self, profile="algorithm", title=title)
        if output is not None:
            report.save(output, language=language)
        return report


def diagnose_vqe_stability(
    source_result: VariationalResult[Any],
    config: VQEStabilityConfig | None = None,
) -> VQEStabilityDiagnosticResult:
    """Diagnose one completed VQE result without rerunning its workflow."""
    resolved = VQEStabilityConfig() if config is None else config
    return VQEStabilityDiagnosticResult.create(source_result, resolved)


def _derive_start_diagnostics(
    result: VariationalResult[Any],
    config: VQEStabilityConfig,
) -> tuple[VQEStartStabilityDiagnosticIR, ...]:
    sampled = isinstance(result.evaluations[0], SampledObjectiveEvaluationIR)
    return tuple(
        _diagnose_start(
            start,
            config=config,
            selected=start.start_index == result.selected_start_index,
            sampled=sampled,
            max_evaluations=result.optimizer.max_evaluations,
            max_backend_executions=result.optimizer.max_backend_executions,
        )
        for start in result.optimization_starts
    )


def _diagnose_start(
    start: OptimizationStartIR,
    *,
    config: VQEStabilityConfig,
    selected: bool,
    sampled: bool,
    max_evaluations: int | None,
    max_backend_executions: int | None,
) -> VQEStartStabilityDiagnosticIR:
    iterations = start.spsa_iterations
    terminal_iterations = iterations[-config.window_size :]
    window_indices = tuple(item.iteration_index for item in terminal_iterations)

    # 每个扰动方向的 plus/minus 中点都近似同一轮中心目标；多方向时先取平均，
    # 避免诊断结果依赖任意一个方向。最终中心仍使用独立保存的 final estimate。
    final_estimate = start.spsa_final_estimate
    assert final_estimate is not None
    objective_proxies = tuple(
        math.fsum(
            (direction.plus_objective + direction.minus_objective) / 2.0
            for direction in item.directions
        )
        / len(item.directions)
        for item in iterations
    ) + (final_estimate.pooled_objective,)
    objective_window = tuple(
        math.fsum(
            (direction.plus_objective + direction.minus_objective) / 2.0
            for direction in item.directions
        )
        / len(item.directions)
        for item in terminal_iterations
    ) + (final_estimate.pooled_objective,)
    update_norms = tuple(item.update_norm for item in terminal_iterations)
    gradient_norms = tuple(
        math.sqrt(math.fsum(value * value for value in item.gradient_estimate.values()))
        for item in terminal_iterations
    )

    enough_iterations = len(iterations) >= config.min_iterations
    complete_window = len(terminal_iterations) == config.window_size
    objective_value = (
        max(objective_window) - min(objective_window)
        if enough_iterations and len(objective_window) == config.window_size + 1
        else None
    )
    update_value = max(update_norms) if enough_iterations and complete_window else None
    gradient_value = (
        max(gradient_norms) if enough_iterations and complete_window else None
    )
    checks: list[VQEStabilityCheckIR] = [
        VQEStabilityCheckIR.create(
            name="objective_range",
            observed_value=objective_value,
            threshold=config.objective_range_tolerance,
            sample_count=len(objective_window),
        ),
        VQEStabilityCheckIR.create(
            name="update_norm",
            observed_value=update_value,
            threshold=config.update_norm_tolerance,
            sample_count=len(update_norms),
        ),
        VQEStabilityCheckIR.create(
            name="gradient_norm",
            observed_value=gradient_value,
            threshold=config.gradient_norm_tolerance,
            sample_count=len(gradient_norms),
        ),
    ]

    standard_errors: tuple[float | None, ...] = ()
    repeat_counts: tuple[int, ...] = ()
    repeat_reasons: tuple[str, ...] = ()
    if sampled:
        estimates = tuple(
            estimate
            for item in terminal_iterations
            for direction in item.directions
            for estimate in (direction.plus_estimate, direction.minus_estimate)
        ) + (final_estimate,)
        standard_errors = tuple(item.pooled_standard_error for item in estimates)
        repeat_counts = tuple(item.repeat_count for item in estimates)
        repeat_reasons = tuple(item.stop_reason for item in estimates)
        uncertainty_value = (
            max(cast(tuple[float, ...], standard_errors))
            if enough_iterations
            and complete_window
            and all(value is not None for value in standard_errors)
            else None
        )
        checks.append(
            VQEStabilityCheckIR.create(
                name="sampled_uncertainty",
                observed_value=uncertainty_value,
                threshold=config.sampled_standard_error_tolerance,
                sample_count=sum(value is not None for value in standard_errors),
            )
        )

    check_statuses = {item.status for item in checks}
    if not enough_iterations or "unavailable" in check_statuses:
        status: VQEStabilityStatus = "insufficient_evidence"
    elif "failed" in check_statuses:
        status = "unstable"
    else:
        status = "stable"

    assert start.backend_execution_count is not None
    return VQEStartStabilityDiagnosticIR(
        start_index=start.start_index,
        source_start_hash=start.stable_hash(),
        selected=selected,
        evaluator_kind="sampled" if sampled else "exact",
        status=status,
        iteration_count=len(iterations),
        window_iteration_indices=window_indices,
        objective_proxy_values=objective_proxies,
        objective_window_values=objective_window,
        update_norm_window=update_norms,
        gradient_norm_window=gradient_norms,
        sampled_standard_errors=standard_errors,
        sampled_repeat_counts=repeat_counts,
        sampled_repeat_stop_reasons=repeat_reasons,
        checks=tuple(checks),
        termination=start.termination,
        evaluation_count=start.evaluation_count,
        backend_execution_count=start.backend_execution_count,
        max_evaluations=max_evaluations,
        max_backend_executions=max_backend_executions,
    )


def _validate_source_result(result: object) -> None:
    if not isinstance(result, VariationalResult):
        raise TypeError("source_result must be VariationalResult.")
    if result.algorithm_kind != "vqe":
        raise ValueError("VQE stability diagnostics require algorithm_kind='vqe'.")
    if result.optimizer.method != "SPSA":
        raise ValueError("VQE stability diagnostics require native SPSA.")
    if not result.optimization_starts:
        raise ValueError("VQE stability diagnostics require optimization starts.")


def _diagnostic_id(source_hash: str, config: VQEStabilityConfig) -> str:
    suffix = hashlib.sha256(
        stable_json({"source_result_hash": source_hash, "config": config}).encode(
            "utf-8"
        )
    ).hexdigest()[:24]
    return f"vqe_stability.{suffix}"


def _finite_float(value: object, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{name} must be a finite number.")
    normalized = float(value)
    if not math.isfinite(normalized):
        raise ValueError(f"{name} must be finite.")
    return normalized


def _require_positive_int(value: object, name: str) -> None:
    if not isinstance(value, int) or isinstance(value, bool) or value <= 0:
        raise ValueError(f"{name} must be a positive integer.")


def _require_non_negative_int(value: object, name: str) -> None:
    if not isinstance(value, int) or isinstance(value, bool) or value < 0:
        raise ValueError(f"{name} must be a non-negative integer.")


def _require_digest(value: object, name: str) -> None:
    if (
        not isinstance(value, str)
        or len(value) != 64
        or any(character not in "0123456789abcdef" for character in value)
    ):
        raise ValueError(f"{name} must be a lowercase SHA-256 digest.")


def _float_tuple(values: object, name: str) -> tuple[float, ...]:
    if not isinstance(values, (list, tuple)):
        raise TypeError(f"{name} must be an array.")
    return tuple(_finite_float(value, name) for value in values)


def _int_tuple(values: object, name: str) -> tuple[int, ...]:
    if not isinstance(values, (list, tuple)):
        raise TypeError(f"{name} must be an array.")
    normalized = tuple(values)
    if any(
        not isinstance(value, int) or isinstance(value, bool) for value in normalized
    ):
        raise TypeError(f"{name} must contain integers.")
    return normalized


def _mapping(value: object, name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{name} must be an object.")
    return value


def _sequence(value: object, name: str) -> Sequence[Any]:
    if not isinstance(value, (list, tuple)):
        raise TypeError(f"{name} must be an array.")
    return value


def _json_object(text: str, name: str) -> Mapping[str, Any]:
    data = json.loads(text)
    if not isinstance(data, Mapping):
        raise TypeError(f"{name} JSON must contain an object.")
    return data
