"""Executable VQE ansatz and single-objective evaluation."""

from __future__ import annotations

import math
from dataclasses import dataclass, field, replace
from typing import Any, Union, cast, overload

from cascaqit.algorithms.ansatz import (
    BuiltAnsatz,
    CardinalityPreservingAnsatz,
    HardwareEfficientAnsatz,
    build_vqe_ansatz,
    transfer_vqe_parameters,
)
from cascaqit.algorithms.execution import (
    ParameterValues,
    execute_objective_evaluation,
)
from cascaqit.algorithms.gradient import (
    GradientConfig,
    ObjectiveGradientIR,
    execute_parameter_shift_gradient,
)
from cascaqit.algorithms.measurement import (
    PauliMeasurementConfig,
    SampledObjectiveEvaluationIR,
    execute_sampled_objective_evaluation,
)
from cascaqit.algorithms.models import (
    AnsatzSpecIR,
    ObjectiveEvaluationIR,
    OptimizerConfig,
    PauliHamiltonian,
    VariationalResult,
)
from cascaqit.algorithms.optimizer import run_variational_optimization
from cascaqit.algorithms.problem_projection import problem_to_pauli_hamiltonian
from cascaqit.algorithms.sampled_selection import SampledSelectionConfig
from cascaqit.algorithms.vqe_layer_experiment import (
    VQELayerStatisticsIR,
    VQEPairedImprovementIR,
    VQERepeatedLayerExperimentResult,
    VQERepeatedLayerRunIR,
    build_vqe_repeated_layer_experiment_result,
    derive_vqe_layer_run_seed,
)
from cascaqit.algorithms.vqe_sampling_benchmark import (
    VQESamplingBenchmarkConfig,
    VQESamplingBenchmarkResult,
    execute_vqe_sampling_benchmark,
)
from cascaqit.digital import Circuit
from cascaqit.parameters import ParameterSchemaIR
from cascaqit.problems import IsingModelIR, QUBOProblemIR
from cascaqit.simulators import LocalBackend, NoiseModel, SimulationOptions

__all__ = ["VQE"]

VQEInput = Union[PauliHamiltonian, QUBOProblemIR, IsingModelIR]


@dataclass(frozen=True)
class VQE:
    """Build and evaluate a built-in or explicit Circuit ansatz."""

    operator: VQEInput
    layers: int = 1
    ansatz: HardwareEfficientAnsatz | CardinalityPreservingAnsatz | Circuit | None = (
        None
    )
    algorithm_id: str | None = None
    _hamiltonian: PauliHamiltonian = field(init=False, repr=False)
    _built_ansatz: BuiltAnsatz = field(init=False, repr=False)

    def __post_init__(self) -> None:
        if (
            not isinstance(self.layers, int)
            or isinstance(self.layers, bool)
            or self.layers <= 0
        ):
            raise ValueError("layers must be a positive integer.")
        if isinstance(self.operator, PauliHamiltonian):
            hamiltonian = self.operator
        elif isinstance(self.operator, (QUBOProblemIR, IsingModelIR)):
            hamiltonian = problem_to_pauli_hamiltonian(self.operator)
        else:
            raise TypeError(
                "operator must be PauliHamiltonian, QUBOProblemIR, or IsingModelIR."
            )
        algorithm_id = self.algorithm_id or f"vqe.{hamiltonian.hamiltonian_id}"
        if (
            not isinstance(algorithm_id, str)
            or not algorithm_id.strip()
            or algorithm_id != algorithm_id.strip()
        ):
            raise ValueError("algorithm_id must be a non-empty trimmed string.")
        object.__setattr__(self, "algorithm_id", algorithm_id)
        object.__setattr__(self, "_hamiltonian", hamiltonian)
        built = build_vqe_ansatz(
            logical_order=hamiltonian.logical_order,
            layers=self.layers,
            algorithm_id=algorithm_id,
            hamiltonian_hash=hamiltonian.stable_hash(),
            ansatz=self.ansatz,
        )
        object.__setattr__(self, "_built_ansatz", built)
        if isinstance(self.ansatz, Circuit):
            object.__setattr__(self, "ansatz", built.fresh_circuit())

    @property
    def hamiltonian(self) -> PauliHamiltonian:
        """Return the weighted Pauli Hamiltonian evaluated by VQE."""
        return self._hamiltonian

    @property
    def parameter_names(self) -> tuple[str, ...]:
        """Return custom or default ansatz parameters in declaration order."""
        return self._built_ansatz.spec.parameter_names

    def build_circuit(self) -> Circuit:
        """Build a fresh parameterized VQE Circuit."""
        return self._built_ansatz.fresh_circuit()

    def ansatz_spec(self) -> AnsatzSpecIR:
        """Return the stable VQE ansatz declaration."""
        return self._built_ansatz.spec

    def parameter_schema(self) -> ParameterSchemaIR:
        """Return the canonical schema declared by the VQE Circuit."""
        return self._built_ansatz.parameter_schema

    def evaluate(
        self,
        parameters: ParameterValues,
        *,
        backend: LocalBackend | None = None,
        evaluation_index: int = 0,
        algorithm_run_id: str | None = None,
        seed: int | None = None,
        noise: NoiseModel | None = None,
        options: SimulationOptions | None = None,
    ) -> ObjectiveEvaluationIR:
        """通过一个 LocalBackend Job 执行 ideal 或 density-noisy VQE objective。"""
        return execute_objective_evaluation(
            algorithm_kind="vqe",
            algorithm_id=str(self.algorithm_id),
            algorithm_run_id=algorithm_run_id,
            evaluation_index=evaluation_index,
            circuit=self.build_circuit(),
            parameter_names=self.parameter_names,
            parameters=parameters,
            hamiltonian=self.hamiltonian,
            backend=backend,
            seed=seed,
            noise=noise,
            options=options,
        )

    def evaluate_sampled(
        self,
        parameters: ParameterValues,
        *,
        measurement: PauliMeasurementConfig | None = None,
        backend: LocalBackend | None = None,
        evaluation_index: int = 0,
        algorithm_run_id: str | None = None,
        seed: int | None = None,
        noise: NoiseModel | None = None,
        options: SimulationOptions | None = None,
    ) -> SampledObjectiveEvaluationIR:
        """Estimate ideal or noisy VQE energy from grouped finite-shot counts."""
        return execute_sampled_objective_evaluation(
            algorithm_id=str(self.algorithm_id),
            algorithm_run_id=algorithm_run_id,
            evaluation_index=evaluation_index,
            circuit=self.build_circuit(),
            parameter_names=self.parameter_names,
            parameters=parameters,
            hamiltonian=self.hamiltonian,
            measurement=(
                PauliMeasurementConfig() if measurement is None else measurement
            ),
            backend=backend,
            seed=seed,
            noise=noise,
            options=options,
        )

    def gradient(
        self,
        parameters: ParameterValues,
        *,
        backend: LocalBackend | None = None,
        gradient_index: int = 0,
        objective_evaluation_offset: int = 0,
        max_backend_executions: int | None = None,
        algorithm_run_id: str | None = None,
        seed: int | None = None,
        config: GradientConfig | None = None,
        measurement: PauliMeasurementConfig | None = None,
        noise: NoiseModel | None = None,
        options: SimulationOptions | None = None,
    ) -> ObjectiveGradientIR:
        """Execute an exact or finite-shot parameter-shift VQE gradient."""
        return execute_parameter_shift_gradient(
            algorithm_kind="vqe",
            algorithm_id=str(self.algorithm_id),
            algorithm_run_id=algorithm_run_id,
            gradient_index=gradient_index,
            objective_evaluation_offset=objective_evaluation_offset,
            max_backend_executions=max_backend_executions,
            circuit=self.build_circuit(),
            parameter_names=self.parameter_names,
            parameters=parameters,
            hamiltonian=self.hamiltonian,
            backend=backend,
            seed=seed,
            config=config,
            measurement=measurement,
            noise=noise,
            options=options,
        )

    @overload
    def run(
        self,
        *,
        backend: LocalBackend | None = None,
        optimizer: OptimizerConfig | None = None,
        initial_parameters: ParameterValues | None = None,
        algorithm_run_id: str | None = None,
        final_shots: int = 2048,
        noise: NoiseModel | None = None,
        options: SimulationOptions | None = None,
        measurement: None = None,
        sampled_selection: None = None,
    ) -> VariationalResult[ObjectiveEvaluationIR]: ...

    @overload
    def run(
        self,
        *,
        backend: LocalBackend | None = None,
        optimizer: OptimizerConfig | None = None,
        initial_parameters: ParameterValues | None = None,
        algorithm_run_id: str | None = None,
        final_shots: int = 2048,
        noise: NoiseModel | None = None,
        options: SimulationOptions | None = None,
        measurement: PauliMeasurementConfig,
        sampled_selection: SampledSelectionConfig | None = None,
    ) -> VariationalResult[SampledObjectiveEvaluationIR]: ...

    def run(
        self,
        *,
        backend: LocalBackend | None = None,
        optimizer: OptimizerConfig | None = None,
        initial_parameters: ParameterValues | None = None,
        algorithm_run_id: str | None = None,
        final_shots: int = 2048,
        noise: NoiseModel | None = None,
        options: SimulationOptions | None = None,
        measurement: PauliMeasurementConfig | None = None,
        sampled_selection: SampledSelectionConfig | None = None,
    ) -> VariationalResult[
        Union[  # noqa: UP007 -- Python 3.9 runtime compatibility.
            ObjectiveEvaluationIR, SampledObjectiveEvaluationIR
        ]
    ]:
        """Optimize VQE and final-sample the minimum observed parameters.

        Passing ``measurement`` selects a finite-shot Pauli estimator for every
        SPSA objective or Adam objective/gradient point. The exact estimator
        remains the default.
        """
        return cast(
            VariationalResult[
                Union[ObjectiveEvaluationIR, SampledObjectiveEvaluationIR]
            ],
            run_variational_optimization(
                algorithm_kind="vqe",
                algorithm_id=str(self.algorithm_id),
                layers=self.layers,
                parameter_names=self.parameter_names,
                hamiltonian=self.hamiltonian,
                ansatz=self.ansatz_spec(),
                evaluator=cast(
                    Any,
                    self.evaluate if measurement is None else self.evaluate_sampled,
                ),
                circuit_builder=self.build_circuit,
                gradient_evaluator=self.gradient,
                problem=(
                    self.operator
                    if isinstance(self.operator, (QUBOProblemIR, IsingModelIR))
                    else None
                ),
                backend=backend,
                optimizer=optimizer,
                initial_parameters=initial_parameters,
                algorithm_run_id=algorithm_run_id,
                final_shots=final_shots,
                noise=noise,
                options=options,
                measurement=measurement,
                sampled_selection=sampled_selection,
            ),
        )

    def benchmark_sampling(
        self,
        config: VQESamplingBenchmarkConfig,
        *,
        backend: LocalBackend | None = None,
    ) -> VQESamplingBenchmarkResult:
        """Compare exact and sampled SPSA strategies with paired run facts."""
        return execute_vqe_sampling_benchmark(self, config=config, backend=backend)

    def optimize_layers_repeated(
        self,
        *,
        max_layers: int,
        repeats: int,
        optimizer: OptimizerConfig | None = None,
        confidence_level: float = 0.95,
        min_improvement: float = 0.0,
        patience: int = 1,
        final_shots: int = 2048,
        seed: int = 0,
        backend: LocalBackend | None = None,
        noise: NoiseModel | None = None,
        options: SimulationOptions | None = None,
        measurement: PauliMeasurementConfig | None = None,
        sampled_selection: SampledSelectionConfig | None = None,
    ) -> VQERepeatedLayerExperimentResult:
        """Run paired optimizer repeats and select a supported VQE layer count.

        Repeat ``i`` at layer ``p`` inherits only the best parameters from repeat
        ``i`` at layer ``p - 1``. Selection uses the one-sided Student-t lower
        confidence bound of paired objective decreases; it does not claim that the
        selected depth or parameters are globally optimal.
        """
        from cascaqit.algorithms.optimizer import seeded_initial_point

        if isinstance(self.ansatz, Circuit):
            raise ValueError(
                "optimize_layers_repeated requires a built-in VQE Ansatz; "
                "custom Circuit layer structure is not declared."
            )
        if (
            not isinstance(max_layers, int)
            or isinstance(max_layers, bool)
            or max_layers <= 0
        ):
            raise ValueError("max_layers must be a positive integer.")
        if not isinstance(repeats, int) or isinstance(repeats, bool) or repeats < 2:
            raise ValueError("repeats must be an integer of at least two.")
        config = OptimizerConfig() if optimizer is None else optimizer
        if not isinstance(config, OptimizerConfig):
            raise TypeError("optimizer must be OptimizerConfig or None.")
        if config.seed is not None:
            raise ValueError(
                "optimizer.seed must be None; repeated runs derive their seeds."
            )
        if config.bounds:
            raise ValueError(
                "optimize_layers_repeated does not accept fixed optimizer bounds "
                "because the parameter dimension changes by layer."
            )
        if config.initialization != "random":
            raise ValueError(
                "optimize_layers_repeated manages initialization; "
                "optimizer.initialization must be 'random'."
            )
        if (
            not isinstance(confidence_level, (int, float))
            or isinstance(confidence_level, bool)
            or not math.isfinite(float(confidence_level))
            or not 0.5 < float(confidence_level) < 1.0
        ):
            raise ValueError(
                "confidence_level must be finite, greater than 0.5 and below 1.0."
            )
        if (
            not isinstance(min_improvement, (int, float))
            or isinstance(min_improvement, bool)
            or not math.isfinite(float(min_improvement))
            or float(min_improvement) < 0.0
        ):
            raise ValueError("min_improvement must be a finite non-negative number.")
        if not isinstance(patience, int) or isinstance(patience, bool) or patience <= 0:
            raise ValueError("patience must be a positive integer.")
        if (
            not isinstance(final_shots, int)
            or isinstance(final_shots, bool)
            or final_shots <= 0
        ):
            raise ValueError("final_shots must be a positive integer.")
        if not isinstance(seed, int) or isinstance(seed, bool) or seed < 0:
            raise ValueError("seed must be a non-negative integer.")
        if backend is not None and not isinstance(backend, LocalBackend):
            raise TypeError("backend must be LocalBackend or None.")
        if noise is not None and not isinstance(noise, NoiseModel):
            raise TypeError("noise must be NoiseModel or None.")
        if options is not None and not isinstance(options, SimulationOptions):
            raise TypeError("options must be SimulationOptions or None.")
        if measurement is not None and not isinstance(
            measurement, PauliMeasurementConfig
        ):
            raise TypeError("measurement must be PauliMeasurementConfig or None.")
        if sampled_selection is not None and not isinstance(
            sampled_selection, SampledSelectionConfig
        ):
            raise TypeError("sampled_selection must be SampledSelectionConfig or None.")
        if measurement is not None and sampled_selection is None:
            raise ValueError(
                "sampled repeated VQE requires sampled_selection to avoid "
                "optimizer-history selection bias."
            )
        if sampled_selection is not None and measurement is None:
            raise ValueError("sampled repeated VQE requires finite-shot measurement.")
        if measurement is not None and config.method not in {"SPSA", "ADAM"}:
            raise ValueError("sampled repeated VQE requires SPSA or ADAM.")

        ansatz_definition = self.ansatz
        runs_by_layer: list[tuple[VQERepeatedLayerRunIR, ...]] = []
        statistics: list[VQELayerStatisticsIR] = []
        selected_index = 0
        no_improvement_count = 0
        for layers in range(1, max_layers + 1):
            layer_vqe = VQE(
                self.operator,
                layers=layers,
                ansatz=ansatz_definition,
                algorithm_id=self.algorithm_id,
            )
            layer_runs: list[VQERepeatedLayerRunIR] = []
            for repeat_index in range(repeats):
                run_seed = derive_vqe_layer_run_seed(
                    seed,
                    layers=layers,
                    repeat_index=repeat_index,
                )
                if layers == 1:
                    # 显式使用派生 seed 生成第一层初值，避免理想执行下多个
                    # repeat 因默认参数相同而失去独立重复实验的意义。
                    point = seeded_initial_point(
                        algorithm_kind="vqe",
                        layers=layers,
                        parameter_count=len(layer_vqe.parameter_names),
                        seed=run_seed,
                        bounds=(),
                    )
                    initial_parameters = dict(zip(layer_vqe.parameter_names, point))
                    run_optimizer = replace(config, seed=run_seed)
                else:
                    prior = runs_by_layer[-1][repeat_index].result
                    initial_parameters = transfer_vqe_parameters(
                        prior.ansatz,
                        layer_vqe.ansatz_spec(),
                        prior.selected_evaluation.parameter_bind.values,
                    )
                    run_optimizer = replace(
                        config,
                        seed=run_seed,
                        initialization="layerwise",
                    )
                run_id = (
                    f"{self.algorithm_id}.layers-{layers}."
                    f"repeat-{repeat_index}.seed-{run_seed}"
                )
                result: VariationalResult[Any]
                if measurement is None:
                    result = layer_vqe.run(
                        backend=backend,
                        optimizer=run_optimizer,
                        initial_parameters=initial_parameters,
                        algorithm_run_id=run_id,
                        final_shots=final_shots,
                        noise=noise,
                        options=options,
                    )
                else:
                    assert sampled_selection is not None
                    result = layer_vqe.run(
                        backend=backend,
                        optimizer=run_optimizer,
                        initial_parameters=initial_parameters,
                        algorithm_run_id=run_id,
                        final_shots=final_shots,
                        measurement=measurement,
                        sampled_selection=sampled_selection,
                        noise=noise,
                        options=options,
                    )
                layer_runs.append(
                    VQERepeatedLayerRunIR.create(
                        layers=layers,
                        repeat_index=repeat_index,
                        seed=run_seed,
                        result=result,
                    )
                )
            completed_runs = tuple(layer_runs)
            runs_by_layer.append(completed_runs)
            layer_statistics = VQELayerStatisticsIR.create(
                completed_runs,
                confidence_level=float(confidence_level),
            )
            statistics.append(layer_statistics)
            if layers == 1:
                continue
            comparison = VQEPairedImprovementIR.create(
                statistics[selected_index],
                layer_statistics,
                confidence_level=float(confidence_level),
            )
            lower = comparison.lower_confidence_bound
            material_improvement = lower > 1e-12 and lower >= float(min_improvement)
            if material_improvement:
                selected_index = layers - 1
                no_improvement_count = 0
            else:
                no_improvement_count += 1
                if no_improvement_count >= patience:
                    break

        return build_vqe_repeated_layer_experiment_result(
            runs_by_layer,
            algorithm_id=str(self.algorithm_id),
            optimizer=config,
            max_layers=max_layers,
            repeats=repeats,
            confidence_level=float(confidence_level),
            min_improvement=float(min_improvement),
            patience=patience,
            final_shots=final_shots,
            seed=seed,
            measurement=measurement,
            sampled_selection=sampled_selection,
        )
