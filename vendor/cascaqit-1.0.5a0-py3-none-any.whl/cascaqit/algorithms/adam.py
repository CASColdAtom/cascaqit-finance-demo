"""Native Adam configuration and auditable iteration contracts."""

from __future__ import annotations

import hashlib
import json
import math
import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from types import MappingProxyType
from typing import Any, Literal

import numpy as np

from cascaqit.native_ir.base import IRMixin, stable_json

__all__ = [
    "ADAM_SCHEMA_VERSION",
    "AdamConfig",
    "AdamIterationIR",
    "AdamStoppingConfig",
    "AdamStoppingEvidenceIR",
    "validate_adam_iteration_sequence",
    "validate_adam_stopping_evidence",
]

ADAM_SCHEMA_VERSION = "cascaqit.algorithms.adam.v2"
_DIGEST_PATTERN = re.compile(r"[0-9a-f]{64}")
_TOLERANCE = 1e-12


@dataclass(frozen=True)
class AdamStoppingConfig(IRMixin):
    """Consecutive projected-update threshold used for engineering stopping."""

    window_size: int = 3
    min_iterations: int = 3
    update_norm_tolerance: float = 1e-4
    gradient_uncertainty_norm_tolerance: float | None = None
    schema_version: str = ADAM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_positive_int(self.window_size, "window_size")
        if self.window_size < 2:
            raise ValueError("window_size must be at least 2.")
        _require_positive_int(self.min_iterations, "min_iterations")
        if self.min_iterations < self.window_size:
            raise ValueError("min_iterations must be at least window_size.")
        tolerance = _finite_float(
            self.update_norm_tolerance,
            "update_norm_tolerance",
        )
        if tolerance <= 0.0:
            raise ValueError("update_norm_tolerance must be positive.")
        uncertainty_tolerance = self.gradient_uncertainty_norm_tolerance
        if uncertainty_tolerance is not None:
            uncertainty_tolerance = _finite_float(
                uncertainty_tolerance,
                "gradient_uncertainty_norm_tolerance",
            )
            if uncertainty_tolerance <= 0.0:
                raise ValueError(
                    "gradient_uncertainty_norm_tolerance must be positive."
                )
        _require_schema(self.schema_version)
        object.__setattr__(self, "update_norm_tolerance", tolerance)
        object.__setattr__(
            self,
            "gradient_uncertainty_norm_tolerance",
            uncertainty_tolerance,
        )

    def to_dict(self) -> dict[str, Any]:
        """Omit the optional uncertainty condition when it is disabled."""
        data = super().to_dict()
        if self.gradient_uncertainty_norm_tolerance is None:
            data.pop("gradient_uncertainty_norm_tolerance", None)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> AdamStoppingConfig:
        """Restore Adam stopping settings from JSON-compatible data."""
        return cls(
            window_size=data.get("window_size", 3),
            min_iterations=data.get("min_iterations", 3),
            update_norm_tolerance=data.get("update_norm_tolerance", 1e-4),
            gradient_uncertainty_norm_tolerance=data.get(
                "gradient_uncertainty_norm_tolerance"
            ),
            schema_version=str(data.get("schema_version", ADAM_SCHEMA_VERSION)),
        )

    @classmethod
    def from_json(cls, text: str) -> AdamStoppingConfig:
        """Restore Adam stopping settings from JSON text."""
        return cls.from_dict(_json_object(text, "AdamStoppingConfig"))


@dataclass(frozen=True)
class AdamConfig(IRMixin):
    """Hyperparameters for the native Adam update rule."""

    learning_rate: float = 0.05
    beta1: float = 0.9
    beta2: float = 0.999
    epsilon: float = 1e-8
    stopping: AdamStoppingConfig | None = None
    schema_version: str = ADAM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        learning_rate = _finite_float(self.learning_rate, "learning_rate")
        beta1 = _finite_float(self.beta1, "beta1")
        beta2 = _finite_float(self.beta2, "beta2")
        epsilon = _finite_float(self.epsilon, "epsilon")
        if learning_rate <= 0.0:
            raise ValueError("learning_rate must be positive.")
        if not 0.0 < beta1 < 1.0:
            raise ValueError("beta1 must be strictly between zero and one.")
        if not 0.0 < beta2 < 1.0:
            raise ValueError("beta2 must be strictly between zero and one.")
        if epsilon <= 0.0:
            raise ValueError("epsilon must be positive.")
        if self.stopping is not None and not isinstance(
            self.stopping,
            AdamStoppingConfig,
        ):
            raise TypeError("stopping must be AdamStoppingConfig or None.")
        _require_schema(self.schema_version)
        object.__setattr__(self, "learning_rate", learning_rate)
        object.__setattr__(self, "beta1", beta1)
        object.__setattr__(self, "beta2", beta2)
        object.__setattr__(self, "epsilon", epsilon)

    def to_dict(self) -> dict[str, Any]:
        """Omit the unused stopping field from the compact default payload."""
        data = super().to_dict()
        if self.stopping is None:
            data.pop("stopping", None)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> AdamConfig:
        """Restore Adam hyperparameters from JSON-compatible data."""
        return cls(
            learning_rate=data.get("learning_rate", 0.05),
            beta1=data.get("beta1", 0.9),
            beta2=data.get("beta2", 0.999),
            epsilon=data.get("epsilon", 1e-8),
            stopping=(
                None
                if data.get("stopping") is None
                else AdamStoppingConfig.from_dict(
                    _mapping(data["stopping"], "stopping")
                )
            ),
            schema_version=str(data.get("schema_version", ADAM_SCHEMA_VERSION)),
        )

    @classmethod
    def from_json(cls, text: str) -> AdamConfig:
        """Restore Adam hyperparameters from JSON text."""
        return cls.from_dict(_json_object(text, "AdamConfig"))


@dataclass(frozen=True)
class AdamIterationIR(IRMixin):
    """One self-contained Adam update linked to a complete gradient result."""

    iteration_index: int
    config: AdamConfig
    center_objective_evaluation_index: int
    updated_objective_evaluation_index: int
    center_parameters: Mapping[str, float]
    gradient_index: int
    gradient_hash: str
    gradient: Mapping[str, float]
    gradient_covariance: Mapping[str, Mapping[str, float]]
    gradient_standard_errors: Mapping[str, float]
    gradient_uncertainty_norm: float
    gradient_repeat_count: int
    gradient_repeat_stop_reason: Literal[
        "fixed_repeats",
        "target_reached",
        "max_repeats_reached",
        "evaluation_budget_exhausted",
        "backend_budget_exhausted",
    ]
    previous_first_moment: Mapping[str, float]
    previous_second_moment: Mapping[str, float]
    first_moment: Mapping[str, float]
    second_moment: Mapping[str, float]
    bias_corrected_first_moment: Mapping[str, float]
    bias_corrected_second_moment: Mapping[str, float]
    step: Mapping[str, float]
    bounds: Mapping[str, tuple[float, float]]
    unprojected_parameters: Mapping[str, float]
    updated_parameters: Mapping[str, float]
    update_norm: float
    projection_applied: bool
    gradient_objective_evaluation_count: int
    gradient_backend_execution_count: int
    gradient_total_shots: int
    iteration_hash: str = ""
    schema_version: str = ADAM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_non_negative_int(self.iteration_index, "iteration_index")
        if not isinstance(self.config, AdamConfig):
            raise TypeError("config must be AdamConfig.")
        _require_non_negative_int(
            self.center_objective_evaluation_index,
            "center_objective_evaluation_index",
        )
        _require_non_negative_int(
            self.updated_objective_evaluation_index,
            "updated_objective_evaluation_index",
        )
        if (
            self.updated_objective_evaluation_index
            != self.center_objective_evaluation_index + 1
        ):
            raise ValueError(
                "updated objective index must immediately follow the center."
            )
        _require_non_negative_int(self.gradient_index, "gradient_index")
        _require_digest(self.gradient_hash, "gradient_hash")
        _require_positive_int(
            self.gradient_objective_evaluation_count,
            "gradient_objective_evaluation_count",
        )
        _require_positive_int(
            self.gradient_backend_execution_count,
            "gradient_backend_execution_count",
        )
        _require_non_negative_int(self.gradient_total_shots, "gradient_total_shots")
        _require_positive_int(self.gradient_repeat_count, "gradient_repeat_count")
        if self.gradient_repeat_stop_reason not in {
            "fixed_repeats",
            "target_reached",
            "max_repeats_reached",
            "evaluation_budget_exhausted",
            "backend_budget_exhausted",
        }:
            raise ValueError("unsupported gradient_repeat_stop_reason.")
        _require_schema(self.schema_version)

        mappings = {
            "center_parameters": _finite_parameter_mapping(
                self.center_parameters,
                "center_parameters",
            ),
            "gradient": _finite_parameter_mapping(self.gradient, "gradient"),
            "gradient_standard_errors": _finite_parameter_mapping(
                self.gradient_standard_errors,
                "gradient_standard_errors",
            ),
            "previous_first_moment": _finite_parameter_mapping(
                self.previous_first_moment,
                "previous_first_moment",
            ),
            "previous_second_moment": _finite_parameter_mapping(
                self.previous_second_moment,
                "previous_second_moment",
            ),
            "first_moment": _finite_parameter_mapping(
                self.first_moment,
                "first_moment",
            ),
            "second_moment": _finite_parameter_mapping(
                self.second_moment,
                "second_moment",
            ),
            "bias_corrected_first_moment": _finite_parameter_mapping(
                self.bias_corrected_first_moment,
                "bias_corrected_first_moment",
            ),
            "bias_corrected_second_moment": _finite_parameter_mapping(
                self.bias_corrected_second_moment,
                "bias_corrected_second_moment",
            ),
            "step": _finite_parameter_mapping(self.step, "step"),
            "unprojected_parameters": _finite_parameter_mapping(
                self.unprojected_parameters,
                "unprojected_parameters",
            ),
            "updated_parameters": _finite_parameter_mapping(
                self.updated_parameters,
                "updated_parameters",
            ),
        }
        parameter_names = tuple(mappings["center_parameters"])
        if not parameter_names or any(
            tuple(values) != parameter_names for values in mappings.values()
        ):
            raise ValueError("all Adam parameter mappings must share ordered keys.")
        if any(
            mappings[name][parameter] < 0.0
            for name in (
                "gradient_standard_errors",
                "previous_second_moment",
                "second_moment",
                "bias_corrected_second_moment",
            )
            for parameter in parameter_names
        ):
            raise ValueError("Adam errors and second moments must be non-negative.")

        covariance = _gradient_covariance(
            self.gradient_covariance,
            parameter_names,
        )
        for name in parameter_names:
            expected_error = math.sqrt(max(0.0, covariance[name][name]))
            if not math.isclose(
                mappings["gradient_standard_errors"][name],
                expected_error,
                rel_tol=0.0,
                abs_tol=_TOLERANCE,
            ):
                raise ValueError(
                    "gradient_standard_errors must match covariance diagonal."
                )
        expected_uncertainty_norm = math.sqrt(
            math.fsum(covariance[name][name] for name in parameter_names)
        )
        uncertainty_norm = _finite_non_negative_float(
            self.gradient_uncertainty_norm,
            "gradient_uncertainty_norm",
        )
        if not math.isclose(
            uncertainty_norm,
            expected_uncertainty_norm,
            rel_tol=0.0,
            abs_tol=_TOLERANCE,
        ):
            raise ValueError(
                "gradient_uncertainty_norm must equal sqrt(trace(covariance))."
            )

        beta1 = self.config.beta1
        beta2 = self.config.beta2
        step_number = self.iteration_index + 1
        expected_first = {
            name: beta1 * mappings["previous_first_moment"][name]
            + (1.0 - beta1) * mappings["gradient"][name]
            for name in parameter_names
        }
        expected_second = {
            name: beta2 * mappings["previous_second_moment"][name]
            + (1.0 - beta2) * mappings["gradient"][name] ** 2
            for name in parameter_names
        }
        first_denominator = 1.0 - beta1**step_number
        second_denominator = 1.0 - beta2**step_number
        expected_corrected_first = {
            name: expected_first[name] / first_denominator for name in parameter_names
        }
        expected_corrected_second = {
            name: expected_second[name] / second_denominator for name in parameter_names
        }
        expected_step = {
            name: self.config.learning_rate
            * expected_corrected_first[name]
            / (math.sqrt(expected_corrected_second[name]) + self.config.epsilon)
            for name in parameter_names
        }
        expected_unprojected = {
            name: mappings["center_parameters"][name] - expected_step[name]
            for name in parameter_names
        }
        for field_name, expected in (
            ("first_moment", expected_first),
            ("second_moment", expected_second),
            ("bias_corrected_first_moment", expected_corrected_first),
            ("bias_corrected_second_moment", expected_corrected_second),
            ("step", expected_step),
            ("unprojected_parameters", expected_unprojected),
        ):
            _require_mapping_close(mappings[field_name], expected, field_name)

        bounds = _bounds_mapping(self.bounds, parameter_names)
        expected_updated = {
            name: (
                expected_unprojected[name]
                if not bounds
                else min(
                    max(expected_unprojected[name], bounds[name][0]),
                    bounds[name][1],
                )
            )
            for name in parameter_names
        }
        _require_mapping_close(
            mappings["updated_parameters"],
            expected_updated,
            "updated_parameters",
        )
        expected_projection = any(
            expected_updated[name] != expected_unprojected[name]
            for name in parameter_names
        )
        if not isinstance(self.projection_applied, bool):
            raise TypeError("projection_applied must be bool.")
        if self.projection_applied != expected_projection:
            raise ValueError("projection_applied must match bounds projection.")
        expected_norm = math.sqrt(
            math.fsum(
                (expected_updated[name] - mappings["center_parameters"][name]) ** 2
                for name in parameter_names
            )
        )
        update_norm = _finite_float(self.update_norm, "update_norm")
        if update_norm < 0.0 or not math.isclose(
            update_norm,
            expected_norm,
            rel_tol=0.0,
            abs_tol=_TOLERANCE,
        ):
            raise ValueError("update_norm must match the projected Adam update.")

        for name, values in mappings.items():
            object.__setattr__(self, name, values)
        object.__setattr__(self, "gradient_covariance", covariance)
        object.__setattr__(self, "gradient_uncertainty_norm", uncertainty_norm)
        object.__setattr__(self, "bounds", bounds)
        object.__setattr__(self, "update_norm", update_norm)
        if not self.iteration_hash:
            object.__setattr__(self, "iteration_hash", self.compute_iteration_hash())
        else:
            _require_digest(self.iteration_hash, "iteration_hash")
            if not self.verify_hash():
                raise ValueError("iteration_hash does not match Adam iteration facts.")

    @classmethod
    def create(
        cls,
        *,
        iteration_index: int,
        config: AdamConfig,
        center_objective_evaluation_index: int,
        updated_objective_evaluation_index: int,
        center_parameters: Mapping[str, float],
        gradient_index: int,
        gradient_hash: str,
        gradient: Mapping[str, float],
        gradient_covariance: Mapping[str, Mapping[str, float]],
        gradient_standard_errors: Mapping[str, float],
        gradient_uncertainty_norm: float,
        gradient_repeat_count: int,
        gradient_repeat_stop_reason: Literal[
            "fixed_repeats",
            "target_reached",
            "max_repeats_reached",
            "evaluation_budget_exhausted",
            "backend_budget_exhausted",
        ],
        previous_first_moment: Mapping[str, float],
        previous_second_moment: Mapping[str, float],
        bounds: Mapping[str, tuple[float, float]],
        gradient_objective_evaluation_count: int,
        gradient_backend_execution_count: int,
        gradient_total_shots: int,
    ) -> AdamIterationIR:
        """Compute one complete Adam update from saved gradient facts."""
        names = tuple(center_parameters)
        beta1 = config.beta1
        beta2 = config.beta2
        step_number = iteration_index + 1
        first = {
            name: beta1 * previous_first_moment[name] + (1.0 - beta1) * gradient[name]
            for name in names
        }
        second = {
            name: beta2 * previous_second_moment[name]
            + (1.0 - beta2) * gradient[name] ** 2
            for name in names
        }
        corrected_first = {
            name: first[name] / (1.0 - beta1**step_number) for name in names
        }
        corrected_second = {
            name: second[name] / (1.0 - beta2**step_number) for name in names
        }
        step = {
            name: config.learning_rate
            * corrected_first[name]
            / (math.sqrt(corrected_second[name]) + config.epsilon)
            for name in names
        }
        unprojected = {name: center_parameters[name] - step[name] for name in names}
        updated = {
            name: (
                unprojected[name]
                if not bounds
                else min(max(unprojected[name], bounds[name][0]), bounds[name][1])
            )
            for name in names
        }
        return cls(
            iteration_index=iteration_index,
            config=config,
            center_objective_evaluation_index=center_objective_evaluation_index,
            updated_objective_evaluation_index=updated_objective_evaluation_index,
            center_parameters=center_parameters,
            gradient_index=gradient_index,
            gradient_hash=gradient_hash,
            gradient=gradient,
            gradient_covariance=gradient_covariance,
            gradient_standard_errors=gradient_standard_errors,
            gradient_uncertainty_norm=gradient_uncertainty_norm,
            gradient_repeat_count=gradient_repeat_count,
            gradient_repeat_stop_reason=gradient_repeat_stop_reason,
            previous_first_moment=previous_first_moment,
            previous_second_moment=previous_second_moment,
            first_moment=first,
            second_moment=second,
            bias_corrected_first_moment=corrected_first,
            bias_corrected_second_moment=corrected_second,
            step=step,
            bounds=bounds,
            unprojected_parameters=unprojected,
            updated_parameters=updated,
            update_norm=math.sqrt(
                math.fsum(
                    (updated[name] - center_parameters[name]) ** 2 for name in names
                )
            ),
            projection_applied=any(
                updated[name] != unprojected[name] for name in names
            ),
            gradient_objective_evaluation_count=(gradient_objective_evaluation_count),
            gradient_backend_execution_count=gradient_backend_execution_count,
            gradient_total_shots=gradient_total_shots,
        )

    def compute_iteration_hash(self) -> str:
        """Hash every saved Adam fact except the embedded hash itself."""
        return hashlib.sha256(
            stable_json(self._hash_payload()).encode("utf-8")
        ).hexdigest()

    def verify_hash(self) -> bool:
        """Return whether the embedded hash matches the iteration facts."""
        return self.iteration_hash == self.compute_iteration_hash()

    def _hash_payload(self) -> dict[str, Any]:
        return {
            "iteration_index": self.iteration_index,
            "config": self.config,
            "center_objective_evaluation_index": (
                self.center_objective_evaluation_index
            ),
            "updated_objective_evaluation_index": (
                self.updated_objective_evaluation_index
            ),
            "center_parameters": self.center_parameters,
            "gradient_index": self.gradient_index,
            "gradient_hash": self.gradient_hash,
            "gradient": self.gradient,
            "gradient_covariance": self.gradient_covariance,
            "gradient_standard_errors": self.gradient_standard_errors,
            "gradient_uncertainty_norm": self.gradient_uncertainty_norm,
            "gradient_repeat_count": self.gradient_repeat_count,
            "gradient_repeat_stop_reason": self.gradient_repeat_stop_reason,
            "previous_first_moment": self.previous_first_moment,
            "previous_second_moment": self.previous_second_moment,
            "first_moment": self.first_moment,
            "second_moment": self.second_moment,
            "bias_corrected_first_moment": self.bias_corrected_first_moment,
            "bias_corrected_second_moment": self.bias_corrected_second_moment,
            "step": self.step,
            "bounds": self.bounds,
            "unprojected_parameters": self.unprojected_parameters,
            "updated_parameters": self.updated_parameters,
            "update_norm": self.update_norm,
            "projection_applied": self.projection_applied,
            "gradient_objective_evaluation_count": (
                self.gradient_objective_evaluation_count
            ),
            "gradient_backend_execution_count": (self.gradient_backend_execution_count),
            "gradient_total_shots": self.gradient_total_shots,
            "schema_version": self.schema_version,
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> AdamIterationIR:
        """Restore and recompute one complete Adam update."""
        return cls(
            iteration_index=data["iteration_index"],
            config=AdamConfig.from_dict(_mapping(data["config"], "config")),
            center_objective_evaluation_index=data["center_objective_evaluation_index"],
            updated_objective_evaluation_index=data[
                "updated_objective_evaluation_index"
            ],
            center_parameters=_mapping(
                data["center_parameters"],
                "center_parameters",
            ),
            gradient_index=data["gradient_index"],
            gradient_hash=data["gradient_hash"],
            gradient=_mapping(data["gradient"], "gradient"),
            gradient_covariance=_mapping(
                data["gradient_covariance"],
                "gradient_covariance",
            ),
            gradient_standard_errors=_mapping(
                data["gradient_standard_errors"],
                "gradient_standard_errors",
            ),
            gradient_uncertainty_norm=data["gradient_uncertainty_norm"],
            gradient_repeat_count=data["gradient_repeat_count"],
            gradient_repeat_stop_reason=data["gradient_repeat_stop_reason"],
            previous_first_moment=_mapping(
                data["previous_first_moment"],
                "previous_first_moment",
            ),
            previous_second_moment=_mapping(
                data["previous_second_moment"],
                "previous_second_moment",
            ),
            first_moment=_mapping(data["first_moment"], "first_moment"),
            second_moment=_mapping(data["second_moment"], "second_moment"),
            bias_corrected_first_moment=_mapping(
                data["bias_corrected_first_moment"],
                "bias_corrected_first_moment",
            ),
            bias_corrected_second_moment=_mapping(
                data["bias_corrected_second_moment"],
                "bias_corrected_second_moment",
            ),
            step=_mapping(data["step"], "step"),
            bounds=_mapping(data["bounds"], "bounds"),
            unprojected_parameters=_mapping(
                data["unprojected_parameters"],
                "unprojected_parameters",
            ),
            updated_parameters=_mapping(
                data["updated_parameters"],
                "updated_parameters",
            ),
            update_norm=data["update_norm"],
            projection_applied=data["projection_applied"],
            gradient_objective_evaluation_count=data[
                "gradient_objective_evaluation_count"
            ],
            gradient_backend_execution_count=data["gradient_backend_execution_count"],
            gradient_total_shots=data["gradient_total_shots"],
            iteration_hash=data["iteration_hash"],
            schema_version=str(data.get("schema_version", ADAM_SCHEMA_VERSION)),
        )

    @classmethod
    def from_json(cls, text: str) -> AdamIterationIR:
        """Restore one Adam update from JSON text."""
        return cls.from_dict(_json_object(text, "AdamIterationIR"))


@dataclass(frozen=True)
class AdamStoppingEvidenceIR(IRMixin):
    """Last consecutive-window decision derived from Adam updates."""

    config: AdamStoppingConfig
    status: Literal[
        "insufficient_evidence",
        "threshold_not_met",
        "stability_reached",
    ]
    window_iteration_indices: tuple[int, ...]
    update_norms: tuple[float, ...]
    gradient_uncertainty_norms: tuple[float, ...]
    gradient_repeat_counts: tuple[int, ...]
    gradient_repeat_stop_reasons: tuple[str, ...]
    evidence_hash: str = ""
    schema_version: str = ADAM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if not isinstance(self.config, AdamStoppingConfig):
            raise TypeError("config must be AdamStoppingConfig.")
        indices = tuple(self.window_iteration_indices)
        if not indices:
            raise ValueError("window_iteration_indices must not be empty.")
        if any(
            not isinstance(value, int) or isinstance(value, bool) or value < 0
            for value in indices
        ):
            raise ValueError("window_iteration_indices must be non-negative integers.")
        if indices != tuple(range(indices[0], indices[-1] + 1)):
            raise ValueError("window_iteration_indices must be contiguous.")
        norms = tuple(
            _finite_non_negative_float(value, "update_norm")
            for value in self.update_norms
        )
        if len(norms) != len(indices):
            raise ValueError("update_norms must match window_iteration_indices.")
        uncertainty_norms = tuple(
            _finite_non_negative_float(value, "gradient_uncertainty_norm")
            for value in self.gradient_uncertainty_norms
        )
        repeat_counts = tuple(self.gradient_repeat_counts)
        repeat_reasons = tuple(self.gradient_repeat_stop_reasons)
        if not (
            len(uncertainty_norms)
            == len(repeat_counts)
            == len(repeat_reasons)
            == len(indices)
        ):
            raise ValueError("gradient stopping facts must match the window.")
        for value in repeat_counts:
            _require_positive_int(value, "gradient_repeat_count")
        allowed_reasons = {
            "fixed_repeats",
            "target_reached",
            "max_repeats_reached",
            "evaluation_budget_exhausted",
            "backend_budget_exhausted",
        }
        if any(reason not in allowed_reasons for reason in repeat_reasons):
            raise ValueError("unsupported gradient repeat stop reason.")
        if len(indices) > self.config.window_size:
            raise ValueError("stopping window exceeds configured window_size.")
        completed_iterations = indices[-1] + 1
        enough = (
            completed_iterations >= self.config.min_iterations
            and len(indices) == self.config.window_size
        )
        expected_status: Literal[
            "insufficient_evidence",
            "threshold_not_met",
            "stability_reached",
        ]
        if not enough:
            expected_status = "insufficient_evidence"
        elif all(
            value <= self.config.update_norm_tolerance for value in norms
        ) and (
            self.config.gradient_uncertainty_norm_tolerance is None
            or all(
                value <= self.config.gradient_uncertainty_norm_tolerance
                for value in uncertainty_norms
            )
        ):
            expected_status = "stability_reached"
        else:
            expected_status = "threshold_not_met"
        if self.status != expected_status:
            raise ValueError("Adam stopping status does not match update norms.")
        _require_schema(self.schema_version)
        object.__setattr__(self, "window_iteration_indices", indices)
        object.__setattr__(self, "update_norms", norms)
        object.__setattr__(self, "gradient_uncertainty_norms", uncertainty_norms)
        object.__setattr__(self, "gradient_repeat_counts", repeat_counts)
        object.__setattr__(self, "gradient_repeat_stop_reasons", repeat_reasons)
        if not self.evidence_hash:
            object.__setattr__(self, "evidence_hash", self.compute_evidence_hash())
        else:
            _require_digest(self.evidence_hash, "evidence_hash")
            if not self.verify_hash():
                raise ValueError("evidence_hash does not match Adam stopping facts.")

    @classmethod
    def create(
        cls,
        iterations: Sequence[AdamIterationIR],
        config: AdamStoppingConfig,
    ) -> AdamStoppingEvidenceIR:
        """Derive the latest stopping window from completed iterations."""
        values = validate_adam_iteration_sequence(iterations)
        if not isinstance(config, AdamStoppingConfig):
            raise TypeError("config must be AdamStoppingConfig.")
        window = values[-config.window_size :]
        completed = len(values) >= config.min_iterations
        status: Literal[
            "insufficient_evidence",
            "threshold_not_met",
            "stability_reached",
        ]
        if not completed or len(window) < config.window_size:
            status = "insufficient_evidence"
        elif all(
            item.update_norm <= config.update_norm_tolerance for item in window
        ) and (
            config.gradient_uncertainty_norm_tolerance is None
            or all(
                item.gradient_uncertainty_norm
                <= config.gradient_uncertainty_norm_tolerance
                for item in window
            )
        ):
            status = "stability_reached"
        else:
            status = "threshold_not_met"
        return cls(
            config=config,
            status=status,
            window_iteration_indices=tuple(item.iteration_index for item in window),
            update_norms=tuple(item.update_norm for item in window),
            gradient_uncertainty_norms=tuple(
                item.gradient_uncertainty_norm for item in window
            ),
            gradient_repeat_counts=tuple(item.gradient_repeat_count for item in window),
            gradient_repeat_stop_reasons=tuple(
                item.gradient_repeat_stop_reason for item in window
            ),
        )

    def compute_evidence_hash(self) -> str:
        """Hash all stopping facts except the embedded hash."""
        return hashlib.sha256(
            stable_json(
                {
                    "config": self.config,
                    "status": self.status,
                    "window_iteration_indices": self.window_iteration_indices,
                    "update_norms": self.update_norms,
                    "gradient_uncertainty_norms": self.gradient_uncertainty_norms,
                    "gradient_repeat_counts": self.gradient_repeat_counts,
                    "gradient_repeat_stop_reasons": (
                        self.gradient_repeat_stop_reasons
                    ),
                    "schema_version": self.schema_version,
                }
            ).encode("utf-8")
        ).hexdigest()

    def verify_hash(self) -> bool:
        """Return whether the embedded hash matches stopping evidence."""
        return self.evidence_hash == self.compute_evidence_hash()

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> AdamStoppingEvidenceIR:
        """Restore one stopping decision from JSON-compatible data."""
        return cls(
            config=AdamStoppingConfig.from_dict(_mapping(data["config"], "config")),
            status=data["status"],
            window_iteration_indices=tuple(
                _sequence(
                    data["window_iteration_indices"],
                    "window_iteration_indices",
                )
            ),
            update_norms=tuple(_sequence(data["update_norms"], "update_norms")),
            gradient_uncertainty_norms=tuple(
                _sequence(
                    data["gradient_uncertainty_norms"],
                    "gradient_uncertainty_norms",
                )
            ),
            gradient_repeat_counts=tuple(
                _sequence(data["gradient_repeat_counts"], "gradient_repeat_counts")
            ),
            gradient_repeat_stop_reasons=tuple(
                str(item)
                for item in _sequence(
                    data["gradient_repeat_stop_reasons"],
                    "gradient_repeat_stop_reasons",
                )
            ),
            evidence_hash=data["evidence_hash"],
            schema_version=str(data.get("schema_version", ADAM_SCHEMA_VERSION)),
        )

    @classmethod
    def from_json(cls, text: str) -> AdamStoppingEvidenceIR:
        """Restore one stopping decision from JSON text."""
        return cls.from_dict(_json_object(text, "AdamStoppingEvidenceIR"))


def validate_adam_iteration_sequence(
    iterations: Sequence[AdamIterationIR],
) -> tuple[AdamIterationIR, ...]:
    """Replay cross-iteration moment, parameter, objective, and gradient links."""
    values = tuple(iterations)
    if not values or any(not isinstance(item, AdamIterationIR) for item in values):
        raise ValueError("iterations must contain AdamIterationIR values.")
    if tuple(item.iteration_index for item in values) != tuple(range(len(values))):
        raise ValueError("Adam iteration indices must be contiguous and zero-based.")
    first = values[0]
    if any(value != 0.0 for value in first.previous_first_moment.values()) or any(
        value != 0.0 for value in first.previous_second_moment.values()
    ):
        raise ValueError("the first Adam iteration must start from zero moments.")
    gradient_start = first.gradient_index
    objective_start = first.center_objective_evaluation_index
    for index, item in enumerate(values):
        if item.config != first.config or item.bounds != first.bounds:
            raise ValueError("all Adam iterations must share config and bounds.")
        if item.gradient_index != gradient_start + index:
            raise ValueError("Adam gradient indices must be contiguous.")
        if item.center_objective_evaluation_index != objective_start + index:
            raise ValueError("Adam center objective indices must be contiguous.")
        if index == 0:
            continue
        previous = values[index - 1]
        _require_mapping_close(
            item.center_parameters,
            previous.updated_parameters,
            "Adam center parameter linkage",
        )
        _require_mapping_close(
            item.previous_first_moment,
            previous.first_moment,
            "Adam first moment linkage",
        )
        _require_mapping_close(
            item.previous_second_moment,
            previous.second_moment,
            "Adam second moment linkage",
        )
    return values


def validate_adam_stopping_evidence(
    evidence: AdamStoppingEvidenceIR,
    iterations: Sequence[AdamIterationIR],
) -> None:
    """Recompute stopping evidence against the saved iteration sequence."""
    if not isinstance(evidence, AdamStoppingEvidenceIR):
        raise TypeError("evidence must be AdamStoppingEvidenceIR.")
    expected = AdamStoppingEvidenceIR.create(iterations, evidence.config)
    if evidence != expected:
        raise ValueError("Adam stopping evidence does not match iterations.")


def _finite_parameter_mapping(
    value: object,
    name: str,
) -> Mapping[str, float]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{name} must be a mapping.")
    normalized: dict[str, float] = {}
    for raw_name, raw_value in value.items():
        parameter = str(raw_name)
        _require_text(parameter, f"{name} key")
        normalized[parameter] = _finite_float(
            raw_value,
            f"{name}[{parameter}]",
        )
    return MappingProxyType(normalized)


def _gradient_covariance(
    value: object,
    parameter_names: tuple[str, ...],
) -> Mapping[str, Mapping[str, float]]:
    if not isinstance(value, Mapping):
        raise TypeError("gradient_covariance must be a mapping.")
    rows: dict[str, Mapping[str, float]] = {}
    for name in parameter_names:
        if name not in value:
            raise ValueError("gradient_covariance must cover every parameter.")
        row = _finite_parameter_mapping(
            value[name],
            f"gradient_covariance[{name}]",
        )
        if tuple(row) != parameter_names:
            raise ValueError("gradient covariance rows must share parameter order.")
        rows[name] = row
    if set(value) != set(parameter_names):
        raise ValueError("gradient_covariance contains unknown parameters.")
    for row_name in parameter_names:
        for column_name in parameter_names:
            if not math.isclose(
                rows[row_name][column_name],
                rows[column_name][row_name],
                rel_tol=0.0,
                abs_tol=_TOLERANCE,
            ):
                raise ValueError("gradient_covariance must be symmetric.")
    matrix = np.asarray(
        [[rows[row][column] for column in parameter_names] for row in parameter_names],
        dtype=np.float64,
    )
    if float(np.min(np.linalg.eigvalsh(matrix))) < -_TOLERANCE:
        raise ValueError("gradient_covariance must be positive semidefinite.")
    return MappingProxyType(rows)


def _bounds_mapping(
    value: object,
    parameter_names: tuple[str, ...],
) -> Mapping[str, tuple[float, float]]:
    if not isinstance(value, Mapping):
        raise TypeError("bounds must be a mapping.")
    if not value:
        return MappingProxyType({})
    if tuple(str(name) for name in value) != parameter_names:
        raise ValueError("bounds must follow the Adam parameter order.")
    normalized: dict[str, tuple[float, float]] = {}
    for name in parameter_names:
        raw = value[name]
        if not isinstance(raw, (list, tuple)) or len(raw) != 2:
            raise TypeError(f"bounds[{name}] must contain lower and upper values.")
        lower = _finite_float(raw[0], f"bounds[{name}].lower")
        upper = _finite_float(raw[1], f"bounds[{name}].upper")
        if lower >= upper:
            raise ValueError(f"bounds[{name}] lower must be less than upper.")
        normalized[name] = (lower, upper)
    return MappingProxyType(normalized)


def _require_mapping_close(
    actual: Mapping[str, float],
    expected: Mapping[str, float],
    name: str,
) -> None:
    if tuple(actual) != tuple(expected) or any(
        not math.isclose(actual[key], expected[key], rel_tol=0.0, abs_tol=_TOLERANCE)
        for key in expected
    ):
        raise ValueError(f"{name} does not match reconstructed values.")


def _finite_float(value: object, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{name} must be a real number.")
    normalized = float(value)
    if not math.isfinite(normalized):
        raise ValueError(f"{name} must be finite.")
    return normalized


def _finite_non_negative_float(value: object, name: str) -> float:
    normalized = _finite_float(value, name)
    if normalized < 0.0:
        raise ValueError(f"{name} must be non-negative.")
    return normalized


def _require_positive_int(value: object, name: str) -> None:
    if not isinstance(value, int) or isinstance(value, bool) or value <= 0:
        raise ValueError(f"{name} must be a positive integer.")


def _require_non_negative_int(value: object, name: str) -> None:
    if not isinstance(value, int) or isinstance(value, bool) or value < 0:
        raise ValueError(f"{name} must be a non-negative integer.")


def _require_text(value: object, name: str) -> None:
    if not isinstance(value, str) or not value.strip() or value != value.strip():
        raise ValueError(f"{name} must be a non-empty trimmed string.")


def _require_digest(value: object, name: str) -> None:
    if not isinstance(value, str) or _DIGEST_PATTERN.fullmatch(value) is None:
        raise ValueError(f"{name} must be a lowercase SHA-256 digest.")


def _require_schema(value: object) -> None:
    if value != ADAM_SCHEMA_VERSION:
        raise ValueError(f"Unsupported Adam schema version: {value!r}.")


def _mapping(value: object, name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{name} must be an object.")
    return value


def _sequence(value: object, name: str) -> tuple[Any, ...]:
    if not isinstance(value, (list, tuple)):
        raise TypeError(f"{name} must be an array.")
    return tuple(value)


def _json_object(text: str, name: str) -> Mapping[str, Any]:
    data = json.loads(text)
    if not isinstance(data, dict):
        raise TypeError(f"{name} JSON must contain an object.")
    return data
