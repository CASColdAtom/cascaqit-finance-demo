"""Paired benchmark for exact and finite-shot VQE objective strategies."""

from __future__ import annotations

import hashlib
import json
import math
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, replace
from os import PathLike
from typing import TYPE_CHECKING, Any, Literal, cast

from cascaqit.algorithms._layer_statistics import (
    confidence_level as _confidence_level,
)
from cascaqit.algorithms._layer_statistics import derive_layer_run_seed, sample_summary
from cascaqit.algorithms.measurement import (
    PauliMeasurementConfig,
    SampledObjectiveEvaluationIR,
    build_pauli_measurement_plan,
)
from cascaqit.algorithms.models import (
    ObjectiveEvaluationIR,
    OptimizerConfig,
    SPSAConfig,
    VariationalResult,
)
from cascaqit.algorithms.optimizer import seeded_initial_point
from cascaqit.algorithms.sampled_selection import SampledSelectionConfig
from cascaqit.native_ir.base import IRMixin, stable_json
from cascaqit.simulators import LocalBackend

if TYPE_CHECKING:
    from cascaqit.algorithms.vqe import VQE
    from cascaqit.visualization import ExperimentReport

__all__ = [
    "VQE_SAMPLING_BENCHMARK_SCHEMA_VERSION",
    "VQESamplingBenchmarkConfig",
    "VQESamplingBenchmarkResult",
    "VQESamplingBenchmarkRunIR",
    "VQESamplingStrategyStatisticsIR",
    "execute_vqe_sampling_benchmark",
]

VQE_SAMPLING_BENCHMARK_SCHEMA_VERSION = "cascaqit.algorithms.vqe_sampling_benchmark.v1"
VQESamplingStrategy = Literal[
    "exact",
    "sampled_single",
    "sampled_fixed",
    "sampled_adaptive",
]
VQE_SAMPLING_STRATEGIES: tuple[VQESamplingStrategy, ...] = (
    "exact",
    "sampled_single",
    "sampled_fixed",
    "sampled_adaptive",
)
_FLOAT_TOLERANCE = 1e-12


@dataclass(frozen=True)
class VQESamplingBenchmarkConfig(IRMixin):
    """Freeze the paired VQE benchmark workload and statistical settings."""

    repeats: int
    objective_evaluation_budget: int
    optimizer: OptimizerConfig
    measurement: PauliMeasurementConfig
    sampled_selection: SampledSelectionConfig
    fixed_objective_repeats: int = 2
    adaptive_objective_repeats: int = 2
    adaptive_max_objective_repeats: int = 4
    adaptive_standard_error_target: float = 0.05
    final_shots: int = 1024
    confidence_level: float = 0.95
    root_seed: int = 0
    schema_version: str = VQE_SAMPLING_BENCHMARK_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _integer_at_least(self.repeats, "repeats", 2)
        _positive_int(self.objective_evaluation_budget, "objective_evaluation_budget")
        if not isinstance(self.optimizer, OptimizerConfig):
            raise TypeError("optimizer must be OptimizerConfig.")
        if self.optimizer.method != "SPSA":
            raise ValueError("VQE sampling benchmark requires SPSA.")
        if self.optimizer.starts != 1:
            raise ValueError("benchmark optimizer starts must be one.")
        if self.optimizer.seed is not None:
            raise ValueError("benchmark optimizer seed must be None.")
        if self.optimizer.initialization != "random":
            raise ValueError("benchmark optimizer initialization must be random.")
        if (
            self.optimizer.max_evaluations is not None
            or self.optimizer.max_backend_executions is not None
        ):
            raise ValueError(
                "benchmark manages optimizer evaluation and Backend budgets."
            )
        spsa = self.optimizer.spsa
        if spsa is None or spsa.objective_repeats != 1:
            raise ValueError("benchmark base SPSA must use one objective repeat.")
        if spsa.objective_repeat_mode != "fixed":
            raise ValueError("benchmark base SPSA must not configure adaptive repeats.")
        if not isinstance(self.measurement, PauliMeasurementConfig):
            raise TypeError("measurement must be PauliMeasurementConfig.")
        if not isinstance(self.sampled_selection, SampledSelectionConfig):
            raise TypeError("sampled_selection must be SampledSelectionConfig.")
        _integer_at_least(
            self.fixed_objective_repeats,
            "fixed_objective_repeats",
            2,
        )
        _integer_at_least(
            self.adaptive_objective_repeats,
            "adaptive_objective_repeats",
            2,
        )
        if (
            not isinstance(self.adaptive_max_objective_repeats, int)
            or isinstance(self.adaptive_max_objective_repeats, bool)
            or self.adaptive_max_objective_repeats <= self.adaptive_objective_repeats
        ):
            raise ValueError(
                "adaptive_max_objective_repeats must exceed the adaptive minimum."
            )
        target = _finite(
            self.adaptive_standard_error_target,
            "adaptive_standard_error_target",
        )
        if target <= 0.0:
            raise ValueError("adaptive_standard_error_target must be positive.")
        object.__setattr__(self, "adaptive_standard_error_target", target)
        minimum_budget = 4 * max(
            self.fixed_objective_repeats,
            self.adaptive_objective_repeats,
        )
        if self.objective_evaluation_budget < minimum_budget:
            raise ValueError(
                "objective_evaluation_budget must cover the largest minimum "
                f"SPSA sequence ({minimum_budget} evaluations)."
            )
        _positive_int(self.final_shots, "final_shots")
        object.__setattr__(
            self,
            "confidence_level",
            _confidence_level(self.confidence_level),
        )
        _non_negative_int(self.root_seed, "root_seed")
        _require_schema(self.schema_version)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> VQESamplingBenchmarkConfig:
        """Restore and revalidate a benchmark configuration."""
        return cls(
            repeats=data["repeats"],
            objective_evaluation_budget=data["objective_evaluation_budget"],
            optimizer=OptimizerConfig.from_dict(
                _mapping(data["optimizer"], "optimizer")
            ),
            measurement=PauliMeasurementConfig.from_dict(
                _mapping(data["measurement"], "measurement")
            ),
            sampled_selection=SampledSelectionConfig.from_dict(
                _mapping(data["sampled_selection"], "sampled_selection")
            ),
            fixed_objective_repeats=data.get("fixed_objective_repeats", 2),
            adaptive_objective_repeats=data.get("adaptive_objective_repeats", 2),
            adaptive_max_objective_repeats=data.get(
                "adaptive_max_objective_repeats", 4
            ),
            adaptive_standard_error_target=data.get(
                "adaptive_standard_error_target", 0.05
            ),
            final_shots=data.get("final_shots", 1024),
            confidence_level=data.get("confidence_level", 0.95),
            root_seed=data.get("root_seed", 0),
            schema_version=str(
                data.get("schema_version", VQE_SAMPLING_BENCHMARK_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> VQESamplingBenchmarkConfig:
        """Restore a benchmark configuration from JSON."""
        return cls.from_dict(_json_object(text, "VQESamplingBenchmarkConfig"))


@dataclass(frozen=True)
class VQESamplingBenchmarkRunIR(IRMixin):
    """One strategy run and its independently checked selected energy."""

    run_id: str
    strategy: VQESamplingStrategy
    repeat_index: int
    paired_seed: int
    result: VariationalResult[Any]
    exact_check: ObjectiveEvaluationIR | None
    selected_estimator_energy: float
    exact_selected_energy: float
    exact_reference_energy: float
    estimator_error: float | None
    paired_exact_reference_gap: float
    objective_evaluation_count: int
    objective_backend_execution_count: int
    objective_shots: int
    confirmation_backend_execution_count: int
    confirmation_shots: int
    final_sampling_backend_execution_count: int
    final_sampling_shots: int
    diagnostic_exact_backend_execution_count: int
    objective_budget_utilization: float
    schema_version: str = VQE_SAMPLING_BENCHMARK_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_schema(self.schema_version)
        if self.strategy not in VQE_SAMPLING_STRATEGIES:
            raise ValueError(f"Unsupported VQE sampling strategy: {self.strategy!r}.")
        _non_negative_int(self.repeat_index, "repeat_index")
        _non_negative_int(self.paired_seed, "paired_seed")
        if not isinstance(self.result, VariationalResult):
            raise TypeError("result must be VariationalResult.")
        if self.result.algorithm_kind != "vqe":
            raise ValueError("sampling benchmark runs require VQE results.")
        if self.result.optimizer.seed != self.paired_seed:
            raise ValueError("result optimizer seed must match paired_seed.")
        sampled = isinstance(self.result.evaluations[0], SampledObjectiveEvaluationIR)
        if sampled != (self.strategy != "exact"):
            raise ValueError("strategy does not match the result objective estimator.")
        expected_spsa = _strategy_spsa(self.strategy, self.result.optimizer.spsa)
        if expected_spsa is not None:
            _validate_strategy_spsa(self.strategy, expected_spsa)
        expected_estimator = _selected_estimator_energy(self.result)
        _require_close(
            self.selected_estimator_energy,
            expected_estimator,
            "selected_estimator_energy",
        )
        if self.strategy == "exact":
            if self.exact_check is not None:
                raise ValueError("exact reference runs do not require an exact check.")
            if self.estimator_error is not None:
                raise ValueError("exact reference estimator_error must be None.")
            expected_exact = expected_estimator
            expected_diagnostic_cost = 0
        else:
            if not isinstance(self.exact_check, ObjectiveEvaluationIR):
                raise ValueError("sampled runs require an independent exact check.")
            if (
                self.exact_check.parameter_bind.parameter_bind_hash
                != self.result.selected_evaluation.parameter_bind.parameter_bind_hash
            ):
                raise ValueError("exact check must use the selected parameter binding.")
            if (
                self.exact_check.hamiltonian_hash
                != self.result.hamiltonian.stable_hash()
            ):
                raise ValueError("exact check must use the benchmark Hamiltonian.")
            result_ids = _result_ids(self.result)
            if self.exact_check.result_id in result_ids:
                raise ValueError(
                    "exact check Result must be independent of optimizer evidence."
                )
            expected_exact = self.exact_check.energy
            expected_diagnostic_cost = 1
            if self.estimator_error is None:
                raise ValueError("sampled runs require estimator_error.")
            _require_close(
                self.estimator_error,
                expected_estimator - expected_exact,
                "estimator_error",
            )
        _require_close(
            self.exact_selected_energy, expected_exact, "exact_selected_energy"
        )
        _require_close(
            self.paired_exact_reference_gap,
            expected_exact - self.exact_reference_energy,
            "paired_exact_reference_gap",
        )
        expected_objective_count = len(self.result.evaluations)
        expected_objective_backend = int(
            self.result.termination.backend_execution_count or 0
        )
        expected_objective_shots = sum(
            item.total_shots
            for item in self.result.evaluations
            if isinstance(item, SampledObjectiveEvaluationIR)
        )
        selection = self.result.sampled_selection
        expected_confirmation_backend = (
            0 if selection is None else selection.backend_execution_count
        )
        expected_confirmation_shots = 0 if selection is None else selection.total_shots
        expected_final_backend = 1 if self.result.final_result is not None else 0
        expected_final_shots = (
            0 if self.result.final_result is None else self.result.final_result.shots
        )
        expected_costs = (
            (
                self.objective_evaluation_count,
                expected_objective_count,
                "objective_evaluation_count",
            ),
            (
                self.objective_backend_execution_count,
                expected_objective_backend,
                "objective_backend_execution_count",
            ),
            (self.objective_shots, expected_objective_shots, "objective_shots"),
            (
                self.confirmation_backend_execution_count,
                expected_confirmation_backend,
                "confirmation_backend_execution_count",
            ),
            (
                self.confirmation_shots,
                expected_confirmation_shots,
                "confirmation_shots",
            ),
            (
                self.final_sampling_backend_execution_count,
                expected_final_backend,
                "final_sampling_backend_execution_count",
            ),
            (self.final_sampling_shots, expected_final_shots, "final_sampling_shots"),
            (
                self.diagnostic_exact_backend_execution_count,
                expected_diagnostic_cost,
                "diagnostic_exact_backend_execution_count",
            ),
        )
        for actual, expected, name in expected_costs:
            if actual != expected:
                raise ValueError(f"{name} does not match saved execution evidence.")
        utilization = _finite(
            self.objective_budget_utilization, "objective_budget_utilization"
        )
        if not 0.0 < utilization <= 1.0:
            raise ValueError("objective_budget_utilization must be in (0, 1].")
        object.__setattr__(self, "objective_budget_utilization", utilization)
        expected_id = _benchmark_run_id(
            strategy=self.strategy,
            repeat_index=self.repeat_index,
            paired_seed=self.paired_seed,
            result=self.result,
            exact_check=self.exact_check,
            exact_reference_energy=self.exact_reference_energy,
        )
        if self.run_id != expected_id:
            raise ValueError("run_id does not match benchmark run facts.")

    @classmethod
    def create(
        cls,
        *,
        strategy: VQESamplingStrategy,
        repeat_index: int,
        paired_seed: int,
        result: VariationalResult[Any],
        exact_check: ObjectiveEvaluationIR | None,
        exact_reference_energy: float,
        objective_evaluation_budget: int,
    ) -> VQESamplingBenchmarkRunIR:
        """Build one run and derive every metric from saved execution facts."""
        selected_estimator = _selected_estimator_energy(result)
        exact_selected = (
            selected_estimator if exact_check is None else exact_check.energy
        )
        selection = result.sampled_selection
        return cls(
            run_id=_benchmark_run_id(
                strategy=strategy,
                repeat_index=repeat_index,
                paired_seed=paired_seed,
                result=result,
                exact_check=exact_check,
                exact_reference_energy=exact_reference_energy,
            ),
            strategy=strategy,
            repeat_index=repeat_index,
            paired_seed=paired_seed,
            result=result,
            exact_check=exact_check,
            selected_estimator_energy=selected_estimator,
            exact_selected_energy=exact_selected,
            exact_reference_energy=exact_reference_energy,
            estimator_error=(
                None if exact_check is None else selected_estimator - exact_selected
            ),
            paired_exact_reference_gap=exact_selected - exact_reference_energy,
            objective_evaluation_count=len(result.evaluations),
            objective_backend_execution_count=int(
                result.termination.backend_execution_count or 0
            ),
            objective_shots=sum(
                item.total_shots
                for item in result.evaluations
                if isinstance(item, SampledObjectiveEvaluationIR)
            ),
            confirmation_backend_execution_count=(
                0 if selection is None else selection.backend_execution_count
            ),
            confirmation_shots=0 if selection is None else selection.total_shots,
            final_sampling_backend_execution_count=(
                1 if result.final_result is not None else 0
            ),
            final_sampling_shots=(
                0 if result.final_result is None else result.final_result.shots
            ),
            diagnostic_exact_backend_execution_count=(0 if exact_check is None else 1),
            objective_budget_utilization=(
                len(result.evaluations) / objective_evaluation_budget
            ),
        )

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> VQESamplingBenchmarkRunIR:
        """Restore one benchmark run and recheck all derived metrics."""
        raw_check = data.get("exact_check")
        return cls(
            run_id=str(data["run_id"]),
            strategy=cast(VQESamplingStrategy, data["strategy"]),
            repeat_index=data["repeat_index"],
            paired_seed=data["paired_seed"],
            result=VariationalResult.from_dict(_mapping(data["result"], "result")),
            exact_check=(
                None
                if raw_check is None
                else ObjectiveEvaluationIR.from_dict(_mapping(raw_check, "exact_check"))
            ),
            selected_estimator_energy=data["selected_estimator_energy"],
            exact_selected_energy=data["exact_selected_energy"],
            exact_reference_energy=data["exact_reference_energy"],
            estimator_error=data.get("estimator_error"),
            paired_exact_reference_gap=data["paired_exact_reference_gap"],
            objective_evaluation_count=data["objective_evaluation_count"],
            objective_backend_execution_count=data["objective_backend_execution_count"],
            objective_shots=data["objective_shots"],
            confirmation_backend_execution_count=data[
                "confirmation_backend_execution_count"
            ],
            confirmation_shots=data["confirmation_shots"],
            final_sampling_backend_execution_count=data[
                "final_sampling_backend_execution_count"
            ],
            final_sampling_shots=data["final_sampling_shots"],
            diagnostic_exact_backend_execution_count=data[
                "diagnostic_exact_backend_execution_count"
            ],
            objective_budget_utilization=data["objective_budget_utilization"],
            schema_version=str(
                data.get("schema_version", VQE_SAMPLING_BENCHMARK_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class VQESamplingStrategyStatisticsIR(IRMixin):
    """Recomputable paired statistics and mean execution cost for one strategy."""

    strategy: VQESamplingStrategy
    runs: tuple[VQESamplingBenchmarkRunIR, ...]
    sample_count: int
    mean_exact_selected_energy: float
    exact_selected_energy_sample_variance: float
    exact_selected_energy_standard_error: float
    exact_selected_energy_interval_low: float
    exact_selected_energy_interval_high: float
    mean_estimator_error: float | None
    estimator_error_rmse: float | None
    mean_paired_exact_reference_gap: float
    paired_gap_sample_variance: float
    paired_gap_standard_error: float
    paired_gap_interval_low: float
    paired_gap_interval_high: float
    mean_objective_evaluations: float
    mean_objective_backend_executions: float
    mean_objective_shots: float
    mean_confirmation_backend_executions: float
    mean_confirmation_shots: float
    mean_diagnostic_exact_backend_executions: float
    mean_objective_budget_utilization: float
    confidence_level: float
    schema_version: str = VQE_SAMPLING_BENCHMARK_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_schema(self.schema_version)
        if self.strategy not in VQE_SAMPLING_STRATEGIES:
            raise ValueError(f"Unsupported VQE sampling strategy: {self.strategy!r}.")
        object.__setattr__(self, "runs", tuple(self.runs))
        if len(self.runs) < 2:
            raise ValueError("strategy statistics require at least two runs.")
        if any(run.strategy != self.strategy for run in self.runs):
            raise ValueError("statistics runs must share one strategy.")
        if tuple(run.repeat_index for run in self.runs) != tuple(range(len(self.runs))):
            raise ValueError("strategy repeat indices must be contiguous from zero.")
        if self.sample_count != len(self.runs):
            raise ValueError("sample_count does not match strategy runs.")
        level = _confidence_level(self.confidence_level)
        object.__setattr__(self, "confidence_level", level)
        energy = sample_summary(
            tuple(run.exact_selected_energy for run in self.runs),
            confidence=level,
        )
        gap = sample_summary(
            tuple(run.paired_exact_reference_gap for run in self.runs),
            confidence=level,
        )
        checks = (
            (
                self.mean_exact_selected_energy,
                energy.mean,
                "mean_exact_selected_energy",
            ),
            (
                self.exact_selected_energy_sample_variance,
                energy.variance,
                "exact_selected_energy_sample_variance",
            ),
            (
                self.exact_selected_energy_standard_error,
                energy.standard_error,
                "exact_selected_energy_standard_error",
            ),
            (
                self.exact_selected_energy_interval_low,
                energy.interval_low,
                "exact_selected_energy_interval_low",
            ),
            (
                self.exact_selected_energy_interval_high,
                energy.interval_high,
                "exact_selected_energy_interval_high",
            ),
            (
                self.mean_paired_exact_reference_gap,
                gap.mean,
                "mean_paired_exact_reference_gap",
            ),
            (
                self.paired_gap_sample_variance,
                gap.variance,
                "paired_gap_sample_variance",
            ),
            (
                self.paired_gap_standard_error,
                gap.standard_error,
                "paired_gap_standard_error",
            ),
            (self.paired_gap_interval_low, gap.interval_low, "paired_gap_interval_low"),
            (
                self.paired_gap_interval_high,
                gap.interval_high,
                "paired_gap_interval_high",
            ),
        )
        for actual, expected, name in checks:
            _require_close(actual, expected, name)
        errors = tuple(
            run.estimator_error for run in self.runs if run.estimator_error is not None
        )
        if self.strategy == "exact":
            if (
                errors
                or self.mean_estimator_error is not None
                or self.estimator_error_rmse is not None
            ):
                raise ValueError(
                    "exact strategy does not have estimator-error statistics."
                )
        else:
            if len(errors) != len(self.runs):
                raise ValueError("sampled strategy requires every estimator error.")
            mean_error = math.fsum(errors) / len(errors)
            rmse = math.sqrt(math.fsum(value * value for value in errors) / len(errors))
            if self.mean_estimator_error is None or self.estimator_error_rmse is None:
                raise ValueError(
                    "sampled strategy requires estimator-error statistics."
                )
            _require_close(
                self.mean_estimator_error, mean_error, "mean_estimator_error"
            )
            _require_close(self.estimator_error_rmse, rmse, "estimator_error_rmse")
        cost_fields = (
            (
                self.mean_objective_evaluations,
                tuple(float(run.objective_evaluation_count) for run in self.runs),
                "mean_objective_evaluations",
            ),
            (
                self.mean_objective_backend_executions,
                tuple(
                    float(run.objective_backend_execution_count) for run in self.runs
                ),
                "mean_objective_backend_executions",
            ),
            (
                self.mean_objective_shots,
                tuple(float(run.objective_shots) for run in self.runs),
                "mean_objective_shots",
            ),
            (
                self.mean_confirmation_backend_executions,
                tuple(
                    float(run.confirmation_backend_execution_count) for run in self.runs
                ),
                "mean_confirmation_backend_executions",
            ),
            (
                self.mean_confirmation_shots,
                tuple(float(run.confirmation_shots) for run in self.runs),
                "mean_confirmation_shots",
            ),
            (
                self.mean_diagnostic_exact_backend_executions,
                tuple(
                    float(run.diagnostic_exact_backend_execution_count)
                    for run in self.runs
                ),
                "mean_diagnostic_exact_backend_executions",
            ),
            (
                self.mean_objective_budget_utilization,
                tuple(run.objective_budget_utilization for run in self.runs),
                "mean_objective_budget_utilization",
            ),
        )
        for actual, values, name in cost_fields:
            _require_close(actual, math.fsum(values) / len(values), name)

    @classmethod
    def create(
        cls,
        strategy: VQESamplingStrategy,
        runs: Sequence[VQESamplingBenchmarkRunIR],
        *,
        confidence_level: float,
    ) -> VQESamplingStrategyStatisticsIR:
        """Build checked strategy statistics from paired runs."""
        normalized = tuple(runs)
        level = _confidence_level(confidence_level)
        energy = sample_summary(
            tuple(run.exact_selected_energy for run in normalized),
            confidence=level,
        )
        gap = sample_summary(
            tuple(run.paired_exact_reference_gap for run in normalized),
            confidence=level,
        )
        errors = tuple(
            run.estimator_error for run in normalized if run.estimator_error is not None
        )

        def mean(values: Sequence[float]) -> float:
            return math.fsum(values) / len(values)

        return cls(
            strategy=strategy,
            runs=normalized,
            sample_count=len(normalized),
            mean_exact_selected_energy=energy.mean,
            exact_selected_energy_sample_variance=energy.variance,
            exact_selected_energy_standard_error=energy.standard_error,
            exact_selected_energy_interval_low=energy.interval_low,
            exact_selected_energy_interval_high=energy.interval_high,
            mean_estimator_error=None if not errors else mean(errors),
            estimator_error_rmse=(
                None
                if not errors
                else math.sqrt(mean(tuple(value * value for value in errors)))
            ),
            mean_paired_exact_reference_gap=gap.mean,
            paired_gap_sample_variance=gap.variance,
            paired_gap_standard_error=gap.standard_error,
            paired_gap_interval_low=gap.interval_low,
            paired_gap_interval_high=gap.interval_high,
            mean_objective_evaluations=mean(
                tuple(float(run.objective_evaluation_count) for run in normalized)
            ),
            mean_objective_backend_executions=mean(
                tuple(
                    float(run.objective_backend_execution_count) for run in normalized
                )
            ),
            mean_objective_shots=mean(
                tuple(float(run.objective_shots) for run in normalized)
            ),
            mean_confirmation_backend_executions=mean(
                tuple(
                    float(run.confirmation_backend_execution_count)
                    for run in normalized
                )
            ),
            mean_confirmation_shots=mean(
                tuple(float(run.confirmation_shots) for run in normalized)
            ),
            mean_diagnostic_exact_backend_executions=mean(
                tuple(
                    float(run.diagnostic_exact_backend_execution_count)
                    for run in normalized
                )
            ),
            mean_objective_budget_utilization=mean(
                tuple(run.objective_budget_utilization for run in normalized)
            ),
            confidence_level=level,
        )

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> VQESamplingStrategyStatisticsIR:
        """Restore strategy statistics and recompute every derived field."""
        return cls(
            strategy=cast(VQESamplingStrategy, data["strategy"]),
            runs=tuple(
                VQESamplingBenchmarkRunIR.from_dict(_mapping(item, "run"))
                for item in _sequence(data["runs"], "runs")
            ),
            sample_count=data["sample_count"],
            mean_exact_selected_energy=data["mean_exact_selected_energy"],
            exact_selected_energy_sample_variance=data[
                "exact_selected_energy_sample_variance"
            ],
            exact_selected_energy_standard_error=data[
                "exact_selected_energy_standard_error"
            ],
            exact_selected_energy_interval_low=data[
                "exact_selected_energy_interval_low"
            ],
            exact_selected_energy_interval_high=data[
                "exact_selected_energy_interval_high"
            ],
            mean_estimator_error=data.get("mean_estimator_error"),
            estimator_error_rmse=data.get("estimator_error_rmse"),
            mean_paired_exact_reference_gap=data["mean_paired_exact_reference_gap"],
            paired_gap_sample_variance=data["paired_gap_sample_variance"],
            paired_gap_standard_error=data["paired_gap_standard_error"],
            paired_gap_interval_low=data["paired_gap_interval_low"],
            paired_gap_interval_high=data["paired_gap_interval_high"],
            mean_objective_evaluations=data["mean_objective_evaluations"],
            mean_objective_backend_executions=data["mean_objective_backend_executions"],
            mean_objective_shots=data["mean_objective_shots"],
            mean_confirmation_backend_executions=data[
                "mean_confirmation_backend_executions"
            ],
            mean_confirmation_shots=data["mean_confirmation_shots"],
            mean_diagnostic_exact_backend_executions=data[
                "mean_diagnostic_exact_backend_executions"
            ],
            mean_objective_budget_utilization=data["mean_objective_budget_utilization"],
            confidence_level=data["confidence_level"],
            schema_version=str(
                data.get("schema_version", VQE_SAMPLING_BENCHMARK_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class VQESamplingBenchmarkResult(IRMixin):
    """Complete paired VQE benchmark with independently restorable statistics."""

    benchmark_id: str
    algorithm_id: str
    hamiltonian_hash: str
    ansatz_hash: str
    logical_order: tuple[str, ...]
    config: VQESamplingBenchmarkConfig
    runs: tuple[VQESamplingBenchmarkRunIR, ...]
    statistics: tuple[VQESamplingStrategyStatisticsIR, ...]
    optimality_claim: Literal["not_claimed"] = "not_claimed"
    schema_version: str = VQE_SAMPLING_BENCHMARK_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_schema(self.schema_version)
        _require_text(self.algorithm_id, "algorithm_id")
        _require_text(self.hamiltonian_hash, "hamiltonian_hash")
        _require_text(self.ansatz_hash, "ansatz_hash")
        object.__setattr__(self, "logical_order", tuple(self.logical_order))
        if not isinstance(self.config, VQESamplingBenchmarkConfig):
            raise TypeError("config must be VQESamplingBenchmarkConfig.")
        object.__setattr__(self, "runs", tuple(self.runs))
        object.__setattr__(self, "statistics", tuple(self.statistics))
        expected_pairs = tuple(
            (repeat_index, strategy)
            for repeat_index in range(self.config.repeats)
            for strategy in VQE_SAMPLING_STRATEGIES
        )
        actual_pairs = tuple((run.repeat_index, run.strategy) for run in self.runs)
        if actual_pairs != expected_pairs:
            raise ValueError(
                "runs must contain the complete repeat-major strategy matrix."
            )
        if tuple(item.strategy for item in self.statistics) != VQE_SAMPLING_STRATEGIES:
            raise ValueError("statistics must follow the canonical strategy order.")
        for repeat_index in range(self.config.repeats):
            paired = tuple(run for run in self.runs if run.repeat_index == repeat_index)
            if len({run.paired_seed for run in paired}) != 1:
                raise ValueError("all strategies in one repeat must share paired_seed.")
            initial_points = tuple(
                tuple(run.result.optimization_starts[0].initial_parameters.values())
                for run in paired
            )
            if len(set(initial_points)) != 1:
                raise ValueError(
                    "all strategies in one repeat must share initial parameters."
                )
            exact_reference = paired[0]
            if exact_reference.strategy != "exact":
                raise ValueError("the first paired run must be the exact reference.")
            expected_reference = exact_reference.exact_selected_energy
            for run in paired:
                _require_close(
                    run.exact_reference_energy,
                    expected_reference,
                    "exact_reference_energy",
                )
        for run in self.runs:
            if run.result.hamiltonian.stable_hash() != self.hamiltonian_hash:
                raise ValueError("benchmark runs must share the Hamiltonian.")
            if run.result.ansatz.stable_hash() != self.ansatz_hash:
                raise ValueError("benchmark runs must share the Ansatz.")
            if run.result.hamiltonian.logical_order != self.logical_order:
                raise ValueError("benchmark runs must share logical_order.")
            if (
                run.result.evaluations[0].metadata.get("algorithm_id")
                != self.algorithm_id
            ):
                raise ValueError("benchmark runs must share algorithm_id.")
            _validate_run_config(
                run,
                config=self.config,
                algorithm_id=self.algorithm_id,
            )
            expected_utilization = (
                run.objective_evaluation_count / self.config.objective_evaluation_budget
            )
            _require_close(
                run.objective_budget_utilization,
                expected_utilization,
                "objective_budget_utilization",
            )
        for item in self.statistics:
            expected_runs = tuple(
                run for run in self.runs if run.strategy == item.strategy
            )
            if item.runs != expected_runs:
                raise ValueError("statistics runs do not match benchmark runs.")
        if self.optimality_claim != "not_claimed":
            raise ValueError("benchmark optimality_claim must remain not_claimed.")
        expected_id = _benchmark_id(
            algorithm_id=self.algorithm_id,
            hamiltonian_hash=self.hamiltonian_hash,
            ansatz_hash=self.ansatz_hash,
            logical_order=self.logical_order,
            config=self.config,
            runs=self.runs,
            statistics=self.statistics,
        )
        if self.benchmark_id != expected_id:
            raise ValueError("benchmark_id does not match benchmark facts.")

    @classmethod
    def create(
        cls,
        *,
        algorithm_id: str,
        config: VQESamplingBenchmarkConfig,
        runs: Sequence[VQESamplingBenchmarkRunIR],
    ) -> VQESamplingBenchmarkResult:
        """Build the final result and checked statistics from completed runs."""
        normalized = tuple(runs)
        first = normalized[0].result
        statistics = tuple(
            VQESamplingStrategyStatisticsIR.create(
                strategy,
                tuple(run for run in normalized if run.strategy == strategy),
                confidence_level=config.confidence_level,
            )
            for strategy in VQE_SAMPLING_STRATEGIES
        )
        hamiltonian_hash = first.hamiltonian.stable_hash()
        ansatz_hash = first.ansatz.stable_hash()
        logical_order = first.hamiltonian.logical_order
        benchmark_id = _benchmark_id(
            algorithm_id=algorithm_id,
            hamiltonian_hash=hamiltonian_hash,
            ansatz_hash=ansatz_hash,
            logical_order=logical_order,
            config=config,
            runs=normalized,
            statistics=statistics,
        )
        return cls(
            benchmark_id=benchmark_id,
            algorithm_id=algorithm_id,
            hamiltonian_hash=hamiltonian_hash,
            ansatz_hash=ansatz_hash,
            logical_order=logical_order,
            config=config,
            runs=normalized,
            statistics=statistics,
        )

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> VQESamplingBenchmarkResult:
        """Restore a benchmark result and reject altered source or statistics."""
        return cls(
            benchmark_id=str(data["benchmark_id"]),
            algorithm_id=str(data["algorithm_id"]),
            hamiltonian_hash=str(data["hamiltonian_hash"]),
            ansatz_hash=str(data["ansatz_hash"]),
            logical_order=tuple(
                str(item) for item in _sequence(data["logical_order"], "logical_order")
            ),
            config=VQESamplingBenchmarkConfig.from_dict(
                _mapping(data["config"], "config")
            ),
            runs=tuple(
                VQESamplingBenchmarkRunIR.from_dict(_mapping(item, "run"))
                for item in _sequence(data["runs"], "runs")
            ),
            statistics=tuple(
                VQESamplingStrategyStatisticsIR.from_dict(_mapping(item, "statistics"))
                for item in _sequence(data["statistics"], "statistics")
            ),
            optimality_claim=cast(
                Literal["not_claimed"], data.get("optimality_claim", "not_claimed")
            ),
            schema_version=str(
                data.get("schema_version", VQE_SAMPLING_BENCHMARK_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> VQESamplingBenchmarkResult:
        """Restore a benchmark result from JSON."""
        return cls.from_dict(_json_object(text, "VQESamplingBenchmarkResult"))

    def report(
        self,
        output: str | PathLike[str] | None = None,
        *,
        language: Literal["en", "zh"] = "en",
        title: str | None = None,
    ) -> ExperimentReport:
        """Build and optionally save the standard benchmark report."""
        from cascaqit.visualization import visualize

        report = visualize(self, profile="algorithm", title=title)
        if output is not None:
            report.save(output, language=language)
        return report


def execute_vqe_sampling_benchmark(
    vqe: VQE,
    *,
    config: VQESamplingBenchmarkConfig,
    backend: LocalBackend | None = None,
) -> VQESamplingBenchmarkResult:
    """Execute all paired strategies and independent exact diagnostics."""
    if not isinstance(config, VQESamplingBenchmarkConfig):
        raise TypeError("config must be VQESamplingBenchmarkConfig.")
    if backend is not None and not isinstance(backend, LocalBackend):
        raise TypeError("backend must be LocalBackend or None.")
    execution_backend = backend or LocalBackend(seed=config.root_seed)
    plan = build_pauli_measurement_plan(
        vqe.build_circuit(),
        vqe.hamiltonian,
        config=config.measurement,
    )
    objective_backend_budget = (
        config.objective_evaluation_budget * plan.backend_execution_count
    )
    request_hash = hashlib.sha256(
        stable_json(
            {
                "algorithm_id": vqe.algorithm_id,
                "hamiltonian_hash": vqe.hamiltonian.stable_hash(),
                "ansatz_hash": vqe.ansatz_spec().stable_hash(),
                "config": config,
            }
        ).encode("utf-8")
    ).hexdigest()[:20]
    runs: list[VQESamplingBenchmarkRunIR] = []
    for repeat_index in range(config.repeats):
        paired_seed = derive_layer_run_seed(
            config.root_seed,
            layers=vqe.layers,
            repeat_index=repeat_index,
            namespace="cascaqit.algorithms.vqe_sampling_benchmark.v1",
        )
        point = seeded_initial_point(
            algorithm_kind="vqe",
            layers=vqe.layers,
            parameter_count=len(vqe.parameter_names),
            seed=paired_seed,
            bounds=config.optimizer.bounds,
        )
        initial_parameters = dict(zip(vqe.parameter_names, point))
        completed: dict[VQESamplingStrategy, VariationalResult[Any]] = {}
        for strategy in VQE_SAMPLING_STRATEGIES:
            optimizer = _strategy_optimizer(
                config,
                strategy=strategy,
                paired_seed=paired_seed,
                objective_backend_budget=objective_backend_budget,
            )
            run_id = (
                f"{vqe.algorithm_id}.sampling-benchmark-{request_hash}."
                f"repeat-{repeat_index}.{strategy}"
            )
            if strategy == "exact":
                completed[strategy] = vqe.run(
                    backend=execution_backend,
                    optimizer=optimizer,
                    initial_parameters=initial_parameters,
                    algorithm_run_id=run_id,
                    final_shots=config.final_shots,
                )
            else:
                completed[strategy] = vqe.run(
                    backend=execution_backend,
                    optimizer=optimizer,
                    initial_parameters=initial_parameters,
                    algorithm_run_id=run_id,
                    final_shots=config.final_shots,
                    measurement=config.measurement,
                    sampled_selection=config.sampled_selection,
                )
        exact_reference_energy = completed["exact"].selected_evaluation.energy
        for strategy in VQE_SAMPLING_STRATEGIES:
            result = completed[strategy]
            exact_check = None
            if strategy != "exact":
                exact_check = vqe.evaluate(
                    dict(result.selected_evaluation.parameter_bind.values),
                    backend=execution_backend,
                    evaluation_index=0,
                    algorithm_run_id=(
                        f"{vqe.algorithm_id}.sampling-benchmark-{request_hash}."
                        f"repeat-{repeat_index}.{strategy}.exact-check"
                    ),
                    seed=paired_seed,
                )
            runs.append(
                VQESamplingBenchmarkRunIR.create(
                    strategy=strategy,
                    repeat_index=repeat_index,
                    paired_seed=paired_seed,
                    result=result,
                    exact_check=exact_check,
                    exact_reference_energy=exact_reference_energy,
                    objective_evaluation_budget=config.objective_evaluation_budget,
                )
            )
    return VQESamplingBenchmarkResult.create(
        algorithm_id=str(vqe.algorithm_id),
        config=config,
        runs=runs,
    )


def _strategy_optimizer(
    config: VQESamplingBenchmarkConfig,
    *,
    strategy: VQESamplingStrategy,
    paired_seed: int,
    objective_backend_budget: int,
) -> OptimizerConfig:
    base_spsa = config.optimizer.spsa
    assert base_spsa is not None
    if strategy in {"exact", "sampled_single"}:
        spsa = replace(base_spsa, objective_repeats=1)
    elif strategy == "sampled_fixed":
        spsa = replace(
            base_spsa,
            objective_repeats=config.fixed_objective_repeats,
        )
    else:
        spsa = replace(
            base_spsa,
            objective_repeats=config.adaptive_objective_repeats,
            max_objective_repeats=config.adaptive_max_objective_repeats,
            objective_standard_error_target=config.adaptive_standard_error_target,
        )
    return replace(
        config.optimizer,
        seed=paired_seed,
        max_evaluations=config.objective_evaluation_budget,
        max_backend_executions=(
            config.objective_evaluation_budget
            if strategy == "exact"
            else objective_backend_budget
        ),
        spsa=spsa,
    )


def _strategy_spsa(
    strategy: VQESamplingStrategy,
    spsa: SPSAConfig | None,
) -> SPSAConfig | None:
    if spsa is None:
        raise ValueError("benchmark runs require SPSA configuration.")
    return spsa


def _validate_strategy_spsa(
    strategy: VQESamplingStrategy,
    spsa: SPSAConfig,
) -> None:
    if strategy in {"exact", "sampled_single"}:
        if spsa.objective_repeats != 1 or spsa.objective_repeat_mode != "fixed":
            raise ValueError(f"{strategy} must use one fixed objective repeat.")
    elif strategy == "sampled_fixed":
        if spsa.objective_repeats < 2 or spsa.objective_repeat_mode != "fixed":
            raise ValueError("sampled_fixed must use at least two fixed repeats.")
    elif spsa.objective_repeat_mode != "adaptive":
        raise ValueError("sampled_adaptive must use adaptive objective repeats.")


def _validate_run_config(
    run: VQESamplingBenchmarkRunIR,
    *,
    config: VQESamplingBenchmarkConfig,
    algorithm_id: str,
) -> None:
    """Bind saved run evidence to the benchmark's shared configuration."""
    optimizer = run.result.optimizer
    if optimizer.max_evaluations != config.objective_evaluation_budget:
        raise ValueError(
            "run optimizer max_evaluations must match the benchmark ceiling."
        )
    spsa = optimizer.spsa
    assert spsa is not None
    expected_spsa = _strategy_optimizer(
        config,
        strategy=run.strategy,
        paired_seed=run.paired_seed,
        objective_backend_budget=(
            config.objective_evaluation_budget
            * _sampled_backend_cost(run, config=config)
        ),
    ).spsa
    if spsa != expected_spsa:
        raise ValueError(
            f"{run.strategy} SPSA configuration does not match the benchmark config."
        )

    if run.strategy == "exact":
        expected_backend_ceiling = config.objective_evaluation_budget
        if run.result.sampled_selection is not None:
            raise ValueError("exact benchmark runs must not use sampled selection.")
    else:
        expected_backend_ceiling = (
            config.objective_evaluation_budget
            * _sampled_backend_cost(run, config=config)
        )
        selection = run.result.sampled_selection
        if selection is None or selection.config != config.sampled_selection:
            raise ValueError(
                "sampled selection configuration does not match the benchmark config."
            )
    if optimizer.max_backend_executions != expected_backend_ceiling:
        raise ValueError(
            "run optimizer max_backend_executions does not match the "
            "benchmark cost ceiling."
        )
    if (
        run.result.final_result is None
        or run.result.final_result.shots != config.final_shots
    ):
        raise ValueError("final sampling shots do not match the benchmark config.")

    check = run.exact_check
    if check is None:
        return
    check_run_id = check.metadata.get("algorithm_run_id")
    if check_run_id == run.result.algorithm_run_id:
        raise ValueError("exact check must use an independent algorithm_run_id.")
    if check.metadata.get("algorithm_id") != algorithm_id:
        raise ValueError("exact check algorithm_id must match the benchmark.")
    if check.metadata.get("algorithm") != "vqe":
        raise ValueError("exact check must identify the VQE algorithm.")
    if check.metadata.get("ansatz_program_id") != f"program.{algorithm_id}":
        raise ValueError("exact check must use the benchmark Ansatz program.")
    if check.execution_evidence.requested_seed != run.paired_seed:
        raise ValueError("exact check seed must match paired_seed.")


def _sampled_backend_cost(
    run: VQESamplingBenchmarkRunIR,
    *,
    config: VQESamplingBenchmarkConfig,
) -> int:
    """Return one logical sampled evaluation's real Backend Job cost."""
    if run.strategy == "exact":
        return 1
    evaluations = cast(
        tuple[SampledObjectiveEvaluationIR, ...],
        run.result.evaluations,
    )
    if any(evaluation.plan.config != config.measurement for evaluation in evaluations):
        raise ValueError(
            "sampled measurement configuration does not match the benchmark config."
        )
    backend_costs = {
        evaluation.plan.backend_execution_count for evaluation in evaluations
    }
    if len(backend_costs) != 1:
        raise ValueError("sampled evaluations must share one Backend Job cost.")
    return next(iter(backend_costs))


def _selected_estimator_energy(result: VariationalResult[Any]) -> float:
    if result.sampled_selection is not None:
        return float(result.sampled_selection.selected_candidate.energy)
    return float(result.selected_evaluation.energy)


def _result_ids(result: VariationalResult[Any]) -> set[str]:
    ids = set(cast(tuple[str, ...], result.metadata.get("backend_result_ids", ())))
    if result.sampled_selection is not None:
        ids.update(
            result_id
            for candidate in result.sampled_selection.candidates
            for evaluation in candidate.evaluations
            for result_id in evaluation.result_ids
        )
    if result.final_result is not None:
        ids.add(result.final_result.result_id)
    return ids


def _benchmark_run_id(
    *,
    strategy: VQESamplingStrategy,
    repeat_index: int,
    paired_seed: int,
    result: VariationalResult[Any],
    exact_check: ObjectiveEvaluationIR | None,
    exact_reference_energy: float,
) -> str:
    digest = hashlib.sha256(
        stable_json(
            {
                "strategy": strategy,
                "repeat_index": repeat_index,
                "paired_seed": paired_seed,
                "result_hash": result.stable_hash(),
                "exact_check_hash": (
                    None if exact_check is None else exact_check.stable_hash()
                ),
                "exact_reference_energy": exact_reference_energy,
            }
        ).encode("utf-8")
    ).hexdigest()
    return f"vqe.sampling.run.{digest[:24]}"


def _benchmark_id(
    *,
    algorithm_id: str,
    hamiltonian_hash: str,
    ansatz_hash: str,
    logical_order: tuple[str, ...],
    config: VQESamplingBenchmarkConfig,
    runs: tuple[VQESamplingBenchmarkRunIR, ...],
    statistics: tuple[VQESamplingStrategyStatisticsIR, ...],
) -> str:
    digest = hashlib.sha256(
        stable_json(
            {
                "algorithm_id": algorithm_id,
                "hamiltonian_hash": hamiltonian_hash,
                "ansatz_hash": ansatz_hash,
                "logical_order": logical_order,
                "config": config,
                "run_ids": tuple(run.run_id for run in runs),
                "statistics": statistics,
            }
        ).encode("utf-8")
    ).hexdigest()
    return f"vqe.sampling.benchmark.{digest[:24]}"


def _require_close(actual: object, expected: float, name: str) -> None:
    normalized = _finite(actual, name)
    if not math.isclose(
        normalized,
        expected,
        rel_tol=_FLOAT_TOLERANCE,
        abs_tol=_FLOAT_TOLERANCE,
    ):
        raise ValueError(f"{name} does not match derived benchmark facts.")


def _finite(value: object, name: str) -> float:
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        raise TypeError(f"{name} must be a real number.")
    normalized = float(value)
    if not math.isfinite(normalized):
        raise ValueError(f"{name} must be finite.")
    return normalized


def _positive_int(value: object, name: str) -> None:
    _integer_at_least(value, name, 1)


def _non_negative_int(value: object, name: str) -> None:
    _integer_at_least(value, name, 0)


def _integer_at_least(value: object, name: str, minimum: int) -> None:
    if not isinstance(value, int) or isinstance(value, bool) or value < minimum:
        raise ValueError(f"{name} must be an integer of at least {minimum}.")


def _require_text(value: object, name: str) -> None:
    if not isinstance(value, str) or not value.strip() or value != value.strip():
        raise ValueError(f"{name} must be a non-empty trimmed string.")


def _require_schema(value: object) -> None:
    if value != VQE_SAMPLING_BENCHMARK_SCHEMA_VERSION:
        raise ValueError(f"Unsupported VQE sampling benchmark schema: {value!r}.")


def _mapping(value: object, name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{name} must be an object.")
    return value


def _sequence(value: object, name: str) -> Sequence[Any]:
    if not isinstance(value, (list, tuple)):
        raise TypeError(f"{name} must be an array.")
    return value


def _json_object(text: str, name: str) -> Mapping[str, Any]:
    data = json.loads(text)
    return _mapping(data, name)
