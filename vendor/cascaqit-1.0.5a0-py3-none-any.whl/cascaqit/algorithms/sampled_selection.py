"""Independent confirmation and statistical selection for sampled VQE."""

from __future__ import annotations

import hashlib
import math
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from statistics import NormalDist
from typing import Any, Literal

from cascaqit.algorithms.measurement import (
    PauliMeasurementConfig,
    PauliMeasurementGroupResultIR,
    SampledObjectiveEvaluationIR,
    build_pauli_measurement_plan,
    execute_sampled_objective_evaluation,
)
from cascaqit.algorithms.models import PauliHamiltonian
from cascaqit.algorithms.readout_mitigation import (
    ReadoutMitigatedGroupStatisticsIR,
)
from cascaqit.digital import Circuit
from cascaqit.native_ir.base import IRMixin, stable_json
from cascaqit.simulators import LocalBackend, NoiseModel, SimulationOptions

__all__ = [
    "PooledMeasurementGroupIR",
    "SampledSelectionRoundIR",
    "SampledCandidateConfirmationIR",
    "SampledSelectionConfig",
    "SampledSelectionIR",
    "derive_sampled_confirmation_seed",
    "execute_sampled_candidate_selection",
]

SAMPLED_SELECTION_SCHEMA_VERSION = "cascaqit.algorithms.sampled_selection.v3"
# 确认种子属于数值可复现契约，不能随 IR schema 的字段演进而变化。
_SAMPLED_CONFIRMATION_SEED_NAMESPACE = "cascaqit.algorithms.sampled_selection.v2"
_FLOAT_TOLERANCE = 1e-12
_SampledSelectionStopReason = Literal[
    "fixed_repeats_complete",
    "confidence_separated",
    "max_repeats_reached",
    "backend_budget_exhausted",
    "single_candidate",
]


@dataclass(frozen=True)
class SampledSelectionConfig(IRMixin):
    """Configure independent measurements used to select a sampled VQE point."""

    candidate_count: int = 3
    repeats_per_candidate: int = 3
    max_repeats_per_candidate: int | None = None
    shots_per_group: int | None = None
    confidence_level: float = 0.95
    max_backend_executions: int | None = None
    schema_version: str = SAMPLED_SELECTION_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_integer_at_least(self.candidate_count, "candidate_count", 2)
        _require_integer_at_least(
            self.repeats_per_candidate,
            "repeats_per_candidate",
            2,
        )
        if self.max_repeats_per_candidate is not None:
            _require_integer_at_least(
                self.max_repeats_per_candidate,
                "max_repeats_per_candidate",
                self.repeats_per_candidate,
            )
        if self.shots_per_group is not None:
            _require_integer_at_least(
                self.shots_per_group,
                "shots_per_group",
                2,
            )
        confidence = _finite_float(self.confidence_level, "confidence_level")
        if not 0.0 < confidence < 1.0:
            raise ValueError("confidence_level must be between zero and one.")
        if self.max_backend_executions is not None:
            _require_integer_at_least(
                self.max_backend_executions,
                "max_backend_executions",
                1,
            )
        _require_schema(self.schema_version)
        object.__setattr__(self, "confidence_level", confidence)

    @property
    def resolved_max_repeats_per_candidate(self) -> int:
        """Return the per-candidate repeat ceiling for fixed or sequential mode."""
        return (
            self.repeats_per_candidate
            if self.max_repeats_per_candidate is None
            else self.max_repeats_per_candidate
        )

    @property
    def mode(self) -> Literal["fixed", "sequential"]:
        """Return whether confirmation has one fixed look or adaptive rounds."""
        return (
            "fixed"
            if self.resolved_max_repeats_per_candidate == self.repeats_per_candidate
            else "sequential"
        )

    @property
    def planned_look_count(self) -> int:
        """Return a conservative bound used by sequential alpha spending."""
        if self.mode == "fixed":
            return 1
        return 1 + self.candidate_count * (
            self.resolved_max_repeats_per_candidate - self.repeats_per_candidate
        )

    @property
    def decision_confidence_level(self) -> float:
        """Return the per-comparison level after Bonferroni alpha spending."""
        if self.mode == "fixed":
            return self.confidence_level
        candidate_pair_count = self.candidate_count * (self.candidate_count - 1) // 2
        comparison_count = self.planned_look_count * candidate_pair_count
        alpha = (1.0 - self.confidence_level) / comparison_count
        return 1.0 - alpha

    def resolved_measurement(
        self,
        optimization_measurement: PauliMeasurementConfig,
    ) -> PauliMeasurementConfig:
        """Return the confirmation measurement while preserving QWC semantics."""
        if not isinstance(optimization_measurement, PauliMeasurementConfig):
            raise TypeError("optimization_measurement must be PauliMeasurementConfig.")
        return PauliMeasurementConfig(
            shots_per_group=(
                optimization_measurement.shots_per_group
                if self.shots_per_group is None
                else self.shots_per_group
            ),
            grouping=optimization_measurement.grouping,
            allocation=optimization_measurement.allocation,
            pilot_shots_per_group=(
                optimization_measurement.pilot_shots_per_group
                if optimization_measurement.allocation == "pilot_variance"
                else None
            ),
            mitigation=optimization_measurement.mitigation,
        )

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> SampledSelectionConfig:
        """Restore an independent-confirmation configuration."""
        return cls(
            candidate_count=data.get("candidate_count", 3),
            repeats_per_candidate=data.get("repeats_per_candidate", 3),
            max_repeats_per_candidate=data.get("max_repeats_per_candidate"),
            shots_per_group=data.get("shots_per_group"),
            confidence_level=data.get("confidence_level", 0.95),
            max_backend_executions=data.get("max_backend_executions"),
            schema_version=str(
                data.get("schema_version", SAMPLED_SELECTION_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> SampledSelectionConfig:
        """Restore a configuration from JSON."""
        return cls.from_dict(_json_object(text, "SampledSelectionConfig"))


@dataclass(frozen=True)
class PooledMeasurementGroupIR(IRMixin):
    """One QWC group's statistics pooled across independent repeats."""

    group_index: int
    energy_mean: float
    energy_standard_error: float
    total_shots: int
    estimator_kind: Literal["sample_mean", "readout_mitigated_sample_mean"]
    calibration_hash: str | None
    schema_version: str = SAMPLED_SELECTION_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_non_negative_int(self.group_index, "group_index")
        mean = _finite_float(self.energy_mean, "energy_mean")
        error = _finite_non_negative_float(
            self.energy_standard_error,
            "energy_standard_error",
        )
        _require_integer_at_least(self.total_shots, "total_shots", 2)
        if self.estimator_kind not in {
            "sample_mean",
            "readout_mitigated_sample_mean",
        }:
            raise ValueError("Unsupported pooled measurement estimator kind.")
        if self.estimator_kind == "sample_mean":
            if self.calibration_hash is not None:
                raise ValueError("raw pooled group must not define calibration_hash.")
        else:
            _require_digest(self.calibration_hash, "calibration_hash")
        _require_schema(self.schema_version)
        object.__setattr__(self, "energy_mean", mean)
        object.__setattr__(self, "energy_standard_error", error)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> PooledMeasurementGroupIR:
        """Restore pooled QWC statistics."""
        return cls(
            group_index=data["group_index"],
            energy_mean=data["energy_mean"],
            energy_standard_error=data["energy_standard_error"],
            total_shots=data["total_shots"],
            estimator_kind=data.get("estimator_kind", "sample_mean"),
            calibration_hash=data.get("calibration_hash"),
            schema_version=str(
                data.get("schema_version", SAMPLED_SELECTION_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class SampledCandidateConfirmationIR(IRMixin):
    """Independent repeated measurements for one optimization-history point."""

    candidate_rank: int
    source_evaluation_index: int
    source_evaluation_id: str
    source_parameter_bind_hash: str
    confidence_level: float
    evaluations: tuple[SampledObjectiveEvaluationIR, ...]
    pooled_groups: tuple[PooledMeasurementGroupIR, ...]
    energy: float
    energy_standard_error: float
    confidence_interval_low: float
    confidence_interval_high: float
    total_shots: int
    backend_execution_count: int
    schema_version: str = SAMPLED_SELECTION_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_non_negative_int(self.candidate_rank, "candidate_rank")
        _require_non_negative_int(
            self.source_evaluation_index,
            "source_evaluation_index",
        )
        _require_text(self.source_evaluation_id, "source_evaluation_id")
        _require_digest(
            self.source_parameter_bind_hash,
            "source_parameter_bind_hash",
        )
        confidence = _finite_float(self.confidence_level, "confidence_level")
        if not 0.0 < confidence < 1.0:
            raise ValueError("confidence_level must be between zero and one.")
        evaluations = tuple(self.evaluations)
        if len(evaluations) < 2 or any(
            not isinstance(item, SampledObjectiveEvaluationIR) for item in evaluations
        ):
            raise ValueError(
                "evaluations must contain at least two sampled objective repeats."
            )
        if len({item.evaluation_id for item in evaluations}) != len(evaluations):
            raise ValueError("confirmation evaluation ids must be unique.")
        bind_hashes = {item.parameter_bind.parameter_bind_hash for item in evaluations}
        if bind_hashes != {self.source_parameter_bind_hash}:
            raise ValueError(
                "confirmation evaluations must use the source parameter binding."
            )
        plan_hashes = {item.plan.plan_hash for item in evaluations}
        if len(plan_hashes) != 1:
            raise ValueError(
                "confirmation evaluations must share one measurement plan."
            )
        expected_groups = _pool_candidate_groups(evaluations)
        groups = tuple(self.pooled_groups)
        if groups != expected_groups:
            raise ValueError(
                "pooled_groups must match independent confirmation evaluations."
            )
        expected_energy = evaluations[0].plan.constant + sum(
            item.energy_mean for item in groups
        )
        energy = _finite_float(self.energy, "energy")
        if not _close(energy, expected_energy):
            raise ValueError("energy must match pooled confirmation groups.")
        expected_error = math.sqrt(
            sum(item.energy_standard_error**2 for item in groups)
        )
        error = _finite_non_negative_float(
            self.energy_standard_error,
            "energy_standard_error",
        )
        if not _close(error, expected_error):
            raise ValueError(
                "energy_standard_error must match pooled confirmation groups."
            )
        z_value = _normal_z(confidence)
        expected_low = energy - z_value * error
        expected_high = energy + z_value * error
        low = _finite_float(self.confidence_interval_low, "confidence_interval_low")
        high = _finite_float(
            self.confidence_interval_high,
            "confidence_interval_high",
        )
        if not _close(low, expected_low) or not _close(high, expected_high):
            raise ValueError(
                "confidence interval must match pooled energy uncertainty."
            )
        expected_shots = sum(item.total_shots for item in evaluations)
        expected_executions = sum(item.backend_execution_count for item in evaluations)
        if self.total_shots != expected_shots:
            raise ValueError("total_shots must match confirmation evaluations.")
        if self.backend_execution_count != expected_executions:
            raise ValueError(
                "backend_execution_count must match confirmation evaluations."
            )
        _require_schema(self.schema_version)
        object.__setattr__(self, "confidence_level", confidence)
        object.__setattr__(self, "evaluations", evaluations)
        object.__setattr__(self, "pooled_groups", groups)
        object.__setattr__(self, "energy", energy)
        object.__setattr__(self, "energy_standard_error", error)
        object.__setattr__(self, "confidence_interval_low", low)
        object.__setattr__(self, "confidence_interval_high", high)

    @classmethod
    def create(
        cls,
        *,
        candidate_rank: int,
        source: SampledObjectiveEvaluationIR,
        confidence_level: float,
        evaluations: tuple[SampledObjectiveEvaluationIR, ...],
    ) -> SampledCandidateConfirmationIR:
        """Pool repeat evidence without treating repeat means as exact values."""
        groups = _pool_candidate_groups(evaluations)
        energy = evaluations[0].plan.constant + sum(item.energy_mean for item in groups)
        error = math.sqrt(sum(item.energy_standard_error**2 for item in groups))
        z_value = _normal_z(confidence_level)
        return cls(
            candidate_rank=candidate_rank,
            source_evaluation_index=source.evaluation_index,
            source_evaluation_id=source.evaluation_id,
            source_parameter_bind_hash=source.parameter_bind.parameter_bind_hash,
            confidence_level=confidence_level,
            evaluations=evaluations,
            pooled_groups=groups,
            energy=energy,
            energy_standard_error=error,
            confidence_interval_low=energy - z_value * error,
            confidence_interval_high=energy + z_value * error,
            total_shots=sum(item.total_shots for item in evaluations),
            backend_execution_count=sum(
                item.backend_execution_count for item in evaluations
            ),
        )

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> SampledCandidateConfirmationIR:
        """Restore one candidate and recompute its pooled statistics."""
        return cls(
            candidate_rank=data["candidate_rank"],
            source_evaluation_index=data["source_evaluation_index"],
            source_evaluation_id=data["source_evaluation_id"],
            source_parameter_bind_hash=data["source_parameter_bind_hash"],
            confidence_level=data["confidence_level"],
            evaluations=tuple(
                SampledObjectiveEvaluationIR.from_dict(
                    _mapping(item, "confirmation evaluation")
                )
                for item in _sequence(data["evaluations"], "evaluations")
            ),
            pooled_groups=tuple(
                PooledMeasurementGroupIR.from_dict(
                    _mapping(item, "pooled measurement group")
                )
                for item in _sequence(data["pooled_groups"], "pooled_groups")
            ),
            energy=data["energy"],
            energy_standard_error=data["energy_standard_error"],
            confidence_interval_low=data["confidence_interval_low"],
            confidence_interval_high=data["confidence_interval_high"],
            total_shots=data["total_shots"],
            backend_execution_count=data["backend_execution_count"],
            schema_version=str(
                data.get("schema_version", SAMPLED_SELECTION_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class SampledSelectionRoundIR(IRMixin):
    """One saved confirmation look after a complete set of candidate repeats."""

    round_index: int
    measured_candidate_ranks: tuple[int, ...]
    repeat_counts: tuple[int, ...]
    selected_candidate_rank: int
    runner_up_candidate_rank: int | None
    energy_difference: float | None
    difference_standard_error: float | None
    difference_confidence_interval_low: float | None
    difference_confidence_interval_high: float | None
    status: Literal["separated", "inconclusive", "single_candidate"]
    decision_confidence_level: float
    total_shots: int
    backend_execution_count: int
    schema_version: str = SAMPLED_SELECTION_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_non_negative_int(self.round_index, "round_index")
        measured = tuple(self.measured_candidate_ranks)
        if not measured or any(
            not isinstance(rank, int) or isinstance(rank, bool) or rank < 0
            for rank in measured
        ):
            raise ValueError(
                "measured_candidate_ranks must contain non-negative integers."
            )
        if tuple(sorted(set(measured))) != measured:
            raise ValueError("measured_candidate_ranks must be unique and sorted.")
        counts = tuple(self.repeat_counts)
        if not counts or any(
            not isinstance(count, int) or isinstance(count, bool) or count < 2
            for count in counts
        ):
            raise ValueError("repeat_counts must contain integers of at least two.")
        _require_non_negative_int(
            self.selected_candidate_rank,
            "selected_candidate_rank",
        )
        if self.runner_up_candidate_rank is not None:
            _require_non_negative_int(
                self.runner_up_candidate_rank,
                "runner_up_candidate_rank",
            )
        confidence = _finite_float(
            self.decision_confidence_level,
            "decision_confidence_level",
        )
        if not 0.0 < confidence < 1.0:
            raise ValueError("decision_confidence_level must be between zero and one.")
        for value, name in (
            (self.energy_difference, "energy_difference"),
            (self.difference_standard_error, "difference_standard_error"),
            (
                self.difference_confidence_interval_low,
                "difference_confidence_interval_low",
            ),
            (
                self.difference_confidence_interval_high,
                "difference_confidence_interval_high",
            ),
        ):
            if value is not None:
                _finite_float(value, name)
        if self.difference_standard_error is not None:
            _finite_non_negative_float(
                self.difference_standard_error,
                "difference_standard_error",
            )
        if self.status not in {"separated", "inconclusive", "single_candidate"}:
            raise ValueError(f"Unsupported sampled selection status: {self.status!r}.")
        comparison_values = (
            self.energy_difference,
            self.difference_standard_error,
            self.difference_confidence_interval_low,
            self.difference_confidence_interval_high,
        )
        if self.status == "single_candidate":
            if self.runner_up_candidate_rank is not None or any(
                value is not None for value in comparison_values
            ):
                raise ValueError(
                    "single-candidate rounds must not contain comparison evidence."
                )
        elif self.runner_up_candidate_rank is None or any(
            value is None for value in comparison_values
        ):
            raise ValueError(
                "multi-candidate rounds require complete comparison evidence."
            )
        _require_non_negative_int(self.total_shots, "total_shots")
        _require_non_negative_int(
            self.backend_execution_count,
            "backend_execution_count",
        )
        _require_schema(self.schema_version)
        object.__setattr__(self, "measured_candidate_ranks", measured)
        object.__setattr__(self, "repeat_counts", counts)
        object.__setattr__(self, "decision_confidence_level", confidence)

    @classmethod
    def create(
        cls,
        *,
        round_index: int,
        measured_candidate_ranks: tuple[int, ...],
        candidates: tuple[SampledCandidateConfirmationIR, ...],
        decision_confidence_level: float,
        selection_mode: Literal["fixed", "sequential"],
    ) -> SampledSelectionRoundIR:
        """Build one cumulative look from complete candidate evidence."""
        selected = min(
            candidates,
            key=lambda item: (item.energy, item.candidate_rank),
        )
        comparison = _selection_comparison(
            candidates,
            selected=selected,
            confidence_level=decision_confidence_level,
            challenger_rule=(
                "minimum_mean"
                if selection_mode == "fixed"
                else "minimum_difference_lower_bound"
            ),
        )
        return cls(
            round_index=round_index,
            measured_candidate_ranks=measured_candidate_ranks,
            repeat_counts=tuple(len(item.evaluations) for item in candidates),
            selected_candidate_rank=selected.candidate_rank,
            runner_up_candidate_rank=comparison[0],
            energy_difference=comparison[1],
            difference_standard_error=comparison[2],
            difference_confidence_interval_low=comparison[3],
            difference_confidence_interval_high=comparison[4],
            status=comparison[5],
            decision_confidence_level=decision_confidence_level,
            total_shots=sum(item.total_shots for item in candidates),
            backend_execution_count=sum(
                item.backend_execution_count for item in candidates
            ),
        )

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> SampledSelectionRoundIR:
        """Restore one sequential look for full-history validation by its owner."""
        return cls(
            round_index=data["round_index"],
            measured_candidate_ranks=tuple(data["measured_candidate_ranks"]),
            repeat_counts=tuple(data["repeat_counts"]),
            selected_candidate_rank=data["selected_candidate_rank"],
            runner_up_candidate_rank=data.get("runner_up_candidate_rank"),
            energy_difference=data.get("energy_difference"),
            difference_standard_error=data.get("difference_standard_error"),
            difference_confidence_interval_low=data.get(
                "difference_confidence_interval_low"
            ),
            difference_confidence_interval_high=data.get(
                "difference_confidence_interval_high"
            ),
            status=data["status"],
            decision_confidence_level=data["decision_confidence_level"],
            total_shots=data["total_shots"],
            backend_execution_count=data["backend_execution_count"],
            schema_version=str(
                data.get("schema_version", SAMPLED_SELECTION_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class SampledSelectionIR(IRMixin):
    """Independent candidate confirmation and final parameter-source decision."""

    config: SampledSelectionConfig
    root_seed: int
    evaluation_start_index: int
    confirmation_shots_per_group: int
    candidates: tuple[SampledCandidateConfirmationIR, ...]
    rounds: tuple[SampledSelectionRoundIR, ...]
    selected_candidate_rank: int
    selected_source_evaluation_index: int
    runner_up_candidate_rank: int | None
    energy_difference: float | None
    difference_standard_error: float | None
    difference_confidence_interval_low: float | None
    difference_confidence_interval_high: float | None
    status: Literal["separated", "inconclusive", "single_candidate"]
    stop_reason: _SampledSelectionStopReason
    decision_confidence_level: float
    total_shots: int
    backend_execution_count: int
    selection_rule: Literal[
        "minimum_independent_confirmation_mean",
        "minimum_sequential_confirmation_mean",
    ] = "minimum_independent_confirmation_mean"
    confidence_interval_method: Literal[
        "independent_normal_approximation",
        "bonferroni_sequential_normal_approximation",
    ] = "independent_normal_approximation"
    schema_version: str = SAMPLED_SELECTION_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if not isinstance(self.config, SampledSelectionConfig):
            raise TypeError("config must be SampledSelectionConfig.")
        _require_seed(self.root_seed, "root_seed")
        _require_non_negative_int(
            self.evaluation_start_index,
            "evaluation_start_index",
        )
        _require_integer_at_least(
            self.confirmation_shots_per_group,
            "confirmation_shots_per_group",
            2,
        )
        candidates = tuple(self.candidates)
        if not candidates or any(
            not isinstance(item, SampledCandidateConfirmationIR) for item in candidates
        ):
            raise ValueError("candidates must contain sampled candidate confirmations.")
        if len(candidates) > self.config.candidate_count:
            raise ValueError("candidate count exceeds the requested maximum.")
        if tuple(item.candidate_rank for item in candidates) != tuple(
            range(len(candidates))
        ):
            raise ValueError("candidate ranks must be contiguous and zero-based.")
        if len({item.source_evaluation_index for item in candidates}) != len(
            candidates
        ):
            raise ValueError("candidate source evaluations must be unique.")
        for candidate in candidates:
            if candidate.confidence_level != self.config.confidence_level:
                raise ValueError(
                    "candidate confidence level must match selection config."
                )
            if not (
                self.config.repeats_per_candidate
                <= len(candidate.evaluations)
                <= self.config.resolved_max_repeats_per_candidate
            ):
                raise ValueError(
                    "candidate repeats must stay within the configured range."
                )
            for repeat_index, evaluation in enumerate(candidate.evaluations):
                expected_seed = derive_sampled_confirmation_seed(
                    self.root_seed,
                    candidate_rank=candidate.candidate_rank,
                    repeat_index=repeat_index,
                )
                if evaluation.metadata.get("root_seed") != expected_seed:
                    raise ValueError(
                        "confirmation root seed does not match selection seed."
                    )
                if (
                    evaluation.plan.config.shots_per_group
                    != self.confirmation_shots_per_group
                ):
                    raise ValueError(
                        "confirmation shots must match selection evidence."
                    )
            if candidate != _candidate_prefix(
                candidate,
                len(candidate.evaluations),
            ):
                raise ValueError(
                    "candidate statistics must match all confirmation evaluations."
                )

        rounds = tuple(self.rounds)
        if not rounds or any(
            not isinstance(item, SampledSelectionRoundIR) for item in rounds
        ):
            raise ValueError("rounds must contain sampled selection looks.")
        _validate_selection_rounds(
            config=self.config,
            root_seed=self.root_seed,
            evaluation_start_index=self.evaluation_start_index,
            confirmation_shots_per_group=self.confirmation_shots_per_group,
            candidates=candidates,
            rounds=rounds,
        )

        all_evaluations = sorted(
            (
                evaluation
                for candidate in candidates
                for evaluation in candidate.evaluations
            ),
            key=lambda item: item.evaluation_index,
        )
        expected_indices = tuple(
            range(
                self.evaluation_start_index,
                self.evaluation_start_index + len(all_evaluations),
            )
        )
        if tuple(item.evaluation_index for item in all_evaluations) != expected_indices:
            raise ValueError("confirmation evaluation indices must be contiguous.")
        result_ids = [
            result_id
            for evaluation in all_evaluations
            for result_id in evaluation.result_ids
        ]
        if len(result_ids) != len(set(result_ids)):
            raise ValueError("confirmation Backend Result ids must be unique.")

        decision_confidence = _finite_float(
            self.decision_confidence_level,
            "decision_confidence_level",
        )
        if not _close(
            decision_confidence,
            self.config.decision_confidence_level,
        ):
            raise ValueError(
                "decision_confidence_level must match the selection configuration."
            )
        final_round = rounds[-1]
        if self.selected_candidate_rank != final_round.selected_candidate_rank:
            raise ValueError("selected candidate must match the final look.")
        expected_selected = candidates[self.selected_candidate_rank]
        if (
            self.selected_source_evaluation_index
            != expected_selected.source_evaluation_index
        ):
            raise ValueError(
                "selected source evaluation must match the selected candidate."
            )
        for actual, expected, name in (
            (
                self.runner_up_candidate_rank,
                final_round.runner_up_candidate_rank,
                "runner_up_candidate_rank",
            ),
            (
                self.energy_difference,
                final_round.energy_difference,
                "energy_difference",
            ),
            (
                self.difference_standard_error,
                final_round.difference_standard_error,
                "difference_standard_error",
            ),
            (
                self.difference_confidence_interval_low,
                final_round.difference_confidence_interval_low,
                "difference_confidence_interval_low",
            ),
            (
                self.difference_confidence_interval_high,
                final_round.difference_confidence_interval_high,
                "difference_confidence_interval_high",
            ),
        ):
            if name == "runner_up_candidate_rank":
                matches = actual == expected
            else:
                matches = _optional_close(actual, expected)
            if not matches:
                raise ValueError(f"{name} does not match candidate evidence.")
        if self.status != final_round.status:
            raise ValueError("selection status does not match difference evidence.")
        expected_shots = sum(item.total_shots for item in candidates)
        expected_executions = sum(item.backend_execution_count for item in candidates)
        if self.total_shots != expected_shots:
            raise ValueError("total_shots must match candidate confirmations.")
        if self.backend_execution_count != expected_executions:
            raise ValueError(
                "backend_execution_count must match candidate confirmations."
            )
        if (
            self.config.max_backend_executions is not None
            and self.backend_execution_count > self.config.max_backend_executions
        ):
            raise ValueError("confirmation Backend cost exceeds configured budget.")
        expected_rule = (
            "minimum_independent_confirmation_mean"
            if self.config.mode == "fixed"
            else "minimum_sequential_confirmation_mean"
        )
        if self.selection_rule != expected_rule:
            raise ValueError("Unsupported sampled selection rule.")
        expected_method = (
            "independent_normal_approximation"
            if self.config.mode == "fixed"
            else "bonferroni_sequential_normal_approximation"
        )
        if self.confidence_interval_method != expected_method:
            raise ValueError("Unsupported sampled confidence interval method.")
        expected_stop_reason = _selection_stop_reason(
            config=self.config,
            candidates=candidates,
            final_round=final_round,
        )
        if self.stop_reason != expected_stop_reason:
            raise ValueError("stop_reason does not match confirmation evidence.")
        _require_schema(self.schema_version)
        object.__setattr__(self, "candidates", candidates)
        object.__setattr__(self, "rounds", rounds)
        object.__setattr__(self, "decision_confidence_level", decision_confidence)

    @property
    def selected_candidate(self) -> SampledCandidateConfirmationIR:
        """Return the independently confirmed candidate used for final sampling."""
        return self.candidates[self.selected_candidate_rank]

    @classmethod
    def create(
        cls,
        *,
        config: SampledSelectionConfig,
        root_seed: int,
        evaluation_start_index: int,
        confirmation_shots_per_group: int,
        candidates: tuple[SampledCandidateConfirmationIR, ...],
        rounds: tuple[SampledSelectionRoundIR, ...],
        stop_reason: _SampledSelectionStopReason,
    ) -> SampledSelectionIR:
        """Build the final decision from the last validated confirmation look."""
        final_round = rounds[-1]
        selected = candidates[final_round.selected_candidate_rank]
        return cls(
            config=config,
            root_seed=root_seed,
            evaluation_start_index=evaluation_start_index,
            confirmation_shots_per_group=confirmation_shots_per_group,
            candidates=candidates,
            rounds=rounds,
            selected_candidate_rank=selected.candidate_rank,
            selected_source_evaluation_index=selected.source_evaluation_index,
            runner_up_candidate_rank=final_round.runner_up_candidate_rank,
            energy_difference=final_round.energy_difference,
            difference_standard_error=final_round.difference_standard_error,
            difference_confidence_interval_low=(
                final_round.difference_confidence_interval_low
            ),
            difference_confidence_interval_high=(
                final_round.difference_confidence_interval_high
            ),
            status=final_round.status,
            stop_reason=stop_reason,
            decision_confidence_level=config.decision_confidence_level,
            total_shots=sum(item.total_shots for item in candidates),
            backend_execution_count=sum(
                item.backend_execution_count for item in candidates
            ),
            selection_rule=(
                "minimum_independent_confirmation_mean"
                if config.mode == "fixed"
                else "minimum_sequential_confirmation_mean"
            ),
            confidence_interval_method=(
                "independent_normal_approximation"
                if config.mode == "fixed"
                else "bonferroni_sequential_normal_approximation"
            ),
        )

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> SampledSelectionIR:
        """Restore selection evidence and recompute its decision."""
        return cls(
            config=SampledSelectionConfig.from_dict(_mapping(data["config"], "config")),
            root_seed=data["root_seed"],
            evaluation_start_index=data["evaluation_start_index"],
            confirmation_shots_per_group=data["confirmation_shots_per_group"],
            candidates=tuple(
                SampledCandidateConfirmationIR.from_dict(
                    _mapping(item, "candidate confirmation")
                )
                for item in _sequence(data["candidates"], "candidates")
            ),
            rounds=tuple(
                SampledSelectionRoundIR.from_dict(_mapping(item, "selection round"))
                for item in _sequence(data["rounds"], "rounds")
            ),
            selected_candidate_rank=data["selected_candidate_rank"],
            selected_source_evaluation_index=data["selected_source_evaluation_index"],
            runner_up_candidate_rank=data.get("runner_up_candidate_rank"),
            energy_difference=data.get("energy_difference"),
            difference_standard_error=data.get("difference_standard_error"),
            difference_confidence_interval_low=data.get(
                "difference_confidence_interval_low"
            ),
            difference_confidence_interval_high=data.get(
                "difference_confidence_interval_high"
            ),
            status=data["status"],
            stop_reason=data["stop_reason"],
            decision_confidence_level=data["decision_confidence_level"],
            total_shots=data["total_shots"],
            backend_execution_count=data["backend_execution_count"],
            selection_rule=data.get(
                "selection_rule",
                "minimum_independent_confirmation_mean",
            ),
            confidence_interval_method=data.get(
                "confidence_interval_method",
                "independent_normal_approximation",
            ),
            schema_version=str(
                data.get("schema_version", SAMPLED_SELECTION_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> SampledSelectionIR:
        """Restore selection evidence from JSON."""
        return cls.from_dict(_json_object(text, "SampledSelectionIR"))


def derive_sampled_confirmation_seed(
    root_seed: int,
    *,
    candidate_rank: int,
    repeat_index: int,
) -> int:
    """Derive one independent and reproducible confirmation root seed."""
    _require_seed(root_seed, "root_seed")
    _require_non_negative_int(candidate_rank, "candidate_rank")
    _require_non_negative_int(repeat_index, "repeat_index")
    material = stable_json(
        {
            "namespace": _SAMPLED_CONFIRMATION_SEED_NAMESPACE,
            "root_seed": root_seed,
            "candidate_rank": candidate_rank,
            "repeat_index": repeat_index,
        }
    )
    return int.from_bytes(
        hashlib.sha256(material.encode("utf-8")).digest()[:8],
        "big",
    )


def execute_sampled_candidate_selection(
    *,
    algorithm_id: str,
    algorithm_run_id: str,
    circuit: Circuit,
    parameter_names: tuple[str, ...],
    hamiltonian: PauliHamiltonian,
    history: tuple[SampledObjectiveEvaluationIR, ...],
    config: SampledSelectionConfig,
    optimization_measurement: PauliMeasurementConfig,
    backend: LocalBackend,
    root_seed: int,
    ranked_source_indices: tuple[int, ...] | None = None,
    noise: NoiseModel | None = None,
    options: SimulationOptions | None = None,
) -> SampledSelectionIR:
    """Confirm distinct history points with fixed or sequential measurements."""
    if not history:
        raise ValueError("sampled selection requires optimization history.")
    if not isinstance(config, SampledSelectionConfig):
        raise TypeError("config must be SampledSelectionConfig.")
    if not isinstance(backend, LocalBackend):
        raise TypeError("backend must be LocalBackend.")
    if noise is not None and not isinstance(noise, NoiseModel):
        raise TypeError("noise must be NoiseModel or None.")
    if options is not None and not isinstance(options, SimulationOptions):
        raise TypeError("options must be SimulationOptions or None.")
    _require_seed(root_seed, "root_seed")
    requested_context = (noise, options)
    if any(
        (evaluation.noise_model, evaluation.requested_options) != requested_context
        for evaluation in history
    ):
        raise ValueError(
            "sampled confirmation context must match optimization history."
        )
    if any(
        evaluation.plan.config.mitigation != optimization_measurement.mitigation
        for evaluation in history
    ):
        raise ValueError(
            "sampled confirmation readout mitigation must match optimization history."
        )
    measurement = config.resolved_measurement(optimization_measurement)
    if ranked_source_indices is None:
        ranked = sorted(history, key=lambda item: (item.energy, item.evaluation_index))
    else:
        if len(ranked_source_indices) != len(set(ranked_source_indices)) or any(
            not isinstance(index, int)
            or isinstance(index, bool)
            or not 0 <= index < len(history)
            for index in ranked_source_indices
        ):
            raise ValueError(
                "ranked_source_indices must contain unique history indices."
            )
        ranked = [history[index] for index in ranked_source_indices]
    distinct: list[SampledObjectiveEvaluationIR] = []
    seen_bindings: set[str] = set()
    for evaluation in ranked:
        bind_hash = evaluation.parameter_bind.parameter_bind_hash
        if bind_hash in seen_bindings:
            continue
        seen_bindings.add(bind_hash)
        distinct.append(evaluation)
        if len(distinct) == config.candidate_count:
            break
    start_index = len(history)
    plan = build_pauli_measurement_plan(
        circuit,
        hamiltonian,
        config=measurement,
    )
    initial_cost = (
        len(distinct) * config.repeats_per_candidate * plan.backend_execution_count
    )
    if (
        config.max_backend_executions is not None
        and config.max_backend_executions < initial_cost
    ):
        raise ValueError(
            "sampled selection max_backend_executions must cover the complete "
            f"initial confirmation look ({initial_cost} Backend executions)."
        )

    evaluations_by_candidate: list[list[SampledObjectiveEvaluationIR]] = [
        [] for _ in distinct
    ]
    next_evaluation_index = start_index
    for candidate_rank, source in enumerate(distinct):
        for repeat_index in range(config.repeats_per_candidate):
            evaluations_by_candidate[candidate_rank].append(
                _execute_confirmation_repeat(
                    algorithm_id=algorithm_id,
                    algorithm_run_id=algorithm_run_id,
                    circuit=circuit,
                    parameter_names=parameter_names,
                    hamiltonian=hamiltonian,
                    measurement=measurement,
                    backend=backend,
                    root_seed=root_seed,
                    source=source,
                    candidate_rank=candidate_rank,
                    repeat_index=repeat_index,
                    evaluation_index=next_evaluation_index,
                    noise=noise,
                    options=options,
                )
            )
            next_evaluation_index += 1

    confirmations = _build_candidate_confirmations(
        sources=tuple(distinct),
        evaluations_by_candidate=evaluations_by_candidate,
        confidence_level=config.confidence_level,
    )
    rounds = [
        SampledSelectionRoundIR.create(
            round_index=0,
            measured_candidate_ranks=tuple(range(len(confirmations))),
            candidates=confirmations,
            decision_confidence_level=config.decision_confidence_level,
            selection_mode=config.mode,
        )
    ]

    stop_reason: _SampledSelectionStopReason
    if len(confirmations) == 1:
        stop_reason = "single_candidate"
    elif config.mode == "fixed":
        stop_reason = "fixed_repeats_complete"
    else:
        stop_reason = _execute_sequential_confirmation_rounds(
            algorithm_id=algorithm_id,
            algorithm_run_id=algorithm_run_id,
            circuit=circuit,
            parameter_names=parameter_names,
            hamiltonian=hamiltonian,
            measurement=measurement,
            backend=backend,
            root_seed=root_seed,
            config=config,
            sources=tuple(distinct),
            evaluations_by_candidate=evaluations_by_candidate,
            rounds=rounds,
            next_evaluation_index=next_evaluation_index,
            noise=noise,
            options=options,
        )
        confirmations = _build_candidate_confirmations(
            sources=tuple(distinct),
            evaluations_by_candidate=evaluations_by_candidate,
            confidence_level=config.confidence_level,
        )

    return SampledSelectionIR.create(
        config=config,
        root_seed=root_seed,
        evaluation_start_index=start_index,
        confirmation_shots_per_group=measurement.shots_per_group,
        candidates=confirmations,
        rounds=tuple(rounds),
        stop_reason=stop_reason,
    )


def _execute_sequential_confirmation_rounds(
    *,
    algorithm_id: str,
    algorithm_run_id: str,
    circuit: Circuit,
    parameter_names: tuple[str, ...],
    hamiltonian: PauliHamiltonian,
    measurement: PauliMeasurementConfig,
    backend: LocalBackend,
    root_seed: int,
    config: SampledSelectionConfig,
    sources: tuple[SampledObjectiveEvaluationIR, ...],
    evaluations_by_candidate: list[list[SampledObjectiveEvaluationIR]],
    rounds: list[SampledSelectionRoundIR],
    next_evaluation_index: int,
    noise: NoiseModel | None,
    options: SimulationOptions | None,
) -> _SampledSelectionStopReason:
    """Append complete adaptive looks until evidence or budget stops execution."""
    while True:
        current = _build_candidate_confirmations(
            sources=sources,
            evaluations_by_candidate=evaluations_by_candidate,
            confidence_level=config.confidence_level,
        )
        if rounds[-1].status == "separated":
            return "confidence_separated"
        targets = _adaptive_measurement_targets(
            current,
            max_repeats_per_candidate=config.resolved_max_repeats_per_candidate,
            decision_confidence_level=config.decision_confidence_level,
        )
        if not targets:
            return "max_repeats_reached"
        next_cost = sum(
            current[rank].evaluations[0].backend_execution_count for rank in targets
        )
        current_cost = sum(item.backend_execution_count for item in current)
        if (
            config.max_backend_executions is not None
            and current_cost + next_cost > config.max_backend_executions
        ):
            return "backend_budget_exhausted"

        for candidate_rank in targets:
            repeat_index = len(evaluations_by_candidate[candidate_rank])
            evaluations_by_candidate[candidate_rank].append(
                _execute_confirmation_repeat(
                    algorithm_id=algorithm_id,
                    algorithm_run_id=algorithm_run_id,
                    circuit=circuit,
                    parameter_names=parameter_names,
                    hamiltonian=hamiltonian,
                    measurement=measurement,
                    backend=backend,
                    root_seed=root_seed,
                    source=sources[candidate_rank],
                    candidate_rank=candidate_rank,
                    repeat_index=repeat_index,
                    evaluation_index=next_evaluation_index,
                    noise=noise,
                    options=options,
                )
            )
            next_evaluation_index += 1
        updated = _build_candidate_confirmations(
            sources=sources,
            evaluations_by_candidate=evaluations_by_candidate,
            confidence_level=config.confidence_level,
        )
        rounds.append(
            SampledSelectionRoundIR.create(
                round_index=len(rounds),
                measured_candidate_ranks=targets,
                candidates=updated,
                decision_confidence_level=config.decision_confidence_level,
                selection_mode=config.mode,
            )
        )


def _execute_confirmation_repeat(
    *,
    algorithm_id: str,
    algorithm_run_id: str,
    circuit: Circuit,
    parameter_names: tuple[str, ...],
    hamiltonian: PauliHamiltonian,
    measurement: PauliMeasurementConfig,
    backend: LocalBackend,
    root_seed: int,
    source: SampledObjectiveEvaluationIR,
    candidate_rank: int,
    repeat_index: int,
    evaluation_index: int,
    noise: NoiseModel | None,
    options: SimulationOptions | None,
) -> SampledObjectiveEvaluationIR:
    """Execute one complete QWC repeat with its stable derived root seed."""
    repeat_seed = derive_sampled_confirmation_seed(
        root_seed,
        candidate_rank=candidate_rank,
        repeat_index=repeat_index,
    )
    return execute_sampled_objective_evaluation(
        algorithm_id=algorithm_id,
        algorithm_run_id=algorithm_run_id,
        evaluation_index=evaluation_index,
        circuit=circuit,
        parameter_names=parameter_names,
        parameters=source.parameter_bind.values,
        hamiltonian=hamiltonian,
        measurement=measurement,
        backend=backend,
        seed=repeat_seed,
        noise=noise,
        options=options,
    )


def _build_candidate_confirmations(
    *,
    sources: tuple[SampledObjectiveEvaluationIR, ...],
    evaluations_by_candidate: Sequence[Sequence[SampledObjectiveEvaluationIR]],
    confidence_level: float,
) -> tuple[SampledCandidateConfirmationIR, ...]:
    """Pool the currently available repeats for every ranked source point."""
    return tuple(
        SampledCandidateConfirmationIR.create(
            candidate_rank=candidate_rank,
            source=source,
            confidence_level=confidence_level,
            evaluations=tuple(evaluations_by_candidate[candidate_rank]),
        )
        for candidate_rank, source in enumerate(sources)
    )


def _candidate_prefix(
    candidate: SampledCandidateConfirmationIR,
    repeat_count: int,
) -> SampledCandidateConfirmationIR:
    """Recompute one candidate from a saved prefix of its raw evaluations."""
    evaluations = candidate.evaluations[:repeat_count]
    groups = _pool_candidate_groups(evaluations)
    energy = evaluations[0].plan.constant + sum(item.energy_mean for item in groups)
    error = math.sqrt(sum(item.energy_standard_error**2 for item in groups))
    z_value = _normal_z(candidate.confidence_level)
    return SampledCandidateConfirmationIR(
        candidate_rank=candidate.candidate_rank,
        source_evaluation_index=candidate.source_evaluation_index,
        source_evaluation_id=candidate.source_evaluation_id,
        source_parameter_bind_hash=candidate.source_parameter_bind_hash,
        confidence_level=candidate.confidence_level,
        evaluations=evaluations,
        pooled_groups=groups,
        energy=energy,
        energy_standard_error=error,
        confidence_interval_low=energy - z_value * error,
        confidence_interval_high=energy + z_value * error,
        total_shots=sum(item.total_shots for item in evaluations),
        backend_execution_count=sum(
            item.backend_execution_count for item in evaluations
        ),
    )


def _adaptive_measurement_targets(
    candidates: tuple[SampledCandidateConfirmationIR, ...],
    *,
    max_repeats_per_candidate: int,
    decision_confidence_level: float,
) -> tuple[int, ...]:
    """Choose the incumbent and strongest lower-bound challenger for one look."""
    selected = min(candidates, key=lambda item: (item.energy, item.candidate_rank))
    others = tuple(item for item in candidates if item != selected)
    if not others:
        return ()
    comparison = _selection_comparison(
        candidates,
        selected=selected,
        confidence_level=decision_confidence_level,
        challenger_rule="minimum_difference_lower_bound",
    )
    challenger_rank = comparison[0]
    if challenger_rank is None:
        return ()
    challenger = candidates[challenger_rank]
    return tuple(
        sorted(
            item.candidate_rank
            for item in (selected, challenger)
            if len(item.evaluations) < max_repeats_per_candidate
        )
    )


def _validate_selection_rounds(
    *,
    config: SampledSelectionConfig,
    root_seed: int,
    evaluation_start_index: int,
    confirmation_shots_per_group: int,
    candidates: tuple[SampledCandidateConfirmationIR, ...],
    rounds: tuple[SampledSelectionRoundIR, ...],
) -> None:
    """Replay every look from raw evaluation prefixes and validate its schedule."""
    candidate_count = len(candidates)
    if config.mode == "fixed" and len(rounds) != 1:
        raise ValueError("fixed confirmation must contain exactly one look.")
    if len(rounds) > config.planned_look_count:
        raise ValueError("selection look count exceeds the planned bound.")
    previous_counts = (0,) * candidate_count
    expected_evaluation_index = evaluation_start_index
    result_ids: list[str] = []
    for round_index, round_item in enumerate(rounds):
        if round_item.round_index != round_index:
            raise ValueError("selection round indices must be contiguous.")
        if len(round_item.repeat_counts) != candidate_count:
            raise ValueError("selection repeat_counts must cover every candidate.")
        if round_index == 0:
            expected_measured = tuple(range(candidate_count))
            expected_counts = (config.repeats_per_candidate,) * candidate_count
        else:
            previous_prefixes = tuple(
                _candidate_prefix(candidate, previous_counts[rank])
                for rank, candidate in enumerate(candidates)
            )
            previous_selected = min(
                previous_prefixes,
                key=lambda item: (item.energy, item.candidate_rank),
            )
            previous_comparison = _selection_comparison(
                previous_prefixes,
                selected=previous_selected,
                confidence_level=config.decision_confidence_level,
                challenger_rule="minimum_difference_lower_bound",
            )
            if previous_comparison[5] == "separated":
                raise ValueError(
                    "sequential confirmation must stop after confidence separation."
                )
            increments = tuple(
                current - previous
                for current, previous in zip(
                    round_item.repeat_counts,
                    previous_counts,
                )
            )
            if any(increment not in {0, 1} for increment in increments):
                raise ValueError(
                    "each sequential look may add at most one repeat per candidate."
                )
            expected_measured = tuple(
                rank for rank, increment in enumerate(increments) if increment == 1
            )
            adaptive_targets = _adaptive_measurement_targets(
                previous_prefixes,
                max_repeats_per_candidate=(config.resolved_max_repeats_per_candidate),
                decision_confidence_level=config.decision_confidence_level,
            )
            if expected_measured != adaptive_targets:
                raise ValueError(
                    "selection round does not measure the adaptive target set."
                )
            expected_counts = round_item.repeat_counts
        if round_item.measured_candidate_ranks != expected_measured:
            raise ValueError(
                "measured_candidate_ranks do not match repeat-count changes."
            )
        if round_item.repeat_counts != expected_counts:
            raise ValueError(
                "the initial look must measure every configured candidate repeat."
            )
        if any(
            count > config.resolved_max_repeats_per_candidate
            for count in round_item.repeat_counts
        ):
            raise ValueError("selection round exceeds the configured repeat ceiling.")

        for candidate_rank in round_item.measured_candidate_ranks:
            start = previous_counts[candidate_rank]
            stop = round_item.repeat_counts[candidate_rank]
            for evaluation in candidates[candidate_rank].evaluations[start:stop]:
                if evaluation.evaluation_index != expected_evaluation_index:
                    raise ValueError(
                        "confirmation evaluation indices must follow round order."
                    )
                expected_seed = derive_sampled_confirmation_seed(
                    root_seed,
                    candidate_rank=candidate_rank,
                    repeat_index=start,
                )
                if evaluation.metadata.get("root_seed") != expected_seed:
                    raise ValueError(
                        "confirmation root seed does not match round schedule."
                    )
                if (
                    evaluation.plan.config.shots_per_group
                    != confirmation_shots_per_group
                ):
                    raise ValueError(
                        "confirmation shots must match selection evidence."
                    )
                result_ids.extend(evaluation.result_ids)
                expected_evaluation_index += 1
                start += 1

        prefixes = tuple(
            _candidate_prefix(candidate, round_item.repeat_counts[rank])
            for rank, candidate in enumerate(candidates)
        )
        expected_round = SampledSelectionRoundIR.create(
            round_index=round_index,
            measured_candidate_ranks=expected_measured,
            candidates=prefixes,
            decision_confidence_level=config.decision_confidence_level,
            selection_mode=config.mode,
        )
        if round_item != expected_round:
            raise ValueError(
                "selection round statistics or cumulative cost do not match evidence."
            )
        previous_counts = round_item.repeat_counts

    if previous_counts != tuple(len(item.evaluations) for item in candidates):
        raise ValueError("final selection round must include all saved evaluations.")
    if len(result_ids) != len(set(result_ids)):
        raise ValueError("confirmation Backend Result ids must be unique.")


def _selection_stop_reason(
    *,
    config: SampledSelectionConfig,
    candidates: tuple[SampledCandidateConfirmationIR, ...],
    final_round: SampledSelectionRoundIR,
) -> _SampledSelectionStopReason:
    """Recompute why no further confirmation look was executed."""
    if len(candidates) == 1:
        return "single_candidate"
    if config.mode == "fixed":
        return "fixed_repeats_complete"
    if final_round.status == "separated":
        return "confidence_separated"
    targets = _adaptive_measurement_targets(
        candidates,
        max_repeats_per_candidate=config.resolved_max_repeats_per_candidate,
        decision_confidence_level=config.decision_confidence_level,
    )
    if not targets:
        return "max_repeats_reached"
    next_cost = sum(
        candidates[rank].evaluations[0].backend_execution_count for rank in targets
    )
    if (
        config.max_backend_executions is not None
        and final_round.backend_execution_count + next_cost
        > config.max_backend_executions
    ):
        return "backend_budget_exhausted"
    raise ValueError("sequential confirmation stopped before a terminal condition.")


def _pool_candidate_groups(
    evaluations: tuple[SampledObjectiveEvaluationIR, ...],
) -> tuple[PooledMeasurementGroupIR, ...]:
    if not evaluations:
        raise ValueError("confirmation evaluations must not be empty.")
    group_count = len(evaluations[0].plan.groups)
    if any(len(item.plan.groups) != group_count for item in evaluations):
        raise ValueError("confirmation evaluations must share QWC group count.")
    estimator_kinds = {item.estimator_kind for item in evaluations}
    if len(estimator_kinds) != 1:
        raise ValueError("confirmation evaluations must share one estimator kind.")
    mitigation = evaluations[0].plan.config.mitigation
    if any(item.plan.config.mitigation != mitigation for item in evaluations[1:]):
        raise ValueError("confirmation evaluations must share one readout mitigation.")
    if mitigation is not None:
        return tuple(
            _pool_mitigated_group(
                tuple(
                    item.mitigated_group_statistics[group_index] for item in evaluations
                )
            )
            for group_index in range(group_count)
        )
    return tuple(
        _pool_raw_group(
            tuple(
                result
                for item in evaluations
                for result in (
                    (item.group_results[group_index],)
                    if not item.additional_group_results
                    else (
                        item.group_results[group_index],
                        item.additional_group_results[group_index],
                    )
                )
            )
        )
        for group_index in range(group_count)
    )


def _pool_raw_group(
    results: tuple[PauliMeasurementGroupResultIR, ...],
) -> PooledMeasurementGroupIR:
    first = results[0]
    if any(item.group != first.group for item in results):
        raise ValueError("pooled confirmation groups must share one QWC group.")
    mean, standard_error, total_shots = _pool_group_moments(
        tuple(
            (item.shots, item.energy_mean, item.energy_standard_error)
            for item in results
        )
    )
    return PooledMeasurementGroupIR(
        group_index=first.group.group_index,
        energy_mean=mean,
        energy_standard_error=standard_error,
        total_shots=total_shots,
        estimator_kind="sample_mean",
        calibration_hash=None,
    )


def _pool_mitigated_group(
    statistics: tuple[ReadoutMitigatedGroupStatisticsIR, ...],
) -> PooledMeasurementGroupIR:
    """合并独立确认中的缓解后组均值与组内采样方差。"""
    first = statistics[0]
    if any(item.group_index != first.group_index for item in statistics):
        raise ValueError("pooled mitigated groups must share one QWC group index.")
    if any(item.calibration_hash != first.calibration_hash for item in statistics):
        raise ValueError("pooled mitigated groups must share one calibration hash.")
    mean, standard_error, total_shots = _pool_group_moments(
        tuple(
            (item.shots, item.energy_mean, item.energy_standard_error)
            for item in statistics
        )
    )
    return PooledMeasurementGroupIR(
        group_index=first.group_index,
        energy_mean=mean,
        energy_standard_error=standard_error,
        total_shots=total_shots,
        estimator_kind="readout_mitigated_sample_mean",
        calibration_hash=first.calibration_hash,
    )


def _pool_group_moments(
    statistics: tuple[tuple[int, float, float], ...],
) -> tuple[float, float, int]:
    """用组内和组间平方和合并独立样本，不丢失 repeat 波动。"""
    total_shots = sum(shots for shots, _, _ in statistics)
    mean = sum(shots * value for shots, value, _ in statistics) / total_shots
    within_sum_squares = sum(
        (shots - 1) * shots * standard_error * standard_error
        for shots, _, standard_error in statistics
    )
    between_sum_squares = sum(
        shots * (value - mean) ** 2 for shots, value, _ in statistics
    )
    sample_variance = (within_sum_squares + between_sum_squares) / (total_shots - 1)
    return mean, math.sqrt(max(0.0, sample_variance) / total_shots), total_shots


def _selection_comparison(
    candidates: tuple[SampledCandidateConfirmationIR, ...],
    *,
    selected: SampledCandidateConfirmationIR,
    confidence_level: float,
    challenger_rule: Literal[
        "minimum_mean",
        "minimum_difference_lower_bound",
    ] = "minimum_mean",
) -> tuple[
    int | None,
    float | None,
    float | None,
    float | None,
    float | None,
    Literal["separated", "inconclusive", "single_candidate"],
]:
    others = tuple(item for item in candidates if item != selected)
    if not others:
        return None, None, None, None, None, "single_candidate"
    z_value = _normal_z(confidence_level)
    if challenger_rule == "minimum_mean":
        runner = min(others, key=lambda item: (item.energy, item.candidate_rank))
    elif challenger_rule == "minimum_difference_lower_bound":
        runner = min(
            others,
            key=lambda item: (
                item.energy
                - selected.energy
                - z_value
                * math.sqrt(
                    selected.energy_standard_error**2 + item.energy_standard_error**2
                ),
                item.energy,
                item.candidate_rank,
            ),
        )
    else:
        raise ValueError(f"Unsupported challenger rule: {challenger_rule!r}.")
    difference = runner.energy - selected.energy
    error = math.sqrt(
        selected.energy_standard_error**2 + runner.energy_standard_error**2
    )
    low = difference - z_value * error
    high = difference + z_value * error
    return (
        runner.candidate_rank,
        difference,
        error,
        low,
        high,
        "separated" if low > 0.0 else "inconclusive",
    )


def _normal_z(confidence_level: float) -> float:
    return NormalDist().inv_cdf(0.5 + confidence_level / 2.0)


def _require_text(value: object, name: str) -> None:
    if not isinstance(value, str) or not value.strip() or value != value.strip():
        raise ValueError(f"{name} must be a non-empty trimmed string.")


def _require_digest(value: object, name: str) -> None:
    if (
        not isinstance(value, str)
        or len(value) != 64
        or any(character not in "0123456789abcdef" for character in value)
    ):
        raise ValueError(f"{name} must be a lowercase SHA-256 digest.")


def _require_non_negative_int(value: object, name: str) -> None:
    if not isinstance(value, int) or isinstance(value, bool) or value < 0:
        raise ValueError(f"{name} must be a non-negative integer.")


def _require_integer_at_least(value: object, name: str, minimum: int) -> None:
    if not isinstance(value, int) or isinstance(value, bool) or value < minimum:
        raise ValueError(f"{name} must be an integer of at least {minimum}.")


def _require_seed(value: object, name: str) -> None:
    _require_non_negative_int(value, name)


def _finite_float(value: object, name: str) -> float:
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        raise TypeError(f"{name} must be a real number.")
    number = float(value)
    if not math.isfinite(number):
        raise ValueError(f"{name} must be finite.")
    return number


def _finite_non_negative_float(value: object, name: str) -> float:
    number = _finite_float(value, name)
    if number < 0.0:
        raise ValueError(f"{name} must be non-negative.")
    return number


def _require_schema(value: object) -> None:
    if value != SAMPLED_SELECTION_SCHEMA_VERSION:
        raise ValueError(f"Unsupported sampled selection schema: {value!r}.")


def _mapping(value: object, name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{name} must be an object.")
    return value


def _sequence(value: object, name: str) -> Sequence[Any]:
    if not isinstance(value, (list, tuple)):
        raise TypeError(f"{name} must be an array.")
    return value


def _json_object(text: str, name: str) -> Mapping[str, Any]:
    import json

    value = json.loads(text)
    if not isinstance(value, Mapping):
        raise TypeError(f"{name} JSON must contain an object.")
    return value


def _close(left: float, right: float) -> bool:
    return math.isclose(left, right, rel_tol=0.0, abs_tol=_FLOAT_TOLERANCE)


def _optional_close(left: float | None, right: float | None) -> bool:
    if left is None or right is None:
        return left is right
    return _close(left, right)
