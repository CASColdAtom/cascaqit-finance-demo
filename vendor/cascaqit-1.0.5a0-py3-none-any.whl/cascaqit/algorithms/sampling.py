"""Final sampling and problem-candidate interpretation for algorithms."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

from cascaqit.algorithms.measurement import SampledObjectiveEvaluationIR
from cascaqit.algorithms.models import (
    AlgorithmCandidateIR,
    ClassicalBaselineIR,
    ObjectiveEvaluationIR,
)
from cascaqit.algorithms.noisy_execution import (
    validate_noisy_variational_request,
    validate_sampled_variational_request,
)
from cascaqit.algorithms.problem_projection import (
    bounded_exhaustive_baseline,
    decode_problem_candidate,
)
from cascaqit.digital import Circuit
from cascaqit.problems import OptimizationProblem
from cascaqit.results import ResultIR
from cascaqit.simulators import (
    LocalBackend,
    NoiseModel,
    NoiseReport,
    SimulationExecutionPlan,
    SimulationOptions,
)

__all__ = ["build_final_sampling_circuit", "select_problem_candidates"]


@dataclass(frozen=True)
class FinalSamplingArtifacts:
    """Internal aggregate returned by the one final sampling Job."""

    result: ResultIR
    most_probable_candidate: AlgorithmCandidateIR | None
    best_observed_candidate: AlgorithmCandidateIR | None
    baseline: ClassicalBaselineIR | None
    metadata: dict[str, Any]


def execute_final_sampling(
    *,
    circuit: Circuit,
    best_evaluation: ObjectiveEvaluationIR | SampledObjectiveEvaluationIR,
    backend: LocalBackend,
    algorithm_run_id: str,
    shots: int,
    seed: int,
    problem: OptimizationProblem | None,
    mis_penalty: float,
    mwis_penalty: float | None = None,
    noise: NoiseModel | None = None,
    options: SimulationOptions | None = None,
) -> FinalSamplingArtifacts:
    """用 objective 的同一模拟与噪声上下文执行一次最终采样 Job。"""
    _positive_shots(shots)
    if not isinstance(circuit, Circuit):
        raise TypeError("circuit must be Circuit.")
    if not isinstance(
        best_evaluation, (ObjectiveEvaluationIR, SampledObjectiveEvaluationIR)
    ):
        raise TypeError("best_evaluation must be a variational objective IR.")
    if not isinstance(backend, LocalBackend):
        raise TypeError("backend must be LocalBackend.")
    if not isinstance(algorithm_run_id, str) or not algorithm_run_id.strip():
        raise ValueError("algorithm_run_id must be a non-empty string.")
    if noise is not None and not isinstance(noise, NoiseModel):
        raise TypeError("noise must be NoiseModel or None.")
    if options is not None and not isinstance(options, SimulationOptions):
        raise TypeError("options must be SimulationOptions or None.")

    if isinstance(best_evaluation, SampledObjectiveEvaluationIR):
        sampled_evaluation = best_evaluation
        source_evidence = None
        source_noise = best_evaluation.noise_model
        source_options = best_evaluation.requested_options
    else:
        sampled_evaluation = None
        source_evidence = best_evaluation.execution_evidence
        source_noise = source_evidence.noise_model
        source_options = source_evidence.requested_options
    source_noise_hash = (
        None
        if source_noise is None
        else source_noise.stable_hash()
    )
    requested_noise_hash = None if noise is None else noise.stable_hash()
    if requested_noise_hash != source_noise_hash:
        raise ValueError("final sampling NoiseModel must match the best objective.")
    source_options_hash = (
        None if source_options is None else source_options.stable_hash()
    )
    requested_options_hash = None if options is None else options.stable_hash()
    if requested_options_hash != source_options_hash:
        raise ValueError(
            "final sampling requested options must match the best objective."
        )
    source_seed = (
        source_evidence.effective_seed
        if source_evidence is not None
        else int(best_evaluation.metadata["root_seed"])
    )
    if source_seed != seed:
        raise ValueError("final sampling seed must match the best objective seed.")

    bound = build_final_sampling_circuit(
        circuit=circuit,
        best_evaluation=best_evaluation,
        algorithm_run_id=algorithm_run_id,
    )
    planned_noisy_execution = None
    if noise is not None:
        # final sampling 与 objective 使用相同的 gate 结构，因此必须复现同一个
        # density 资源决策；readout 只在 terminal measurement 后修改 counts。
        if sampled_evaluation is not None:
            planned_noisy_execution = validate_sampled_variational_request(
                bound,
                noise=noise,
                options=options,
                backend=backend,
                seed=seed,
            )
        else:
            planned_noisy_execution = validate_noisy_variational_request(
                bound,
                noise=noise,
                options=options,
                backend=backend,
                seed=seed,
            )
    job = backend.run(
        bound,
        shots=shots,
        seed=seed,
        job_id=f"{algorithm_run_id}.final_sampling",
        noise=noise,
        options=options,
    )
    result = job.result()
    _validate_counts(result.counts, shots=shots)
    status = job.status()
    plan = _result_simulation_plan(result)
    if (
        planned_noisy_execution is not None
        and plan.execution_contract()
        != planned_noisy_execution.execution_contract()
    ):
        raise RuntimeError(
            "Final sampling SimulationPlan changed between preflight and execution."
        )
    report = _result_noise_report(result, noise=noise)

    most: AlgorithmCandidateIR | None = None
    best: AlgorithmCandidateIR | None = None
    baseline: ClassicalBaselineIR | None = None
    if problem is not None:
        most, best = select_problem_candidates(
            problem,
            counts=result.counts,
            shots=shots,
            mis_penalty=mis_penalty,
            mwis_penalty=mwis_penalty,
        )
        baseline = bounded_exhaustive_baseline(
            problem,
            mis_penalty=mis_penalty,
            mwis_penalty=mwis_penalty,
        )

    metadata = {
        "final_sampling": {
            "status": "completed",
            "shots": shots,
            "seed": seed,
            "backend_id": status.backend_id,
            "backend_job_id": status.job_id,
            "backend_execution_count": status.execution_count,
            "result_id": result.result_id,
            "result_hash": result.stable_hash(),
            "program_hash": result.program_hash,
            "source_evaluation_id": best_evaluation.evaluation_id,
            "source_result_ids": (
                [best_evaluation.result_id]
                if isinstance(best_evaluation, ObjectiveEvaluationIR)
                else list(best_evaluation.result_ids)
            ),
            "source_parameter_bind_hash": (
                best_evaluation.parameter_bind.parameter_bind_hash
            ),
            "source_execution_evidence_hash": (
                None if source_evidence is None else source_evidence.evidence_hash
            ),
            "source_execution_evidence_hashes": (
                list(sampled_evaluation.execution_evidence_hashes)
                if sampled_evaluation is not None
                else None
            ),
            "source_measurement_plan_hash": (
                best_evaluation.plan.plan_hash
                if isinstance(best_evaluation, SampledObjectiveEvaluationIR)
                else None
            ),
            "noise_model": None if noise is None else noise.to_dict(),
            "noise_model_hash": requested_noise_hash,
            "requested_options": None if options is None else options.to_dict(),
            "requested_options_hash": requested_options_hash,
            "simulation_plan": plan.to_dict(),
            "simulation_plan_hash": plan.stable_hash(),
            "noise_report": None if report is None else report.to_dict(),
            "noise_report_hash": None if report is None else report.stable_hash(),
            "execution_mode": "noisy" if noise is not None else "ideal",
        },
        "candidate_status": "available" if problem is not None else "not_applicable",
        "candidate_gap": _candidate_gap(best, baseline),
    }
    return FinalSamplingArtifacts(
        result=result,
        most_probable_candidate=most,
        best_observed_candidate=best,
        baseline=baseline,
        metadata=metadata,
    )


def build_final_sampling_circuit(
    *,
    circuit: Circuit,
    best_evaluation: ObjectiveEvaluationIR | SampledObjectiveEvaluationIR,
    algorithm_run_id: str,
) -> Circuit:
    """Build the bound terminal-measurement Circuit used by final sampling.

    Problem workflows reuse this constructor to retain the exact Native Program
    that produced the final ResultIR. Keeping construction in one place prevents
    report provenance from drifting from the circuit executed by the optimizer.
    """
    if not isinstance(circuit, Circuit):
        raise TypeError("circuit must be Circuit.")
    if not isinstance(
        best_evaluation, (ObjectiveEvaluationIR, SampledObjectiveEvaluationIR)
    ):
        raise TypeError("best_evaluation must be a variational objective IR.")
    if not isinstance(algorithm_run_id, str) or not algorithm_run_id.strip():
        raise ValueError("algorithm_run_id must be a non-empty string.")
    parameter_names = tuple(parameter.name for parameter in circuit.parameters)
    if set(parameter_names) != set(best_evaluation.parameter_bind.values):
        raise ValueError("best evaluation parameters must match the final circuit.")

    # The final program has its own identity while retaining the source ansatz and
    # selected objective point as explicit provenance.
    sampling_circuit = Circuit(
        circuit.qubits,
        program_id=f"program.{algorithm_run_id}.final_sampling",
        metadata={
            "algorithm_run_id": algorithm_run_id,
            "ansatz_program_id": circuit.program_id,
            "source_evaluation_id": best_evaluation.evaluation_id,
            "source_parameter_bind_hash": (
                best_evaluation.parameter_bind.parameter_bind_hash
            ),
            "execution_role": "final_sampling",
        },
    ).compose(circuit)
    bound = sampling_circuit.bind(best_evaluation.parameter_bind.values)
    bound.measure_all(key="algorithm")
    return bound


def _result_simulation_plan(result: ResultIR) -> SimulationExecutionPlan:
    raw_plan = result.metadata.get("simulation_plan")
    if not isinstance(raw_plan, Mapping):
        raise ValueError("final Result must contain SimulationPlan metadata.")
    plan = SimulationExecutionPlan.from_dict(dict(raw_plan))
    if result.metadata.get("simulation_plan_hash") != plan.stable_hash():
        raise ValueError("final Result SimulationPlan hash does not match its facts.")
    return plan


def _result_noise_report(
    result: ResultIR,
    *,
    noise: NoiseModel | None,
) -> NoiseReport | None:
    raw_report = result.metadata.get("noise_report")
    if noise is None:
        if (
            raw_report is not None
            or result.metadata.get("noise_report_hash") is not None
        ):
            raise ValueError(
                "ideal final sampling cannot contain NoiseReport metadata."
            )
        if result.metadata.get("noise_model_hash") is not None:
            raise ValueError("ideal final sampling cannot contain NoiseModel metadata.")
        return None
    if not isinstance(raw_report, Mapping):
        raise ValueError("noisy final sampling requires NoiseReport metadata.")
    report = NoiseReport.from_dict(raw_report)
    if result.metadata.get("noise_report_hash") != report.stable_hash():
        raise ValueError("final Result NoiseReport hash does not match its facts.")
    if result.metadata.get("noise_model_hash") != noise.stable_hash():
        raise ValueError("final Result NoiseModel hash does not match the request.")
    if report.noise_model_id != noise.noise_model_id:
        raise ValueError("final NoiseReport model id does not match the request.")
    if report.noise_model_hash != noise.stable_hash():
        raise ValueError("final NoiseReport model hash does not match the request.")
    return report


def select_problem_candidates(
    problem: OptimizationProblem,
    *,
    counts: dict[str, int],
    shots: int,
    mis_penalty: float = 2.0,
    mwis_penalty: float | None = None,
) -> tuple[AlgorithmCandidateIR, AlgorithmCandidateIR]:
    """Select most-probable and minimum-objective observed candidates."""
    _positive_shots(shots)
    _validate_counts(counts, shots=shots)
    decoded = tuple(
        decode_problem_candidate(
            problem,
            bitstring,
            count=count,
            probability=count / shots,
            mis_penalty=mis_penalty,
            mwis_penalty=mwis_penalty,
        )
        for bitstring, count in sorted(counts.items())
    )
    # Both tie rules explicitly include bitstring so dictionary insertion order
    # can never change a reported candidate.
    most = min(decoded, key=lambda item: (-int(item.count or 0), item.bitstring))
    best = min(decoded, key=lambda item: (item.objective_value, item.bitstring))
    return most, best


def _candidate_gap(
    candidate: AlgorithmCandidateIR | None,
    baseline: ClassicalBaselineIR | None,
) -> dict[str, Any]:
    if candidate is None or baseline is None:
        return {"status": "not_applicable"}
    if baseline.status != "available":
        return {
            "status": "unavailable",
            "reason": baseline.unavailable_reason,
        }
    if candidate.feasible is False:
        return {
            "status": "unavailable",
            "reason": "best observed candidate is infeasible",
        }
    assert baseline.objective_value is not None
    signed_gap = candidate.objective_value - baseline.objective_value
    return {
        "status": "available",
        "objective_direction": "minimize",
        "candidate_objective": candidate.objective_value,
        "baseline_objective": baseline.objective_value,
        "signed_gap": signed_gap,
        "absolute_error": abs(signed_gap),
        "optimality_claim": "not_claimed",
    }


def _positive_shots(value: object) -> None:
    if not isinstance(value, int) or isinstance(value, bool) or value <= 0:
        raise ValueError("final_shots must be a positive integer.")


def _validate_counts(counts: object, *, shots: int) -> None:
    if not isinstance(counts, dict) or not counts:
        raise ValueError("final sampling counts must be a non-empty dictionary.")
    total = 0
    for bitstring, count in counts.items():
        if (
            not isinstance(bitstring, str)
            or not bitstring
            or set(bitstring) - {"0", "1"}
        ):
            raise ValueError("final sampling count keys must be bitstrings.")
        if not isinstance(count, int) or isinstance(count, bool) or count <= 0:
            raise ValueError("final sampling counts must be positive integers.")
        total += count
    if total != shots:
        raise ValueError("final sampling counts must sum to final_shots.")
