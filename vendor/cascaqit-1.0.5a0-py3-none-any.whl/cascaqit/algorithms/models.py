"""Typed contracts for executable variational algorithm workflows."""

from __future__ import annotations

import json
import math
import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import TYPE_CHECKING, Any, Generic, Literal, Union, cast

import numpy as np
from typing_extensions import TypeVar

from cascaqit.native_ir.base import IRMixin, canonicalize
from cascaqit.observables import Observable, ObservableBatchResultIR, ObservableSet
from cascaqit.parameters import ParameterBindIR
from cascaqit.results import ResultIR

if TYPE_CHECKING:
    from cascaqit.algorithms.adam import (
        AdamConfig,
        AdamIterationIR,
        AdamStoppingEvidenceIR,
    )
    from cascaqit.algorithms.gradient import (
        GradientConfig,
        ObjectiveGradientIR,
        ParameterShiftPlanIR,
    )
    from cascaqit.algorithms.measurement import SampledObjectiveEvaluationIR
    from cascaqit.algorithms.noisy_execution import ObjectiveExecutionEvidenceIR
    from cascaqit.algorithms.sampled_selection import SampledSelectionIR
    from cascaqit.algorithms.vqe_stability import (
        VQEStabilityConfig,
        VQEStabilityDiagnosticResult,
    )

__all__ = [
    "ALGORITHM_SCHEMA_VERSION",
    "AlgorithmCandidateIR",
    "AnsatzSpecIR",
    "CardinalityConstraintEvidenceIR",
    "CardinalitySubspaceEvidenceIR",
    "ClassicalBaselineIR",
    "HamiltonianContributionIR",
    "HamiltonianTerm",
    "ObjectiveEvaluationIR",
    "OptimizationStartIR",
    "OptimizerConfig",
    "OptimizerTerminationIR",
    "PauliHamiltonian",
    "SPSAConfig",
    "SPSADirectionIR",
    "SPSAIterationIR",
    "SPSALearningRateCalibrationConfig",
    "SPSALearningRateCalibrationIR",
    "SPSAObjectiveEstimateIR",
    "SPSAStoppingCheckIR",
    "SPSAStoppingConfig",
    "SPSAStoppingEvidenceIR",
    "VariationalResult",
    "build_cardinality_subspace_evidence",
    "validate_adam_start_evidence",
    "validate_spsa_start_evidence",
]

ALGORITHM_SCHEMA_VERSION = "cascaqit.algorithms.v3"
AlgorithmKind = Literal["qaoa", "vqe"]
LayerTransferKind = Literal["append_last_layer", "unsupported"]
OptimizerMethod = Literal[
    "COBYLA",
    "Nelder-Mead",
    "Powell",
    "L-BFGS-B",
    "SPSA",
    "ADAM",
]
InitializationStrategy = Literal["random", "layerwise"]
BaselineStatus = Literal["available", "unavailable"]
_DIGEST_PATTERN = re.compile(r"[0-9a-f]{64}")
_ENERGY_TOLERANCE = 1e-12
_OPTIMIZER_METHODS = frozenset(
    {"COBYLA", "Nelder-Mead", "Powell", "L-BFGS-B", "SPSA", "ADAM"}
)
_MANAGED_SCIPY_OPTIONS = frozenset({"maxiter", "maxfev", "maxfun"})
_ALGORITHM_KINDS = frozenset({"qaoa", "vqe"})
VariationalObjectiveT = TypeVar(
    "VariationalObjectiveT",
    default="ObjectiveEvaluationIR",
    covariant=True,
)


@dataclass(frozen=True)
class HamiltonianTerm(IRMixin):
    """One non-zero weighted Pauli product in a Hamiltonian."""

    term_id: str
    coefficient: float
    observable: Observable
    schema_version: str = ALGORITHM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_text(self.term_id, "term_id")
        object.__setattr__(
            self,
            "coefficient",
            _finite_float(self.coefficient, "coefficient"),
        )
        if self.coefficient == 0.0:
            raise ValueError("Hamiltonian term coefficient must be non-zero.")
        if not isinstance(self.observable, Observable):
            raise TypeError("observable must be Observable.")

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> HamiltonianTerm:
        """Build a Hamiltonian term from JSON-compatible data."""
        return cls(
            term_id=data["term_id"],
            coefficient=data["coefficient"],
            observable=Observable.from_dict(_mapping(data["observable"], "observable")),
            schema_version=str(data.get("schema_version", ALGORITHM_SCHEMA_VERSION)),
        )


@dataclass(frozen=True)
class PauliHamiltonian(IRMixin):
    """An ordered weighted sum evaluated through one ObservableSet batch."""

    hamiltonian_id: str
    terms: tuple[HamiltonianTerm, ...]
    constant: float = 0.0
    logical_order: tuple[str, ...] = ()
    source_problem_id: str | None = None
    source_problem_hash: str | None = None
    metadata: Mapping[str, Any] = field(default_factory=dict)
    schema_version: str = ALGORITHM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_text(self.hamiltonian_id, "hamiltonian_id")
        if not isinstance(self.terms, tuple):
            object.__setattr__(self, "terms", tuple(self.terms))
        if not self.terms:
            raise ValueError("PauliHamiltonian terms must not be empty.")
        if any(not isinstance(term, HamiltonianTerm) for term in self.terms):
            raise TypeError("terms must contain HamiltonianTerm values.")
        term_ids = tuple(term.term_id for term in self.terms)
        if len(term_ids) != len(set(term_ids)):
            raise ValueError("Hamiltonian term_id values must be unique.")
        observable_names = tuple(term.observable.name for term in self.terms)
        if len(observable_names) != len(set(observable_names)):
            raise ValueError("Hamiltonian observable names must be unique.")
        observable_hashes = tuple(term.observable.stable_hash() for term in self.terms)
        if len(observable_hashes) != len(set(observable_hashes)):
            raise ValueError(
                "Hamiltonian Pauli products must be normalized and unique."
            )
        object.__setattr__(self, "constant", _finite_float(self.constant, "constant"))
        object.__setattr__(self, "logical_order", tuple(self.logical_order))
        _require_unique_text(self.logical_order, "logical_order", allow_empty=False)
        targets = {target for term in self.terms for target in term.observable.targets}
        if self.logical_order and not targets.issubset(set(self.logical_order)):
            raise ValueError("Hamiltonian terms contain targets outside logical_order.")
        if (self.source_problem_id is None) != (self.source_problem_hash is None):
            raise ValueError(
                "source_problem_id and source_problem_hash must be provided together."
            )
        if self.source_problem_id is not None:
            _require_text(self.source_problem_id, "source_problem_id")
            _require_digest(self.source_problem_hash, "source_problem_hash")
        object.__setattr__(self, "metadata", _freeze_mapping(self.metadata))

    def observable_set(self) -> ObservableSet:
        """Return the one ordered batch declaration for all weighted terms."""
        return ObservableSet(term.observable for term in self.terms)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> PauliHamiltonian:
        """Build a Hamiltonian from JSON-compatible data."""
        raw_terms = data.get("terms", ())
        if not isinstance(raw_terms, (list, tuple)):
            raise TypeError("Hamiltonian terms must be an array.")
        raw_order = data.get("logical_order", ())
        if not isinstance(raw_order, (list, tuple)):
            raise TypeError("logical_order must be an array.")
        return cls(
            hamiltonian_id=data["hamiltonian_id"],
            terms=tuple(
                HamiltonianTerm.from_dict(_mapping(item, "term")) for item in raw_terms
            ),
            constant=data.get("constant", 0.0),
            logical_order=tuple(raw_order),
            source_problem_id=data.get("source_problem_id"),
            source_problem_hash=data.get("source_problem_hash"),
            metadata=_mapping(data.get("metadata", {}), "metadata"),
            schema_version=str(data.get("schema_version", ALGORITHM_SCHEMA_VERSION)),
        )

    @classmethod
    def from_json(cls, text: str) -> PauliHamiltonian:
        """Build a Hamiltonian from JSON text."""
        return cls.from_dict(_json_object(text, "PauliHamiltonian"))


@dataclass(frozen=True)
class SPSAStoppingConfig(IRMixin):
    """Thresholds for native SPSA online stability stopping."""

    window_size: int = 3
    min_iterations: int = 3
    objective_range_tolerance: float = 1e-3
    update_norm_tolerance: float = 1e-3
    gradient_norm_tolerance: float = 1e-2
    gradient_standard_error_norm_tolerance: float | None = None
    sampled_standard_error_tolerance: float | None = None
    schema_version: str = ALGORITHM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_positive_int(self.window_size, "window_size")
        if self.window_size < 2:
            raise ValueError("window_size must be at least 2.")
        _require_positive_int(self.min_iterations, "min_iterations")
        if self.min_iterations < self.window_size:
            raise ValueError("min_iterations must be at least window_size.")
        for name in (
            "objective_range_tolerance",
            "update_norm_tolerance",
            "gradient_norm_tolerance",
        ):
            value = _finite_float(getattr(self, name), name)
            if value <= 0.0:
                raise ValueError(f"{name} must be positive.")
            object.__setattr__(self, name, value)
        for name in (
            "gradient_standard_error_norm_tolerance",
            "sampled_standard_error_tolerance",
        ):
            raw_value = getattr(self, name)
            if raw_value is None:
                continue
            value = _finite_float(raw_value, name)
            if value <= 0.0:
                raise ValueError(f"{name} must be positive.")
            object.__setattr__(self, name, value)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> SPSAStoppingConfig:
        """Restore online stopping thresholds from JSON-compatible data."""
        return cls(
            window_size=data.get("window_size", 3),
            min_iterations=data.get("min_iterations", 3),
            objective_range_tolerance=data.get("objective_range_tolerance", 1e-3),
            update_norm_tolerance=data.get("update_norm_tolerance", 1e-3),
            gradient_norm_tolerance=data.get("gradient_norm_tolerance", 1e-2),
            gradient_standard_error_norm_tolerance=data.get(
                "gradient_standard_error_norm_tolerance"
            ),
            sampled_standard_error_tolerance=data.get(
                "sampled_standard_error_tolerance"
            ),
            schema_version=str(data.get("schema_version", ALGORITHM_SCHEMA_VERSION)),
        )

    @classmethod
    def from_json(cls, text: str) -> SPSAStoppingConfig:
        """Restore online stopping thresholds from JSON text."""
        return cls.from_dict(_json_object(text, "SPSAStoppingConfig"))


@dataclass(frozen=True)
class SPSALearningRateCalibrationConfig(IRMixin):
    """Controls pre-iteration calibration of the SPSA learning-rate scale."""

    directions: int = 5
    target_update_rms: float = 0.1
    gradient_rms_floor: float = 1e-8
    max_learning_rate: float | None = None
    schema_version: str = ALGORITHM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_positive_int(self.directions, "directions")
        for name in ("target_update_rms", "gradient_rms_floor"):
            value = _finite_float(getattr(self, name), name)
            if value <= 0.0:
                raise ValueError(f"{name} must be positive.")
            object.__setattr__(self, name, value)
        if self.max_learning_rate is not None:
            maximum = _finite_float(self.max_learning_rate, "max_learning_rate")
            if maximum <= 0.0:
                raise ValueError("max_learning_rate must be positive.")
            object.__setattr__(self, "max_learning_rate", maximum)

    @classmethod
    def from_dict(
        cls,
        data: Mapping[str, Any],
    ) -> SPSALearningRateCalibrationConfig:
        """Restore learning-rate calibration settings from compatible data."""
        return cls(
            directions=data.get("directions", 5),
            target_update_rms=data.get("target_update_rms", 0.1),
            gradient_rms_floor=data.get("gradient_rms_floor", 1e-8),
            max_learning_rate=data.get("max_learning_rate"),
            schema_version=str(data.get("schema_version", ALGORITHM_SCHEMA_VERSION)),
        )

    @classmethod
    def from_json(cls, text: str) -> SPSALearningRateCalibrationConfig:
        """Restore learning-rate calibration settings from JSON text."""
        return cls.from_dict(
            _json_object(text, "SPSALearningRateCalibrationConfig")
        )


@dataclass(frozen=True)
class SPSAConfig(IRMixin):
    """Gain schedules for native simultaneous-perturbation optimization."""

    learning_rate: float | None = 0.2
    perturbation: float = 0.1
    stability_constant: float = 0.0
    learning_rate_exponent: float = 0.602
    perturbation_exponent: float = 0.101
    directions_per_iteration: int = 1
    objective_repeats: int = 1
    max_objective_repeats: int | None = None
    objective_standard_error_target: float | None = None
    learning_rate_calibration: SPSALearningRateCalibrationConfig | None = None
    stopping: SPSAStoppingConfig | None = None
    schema_version: str = ALGORITHM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        learning_rate = (
            None
            if self.learning_rate is None
            else _finite_float(self.learning_rate, "learning_rate")
        )
        perturbation = _finite_float(self.perturbation, "perturbation")
        stability = _finite_float(self.stability_constant, "stability_constant")
        alpha = _finite_float(
            self.learning_rate_exponent,
            "learning_rate_exponent",
        )
        gamma = _finite_float(
            self.perturbation_exponent,
            "perturbation_exponent",
        )
        if self.learning_rate_calibration is None:
            if learning_rate is None or learning_rate <= 0.0:
                raise ValueError(
                    "fixed SPSA requires a positive learning_rate."
                )
        else:
            if not isinstance(
                self.learning_rate_calibration,
                SPSALearningRateCalibrationConfig,
            ):
                raise TypeError(
                    "learning_rate_calibration must be "
                    "SPSALearningRateCalibrationConfig or None."
                )
            if learning_rate is not None:
                raise ValueError(
                    "calibrated SPSA requires learning_rate=None."
                )
        if perturbation <= 0.0:
            raise ValueError("perturbation must be positive.")
        if stability < 0.0:
            raise ValueError("stability_constant must be non-negative.")
        if not 0.5 < alpha <= 1.0:
            raise ValueError(
                "learning_rate_exponent must be greater than 0.5 and at most 1."
            )
        if not 0.0 <= gamma <= 0.5:
            raise ValueError(
                "perturbation_exponent must be between 0 and 0.5 inclusive."
            )
        if alpha - gamma <= 0.5:
            raise ValueError(
                "learning_rate_exponent - perturbation_exponent must exceed 0.5."
            )
        _require_positive_int(
            self.directions_per_iteration,
            "directions_per_iteration",
        )
        _require_positive_int(self.objective_repeats, "objective_repeats")
        if (self.max_objective_repeats is None) != (
            self.objective_standard_error_target is None
        ):
            raise ValueError(
                "max_objective_repeats and objective_standard_error_target must be "
                "provided together."
            )
        if self.max_objective_repeats is not None:
            _require_positive_int(
                self.max_objective_repeats,
                "max_objective_repeats",
            )
            if self.objective_repeats < 2:
                raise ValueError(
                    "adaptive objective resampling requires objective_repeats "
                    "of at least 2."
                )
            if self.max_objective_repeats <= self.objective_repeats:
                raise ValueError(
                    "max_objective_repeats must be greater than objective_repeats."
                )
            target = _finite_float(
                self.objective_standard_error_target,
                "objective_standard_error_target",
            )
            if target <= 0.0:
                raise ValueError(
                    "objective_standard_error_target must be positive."
                )
            object.__setattr__(self, "objective_standard_error_target", target)
        if self.stopping is not None:
            if not isinstance(self.stopping, SPSAStoppingConfig):
                raise TypeError("stopping must be SPSAStoppingConfig or None.")
            if (
                self.stopping.gradient_standard_error_norm_tolerance is not None
                and self.directions_per_iteration < 2
            ):
                raise ValueError(
                    "gradient standard-error stopping requires at least two "
                    "directions per iteration."
                )
            if (
                self.stopping.sampled_standard_error_tolerance is not None
                and self.objective_repeats < 2
            ):
                raise ValueError(
                    "sampled standard-error stopping requires objective_repeats "
                    "of at least 2."
                )
        object.__setattr__(self, "learning_rate", learning_rate)
        object.__setattr__(self, "perturbation", perturbation)
        object.__setattr__(self, "stability_constant", stability)
        object.__setattr__(self, "learning_rate_exponent", alpha)
        object.__setattr__(self, "perturbation_exponent", gamma)

    @property
    def objective_repeat_mode(self) -> Literal["fixed", "adaptive"]:
        """Return whether logical objectives use fixed or adaptive repeats."""
        return "adaptive" if self.max_objective_repeats is not None else "fixed"

    @property
    def effective_max_objective_repeats(self) -> int:
        """Return the largest allowed repeat count for one logical objective."""
        return (
            self.objective_repeats
            if self.max_objective_repeats is None
            else self.max_objective_repeats
        )

    def to_dict(self) -> dict[str, Any]:
        """Serialize adaptive fields only when adaptive resampling is enabled."""
        data = super().to_dict()
        if self.objective_repeat_mode == "fixed":
            data.pop("max_objective_repeats", None)
            data.pop("objective_standard_error_target", None)
        if self.stopping is None:
            data.pop("stopping", None)
        if self.learning_rate_calibration is None:
            data.pop("learning_rate_calibration", None)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> SPSAConfig:
        """Build SPSA gain schedules from JSON-compatible data."""
        return cls(
            learning_rate=data.get("learning_rate", 0.2),
            perturbation=data.get("perturbation", 0.1),
            stability_constant=data.get("stability_constant", 0.0),
            learning_rate_exponent=data.get("learning_rate_exponent", 0.602),
            perturbation_exponent=data.get("perturbation_exponent", 0.101),
            directions_per_iteration=data.get("directions_per_iteration", 1),
            objective_repeats=data.get("objective_repeats", 1),
            max_objective_repeats=data.get("max_objective_repeats"),
            objective_standard_error_target=data.get(
                "objective_standard_error_target"
            ),
            learning_rate_calibration=(
                None
                if data.get("learning_rate_calibration") is None
                else SPSALearningRateCalibrationConfig.from_dict(
                    _mapping(
                        data["learning_rate_calibration"],
                        "learning_rate_calibration",
                    )
                )
            ),
            stopping=(
                None
                if data.get("stopping") is None
                else SPSAStoppingConfig.from_dict(
                    _mapping(data["stopping"], "stopping")
                )
            ),
            schema_version=str(data.get("schema_version", ALGORITHM_SCHEMA_VERSION)),
        )

    @classmethod
    def from_json(cls, text: str) -> SPSAConfig:
        """Build SPSA gain schedules from JSON text."""
        return cls.from_dict(_json_object(text, "SPSAConfig"))


@dataclass(frozen=True)
class OptimizerConfig(IRMixin):
    """Deterministic configuration for one executable optimizer."""

    method: OptimizerMethod = "COBYLA"
    max_iterations: int = 80
    max_evaluations: int | None = None
    max_backend_executions: int | None = None
    starts: int = 1
    initialization: InitializationStrategy = "random"
    tolerance: float = 1e-6
    seed: int | None = None
    bounds: tuple[tuple[float, float], ...] = ()
    options: Mapping[str, bool | int | float] = field(default_factory=dict)
    gradient: GradientConfig | None = None
    spsa: SPSAConfig | None = None
    adam: AdamConfig | None = None
    schema_version: str = ALGORITHM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.method not in _OPTIMIZER_METHODS:
            raise ValueError(f"Unsupported optimizer method: {self.method!r}.")
        _require_positive_int(self.max_iterations, "max_iterations")
        if self.max_evaluations is not None:
            _require_positive_int(self.max_evaluations, "max_evaluations")
        if self.max_backend_executions is not None:
            _require_positive_int(
                self.max_backend_executions,
                "max_backend_executions",
            )
        _require_positive_int(self.starts, "starts")
        if self.initialization not in {"random", "layerwise"}:
            raise ValueError(
                f"Unsupported initialization strategy: {self.initialization!r}."
            )
        tolerance = _finite_float(self.tolerance, "tolerance")
        if tolerance <= 0.0:
            raise ValueError("tolerance must be positive.")
        object.__setattr__(self, "tolerance", tolerance)
        if self.seed is not None and (
            not isinstance(self.seed, int)
            or isinstance(self.seed, bool)
            or self.seed < 0
        ):
            raise ValueError("seed must be a non-negative integer or None.")
        if not isinstance(self.bounds, tuple):
            object.__setattr__(self, "bounds", tuple(self.bounds))
        normalized_bounds: list[tuple[float, float]] = []
        for index, bound in enumerate(self.bounds):
            if not isinstance(bound, (list, tuple)) or len(bound) != 2:
                raise TypeError(f"bounds[{index}] must contain lower and upper values.")
            lower = _finite_float(bound[0], f"bounds[{index}].lower")
            upper = _finite_float(bound[1], f"bounds[{index}].upper")
            if lower >= upper:
                raise ValueError(f"bounds[{index}] lower must be less than upper.")
            normalized_bounds.append((lower, upper))
        object.__setattr__(self, "bounds", tuple(normalized_bounds))
        normalized_options: dict[str, bool | int | float] = {}
        for name, value in self.options.items():
            _require_text(name, "option name")
            if name in _MANAGED_SCIPY_OPTIONS:
                raise ValueError(
                    f"options[{name}] is managed by max_iterations or max_evaluations."
                )
            if isinstance(value, (bool, int)):
                normalized_options[name] = value
            else:
                normalized_options[name] = _finite_float(value, f"options[{name}]")
        object.__setattr__(self, "options", MappingProxyType(normalized_options))
        from cascaqit.algorithms.adam import AdamConfig
        from cascaqit.algorithms.gradient import GradientConfig

        if self.method == "L-BFGS-B":
            if not isinstance(self.gradient, GradientConfig):
                raise ValueError("L-BFGS-B requires a GradientConfig.")
            if self.spsa is not None:
                raise ValueError("L-BFGS-B does not accept an SPSA configuration.")
            if self.adam is not None:
                raise ValueError("L-BFGS-B does not accept an Adam configuration.")
        elif self.method == "SPSA":
            if self.gradient is not None:
                raise ValueError("SPSA does not accept a gradient configuration.")
            if normalized_options:
                raise ValueError("SPSA does not accept SciPy options.")
            if self.spsa is None:
                object.__setattr__(self, "spsa", SPSAConfig())
            elif not isinstance(self.spsa, SPSAConfig):
                raise TypeError("spsa must be SPSAConfig or None.")
            if self.adam is not None:
                raise ValueError("SPSA does not accept an Adam configuration.")
            assert self.spsa is not None
            if (
                self.spsa.stopping is not None
                and self.max_iterations < self.spsa.stopping.min_iterations
            ):
                raise ValueError(
                    "max_iterations must be at least the SPSA stopping "
                    "min_iterations."
                )
        elif self.method == "ADAM":
            if not isinstance(self.gradient, GradientConfig):
                raise ValueError("ADAM requires a GradientConfig.")
            if self.spsa is not None:
                raise ValueError("ADAM does not accept an SPSA configuration.")
            if normalized_options:
                raise ValueError("ADAM does not accept SciPy options.")
            if self.adam is None:
                object.__setattr__(self, "adam", AdamConfig())
            elif not isinstance(self.adam, AdamConfig):
                raise TypeError("adam must be AdamConfig or None.")
            assert self.adam is not None
            if (
                self.adam.stopping is not None
                and self.max_iterations < self.adam.stopping.min_iterations
            ):
                raise ValueError(
                    "max_iterations must be at least the Adam stopping "
                    "min_iterations."
                )
        elif self.gradient is not None:
            raise ValueError(f"{self.method} does not accept a gradient configuration.")
        elif self.spsa is not None:
            raise ValueError(f"{self.method} does not accept an SPSA configuration.")
        elif self.adam is not None:
            raise ValueError(f"{self.method} does not accept an Adam configuration.")

    def to_dict(self) -> dict[str, Any]:
        """Keep pre-Adam optimizer payloads stable when Adam is unused."""
        data = super().to_dict()
        if self.adam is None:
            data.pop("adam", None)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> OptimizerConfig:
        """Build optimizer configuration from JSON-compatible data."""
        from cascaqit.algorithms.adam import AdamConfig
        from cascaqit.algorithms.gradient import GradientConfig

        raw_bounds = data.get("bounds", ())
        if not isinstance(raw_bounds, (list, tuple)):
            raise TypeError("bounds must be an array.")
        return cls(
            method=data.get("method", "COBYLA"),
            max_iterations=data.get("max_iterations", 80),
            max_evaluations=data.get("max_evaluations"),
            max_backend_executions=data.get("max_backend_executions"),
            starts=data.get("starts", 1),
            initialization=data.get("initialization", "random"),
            tolerance=data.get("tolerance", 1e-6),
            seed=data.get("seed"),
            bounds=tuple(raw_bounds),
            options=_mapping(data.get("options", {}), "options"),
            gradient=(
                None
                if data.get("gradient") is None
                else GradientConfig.from_dict(_mapping(data["gradient"], "gradient"))
            ),
            spsa=(
                None
                if data.get("spsa") is None
                else SPSAConfig.from_dict(_mapping(data["spsa"], "spsa"))
            ),
            adam=(
                None
                if data.get("adam") is None
                else AdamConfig.from_dict(_mapping(data["adam"], "adam"))
            ),
            schema_version=str(data.get("schema_version", ALGORITHM_SCHEMA_VERSION)),
        )

    @classmethod
    def from_json(cls, text: str) -> OptimizerConfig:
        """Build optimizer configuration from JSON text."""
        return cls.from_dict(_json_object(text, "OptimizerConfig"))


@dataclass(frozen=True)
class AnsatzSpecIR(IRMixin):
    """Stable parameter and qubit layout of one variational ansatz."""

    ansatz_id: str
    ansatz_kind: Literal[
        "qaoa",
        "hardware_efficient",
        "cardinality_preserving",
        "custom",
    ]
    layers: int
    logical_order: tuple[str, ...]
    parameter_names: tuple[str, ...]
    circuit_hash: str | None = None
    definition: Mapping[str, Any] = field(default_factory=dict)
    required_gates: tuple[str, ...] = ()
    layer_transfer: LayerTransferKind = "unsupported"
    metadata: Mapping[str, Any] = field(default_factory=dict)
    schema_version: str = ALGORITHM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_text(self.ansatz_id, "ansatz_id")
        if self.ansatz_kind not in {
            "qaoa",
            "hardware_efficient",
            "cardinality_preserving",
            "custom",
        }:
            raise ValueError(f"Unsupported ansatz_kind: {self.ansatz_kind!r}.")
        _require_positive_int(self.layers, "layers")
        object.__setattr__(self, "logical_order", tuple(self.logical_order))
        object.__setattr__(self, "parameter_names", tuple(self.parameter_names))
        _require_unique_text(self.logical_order, "logical_order", allow_empty=False)
        _require_unique_text(self.parameter_names, "parameter_names", allow_empty=False)
        if self.circuit_hash is not None:
            _require_digest(self.circuit_hash, "circuit_hash")
        object.__setattr__(self, "definition", _freeze_mapping(self.definition))
        object.__setattr__(self, "required_gates", tuple(self.required_gates))
        _require_unique_text(self.required_gates, "required_gates", allow_empty=True)
        if self.layer_transfer not in {"append_last_layer", "unsupported"}:
            raise ValueError(f"Unsupported layer_transfer: {self.layer_transfer!r}.")
        if self.ansatz_kind == "custom" and self.layer_transfer != "unsupported":
            raise ValueError("Custom ansatz layer transfer must be unsupported.")
        object.__setattr__(self, "metadata", _freeze_mapping(self.metadata))

    @property
    def spec_hash(self) -> str:
        """Return the stable hash of all declared ansatz facts."""
        return self.stable_hash()

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> AnsatzSpecIR:
        """Build an ansatz specification from JSON-compatible data."""
        return cls(
            ansatz_id=data["ansatz_id"],
            ansatz_kind=data["ansatz_kind"],
            layers=data["layers"],
            logical_order=tuple(_sequence(data["logical_order"], "logical_order")),
            parameter_names=tuple(
                _sequence(data["parameter_names"], "parameter_names")
            ),
            circuit_hash=data.get("circuit_hash"),
            definition=_mapping(data.get("definition", {}), "definition"),
            required_gates=tuple(
                _sequence(data.get("required_gates", ()), "required_gates")
            ),
            layer_transfer=data.get("layer_transfer", "unsupported"),
            metadata=_mapping(data.get("metadata", {}), "metadata"),
            schema_version=str(data.get("schema_version", ALGORITHM_SCHEMA_VERSION)),
        )


@dataclass(frozen=True)
class HamiltonianContributionIR(IRMixin):
    """Auditable weighted contribution from one Observable batch item."""

    term_id: str
    observable_name: str
    coefficient: float
    expectation: float
    contribution: float
    schema_version: str = ALGORITHM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_text(self.term_id, "term_id")
        _require_text(self.observable_name, "observable_name")
        coefficient = _finite_float(self.coefficient, "coefficient")
        expectation = _finite_float(self.expectation, "expectation")
        contribution = _finite_float(self.contribution, "contribution")
        if not -1.0 - _ENERGY_TOLERANCE <= expectation <= 1.0 + _ENERGY_TOLERANCE:
            raise ValueError("expectation must be within the Pauli range [-1, 1].")
        if not math.isclose(
            contribution,
            coefficient * expectation,
            rel_tol=0.0,
            abs_tol=_ENERGY_TOLERANCE,
        ):
            raise ValueError("contribution must equal coefficient * expectation.")
        object.__setattr__(self, "coefficient", coefficient)
        object.__setattr__(self, "expectation", expectation)
        object.__setattr__(self, "contribution", contribution)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> HamiltonianContributionIR:
        """Build one contribution from JSON-compatible data."""
        return cls(
            term_id=data["term_id"],
            observable_name=data["observable_name"],
            coefficient=data["coefficient"],
            expectation=data["expectation"],
            contribution=data["contribution"],
            schema_version=str(data.get("schema_version", ALGORITHM_SCHEMA_VERSION)),
        )


@dataclass(frozen=True)
class ObjectiveEvaluationIR(IRMixin):
    """One real Backend objective evaluation and its weighted evidence."""

    evaluation_id: str
    evaluation_index: int
    parameter_bind: ParameterBindIR
    hamiltonian_hash: str
    constant: float
    contributions: tuple[HamiltonianContributionIR, ...]
    energy: float
    observable_batch: ObservableBatchResultIR
    execution_evidence: ObjectiveExecutionEvidenceIR
    result_id: str
    result_hash: str
    wall_time_seconds: float
    cache_hit: bool = False
    metadata: Mapping[str, Any] = field(default_factory=dict)
    schema_version: str = ALGORITHM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_text(self.evaluation_id, "evaluation_id")
        if (
            not isinstance(self.evaluation_index, int)
            or isinstance(self.evaluation_index, bool)
            or self.evaluation_index < 0
        ):
            raise ValueError("evaluation_index must be a non-negative integer.")
        if not isinstance(self.parameter_bind, ParameterBindIR):
            raise TypeError("parameter_bind must be ParameterBindIR.")
        if not self.parameter_bind.verify_hash():
            raise ValueError("parameter_bind_hash does not match parameter values.")
        _require_digest(self.hamiltonian_hash, "hamiltonian_hash")
        constant = _finite_float(self.constant, "constant")
        if not isinstance(self.contributions, tuple):
            object.__setattr__(self, "contributions", tuple(self.contributions))
        if not self.contributions:
            raise ValueError("contributions must not be empty.")
        if any(
            not isinstance(item, HamiltonianContributionIR)
            for item in self.contributions
        ):
            raise TypeError("contributions must contain HamiltonianContributionIR.")
        term_ids = tuple(item.term_id for item in self.contributions)
        if len(term_ids) != len(set(term_ids)):
            raise ValueError("contribution term_id values must be unique.")
        if not isinstance(self.observable_batch, ObservableBatchResultIR):
            raise TypeError("observable_batch must be ObservableBatchResultIR.")
        from cascaqit.algorithms.noisy_execution import ObjectiveExecutionEvidenceIR

        if not isinstance(self.execution_evidence, ObjectiveExecutionEvidenceIR):
            raise TypeError("execution_evidence must be ObjectiveExecutionEvidenceIR.")
        contribution_names = tuple(item.observable_name for item in self.contributions)
        batch_names = tuple(item.name for item in self.observable_batch.items)
        if contribution_names != batch_names:
            raise ValueError(
                "contributions must match Observable batch declaration order."
            )
        for contribution, observed in zip(
            self.contributions,
            self.observable_batch.items,
        ):
            if not math.isclose(
                contribution.expectation,
                observed.expectation,
                rel_tol=0.0,
                abs_tol=_ENERGY_TOLERANCE,
            ):
                raise ValueError(
                    "contribution expectation must match Observable batch evidence."
                )
        energy = _finite_float(self.energy, "energy")
        reconstructed = constant + sum(item.contribution for item in self.contributions)
        if not math.isclose(
            energy,
            reconstructed,
            rel_tol=0.0,
            abs_tol=_ENERGY_TOLERANCE,
        ):
            raise ValueError("energy must equal constant plus weighted contributions.")
        _require_text(self.result_id, "result_id")
        _require_digest(self.result_hash, "result_hash")
        if self.execution_evidence.result_id != self.result_id:
            raise ValueError("execution evidence result_id must match evaluation.")
        if self.execution_evidence.result_hash != self.result_hash:
            raise ValueError("execution evidence result_hash must match evaluation.")
        if (
            self.execution_evidence.estimator_kind
            != self.observable_batch.items[0].estimator_kind
        ):
            raise ValueError(
                "execution evidence estimator must match Observable batch."
            )
        if self.execution_evidence.source_kind != self.observable_batch.source_kind:
            raise ValueError("execution evidence source must match Observable batch.")
        batch_sample_counts = {
            item.sample_count for item in self.observable_batch.items
        }
        if batch_sample_counts != {self.execution_evidence.sample_count}:
            raise ValueError(
                "execution evidence sample_count must match Observable batch."
            )
        batch_errors = {
            item.name: item.standard_error for item in self.observable_batch.items
        }
        if dict(self.execution_evidence.observable_standard_errors) != batch_errors:
            raise ValueError(
                "execution evidence standard errors must match Observable batch."
            )
        wall = _finite_float(self.wall_time_seconds, "wall_time_seconds")
        if wall < 0.0:
            raise ValueError("wall_time_seconds must be non-negative.")
        if self.cache_hit is not False:
            raise ValueError("a21 objective evaluations must not be cached.")
        object.__setattr__(self, "constant", constant)
        object.__setattr__(self, "energy", energy)
        object.__setattr__(self, "wall_time_seconds", wall)
        object.__setattr__(self, "metadata", _freeze_mapping(self.metadata))

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ObjectiveEvaluationIR:
        """Build one objective evaluation from JSON-compatible data."""
        raw_contributions = data.get("contributions", ())
        if not isinstance(raw_contributions, (list, tuple)):
            raise TypeError("contributions must be an array.")
        return cls(
            evaluation_id=data["evaluation_id"],
            evaluation_index=data["evaluation_index"],
            parameter_bind=ParameterBindIR.from_dict(
                _mapping(data["parameter_bind"], "parameter_bind")
            ),
            hamiltonian_hash=data["hamiltonian_hash"],
            constant=data["constant"],
            contributions=tuple(
                HamiltonianContributionIR.from_dict(_mapping(item, "contribution"))
                for item in raw_contributions
            ),
            energy=data["energy"],
            observable_batch=ObservableBatchResultIR.from_dict(
                _mapping(data["observable_batch"], "observable_batch")
            ),
            execution_evidence=_objective_execution_evidence_from_dict(
                _mapping(data["execution_evidence"], "execution_evidence")
            ),
            result_id=data["result_id"],
            result_hash=data["result_hash"],
            wall_time_seconds=data["wall_time_seconds"],
            cache_hit=data.get("cache_hit", False),
            metadata=_mapping(data.get("metadata", {}), "metadata"),
            schema_version=str(data.get("schema_version", ALGORITHM_SCHEMA_VERSION)),
        )


def _objective_execution_evidence_from_dict(
    data: Mapping[str, Any],
) -> ObjectiveExecutionEvidenceIR:
    from cascaqit.algorithms.noisy_execution import ObjectiveExecutionEvidenceIR

    return ObjectiveExecutionEvidenceIR.from_dict(data)


@dataclass(frozen=True)
class SPSAObjectiveEstimateIR(IRMixin):
    """One logical SPSA objective pooled from complete physical evaluations."""

    role: Literal["initial", "plus", "minus", "final"]
    evaluation_offsets: tuple[int, ...]
    objective_values: tuple[float, ...]
    pooled_objective: float
    pooled_standard_error: float | None
    stop_reason: Literal[
        "fixed_repeats",
        "target_reached",
        "max_repeats_reached",
        "budget_exhausted",
    ] = "fixed_repeats"
    schema_version: str = ALGORITHM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.role not in {"initial", "plus", "minus", "final"}:
            raise ValueError(f"Unsupported SPSA objective role: {self.role!r}.")
        offsets = tuple(self.evaluation_offsets)
        if not offsets:
            raise ValueError("SPSA objective estimate requires evaluation offsets.")
        for offset in offsets:
            _require_non_negative_int(offset, "evaluation_offset")
        if offsets != tuple(sorted(set(offsets))):
            raise ValueError("SPSA evaluation offsets must be strictly increasing.")
        values = tuple(
            _finite_float(value, "objective_value") for value in self.objective_values
        )
        if len(values) != len(offsets):
            raise ValueError("SPSA objective values must match evaluation offsets.")
        expected_mean = math.fsum(values) / len(values)
        pooled = _finite_float(self.pooled_objective, "pooled_objective")
        if not math.isclose(pooled, expected_mean, rel_tol=0.0, abs_tol=1e-12):
            raise ValueError("pooled_objective must match repeated objective values.")
        expected_error = (
            None
            if len(values) == 1
            else math.sqrt(
                math.fsum((value - expected_mean) ** 2 for value in values)
                / (len(values) - 1)
            )
            / math.sqrt(len(values))
        )
        error = self.pooled_standard_error
        if expected_error is None:
            if error is not None:
                raise ValueError(
                    "pooled_standard_error must be None for one objective repeat."
                )
        else:
            if error is None or not math.isclose(
                _finite_float(error, "pooled_standard_error"),
                expected_error,
                rel_tol=0.0,
                abs_tol=1e-12,
            ):
                raise ValueError(
                    "pooled_standard_error must match repeated objective values."
                )
        object.__setattr__(self, "evaluation_offsets", offsets)
        object.__setattr__(self, "objective_values", values)
        object.__setattr__(self, "pooled_objective", pooled)
        object.__setattr__(self, "pooled_standard_error", expected_error)
        if self.stop_reason not in {
            "fixed_repeats",
            "target_reached",
            "max_repeats_reached",
            "budget_exhausted",
        }:
            raise ValueError(
                f"Unsupported SPSA objective stop reason: {self.stop_reason!r}."
            )

    @property
    def repeat_count(self) -> int:
        """Return the number of complete evaluations in this estimate."""
        return len(self.evaluation_offsets)

    @property
    def source_evaluation_offset(self) -> int:
        """Return the stable evaluation used as the parameter-binding source."""
        return self.evaluation_offsets[0]

    def to_dict(self) -> dict[str, Any]:
        """Keep fixed-repeat serialization byte-compatible with its original IR."""
        data = super().to_dict()
        if self.stop_reason == "fixed_repeats":
            data.pop("stop_reason", None)
        return data

    @classmethod
    def create(
        cls,
        *,
        role: Literal["initial", "plus", "minus", "final"],
        evaluation_offsets: tuple[int, ...],
        objective_values: tuple[float, ...],
        stop_reason: Literal[
            "fixed_repeats",
            "target_reached",
            "max_repeats_reached",
            "budget_exhausted",
        ] = "fixed_repeats",
    ) -> SPSAObjectiveEstimateIR:
        """Pool repeated values and build recomputable estimate evidence."""
        values = tuple(float(value) for value in objective_values)
        mean = math.fsum(values) / len(values) if values else math.nan
        standard_error = (
            None
            if len(values) <= 1
            else math.sqrt(
                math.fsum((value - mean) ** 2 for value in values) / (len(values) - 1)
            )
            / math.sqrt(len(values))
        )
        return cls(
            role=role,
            evaluation_offsets=evaluation_offsets,
            objective_values=values,
            pooled_objective=mean,
            pooled_standard_error=standard_error,
            stop_reason=stop_reason,
        )

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> SPSAObjectiveEstimateIR:
        """Restore one pooled objective and recompute its statistics."""
        return cls(
            role=data["role"],
            evaluation_offsets=tuple(data["evaluation_offsets"]),
            objective_values=tuple(data["objective_values"]),
            pooled_objective=data["pooled_objective"],
            pooled_standard_error=data.get("pooled_standard_error"),
            stop_reason=data.get("stop_reason", "fixed_repeats"),
            schema_version=str(data.get("schema_version", ALGORITHM_SCHEMA_VERSION)),
        )

    @classmethod
    def from_json(cls, text: str) -> SPSAObjectiveEstimateIR:
        """Restore one pooled objective from JSON text."""
        return cls.from_dict(_json_object(text, "SPSAObjectiveEstimateIR"))


@dataclass(frozen=True)
class SPSADirectionIR(IRMixin):
    """One complete plus/minus perturbation direction inside an SPSA update."""

    direction_index: int
    perturbation_vector: Mapping[str, int]
    plus_parameters: Mapping[str, float]
    minus_parameters: Mapping[str, float]
    plus_estimate: SPSAObjectiveEstimateIR
    minus_estimate: SPSAObjectiveEstimateIR
    gradient_estimate: Mapping[str, float]
    schema_version: str = ALGORITHM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_non_negative_int(self.direction_index, "direction_index")
        mappings = {
            "plus_parameters": _finite_parameter_mapping(
                self.plus_parameters,
                "plus_parameters",
            ),
            "minus_parameters": _finite_parameter_mapping(
                self.minus_parameters,
                "minus_parameters",
            ),
            "gradient_estimate": _finite_parameter_mapping(
                self.gradient_estimate,
                "gradient_estimate",
            ),
        }
        parameter_names = tuple(mappings["plus_parameters"])
        if not parameter_names or any(
            tuple(values) != parameter_names for values in mappings.values()
        ):
            raise ValueError(
                "all SPSA direction parameter mappings must share ordered keys."
            )
        if not isinstance(self.perturbation_vector, Mapping):
            raise TypeError("perturbation_vector must be a mapping.")
        perturbations: dict[str, int] = {}
        for name, value in self.perturbation_vector.items():
            _require_text(name, "perturbation_vector key")
            if (
                not isinstance(value, int)
                or isinstance(value, bool)
                or value not in {-1, 1}
            ):
                raise ValueError("SPSA perturbations must be -1 or 1.")
            perturbations[str(name)] = value
        if tuple(perturbations) != parameter_names:
            raise ValueError(
                "perturbation_vector must match the ordered SPSA parameters."
            )
        if not isinstance(self.plus_estimate, SPSAObjectiveEstimateIR) or (
            self.plus_estimate.role != "plus"
        ):
            raise TypeError("plus_estimate must be a plus SPSAObjectiveEstimateIR.")
        if not isinstance(self.minus_estimate, SPSAObjectiveEstimateIR) or (
            self.minus_estimate.role != "minus"
        ):
            raise TypeError("minus_estimate must be a minus SPSAObjectiveEstimateIR.")
        if self.plus_estimate.repeat_count != self.minus_estimate.repeat_count:
            raise ValueError("SPSA plus and minus estimates must use equal repeats.")
        if self.plus_estimate.stop_reason != self.minus_estimate.stop_reason:
            raise ValueError(
                "SPSA plus and minus estimates must share one stop reason."
            )
        if set(self.plus_estimate.evaluation_offsets).intersection(
            self.minus_estimate.evaluation_offsets
        ):
            raise ValueError("SPSA plus and minus evaluations must be distinct.")
        object.__setattr__(
            self,
            "perturbation_vector",
            MappingProxyType(perturbations),
        )
        for name, values in mappings.items():
            object.__setattr__(self, name, values)

    @property
    def plus_evaluation_offset(self) -> int:
        """Return the stable source offset for the plus parameter point."""
        return self.plus_estimate.source_evaluation_offset

    @property
    def minus_evaluation_offset(self) -> int:
        """Return the stable source offset for the minus parameter point."""
        return self.minus_estimate.source_evaluation_offset

    @property
    def plus_objective(self) -> float:
        """Return the pooled plus objective used by this direction."""
        return self.plus_estimate.pooled_objective

    @property
    def minus_objective(self) -> float:
        """Return the pooled minus objective used by this direction."""
        return self.minus_estimate.pooled_objective

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> SPSADirectionIR:
        """Restore one direction; its parent iteration recomputes the gradient."""
        return cls(
            direction_index=data["direction_index"],
            perturbation_vector=_mapping(
                data["perturbation_vector"],
                "perturbation_vector",
            ),
            plus_parameters=_mapping(data["plus_parameters"], "plus_parameters"),
            minus_parameters=_mapping(data["minus_parameters"], "minus_parameters"),
            plus_estimate=SPSAObjectiveEstimateIR.from_dict(
                _mapping(data["plus_estimate"], "plus_estimate")
            ),
            minus_estimate=SPSAObjectiveEstimateIR.from_dict(
                _mapping(data["minus_estimate"], "minus_estimate")
            ),
            gradient_estimate=_mapping(
                data["gradient_estimate"],
                "gradient_estimate",
            ),
            schema_version=str(data.get("schema_version", ALGORITHM_SCHEMA_VERSION)),
        )


@dataclass(frozen=True)
class SPSALearningRateCalibrationIR(IRMixin):
    """Recomputable SPSA learning-rate calibration evidence for one start."""

    parameter_names: tuple[str, ...]
    center_parameters: Mapping[str, float]
    perturbation: float
    directions: tuple[SPSADirectionIR, ...]
    gradient_estimate: Mapping[str, float]
    gradient_rms: float
    target_update_rms: float
    derived_learning_rate: float
    projection_applied: bool
    schema_version: str = ALGORITHM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        parameter_names = tuple(self.parameter_names)
        _require_unique_text(
            parameter_names,
            "parameter_names",
            allow_empty=False,
        )
        center = _finite_parameter_mapping(
            self.center_parameters,
            "center_parameters",
        )
        gradient = _finite_parameter_mapping(
            self.gradient_estimate,
            "gradient_estimate",
        )
        if set(center) != set(parameter_names) or set(gradient) != set(
            parameter_names
        ):
            raise ValueError(
                "calibration center and gradient must match parameter_names."
            )
        perturbation = _finite_float(self.perturbation, "perturbation")
        if perturbation <= 0.0:
            raise ValueError("calibration perturbation must be positive.")
        directions = tuple(self.directions)
        if not directions or any(
            not isinstance(direction, SPSADirectionIR) for direction in directions
        ):
            raise TypeError(
                "calibration directions must contain SPSADirectionIR values."
            )
        if tuple(direction.direction_index for direction in directions) != tuple(
            range(len(directions))
        ):
            raise ValueError(
                "calibration direction indices must be contiguous and zero-based."
            )
        for direction in directions:
            if set(direction.gradient_estimate) != set(parameter_names):
                raise ValueError(
                    "calibration direction parameters must match the center."
                )
            if all(
                math.isclose(
                    direction.plus_parameters[name],
                    direction.minus_parameters[name],
                    rel_tol=0.0,
                    abs_tol=1e-15,
                )
                for name in parameter_names
            ):
                raise ValueError(
                    "calibration directions must move at least one parameter."
                )
            objective_difference = (
                direction.plus_objective - direction.minus_objective
            )
            expected_direction_gradient = {
                name: objective_difference
                / (2.0 * perturbation)
                * direction.perturbation_vector[name]
                for name in parameter_names
            }
            _require_parameter_mapping_values_close(
                direction.gradient_estimate,
                expected_direction_gradient,
                "calibration direction gradient_estimate",
            )
        expected_gradient = {
            name: math.fsum(
                direction.gradient_estimate[name] for direction in directions
            )
            / len(directions)
            for name in parameter_names
        }
        _require_parameter_mapping_values_close(
            gradient,
            expected_gradient,
            "calibration gradient_estimate",
        )
        expected_rms = math.sqrt(
            math.fsum(value * value for value in expected_gradient.values())
            / len(parameter_names)
        )
        gradient_rms = _finite_float(self.gradient_rms, "gradient_rms")
        if gradient_rms < 0.0 or not math.isclose(
            gradient_rms,
            expected_rms,
            rel_tol=0.0,
            abs_tol=1e-12,
        ):
            raise ValueError("gradient_rms must match the calibration gradient.")
        target = _finite_float(self.target_update_rms, "target_update_rms")
        derived = _finite_float(self.derived_learning_rate, "derived_learning_rate")
        if target <= 0.0 or derived <= 0.0:
            raise ValueError(
                "calibration target and derived learning rate must be positive."
            )
        if not isinstance(self.projection_applied, bool):
            raise TypeError("projection_applied must be bool.")
        object.__setattr__(self, "parameter_names", parameter_names)
        object.__setattr__(self, "center_parameters", center)
        object.__setattr__(self, "perturbation", perturbation)
        object.__setattr__(self, "directions", directions)
        object.__setattr__(self, "gradient_estimate", gradient)
        object.__setattr__(self, "gradient_rms", gradient_rms)
        object.__setattr__(self, "target_update_rms", target)
        object.__setattr__(self, "derived_learning_rate", derived)

    @classmethod
    def from_dict(
        cls,
        data: Mapping[str, Any],
    ) -> SPSALearningRateCalibrationIR:
        """Restore calibration evidence and recompute all direction facts."""
        raw_directions = data.get("directions", ())
        if not isinstance(raw_directions, (list, tuple)):
            raise TypeError("calibration directions must be an array.")
        return cls(
            parameter_names=tuple(
                _sequence(data["parameter_names"], "parameter_names")
            ),
            center_parameters=_mapping(
                data["center_parameters"],
                "center_parameters",
            ),
            perturbation=data["perturbation"],
            directions=tuple(
                SPSADirectionIR.from_dict(_mapping(item, "calibration_direction"))
                for item in raw_directions
            ),
            gradient_estimate=_mapping(
                data["gradient_estimate"],
                "gradient_estimate",
            ),
            gradient_rms=data["gradient_rms"],
            target_update_rms=data["target_update_rms"],
            derived_learning_rate=data["derived_learning_rate"],
            projection_applied=data["projection_applied"],
            schema_version=str(data.get("schema_version", ALGORITHM_SCHEMA_VERSION)),
        )


@dataclass(frozen=True)
class SPSAIterationIR(IRMixin):
    """One SPSA update derived from one or more perturbation directions."""

    iteration_index: int
    learning_rate: float
    perturbation: float
    center_parameters: Mapping[str, float]
    directions: tuple[SPSADirectionIR, ...]
    gradient_estimate: Mapping[str, float]
    gradient_standard_error: Mapping[str, float] | None
    unprojected_parameters: Mapping[str, float]
    updated_parameters: Mapping[str, float]
    update_norm: float
    projection_applied: bool
    schema_version: str = ALGORITHM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_non_negative_int(self.iteration_index, "iteration_index")
        learning_rate = _finite_float(self.learning_rate, "learning_rate")
        perturbation = _finite_float(self.perturbation, "perturbation")
        if learning_rate <= 0.0 or perturbation <= 0.0:
            raise ValueError("SPSA learning rate and perturbation must be positive.")
        mappings = {
            "center_parameters": _finite_parameter_mapping(
                self.center_parameters,
                "center_parameters",
            ),
            "gradient_estimate": _finite_parameter_mapping(
                self.gradient_estimate,
                "gradient_estimate",
            ),
            "unprojected_parameters": _finite_parameter_mapping(
                self.unprojected_parameters,
                "unprojected_parameters",
            ),
            "updated_parameters": _finite_parameter_mapping(
                self.updated_parameters,
                "updated_parameters",
            ),
        }
        parameter_names = tuple(mappings["center_parameters"])
        if not parameter_names or any(
            tuple(values) != parameter_names for values in mappings.values()
        ):
            raise ValueError("all SPSA parameter mappings must share ordered keys.")
        directions = tuple(self.directions)
        if not directions or any(
            not isinstance(direction, SPSADirectionIR) for direction in directions
        ):
            raise TypeError("directions must contain SPSADirectionIR values.")
        if tuple(direction.direction_index for direction in directions) != tuple(
            range(len(directions))
        ):
            raise ValueError(
                "SPSA direction indices must be contiguous and zero-based."
            )
        for direction in directions:
            if tuple(direction.gradient_estimate) != parameter_names:
                raise ValueError(
                    "SPSA direction parameters must match iteration parameters."
                )
            objective_difference = (
                direction.plus_objective - direction.minus_objective
            )
            expected_direction_gradient = {
                name: objective_difference
                / (2.0 * perturbation)
                * direction.perturbation_vector[name]
                for name in parameter_names
            }
            _require_parameter_mapping_close(
                direction.gradient_estimate,
                expected_direction_gradient,
                "direction gradient_estimate",
            )
        expected_gradient = {
            name: math.fsum(
                direction.gradient_estimate[name] for direction in directions
            )
            / len(directions)
            for name in parameter_names
        }
        _require_parameter_mapping_close(
            mappings["gradient_estimate"],
            expected_gradient,
            "gradient_estimate",
        )
        if len(directions) == 1:
            if self.gradient_standard_error is not None:
                raise ValueError(
                    "gradient_standard_error requires at least two directions."
                )
            gradient_standard_error = None
        else:
            if self.gradient_standard_error is None:
                raise ValueError(
                    "multiple SPSA directions require gradient_standard_error."
                )
            gradient_standard_error = _finite_parameter_mapping(
                self.gradient_standard_error,
                "gradient_standard_error",
            )
            if tuple(gradient_standard_error) != parameter_names:
                raise ValueError(
                    "gradient_standard_error must match iteration parameters."
                )
            expected_standard_error = {
                name: math.sqrt(
                    math.fsum(
                        (
                            direction.gradient_estimate[name]
                            - expected_gradient[name]
                        )
                        ** 2
                        for direction in directions
                    )
                    / (len(directions) - 1)
                )
                / math.sqrt(len(directions))
                for name in parameter_names
            }
            _require_parameter_mapping_close(
                gradient_standard_error,
                expected_standard_error,
                "gradient_standard_error",
            )
        expected_unprojected = {
            name: mappings["center_parameters"][name]
            - learning_rate * expected_gradient[name]
            for name in parameter_names
        }
        _require_parameter_mapping_close(
            mappings["unprojected_parameters"],
            expected_unprojected,
            "unprojected_parameters",
        )
        if not isinstance(self.projection_applied, bool):
            raise TypeError("projection_applied must be bool.")
        if not self.projection_applied:
            for direction in directions:
                expected_plus = {
                    name: mappings["center_parameters"][name]
                    + perturbation * direction.perturbation_vector[name]
                    for name in parameter_names
                }
                expected_minus = {
                    name: mappings["center_parameters"][name]
                    - perturbation * direction.perturbation_vector[name]
                    for name in parameter_names
                }
                _require_parameter_mapping_close(
                    direction.plus_parameters,
                    expected_plus,
                    "plus_parameters",
                )
                _require_parameter_mapping_close(
                    direction.minus_parameters,
                    expected_minus,
                    "minus_parameters",
                )
            _require_parameter_mapping_close(
                mappings["updated_parameters"],
                expected_unprojected,
                "updated_parameters",
            )
        expected_norm = math.sqrt(
            math.fsum(
                (
                    mappings["updated_parameters"][name]
                    - mappings["center_parameters"][name]
                )
                ** 2
                for name in parameter_names
            )
        )
        update_norm = _finite_float(self.update_norm, "update_norm")
        if update_norm < 0.0 or not math.isclose(
            update_norm,
            expected_norm,
            rel_tol=0.0,
            abs_tol=1e-12,
        ):
            raise ValueError("update_norm must match the projected SPSA update.")
        object.__setattr__(self, "learning_rate", learning_rate)
        object.__setattr__(self, "perturbation", perturbation)
        object.__setattr__(self, "directions", directions)
        for name, values in mappings.items():
            object.__setattr__(self, name, values)
        object.__setattr__(
            self,
            "gradient_standard_error",
            gradient_standard_error,
        )
        object.__setattr__(self, "update_norm", update_norm)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> SPSAIterationIR:
        """Restore one iteration and recompute all direction-derived facts."""
        raw_directions = data.get("directions", ())
        if not isinstance(raw_directions, (list, tuple)):
            raise TypeError("directions must be an array.")
        return cls(
            iteration_index=data["iteration_index"],
            learning_rate=data["learning_rate"],
            perturbation=data["perturbation"],
            center_parameters=_mapping(
                data["center_parameters"],
                "center_parameters",
            ),
            directions=tuple(
                SPSADirectionIR.from_dict(_mapping(item, "spsa_direction"))
                for item in raw_directions
            ),
            gradient_estimate=_mapping(
                data["gradient_estimate"],
                "gradient_estimate",
            ),
            gradient_standard_error=(
                None
                if data.get("gradient_standard_error") is None
                else _mapping(
                    data["gradient_standard_error"],
                    "gradient_standard_error",
                )
            ),
            unprojected_parameters=_mapping(
                data["unprojected_parameters"],
                "unprojected_parameters",
            ),
            updated_parameters=_mapping(
                data["updated_parameters"],
                "updated_parameters",
            ),
            update_norm=data["update_norm"],
            projection_applied=data["projection_applied"],
            schema_version=str(data.get("schema_version", ALGORITHM_SCHEMA_VERSION)),
        )


SPSAStoppingCheckName = Literal[
    "objective_range",
    "update_norm",
    "gradient_norm",
    "gradient_standard_error_norm",
    "sampled_standard_error",
]
SPSAStoppingCheckStatus = Literal["passed", "failed", "unavailable"]
SPSAStoppingStatus = Literal[
    "insufficient_evidence",
    "thresholds_not_met",
    "stability_reached",
]
_SPSA_STOPPING_CHECK_NAMES = frozenset(
    (
        "objective_range",
        "update_norm",
        "gradient_norm",
        "gradient_standard_error_norm",
        "sampled_standard_error",
    )
)


@dataclass(frozen=True)
class SPSAStoppingCheckIR(IRMixin):
    """One online SPSA threshold check and its recomputable scalar evidence."""

    name: SPSAStoppingCheckName
    status: SPSAStoppingCheckStatus
    observed_value: float | None
    threshold: float
    sample_count: int
    schema_version: str = ALGORITHM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.name not in _SPSA_STOPPING_CHECK_NAMES:
            raise ValueError(f"Unsupported SPSA stopping check: {self.name!r}.")
        if self.status not in {"passed", "failed", "unavailable"}:
            raise ValueError(f"Unsupported SPSA stopping status: {self.status!r}.")
        threshold = _finite_float(self.threshold, "threshold")
        if threshold <= 0.0:
            raise ValueError("threshold must be positive.")
        _require_non_negative_int(self.sample_count, "sample_count")
        if self.status == "unavailable":
            if self.observed_value is not None:
                raise ValueError("unavailable checks cannot have an observed value.")
        else:
            observed = _finite_float(self.observed_value, "observed_value")
            if observed < 0.0:
                raise ValueError("observed_value must be non-negative.")
            expected = "passed" if observed <= threshold else "failed"
            if self.status != expected:
                raise ValueError(
                    "check status must match observed value and threshold."
                )
            object.__setattr__(self, "observed_value", observed)
        object.__setattr__(self, "threshold", threshold)

    @classmethod
    def create(
        cls,
        *,
        name: SPSAStoppingCheckName,
        observed_value: float | None,
        threshold: float,
        sample_count: int,
    ) -> SPSAStoppingCheckIR:
        """Build a check whose status is derived from its observed value."""
        status: SPSAStoppingCheckStatus
        if observed_value is None:
            status = "unavailable"
        else:
            status = "passed" if observed_value <= threshold else "failed"
        return cls(
            name=name,
            status=status,
            observed_value=observed_value,
            threshold=threshold,
            sample_count=sample_count,
        )

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> SPSAStoppingCheckIR:
        """Restore one online stopping check from JSON-compatible data."""
        return cls(
            name=cast(SPSAStoppingCheckName, data["name"]),
            status=cast(SPSAStoppingCheckStatus, data["status"]),
            observed_value=data.get("observed_value"),
            threshold=data["threshold"],
            sample_count=data["sample_count"],
            schema_version=str(data.get("schema_version", ALGORITHM_SCHEMA_VERSION)),
        )


@dataclass(frozen=True)
class SPSAStoppingEvidenceIR(IRMixin):
    """Last online stopping decision derived from an SPSA iteration prefix."""

    status: SPSAStoppingStatus
    window_iteration_indices: tuple[int, ...]
    objective_proxy_values: tuple[float, ...]
    checks: tuple[SPSAStoppingCheckIR, ...]
    schema_version: str = ALGORITHM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.status not in {
            "insufficient_evidence",
            "thresholds_not_met",
            "stability_reached",
        }:
            raise ValueError(f"Unsupported SPSA stopping evidence: {self.status!r}.")
        indices = tuple(self.window_iteration_indices)
        if any(
            not isinstance(index, int) or isinstance(index, bool) or index < 0
            for index in indices
        ):
            raise ValueError("window iteration indices must be non-negative integers.")
        if tuple(sorted(indices)) != indices or len(set(indices)) != len(indices):
            raise ValueError("window iteration indices must be unique and ordered.")
        proxies = tuple(
            _finite_float(value, "objective_proxy_value")
            for value in self.objective_proxy_values
        )
        if len(proxies) != len(indices):
            raise ValueError("objective proxies must match the stopping window.")
        checks = tuple(self.checks)
        if not checks or any(
            not isinstance(check, SPSAStoppingCheckIR) for check in checks
        ):
            raise TypeError("checks must contain SPSAStoppingCheckIR values.")
        expected_names: tuple[str, ...] = (
            "objective_range",
            "update_norm",
            "gradient_norm",
        )
        if any(check.name == "gradient_standard_error_norm" for check in checks):
            expected_names += ("gradient_standard_error_norm",)
        if any(check.name == "sampled_standard_error" for check in checks):
            expected_names += ("sampled_standard_error",)
        if tuple(check.name for check in checks) != expected_names:
            raise ValueError("SPSA stopping checks must use the canonical order.")
        statuses = {check.status for check in checks}
        expected_status: SPSAStoppingStatus
        if "unavailable" in statuses:
            expected_status = "insufficient_evidence"
        elif "failed" in statuses:
            expected_status = "thresholds_not_met"
        else:
            expected_status = "stability_reached"
        if self.status != expected_status:
            raise ValueError("evidence status must match its stopping checks.")
        object.__setattr__(self, "window_iteration_indices", indices)
        object.__setattr__(self, "objective_proxy_values", proxies)
        object.__setattr__(self, "checks", checks)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> SPSAStoppingEvidenceIR:
        """Restore online stopping evidence from JSON-compatible data."""
        raw_checks = data.get("checks", ())
        if not isinstance(raw_checks, (list, tuple)):
            raise TypeError("checks must be an array.")
        return cls(
            status=cast(SPSAStoppingStatus, data["status"]),
            window_iteration_indices=tuple(data.get("window_iteration_indices", ())),
            objective_proxy_values=tuple(data.get("objective_proxy_values", ())),
            checks=tuple(
                SPSAStoppingCheckIR.from_dict(_mapping(item, "stopping_check"))
                for item in raw_checks
            ),
            schema_version=str(data.get("schema_version", ALGORITHM_SCHEMA_VERSION)),
        )


@dataclass(frozen=True)
class OptimizerTerminationIR(IRMixin):
    """Optimizer termination facts plus a stable CASCAQit reason."""

    method: OptimizerMethod
    success: bool
    status: int
    message: str
    nfev: int
    nit: int | None
    reason: Literal[
        "completed",
        "stability_reached",
        "max_iterations",
        "max_evaluations",
        "max_gradient_evaluations",
        "max_backend_executions",
        "failed",
    ]
    njev: int = 0
    backend_execution_count: int | None = None
    schema_version: str = ALGORITHM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.method not in _OPTIMIZER_METHODS:
            raise ValueError(f"Unsupported optimizer method: {self.method!r}.")
        if not isinstance(self.success, bool):
            raise TypeError("success must be bool.")
        if not isinstance(self.status, int) or isinstance(self.status, bool):
            raise TypeError("status must be int.")
        _require_text(self.message, "message")
        _require_positive_int(self.nfev, "nfev")
        _require_non_negative_int(self.njev, "njev")
        if self.nit is not None and (
            not isinstance(self.nit, int) or isinstance(self.nit, bool) or self.nit < 0
        ):
            raise ValueError("nit must be a non-negative integer or None.")
        if self.reason not in {
            "completed",
            "stability_reached",
            "max_iterations",
            "max_evaluations",
            "max_gradient_evaluations",
            "max_backend_executions",
            "failed",
        }:
            raise ValueError(f"Unsupported termination reason: {self.reason!r}.")
        if self.success != (self.reason in {"completed", "stability_reached"}):
            raise ValueError(
                "success is true exactly for completed or stability_reached."
            )
        backend_count = (
            self.nfev
            if self.backend_execution_count is None
            else self.backend_execution_count
        )
        _require_positive_int(backend_count, "backend_execution_count")
        if backend_count < self.nfev:
            raise ValueError("backend_execution_count must not be less than nfev.")
        object.__setattr__(self, "backend_execution_count", backend_count)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> OptimizerTerminationIR:
        """Build termination evidence from JSON-compatible data."""
        return cls(
            method=data["method"],
            success=data["success"],
            status=data["status"],
            message=data["message"],
            nfev=data["nfev"],
            nit=data.get("nit"),
            reason=data["reason"],
            njev=data.get("njev", 0),
            backend_execution_count=data.get("backend_execution_count"),
            schema_version=str(data.get("schema_version", ALGORITHM_SCHEMA_VERSION)),
        )


@dataclass(frozen=True)
class OptimizationStartIR(IRMixin):
    """One optimizer start and the exact slice of evaluations it owns."""

    start_index: int
    seed: int
    initialization: Literal["random", "explicit", "layerwise", "schema_default"]
    evaluation_start_index: int
    evaluation_count: int
    best_evaluation_index: int
    initial_parameters: Mapping[str, float]
    final_parameters: Mapping[str, float]
    final_objective: float
    best_objective: float
    termination: OptimizerTerminationIR
    gradient_start_index: int = 0
    gradient_count: int = 0
    backend_execution_count: int | None = None
    adam_iterations: tuple[AdamIterationIR, ...] = ()
    adam_stopping_evidence: AdamStoppingEvidenceIR | None = None
    spsa_iterations: tuple[SPSAIterationIR, ...] = ()
    spsa_initial_estimate: SPSAObjectiveEstimateIR | None = None
    spsa_final_estimate: SPSAObjectiveEstimateIR | None = None
    spsa_learning_rate_calibration: SPSALearningRateCalibrationIR | None = None
    spsa_stopping_evidence: SPSAStoppingEvidenceIR | None = None
    schema_version: str = ALGORITHM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_non_negative_int(self.start_index, "start_index")
        _require_non_negative_int(self.seed, "seed")
        if self.initialization not in {
            "random",
            "explicit",
            "layerwise",
            "schema_default",
        }:
            raise ValueError(
                f"Unsupported start initialization: {self.initialization!r}."
            )
        _require_non_negative_int(
            self.evaluation_start_index,
            "evaluation_start_index",
        )
        _require_positive_int(self.evaluation_count, "evaluation_count")
        if (
            not isinstance(self.best_evaluation_index, int)
            or isinstance(self.best_evaluation_index, bool)
            or not self.evaluation_start_index
            <= self.best_evaluation_index
            < self.evaluation_start_index + self.evaluation_count
        ):
            raise ValueError(
                "best_evaluation_index must belong to this optimization start."
            )
        initial = _finite_parameter_mapping(
            self.initial_parameters,
            "initial_parameters",
        )
        final = _finite_parameter_mapping(
            self.final_parameters,
            "final_parameters",
        )
        if not initial or initial.keys() != final.keys():
            raise ValueError(
                "initial_parameters and final_parameters must share non-empty keys."
            )
        object.__setattr__(self, "initial_parameters", initial)
        object.__setattr__(self, "final_parameters", final)
        object.__setattr__(
            self,
            "final_objective",
            _finite_float(self.final_objective, "final_objective"),
        )
        object.__setattr__(
            self,
            "best_objective",
            _finite_float(self.best_objective, "best_objective"),
        )
        if not isinstance(self.termination, OptimizerTerminationIR):
            raise TypeError("termination must be OptimizerTerminationIR.")
        if self.termination.nfev != self.evaluation_count:
            raise ValueError("termination nfev must match evaluation_count.")
        _require_non_negative_int(self.gradient_start_index, "gradient_start_index")
        _require_non_negative_int(self.gradient_count, "gradient_count")
        if self.termination.njev != self.gradient_count:
            raise ValueError("termination njev must match gradient_count.")
        backend_count = (
            self.termination.backend_execution_count
            if self.backend_execution_count is None
            else self.backend_execution_count
        )
        assert backend_count is not None
        _require_positive_int(backend_count, "backend_execution_count")
        if backend_count != self.termination.backend_execution_count:
            raise ValueError(
                "start backend_execution_count must match termination evidence."
            )
        object.__setattr__(self, "backend_execution_count", backend_count)
        from cascaqit.algorithms.adam import (
            AdamIterationIR,
            AdamStoppingEvidenceIR,
        )

        if not isinstance(self.adam_iterations, tuple):
            object.__setattr__(
                self,
                "adam_iterations",
                tuple(self.adam_iterations),
            )
        if any(not isinstance(item, AdamIterationIR) for item in self.adam_iterations):
            raise TypeError("adam_iterations must contain AdamIterationIR values.")
        if self.termination.method == "ADAM":
            if not self.adam_iterations:
                raise ValueError("ADAM optimizer starts require iteration evidence.")
            if self.gradient_count != len(self.adam_iterations):
                raise ValueError(
                    "ADAM optimizer starts require one gradient per iteration."
                )
            if self.adam_stopping_evidence is not None and not isinstance(
                self.adam_stopping_evidence,
                AdamStoppingEvidenceIR,
            ):
                raise TypeError(
                    "adam_stopping_evidence must be AdamStoppingEvidenceIR or None."
                )
        elif self.adam_iterations or self.adam_stopping_evidence is not None:
            raise ValueError("only ADAM optimizer starts can contain Adam evidence.")
        if not isinstance(self.spsa_iterations, tuple):
            object.__setattr__(
                self,
                "spsa_iterations",
                tuple(self.spsa_iterations),
            )
        if any(not isinstance(item, SPSAIterationIR) for item in self.spsa_iterations):
            raise TypeError("spsa_iterations must contain SPSAIterationIR values.")
        if self.termination.method == "SPSA":
            if not self.spsa_iterations:
                raise ValueError("SPSA optimizer starts require iteration evidence.")
            if self.gradient_count != 0:
                raise ValueError("SPSA optimizer starts cannot contain gradients.")
            if (
                not isinstance(self.spsa_initial_estimate, SPSAObjectiveEstimateIR)
                or self.spsa_initial_estimate.role != "initial"
            ):
                raise TypeError("SPSA starts require an initial objective estimate.")
            if (
                not isinstance(self.spsa_final_estimate, SPSAObjectiveEstimateIR)
                or self.spsa_final_estimate.role != "final"
            ):
                raise TypeError("SPSA starts require a final objective estimate.")
            if self.spsa_learning_rate_calibration is not None and not isinstance(
                self.spsa_learning_rate_calibration,
                SPSALearningRateCalibrationIR,
            ):
                raise TypeError(
                    "spsa_learning_rate_calibration must be "
                    "SPSALearningRateCalibrationIR or None."
                )
            if self.spsa_stopping_evidence is not None and not isinstance(
                self.spsa_stopping_evidence,
                SPSAStoppingEvidenceIR,
            ):
                raise TypeError(
                    "spsa_stopping_evidence must be SPSAStoppingEvidenceIR or None."
                )
        elif (
            self.spsa_iterations
            or self.spsa_initial_estimate is not None
            or self.spsa_final_estimate is not None
            or self.spsa_learning_rate_calibration is not None
            or self.spsa_stopping_evidence is not None
        ):
            raise ValueError("only SPSA optimizer starts can contain SPSA evidence.")

    def to_dict(self) -> dict[str, Any]:
        """Omit disabled optimizer evidence from compact payloads."""
        data = super().to_dict()
        if not self.adam_iterations:
            data.pop("adam_iterations", None)
        if self.adam_stopping_evidence is None:
            data.pop("adam_stopping_evidence", None)
        if self.spsa_learning_rate_calibration is None:
            data.pop("spsa_learning_rate_calibration", None)
        if self.spsa_stopping_evidence is None:
            data.pop("spsa_stopping_evidence", None)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> OptimizationStartIR:
        """Restore one optimizer-start summary from JSON-compatible data."""
        return cls(
            start_index=data["start_index"],
            seed=data["seed"],
            initialization=data["initialization"],
            evaluation_start_index=data["evaluation_start_index"],
            evaluation_count=data["evaluation_count"],
            best_evaluation_index=data["best_evaluation_index"],
            initial_parameters=_mapping(
                data["initial_parameters"], "initial_parameters"
            ),
            final_parameters=_mapping(data["final_parameters"], "final_parameters"),
            final_objective=data["final_objective"],
            best_objective=data["best_objective"],
            termination=OptimizerTerminationIR.from_dict(
                _mapping(data["termination"], "termination")
            ),
            gradient_start_index=data.get("gradient_start_index", 0),
            gradient_count=data.get("gradient_count", 0),
            backend_execution_count=data.get("backend_execution_count"),
            adam_iterations=tuple(
                _adam_iteration_from_dict(_mapping(item, "adam_iteration"))
                for item in data.get("adam_iterations", ())
            ),
            adam_stopping_evidence=(
                None
                if data.get("adam_stopping_evidence") is None
                else _adam_stopping_evidence_from_dict(
                    _mapping(
                        data["adam_stopping_evidence"],
                        "adam_stopping_evidence",
                    )
                )
            ),
            spsa_iterations=tuple(
                SPSAIterationIR.from_dict(_mapping(item, "spsa_iteration"))
                for item in data.get("spsa_iterations", ())
            ),
            spsa_initial_estimate=(
                None
                if data.get("spsa_initial_estimate") is None
                else SPSAObjectiveEstimateIR.from_dict(
                    _mapping(data["spsa_initial_estimate"], "spsa_initial_estimate")
                )
            ),
            spsa_final_estimate=(
                None
                if data.get("spsa_final_estimate") is None
                else SPSAObjectiveEstimateIR.from_dict(
                    _mapping(data["spsa_final_estimate"], "spsa_final_estimate")
                )
            ),
            spsa_learning_rate_calibration=(
                None
                if data.get("spsa_learning_rate_calibration") is None
                else SPSALearningRateCalibrationIR.from_dict(
                    _mapping(
                        data["spsa_learning_rate_calibration"],
                        "spsa_learning_rate_calibration",
                    )
                )
            ),
            spsa_stopping_evidence=(
                None
                if data.get("spsa_stopping_evidence") is None
                else SPSAStoppingEvidenceIR.from_dict(
                    _mapping(
                        data["spsa_stopping_evidence"],
                        "spsa_stopping_evidence",
                    )
                )
            ),
            schema_version=str(data.get("schema_version", ALGORITHM_SCHEMA_VERSION)),
        )


def validate_adam_start_evidence(
    start: OptimizationStartIR,
    optimizer: OptimizerConfig,
) -> None:
    """Replay one Adam start's state chain, stopping, and atomic budgets."""
    from cascaqit.algorithms.adam import (
        AdamStoppingEvidenceIR,
        validate_adam_iteration_sequence,
        validate_adam_stopping_evidence,
    )

    if not isinstance(start, OptimizationStartIR):
        raise TypeError("start must be OptimizationStartIR.")
    if not isinstance(optimizer, OptimizerConfig):
        raise TypeError("optimizer must be OptimizerConfig.")
    if start.termination.method != optimizer.method:
        raise ValueError("optimizer start method must match optimizer configuration.")
    if optimizer.method != "ADAM":
        if start.adam_iterations or start.adam_stopping_evidence is not None:
            raise ValueError("non-ADAM starts cannot contain Adam evidence.")
        return
    assert optimizer.adam is not None
    assert optimizer.gradient is not None
    iterations = validate_adam_iteration_sequence(start.adam_iterations)
    if start.evaluation_count != len(iterations) + 1:
        raise ValueError(
            "ADAM starts require one initial and one objective per update."
        )
    if start.gradient_count != len(iterations):
        raise ValueError("ADAM gradient_count must match iteration evidence.")
    if start.termination.nit != len(iterations):
        raise ValueError("ADAM termination nit must match iteration evidence.")
    expected_bounds = {
        name: bound
        for name, bound in zip(start.initial_parameters, optimizer.bounds)
    }
    if any(
        item.config != optimizer.adam or dict(item.bounds) != expected_bounds
        for item in iterations
    ):
        raise ValueError("ADAM iteration config or bounds do not match optimizer.")
    if any(
        item.center_objective_evaluation_index
        != start.evaluation_start_index + item.iteration_index
        or item.updated_objective_evaluation_index
        != start.evaluation_start_index + item.iteration_index + 1
        or item.gradient_index
        != start.gradient_start_index + item.iteration_index
        for item in iterations
    ):
        raise ValueError("ADAM iteration indices do not match optimizer start slices.")
    _require_parameter_mapping_values_close(
        iterations[0].center_parameters,
        start.initial_parameters,
        "ADAM initial parameters",
    )
    _require_parameter_mapping_values_close(
        iterations[-1].updated_parameters,
        start.final_parameters,
        "ADAM final parameters",
    )

    stopping = optimizer.adam.stopping
    if stopping is None:
        if start.adam_stopping_evidence is not None:
            raise ValueError(
                "ADAM stopping evidence requires a stopping configuration."
            )
        first_stability_index = None
    else:
        if not isinstance(start.adam_stopping_evidence, AdamStoppingEvidenceIR):
            raise TypeError("configured ADAM stopping requires stopping evidence.")
        validate_adam_stopping_evidence(
            start.adam_stopping_evidence,
            iterations,
        )
        first_stability_index = next(
            (
                index
                for index in range(len(iterations))
                if AdamStoppingEvidenceIR.create(
                    iterations[: index + 1],
                    stopping,
                ).status
                == "stability_reached"
            ),
            None,
        )
    if first_stability_index is not None and (
        len(iterations) != first_stability_index + 1
        or start.termination.reason != "stability_reached"
    ):
        raise ValueError("ADAM must stop at the first satisfied stability window.")
    if (
        start.termination.reason == "stability_reached"
        and first_stability_index is None
    ):
        raise ValueError("ADAM stability termination requires matching evidence.")

    # Adaptive gradients may consume a different number of complete repeats in
    # each Adam iteration.  The executable QWC plan still fixes the cost of one
    # repeat, which is the invariant needed to reconstruct the next hard-budget
    # check without rejecting valid variable-repeat histories.
    per_repeat_gradient_costs: set[int] = set()
    for item in iterations:
        per_repeat_cost, remainder = divmod(
            item.gradient_backend_execution_count,
            item.gradient_repeat_count,
        )
        if per_repeat_cost <= 0 or remainder:
            raise ValueError(
                "ADAM gradient Backend cost must contain complete repeats."
            )
        per_repeat_gradient_costs.add(per_repeat_cost)
    if len(per_repeat_gradient_costs) != 1:
        raise ValueError("ADAM gradients must use one fixed per-repeat Backend cost.")
    minimum_gradient_cost = (
        next(iter(per_repeat_gradient_costs)) * optimizer.gradient.repeats
    )
    objective_backend_cost, remainder = divmod(
        (start.backend_execution_count or 0)
        - sum(item.gradient_backend_execution_count for item in iterations),
        start.evaluation_count,
    )
    if objective_backend_cost <= 0 or remainder:
        raise ValueError("ADAM objectives must use one fixed positive Backend cost.")
    if first_stability_index is not None:
        expected_reason = "stability_reached"
    elif len(iterations) >= optimizer.max_iterations:
        expected_reason = "max_iterations"
    elif (
        optimizer.max_evaluations is not None
        and start.evaluation_count + 1 > optimizer.max_evaluations
    ):
        expected_reason = "max_evaluations"
    elif (
        optimizer.gradient.max_evaluations is not None
        and len(iterations) + 1 > optimizer.gradient.max_evaluations
    ):
        expected_reason = "max_gradient_evaluations"
    elif (
        optimizer.max_backend_executions is not None
        and (start.backend_execution_count or 0)
        + minimum_gradient_cost
        + objective_backend_cost
        > optimizer.max_backend_executions
    ):
        expected_reason = "max_backend_executions"
    else:
        raise ValueError("ADAM start stopped before any configured limit.")
    if start.termination.reason != expected_reason:
        raise ValueError("ADAM termination reason does not match the first hard limit.")


def validate_spsa_start_evidence(
    start: OptimizationStartIR,
    optimizer: OptimizerConfig,
) -> None:
    """Recompute one start's SPSA schedule, chain, and atomic evaluation layout."""
    if not isinstance(start, OptimizationStartIR):
        raise TypeError("start must be OptimizationStartIR.")
    if not isinstance(optimizer, OptimizerConfig):
        raise TypeError("optimizer must be OptimizerConfig.")
    if start.termination.method != optimizer.method:
        raise ValueError("optimizer start method must match optimizer configuration.")
    if optimizer.method != "SPSA":
        if start.spsa_iterations:
            raise ValueError("non-SPSA starts cannot contain SPSA evidence.")
        return
    config = optimizer.spsa
    assert config is not None
    iterations = start.spsa_iterations
    repeats = config.objective_repeats
    direction_count = config.directions_per_iteration
    calibration_config = config.learning_rate_calibration
    calibration = start.spsa_learning_rate_calibration
    if calibration_config is None:
        if calibration is not None:
            raise ValueError(
                "SPSA calibration evidence requires a calibration configuration."
            )
        calibration_direction_count = 0
    else:
        if calibration is None:
            raise ValueError(
                "calibrated SPSA starts require learning-rate calibration evidence."
            )
        calibration_direction_count = calibration_config.directions
        if len(calibration.directions) != calibration_direction_count:
            raise ValueError(
                "SPSA calibration directions must match the configuration."
            )
    initial_estimate = start.spsa_initial_estimate
    final_estimate = start.spsa_final_estimate
    assert initial_estimate is not None
    assert final_estimate is not None
    if tuple(item.iteration_index for item in iterations) != tuple(
        range(len(iterations))
    ):
        raise ValueError("SPSA iteration indices must be contiguous and zero-based.")
    if config.objective_repeat_mode == "fixed":
        if start.evaluation_count != repeats * (
            2 * calibration_direction_count
            + 2 * direction_count * len(iterations)
            + 2
        ):
            raise ValueError(
                "SPSA evaluation_count must contain initial/final centers and pairs."
            )
        if (
            initial_estimate.repeat_count != repeats
            or final_estimate.repeat_count != repeats
        ):
            raise ValueError("SPSA center estimates must match objective_repeats.")
        if initial_estimate.evaluation_offsets != tuple(range(repeats)):
            raise ValueError("SPSA initial evaluation offsets must be contiguous.")
        expected_final_start = repeats * (
            1
            + 2 * calibration_direction_count
            + 2 * direction_count * len(iterations)
        )
        if final_estimate.evaluation_offsets != tuple(
            range(expected_final_start, expected_final_start + repeats)
        ):
            raise ValueError("SPSA final evaluation offsets must be contiguous.")
        if any(
            estimate.stop_reason != "fixed_repeats"
            for estimate in _spsa_objective_estimates(start)
        ):
            raise ValueError("fixed SPSA estimates must use fixed_repeats.")
    else:
        _validate_adaptive_spsa_layout(start, optimizer)
    if start.termination.nit != len(iterations):
        raise ValueError("SPSA termination nit must match iteration evidence.")
    parameter_names = (
        tuple(start.initial_parameters)
        if calibration is None
        else calibration.parameter_names
    )
    if set(parameter_names) != set(start.initial_parameters):
        raise ValueError("SPSA calibration parameter_names must match the start.")
    if optimizer.bounds and len(optimizer.bounds) != len(parameter_names):
        raise ValueError("SPSA bounds must match optimizer-start parameters.")
    # 校准 IR 显式保留 Ansatz 参数顺序，因此 JSON 恢复后仍可从 start seed
    # 重放校准和正式 iteration 的整条 Rademacher 方向流。
    if calibration is not None:
        rng = np.random.default_rng(start.seed)
        direction_groups = (
            calibration.directions,
            *(iteration.directions for iteration in iterations),
        )
        for directions in direction_groups:
            for direction in directions:
                expected_vector = tuple(
                    int(value)
                    for value in rng.choice(
                        np.asarray((-1, 1), dtype=np.int8),
                        size=len(parameter_names),
                    )
                )
                observed_vector = tuple(
                    direction.perturbation_vector[name] for name in parameter_names
                )
                if observed_vector != expected_vector:
                    raise ValueError(
                        "SPSA perturbation vectors must match the start seed."
                    )
    learning_rate_scale = config.learning_rate
    if calibration_config is not None:
        assert calibration is not None
        _require_parameter_mapping_values_close(
            calibration.center_parameters,
            start.initial_parameters,
            "SPSA calibration center_parameters",
        )
        if not math.isclose(
            calibration.perturbation,
            config.perturbation,
            rel_tol=0.0,
            abs_tol=1e-12,
        ):
            raise ValueError(
                "SPSA calibration perturbation must match the initial schedule."
            )
        if calibration.gradient_rms < calibration_config.gradient_rms_floor:
            raise ValueError(
                "SPSA calibration gradient RMS is below gradient_rms_floor."
            )
        expected_learning_rate = (
            calibration_config.target_update_rms
            * (1.0 + config.stability_constant) ** config.learning_rate_exponent
            / calibration.gradient_rms
        )
        if not math.isclose(
            calibration.derived_learning_rate,
            expected_learning_rate,
            rel_tol=0.0,
            abs_tol=1e-12,
        ):
            raise ValueError(
                "derived SPSA learning rate must match calibration evidence."
            )
        if (
            calibration_config.max_learning_rate is not None
            and calibration.derived_learning_rate
            > calibration_config.max_learning_rate
        ):
            raise ValueError(
                "derived SPSA learning rate exceeds max_learning_rate."
            )
        projection_expected = False
        for direction in calibration.directions:
            raw_plus = {
                name: start.initial_parameters[name]
                + config.perturbation * direction.perturbation_vector[name]
                for name in parameter_names
            }
            raw_minus = {
                name: start.initial_parameters[name]
                - config.perturbation * direction.perturbation_vector[name]
                for name in parameter_names
            }
            if optimizer.bounds:
                expected_plus = {
                    name: min(max(raw_plus[name], lower), upper)
                    for name, (lower, upper) in zip(
                        parameter_names,
                        optimizer.bounds,
                    )
                }
                expected_minus = {
                    name: min(max(raw_minus[name], lower), upper)
                    for name, (lower, upper) in zip(
                        parameter_names,
                        optimizer.bounds,
                    )
                }
            else:
                expected_plus = raw_plus
                expected_minus = raw_minus
            _require_parameter_mapping_values_close(
                direction.plus_parameters,
                expected_plus,
                "SPSA calibration plus_parameters",
            )
            _require_parameter_mapping_values_close(
                direction.minus_parameters,
                expected_minus,
                "SPSA calibration minus_parameters",
            )
            projection_expected = projection_expected or any(
                raw_values[name] != projected_values[name]
                for raw_values, projected_values in (
                    (raw_plus, expected_plus),
                    (raw_minus, expected_minus),
                )
                for name in parameter_names
            )
            if config.objective_repeat_mode == "fixed":
                expected_plus_start = repeats * (
                    1 + 2 * direction.direction_index
                )
                expected_minus_start = expected_plus_start + repeats
                if direction.plus_estimate.evaluation_offsets != tuple(
                    range(expected_plus_start, expected_plus_start + repeats)
                ):
                    raise ValueError(
                        "SPSA calibration plus offsets must be contiguous."
                    )
                if direction.minus_estimate.evaluation_offsets != tuple(
                    range(expected_minus_start, expected_minus_start + repeats)
                ):
                    raise ValueError(
                        "SPSA calibration minus offsets must be contiguous."
                    )
        if calibration.projection_applied != projection_expected:
            raise ValueError(
                "SPSA calibration projection flag does not match its parameters."
            )
        learning_rate_scale = calibration.derived_learning_rate
    assert learning_rate_scale is not None
    previous = start.initial_parameters
    for index, iteration in enumerate(iterations):
        if len(iteration.directions) != direction_count:
            raise ValueError(
                "SPSA iteration directions must match directions_per_iteration."
            )
        expected_learning_rate = (
            learning_rate_scale
            / (index + 1 + config.stability_constant) ** config.learning_rate_exponent
        )
        expected_perturbation = (
            config.perturbation / (index + 1) ** config.perturbation_exponent
        )
        if not math.isclose(
            iteration.learning_rate,
            expected_learning_rate,
            rel_tol=0.0,
            abs_tol=1e-12,
        ):
            raise ValueError("SPSA learning rate does not match its gain schedule.")
        if not math.isclose(
            iteration.perturbation,
            expected_perturbation,
            rel_tol=0.0,
            abs_tol=1e-12,
        ):
            raise ValueError("SPSA perturbation does not match its gain schedule.")
        if config.objective_repeat_mode == "fixed":
            iteration_start = repeats * (
                1
                + 2 * calibration_direction_count
                + 2 * direction_count * index
            )
            for direction in iteration.directions:
                expected_plus_start = (
                    iteration_start + 2 * repeats * direction.direction_index
                )
                expected_minus_start = expected_plus_start + repeats
                if direction.plus_estimate.evaluation_offsets != tuple(
                    range(expected_plus_start, expected_plus_start + repeats)
                ):
                    raise ValueError(
                        "SPSA plus evaluation offsets must be contiguous."
                    )
                if direction.minus_estimate.evaluation_offsets != tuple(
                    range(expected_minus_start, expected_minus_start + repeats)
                ):
                    raise ValueError(
                        "SPSA minus evaluation offsets must be contiguous."
                    )
                if (
                    direction.plus_estimate.repeat_count != repeats
                    or direction.minus_estimate.repeat_count != repeats
                ):
                    raise ValueError(
                        "SPSA perturbation estimates must match objective_repeats."
                    )
        _require_parameter_mapping_close(
            iteration.center_parameters,
            previous,
            "SPSA center_parameters",
        )
        if optimizer.bounds:
            expected_updated = {
                name: min(
                    max(iteration.unprojected_parameters[name], lower),
                    upper,
                )
                for name, (lower, upper) in zip(parameter_names, optimizer.bounds)
            }
            _require_parameter_mapping_values_close(
                iteration.updated_parameters,
                expected_updated,
                "SPSA projected updated_parameters",
            )
            projection_pairs: list[
                tuple[Mapping[str, float], Mapping[str, float]]
            ] = []
            for direction in iteration.directions:
                perturbations = direction.perturbation_vector
                raw_plus = {
                    name: iteration.center_parameters[name]
                    + iteration.perturbation * perturbations[name]
                    for name in parameter_names
                }
                raw_minus = {
                    name: iteration.center_parameters[name]
                    - iteration.perturbation * perturbations[name]
                    for name in parameter_names
                }
                expected_plus = {
                    name: min(max(raw_plus[name], lower), upper)
                    for name, (lower, upper) in zip(
                        parameter_names,
                        optimizer.bounds,
                    )
                }
                expected_minus = {
                    name: min(max(raw_minus[name], lower), upper)
                    for name, (lower, upper) in zip(
                        parameter_names,
                        optimizer.bounds,
                    )
                }
                _require_parameter_mapping_values_close(
                    direction.plus_parameters,
                    expected_plus,
                    "SPSA projected plus_parameters",
                )
                _require_parameter_mapping_values_close(
                    direction.minus_parameters,
                    expected_minus,
                    "SPSA projected minus_parameters",
                )
                projection_pairs.extend(
                    ((raw_plus, expected_plus), (raw_minus, expected_minus))
                )
            projection_pairs.append(
                (iteration.unprojected_parameters, expected_updated)
            )
            projection_expected = any(
                raw_values[name] != projected_values[name]
                for raw_values, projected_values in projection_pairs
                for name in parameter_names
            )
            if iteration.projection_applied != projection_expected:
                raise ValueError("SPSA projection flag does not match its parameters.")
        elif iteration.projection_applied:
            raise ValueError("unbounded SPSA iterations cannot report projection.")
        previous = iteration.updated_parameters
    _require_parameter_mapping_close(
        start.final_parameters,
        previous,
        "SPSA final_parameters",
    )
    stopping = config.stopping
    # Import locally to keep the typed IR module independent from the optimizer
    # runtime while using exactly the same pure derivation for execution/replay.
    from cascaqit.algorithms.optimizer import derive_spsa_stopping_evidence

    if stopping is None:
        if start.spsa_stopping_evidence is not None:
            raise ValueError(
                "SPSA stopping evidence requires a stopping configuration."
            )
        if start.termination.reason == "stability_reached":
            raise ValueError(
                "stability_reached requires an SPSA stopping configuration."
            )
    else:
        expected_evidence = derive_spsa_stopping_evidence(iterations, stopping)
        if canonicalize(start.spsa_stopping_evidence) != canonicalize(
            expected_evidence
        ):
            raise ValueError(
                "SPSA stopping evidence must match the saved iteration prefix."
            )

    expected_stop_index: int | None = None
    expected_stop_reason: Literal["completed", "stability_reached"] | None = None
    for index, iteration in enumerate(iterations):
        if iteration.update_norm <= optimizer.tolerance:
            expected_stop_index = index
            expected_stop_reason = "completed"
            break
        if stopping is not None:
            prefix_evidence = derive_spsa_stopping_evidence(
                iterations[: index + 1],
                stopping,
            )
            if prefix_evidence.status == "stability_reached":
                expected_stop_index = index
                expected_stop_reason = "stability_reached"
                break
    if expected_stop_index is None:
        if start.termination.reason in {"completed", "stability_reached"}:
            raise ValueError(
                "successful SPSA termination requires a matching stopping event."
            )
    elif (
        len(iterations) != expected_stop_index + 1
        or start.termination.reason != expected_stop_reason
    ):
        raise ValueError(
            "SPSA termination must match the first eligible stopping event."
        )


def _validate_adaptive_spsa_layout(
    start: OptimizationStartIR,
    optimizer: OptimizerConfig,
) -> None:
    """Replay adaptive repeat layout, stopping facts, and reserved budgets."""
    config = optimizer.spsa
    assert config is not None
    assert config.objective_repeat_mode == "adaptive"
    target = config.objective_standard_error_target
    assert target is not None
    minimum = config.objective_repeats
    maximum = config.effective_max_objective_repeats
    initial = start.spsa_initial_estimate
    final = start.spsa_final_estimate
    assert initial is not None
    assert final is not None

    per_evaluation_backend_cost, remainder = divmod(
        start.backend_execution_count or 0,
        start.evaluation_count,
    )
    if per_evaluation_backend_cost <= 0 or remainder:
        raise ValueError(
            "adaptive SPSA Backend cost must be constant per objective evaluation."
        )
    limits: list[int] = []
    if optimizer.max_evaluations is not None:
        limits.append(optimizer.max_evaluations)
    if optimizer.max_backend_executions is not None:
        limits.append(
            optimizer.max_backend_executions // per_evaluation_backend_cost
        )
    evaluation_limit = min(limits) if limits else None

    def reached(estimate: SPSAObjectiveEstimateIR) -> bool:
        return (
            estimate.pooled_standard_error is not None
            and estimate.pooled_standard_error <= target
        )

    def prefix_reached(
        estimate: SPSAObjectiveEstimateIR,
        repeat_count: int,
    ) -> bool:
        """Replay the standard-error decision at an earlier repeat boundary."""
        values = estimate.objective_values[:repeat_count]
        mean = math.fsum(values) / repeat_count
        standard_error = math.sqrt(
            math.fsum((value - mean) ** 2 for value in values)
            / (repeat_count - 1)
        ) / math.sqrt(repeat_count)
        return standard_error <= target

    def validate_center(
        estimate: SPSAObjectiveEstimateIR,
        *,
        used_after: int,
        reserve: int,
    ) -> None:
        if not minimum <= estimate.repeat_count <= maximum:
            raise ValueError("adaptive SPSA repeat count is outside configured bounds.")
        if any(
            prefix_reached(estimate, repeat_count)
            for repeat_count in range(minimum, estimate.repeat_count)
        ):
            raise ValueError(
                "adaptive SPSA center continued after reaching the standard-error "
                "target."
            )
        did_reach = reached(estimate)
        if estimate.stop_reason == "target_reached":
            if not did_reach:
                raise ValueError(
                    "target_reached requires the configured standard error."
                )
        elif estimate.stop_reason == "max_repeats_reached":
            if estimate.repeat_count != maximum or did_reach:
                raise ValueError(
                    "max_repeats_reached must stop at the configured maximum."
                )
        elif estimate.stop_reason == "budget_exhausted":
            if (
                did_reach
                or estimate.repeat_count >= maximum
                or evaluation_limit is None
                or used_after + 1 + reserve <= evaluation_limit
            ):
                raise ValueError(
                    "budget_exhausted must match the adaptive evaluation budget."
                )
        else:
            raise ValueError("adaptive SPSA estimates cannot use fixed_repeats.")

    def validate_pair(
        direction: SPSADirectionIR,
        *,
        cursor: int,
        reserve: int,
    ) -> tuple[int, tuple[int, ...]]:
        plus = direction.plus_estimate
        minus = direction.minus_estimate
        if plus.repeat_count != minus.repeat_count:
            raise ValueError("adaptive SPSA plus/minus repeats must be equal.")
        if not minimum <= plus.repeat_count <= maximum:
            raise ValueError(
                "adaptive SPSA repeat count is outside configured bounds."
            )
        extra = plus.repeat_count - minimum
        expected_plus = tuple(range(cursor, cursor + minimum)) + tuple(
            cursor + 2 * minimum + 2 * index for index in range(extra)
        )
        expected_minus = tuple(
            range(cursor + minimum, cursor + 2 * minimum)
        ) + tuple(
            cursor + 2 * minimum + 2 * index + 1 for index in range(extra)
        )
        if plus.evaluation_offsets != expected_plus:
            raise ValueError(
                "adaptive SPSA plus offsets do not match execution order."
            )
        if minus.evaluation_offsets != expected_minus:
            raise ValueError(
                "adaptive SPSA minus offsets do not match execution order."
            )
        cursor += 2 * plus.repeat_count
        if any(
            prefix_reached(plus, repeat_count)
            and prefix_reached(minus, repeat_count)
            for repeat_count in range(minimum, plus.repeat_count)
        ):
            raise ValueError(
                "adaptive SPSA pair continued after reaching the standard-error "
                "target."
            )
        both_reached = reached(plus) and reached(minus)
        if plus.stop_reason == "target_reached":
            if not both_reached:
                raise ValueError(
                    "adaptive SPSA pair target requires both standard errors."
                )
        elif plus.stop_reason == "max_repeats_reached":
            if plus.repeat_count != maximum or both_reached:
                raise ValueError(
                    "adaptive SPSA pair maximum must match configured repeats."
                )
        elif plus.stop_reason == "budget_exhausted":
            if (
                both_reached
                or plus.repeat_count >= maximum
                or evaluation_limit is None
                or cursor + 2 + reserve <= evaluation_limit
            ):
                raise ValueError(
                    "adaptive SPSA pair budget stop does not match the hard limit."
                )
        else:
            raise ValueError("adaptive SPSA pairs cannot use fixed_repeats.")
        return cursor, (*plus.evaluation_offsets, *minus.evaluation_offsets)

    if initial.evaluation_offsets != tuple(range(initial.repeat_count)):
        raise ValueError("adaptive SPSA initial offsets must start at zero.")
    cursor = initial.repeat_count
    direction_count = config.directions_per_iteration
    stopping = config.stopping
    calibration = start.spsa_learning_rate_calibration
    calibration_direction_count = 0 if calibration is None else len(
        calibration.directions
    )
    required_iterations = 1 if stopping is None else stopping.min_iterations
    validate_center(
        initial,
        used_after=cursor,
        reserve=(
            2 * calibration_direction_count
            + 2 * direction_count * required_iterations
            + 1
        )
        * minimum,
    )

    all_offsets: list[int] = list(initial.evaluation_offsets)
    if calibration is not None:
        for direction in calibration.directions:
            remaining_calibration = (
                calibration_direction_count - direction.direction_index - 1
            )
            reserve = (
                2 * remaining_calibration
                + 2 * direction_count * required_iterations
                + 1
            ) * minimum
            cursor, offsets = validate_pair(
                direction,
                cursor=cursor,
                reserve=reserve,
            )
            all_offsets.extend(offsets)

    for iteration in start.spsa_iterations:
        if len(iteration.directions) != direction_count:
            raise ValueError(
                "SPSA iteration directions must match directions_per_iteration."
            )
        for direction in iteration.directions:
            remaining_directions = direction_count - direction.direction_index - 1
            remaining_required_iterations = (
                0
                if stopping is None
                else max(
                    0,
                    stopping.min_iterations - iteration.iteration_index - 1,
                )
            )
            reserve = (
                2 * remaining_directions
                + 2 * direction_count * remaining_required_iterations
                + 1
            ) * minimum
            cursor, offsets = validate_pair(
                direction,
                cursor=cursor,
                reserve=reserve,
            )
            all_offsets.extend(offsets)

    expected_final = tuple(range(cursor, cursor + final.repeat_count))
    if final.evaluation_offsets != expected_final:
        raise ValueError(
            "adaptive SPSA final offsets must close the execution sequence."
        )
    cursor += final.repeat_count
    validate_center(final, used_after=cursor, reserve=0)
    all_offsets.extend(final.evaluation_offsets)
    if cursor != start.evaluation_count or tuple(sorted(all_offsets)) != tuple(
        range(start.evaluation_count)
    ):
        raise ValueError("adaptive SPSA offsets must cover every evaluation once.")


def _spsa_objective_estimates(
    start: OptimizationStartIR,
) -> tuple[SPSAObjectiveEstimateIR, ...]:
    """Return one start's logical objectives in execution order."""
    if start.termination.method != "SPSA":
        return ()
    assert start.spsa_initial_estimate is not None
    assert start.spsa_final_estimate is not None
    return (
        start.spsa_initial_estimate,
        *(
            estimate
            for calibration in (start.spsa_learning_rate_calibration,)
            if calibration is not None
            for direction in calibration.directions
            for estimate in (direction.plus_estimate, direction.minus_estimate)
        ),
        *(
            estimate
            for iteration in start.spsa_iterations
            for direction in iteration.directions
            for estimate in (direction.plus_estimate, direction.minus_estimate)
        ),
        start.spsa_final_estimate,
    )


def rank_spsa_source_evaluation_indices(
    starts: Sequence[OptimizationStartIR],
) -> tuple[int, ...]:
    """Rank stable source evaluations by pooled SPSA objective."""
    ranked = sorted(
        (
            (
                estimate.pooled_objective,
                start.evaluation_start_index + estimate.source_evaluation_offset,
            )
            for start in starts
            for estimate in _spsa_objective_estimates(start)
        ),
        key=lambda item: (item[0], item[1]),
    )
    return tuple(index for _, index in ranked)


def _validate_spsa_estimate_evaluations(
    estimate: SPSAObjectiveEstimateIR,
    evaluations: Sequence[Any],
    expected_parameters: Mapping[str, float],
) -> None:
    """Match one pooled estimate to its complete saved evaluation slice."""
    actual_values: list[float] = []
    for offset in estimate.evaluation_offsets:
        if offset >= len(evaluations):
            raise ValueError("SPSA estimate offset is outside the start evaluations.")
        evaluation = evaluations[offset]
        _require_parameter_mapping_values_close(
            evaluation.parameter_bind.values,
            expected_parameters,
            "SPSA estimate evaluation parameters",
        )
        actual_values.append(float(evaluation.energy))
    if len(actual_values) != len(estimate.objective_values) or any(
        not math.isclose(actual, expected, rel_tol=0.0, abs_tol=_ENERGY_TOLERANCE)
        for actual, expected in zip(actual_values, estimate.objective_values)
    ):
        raise ValueError("SPSA estimate objectives must match saved evaluations.")


@dataclass(frozen=True)
class AlgorithmCandidateIR(IRMixin):
    """One sampled problem candidate without an optimality claim."""

    bitstring: str
    objective_value: float
    probability: float | None
    count: int | None
    feasible: bool | None
    decoded: Mapping[str, Any] = field(default_factory=dict)
    optimality_claim: Literal["not_claimed"] = "not_claimed"
    schema_version: str = ALGORITHM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if not self.bitstring or set(self.bitstring) - {"0", "1"}:
            raise ValueError("bitstring must contain only 0 and 1.")
        object.__setattr__(
            self,
            "objective_value",
            _finite_float(self.objective_value, "objective_value"),
        )
        if self.probability is not None:
            probability = _finite_float(self.probability, "probability")
            if not 0.0 <= probability <= 1.0:
                raise ValueError("probability must be within [0, 1].")
            object.__setattr__(self, "probability", probability)
        if self.count is not None and (
            not isinstance(self.count, int)
            or isinstance(self.count, bool)
            or self.count < 0
        ):
            raise ValueError("count must be a non-negative integer or None.")
        if self.feasible is not None and not isinstance(self.feasible, bool):
            raise TypeError("feasible must be bool or None.")
        if self.optimality_claim != "not_claimed":
            raise ValueError("Algorithm candidates cannot claim optimality.")
        object.__setattr__(self, "decoded", _freeze_mapping(self.decoded))

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> AlgorithmCandidateIR:
        """Build a sampled candidate from JSON-compatible data."""
        return cls(
            bitstring=data["bitstring"],
            objective_value=data["objective_value"],
            probability=data.get("probability"),
            count=data.get("count"),
            feasible=data.get("feasible"),
            decoded=_mapping(data.get("decoded", {}), "decoded"),
            optimality_claim=data.get("optimality_claim", "not_claimed"),
            schema_version=str(data.get("schema_version", ALGORITHM_SCHEMA_VERSION)),
        )


@dataclass(frozen=True)
class ClassicalBaselineIR(IRMixin):
    """Bounded classical reference, or an explicit unavailable reason."""

    status: BaselineStatus
    method: Literal["bounded_exhaustive"]
    variable_count: int
    limit: int
    objective_value: float | None = None
    bitstring: str | None = None
    unavailable_reason: str | None = None
    schema_version: str = ALGORITHM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.status not in {"available", "unavailable"}:
            raise ValueError(f"Unsupported baseline status: {self.status!r}.")
        if self.method != "bounded_exhaustive":
            raise ValueError("method must be bounded_exhaustive.")
        _require_non_negative_int(self.variable_count, "variable_count")
        _require_positive_int(self.limit, "limit")
        if self.status == "available":
            if self.variable_count > self.limit:
                raise ValueError("available baseline cannot exceed its variable limit.")
            if self.objective_value is None or self.bitstring is None:
                raise ValueError("available baseline requires objective and bitstring.")
            object.__setattr__(
                self,
                "objective_value",
                _finite_float(self.objective_value, "objective_value"),
            )
            if len(self.bitstring) != self.variable_count or set(self.bitstring) - {
                "0",
                "1",
            }:
                raise ValueError("baseline bitstring must match variable_count.")
            if self.unavailable_reason is not None:
                raise ValueError("available baseline cannot have unavailable_reason.")
        else:
            if self.objective_value is not None or self.bitstring is not None:
                raise ValueError("unavailable baseline cannot contain a solution.")
            _require_text(self.unavailable_reason, "unavailable_reason")

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ClassicalBaselineIR:
        """Build baseline evidence from JSON-compatible data."""
        return cls(
            status=data["status"],
            method=data["method"],
            variable_count=data["variable_count"],
            limit=data["limit"],
            objective_value=data.get("objective_value"),
            bitstring=data.get("bitstring"),
            unavailable_reason=data.get("unavailable_reason"),
            schema_version=str(data.get("schema_version", ALGORITHM_SCHEMA_VERSION)),
        )


@dataclass(frozen=True)
class CardinalityConstraintEvidenceIR(IRMixin):
    """Observed final-distribution evidence for one fixed-weight qubit group."""

    constraint_index: int
    qubits: tuple[str, ...]
    target_weight: int
    weight_probabilities: Mapping[str, float]
    preservation_rate: float
    weight_counts: Mapping[str, int] = field(default_factory=dict)
    shots: int | None = None
    preserved_shots: int | None = None
    violating_shots: int | None = None
    schema_version: str = ALGORITHM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_non_negative_int(self.constraint_index, "constraint_index")
        object.__setattr__(self, "qubits", tuple(self.qubits))
        _require_unique_text(self.qubits, "qubits", allow_empty=False)
        if (
            not isinstance(self.target_weight, int)
            or isinstance(self.target_weight, bool)
            or not 0 <= self.target_weight <= len(self.qubits)
        ):
            raise ValueError("target_weight must be between zero and group size.")

        probabilities = _normalize_weight_probabilities(
            self.weight_probabilities,
            group_size=len(self.qubits),
        )
        expected_rate = probabilities.get(str(self.target_weight), 0.0)
        preservation_rate = _probability(
            self.preservation_rate,
            "preservation_rate",
        )
        if not math.isclose(
            preservation_rate,
            expected_rate,
            rel_tol=0.0,
            abs_tol=_ENERGY_TOLERANCE,
        ):
            raise ValueError(
                "preservation_rate must match the target-weight probability."
            )

        counts = _normalize_weight_counts(
            self.weight_counts,
            group_size=len(self.qubits),
        )
        if self.shots is None:
            if (
                counts
                or self.preserved_shots is not None
                or self.violating_shots is not None
            ):
                raise ValueError(
                    "count evidence requires shots, preserved_shots, and "
                    "violating_shots together."
                )
        else:
            _require_positive_int(self.shots, "shots")
            if self.preserved_shots is None or self.violating_shots is None:
                raise ValueError("shots requires preserved_shots and violating_shots.")
            _require_non_negative_int(self.preserved_shots, "preserved_shots")
            _require_non_negative_int(self.violating_shots, "violating_shots")
            if self.preserved_shots + self.violating_shots != self.shots:
                raise ValueError(
                    "preserved_shots and violating_shots must sum to shots."
                )
            if sum(counts.values()) != self.shots:
                raise ValueError("weight_counts must sum to shots.")
            expected_preserved = counts.get(str(self.target_weight), 0)
            if self.preserved_shots != expected_preserved:
                raise ValueError("preserved_shots must match the target-weight count.")
            for weight, count in counts.items():
                if not math.isclose(
                    probabilities.get(weight, 0.0),
                    count / self.shots,
                    rel_tol=0.0,
                    abs_tol=_ENERGY_TOLERANCE,
                ):
                    raise ValueError(
                        "weight_probabilities must match weight_counts / shots."
                    )

        object.__setattr__(self, "weight_probabilities", probabilities)
        object.__setattr__(self, "preservation_rate", preservation_rate)
        object.__setattr__(self, "weight_counts", counts)

    @classmethod
    def from_dict(
        cls,
        data: Mapping[str, Any],
    ) -> CardinalityConstraintEvidenceIR:
        """Restore one fixed-weight observation from JSON-compatible data."""
        return cls(
            constraint_index=data["constraint_index"],
            qubits=tuple(_sequence(data["qubits"], "qubits")),
            target_weight=data["target_weight"],
            weight_probabilities=_mapping(
                data["weight_probabilities"],
                "weight_probabilities",
            ),
            preservation_rate=data["preservation_rate"],
            weight_counts=_mapping(data.get("weight_counts", {}), "weight_counts"),
            shots=data.get("shots"),
            preserved_shots=data.get("preserved_shots"),
            violating_shots=data.get("violating_shots"),
            schema_version=str(data.get("schema_version", ALGORITHM_SCHEMA_VERSION)),
        )


@dataclass(frozen=True)
class CardinalitySubspaceEvidenceIR(IRMixin):
    """Observed preservation of all declared fixed-cardinality groups."""

    source_kind: Literal["counts", "probabilities"]
    constraints: tuple[CardinalityConstraintEvidenceIR, ...]
    preservation_rate: float
    violation_rate: float
    status: Literal["preserved", "violated"]
    shots: int | None = None
    preserved_shots: int | None = None
    violating_shots: int | None = None
    schema_version: str = ALGORITHM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.source_kind not in {"counts", "probabilities"}:
            raise ValueError(f"Unsupported source_kind: {self.source_kind!r}.")
        object.__setattr__(self, "constraints", tuple(self.constraints))
        if not self.constraints or any(
            not isinstance(item, CardinalityConstraintEvidenceIR)
            for item in self.constraints
        ):
            raise ValueError(
                "constraints must contain CardinalityConstraintEvidenceIR values."
            )
        if tuple(item.constraint_index for item in self.constraints) != tuple(
            range(len(self.constraints))
        ):
            raise ValueError("constraint indices must be contiguous and zero-based.")
        preservation_rate = _probability(
            self.preservation_rate,
            "preservation_rate",
        )
        violation_rate = _probability(self.violation_rate, "violation_rate")
        if not math.isclose(
            preservation_rate + violation_rate,
            1.0,
            rel_tol=0.0,
            abs_tol=_ENERGY_TOLERANCE,
        ):
            raise ValueError("preservation_rate and violation_rate must sum to one.")
        expected_status = (
            "preserved" if violation_rate <= _ENERGY_TOLERANCE else "violated"
        )
        if self.status != expected_status:
            raise ValueError("status must match the observed violation rate.")

        if self.source_kind == "probabilities":
            if (
                self.shots is not None
                or self.preserved_shots is not None
                or self.violating_shots is not None
            ):
                raise ValueError("probability evidence cannot contain shot counts.")
            if any(item.shots is not None for item in self.constraints):
                raise ValueError(
                    "probability evidence constraints cannot contain shot counts."
                )
        else:
            if (
                self.shots is None
                or self.preserved_shots is None
                or self.violating_shots is None
            ):
                raise ValueError(
                    "count evidence requires shots and preservation counts."
                )
            _require_positive_int(self.shots, "shots")
            _require_non_negative_int(self.preserved_shots, "preserved_shots")
            _require_non_negative_int(self.violating_shots, "violating_shots")
            if self.preserved_shots + self.violating_shots != self.shots:
                raise ValueError(
                    "preserved_shots and violating_shots must sum to shots."
                )
            if not math.isclose(
                preservation_rate,
                self.preserved_shots / self.shots,
                rel_tol=0.0,
                abs_tol=_ENERGY_TOLERANCE,
            ):
                raise ValueError(
                    "preservation_rate must match preserved_shots / shots."
                )
            if any(item.shots != self.shots for item in self.constraints):
                raise ValueError("all constraint shot counts must match total shots.")

        object.__setattr__(self, "preservation_rate", preservation_rate)
        object.__setattr__(self, "violation_rate", violation_rate)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> CardinalitySubspaceEvidenceIR:
        """Restore aggregate fixed-cardinality evidence from wire data."""
        return cls(
            source_kind=data["source_kind"],
            constraints=tuple(
                CardinalityConstraintEvidenceIR.from_dict(_mapping(item, "constraint"))
                for item in _sequence(data["constraints"], "constraints")
            ),
            preservation_rate=data["preservation_rate"],
            violation_rate=data["violation_rate"],
            status=data["status"],
            shots=data.get("shots"),
            preserved_shots=data.get("preserved_shots"),
            violating_shots=data.get("violating_shots"),
            schema_version=str(data.get("schema_version", ALGORITHM_SCHEMA_VERSION)),
        )


@dataclass(frozen=True)
class VariationalResult(IRMixin, Generic[VariationalObjectiveT]):
    """Workflow result that references, but never replaces, Backend ResultIR facts."""

    algorithm_run_id: str
    algorithm_kind: AlgorithmKind
    hamiltonian: PauliHamiltonian
    ansatz: AnsatzSpecIR
    optimizer: OptimizerConfig
    evaluations: tuple[VariationalObjectiveT, ...]
    best_evaluation_index: int
    termination: OptimizerTerminationIR
    gradients: tuple[ObjectiveGradientIR, ...] = ()
    optimization_starts: tuple[OptimizationStartIR, ...] = ()
    selected_start_index: int | None = None
    sampled_selection: SampledSelectionIR | None = None
    final_result: ResultIR | None = None
    most_probable_candidate: AlgorithmCandidateIR | None = None
    best_observed_candidate: AlgorithmCandidateIR | None = None
    baseline: ClassicalBaselineIR | None = None
    cardinality_subspace: CardinalitySubspaceEvidenceIR | None = None
    problem_id: str | None = None
    problem_hash: str | None = None
    optimality_claim: Literal["not_claimed"] = "not_claimed"
    metadata: Mapping[str, Any] = field(default_factory=dict)
    schema_version: str = ALGORITHM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_text(self.algorithm_run_id, "algorithm_run_id")
        if self.algorithm_kind not in _ALGORITHM_KINDS:
            raise ValueError(f"Unsupported algorithm_kind: {self.algorithm_kind!r}.")
        if not isinstance(self.hamiltonian, PauliHamiltonian):
            raise TypeError("hamiltonian must be PauliHamiltonian.")
        if not isinstance(self.ansatz, AnsatzSpecIR):
            raise TypeError("ansatz must be AnsatzSpecIR.")
        if self.ansatz.logical_order != self.hamiltonian.logical_order:
            raise ValueError(
                "ansatz logical_order must match Hamiltonian logical_order."
            )
        if self.algorithm_kind == "qaoa" and self.ansatz.ansatz_kind != "qaoa":
            raise ValueError("QAOA result requires a QAOA ansatz.")
        if self.algorithm_kind == "vqe" and self.ansatz.ansatz_kind == "qaoa":
            raise ValueError("VQE result cannot use a QAOA ansatz contract.")
        if not isinstance(self.optimizer, OptimizerConfig):
            raise TypeError("optimizer must be OptimizerConfig.")
        if self.optimizer.bounds and len(self.optimizer.bounds) != len(
            self.ansatz.parameter_names
        ):
            raise ValueError("optimizer bounds must match ansatz parameter count.")
        if not isinstance(self.evaluations, tuple):
            object.__setattr__(self, "evaluations", tuple(self.evaluations))
        if not self.evaluations:
            raise ValueError("evaluations must not be empty.")
        from cascaqit.algorithms.measurement import SampledObjectiveEvaluationIR

        evaluation_types = (ObjectiveEvaluationIR, SampledObjectiveEvaluationIR)
        if any(not isinstance(item, evaluation_types) for item in self.evaluations):
            raise TypeError("evaluations must contain variational objective IR values.")
        evaluations = cast(
            tuple[Union[ObjectiveEvaluationIR, SampledObjectiveEvaluationIR], ...],
            self.evaluations,
        )
        if len({type(item) for item in evaluations}) != 1:
            raise ValueError("all evaluations must use one objective estimator type.")
        if isinstance(evaluations[0], SampledObjectiveEvaluationIR):
            if self.algorithm_kind != "vqe":
                raise ValueError("sampled objective evaluations require VQE.")
            if self.optimizer.method not in {"SPSA", "ADAM"}:
                raise ValueError("sampled objective evaluations require SPSA or ADAM.")
            if (
                self.optimizer.method == "SPSA"
                and self.optimizer.gradient is not None
            ):
                raise ValueError("sampled SPSA evaluations cannot use gradients.")
        indices = tuple(item.evaluation_index for item in evaluations)
        if indices != tuple(range(len(evaluations))):
            raise ValueError("evaluation indices must be contiguous and zero-based.")
        evaluation_ids = tuple(item.evaluation_id for item in evaluations)
        if len(evaluation_ids) != len(set(evaluation_ids)):
            raise ValueError("evaluation evaluation_id values must be unique.")
        result_ids = tuple(
            result_id
            for item in evaluations
            for result_id in _variational_evaluation_result_ids(item)
        )
        if len(result_ids) != len(set(result_ids)):
            raise ValueError("objective Backend result ids must be unique.")
        from cascaqit.algorithms.sampled_selection import SampledSelectionIR

        selection = self.sampled_selection
        selection_result_ids: tuple[str, ...] = ()
        if selection is not None:
            if not isinstance(selection, SampledSelectionIR):
                raise TypeError("sampled_selection must be SampledSelectionIR or None.")
            if not isinstance(evaluations[0], SampledObjectiveEvaluationIR):
                raise ValueError(
                    "sampled_selection requires sampled objective evaluations."
                )
            if selection.evaluation_start_index != len(evaluations):
                raise ValueError(
                    "sampled selection must start after optimizer evaluations."
                )
            if self.optimizer.method == "SPSA":
                ranked_evaluations = tuple(
                    evaluations[index]
                    for index in rank_spsa_source_evaluation_indices(
                        self.optimization_starts
                    )
                )
            else:
                ranked_evaluations = tuple(
                    sorted(
                        cast(tuple[SampledObjectiveEvaluationIR, ...], evaluations),
                        key=lambda item: (item.energy, item.evaluation_index),
                    )
                )
            expected_sources: list[int] = []
            seen_bindings: set[str] = set()
            for ranked_evaluation in ranked_evaluations:
                bind_hash = ranked_evaluation.parameter_bind.parameter_bind_hash
                if bind_hash in seen_bindings:
                    continue
                seen_bindings.add(bind_hash)
                expected_sources.append(ranked_evaluation.evaluation_index)
                if len(expected_sources) == selection.config.candidate_count:
                    break
            actual_sources = [
                item.source_evaluation_index for item in selection.candidates
            ]
            if actual_sources != expected_sources:
                raise ValueError(
                    "sampled selection candidates must be the ranked distinct "
                    "optimizer points."
                )
            for candidate in selection.candidates:
                source = cast(
                    SampledObjectiveEvaluationIR,
                    evaluations[candidate.source_evaluation_index],
                )
                if candidate.source_evaluation_id != source.evaluation_id:
                    raise ValueError(
                        "sampled selection source id must match optimizer history."
                    )
                if (
                    candidate.source_parameter_bind_hash
                    != source.parameter_bind.parameter_bind_hash
                ):
                    raise ValueError(
                        "sampled selection binding must match optimizer history."
                    )
                for repeated in candidate.evaluations:
                    if (
                        repeated.plan.source_circuit_hash
                        != source.plan.source_circuit_hash
                        or repeated.plan.hamiltonian_hash
                        != source.plan.hamiltonian_hash
                        or repeated.plan.logical_order != source.plan.logical_order
                    ):
                        raise ValueError(
                            "confirmation measurement plan must match its source "
                            "optimizer evaluation."
                        )
                    if _sampled_runtime_context(repeated) != _sampled_runtime_context(
                        source
                    ):
                        raise ValueError(
                            "sampled confirmation context must match optimizer history."
                        )
            selection_result_ids = tuple(
                result_id
                for candidate in selection.candidates
                for repeated in candidate.evaluations
                for result_id in repeated.result_ids
            )
            if set(selection_result_ids).intersection(result_ids):
                raise ValueError(
                    "confirmation Result ids must be distinct from optimizer evidence."
                )
        hamiltonian_hash = self.hamiltonian.stable_hash()
        if any(
            _variational_evaluation_hamiltonian_hash(item) != hamiltonian_hash
            for item in evaluations
        ):
            raise ValueError("all evaluations must reference the result Hamiltonian.")
        expected_terms = tuple(
            (term.term_id, term.observable.name, term.coefficient)
            for term in self.hamiltonian.terms
        )
        expected_parameter_names = set(self.ansatz.parameter_names)
        expected_observable_set_hash = self.hamiltonian.observable_set().stable_hash()
        objective_execution_context = _objective_execution_context(evaluations[0])
        for objective_evaluation in evaluations:
            actual_terms = tuple(
                (item.term_id, item.observable_name, item.coefficient)
                for item in objective_evaluation.contributions
            )
            if actual_terms != expected_terms:
                raise ValueError(
                    "evaluation contributions must match Hamiltonian term order."
                )
            if (
                _variational_evaluation_constant(objective_evaluation)
                != self.hamiltonian.constant
            ):
                raise ValueError("evaluation constant must match Hamiltonian constant.")
            if (
                objective_evaluation.observable_batch.observable_set_hash
                != expected_observable_set_hash
            ):
                raise ValueError(
                    "evaluation Observable batch must match the Hamiltonian."
                )
            if (
                set(objective_evaluation.parameter_bind.values)
                != expected_parameter_names
            ):
                raise ValueError(
                    "evaluation parameters must match ansatz parameter names."
                )
            if (
                _objective_execution_context(objective_evaluation)
                != objective_execution_context
            ):
                raise ValueError(
                    "all evaluations must share NoiseModel, requested options, "
                    "simulation method, and estimator."
                )
        if not isinstance(self.best_evaluation_index, int) or isinstance(
            self.best_evaluation_index, bool
        ):
            raise TypeError("best_evaluation_index must be int.")
        if not 0 <= self.best_evaluation_index < len(evaluations):
            raise ValueError("best_evaluation_index is outside evaluations.")
        if self.optimizer.method == "SPSA" and self.optimization_starts:
            expected_best = min(
                self.optimization_starts,
                key=lambda item: (item.best_objective, item.best_evaluation_index),
            ).best_evaluation_index
        else:
            expected_best = min(
                evaluations,
                key=lambda item: (item.energy, item.evaluation_index),
            ).evaluation_index
        if self.best_evaluation_index != expected_best:
            raise ValueError(
                "best_evaluation_index must select the minimum objective estimate."
            )
        if not isinstance(self.termination, OptimizerTerminationIR):
            raise TypeError("termination must be OptimizerTerminationIR.")
        if self.termination.method != self.optimizer.method:
            raise ValueError("termination method must match optimizer method.")
        if self.termination.nfev != len(evaluations):
            raise ValueError("termination nfev must match evaluation count.")
        from cascaqit.algorithms.gradient import ObjectiveGradientIR

        if not isinstance(self.gradients, tuple):
            object.__setattr__(self, "gradients", tuple(self.gradients))
        if any(not isinstance(item, ObjectiveGradientIR) for item in self.gradients):
            raise TypeError("gradients must contain ObjectiveGradientIR values.")
        gradient_indices = tuple(item.gradient_index for item in self.gradients)
        if gradient_indices != tuple(range(len(self.gradients))):
            raise ValueError("gradient indices must be contiguous and zero-based.")
        if len({item.gradient_id for item in self.gradients}) != len(self.gradients):
            raise ValueError("gradient ids must be unique.")
        if self.gradients:
            first_plan_hash = self.gradients[0].plan_hash
            for gradient in self.gradients:
                if gradient.plan_hash != first_plan_hash:
                    raise ValueError(
                        "all gradients must share one parameter-shift plan."
                    )
                if gradient.plan.hamiltonian_hash != hamiltonian_hash:
                    raise ValueError(
                        "gradient plan must reference the result Hamiltonian."
                    )
                if gradient.plan.parameter_names != self.ansatz.parameter_names:
                    raise ValueError(
                        "gradient parameters must match the result ansatz."
                    )
                for repeat in gradient.repeats:
                    for pair in repeat.shift_pairs:
                        for shift_evaluation in (
                            pair.positive_evaluation,
                            pair.negative_evaluation,
                        ):
                            if (
                                _objective_runtime_context(shift_evaluation)
                                != _objective_runtime_context(evaluations[0])
                            ):
                                raise ValueError(
                                    "gradient execution context must match objective "
                                    "execution context."
                                )
        if self.optimizer.gradient is None and self.gradients:
            raise ValueError(
                "gradient history requires optimizer gradient configuration."
            )
        if self.optimizer.gradient is not None and not self.gradients:
            raise ValueError("gradient optimizer result requires gradient history.")
        if self.termination.njev != len(self.gradients):
            raise ValueError("termination njev must match gradient count.")
        expected_backend_count = sum(
            _variational_evaluation_backend_execution_count(item)
            for item in evaluations
        ) + sum(item.backend_execution_count for item in self.gradients)
        if self.termination.backend_execution_count != expected_backend_count:
            raise ValueError(
                "termination backend_execution_count must match objective and "
                "gradient evidence."
            )
        if not isinstance(self.optimization_starts, tuple):
            object.__setattr__(
                self,
                "optimization_starts",
                tuple(self.optimization_starts),
            )
        if any(
            not isinstance(item, OptimizationStartIR)
            for item in self.optimization_starts
        ):
            raise TypeError(
                "optimization_starts must contain OptimizationStartIR values."
            )
        if self.optimization_starts:
            if len(self.optimization_starts) != self.optimizer.starts:
                raise ValueError("optimization_starts must match optimizer starts.")
            if tuple(item.start_index for item in self.optimization_starts) != tuple(
                range(len(self.optimization_starts))
            ):
                raise ValueError(
                    "optimization start indices must be contiguous and zero-based."
                )
            expected_evaluation_start = 0
            expected_gradient_start = 0
            for start in self.optimization_starts:
                validate_adam_start_evidence(start, self.optimizer)
                validate_spsa_start_evidence(start, self.optimizer)
                if start.evaluation_start_index != expected_evaluation_start:
                    raise ValueError(
                        "optimization starts must cover contiguous evaluation slices."
                    )
                expected_evaluation_start += start.evaluation_count
                if start.gradient_start_index != expected_gradient_start:
                    raise ValueError(
                        "optimization starts must cover contiguous gradient slices."
                    )
                expected_gradient_start += start.gradient_count
                if start.termination.method == "ADAM":
                    start_evaluations = evaluations[
                        start.evaluation_start_index : start.evaluation_start_index
                        + start.evaluation_count
                    ]
                    start_gradients = self.gradients[
                        start.gradient_start_index : start.gradient_start_index
                        + start.gradient_count
                    ]
                    for iteration, gradient in zip(
                        start.adam_iterations,
                        start_gradients,
                    ):
                        if (
                            iteration.gradient_index != gradient.gradient_index
                            or iteration.gradient_hash != gradient.gradient_hash
                            or dict(iteration.gradient) != dict(gradient.gradient)
                            or dict(iteration.gradient_covariance)
                            != dict(gradient.gradient_covariance)
                            or dict(iteration.gradient_standard_errors)
                            != dict(gradient.gradient_standard_errors)
                            or iteration.gradient_uncertainty_norm
                            != gradient.uncertainty_norm
                            or iteration.gradient_repeat_count
                            != gradient.repeat_count
                            or iteration.gradient_repeat_stop_reason
                            != gradient.repeat_stop_reason
                            or iteration.gradient_objective_evaluation_count
                            != gradient.objective_evaluation_count
                            or iteration.gradient_backend_execution_count
                            != gradient.backend_execution_count
                            or iteration.gradient_total_shots != gradient.total_shots
                        ):
                            raise ValueError(
                                "ADAM iteration gradient facts must match history."
                            )
                        center = start_evaluations[iteration.iteration_index]
                        updated = start_evaluations[iteration.iteration_index + 1]
                        _require_parameter_mapping_values_close(
                            iteration.center_parameters,
                            center.parameter_bind.values,
                            "ADAM center objective parameters",
                        )
                        _require_parameter_mapping_values_close(
                            iteration.updated_parameters,
                            updated.parameter_bind.values,
                            "ADAM updated objective parameters",
                        )
                    if not math.isclose(
                        start_evaluations[-1].energy,
                        start.final_objective,
                        rel_tol=0.0,
                        abs_tol=_ENERGY_TOLERANCE,
                    ):
                        raise ValueError(
                            "ADAM final_objective must match its updated objective."
                        )
                elif start.termination.method == "SPSA":
                    start_evaluations = evaluations[
                        start.evaluation_start_index : start.evaluation_start_index
                        + start.evaluation_count
                    ]
                    assert start.spsa_initial_estimate is not None
                    assert start.spsa_final_estimate is not None
                    _validate_spsa_estimate_evaluations(
                        start.spsa_initial_estimate,
                        start_evaluations,
                        start.initial_parameters,
                    )
                    _validate_spsa_estimate_evaluations(
                        start.spsa_final_estimate,
                        start_evaluations,
                        start.final_parameters,
                    )
                    if not math.isclose(
                        start.spsa_final_estimate.pooled_objective,
                        start.final_objective,
                        rel_tol=0.0,
                        abs_tol=_ENERGY_TOLERANCE,
                    ):
                        raise ValueError(
                            "SPSA final_objective must match the final center estimate."
                        )
                    estimates = list(_spsa_objective_estimates(start))
                    expected_start_best = min(
                        estimates,
                        key=lambda item: (
                            item.pooled_objective,
                            item.source_evaluation_offset,
                        ),
                    )
                    if (
                        start.best_evaluation_index
                        != start.evaluation_start_index
                        + expected_start_best.source_evaluation_offset
                        or not math.isclose(
                            start.best_objective,
                            expected_start_best.pooled_objective,
                            rel_tol=0.0,
                            abs_tol=_ENERGY_TOLERANCE,
                        )
                    ):
                        raise ValueError(
                            "start best objective must match pooled SPSA estimates."
                        )
                    for spsa_iteration in start.spsa_iterations:
                        for direction in spsa_iteration.directions:
                            _validate_spsa_estimate_evaluations(
                                direction.plus_estimate,
                                start_evaluations,
                                direction.plus_parameters,
                            )
                            _validate_spsa_estimate_evaluations(
                                direction.minus_estimate,
                                start_evaluations,
                                direction.minus_parameters,
                            )
                    calibration = start.spsa_learning_rate_calibration
                    if calibration is not None:
                        for direction in calibration.directions:
                            _validate_spsa_estimate_evaluations(
                                direction.plus_estimate,
                                start_evaluations,
                                direction.plus_parameters,
                            )
                            _validate_spsa_estimate_evaluations(
                                direction.minus_estimate,
                                start_evaluations,
                                direction.minus_parameters,
                            )
                elif not math.isclose(
                    evaluations[start.best_evaluation_index].energy,
                    start.best_objective,
                    rel_tol=0.0,
                    abs_tol=_ENERGY_TOLERANCE,
                ):
                    raise ValueError(
                        "start best_objective must match its best evaluation."
                    )
            if expected_evaluation_start != len(evaluations):
                raise ValueError(
                    "optimization starts must cover every evaluation exactly once."
                )
            if expected_gradient_start != len(self.gradients):
                raise ValueError(
                    "optimization starts must cover every gradient exactly once."
                )
            if (
                sum(
                    item.backend_execution_count
                    if item.backend_execution_count is not None
                    else 0
                    for item in self.optimization_starts
                )
                != self.termination.backend_execution_count
            ):
                raise ValueError(
                    "optimization start Backend costs must match termination evidence."
                )
            if (
                not isinstance(self.selected_start_index, int)
                or isinstance(self.selected_start_index, bool)
                or not 0 <= self.selected_start_index < len(self.optimization_starts)
            ):
                raise ValueError("selected_start_index is outside optimization_starts.")
            selected_start = self.optimization_starts[self.selected_start_index]
            if selected_start.best_evaluation_index != self.best_evaluation_index:
                raise ValueError("selected start must own the global best evaluation.")
        elif self.selected_start_index is not None:
            raise ValueError("selected_start_index requires optimization_starts.")
        if self.final_result is not None and not isinstance(
            self.final_result, ResultIR
        ):
            raise TypeError("final_result must be ResultIR or None.")
        if self.final_result is not None:
            if self.final_result.result_id in set((*result_ids, *selection_result_ids)):
                raise ValueError(
                    "final_result must be distinct from objective and confirmation "
                    "Result evidence."
                )
            if self.final_result.shots <= 0 or not self.final_result.counts:
                raise ValueError("final_result must contain sampled counts.")
            if sum(self.final_result.counts.values()) != self.final_result.shots:
                raise ValueError("final_result counts must sum to shots.")
        for name, algorithm_candidate in (
            ("most_probable_candidate", self.most_probable_candidate),
            ("best_observed_candidate", self.best_observed_candidate),
        ):
            if algorithm_candidate is not None and not isinstance(
                algorithm_candidate, AlgorithmCandidateIR
            ):
                raise TypeError(f"{name} must be AlgorithmCandidateIR or None.")
            if algorithm_candidate is not None and self.final_result is None:
                raise ValueError(f"{name} requires final_result evidence.")
            if algorithm_candidate is not None and self.problem_id is None:
                raise ValueError(f"{name} requires problem provenance.")
            if algorithm_candidate is not None:
                assert self.final_result is not None
                expected_count = self.final_result.counts.get(
                    algorithm_candidate.bitstring
                )
                if (
                    expected_count is None
                    or expected_count != algorithm_candidate.count
                ):
                    raise ValueError(f"{name} count must match final_result counts.")
                expected_probability = expected_count / self.final_result.shots
                if algorithm_candidate.probability is None or not math.isclose(
                    algorithm_candidate.probability,
                    expected_probability,
                    rel_tol=0.0,
                    abs_tol=_ENERGY_TOLERANCE,
                ):
                    raise ValueError(
                        f"{name} probability must match final_result counts."
                    )
        if self.most_probable_candidate is not None:
            assert self.final_result is not None
            largest_count = max(self.final_result.counts.values())
            expected_most = min(
                bitstring
                for bitstring, count in self.final_result.counts.items()
                if count == largest_count
            )
            if self.most_probable_candidate.bitstring != expected_most:
                raise ValueError(
                    "most_probable_candidate must use count and bitstring tie-break."
                )
        if self.baseline is not None and not isinstance(
            self.baseline, ClassicalBaselineIR
        ):
            raise TypeError("baseline must be ClassicalBaselineIR or None.")
        if self.baseline is not None and self.problem_id is None:
            raise ValueError("baseline requires problem provenance.")
        expected_cardinality = build_cardinality_subspace_evidence(
            self.ansatz,
            self.final_result,
        )
        if self.cardinality_subspace != expected_cardinality:
            raise ValueError(
                "cardinality_subspace must match the Ansatz and final Result."
            )
        if (self.problem_id is None) != (self.problem_hash is None):
            raise ValueError("problem_id and problem_hash must be provided together.")
        if self.problem_id is not None:
            _require_text(self.problem_id, "problem_id")
            _require_digest(self.problem_hash, "problem_hash")
            if self.hamiltonian.source_problem_id != self.problem_id:
                raise ValueError("problem_id must match Hamiltonian provenance.")
            if self.hamiltonian.source_problem_hash != self.problem_hash:
                raise ValueError("problem_hash must match Hamiltonian provenance.")
        if self.optimality_claim != "not_claimed":
            raise ValueError("VariationalResult cannot claim global optimality.")
        metadata = _freeze_mapping(self.metadata)
        expected_objective_repeats = (
            self.optimizer.spsa.objective_repeats
            if self.optimizer.spsa is not None
            else 1
        )
        if metadata.get("objective_repeats") not in {
            None,
            expected_objective_repeats,
        }:
            raise ValueError("objective_repeats metadata does not match SPSA config.")
        expected_repeat_mode = (
            self.optimizer.spsa.objective_repeat_mode
            if self.optimizer.spsa is not None
            else "fixed"
        )
        actual_repeat_mode = metadata.get("objective_repeat_mode")
        if (
            expected_repeat_mode == "adaptive"
            and actual_repeat_mode != "adaptive"
        ) or (
            expected_repeat_mode == "fixed"
            and actual_repeat_mode not in {None, "fixed"}
        ):
            raise ValueError(
                "objective_repeat_mode metadata does not match SPSA config."
            )
        expected_max_repeats = (
            self.optimizer.spsa.max_objective_repeats
            if self.optimizer.spsa is not None
            else None
        )
        if metadata.get("max_objective_repeats") != expected_max_repeats:
            raise ValueError(
                "max_objective_repeats metadata does not match SPSA config."
            )
        expected_error_target = (
            self.optimizer.spsa.objective_standard_error_target
            if self.optimizer.spsa is not None
            else None
        )
        if metadata.get("objective_standard_error_target") != expected_error_target:
            raise ValueError(
                "objective_standard_error_target metadata does not match SPSA config."
            )
        expected_repeat_counts = tuple(
            estimate.repeat_count
            for start in self.optimization_starts
            for estimate in _spsa_objective_estimates(start)
        )
        actual_repeat_counts = metadata.get("objective_repeat_counts")
        if (
            expected_repeat_mode == "adaptive"
            and actual_repeat_counts is None
        ) or (
            actual_repeat_counts is not None
            and tuple(actual_repeat_counts) != expected_repeat_counts
        ):
            raise ValueError(
                "objective_repeat_counts metadata does not match SPSA evidence."
            )
        expected_pooled_estimates = tuple(
            estimate.to_dict()
            for start in self.optimization_starts
            for estimate in _spsa_objective_estimates(start)
        )
        actual_pooled_estimates = metadata.get("objective_pooled_estimates")
        if actual_pooled_estimates is not None and canonicalize(
            actual_pooled_estimates
        ) != canonicalize(expected_pooled_estimates):
            raise ValueError(
                "objective_pooled_estimates metadata does not match SPSA evidence."
            )
        expected_selection_rule = (
            selection.selection_rule
            if selection is not None
            else (
                (
                    "minimum_pooled_sample_mean"
                    if isinstance(evaluations[0], SampledObjectiveEvaluationIR)
                    and self.optimizer.spsa is not None
                    and self.optimizer.spsa.objective_repeats > 1
                    else "minimum_observed_sample_mean"
                )
                if isinstance(evaluations[0], SampledObjectiveEvaluationIR)
                else "minimum_observed_energy"
            )
        )
        if metadata.get("objective_selection_rule") not in {
            None,
            expected_selection_rule,
        }:
            raise ValueError(
                "objective_selection_rule does not match saved selection evidence."
            )
        if selection is not None:
            if metadata.get("resolved_seed") != selection.root_seed:
                raise ValueError(
                    "sampled selection root seed must match the resolved run seed."
                )
            if (
                metadata.get("confirmation_backend_execution_count")
                != selection.backend_execution_count
                or metadata.get("confirmation_total_shots") != selection.total_shots
            ):
                raise ValueError(
                    "confirmation metadata cost must match sampled selection."
                )
            if (
                metadata.get("selected_evaluation_index")
                != selection.selected_source_evaluation_index
            ):
                raise ValueError(
                    "selected evaluation metadata must match sampled selection."
                )
            expected_workflow_backend_executions = (
                (self.termination.backend_execution_count or 0)
                + selection.backend_execution_count
                + (1 if self.final_result is not None else 0)
            )
            expected_workflow_shots = (
                sum(
                    item.total_shots
                    for item in cast(
                        tuple[SampledObjectiveEvaluationIR, ...],
                        evaluations,
                    )
                )
                + sum(item.total_shots for item in self.gradients)
                + selection.total_shots
                + (0 if self.final_result is None else self.final_result.shots)
            )
            if (
                metadata.get("workflow_backend_execution_count")
                != expected_workflow_backend_executions
                or metadata.get("workflow_total_shots") != expected_workflow_shots
            ):
                raise ValueError(
                    "workflow metadata cost must match optimization, confirmation, "
                    "and final sampling evidence."
                )
        expected_gradient_total_shots = sum(
            item.total_shots for item in self.gradients
        )
        if (
            "gradient_total_shots" in metadata
            and metadata.get("gradient_total_shots")
            != expected_gradient_total_shots
        ):
            raise ValueError(
                "gradient_total_shots metadata must match gradient evidence."
            )
        if self.final_result is not None:
            final_sampling = metadata.get("final_sampling")
            if not isinstance(final_sampling, Mapping):
                raise ValueError("final_result requires final_sampling metadata.")
            if final_sampling.get("result_id") != self.final_result.result_id:
                raise ValueError("final_sampling result_id must match final_result.")
            if final_sampling.get("result_hash") != self.final_result.stable_hash():
                raise ValueError("final_sampling result_hash must match final_result.")
            selected_evaluation = cast(
                Union[ObjectiveEvaluationIR, SampledObjectiveEvaluationIR],
                self.selected_evaluation,
            )
            if (
                final_sampling.get("source_evaluation_id")
                != selected_evaluation.evaluation_id
            ):
                raise ValueError(
                    "final_sampling must reference the selected evaluation."
                )
            _validate_final_sampling_execution_context(
                self.final_result,
                final_sampling,
                selected_evaluation,
            )
        object.__setattr__(self, "metadata", metadata)

    @property
    def best_evaluation(
        self,
    ) -> VariationalObjectiveT:
        """Return the minimum observed objective evaluation."""
        return self.evaluations[self.best_evaluation_index]

    @property
    def selected_evaluation(self) -> VariationalObjectiveT:
        """Return the optimizer point selected as the final-sampling source."""
        if self.sampled_selection is None:
            return self.best_evaluation
        return self.evaluations[self.sampled_selection.selected_source_evaluation_index]

    @property
    def gradient_plan(self) -> ParameterShiftPlanIR | None:
        """Return the shared gradient plan, when gradient optimization was used."""
        return None if not self.gradients else self.gradients[0].plan

    def diagnose_stability(
        self,
        config: VQEStabilityConfig | None = None,
    ) -> VQEStabilityDiagnosticResult:
        """Diagnose saved native-SPSA VQE evidence without rerunning it."""
        from cascaqit.algorithms.vqe_stability import diagnose_vqe_stability

        return diagnose_vqe_stability(self, config)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> VariationalResult[Any]:
        """Build a variational result from JSON-compatible data."""
        from cascaqit.algorithms.gradient import ObjectiveGradientIR

        raw_evaluations = data.get("evaluations", ())
        if not isinstance(raw_evaluations, (list, tuple)):
            raise TypeError("evaluations must be an array.")
        raw_final = data.get("final_result")
        raw_most = data.get("most_probable_candidate")
        raw_best = data.get("best_observed_candidate")
        raw_baseline = data.get("baseline")
        raw_cardinality = data.get("cardinality_subspace")
        raw_selection = data.get("sampled_selection")
        restored_evaluations: tuple[Any, ...] = tuple(
            _variational_evaluation_from_dict(_mapping(item, "evaluation"))
            for item in raw_evaluations
        )
        return cls(
            algorithm_run_id=data["algorithm_run_id"],
            algorithm_kind=data["algorithm_kind"],
            hamiltonian=PauliHamiltonian.from_dict(
                _mapping(data["hamiltonian"], "hamiltonian")
            ),
            ansatz=AnsatzSpecIR.from_dict(_mapping(data["ansatz"], "ansatz")),
            optimizer=OptimizerConfig.from_dict(
                _mapping(data["optimizer"], "optimizer")
            ),
            evaluations=restored_evaluations,
            best_evaluation_index=data["best_evaluation_index"],
            termination=OptimizerTerminationIR.from_dict(
                _mapping(data["termination"], "termination")
            ),
            gradients=tuple(
                ObjectiveGradientIR.from_dict(_mapping(item, "gradient"))
                for item in data.get("gradients", ())
            ),
            optimization_starts=tuple(
                OptimizationStartIR.from_dict(_mapping(item, "optimization_start"))
                for item in data.get("optimization_starts", ())
            ),
            selected_start_index=data.get("selected_start_index"),
            sampled_selection=(
                None
                if raw_selection is None
                else _restore_sampled_selection(
                    _mapping(raw_selection, "sampled_selection")
                )
            ),
            final_result=None
            if raw_final is None
            else ResultIR.from_dict(dict(_mapping(raw_final, "final_result"))),
            most_probable_candidate=None
            if raw_most is None
            else AlgorithmCandidateIR.from_dict(
                _mapping(raw_most, "most_probable_candidate")
            ),
            best_observed_candidate=None
            if raw_best is None
            else AlgorithmCandidateIR.from_dict(
                _mapping(raw_best, "best_observed_candidate")
            ),
            baseline=None
            if raw_baseline is None
            else ClassicalBaselineIR.from_dict(_mapping(raw_baseline, "baseline")),
            cardinality_subspace=(
                None
                if raw_cardinality is None
                else CardinalitySubspaceEvidenceIR.from_dict(
                    _mapping(raw_cardinality, "cardinality_subspace")
                )
            ),
            problem_id=data.get("problem_id"),
            problem_hash=data.get("problem_hash"),
            optimality_claim=data.get("optimality_claim", "not_claimed"),
            metadata=_mapping(data.get("metadata", {}), "metadata"),
            schema_version=str(data.get("schema_version", ALGORITHM_SCHEMA_VERSION)),
        )

    @classmethod
    def from_json(cls, text: str) -> VariationalResult[Any]:
        """Build a variational result from JSON text."""
        return cls.from_dict(_json_object(text, "VariationalResult"))


def build_cardinality_subspace_evidence(
    ansatz: AnsatzSpecIR,
    result: ResultIR | None,
) -> CardinalitySubspaceEvidenceIR | None:
    """Derive fixed-cardinality preservation from an unmodified final result."""
    if not isinstance(ansatz, AnsatzSpecIR):
        raise TypeError("ansatz must be AnsatzSpecIR.")
    if ansatz.ansatz_kind != "cardinality_preserving":
        return None
    if result is None:
        return None
    if not isinstance(result, ResultIR):
        raise TypeError("result must be ResultIR or None.")

    raw_constraints = ansatz.definition.get("constraints")
    if not isinstance(raw_constraints, (list, tuple)) or not raw_constraints:
        raise ValueError(
            "cardinality-preserving Ansatz must declare constraint definitions."
        )
    definitions: list[tuple[tuple[str, ...], int]] = []
    for item in raw_constraints:
        if not isinstance(item, Mapping):
            raise ValueError("cardinality constraint definition must be an object.")
        qubits = tuple(_sequence(item.get("qubits"), "constraint qubits"))
        _require_unique_text(qubits, "constraint qubits", allow_empty=False)
        weight = item.get("weight")
        if (
            not isinstance(weight, int)
            or isinstance(weight, bool)
            or not 0 <= weight <= len(qubits)
        ):
            raise ValueError("constraint weight must match its qubit group.")
        definitions.append((qubits, weight))

    positions = {qubit: index for index, qubit in enumerate(ansatz.logical_order)}
    if any(qubit not in positions for qubits, _ in definitions for qubit in qubits):
        raise ValueError("cardinality constraint references an unknown logical qubit.")

    # Sampling evidence must describe the observed counts. Exact evaluate() calls
    # have no shots, so they fall back to the complete basis probabilities.
    if result.shots > 0 and result.counts:
        if sum(result.counts.values()) != result.shots:
            raise ValueError("Result counts must sum to shots.")
        distribution = {
            bitstring: count / result.shots
            for bitstring, count in result.counts.items()
        }
        count_distribution: Mapping[str, int] | None = result.counts
        source_kind: Literal["counts", "probabilities"] = "counts"
        shots: int | None = result.shots
    elif result.probabilities:
        distribution = dict(result.probabilities)
        count_distribution = None
        source_kind = "probabilities"
        shots = None
    else:
        raise ValueError(
            "cardinality evidence requires sampled counts or exact probabilities."
        )
    _validate_basis_distribution(distribution, width=len(ansatz.logical_order))

    weight_probabilities: list[dict[str, float]] = [{} for _ in definitions]
    weight_counts: list[dict[str, int]] = [{} for _ in definitions]
    preserved_probability = 0.0
    preserved_shots = 0
    # Accumulate both each group's marginal weight distribution and the joint
    # event that every declared group satisfies its target in the same state.
    for bitstring, probability in distribution.items():
        all_preserved = True
        for index, (qubits, target_weight) in enumerate(definitions):
            observed_weight = sum(
                bitstring[positions[qubit]] == "1" for qubit in qubits
            )
            key = str(observed_weight)
            weight_probabilities[index][key] = (
                weight_probabilities[index].get(key, 0.0) + probability
            )
            if count_distribution is not None:
                weight_counts[index][key] = (
                    weight_counts[index].get(key, 0) + count_distribution[bitstring]
                )
            if observed_weight != target_weight:
                all_preserved = False
        if all_preserved:
            preserved_probability += probability
            if count_distribution is not None:
                preserved_shots += count_distribution[bitstring]

    constraints = tuple(
        CardinalityConstraintEvidenceIR(
            constraint_index=index,
            qubits=qubits,
            target_weight=target_weight,
            weight_probabilities=weight_probabilities[index],
            preservation_rate=weight_probabilities[index].get(
                str(target_weight),
                0.0,
            ),
            weight_counts=weight_counts[index],
            shots=shots,
            preserved_shots=(
                None
                if shots is None
                else weight_counts[index].get(str(target_weight), 0)
            ),
            violating_shots=(
                None
                if shots is None
                else shots - weight_counts[index].get(str(target_weight), 0)
            ),
        )
        for index, (qubits, target_weight) in enumerate(definitions)
    )
    preserved_probability = min(max(preserved_probability, 0.0), 1.0)
    violating_probability = 1.0 - preserved_probability
    return CardinalitySubspaceEvidenceIR(
        source_kind=source_kind,
        constraints=constraints,
        preservation_rate=preserved_probability,
        violation_rate=violating_probability,
        status=(
            "preserved" if violating_probability <= _ENERGY_TOLERANCE else "violated"
        ),
        shots=shots,
        preserved_shots=None if shots is None else preserved_shots,
        violating_shots=None if shots is None else shots - preserved_shots,
    )


def _objective_execution_context(
    evaluation: ObjectiveEvaluationIR | SampledObjectiveEvaluationIR,
) -> tuple[object, ...]:
    """返回用于同一次优化交叉校验的 objective 执行上下文。"""
    from cascaqit.algorithms.measurement import SampledObjectiveEvaluationIR

    if isinstance(evaluation, SampledObjectiveEvaluationIR):
        return (
            "finite_shot_pauli_measurement",
            evaluation.plan.source_circuit_hash,
            evaluation.plan.hamiltonian_hash,
            evaluation.plan.config.shots_per_group,
            evaluation.plan.plan_hash,
            None
            if evaluation.noise_model is None
            else evaluation.noise_model.stable_hash(),
            None
            if evaluation.requested_options is None
            else evaluation.requested_options.stable_hash(),
            evaluation.simulation_method,
            evaluation.backend_id,
        )
    evidence = evaluation.execution_evidence
    return (
        None if evidence.noise_model is None else evidence.noise_model.stable_hash(),
        None
        if evidence.requested_options is None
        else evidence.requested_options.stable_hash(),
        evidence.simulation_plan.method_selected,
        evidence.estimator_kind,
        evidence.source_kind,
    )


def _objective_runtime_context(
    evaluation: ObjectiveEvaluationIR | SampledObjectiveEvaluationIR,
) -> tuple[object, ...]:
    """Return execution facts that must agree across objectives and gradients.

    Parameter-shift evaluates bound circuits with deliberately shifted angles, so
    their Circuit and measurement-plan hashes differ from the optimizer's center
    objective.  The physical runtime, estimator, and measurement configuration
    must still be identical.
    """
    from cascaqit.algorithms.measurement import SampledObjectiveEvaluationIR

    if isinstance(evaluation, SampledObjectiveEvaluationIR):
        evidence = evaluation.all_group_results[0].execution_evidence
        return (
            "sampled",
            evaluation.plan.config,
            evaluation.plan.hamiltonian_hash,
            evaluation.plan.logical_order,
            None
            if evaluation.noise_model is None
            else evaluation.noise_model.stable_hash(),
            None
            if evaluation.requested_options is None
            else evaluation.requested_options.stable_hash(),
            evaluation.simulation_method,
            evaluation.estimator_kind,
            evidence.source_kind,
            evaluation.backend_id,
        )
    evidence = evaluation.execution_evidence
    return (
        "exact",
        None
        if evidence.noise_model is None
        else evidence.noise_model.stable_hash(),
        None
        if evidence.requested_options is None
        else evidence.requested_options.stable_hash(),
        evidence.simulation_plan.method_selected,
        evidence.estimator_kind,
        evidence.source_kind,
        evidence.backend_id,
    )


def _sampled_runtime_context(
    evaluation: SampledObjectiveEvaluationIR,
) -> tuple[object, ...]:
    """Return runtime facts that confirmation must inherit from its source."""
    return (
        None
        if evaluation.noise_model is None
        else evaluation.noise_model.stable_hash(),
        None
        if evaluation.requested_options is None
        else evaluation.requested_options.stable_hash(),
        evaluation.simulation_method,
        evaluation.backend_id,
        evaluation.estimator_kind,
        (
            None
            if evaluation.plan.config.mitigation is None
            else evaluation.plan.config.mitigation.calibration.calibration_hash
        ),
    )


def _variational_evaluation_from_dict(
    data: Mapping[str, Any],
) -> ObjectiveEvaluationIR | SampledObjectiveEvaluationIR:
    """Restore the concrete objective IR without trusting free-form metadata."""
    from cascaqit.algorithms.measurement import SampledObjectiveEvaluationIR

    sampled_fields = {"plan", "group_results", "energy_standard_error"}
    exact_fields = {"execution_evidence", "result_id", "hamiltonian_hash"}
    if sampled_fields.issubset(data) and not exact_fields.intersection(data):
        return SampledObjectiveEvaluationIR.from_dict(data)
    if exact_fields.issubset(data) and not sampled_fields.intersection(data):
        return ObjectiveEvaluationIR.from_dict(data)
    raise ValueError("evaluation fields do not identify one objective IR type.")


def _restore_sampled_selection(data: Mapping[str, Any]) -> SampledSelectionIR:
    """Restore sampled selection lazily to avoid the measurement/model cycle."""
    from cascaqit.algorithms.sampled_selection import SampledSelectionIR

    return SampledSelectionIR.from_dict(data)


def _variational_evaluation_result_ids(
    evaluation: ObjectiveEvaluationIR | SampledObjectiveEvaluationIR,
) -> tuple[str, ...]:
    """Return every Backend Result id owned by one objective evaluation."""
    from cascaqit.algorithms.measurement import SampledObjectiveEvaluationIR

    if isinstance(evaluation, SampledObjectiveEvaluationIR):
        return evaluation.result_ids
    return (evaluation.result_id,)


def _variational_evaluation_hamiltonian_hash(
    evaluation: ObjectiveEvaluationIR | SampledObjectiveEvaluationIR,
) -> str:
    """Return the Hamiltonian identity shared by exact and sampled objectives."""
    from cascaqit.algorithms.measurement import SampledObjectiveEvaluationIR

    if isinstance(evaluation, SampledObjectiveEvaluationIR):
        return evaluation.plan.hamiltonian_hash
    return evaluation.hamiltonian_hash


def _variational_evaluation_constant(
    evaluation: ObjectiveEvaluationIR | SampledObjectiveEvaluationIR,
) -> float:
    """Return the constant energy term from either objective estimator."""
    from cascaqit.algorithms.measurement import SampledObjectiveEvaluationIR

    if isinstance(evaluation, SampledObjectiveEvaluationIR):
        return evaluation.plan.constant
    return evaluation.constant


def _variational_evaluation_backend_execution_count(
    evaluation: ObjectiveEvaluationIR | SampledObjectiveEvaluationIR,
) -> int:
    """Return actual Backend Jobs used by one objective evaluation."""
    from cascaqit.algorithms.measurement import SampledObjectiveEvaluationIR

    if isinstance(evaluation, SampledObjectiveEvaluationIR):
        return evaluation.backend_execution_count
    return 1


def _validate_final_sampling_execution_context(
    final_result: ResultIR,
    final_sampling: Mapping[str, Any],
    best_evaluation: ObjectiveEvaluationIR | SampledObjectiveEvaluationIR,
) -> None:
    """从保存 metadata 重建 final sampling 的数值与噪声来源事实。"""
    from cascaqit.algorithms.measurement import SampledObjectiveEvaluationIR
    from cascaqit.simulators import (
        NoiseModel,
        NoiseReport,
        SimulationExecutionPlan,
        SimulationOptions,
    )

    if isinstance(best_evaluation, SampledObjectiveEvaluationIR):
        sampled_evaluation = best_evaluation
        source = None
    else:
        sampled_evaluation = None
        source = best_evaluation.execution_evidence
    if final_sampling.get("shots") != final_result.shots:
        raise ValueError("final_sampling shots must match final Result.")
    if final_sampling.get("backend_execution_count") != 1:
        raise ValueError("final_sampling must record exactly one Backend execution.")
    if final_sampling.get("backend_id") != final_result.metadata.get("backend_id"):
        raise ValueError("final_sampling backend id must match final Result.")
    if sampled_evaluation is not None:
        source_backend_id = sampled_evaluation.backend_id
    else:
        assert source is not None
        source_backend_id = source.backend_id
    if final_sampling.get("backend_id") != source_backend_id:
        raise ValueError("final sampling Backend must match objective evidence.")
    backend_job_id = final_sampling.get("backend_job_id")
    if not isinstance(backend_job_id, str) or not backend_job_id.strip():
        raise ValueError("final_sampling backend job id must be non-empty.")
    if tuple(final_sampling.get("source_result_ids", ())) != (
        _variational_evaluation_result_ids(best_evaluation)
    ):
        raise ValueError(
            "final_sampling source Result ids must match the best evaluation."
        )
    if sampled_evaluation is not None:
        if final_sampling.get("source_execution_evidence_hash") is not None:
            raise ValueError(
                "sampled final sampling cannot reference exact execution evidence."
            )
        if (
            final_sampling.get("source_measurement_plan_hash")
            != sampled_evaluation.plan.plan_hash
        ):
            raise ValueError(
                "final_sampling source measurement plan must match the best evaluation."
            )
        if tuple(final_sampling.get("source_execution_evidence_hashes", ())) != (
            sampled_evaluation.execution_evidence_hashes
        ):
            raise ValueError(
                "final_sampling source evidence hashes must match sampled groups."
            )
        source_seed = int(sampled_evaluation.metadata["root_seed"])
    else:
        assert source is not None
        if final_sampling.get("source_execution_evidence_hash") != source.evidence_hash:
            raise ValueError(
                "final_sampling source evidence hash must match the best evaluation."
            )
        if final_sampling.get("source_measurement_plan_hash") is not None:
            raise ValueError(
                "exact final sampling cannot reference a measurement plan."
            )
        if final_sampling.get("source_execution_evidence_hashes") is not None:
            raise ValueError(
                "exact final sampling cannot reference sampled execution evidence."
            )
        source_seed = source.effective_seed
    if final_sampling.get("seed") != source_seed:
        raise ValueError("final_sampling seed must match the best evaluation seed.")

    raw_noise = final_sampling.get("noise_model")
    final_noise = (
        None
        if raw_noise is None
        else NoiseModel.from_dict(dict(_mapping(raw_noise, "final noise_model")))
    )
    final_noise_hash = None if final_noise is None else final_noise.stable_hash()
    if final_sampling.get("noise_model_hash") != final_noise_hash:
        raise ValueError("final_sampling NoiseModel hash does not match its facts.")
    if sampled_evaluation is not None:
        source_noise = sampled_evaluation.noise_model
    else:
        assert source is not None
        source_noise = source.noise_model
    source_noise_hash = None if source_noise is None else source_noise.stable_hash()
    if final_noise_hash != source_noise_hash:
        raise ValueError("final sampling NoiseModel must match objective evidence.")

    raw_options = final_sampling.get("requested_options")
    final_options = (
        None
        if raw_options is None
        else SimulationOptions.from_dict(
            dict(_mapping(raw_options, "final requested_options"))
        )
    )
    final_options_hash = None if final_options is None else final_options.stable_hash()
    if final_sampling.get("requested_options_hash") != final_options_hash:
        raise ValueError(
            "final_sampling requested options hash does not match its facts."
        )
    if sampled_evaluation is not None:
        source_options = sampled_evaluation.requested_options
    else:
        assert source is not None
        source_options = source.requested_options
    source_options_hash = (
        None if source_options is None else source_options.stable_hash()
    )
    if final_options_hash != source_options_hash:
        raise ValueError("final sampling options must match objective evidence.")

    final_plan = SimulationExecutionPlan.from_dict(
        dict(_mapping(final_sampling.get("simulation_plan"), "final simulation_plan"))
    )
    if final_sampling.get("simulation_plan_hash") != final_plan.stable_hash():
        raise ValueError("final_sampling SimulationPlan hash does not match its facts.")
    result_plan = SimulationExecutionPlan.from_dict(
        dict(
            _mapping(
                final_result.metadata.get("simulation_plan"),
                "final Result simulation_plan",
            )
        )
    )
    if final_result.metadata.get("simulation_plan_hash") != result_plan.stable_hash():
        raise ValueError("final Result SimulationPlan hash does not match its facts.")
    if final_plan != result_plan:
        raise ValueError(
            "final_sampling SimulationPlan must match final Result metadata."
        )
    if sampled_evaluation is not None:
        source_plan = (
            sampled_evaluation.all_group_results[0].execution_evidence.simulation_plan
        )
    else:
        assert source is not None
        source_plan = source.simulation_plan
    if _simulation_plan_context(final_plan) != _simulation_plan_context(source_plan):
        raise ValueError(
            "final sampling plan context must match objective execution context."
        )

    raw_report = final_sampling.get("noise_report")
    final_report = (
        None
        if raw_report is None
        else NoiseReport.from_dict(_mapping(raw_report, "final noise_report"))
    )
    final_report_hash = None if final_report is None else final_report.stable_hash()
    if final_sampling.get("noise_report_hash") != final_report_hash:
        raise ValueError("final_sampling NoiseReport hash does not match its facts.")
    expected_mode = "noisy" if final_noise is not None else "ideal"
    if final_sampling.get("execution_mode") != expected_mode:
        raise ValueError("final_sampling execution_mode does not match NoiseModel.")

    result_report_data = final_result.metadata.get("noise_report")
    if final_noise is None:
        if final_report is not None or result_report_data is not None:
            raise ValueError("ideal final sampling cannot contain NoiseReport.")
        if final_result.metadata.get("noise_model_hash") is not None:
            raise ValueError("ideal final Result cannot contain NoiseModel hash.")
        return
    if final_report is None or not isinstance(result_report_data, Mapping):
        raise ValueError("noisy final sampling requires NoiseReport evidence.")
    result_report = NoiseReport.from_dict(result_report_data)
    if final_report != result_report:
        raise ValueError("final_sampling NoiseReport must match final Result metadata.")
    if final_result.metadata.get("noise_report_hash") != result_report.stable_hash():
        raise ValueError("final Result NoiseReport hash does not match its facts.")
    if final_result.metadata.get("noise_model_hash") != final_noise_hash:
        raise ValueError("final Result NoiseModel hash does not match final sampling.")
    if (
        final_report.noise_model_id != final_noise.noise_model_id
        or final_report.noise_model_hash != final_noise_hash
        or final_report.method != final_plan.method_selected
    ):
        raise ValueError(
            "final NoiseReport model and method must match final sampling context."
        )


def _simulation_plan_context(plan: object) -> Mapping[str, Any]:
    """提取跨线路阶段必须一致的数值设置，排除动态主机与运行身份。"""
    from cascaqit.simulators import SimulationExecutionPlan

    if not isinstance(plan, SimulationExecutionPlan):
        raise TypeError("plan must be SimulationExecutionPlan.")
    return {
        "program_kind": plan.program_kind,
        "logical_sites": plan.logical_sites,
        "noisy": plan.noisy,
        "method_requested": plan.method_requested,
        "method_selected": plan.method_selected,
        "integrator_requested": plan.integrator_requested,
        "integrator_selected": plan.integrator_selected,
        "state_representation": plan.state_representation,
        "device": plan.device,
        "dtype": plan.dtype,
        "hilbert_dimension": plan.hilbert_dimension,
        "workers": plan.workers,
        "trajectories": plan.trajectories,
        "rtol": plan.rtol,
        "atol": plan.atol,
        "max_steps": plan.max_steps,
    }


def _finite_float(value: object, name: str) -> float:
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        raise TypeError(f"{name} must be a real number.")
    normalized = float(value)
    if not math.isfinite(normalized):
        raise ValueError(f"{name} must be finite.")
    return normalized


def _probability(value: object, name: str) -> float:
    """Normalize a probability while tolerating floating-point boundary noise."""
    normalized = _finite_float(value, name)
    if not -_ENERGY_TOLERANCE <= normalized <= 1.0 + _ENERGY_TOLERANCE:
        raise ValueError(f"{name} must be within [0, 1].")
    return min(max(normalized, 0.0), 1.0)


def _normalize_weight_probabilities(
    value: object,
    *,
    group_size: int,
) -> Mapping[str, float]:
    if not isinstance(value, Mapping) or not value:
        raise ValueError("weight_probabilities must be a non-empty mapping.")
    normalized: dict[str, float] = {}
    for raw_weight, raw_probability in value.items():
        weight = _weight_key(raw_weight, group_size=group_size)
        if weight in normalized:
            raise ValueError("weight_probabilities contains duplicate weights.")
        normalized[weight] = _probability(
            raw_probability,
            f"weight_probabilities[{weight}]",
        )
    if not math.isclose(
        sum(normalized.values()),
        1.0,
        rel_tol=0.0,
        abs_tol=1e-9,
    ):
        raise ValueError("weight_probabilities must sum to one.")
    return MappingProxyType(
        dict(sorted(normalized.items(), key=lambda item: int(item[0])))
    )


def _normalize_weight_counts(
    value: object,
    *,
    group_size: int,
) -> Mapping[str, int]:
    if not isinstance(value, Mapping):
        raise TypeError("weight_counts must be a mapping.")
    normalized: dict[str, int] = {}
    for raw_weight, raw_count in value.items():
        weight = _weight_key(raw_weight, group_size=group_size)
        if weight in normalized:
            raise ValueError("weight_counts contains duplicate weights.")
        _require_non_negative_int(raw_count, f"weight_counts[{weight}]")
        normalized[weight] = raw_count
    return MappingProxyType(
        dict(sorted(normalized.items(), key=lambda item: int(item[0])))
    )


def _weight_key(value: object, *, group_size: int) -> str:
    if isinstance(value, int) and not isinstance(value, bool):
        weight = value
    elif isinstance(value, str) and value.isdigit() and str(int(value)) == value:
        weight = int(value)
    else:
        raise ValueError("weight keys must be canonical non-negative integers.")
    if not 0 <= weight <= group_size:
        raise ValueError("weight key is outside the constraint group size.")
    return str(weight)


def _validate_basis_distribution(
    distribution: Mapping[str, float],
    *,
    width: int,
) -> None:
    if not distribution:
        raise ValueError("basis distribution must not be empty.")
    total = 0.0
    for bitstring, value in distribution.items():
        if (
            not isinstance(bitstring, str)
            or len(bitstring) != width
            or set(bitstring) - {"0", "1"}
        ):
            raise ValueError("basis states must match the Ansatz logical order.")
        total += _probability(value, f"distribution[{bitstring}]")
    if not math.isclose(total, 1.0, rel_tol=0.0, abs_tol=1e-9):
        raise ValueError("basis distribution must sum to one.")


def _finite_parameter_mapping(
    value: object,
    name: str,
) -> Mapping[str, float]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{name} must be a mapping.")
    normalized: dict[str, float] = {}
    for parameter_name, parameter_value in value.items():
        _require_text(parameter_name, f"{name} key")
        normalized[str(parameter_name)] = _finite_float(
            parameter_value,
            f"{name}[{parameter_name}]",
        )
    return MappingProxyType(normalized)


def _require_parameter_mapping_close(
    actual: Mapping[str, float],
    expected: Mapping[str, float],
    name: str,
) -> None:
    if tuple(actual) != tuple(expected):
        raise ValueError(f"{name} must preserve ordered parameter names.")
    if any(
        not math.isclose(
            actual[parameter_name],
            expected[parameter_name],
            rel_tol=0.0,
            abs_tol=1e-12,
        )
        for parameter_name in actual
    ):
        raise ValueError(f"{name} does not match recomputed values.")


def _require_parameter_mapping_values_close(
    actual: Mapping[str, float],
    expected: Mapping[str, float],
    name: str,
) -> None:
    """Compare named values when the owning schemas use different stable orders."""
    if set(actual) != set(expected):
        raise ValueError(f"{name} must contain the same parameter names.")
    if any(
        not math.isclose(
            actual[parameter_name],
            expected[parameter_name],
            rel_tol=0.0,
            abs_tol=1e-12,
        )
        for parameter_name in actual
    ):
        raise ValueError(f"{name} does not match recomputed values.")


def _require_text(value: object, name: str) -> None:
    if not isinstance(value, str) or not value.strip() or value != value.strip():
        raise ValueError(f"{name} must be a non-empty trimmed string.")


def _require_digest(value: object, name: str) -> None:
    if not isinstance(value, str) or _DIGEST_PATTERN.fullmatch(value) is None:
        raise ValueError(f"{name} must be a lowercase SHA-256 digest.")


def _require_positive_int(value: object, name: str) -> None:
    if not isinstance(value, int) or isinstance(value, bool) or value <= 0:
        raise ValueError(f"{name} must be a positive integer.")


def _require_non_negative_int(value: object, name: str) -> None:
    if not isinstance(value, int) or isinstance(value, bool) or value < 0:
        raise ValueError(f"{name} must be a non-negative integer.")


def _require_unique_text(
    values: Sequence[object],
    name: str,
    *,
    allow_empty: bool = True,
) -> None:
    if not allow_empty and not values:
        raise ValueError(f"{name} must not be empty.")
    for value in values:
        _require_text(value, name)
    if len(values) != len(set(values)):
        raise ValueError(f"{name} values must be unique.")


def _mapping(value: object, name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{name} must be an object.")
    return value


def _adam_iteration_from_dict(data: Mapping[str, Any]) -> AdamIterationIR:
    """Restore Adam evidence without creating a module-level import cycle."""
    from cascaqit.algorithms.adam import AdamIterationIR

    return AdamIterationIR.from_dict(data)


def _adam_stopping_evidence_from_dict(
    data: Mapping[str, Any],
) -> AdamStoppingEvidenceIR:
    """Restore Adam stopping evidence through its owning module."""
    from cascaqit.algorithms.adam import AdamStoppingEvidenceIR

    return AdamStoppingEvidenceIR.from_dict(data)


def _sequence(value: object, name: str) -> Sequence[Any]:
    if not isinstance(value, (list, tuple)):
        raise TypeError(f"{name} must be an array.")
    return value


def _freeze_mapping(value: Mapping[str, Any]) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError("metadata must be a mapping.")
    return MappingProxyType(
        {str(key): _freeze_value(item) for key, item in value.items()}
    )


def _freeze_value(value: Any) -> Any:
    if isinstance(value, Mapping):
        return _freeze_mapping(value)
    if isinstance(value, (list, tuple)):
        return tuple(_freeze_value(item) for item in value)
    return value


def _json_object(text: str, name: str) -> Mapping[str, Any]:
    data = json.loads(text)
    if not isinstance(data, dict):
        raise TypeError(f"{name} JSON must contain an object.")
    return data
