"""Mock neutral-atom target factory for local MVP tests and examples."""

from __future__ import annotations

import math
from dataclasses import replace

from cascaqit.targets.models import (
    AnalogOperationCapability,
    ChannelCrosstalkCapability,
    ChannelTimingCapability,
    DigitalGateCapability,
    ProgrammableRegion,
    ReadoutCapability,
    TargetCapabilityProfile,
    TargetSpec,
    TimingCapability,
)

__all__ = ["MockNeutralAtomTarget"]


class MockNeutralAtomTarget:
    """Factory for deterministic local neutral-atom target specifications."""

    @staticmethod
    def v0_1() -> TargetSpec:
        """Return the conservative MVP mock target specification."""
        return TargetSpec(
            target_id="mock.neutral_atom.v0_1",
            target_name="MockNeutralAtomTarget v0.1",
            max_atoms=16,
            programmable_region=ProgrammableRegion(
                x_min=-50.0,
                x_max=50.0,
                y_min=-50.0,
                y_max=50.0,
            ),
            min_atom_spacing=3.0,
            time_resolution=0.001,
            rabi_range=(0.0, 20.0),
            detuning_range=(-50.0, 50.0),
            phase_range=(-math.tau, math.tau),
            amplitude_resolution=0.001,
            detuning_resolution=0.001,
            phase_resolution=0.0001,
            supported_waveforms=(
                "constant",
                "linear",
                "piecewise_constant",
                "piecewise_linear",
            ),
            supported_measurement_basis=("ground_rydberg",),
            shots_range=(1, 10000),
            capabilities={
                "analog_ahs": "supported",
                "cloud_submit": "unsupported",
                "digital_circuit": "ir_only",
                "dynamic_atom_movement": "unsupported",
                "global_detuning": "supported",
                "global_phase": "supported",
                "global_rabi": "supported",
                "hardware_submit": "unsupported",
                "hybrid_block": "ir_only",
                "local_detuning": "unsupported",
                "local_rabi": "unsupported",
                "local_rabi_phase_pattern": "unsupported",
                "mid_circuit_measurement": "unsupported",
                "supported_program_types": ["analog", "digital"],
            },
            typed_capabilities=TargetCapabilityProfile(
                analog_operations=(
                    AnalogOperationCapability(
                        operation="global_rydberg_drive",
                        status="supported",
                        addressing=("global",),
                        fields=("rabi", "detuning", "phase"),
                        channel_refs=("control.channels.global_rydberg",),
                    ),
                    AnalogOperationCapability(
                        operation="local_detuning",
                        status="unsupported",
                        addressing=("local",),
                        fields=("detuning",),
                        channel_refs=("control.channels.local_detuning",),
                        metadata={
                            "blocked_reason": "not_lowered_by_phase_107"
                        },
                    ),
                    AnalogOperationCapability(
                        operation="local_rabi",
                        status="unsupported",
                        addressing=("local",),
                        fields=("rabi", "phase", "phase_pattern"),
                        channel_refs=("control.channels.local_rabi",),
                        metadata={"blocked_reason": "local_simulator_only"},
                    ),
                ),
                digital_gates=(
                    DigitalGateCapability(
                        gate="h",
                        status="supported",
                        arity=1,
                        native=False,
                        duration=1.0,
                        duration_unit="gate_index",
                        channel_refs=("control.channels.digital_mock",),
                    ),
                    DigitalGateCapability(
                        gate="x",
                        status="supported",
                        arity=1,
                        native=False,
                        duration=1.0,
                        duration_unit="gate_index",
                        channel_refs=("control.channels.digital_mock",),
                    ),
                    DigitalGateCapability(
                        gate="rx",
                        status="supported",
                        arity=1,
                        native=False,
                        parameter_names=("theta",),
                        duration=1.0,
                        duration_unit="gate_index",
                        channel_refs=("control.channels.digital_mock",),
                    ),
                    DigitalGateCapability(
                        gate="ry",
                        status="supported",
                        arity=1,
                        native=False,
                        parameter_names=("theta",),
                        duration=1.0,
                        duration_unit="gate_index",
                        channel_refs=("control.channels.digital_mock",),
                    ),
                    DigitalGateCapability(
                        gate="rz",
                        status="supported",
                        arity=1,
                        native=False,
                        parameter_names=("theta",),
                        duration=1.0,
                        duration_unit="gate_index",
                        channel_refs=("control.channels.digital_mock",),
                    ),
                    DigitalGateCapability(
                        gate="cx",
                        status="supported",
                        arity=2,
                        native=False,
                        duration=1.0,
                        duration_unit="gate_index",
                        channel_refs=("control.channels.digital_mock",),
                    ),
                ),
                readout=ReadoutCapability(
                    basis=("ground_rydberg", "computational"),
                    status="supported",
                    readout_modes=("counts",),
                    supports_shot_counts=True,
                    supports_per_shot_memory=False,
                    channel_refs=("control.readout.global",),
                ),
                timing=TimingCapability(
                    time_resolution=0.001,
                    min_duration=0.01,
                    max_duration=100.0,
                    alignment=0.001,
                    duration_unit="us",
                ),
                supported_program_types=("analog", "digital"),
                control_refs=(
                    "control.channels.global_rydberg",
                    "control.channels.digital_mock",
                    "control.readout.global",
                ),
                metadata={
                    "execution_scope": "local_mock_only",
                    "hardware_submit": "unsupported",
                    "digital_live_hardware": "unsupported",
                },
            ),
            metadata={
                "blockade_radius": 8.0,
                "coordinate_resolution": 0.001,
                "dimensions": 2,
                "duration_range": [0.01, 100.0],
            },
        )

    @staticmethod
    def v0_2() -> TargetSpec:
        """Return the mock target revision with native PCHIP waveforms."""
        frozen_v0_1 = MockNeutralAtomTarget.v0_1()
        return replace(
            frozen_v0_1,
            target_id="mock.neutral_atom.v0_2",
            target_name="MockNeutralAtomTarget v0.2",
            supported_waveforms=(*frozen_v0_1.supported_waveforms, "interpolated"),
            metadata={
                **frozen_v0_1.metadata,
                "target_revision": "v0.2",
                "interpolation_method": "pchip",
            },
        )

    @staticmethod
    def control_vocabulary_v0_1() -> TargetSpec:
        """Return Raman/DMM declarations without claiming executable support."""
        conservative = MockNeutralAtomTarget.v0_1()
        typed = conservative.typed_capabilities
        assert typed is not None
        return replace(
            conservative,
            target_id="mock.neutral_atom.control_vocabulary.v0_1",
            target_name="MockNeutralAtomTarget Control Vocabulary v0.1",
            capabilities={
                **conservative.capabilities,
                "raman": "unsupported",
                "dmm": "ir_only",
            },
            typed_capabilities=replace(
                typed,
                analog_operations=(
                    *typed.analog_operations,
                    AnalogOperationCapability(
                        operation="raman_drive",
                        status="unsupported",
                        channel_type="raman",
                        addressing=("global",),
                        fields=("rabi", "detuning", "phase"),
                        channel_refs=("control.channels.raman",),
                        metadata={
                            "blocked_reason": "no_physical_definition_or_consumer"
                        },
                    ),
                    AnalogOperationCapability(
                        operation="dmm_detuning",
                        status="ir_only",
                        channel_type="dmm",
                        addressing=("site_pattern_static", "site_mask_static"),
                        fields=("detuning", "pattern", "mask"),
                        channel_refs=("control.channels.dmm",),
                        metadata={"blocked_reason": "no_runtime_consumer"},
                    ),
                ),
                control_refs=(
                    *typed.control_refs,
                    "control.channels.raman",
                    "control.channels.dmm",
                ),
            ),
            metadata={
                **conservative.metadata,
                "control_vocabulary_only": True,
            },
        )

    @staticmethod
    def local_ahs_v0_1() -> TargetSpec:
        """Return an experimental local-simulator-only AHS target profile."""
        conservative = MockNeutralAtomTarget.v0_1()
        typed = conservative.typed_capabilities
        assert typed is not None
        addressing_modes = (
            "site_pattern_static",
            "site_mask_static",
            "site_mask_piecewise",
        )
        analog_operations = tuple(
            replace(
                capability,
                status="experimental",
                addressing=addressing_modes,
                metadata={
                    "execution_scope": "local_simulator_only",
                    "hardware_submit": "unsupported",
                    "cloud_submit": "unsupported",
                    "mask_interpolation": "step",
                },
            )
            if capability.operation in {"local_detuning", "local_rabi"}
            else capability
            for capability in typed.analog_operations
        )
        return replace(
            conservative,
            target_id="mock.neutral_atom.local_ahs.v0_1",
            target_name="MockNeutralAtomTarget Local AHS v0.1",
            capabilities={
                **conservative.capabilities,
                "execution_scope": "local_simulator_only",
                "local_detuning": "experimental",
                "local_detuning_addressing": list(addressing_modes),
                "local_rabi": "experimental",
                "local_rabi_addressing": list(addressing_modes),
                "local_rabi_phase_pattern": "experimental",
                "mask_interpolation": "step",
                "hardware_submit": "unsupported",
                "cloud_submit": "unsupported",
            },
            typed_capabilities=replace(
                typed,
                analog_operations=analog_operations,
                digital_gates=(
                    *typed.digital_gates,
                    DigitalGateCapability(
                        gate="cz",
                        status="supported",
                        arity=2,
                        native=False,
                        duration=1.0,
                        duration_unit="gate_index",
                        channel_refs=("control.channels.digital_mock",),
                        metadata={"execution_scope": "local_simulator_only"},
                    ),
                ),
                control_timing=(
                    ChannelTimingCapability(
                        channel_id="rydberg.detuning.local",
                        concurrency_group="rydberg.local",
                        max_concurrent_operations=2,
                        bandwidth_limit=2.0,
                        bandwidth_unit="MHz",
                        max_slew_rate=30.0,
                        slew_rate_unit="rad/us^2",
                        metadata={"fact_scope": "local_mock"},
                    ),
                    ChannelTimingCapability(
                        channel_id="rydberg.rabi.local",
                        concurrency_group="rydberg.local",
                        max_concurrent_operations=2,
                        bandwidth_limit=2.5,
                        bandwidth_unit="MHz",
                        max_slew_rate=40.0,
                        slew_rate_unit="rad/us^2",
                        metadata={"fact_scope": "local_mock"},
                    ),
                ),
                control_crosstalk=(
                    # This mock deliberately withholds a numeric overlap bound:
                    # a real target would need calibration-backed evidence.
                    ChannelCrosstalkCapability(
                        left_channel_id="rydberg.rabi.local",
                        right_channel_id="rydberg.rabi.global",
                        overlap_policy="calibration_required",
                        time_unit="us",
                        metadata={"fact_scope": "local_mock"},
                    ),
                ),
                control_refs=(
                    *typed.control_refs,
                    "control.channels.local_detuning",
                    "control.channels.local_rabi",
                ),
                metadata={
                    **typed.metadata,
                    "execution_scope": "local_simulator_only",
                    "hardware_submit": "unsupported",
                    "cloud_submit": "unsupported",
                },
            ),
            metadata={
                **conservative.metadata,
                "execution_scope": "local_simulator_only",
            },
        )
