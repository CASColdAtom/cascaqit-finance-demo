"""Unified Target-aware compiler entrypoint for optimization Problems."""

from __future__ import annotations

import hashlib
import math
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field, replace
from typing import TYPE_CHECKING, ClassVar, Literal, Union, cast

from cascaqit.algorithms import (
    AnsatzSpecIR,
    CardinalityPreservingAnsatz,
    HardwareEfficientAnsatz,
    PauliHamiltonian,
    transfer_vqe_parameters,
)
from cascaqit.analog import AHSProgram
from cascaqit.compiler.problem_analog import AnalogProblemLowerer, QAAProtocolIR
from cascaqit.compiler.problem_digital import DigitalProblemLowerer
from cascaqit.compiler.problem_hybrid import HybridDADLowerer
from cascaqit.compiler.problem_mapping import ProblemTermMappingIR
from cascaqit.compiler.problem_vqe import DigitalVQELowerer
from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.digital import Circuit
from cascaqit.exceptions import CapabilityError
from cascaqit.hybrid import HybridProgram
from cascaqit.native_ir.base import stable_json
from cascaqit.parameters import ParameterBindIR, ParameterSchemaIR
from cascaqit.problems.analysis import ProblemAnalysisResult, analyze_problem
from cascaqit.problems.optimization import DEFAULT_MIS_PENALTY, OptimizationProblem
from cascaqit.targets import TargetSpec

if TYPE_CHECKING:
    from cascaqit.algorithms import (
        GradientConfig,
        ObjectiveGradientIR,
        OptimizerConfig,
        PauliMeasurementConfig,
        SampledSelectionConfig,
    )
    from cascaqit.algorithms.execution import ParameterValues
    from cascaqit.problems.execution import ProblemExecutionResult
    from cascaqit.problems.layer_experiment import ProblemLayerExperimentResult
    from cascaqit.problems.repeated_layer_experiment import (
        ProblemRepeatedLayerExperimentResult,
    )
    from cascaqit.results import ResultIR
    from cascaqit.simulators import LocalBackend, NoiseModel, SimulationOptions

__all__ = [
    "ProblemCompileResult",
    "ProblemCompiler",
    "ProblemAHSCompileResult",
    "ProblemDigitalCompileResult",
    "ProblemHybridCompileResult",
]

_MODES = frozenset({"digital", "analog", "hybrid"})
_ALGORITHMS = frozenset({"qaoa", "vqe", "qaa"})
_VALID_COMBINATIONS = {
    "digital": frozenset({"qaoa", "vqe"}),
    "analog": frozenset({"qaa"}),
    "hybrid": frozenset({"qaoa"}),
}


@dataclass(frozen=True)
class ProblemDigitalCompileResult:
    """Digital QAOA or VQE program and the shared facts that produced it."""

    analysis: ProblemAnalysisResult
    program: Circuit
    hamiltonian: PauliHamiltonian
    ansatz: AnsatzSpecIR
    parameter_schema: ParameterSchemaIR
    term_mapping: tuple[ProblemTermMappingIR, ...]
    layers: int
    algorithm: Literal["qaoa", "vqe"] = "qaoa"
    parameter_bind: ParameterBindIR | None = None
    diagnostics: tuple[DiagnosticsIR, ...] = ()
    metadata: dict[str, object] = field(default_factory=dict)

    mode: ClassVar[str] = "digital"
    topology: ClassVar[None] = None
    local_reference: ClassVar[bool] = True
    hardware_executable: ClassVar[bool] = False

    def __post_init__(self) -> None:
        if not isinstance(self.analysis, ProblemAnalysisResult):
            raise TypeError("analysis must be ProblemAnalysisResult.")
        if not isinstance(self.program, Circuit):
            raise TypeError("program must be Circuit.")
        if not isinstance(self.hamiltonian, PauliHamiltonian):
            raise TypeError("hamiltonian must be PauliHamiltonian.")
        if not isinstance(self.ansatz, AnsatzSpecIR):
            raise TypeError("ansatz must be AnsatzSpecIR.")
        if not isinstance(self.parameter_schema, ParameterSchemaIR):
            raise TypeError("parameter_schema must be ParameterSchemaIR.")
        if (
            not isinstance(self.layers, int)
            or isinstance(self.layers, bool)
            or self.layers <= 0
        ):
            raise ValueError("layers must be a positive integer.")
        if self.algorithm not in _VALID_COMBINATIONS[self.mode]:
            raise ValueError("Digital algorithm must be 'qaoa' or 'vqe'.")
        object.__setattr__(self, "term_mapping", tuple(self.term_mapping))
        object.__setattr__(self, "diagnostics", tuple(self.diagnostics))
        object.__setattr__(self, "metadata", dict(self.metadata))
        if self.program.qubits != self.logical_order:
            raise ValueError("Digital program logical order does not match analysis.")
        if self.hamiltonian.logical_order != self.logical_order:
            raise ValueError(
                "Digital Hamiltonian logical order does not match analysis."
            )
        if (
            self.hamiltonian.stable_hash()
            != self.analysis.logical_hamiltonian.pauli_hamiltonian_hash
        ):
            raise ValueError("Digital Hamiltonian does not match shared analysis.")
        if self.ansatz.logical_order != self.logical_order:
            raise ValueError("Digital ansatz logical order does not match analysis.")
        if self.algorithm == "qaoa" and self.ansatz.ansatz_kind != "qaoa":
            raise ValueError("Digital QAOA requires a QAOA ansatz.")
        if self.algorithm == "vqe" and self.ansatz.ansatz_kind not in {
            "hardware_efficient",
            "cardinality_preserving",
            "custom",
        }:
            raise ValueError("Digital VQE requires a VQE ansatz.")
        if self.algorithm == "vqe":
            if self.ansatz.circuit_hash is None or not self.ansatz.definition:
                raise ValueError("Digital VQE requires complete ansatz source facts.")
            if self.ansatz.required_gates != tuple(
                dict.fromkeys(self.program.gate_names)
            ):
                raise ValueError("Digital VQE required gates do not match program.")
            if (
                self.parameter_bind is None
                and self.ansatz.circuit_hash != self.program.structural_hash()
            ):
                raise ValueError("Digital VQE Circuit does not match ansatz hash.")
        parameter_names = tuple(item.name for item in self.parameter_schema.parameters)
        if parameter_names != self.ansatz.parameter_names:
            raise ValueError("Digital parameter schema does not match the ansatz.")
        if (
            tuple(parameter.name for parameter in self.program.parameters)
            != parameter_names
        ):
            raise ValueError(
                "Digital program parameters do not match parameter_schema."
            )
        expected_terms = tuple(
            item.term_id for item in self.analysis.logical_hamiltonian.terms
        )
        actual_terms = tuple(item.logical_term_id for item in self.term_mapping)
        if actual_terms != expected_terms:
            raise ValueError(
                "Digital term mapping does not cover the logical Hamiltonian."
            )
        if any(
            item.implementation != "digital_gate"
            or item.analog_coefficient != 0.0
            or not item.conserved
            for item in self.term_mapping
        ):
            raise ValueError(
                "Digital term mapping must use conserved gate contributions."
            )
        if self.parameter_bind is None:
            if self.program.is_bound:
                raise ValueError(
                    "Unbound compile result cannot contain a bound program."
                )
        else:
            if self.parameter_bind.validate_against(self.parameter_schema):
                raise ValueError("parameter_bind does not match parameter_schema.")
            if not self.program.is_bound:
                raise ValueError("Bound compile result requires a bound program.")

    @property
    def analysis_hash(self) -> str:
        """Return the shared analysis hash referenced by this result."""
        return self.analysis.analysis_hash

    @property
    def problem_hash(self) -> str:
        """Return the source Problem hash."""
        return self.analysis.canonical_problem.problem_hash

    @property
    def logical_order(self) -> tuple[str, ...]:
        """Return the shared logical variable order."""
        return self.analysis.canonical_problem.logical_order

    @property
    def resource_estimate(self) -> dict[str, int]:
        """Return a copy of the shared resource estimate."""
        return dict(self.analysis.mapping_plan.resource_estimate)

    @property
    def compile_hash(self) -> str:
        """Return a deterministic hash of compile-time semantics."""
        payload = {
            "mode": self.mode,
            "algorithm": self.algorithm,
            "analysis_hash": self.analysis_hash,
            "layers": self.layers,
            "hamiltonian_hash": self.hamiltonian.stable_hash(),
            "ansatz": self.ansatz,
            "parameter_schema": self.parameter_schema,
            "term_mapping": self.term_mapping,
            "local_reference": self.local_reference,
            "hardware_executable": self.hardware_executable,
        }
        return hashlib.sha256(stable_json(payload).encode("utf-8")).hexdigest()

    @property
    def is_bound(self) -> bool:
        """Return whether the generated program has concrete parameters."""
        return self.parameter_bind is not None

    def bind(self, values: Mapping[str, float]) -> ProblemDigitalCompileResult:
        """Return an independently bound Digital compile result."""
        if self.is_bound:
            raise ValueError("A bound compile result cannot be rebound.")
        parameter_bind = ParameterBindIR.create(
            parameter_bind_id=f"{self.analysis.analysis_id}.digital.bind",
            parameter_schema=self.parameter_schema,
            values=values,
            metadata={
                "mode": self.mode,
                "algorithm": self.algorithm,
                "compile_hash": self.compile_hash,
            },
        )
        return replace(
            self,
            program=self.program.bind(parameter_bind.values),
            parameter_bind=parameter_bind,
        )

    def run(
        self,
        *,
        params: Mapping[str, float] | None = None,
        shots: int = 1024,
        seed: int | None = 0,
        backend: LocalBackend | None = None,
        noise: NoiseModel | None = None,
        options: SimulationOptions | None = None,
    ) -> ProblemExecutionResult:
        """Bind, execute, and decode this Digital Problem program."""
        from cascaqit.problems.execution import run_compiled_problem

        return run_compiled_problem(
            self,
            params=params,
            shots=shots,
            seed=seed,
            backend=backend,
            noise=noise,
            options=options,
        )

    def evaluate(
        self,
        *,
        params: Mapping[str, float] | None = None,
        seed: int | None = 0,
        backend: LocalBackend | None = None,
        noise: NoiseModel | None = None,
        options: SimulationOptions | None = None,
    ) -> ProblemExecutionResult:
        """Evaluate exact basis probabilities at one Digital parameter point."""
        from cascaqit.problems.execution import evaluate_compiled_problem

        return evaluate_compiled_problem(
            self,
            params=params,
            seed=seed,
            backend=backend,
            noise=noise,
            options=options,
        )

    def gradient(
        self,
        *,
        params: ParameterValues,
        backend: LocalBackend | None = None,
        gradient_index: int = 0,
        objective_evaluation_offset: int = 0,
        max_backend_executions: int | None = None,
        algorithm_run_id: str | None = None,
        seed: int | None = None,
        config: GradientConfig | None = None,
        measurement: PauliMeasurementConfig | None = None,
        noise: NoiseModel | None = None,
        options: SimulationOptions | None = None,
    ) -> ObjectiveGradientIR:
        """Execute one exact or finite-shot Digital parameter-shift gradient."""
        from cascaqit.algorithms.gradient import execute_parameter_shift_gradient

        if self.is_bound:
            raise ValueError("gradient requires an unbound Digital compile result.")
        algorithm_id = self.program.metadata.get("algorithm_id")
        if not isinstance(algorithm_id, str) or not algorithm_id.strip():
            raise ValueError("Digital compile result is missing algorithm_id metadata.")
        parameter_names = tuple(
            parameter.name for parameter in self.parameter_schema.parameters
        )
        return execute_parameter_shift_gradient(
            algorithm_kind=self.algorithm,
            algorithm_id=algorithm_id,
            algorithm_run_id=algorithm_run_id,
            gradient_index=gradient_index,
            objective_evaluation_offset=objective_evaluation_offset,
            max_backend_executions=max_backend_executions,
            circuit=self.program,
            parameter_names=parameter_names,
            parameters=params,
            hamiltonian=self.hamiltonian,
            backend=backend,
            seed=seed,
            config=config,
            measurement=measurement,
            noise=noise,
            options=options,
        )

    def optimize(
        self,
        *,
        parameter_sets: Sequence[Mapping[str, float]] | None = None,
        optimizer: OptimizerConfig | None = None,
        initial_parameters: ParameterValues | None = None,
        shots: int = 0,
        seed: int | None = 0,
        backend: LocalBackend | None = None,
        noise: NoiseModel | None = None,
        options: SimulationOptions | None = None,
        parallel_workers: int | Literal["auto"] = 1,
        measurement: PauliMeasurementConfig | None = None,
        sampled_selection: SampledSelectionConfig | None = None,
    ) -> ProblemExecutionResult:
        """Run exact or finite-shot Digital parameter optimization."""
        from cascaqit.problems.execution import optimize_compiled_problem

        return optimize_compiled_problem(
            self,
            parameter_sets=parameter_sets,
            optimizer=optimizer,
            initial_parameters=initial_parameters,
            shots=shots,
            seed=seed,
            backend=backend,
            noise=noise,
            options=options,
            parallel_workers=parallel_workers,
            measurement=measurement,
            sampled_selection=sampled_selection,
        )

    def decode(self, result: ResultIR) -> ProblemExecutionResult:
        """Decode an external ResultIR with this bound compile result."""
        from cascaqit.problems.execution import (
            build_problem_execution_context,
            decode_problem_result,
        )

        if self.parameter_bind is None:
            raise ValueError("Bind params before decoding a Digital result.")
        return decode_problem_result(
            analysis=self.analysis,
            mode=self.mode,
            algorithm=self.algorithm,
            topology=self.topology,
            compile_hash=self.compile_hash,
            context=build_problem_execution_context(self),
            parameter_bind=self.parameter_bind,
            result=result,
        )


@dataclass(frozen=True)
class ProblemHybridCompileResult:
    """Bound D-A-D program and the shared facts that produced it."""

    analysis: ProblemAnalysisResult
    program: HybridProgram
    parameter_schema: ParameterSchemaIR
    parameter_bind: ParameterBindIR
    term_mapping: tuple[ProblemTermMappingIR, ...]
    layers: int = 1
    diagnostics: tuple[DiagnosticsIR, ...] = ()
    metadata: dict[str, object] = field(default_factory=dict)

    mode: ClassVar[str] = "hybrid"
    algorithm: ClassVar[str] = "qaoa"
    topology: ClassVar[str] = "dad"
    local_reference: ClassVar[bool] = True
    hardware_executable: ClassVar[bool] = False

    def __post_init__(self) -> None:
        if not isinstance(self.analysis, ProblemAnalysisResult):
            raise TypeError("analysis must be ProblemAnalysisResult.")
        if not isinstance(self.program, HybridProgram):
            raise TypeError("program must be HybridProgram.")
        if not isinstance(self.parameter_schema, ParameterSchemaIR):
            raise TypeError("parameter_schema must be ParameterSchemaIR.")
        if not isinstance(self.parameter_bind, ParameterBindIR):
            raise TypeError("parameter_bind must be ParameterBindIR.")
        if (
            not isinstance(self.layers, int)
            or isinstance(self.layers, bool)
            or self.layers <= 0
        ):
            raise ValueError("layers must be a positive integer.")
        object.__setattr__(self, "term_mapping", tuple(self.term_mapping))
        object.__setattr__(self, "diagnostics", tuple(self.diagnostics))
        object.__setattr__(self, "metadata", dict(self.metadata))
        expected_parameter_names = tuple(
            f"gamma_{layer}" for layer in range(self.layers)
        ) + tuple(f"beta_{layer}" for layer in range(self.layers))
        parameter_names = tuple(
            parameter.name for parameter in self.parameter_schema.parameters
        )
        if parameter_names != expected_parameter_names:
            raise ValueError("Hybrid parameter schema does not match QAOA layers.")
        if self.parameter_schema.metadata.get("layers") != self.layers:
            raise ValueError("Hybrid parameter schema does not match layers.")
        if self.parameter_bind.validate_against(self.parameter_schema):
            raise ValueError("parameter_bind does not match parameter_schema.")
        if not self.term_mapping:
            raise ValueError("Hybrid term mapping cannot be empty.")
        if any(not item.conserved for item in self.term_mapping):
            raise ValueError("Hybrid term mapping must conserve every coefficient.")
        if self.analog_contribution_count == 0:
            raise ValueError("Hybrid D-A-D requires a non-empty Analog contribution.")
        logical_term_ids = tuple(
            item.term_id for item in self.analysis.logical_hamiltonian.terms
        )
        mapped_term_ids = tuple(item.logical_term_id for item in self.term_mapping)
        if any(mapped_term_ids.count(term_id) != 1 for term_id in logical_term_ids):
            raise ValueError(
                "Hybrid term mapping must cover every logical term exactly once."
            )
        expected_block_kinds = ("digital",) + (
            "analog",
            "digital",
        ) * self.layers + ("measurement",)
        block_kinds = tuple(block.block_kind for block in self.program.blocks)
        if block_kinds != expected_block_kinds:
            raise ValueError(
                "Hybrid program must use the D-(A-D)^p-measure block order."
            )
        expected_block_names = ("prepare",) + tuple(
            name
            for layer in range(self.layers)
            for name in (f"cost_{layer}", f"residual_mixer_{layer}")
        ) + ("measure",)
        if tuple(block.block_name for block in self.program.blocks) != (
            expected_block_names
        ):
            raise ValueError("Hybrid program block names do not match QAOA layers.")
        for block in self.program.blocks:
            block_order = tuple(
                resource.logical_id for resource in block.logical_resources
            )
            if block_order != self.logical_order:
                raise ValueError(
                    "Hybrid program logical order does not match analysis."
                )
        if self.program.metadata.get("analysis_hash") != self.analysis_hash:
            raise ValueError("Hybrid program does not reference the shared analysis.")
        if self.program.metadata.get("problem_hash") != self.problem_hash:
            raise ValueError("Hybrid program does not reference the source Problem.")
        if self.program.metadata.get("topology") != self.topology:
            raise ValueError("Hybrid program does not declare the D-A-D topology.")
        if self.program.metadata.get("layers") != self.layers:
            raise ValueError("Hybrid program does not match layers.")
        if self.program.metadata.get("parameter_values") != dict(
            self.parameter_bind.values
        ):
            raise ValueError("Hybrid program does not match parameter_bind values.")

    @property
    def analysis_hash(self) -> str:
        """Return the shared analysis hash referenced by this result."""
        return self.analysis.analysis_hash

    @property
    def problem_hash(self) -> str:
        """Return the source Problem hash."""
        return self.analysis.canonical_problem.problem_hash

    @property
    def logical_order(self) -> tuple[str, ...]:
        """Return the shared logical variable order."""
        return self.analysis.canonical_problem.logical_order

    @property
    def resource_estimate(self) -> dict[str, int]:
        """Return a copy of the shared resource estimate."""
        return dict(self.analysis.mapping_plan.resource_estimate)

    @property
    def analog_contribution_count(self) -> int:
        """Return the number of terms implemented wholly or partly in Analog form."""
        tolerance = self.analysis.mapping_plan.absolute_tolerance
        return sum(
            abs(item.analog_coefficient) > tolerance for item in self.term_mapping
        )

    @property
    def compile_hash(self) -> str:
        """Return a deterministic hash independent of parameter binding values."""
        payload = {
            "mode": self.mode,
            "algorithm": self.algorithm,
            "topology": self.topology,
            "analysis_hash": self.analysis_hash,
            "layers": self.layers,
            "parameter_schema": self.parameter_schema,
            "term_mapping": self.term_mapping,
            "local_reference": self.local_reference,
            "hardware_executable": self.hardware_executable,
        }
        return hashlib.sha256(stable_json(payload).encode("utf-8")).hexdigest()

    @property
    def is_bound(self) -> bool:
        """Return true because D-A-D programs are rebuilt for concrete values."""
        return True

    def bind(self, values: Mapping[str, float]) -> ProblemHybridCompileResult:
        """Rebuild the Analog duration and Digital angles for concrete values."""
        program, parameter_bind = HybridDADLowerer().bind(
            self.analysis,
            parameter_schema=self.parameter_schema,
            term_mapping=self.term_mapping,
            values=dict(values),
            layers=self.layers,
        )
        return replace(
            self,
            program=program,
            parameter_bind=parameter_bind,
        )

    def run(
        self,
        *,
        params: Mapping[str, float] | None = None,
        shots: int = 1024,
        seed: int | None = 0,
        backend: LocalBackend | None = None,
        noise: NoiseModel | None = None,
        options: SimulationOptions | None = None,
    ) -> ProblemExecutionResult:
        """Bind, execute, and decode this Hybrid Problem program."""
        from cascaqit.problems.execution import run_compiled_problem

        return run_compiled_problem(
            self,
            params=params,
            shots=shots,
            seed=seed,
            backend=backend,
            noise=noise,
            options=options,
        )

    def evaluate(
        self,
        *,
        params: Mapping[str, float] | None = None,
        seed: int | None = 0,
        backend: LocalBackend | None = None,
        noise: NoiseModel | None = None,
        options: SimulationOptions | None = None,
    ) -> ProblemExecutionResult:
        """Evaluate exact basis probabilities at one Hybrid parameter point."""
        from cascaqit.problems.execution import evaluate_compiled_problem

        return evaluate_compiled_problem(
            self,
            params=params,
            seed=seed,
            backend=backend,
            noise=noise,
            options=options,
        )

    def gradient(
        self,
        *,
        params: ParameterValues,
        backend: LocalBackend | None = None,
        gradient_index: int = 0,
        algorithm_run_id: str | None = None,
        seed: int | None = None,
        config: GradientConfig | None = None,
        noise: NoiseModel | None = None,
        options: SimulationOptions | None = None,
    ) -> ObjectiveGradientIR:
        """Reject gradients for the current Hybrid D-A-D route."""
        _reject_non_digital_noise(
            mode=self.mode,
            algorithm=self.algorithm,
            operation="gradient",
            noise=noise,
        )
        del params, backend, gradient_index, algorithm_run_id, seed, config, options
        raise CapabilityError(
            "Problem gradients are unavailable for Hybrid D-A-D programs.",
            code="PROBLEM_GRADIENT_MODE_UNSUPPORTED",
            stage="optimization",
            object_path="problem.compile.hybrid.gradient",
            metadata={"mode": self.mode, "algorithm": self.algorithm},
        )

    def optimize(
        self,
        *,
        parameter_sets: Sequence[Mapping[str, float]] | None = None,
        optimizer: OptimizerConfig | None = None,
        initial_parameters: ParameterValues | None = None,
        shots: int = 0,
        seed: int | None = 0,
        backend: LocalBackend | None = None,
        noise: NoiseModel | None = None,
        options: SimulationOptions | None = None,
        parallel_workers: int | Literal["auto"] = 1,
    ) -> ProblemExecutionResult:
        """Run discrete or configured Hybrid parameter optimization."""
        from cascaqit.problems.execution import optimize_compiled_problem

        return optimize_compiled_problem(
            self,
            parameter_sets=parameter_sets,
            optimizer=optimizer,
            initial_parameters=initial_parameters,
            shots=shots,
            seed=seed,
            backend=backend,
            noise=noise,
            options=options,
            parallel_workers=parallel_workers,
        )

    def decode(self, result: ResultIR) -> ProblemExecutionResult:
        """Decode an external ResultIR with the shared Problem decoder."""
        from cascaqit.problems.execution import (
            build_problem_execution_context,
            decode_problem_result,
        )

        return decode_problem_result(
            analysis=self.analysis,
            mode=self.mode,
            algorithm=self.algorithm,
            topology=self.topology,
            compile_hash=self.compile_hash,
            context=build_problem_execution_context(self),
            parameter_bind=self.parameter_bind,
            result=result,
        )


@dataclass(frozen=True)
class ProblemAHSCompileResult:
    """Bound QAA program and the shared facts that produced it."""

    analysis: ProblemAnalysisResult
    program: AHSProgram
    protocol: QAAProtocolIR
    parameter_schema: ParameterSchemaIR
    parameter_bind: ParameterBindIR
    term_mapping: tuple[ProblemTermMappingIR, ...]
    target: TargetSpec = field(repr=False, compare=False)
    diagnostics: tuple[DiagnosticsIR, ...] = ()
    metadata: dict[str, object] = field(default_factory=dict)

    mode: ClassVar[str] = "analog"
    algorithm: ClassVar[str] = "qaa"
    topology: ClassVar[None] = None
    local_reference: ClassVar[bool] = True
    hardware_executable: ClassVar[bool] = False

    def __post_init__(self) -> None:
        if not isinstance(self.analysis, ProblemAnalysisResult):
            raise TypeError("analysis must be ProblemAnalysisResult.")
        if not isinstance(self.program, AHSProgram):
            raise TypeError("program must be AHSProgram.")
        if not isinstance(self.protocol, QAAProtocolIR):
            raise TypeError("protocol must be QAAProtocolIR.")
        if not isinstance(self.parameter_schema, ParameterSchemaIR):
            raise TypeError("parameter_schema must be ParameterSchemaIR.")
        if not isinstance(self.parameter_bind, ParameterBindIR):
            raise TypeError("parameter_bind must be ParameterBindIR.")
        if not isinstance(self.target, TargetSpec):
            raise TypeError("target must be TargetSpec.")
        object.__setattr__(self, "term_mapping", tuple(self.term_mapping))
        object.__setattr__(self, "diagnostics", tuple(self.diagnostics))
        object.__setattr__(self, "metadata", dict(self.metadata))
        if self.parameter_bind.validate_against(self.parameter_schema):
            raise ValueError("parameter_bind does not match parameter_schema.")
        parameter_names = tuple(item.name for item in self.parameter_schema.parameters)
        if parameter_names != ("anneal_time", "omega_max"):
            raise ValueError("Analog parameter schema does not match QAA controls.")
        if dict(self.parameter_bind.values) != {
            "anneal_time": self.protocol.anneal_time,
            "omega_max": self.protocol.omega_max,
        }:
            raise ValueError("QAA protocol does not match parameter_bind values.")
        if self.protocol.target_hash != self.analysis.mapping_plan.target_hash:
            raise ValueError("QAA protocol does not reference the analysis Target.")
        if self.target.stable_hash() != self.protocol.target_hash:
            raise ValueError("QAA protocol does not match the retained Target.")
        if self.protocol.metadata.get("analysis_hash") != self.analysis_hash:
            raise ValueError("QAA protocol does not reference the shared analysis.")
        logical_term_ids = tuple(
            item.term_id for item in self.analysis.logical_hamiltonian.terms
        )
        mapped_term_ids = tuple(item.logical_term_id for item in self.term_mapping)
        if mapped_term_ids != logical_term_ids:
            raise ValueError(
                "Analog term mapping must cover every logical term exactly once."
            )
        if any(
            item.digital_coefficient != 0.0
            or item.analog_coefficient != item.logical_coefficient
            or not item.conserved
            for item in self.term_mapping
        ):
            raise ValueError("Analog term mapping cannot use a Digital residual.")
        program_ir = self.program.to_ir()
        if program_ir.register.active_atom_ids != self.logical_order:
            raise ValueError("AHS register logical order does not match analysis.")
        if len(program_ir.measurements) != 1:
            raise ValueError("QAA program requires one terminal measurement.")
        if (
            tuple(name for name, _ in self.protocol.final_detuning)
            != self.logical_order
        ):
            raise ValueError("QAA final detuning order does not match analysis.")
        rabi = program_ir.hamiltonian.rabi
        expected_rabi = (
            0.0,
            self.protocol.omega_max,
            self.protocol.omega_max,
            0.0,
        )
        if rabi.duration != self.protocol.anneal_time or rabi.values != expected_rabi:
            raise ValueError("QAA program Rabi schedule does not match protocol.")
        if program_ir.hamiltonian.phase != self.protocol.phase:
            raise ValueError("QAA program phase does not match protocol.")
        global_detuning = program_ir.hamiltonian.detuning
        if (
            global_detuning.duration != self.protocol.anneal_time
            or global_detuning.values is None
            or global_detuning.values[0] != self.protocol.initial_detuning
        ):
            raise ValueError("QAA program detuning schedule does not match protocol.")
        final_detuning = {
            name: global_detuning.values[-1] for name in self.logical_order
        }
        for term in program_ir.hamiltonian.local_detuning_terms:
            if (
                term.waveform.duration != self.protocol.anneal_time
                or term.waveform.values is None
                or term.waveform.values[0] != 0.0
            ):
                raise ValueError("QAA local detuning does not match protocol.")
            amplitude = term.waveform.values[-1]
            weights = term.addressing.weights[-1]
            for name, weight in zip(self.logical_order, weights):
                final_detuning[name] += amplitude * weight
        tolerance = self.analysis.mapping_plan.absolute_tolerance
        if any(
            not math.isclose(
                final_detuning[name],
                expected,
                abs_tol=tolerance,
                rel_tol=self.analysis.mapping_plan.relative_tolerance,
            )
            for name, expected in self.protocol.final_detuning
        ):
            raise ValueError("QAA program final detuning does not match protocol.")

    @property
    def analysis_hash(self) -> str:
        """Return the shared analysis hash referenced by this result."""
        return self.analysis.analysis_hash

    @property
    def problem_hash(self) -> str:
        """Return the source Problem hash."""
        return self.analysis.canonical_problem.problem_hash

    @property
    def logical_order(self) -> tuple[str, ...]:
        """Return the shared logical variable order."""
        return self.analysis.canonical_problem.logical_order

    @property
    def resource_estimate(self) -> dict[str, int]:
        """Return a copy of the shared resource estimate."""
        return dict(self.analysis.mapping_plan.resource_estimate)

    @property
    def compile_hash(self) -> str:
        """Return a deterministic hash independent of parameter binding values."""
        payload = {
            "mode": self.mode,
            "algorithm": self.algorithm,
            "analysis_hash": self.analysis_hash,
            "parameter_schema": self.parameter_schema,
            "term_mapping": self.term_mapping,
            "schedule": self.protocol.schedule,
            "ramp_fraction": self.protocol.ramp_fraction,
            "initial_detuning": self.protocol.initial_detuning,
            "final_detuning": self.protocol.final_detuning,
            "energy_scale": self.protocol.energy_scale,
            "detuning_implementation": self.protocol.detuning_implementation,
            "target_hash": self.protocol.target_hash,
            "local_reference": self.local_reference,
            "hardware_executable": self.hardware_executable,
        }
        return hashlib.sha256(stable_json(payload).encode("utf-8")).hexdigest()

    @property
    def is_bound(self) -> bool:
        """Return true because QAA waveforms are rebuilt for concrete values."""
        return True

    def bind(self, values: Mapping[str, float]) -> ProblemAHSCompileResult:
        """Rebuild every QAA waveform for concrete protocol values."""
        program, protocol, parameter_bind = AnalogProblemLowerer().bind(
            self.analysis,
            parameter_schema=self.parameter_schema,
            term_mapping=self.term_mapping,
            target_id=self.protocol.target_id,
            target_hash=self.protocol.target_hash,
            target=self.target,
            values=dict(values),
        )
        return replace(
            self,
            program=program,
            protocol=protocol,
            parameter_bind=parameter_bind,
        )

    def run(
        self,
        *,
        params: Mapping[str, float] | None = None,
        shots: int = 1024,
        seed: int | None = 0,
        backend: LocalBackend | None = None,
        noise: NoiseModel | None = None,
        options: SimulationOptions | None = None,
    ) -> ProblemExecutionResult:
        """Bind, execute, and decode this Analog Problem program."""
        from cascaqit.problems.execution import run_compiled_problem

        return run_compiled_problem(
            self,
            params=params,
            shots=shots,
            seed=seed,
            backend=backend,
            noise=noise,
            options=options,
        )

    def evaluate(
        self,
        *,
        params: Mapping[str, float] | None = None,
        seed: int | None = 0,
        backend: LocalBackend | None = None,
        noise: NoiseModel | None = None,
        options: SimulationOptions | None = None,
    ) -> ProblemExecutionResult:
        """Evaluate exact basis probabilities at one Analog parameter point."""
        from cascaqit.problems.execution import evaluate_compiled_problem

        return evaluate_compiled_problem(
            self,
            params=params,
            seed=seed,
            backend=backend,
            noise=noise,
            options=options,
        )

    def gradient(
        self,
        *,
        params: ParameterValues,
        backend: LocalBackend | None = None,
        gradient_index: int = 0,
        algorithm_run_id: str | None = None,
        seed: int | None = None,
        config: GradientConfig | None = None,
        noise: NoiseModel | None = None,
        options: SimulationOptions | None = None,
    ) -> ObjectiveGradientIR:
        """Reject gradients for the current Analog QAA route."""
        _reject_non_digital_noise(
            mode=self.mode,
            algorithm=self.algorithm,
            operation="gradient",
            noise=noise,
        )
        del params, backend, gradient_index, algorithm_run_id, seed, config, options
        raise CapabilityError(
            "Problem gradients are unavailable for Analog QAA programs.",
            code="PROBLEM_GRADIENT_MODE_UNSUPPORTED",
            stage="optimization",
            object_path="problem.compile.analog.gradient",
            metadata={"mode": self.mode, "algorithm": self.algorithm},
        )

    def optimize(
        self,
        *,
        parameter_sets: Sequence[Mapping[str, float]] | None = None,
        optimizer: OptimizerConfig | None = None,
        initial_parameters: ParameterValues | None = None,
        shots: int = 0,
        seed: int | None = 0,
        backend: LocalBackend | None = None,
        noise: NoiseModel | None = None,
        options: SimulationOptions | None = None,
        parallel_workers: int | Literal["auto"] = 1,
    ) -> ProblemExecutionResult:
        """Run discrete or configured Analog parameter optimization."""
        from cascaqit.problems.execution import optimize_compiled_problem

        return optimize_compiled_problem(
            self,
            parameter_sets=parameter_sets,
            optimizer=optimizer,
            initial_parameters=initial_parameters,
            shots=shots,
            seed=seed,
            backend=backend,
            noise=noise,
            options=options,
            parallel_workers=parallel_workers,
        )

    def decode(self, result: ResultIR) -> ProblemExecutionResult:
        """Decode an external ResultIR with the shared Problem decoder."""
        from cascaqit.problems.execution import (
            build_problem_execution_context,
            decode_problem_result,
        )

        return decode_problem_result(
            analysis=self.analysis,
            mode=self.mode,
            algorithm=self.algorithm,
            topology=self.topology,
            compile_hash=self.compile_hash,
            context=build_problem_execution_context(self),
            parameter_bind=self.parameter_bind,
            result=result,
        )


ProblemCompileResult = Union[
    ProblemDigitalCompileResult,
    ProblemHybridCompileResult,
    ProblemAHSCompileResult,
]


@dataclass(frozen=True)
class ProblemCompiler:
    """Analyze once and dispatch to a mode-specific Problem Lowerer."""

    # MIS 与 MWIS 的严格充分阈值不同，两个配置必须沿编译链独立传递。
    mis_penalty: float = DEFAULT_MIS_PENALTY
    mwis_penalty: float | None = None
    absolute_tolerance: float = 1e-8
    relative_tolerance: float = 0.05

    def analyze(
        self,
        problem: OptimizationProblem,
        *,
        target: TargetSpec,
    ) -> ProblemAnalysisResult:
        """Return the shared analysis used by all compile modes."""
        return analyze_problem(
            problem,
            target=target,
            mis_penalty=self.mis_penalty,
            mwis_penalty=self.mwis_penalty,
            absolute_tolerance=self.absolute_tolerance,
            relative_tolerance=self.relative_tolerance,
        )

    def compile(
        self,
        problem: OptimizationProblem,
        *,
        mode: str,
        algorithm: str,
        target: TargetSpec,
        layers: int = 1,
        ansatz: (
            HardwareEfficientAnsatz
            | CardinalityPreservingAnsatz
            | Circuit
            | None
        ) = None,
    ) -> ProblemCompileResult:
        """Compile one Problem through the explicitly selected program family."""
        _validate_mode_algorithm(mode, algorithm)
        _validate_vqe_ansatz_input(mode, algorithm, ansatz)
        if mode in {"digital", "hybrid"} and (
            not isinstance(layers, int) or isinstance(layers, bool) or layers <= 0
        ):
            raise CapabilityError(
                "Variational Problem layers must be a positive integer.",
                code="PROBLEM_TOPOLOGY_UNSUPPORTED",
                stage="compilation",
                object_path=f"problem.compile.{mode}.layers",
                metadata={"mode": mode, "algorithm": algorithm, "layers": layers},
            )
        analysis = self.analyze(problem, target=target)
        return self._compile_analyzed(
            problem,
            analysis=analysis,
            mode=mode,
            algorithm=algorithm,
            target=target,
            layers=layers,
            ansatz=ansatz,
        )

    def optimize_layers(
        self,
        problem: OptimizationProblem,
        *,
        mode: str,
        algorithm: str,
        target: TargetSpec,
        max_layers: int,
        optimizer: OptimizerConfig,
        ansatz: (
            HardwareEfficientAnsatz
            | CardinalityPreservingAnsatz
            | Circuit
            | None
        ) = None,
        min_improvement: float = 0.0,
        patience: int = 1,
        initial_parameters: ParameterValues | None = None,
        shots: int = 0,
        seed: int = 0,
        backend: LocalBackend | None = None,
        noise: NoiseModel | None = None,
        options: SimulationOptions | None = None,
        measurement: PauliMeasurementConfig | None = None,
        sampled_selection: SampledSelectionConfig | None = None,
    ) -> ProblemLayerExperimentResult:
        """Optimize contiguous Ansatz layers with checked early stopping.

        Layer one uses the requested optimizer initialization. Every later layer
        expands the prior selected parameters through the canonical QAOA or
        built-in VQE layer-wise rule. The per-start optimizer budget remains the
        same at every layer; this method does not claim a globally optimal depth.
        """
        from cascaqit.algorithms import (
            OptimizerConfig,
            PauliMeasurementConfig,
            SampledSelectionConfig,
        )
        from cascaqit.problems.layer_experiment import (
            build_problem_layer_experiment_result,
            is_material_layer_improvement,
            problem_layer_objective,
        )
        from cascaqit.simulators import NoiseModel, SimulationOptions

        _validate_mode_algorithm(mode, algorithm)
        _validate_layer_experiment_ansatz_input(
            mode,
            algorithm,
            ansatz,
            repeated=False,
        )
        if mode == "analog" or algorithm == "qaa":
            raise CapabilityError(
                "Automatic layer experiments are unavailable for Analog QAA.",
                code="PROBLEM_LAYER_EXPERIMENT_UNSUPPORTED",
                stage="optimization",
                object_path="problem.optimize_layers",
                metadata={"mode": mode, "algorithm": algorithm},
            )
        sampled_requested = measurement is not None or sampled_selection is not None
        if sampled_requested and (mode != "digital" or algorithm != "vqe"):
            raise CapabilityError(
                "Finite-shot layer experiments require Digital VQE.",
                code="PROBLEM_SAMPLED_LAYER_EXPERIMENT_UNSUPPORTED",
                stage="optimization",
                object_path="problem.optimize_layers",
                metadata={"mode": mode, "algorithm": algorithm},
            )
        if measurement is not None and not isinstance(
            measurement, PauliMeasurementConfig
        ):
            raise TypeError("measurement must be PauliMeasurementConfig or None.")
        if sampled_selection is not None and not isinstance(
            sampled_selection, SampledSelectionConfig
        ):
            raise TypeError(
                "sampled_selection must be SampledSelectionConfig or None."
            )
        if measurement is not None and sampled_selection is None:
            raise ValueError("sampled VQE layer search requires sampled_selection.")
        if sampled_selection is not None and measurement is None:
            raise ValueError("sampled VQE layer search requires measurement.")
        if (
            not isinstance(max_layers, int)
            or isinstance(max_layers, bool)
            or max_layers <= 0
        ):
            raise ValueError("max_layers must be a positive integer.")
        if not isinstance(optimizer, OptimizerConfig):
            raise TypeError("optimizer must be OptimizerConfig.")
        if optimizer.bounds:
            raise ValueError(
                "optimize_layers does not accept fixed optimizer bounds because "
                "the parameter dimension changes by layer."
            )
        if optimizer.initialization != "random":
            raise ValueError(
                "optimize_layers manages later layerwise initialization; "
                "optimizer.initialization must be 'random'."
            )
        if sampled_requested and optimizer.method not in {"SPSA", "ADAM"}:
            raise ValueError("sampled VQE layer search requires SPSA or ADAM.")
        if (
            sampled_requested
            and optimizer.method == "SPSA"
            and optimizer.gradient is not None
        ):
            raise ValueError("sampled VQE SPSA does not accept gradients.")
        if (
            not isinstance(min_improvement, (int, float))
            or isinstance(min_improvement, bool)
            or not math.isfinite(float(min_improvement))
            or float(min_improvement) < 0.0
        ):
            raise ValueError("min_improvement must be a finite non-negative number.")
        if not isinstance(patience, int) or isinstance(patience, bool) or patience <= 0:
            raise ValueError("patience must be a positive integer.")
        if not isinstance(shots, int) or isinstance(shots, bool) or shots < 0:
            raise ValueError("shots must be a non-negative integer.")
        if sampled_requested and shots <= 0:
            raise ValueError("sampled VQE layer search requires positive final shots.")
        if not isinstance(seed, int) or isinstance(seed, bool) or seed < 0:
            raise ValueError("seed must be a non-negative integer.")
        if noise is not None and not isinstance(noise, NoiseModel):
            raise TypeError("noise must be NoiseModel or None.")
        if options is not None and not isinstance(options, SimulationOptions):
            raise TypeError("options must be SimulationOptions or None.")

        # Analyze once so every compiled depth shares the exact canonical Problem,
        # mapping plan, Target snapshot, decoder, and analysis identity.
        analysis = self.analyze(problem, target=target)
        executions: list[ProblemExecutionResult] = []
        selected_execution: ProblemExecutionResult | None = None
        no_improvement_count = 0
        for layers in range(1, max_layers + 1):
            compiled = self._compile_analyzed(
                problem,
                analysis=analysis,
                mode=mode,
                algorithm=algorithm,
                target=target,
                layers=layers,
                ansatz=ansatz,
            )
            layer_optimizer = (
                optimizer
                if layers == 1
                else replace(optimizer, initialization="layerwise")
            )
            if layers == 1:
                layer_initial_parameters = initial_parameters
            elif algorithm == "vqe":
                previous_ansatz = executions[-1].context.ansatz
                current_ansatz = getattr(compiled, "ansatz", None)
                if previous_ansatz is None or current_ansatz is None:
                    raise RuntimeError("VQE layer experiment lost ansatz facts.")
                previous_parameters = executions[-1].parameter_bind.values
                if sampled_requested:
                    previous_optimization = executions[-1].optimization
                    if (
                        previous_optimization is None
                        or previous_optimization.sampled_selection is None
                    ):
                        raise RuntimeError(
                            "Sampled VQE layer search lost confirmation evidence."
                        )
                    selected_index = (
                        previous_optimization.sampled_selection
                        .selected_source_evaluation_index
                    )
                    previous_parameters = previous_optimization.sampled_evaluations[
                        selected_index
                    ].parameter_bind.values
                layer_initial_parameters = transfer_vqe_parameters(
                    previous_ansatz,
                    current_ansatz,
                    previous_parameters,
                )
            else:
                layer_initial_parameters = dict(
                    executions[-1].parameter_bind.values
                )
            if sampled_requested:
                assert measurement is not None
                assert sampled_selection is not None
                if not isinstance(compiled, ProblemDigitalCompileResult):
                    raise RuntimeError(
                        "Sampled VQE layer search produced a non-Digital "
                        "compile result."
                    )
                execution = compiled.optimize(
                    optimizer=layer_optimizer,
                    initial_parameters=layer_initial_parameters,
                    shots=shots,
                    seed=seed,
                    backend=backend,
                    measurement=measurement,
                    sampled_selection=sampled_selection,
                    noise=noise,
                    options=options,
                )
            else:
                execution = compiled.optimize(
                    optimizer=layer_optimizer,
                    initial_parameters=layer_initial_parameters,
                    shots=shots,
                    seed=seed,
                    backend=backend,
                    noise=noise,
                    options=options,
                )
            executions.append(execution)
            if selected_execution is None:
                selected_execution = execution
                continue
            improvement = problem_layer_objective(
                selected_execution
            ) - problem_layer_objective(execution)
            material_improvement = is_material_layer_improvement(
                improvement,
                float(min_improvement),
            )
            if material_improvement:
                selected_execution = execution
                no_improvement_count = 0
            else:
                no_improvement_count += 1
                if no_improvement_count >= patience:
                    break

        return build_problem_layer_experiment_result(
            executions,
            optimizer=optimizer,
            measurement=measurement,
            sampled_selection=sampled_selection,
            max_layers=max_layers,
            min_improvement=float(min_improvement),
            patience=patience,
            requested_shots=shots,
            seed=seed,
        )

    def optimize_layers_repeated(
        self,
        problem: OptimizationProblem,
        *,
        mode: str,
        algorithm: str,
        target: TargetSpec,
        max_layers: int,
        repeats: int,
        optimizer: OptimizerConfig,
        ansatz: (
            HardwareEfficientAnsatz
            | CardinalityPreservingAnsatz
            | Circuit
            | None
        ) = None,
        confidence_level: float = 0.95,
        min_improvement: float = 0.0,
        patience: int = 1,
        shots: int = 0,
        seed: int = 0,
        backend: LocalBackend | None = None,
        noise: NoiseModel | None = None,
        options: SimulationOptions | None = None,
        measurement: PauliMeasurementConfig | None = None,
        sampled_selection: SampledSelectionConfig | None = None,
    ) -> ProblemRepeatedLayerExperimentResult:
        """Select contiguous Ansatz layers from paired optimizer repeats.

        Each repeat is a complete optimizer run with its own derived seed.
        Later layers warm-start only from the same repeat index at the previous
        layer. Selection uses the one-sided Student-t lower confidence bound of
        paired objective improvements and does not claim a globally optimal depth.
        """
        from cascaqit.algorithms import (
            OptimizerConfig,
            PauliMeasurementConfig,
            SampledSelectionConfig,
        )
        from cascaqit.algorithms.optimizer import seeded_initial_point
        from cascaqit.problems.execution import resolve_problem_optimizer_config
        from cascaqit.problems.layer_experiment import (
            PROBLEM_LAYER_OBJECTIVE_TOLERANCE,
        )
        from cascaqit.problems.repeated_layer_experiment import (
            ProblemLayerStatisticsIR,
            ProblemPairedImprovementIR,
            ProblemRepeatedLayerRunIR,
            build_problem_repeated_layer_experiment_result,
            derive_problem_layer_run_seed,
        )
        from cascaqit.simulators import NoiseModel, SimulationOptions

        _validate_mode_algorithm(mode, algorithm)
        _validate_layer_experiment_ansatz_input(
            mode,
            algorithm,
            ansatz,
            repeated=True,
        )
        if mode == "analog" or algorithm == "qaa":
            raise CapabilityError(
                "Repeated layer experiments are unavailable for Analog QAA.",
                code="PROBLEM_REPEATED_LAYER_EXPERIMENT_UNSUPPORTED",
                stage="optimization",
                object_path="problem.optimize_layers_repeated",
                metadata={"mode": mode, "algorithm": algorithm},
            )
        sampled_requested = measurement is not None or sampled_selection is not None
        if sampled_requested and (mode != "digital" or algorithm != "vqe"):
            raise CapabilityError(
                "Finite-shot repeated layer experiments require Digital VQE.",
                code="PROBLEM_SAMPLED_REPEATED_LAYER_EXPERIMENT_UNSUPPORTED",
                stage="optimization",
                object_path="problem.optimize_layers_repeated",
                metadata={"mode": mode, "algorithm": algorithm},
            )
        if measurement is not None and not isinstance(
            measurement, PauliMeasurementConfig
        ):
            raise TypeError("measurement must be PauliMeasurementConfig or None.")
        if sampled_selection is not None and not isinstance(
            sampled_selection, SampledSelectionConfig
        ):
            raise TypeError(
                "sampled_selection must be SampledSelectionConfig or None."
            )
        if measurement is not None and sampled_selection is None:
            raise ValueError(
                "sampled repeated VQE requires sampled_selection to avoid "
                "optimizer-history selection bias."
            )
        if sampled_selection is not None and measurement is None:
            raise ValueError(
                "sampled repeated VQE requires finite-shot measurement."
            )
        if (
            not isinstance(max_layers, int)
            or isinstance(max_layers, bool)
            or max_layers <= 0
        ):
            raise ValueError("max_layers must be a positive integer.")
        if (
            not isinstance(repeats, int)
            or isinstance(repeats, bool)
            or repeats < 2
        ):
            raise ValueError("repeats must be an integer of at least two.")
        if not isinstance(optimizer, OptimizerConfig):
            raise TypeError("optimizer must be OptimizerConfig.")
        if optimizer.seed is not None:
            raise ValueError(
                "optimizer.seed must be None; repeated runs derive their seeds."
            )
        if optimizer.bounds:
            raise ValueError(
                "optimize_layers_repeated does not accept fixed optimizer bounds "
                "because the parameter dimension changes by layer."
            )
        if optimizer.initialization != "random":
            raise ValueError(
                "optimize_layers_repeated manages initialization; "
                "optimizer.initialization must be 'random'."
            )
        if sampled_requested and optimizer.method not in {"SPSA", "ADAM"}:
            raise ValueError("sampled repeated VQE requires SPSA or ADAM.")
        if (
            not isinstance(confidence_level, (int, float))
            or isinstance(confidence_level, bool)
            or not math.isfinite(float(confidence_level))
            or not 0.5 < float(confidence_level) < 1.0
        ):
            raise ValueError(
                "confidence_level must be finite, greater than 0.5 and below 1.0."
            )
        if (
            not isinstance(min_improvement, (int, float))
            or isinstance(min_improvement, bool)
            or not math.isfinite(float(min_improvement))
            or float(min_improvement) < 0.0
        ):
            raise ValueError("min_improvement must be a finite non-negative number.")
        if not isinstance(patience, int) or isinstance(patience, bool) or patience <= 0:
            raise ValueError("patience must be a positive integer.")
        if not isinstance(shots, int) or isinstance(shots, bool) or shots < 0:
            raise ValueError("shots must be a non-negative integer.")
        if sampled_requested and shots <= 0:
            raise ValueError("sampled repeated VQE requires positive final shots.")
        if not isinstance(seed, int) or isinstance(seed, bool) or seed < 0:
            raise ValueError("seed must be a non-negative integer.")
        if noise is not None and not isinstance(noise, NoiseModel):
            raise TypeError("noise must be NoiseModel or None.")
        if options is not None and not isinstance(options, SimulationOptions):
            raise TypeError("options must be SimulationOptions or None.")

        # Analyze and map once. Every layer and repeat therefore shares the same
        # canonical Problem, Target snapshot, decoder and logical ordering.
        analysis = self.analyze(problem, target=target)
        runs_by_layer: list[tuple[ProblemRepeatedLayerRunIR, ...]] = []
        statistics: list[ProblemLayerStatisticsIR] = []
        selected_index = 0
        no_improvement_count = 0
        algorithm_kind = cast(Literal["qaoa", "vqe"], algorithm)
        for layers in range(1, max_layers + 1):
            compiled = self._compile_analyzed(
                problem,
                analysis=analysis,
                mode=mode,
                algorithm=algorithm,
                target=target,
                layers=layers,
                ansatz=ansatz,
            )
            parameter_names = tuple(
                parameter.name for parameter in compiled.parameter_schema.parameters
            )
            resolved_bounds = resolve_problem_optimizer_config(
                compiled,
                optimizer,
            ).bounds
            layer_runs: list[ProblemRepeatedLayerRunIR] = []
            for repeat_index in range(repeats):
                run_seed = derive_problem_layer_run_seed(
                    seed,
                    layers=layers,
                    repeat_index=repeat_index,
                )
                if layers == 1:
                    # compiled.optimize() normally prefers schema defaults. Supplying
                    # a seed-derived explicit point prevents ideal deterministic runs
                    # from collapsing every repeat onto the same first optimization.
                    point = seeded_initial_point(
                        algorithm_kind=algorithm_kind,
                        layers=layers,
                        parameter_count=len(parameter_names),
                        seed=run_seed,
                        bounds=resolved_bounds,
                    )
                    initial_parameters = dict(zip(parameter_names, point))
                    run_optimizer = replace(optimizer, seed=run_seed)
                else:
                    previous_execution = runs_by_layer[-1][repeat_index].execution
                    if algorithm == "vqe":
                        previous_ansatz = previous_execution.context.ansatz
                        current_ansatz = getattr(compiled, "ansatz", None)
                        if previous_ansatz is None or current_ansatz is None:
                            raise RuntimeError(
                                "Repeated VQE layer experiment lost ansatz facts."
                            )
                        initial_parameters = transfer_vqe_parameters(
                            previous_ansatz,
                            current_ansatz,
                            previous_execution.parameter_bind.values,
                        )
                    else:
                        initial_parameters = dict(
                            previous_execution.parameter_bind.values
                        )
                    run_optimizer = replace(
                        optimizer,
                        seed=run_seed,
                        initialization="layerwise",
                    )
                if measurement is None:
                    execution = compiled.optimize(
                        optimizer=run_optimizer,
                        initial_parameters=initial_parameters,
                        shots=shots,
                        seed=run_seed,
                        backend=backend,
                        noise=noise,
                        options=options,
                    )
                else:
                    # The preflight checks above narrow this branch to Digital VQE.
                    # Keeping the call separate avoids leaking Digital-only keyword
                    # arguments into the Analog and Hybrid compile-result APIs.
                    assert sampled_selection is not None
                    assert isinstance(compiled, ProblemDigitalCompileResult)
                    execution = compiled.optimize(
                        optimizer=run_optimizer,
                        initial_parameters=initial_parameters,
                        shots=shots,
                        seed=run_seed,
                        backend=backend,
                        noise=noise,
                        options=options,
                        measurement=measurement,
                        sampled_selection=sampled_selection,
                    )
                layer_runs.append(
                    ProblemRepeatedLayerRunIR.create(
                        layers=layers,
                        repeat_index=repeat_index,
                        seed=run_seed,
                        execution=execution,
                    )
                )
            completed_runs = tuple(layer_runs)
            runs_by_layer.append(completed_runs)
            layer_statistics = ProblemLayerStatisticsIR.create(
                completed_runs,
                confidence_level=float(confidence_level),
            )
            statistics.append(layer_statistics)
            if layers == 1:
                continue
            comparison = ProblemPairedImprovementIR.create(
                statistics[selected_index],
                layer_statistics,
                confidence_level=float(confidence_level),
            )
            lower = comparison.lower_confidence_bound
            material_improvement = (
                lower > PROBLEM_LAYER_OBJECTIVE_TOLERANCE
                and lower >= float(min_improvement)
            )
            if material_improvement:
                selected_index = layers - 1
                no_improvement_count = 0
            else:
                no_improvement_count += 1
                if no_improvement_count >= patience:
                    break

        return build_problem_repeated_layer_experiment_result(
            runs_by_layer,
            optimizer=optimizer,
            max_layers=max_layers,
            repeats=repeats,
            confidence_level=float(confidence_level),
            min_improvement=float(min_improvement),
            patience=patience,
            requested_shots=shots,
            seed=seed,
            measurement=measurement,
            sampled_selection=sampled_selection,
        )

    def _compile_analyzed(
        self,
        problem: OptimizationProblem,
        *,
        analysis: ProblemAnalysisResult,
        mode: str,
        algorithm: str,
        target: TargetSpec,
        layers: int,
        ansatz: (
            HardwareEfficientAnsatz
            | CardinalityPreservingAnsatz
            | Circuit
            | None
        ) = None,
    ) -> ProblemCompileResult:
        """Lower one layer count from an already frozen shared analysis."""
        feasibility = analysis.mapping_plan.feasibility_for(mode)  # type: ignore[arg-type]
        if not feasibility.feasible:
            code = feasibility.diagnostic_codes[0]
            diagnostics = _mode_diagnostics(analysis, mode=mode)
            raise CapabilityError(
                f"Problem cannot be compiled in {mode!r} mode for this Target.",
                code=code,
                stage="compilation",
                object_path=f"problem.compile.{mode}",
                source_hashes={
                    "problem_hash": analysis.canonical_problem.problem_hash,
                    "analysis_hash": analysis.analysis_hash,
                    "target_hash": analysis.mapping_plan.target_hash,
                },
                metadata={
                    "mode": mode,
                    "algorithm": algorithm,
                    "diagnostic_codes": list(feasibility.diagnostic_codes),
                },
                diagnostics=diagnostics,
            )
        if mode == "analog":
            analog = AnalogProblemLowerer().lower(analysis, target=target)
            return ProblemAHSCompileResult(
                analysis=analysis,
                program=analog.program,
                protocol=analog.protocol,
                parameter_schema=analog.parameter_schema,
                parameter_bind=analog.parameter_bind,
                term_mapping=analog.term_mapping,
                target=target,
                metadata={
                    "lowerer": "AnalogProblemLowerer",
                    "target_id": target.target_id,
                },
            )

        if mode == "digital":
            if algorithm == "qaoa":
                qaoa_lowerer = DigitalProblemLowerer()
                artifacts = qaoa_lowerer.lower(
                    problem,
                    analysis=analysis,
                    layers=layers,
                    mis_penalty=self.mis_penalty,
                    mwis_penalty=self.mwis_penalty,
                )
                lowerer_name = type(qaoa_lowerer).__name__
            else:
                vqe_lowerer = DigitalVQELowerer()
                artifacts = vqe_lowerer.lower(
                    problem,
                    analysis=analysis,
                    layers=layers,
                    mis_penalty=self.mis_penalty,
                    mwis_penalty=self.mwis_penalty,
                    ansatz=ansatz,
                    target=target,
                )
                lowerer_name = type(vqe_lowerer).__name__
            return ProblemDigitalCompileResult(
                analysis=analysis,
                program=artifacts.program,
                hamiltonian=artifacts.hamiltonian,
                ansatz=artifacts.ansatz,
                parameter_schema=artifacts.parameter_schema,
                term_mapping=artifacts.term_mapping,
                layers=layers,
                algorithm="qaoa" if algorithm == "qaoa" else "vqe",
                metadata={
                    "lowerer": lowerer_name,
                    "target_id": target.target_id,
                    "ansatz_spec_hash": artifacts.ansatz.spec_hash,
                },
            )

        hybrid = HybridDADLowerer().lower(analysis, layers=layers)
        return ProblemHybridCompileResult(
            analysis=analysis,
            program=hybrid.program,
            parameter_schema=hybrid.parameter_schema,
            parameter_bind=hybrid.parameter_bind,
            term_mapping=hybrid.term_mapping,
            layers=layers,
            metadata={
                "lowerer": "HybridDADLowerer",
                "target_id": target.target_id,
            },
        )


def _validate_mode_algorithm(mode: str, algorithm: str) -> None:
    if mode not in _MODES:
        raise CapabilityError(
            f"Unsupported Problem compile mode: {mode!r}.",
            code="PROBLEM_MODE_UNSUPPORTED",
            stage="compilation",
            object_path="problem.compile.mode",
        )
    if algorithm not in _ALGORITHMS:
        raise CapabilityError(
            f"Unsupported Problem algorithm: {algorithm!r}.",
            code="PROBLEM_ALGORITHM_UNSUPPORTED",
            stage="compilation",
            object_path="problem.compile.algorithm",
        )
    if algorithm not in _VALID_COMBINATIONS[mode]:
        raise CapabilityError(
            f"Mode {mode!r} does not support algorithm {algorithm!r}.",
            code="PROBLEM_MODE_ALGORITHM_MISMATCH",
            stage="compilation",
            object_path="problem.compile",
            metadata={"mode": mode, "algorithm": algorithm},
        )


def _validate_vqe_ansatz_input(
    mode: str,
    algorithm: str,
    ansatz: HardwareEfficientAnsatz | CardinalityPreservingAnsatz | Circuit | None,
) -> None:
    if ansatz is None:
        return
    if not isinstance(
        ansatz,
        (HardwareEfficientAnsatz, CardinalityPreservingAnsatz, Circuit),
    ):
        raise TypeError(
            "ansatz must be HardwareEfficientAnsatz, "
            "CardinalityPreservingAnsatz, Circuit, or None."
        )
    if mode != "digital" or algorithm != "vqe":
        raise CapabilityError(
            "A VQE ansatz is only valid for mode='digital', algorithm='vqe'.",
            code="PROBLEM_VQE_ANSATZ_UNSUPPORTED",
            stage="compilation",
            object_path="problem.compile.ansatz",
            metadata={"mode": mode, "algorithm": algorithm},
        )


def _validate_layer_experiment_ansatz_input(
    mode: str,
    algorithm: str,
    ansatz: HardwareEfficientAnsatz | CardinalityPreservingAnsatz | Circuit | None,
    *,
    repeated: bool,
) -> None:
    _validate_vqe_ansatz_input(mode, algorithm, ansatz)
    if isinstance(ansatz, Circuit):
        entrypoint = (
            "problem.optimize_layers_repeated"
            if repeated
            else "problem.optimize_layers"
        )
        code = (
            "PROBLEM_REPEATED_LAYER_EXPERIMENT_ANSATZ_UNSUPPORTED"
            if repeated
            else "PROBLEM_LAYER_EXPERIMENT_ANSATZ_UNSUPPORTED"
        )
        raise CapabilityError(
            "Automatic layer experiments require a built-in VQE ansatz; "
            "a custom Circuit has no layer-transfer contract.",
            code=code,
            stage="optimization",
            object_path=f"{entrypoint}.ansatz",
            metadata={"mode": mode, "algorithm": algorithm},
        )


def _reject_non_digital_noise(
    *,
    mode: str,
    algorithm: str,
    operation: str,
    noise: object | None,
) -> None:
    """Reject an unsupported noisy Problem route before any Backend submission."""
    if noise is None:
        return
    raise CapabilityError(
        "Problem noise is currently available only for Digital QAOA/VQE.",
        code="PROBLEM_NOISY_MODE_UNSUPPORTED",
        stage="optimization" if operation in {"gradient", "optimize"} else "execution",
        object_path=f"problem.compile.{mode}.{operation}.noise",
        metadata={"mode": mode, "algorithm": algorithm, "operation": operation},
    )


def _mode_diagnostics(
    analysis: ProblemAnalysisResult,
    *,
    mode: str,
) -> tuple[DiagnosticsIR, ...]:
    return tuple(
        item
        for item in analysis.diagnostics
        if mode in item.metadata.get("affected_modes", ())
    )
