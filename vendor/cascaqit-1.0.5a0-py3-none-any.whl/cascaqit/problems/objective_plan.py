"""Request-local objective lookup tables for repeated Problem evaluation."""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Literal, Union

import numpy as np
from numpy.typing import NDArray

from cascaqit.problems.canonical import CanonicalProblemIR
from cascaqit.problems.penalties import (
    ProblemConstraintPenaltyIR,
    ProblemEnergyBreakdownIR,
    ProblemPenaltyAnalysisIR,
    analyze_problem_penalty,
)
from cascaqit.results import ResultIR

__all__ = [
    "ProblemObjectiveEvaluation",
    "ProblemObjectivePlan",
    "build_problem_objective_plan",
]

_DEFAULT_MAX_BYTES = 256 * 1024 * 1024
_PROBABILITY_TOLERANCE = 1e-9
_MAX_VECTOR_CHUNK_STATES = 65_536
_VECTOR_WORKSPACE_BASE_BYTES_PER_STATE = 41
_MAX_REDUCTION_CHUNK_STATES = 65_536

_ObjectiveVector = Union[
    NDArray[np.float64],
    NDArray[np.bool_],
    NDArray[np.int32],
]


def _ordered_probability_chunk(
    probabilities: NDArray[np.float64],
    workspace: NDArray[np.float64],
    previous: float,
) -> float:
    """Continue scalar-order probability addition in one bounded chunk."""
    np.copyto(workspace, probabilities)
    workspace[0] = previous + float(workspace[0])
    np.add.accumulate(workspace, out=workspace)
    return float(workspace[-1])


def _ordered_weighted_chunk(
    probabilities: NDArray[np.float64],
    indices: NDArray[np.intp],
    values: _ObjectiveVector,
    workspace: NDArray[np.float64],
    previous: float,
) -> float:
    """Continue scalar-order weighted addition in one bounded chunk."""
    np.multiply(probabilities, values[indices], out=workspace)
    workspace[0] = previous + float(workspace[0])
    np.add.accumulate(workspace, out=workspace)
    return float(workspace[-1])


@dataclass(frozen=True)
class ProblemObjectiveEvaluation:
    """Scalar evidence reduced from one complete Backend result distribution."""

    objective_value: float
    best_bitstring: str
    feasible_probability: float | None
    expected_constraint_violation_count: float | None
    best_observed_constraint_violation_count: int | None
    expected_selected_weight: float | None
    energy_breakdown: ProblemEnergyBreakdownIR


@dataclass(frozen=True, eq=False)
class ProblemObjectivePlan:
    """Immutable basis-state facts reused within one optimization request."""

    canonical: CanonicalProblemIR
    penalty_analysis: ProblemPenaltyAnalysisIR | None
    total_objectives: NDArray[np.float64]
    canonical_objectives: NDArray[np.float64]
    business_objectives: NDArray[np.float64]
    penalty_activations: tuple[NDArray[np.bool_], ...]
    feasible_mask: NDArray[np.bool_] | None
    violation_counts: NDArray[np.int32] | None
    selected_weights: NDArray[np.float64] | None
    estimated_bytes: int

    @property
    def state_count(self) -> int:
        return int(self.total_objectives.shape[0])

    def evaluate_result(self, result: ResultIR) -> ProblemObjectiveEvaluation:
        """Reduce one validated ResultIR without constructing every candidate."""
        raw_weights = (
            result.probabilities.items()
            if result.probabilities is not None
            else (
                (bitstring, count / result.shots)
                for bitstring, count in result.counts.items()
            )
        )
        weight_count = (
            len(result.probabilities)
            if result.probabilities is not None
            else len(result.counts)
        )
        if weight_count == 0:
            raise ValueError("Result must contain counts or probabilities.")

        width = len(self.canonical.logical_order)
        chunk_capacity = min(weight_count, _MAX_REDUCTION_CHUNK_STATES)
        indices = np.empty(chunk_capacity, dtype=np.intp)
        probabilities = np.empty(chunk_capacity, dtype=np.float64)
        workspace = np.empty(chunk_capacity, dtype=np.float64)
        probability_mass = 0.0
        total = 0.0
        canonical_total = 0.0
        business = 0.0
        feasible_probability = 0.0
        expected_violations = 0.0
        expected_selected_weight = 0.0
        activations = [0.0] * len(self.penalty_activations)
        probability_best_key: tuple[float, int] | None = None

        def reduce_chunk(length: int) -> None:
            nonlocal probability_mass
            nonlocal total
            nonlocal canonical_total
            nonlocal business
            nonlocal feasible_probability
            nonlocal expected_violations
            nonlocal expected_selected_weight
            nonlocal probability_best_key
            chunk_indices = indices[:length]
            chunk_probabilities = probabilities[:length]
            chunk_workspace = workspace[:length]
            probability_mass = _ordered_probability_chunk(
                chunk_probabilities,
                chunk_workspace,
                probability_mass,
            )
            total = _ordered_weighted_chunk(
                chunk_probabilities,
                chunk_indices,
                self.total_objectives,
                chunk_workspace,
                total,
            )
            canonical_total = _ordered_weighted_chunk(
                chunk_probabilities,
                chunk_indices,
                self.canonical_objectives,
                chunk_workspace,
                canonical_total,
            )
            business = _ordered_weighted_chunk(
                chunk_probabilities,
                chunk_indices,
                self.business_objectives,
                chunk_workspace,
                business,
            )
            if self.feasible_mask is not None:
                feasible_probability = _ordered_weighted_chunk(
                    chunk_probabilities,
                    chunk_indices,
                    self.feasible_mask,
                    chunk_workspace,
                    feasible_probability,
                )
                assert self.violation_counts is not None
                expected_violations = _ordered_weighted_chunk(
                    chunk_probabilities,
                    chunk_indices,
                    self.violation_counts,
                    chunk_workspace,
                    expected_violations,
                )
            if self.selected_weights is not None:
                expected_selected_weight = _ordered_weighted_chunk(
                    chunk_probabilities,
                    chunk_indices,
                    self.selected_weights,
                    chunk_workspace,
                    expected_selected_weight,
                )
            for activation_index, vector in enumerate(
                self.penalty_activations
            ):
                activations[activation_index] = _ordered_weighted_chunk(
                    chunk_probabilities,
                    chunk_indices,
                    vector,
                    chunk_workspace,
                    activations[activation_index],
                )
            if not result.counts:
                candidate_indices = chunk_indices[
                    chunk_probabilities > _PROBABILITY_TOLERANCE
                ]
                if candidate_indices.size:
                    candidate_objectives = self.total_objectives[
                        candidate_indices
                    ]
                    best_objective = float(np.min(candidate_objectives))
                    best_index = int(
                        np.min(
                            candidate_indices[
                                candidate_objectives == best_objective
                            ]
                        )
                    )
                    key = (best_objective, best_index)
                    if probability_best_key is None or key < probability_best_key:
                        probability_best_key = key

        chunk_length = 0
        for bitstring, probability in raw_weights:
            if len(bitstring) != width or str.strip(bitstring, "01"):
                raise ValueError(
                    "Result bitstrings must match the Problem logical order."
                )
            normalized = (
                probability if type(probability) is float else float(probability)
            )
            if not math.isfinite(normalized) or normalized < 0.0:
                raise ValueError(
                    "Result probabilities must be finite and non-negative."
                )
            indices[chunk_length] = int(bitstring, 2)
            probabilities[chunk_length] = normalized
            chunk_length += 1
            if chunk_length == chunk_capacity:
                reduce_chunk(chunk_length)
                chunk_length = 0
        if chunk_length:
            reduce_chunk(chunk_length)

        if not math.isclose(
            probability_mass,
            1.0,
            rel_tol=0.0,
            abs_tol=_PROBABILITY_TOLERANCE,
        ):
            raise ValueError("Result probabilities must sum to one.")

        if result.counts:
            candidate_bitstrings = tuple(sorted(result.counts))
            best_bitstring = min(
                candidate_bitstrings,
                key=lambda bitstring: (
                    float(self.total_objectives[int(bitstring, 2)]),
                    bitstring,
                ),
            )
            best_index = int(best_bitstring, 2)
        elif probability_best_key is None:
            raise ValueError(
                "Result probabilities do not contain a non-zero candidate."
            )
        else:
            best_index = probability_best_key[1]
            best_bitstring = format(best_index, f"0{width}b")

        if self.penalty_analysis is None:
            penalties: tuple[ProblemConstraintPenaltyIR, ...] = ()
            penalty_energy = 0.0
            status: Literal["defined", "not_applicable"] = "not_applicable"
        else:
            penalties = tuple(
                ProblemConstraintPenaltyIR(
                    constraint_id=term.constraint_id,
                    canonical_term_id=term.canonical_term_id,
                    targets=term.targets,
                    coefficient=term.coefficient,
                    activation=activations[index],
                    contribution=term.coefficient * activations[index],
                )
                for index, term in enumerate(self.penalty_analysis.penalty_terms)
            )
            penalty_energy = sum(item.contribution for item in penalties)
            status = "defined"
        energy_breakdown = ProblemEnergyBreakdownIR(
            scope="expectation",
            penalty_model_status=status,
            business_objective=business,
            penalty_energy=penalty_energy,
            total_objective=canonical_total,
            constraint_penalties=penalties,
        )
        return ProblemObjectiveEvaluation(
            objective_value=total,
            best_bitstring=best_bitstring,
            feasible_probability=(
                None
                if self.feasible_mask is None
                else min(max(feasible_probability, 0.0), 1.0)
            ),
            expected_constraint_violation_count=(
                None if self.violation_counts is None else expected_violations
            ),
            best_observed_constraint_violation_count=(
                None
                if self.violation_counts is None
                else int(self.violation_counts[best_index])
            ),
            expected_selected_weight=(
                None if self.selected_weights is None else expected_selected_weight
            ),
            energy_breakdown=energy_breakdown,
        )


def build_problem_objective_plan(
    canonical: CanonicalProblemIR,
    *,
    penalty_analysis: ProblemPenaltyAnalysisIR | None,
    max_bytes: int = _DEFAULT_MAX_BYTES,
) -> ProblemObjectivePlan | None:
    """Build immutable lookup tables, or return None before an unsafe allocation."""
    if not isinstance(canonical, CanonicalProblemIR):
        raise TypeError("canonical must be CanonicalProblemIR.")
    if not isinstance(max_bytes, int) or isinstance(max_bytes, bool) or max_bytes <= 0:
        raise ValueError("max_bytes must be a positive integer.")
    expected_penalty_analysis = analyze_problem_penalty(canonical)
    if penalty_analysis != expected_penalty_analysis:
        raise ValueError("penalty_analysis does not match the canonical Problem.")

    variable_count = len(canonical.logical_order)
    state_count = 1 << variable_count
    penalty_count = 0 if penalty_analysis is None else len(
        penalty_analysis.penalty_terms
    )
    constrained = penalty_analysis is not None
    weighted = canonical.decoder.decoder_kind == "mwis"
    bytes_per_state = (
        3 * np.dtype(np.float64).itemsize
        + penalty_count * np.dtype(np.bool_).itemsize
        + (
            np.dtype(np.bool_).itemsize + np.dtype(np.int32).itemsize
            if constrained
            else 0
        )
        + (np.dtype(np.float64).itemsize if weighted else 0)
    )
    estimated_bytes = state_count * bytes_per_state
    if estimated_bytes > max_bytes:
        return None
    workspace_bytes_per_state = (
        variable_count + _VECTOR_WORKSPACE_BASE_BYTES_PER_STATE
    )
    chunk_states = min(
        state_count,
        _MAX_VECTOR_CHUNK_STATES,
        (max_bytes - estimated_bytes) // workspace_bytes_per_state,
    )
    if chunk_states < 1:
        return None

    total_objectives = np.empty(state_count, dtype=np.float64)
    canonical_objectives = np.empty(state_count, dtype=np.float64)
    business_objectives = np.empty(state_count, dtype=np.float64)
    penalty_activations = tuple(
        np.empty(state_count, dtype=np.bool_) for _ in range(penalty_count)
    )
    feasible_mask = (
        np.empty(state_count, dtype=np.bool_) if constrained else None
    )
    violation_counts = (
        np.empty(state_count, dtype=np.int32) if constrained else None
    )
    selected_weights = (
        np.empty(state_count, dtype=np.float64) if weighted else None
    )

    positions = {
        variable: index for index, variable in enumerate(canonical.logical_order)
    }
    linear_terms = tuple(
        (positions[term.variable], term.coefficient)
        for term in canonical.linear_terms
    )
    quadratic_terms = tuple(
        (positions[term.left], positions[term.right], term.coefficient)
        for term in canonical.quadratic_terms
    )
    penalty_terms = (
        ()
        if penalty_analysis is None
        else tuple(
            (positions[term.targets[0]], positions[term.targets[1]])
            for term in penalty_analysis.penalty_terms
        )
    )
    node_weights = tuple(
        (positions[node], weight) for node, weight in canonical.decoder.node_weights
    )

    spin = canonical.variable_domain == "spin"
    for start in range(0, state_count, chunk_states):
        stop = min(start + chunk_states, state_count)
        length = stop - start
        state_indices = np.arange(start, stop, dtype=np.uint64)
        integer_scratch = np.empty(length, dtype=np.uint64)
        raw_bits = np.empty((variable_count, length), dtype=np.bool_)
        for position in range(variable_count):
            shift = variable_count - position - 1
            np.right_shift(state_indices, shift, out=integer_scratch)
            np.bitwise_and(integer_scratch, 1, out=integer_scratch)
            np.copyto(raw_bits[position], integer_scratch, casting="unsafe")

        # Keep the scalar evaluator's per-term addition order. Separate linear and
        # quadratic sums also preserve its canonical-objective grouping.
        linear_sum = np.zeros(length, dtype=np.float64)
        quadratic_sum = np.zeros(length, dtype=np.float64)
        term_values = np.empty(length, dtype=np.float64)
        active = np.empty(length, dtype=np.bool_)
        total = total_objectives[start:stop]
        total.fill(canonical.offset)

        for position, coefficient in linear_terms:
            if spin:
                term_values.fill(-coefficient)
                np.copyto(term_values, coefficient, where=raw_bits[position])
            else:
                term_values.fill(0.0)
                np.copyto(term_values, coefficient, where=raw_bits[position])
            np.add(linear_sum, term_values, out=linear_sum)
            np.add(total, term_values, out=total)

        for left, right, coefficient in quadratic_terms:
            if spin:
                np.equal(raw_bits[left], raw_bits[right], out=active)
                term_values.fill(-coefficient)
                np.copyto(term_values, coefficient, where=active)
            else:
                np.logical_and(raw_bits[left], raw_bits[right], out=active)
                term_values.fill(0.0)
                np.copyto(term_values, coefficient, where=active)
            np.add(quadratic_sum, term_values, out=quadratic_sum)
            np.add(total, term_values, out=total)

        canonical_chunk = canonical_objectives[start:stop]
        np.add(canonical.offset, linear_sum, out=canonical_chunk)
        np.add(canonical_chunk, quadratic_sum, out=canonical_chunk)
        business_chunk = business_objectives[start:stop]
        if constrained:
            np.add(canonical.offset, linear_sum, out=business_chunk)
        else:
            np.copyto(business_chunk, total)

        if constrained:
            assert violation_counts is not None
            assert feasible_mask is not None
            violation_chunk = violation_counts[start:stop]
            violation_chunk.fill(0)
            for penalty_index, (left, right) in enumerate(penalty_terms):
                activation = penalty_activations[penalty_index][start:stop]
                np.logical_and(raw_bits[left], raw_bits[right], out=activation)
                np.add(violation_chunk, activation, out=violation_chunk)
            np.equal(violation_chunk, 0, out=feasible_mask[start:stop])

        if selected_weights is not None:
            selected_chunk = selected_weights[start:stop]
            selected_chunk.fill(0.0)
            for position, weight in node_weights:
                term_values.fill(0.0)
                np.copyto(term_values, weight, where=raw_bits[position])
                np.add(selected_chunk, term_values, out=selected_chunk)
            np.negative(selected_chunk, out=total)
            assert penalty_analysis is not None
            assert violation_counts is not None
            np.multiply(
                violation_counts[start:stop],
                penalty_analysis.penalty_strength,
                out=term_values,
            )
            np.add(total, term_values, out=total)

    arrays = (
        total_objectives,
        canonical_objectives,
        business_objectives,
        *penalty_activations,
        *(() if feasible_mask is None else (feasible_mask,)),
        *(() if violation_counts is None else (violation_counts,)),
        *(() if selected_weights is None else (selected_weights,)),
    )
    for array in arrays:
        array.setflags(write=False)
    return ProblemObjectivePlan(
        canonical=canonical,
        penalty_analysis=penalty_analysis,
        total_objectives=total_objectives,
        canonical_objectives=canonical_objectives,
        business_objectives=business_objectives,
        penalty_activations=penalty_activations,
        feasible_mask=feasible_mask,
        violation_counts=violation_counts,
        selected_weights=selected_weights,
        estimated_bytes=estimated_bytes,
    )
