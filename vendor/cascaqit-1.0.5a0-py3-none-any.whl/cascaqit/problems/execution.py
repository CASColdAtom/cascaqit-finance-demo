"""Unified execution and decoding for compiled optimization Problems."""

from __future__ import annotations

import hashlib
import math
import re
from collections import Counter
from collections.abc import Iterable, Mapping, Sequence
from concurrent.futures import wait
from dataclasses import InitVar, dataclass, field, replace
from os import PathLike
from typing import TYPE_CHECKING, Any, Literal, cast

from cascaqit.algorithms.execution import ParameterValues
from cascaqit.algorithms.gradient import (
    GradientConfig,
    ObjectiveGradientIR,
    ParameterShiftPlanIR,
    build_parameter_shift_plan,
)
from cascaqit.algorithms.measurement import (
    PauliMeasurementConfig,
    SampledObjectiveEvaluationIR,
    execute_sampled_objective_evaluation,
)
from cascaqit.algorithms.models import (
    AlgorithmCandidateIR,
    AnsatzSpecIR,
    CardinalitySubspaceEvidenceIR,
    ClassicalBaselineIR,
    ObjectiveEvaluationIR,
    OptimizationStartIR,
    OptimizerConfig,
    OptimizerTerminationIR,
    PauliHamiltonian,
    SPSAObjectiveEstimateIR,
    build_cardinality_subspace_evidence,
    rank_spsa_source_evaluation_indices,
    validate_adam_start_evidence,
    validate_spsa_start_evidence,
)
from cascaqit.algorithms.noisy_execution import (
    ObjectiveExecutionEvidenceIR,
    build_objective_execution_evidence,
    validate_noisy_variational_request,
)
from cascaqit.algorithms.optimizer import (
    OptimizationStartPlan,
    ScalarOptimizationOutcome,
    aggregate_optimizer_termination,
    build_optimization_start_plans,
    run_scalar_optimization,
    run_variational_optimization,
)
from cascaqit.algorithms.problem_projection import (
    bounded_exhaustive_baseline,
    decode_problem_candidate,
)
from cascaqit.algorithms.sampled_selection import (
    SampledSelectionConfig,
    SampledSelectionIR,
)
from cascaqit.algorithms.sampling import build_final_sampling_circuit
from cascaqit.analog import AHSProgram
from cascaqit.digital import Circuit
from cascaqit.exceptions import CapabilityError
from cascaqit.hybrid import HybridProgram
from cascaqit.native_ir.base import IRMixin, canonicalize, stable_json
from cascaqit.observables import ObservableBatchResultIR
from cascaqit.parameters import ParameterBindIR
from cascaqit.problems.analysis import ProblemAnalysisResult
from cascaqit.problems.canonical import CanonicalProblemIR
from cascaqit.problems.execution_context import (
    ProblemExecutionContextIR,
    ProblemNativeProgramIR,
)
from cascaqit.problems.mis import MISInstance
from cascaqit.problems.models import IsingModelIR, MWISProblemIR, QUBOProblemIR
from cascaqit.problems.objective_plan import (
    ProblemObjectiveEvaluation,
    ProblemObjectivePlan,
    build_problem_objective_plan,
)
from cascaqit.problems.penalties import (
    ProblemEnergyBreakdownIR,
    evaluate_problem_energy_breakdowns,
    expected_problem_energy_breakdown,
)
from cascaqit.results import ResultIR
from cascaqit.simulators import LocalBackend, NoiseModel, SimulationOptions
from cascaqit.simulators.parallel_execution import (
    ParallelExecutionPlanner,
    ParallelExecutionRequest,
    WorkerRequest,
    reusable_process_executor,
)

if TYPE_CHECKING:
    from cascaqit.problems.compiler import (
        ProblemCompileResult,
        ProblemHybridCompileResult,
    )
    from cascaqit.visualization import ExperimentReport

__all__ = [
    "PROBLEM_EXECUTION_SCHEMA_VERSION",
    "ProblemExecutionResult",
    "ProblemExecutionContextIR",
    "ProblemOptimizationIR",
    "ProblemParameterEvaluationIR",
    "build_problem_execution_context",
    "decode_problem_result",
    "evaluate_compiled_problem",
    "optimize_compiled_problem",
    "run_compiled_problem",
]

_ENERGY_ABSOLUTE_TOLERANCE = 1e-12
_ENERGY_RELATIVE_TOLERANCE = 1e-12

PROBLEM_EXECUTION_SCHEMA_VERSION = "cascaqit.problem.execution.v6"
_DIGEST_PATTERN = re.compile(r"[0-9a-f]{64}")
_MODES = frozenset({"digital", "analog", "hybrid"})
_MODE_ALGORITHMS = {
    "digital": frozenset({"qaoa", "vqe"}),
    "analog": frozenset({"qaa"}),
    "hybrid": frozenset({"qaoa"}),
}
_PROBABILITY_TOLERANCE = 1e-9


@dataclass(frozen=True)
class _ProblemEvaluationMetrics:
    """Metrics derived from one complete Problem result distribution."""

    best_observed_candidate: AlgorithmCandidateIR
    feasible_probability: float | None
    expected_constraint_violation_count: float | None
    best_observed_constraint_violation_count: int | None
    expected_selected_weight: float | None
    baseline_objective: float | None
    expected_objective_gap: float | None
    best_observed_objective_gap: float | None


@dataclass(frozen=True)
class _ProblemExecutionRecord:
    """One real Backend execution before the expensive public result projection."""

    bound: ProblemCompileResult
    context: ProblemExecutionContextIR
    parameter_bind: ParameterBindIR
    result: ResultIR
    result_hash: str
    execution_evidence: ObjectiveExecutionEvidenceIR | None
    seed: int | None
    backend_job_id: str
    metadata: dict[str, Any]


@dataclass(frozen=True)
class _ProblemOptimizationFinalization:
    """Validated optimization fields applied during the selected decode."""

    execution_id: str
    parameter_history: tuple[ProblemParameterEvaluationIR, ...]
    selected_evaluation_index: int
    optimization: ProblemOptimizationIR
    metadata: dict[str, Any]


@dataclass(frozen=True)
class _ProblemOptimizationStartResult:
    """One complete optimizer start before global deterministic merging."""

    plan: OptimizationStartPlan
    outcome: ScalarOptimizationOutcome
    parameter_history: tuple[ProblemParameterEvaluationIR, ...]
    objective_evaluations: tuple[ProblemObjectiveEvaluation, ...]
    best_record: _ProblemExecutionRecord | None
    executions: tuple[ProblemExecutionResult, ...]
    gradients: tuple[ObjectiveGradientIR, ...]


@dataclass(frozen=True)
class _ProblemHybridOptimizationStartTask:
    """Immutable input for one spawn-safe Hybrid optimizer start."""

    compiled: dict[str, Any]
    objective_plan: ProblemObjectivePlan | None
    plan: dict[str, Any]
    optimizer: dict[str, Any]
    parameter_names: tuple[str, ...]
    effective_shots: int
    run_hash: str
    backend: dict[str, Any]
    noise: dict[str, Any] | None
    options: dict[str, Any] | None


@dataclass(frozen=True)
class ProblemParameterEvaluationIR(IRMixin):
    """Evidence that one concrete parameter point was executed."""

    evaluation_index: int
    parameter_bind: ParameterBindIR
    result_id: str
    result_hash: str
    source_program_hash: str
    program_hash: str
    objective_value: float
    shots: int
    seed: int | None
    best_observed_candidate: AlgorithmCandidateIR
    feasible_probability: float | None
    expected_constraint_violation_count: float | None
    best_observed_constraint_violation_count: int | None
    expected_selected_weight: float | None
    baseline_objective: float | None
    expected_objective_gap: float | None
    best_observed_objective_gap: float | None
    energy_breakdown: ProblemEnergyBreakdownIR
    execution_evidence: ObjectiveExecutionEvidenceIR | None = None
    backend_job_id: str | None = None
    schema_version: str = PROBLEM_EXECUTION_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_execution_schema(self.schema_version)
        if (
            not isinstance(self.evaluation_index, int)
            or isinstance(self.evaluation_index, bool)
            or self.evaluation_index < 0
        ):
            raise ValueError("evaluation_index must be a non-negative integer.")
        if not isinstance(self.parameter_bind, ParameterBindIR):
            raise TypeError("parameter_bind must be ParameterBindIR.")
        if not self.parameter_bind.verify_hash():
            raise ValueError("parameter_bind hash does not match its values.")
        _require_text(self.result_id, "result_id")
        _require_digest(self.result_hash, "result_hash")
        _require_digest(self.source_program_hash, "source_program_hash")
        _require_digest(self.program_hash, "program_hash")
        object.__setattr__(
            self,
            "objective_value",
            _finite(self.objective_value, "objective_value"),
        )
        _non_negative_int(self.shots, "shots")
        _optional_seed(self.seed)
        if not isinstance(self.best_observed_candidate, AlgorithmCandidateIR):
            raise TypeError("best_observed_candidate must be AlgorithmCandidateIR.")
        if self.feasible_probability is None:
            if any(
                value is not None
                for value in (
                    self.expected_constraint_violation_count,
                    self.best_observed_constraint_violation_count,
                )
            ):
                raise ValueError(
                    "constraint metrics must all be None when feasibility is undefined."
                )
            if self.best_observed_candidate.feasible is not None:
                raise ValueError(
                    "undefined feasible_probability requires candidate "
                    "feasibility None."
                )
        else:
            feasible_probability = _finite(
                self.feasible_probability,
                "feasible_probability",
            )
            if not 0.0 <= feasible_probability <= 1.0:
                raise ValueError("feasible_probability must be within [0, 1].")
            object.__setattr__(
                self,
                "feasible_probability",
                feasible_probability,
            )
            if self.expected_constraint_violation_count is None or (
                self.best_observed_constraint_violation_count is None
            ):
                raise ValueError(
                    "constraint metrics are required when feasibility is defined."
                )
            expected_violations = _finite(
                self.expected_constraint_violation_count,
                "expected_constraint_violation_count",
            )
            if expected_violations < 0.0:
                raise ValueError(
                    "expected_constraint_violation_count must be non-negative."
                )
            object.__setattr__(
                self,
                "expected_constraint_violation_count",
                expected_violations,
            )
            _non_negative_int(
                self.best_observed_constraint_violation_count,
                "best_observed_constraint_violation_count",
            )
            if self.best_observed_candidate.feasible is None:
                raise ValueError(
                    "defined feasible_probability requires candidate feasibility."
                )

        candidate_problem_type = self.best_observed_candidate.decoded.get(
            "problem_type"
        )
        if self.expected_selected_weight is None:
            if candidate_problem_type == "mwis":
                raise ValueError(
                    "MWIS parameter evaluations require expected_selected_weight."
                )
        else:
            selected_weight = _finite(
                self.expected_selected_weight,
                "expected_selected_weight",
            )
            if selected_weight < 0.0:
                raise ValueError("expected_selected_weight must be non-negative.")
            if candidate_problem_type != "mwis":
                raise ValueError(
                    "expected_selected_weight is defined only for MWIS results."
                )
            object.__setattr__(
                self,
                "expected_selected_weight",
                selected_weight,
            )

        baseline_metrics = (
            self.baseline_objective,
            self.expected_objective_gap,
            self.best_observed_objective_gap,
        )
        if all(value is None for value in baseline_metrics):
            pass
        elif any(value is None for value in baseline_metrics):
            raise ValueError("baseline metrics must all be present or all be None.")
        else:
            baseline = _finite(self.baseline_objective, "baseline_objective")
            expected_gap = _finite(
                self.expected_objective_gap,
                "expected_objective_gap",
            )
            best_gap = _finite(
                self.best_observed_objective_gap,
                "best_observed_objective_gap",
            )
            if not math.isclose(
                expected_gap,
                self.objective_value - baseline,
                rel_tol=_ENERGY_RELATIVE_TOLERANCE,
                abs_tol=_ENERGY_ABSOLUTE_TOLERANCE,
            ):
                raise ValueError(
                    "expected_objective_gap must equal objective minus baseline."
                )
            if not math.isclose(
                best_gap,
                self.best_observed_candidate.objective_value - baseline,
                rel_tol=_ENERGY_RELATIVE_TOLERANCE,
                abs_tol=_ENERGY_ABSOLUTE_TOLERANCE,
            ):
                raise ValueError(
                    "best_observed_objective_gap must equal candidate minus baseline."
                )
            object.__setattr__(self, "baseline_objective", baseline)
            object.__setattr__(self, "expected_objective_gap", expected_gap)
            object.__setattr__(self, "best_observed_objective_gap", best_gap)
        if not isinstance(self.energy_breakdown, ProblemEnergyBreakdownIR):
            raise TypeError("energy_breakdown must be ProblemEnergyBreakdownIR.")
        if self.energy_breakdown.scope != "expectation":
            raise ValueError("parameter evaluation requires an expectation breakdown.")
        if not math.isclose(
            self.energy_breakdown.total_objective,
            self.objective_value,
            rel_tol=_ENERGY_RELATIVE_TOLERANCE,
            abs_tol=_ENERGY_ABSOLUTE_TOLERANCE,
        ):
            raise ValueError(
                "energy breakdown total must match the parameter objective."
            )
        if self.backend_job_id is not None:
            _require_text(self.backend_job_id, "backend_job_id")
        if self.execution_evidence is not None:
            evidence = self.execution_evidence
            if not isinstance(evidence, ObjectiveExecutionEvidenceIR):
                raise TypeError(
                    "execution_evidence must be ObjectiveExecutionEvidenceIR or None."
                )
            if evidence.result_id != self.result_id:
                raise ValueError("execution evidence result_id does not match result.")
            if evidence.result_hash != self.result_hash:
                raise ValueError(
                    "execution evidence result_hash does not match result."
                )
            if evidence.metadata.get("program_hash") != self.program_hash:
                raise ValueError(
                    "execution evidence program_hash does not match result."
                )
            if evidence.backend_shots != self.shots:
                raise ValueError("execution evidence shots do not match result.")
            if evidence.effective_seed != self.seed:
                raise ValueError("execution evidence seed does not match result.")
            if self.backend_job_id != evidence.backend_job_id:
                raise ValueError(
                    "execution evidence Backend Job does not match result."
                )

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ProblemParameterEvaluationIR:
        """Restore one parameter evaluation from JSON-compatible data."""
        return cls(
            evaluation_index=int(data["evaluation_index"]),
            parameter_bind=ParameterBindIR.from_dict(
                _mapping(data["parameter_bind"], "parameter_bind")
            ),
            result_id=str(data["result_id"]),
            result_hash=str(data["result_hash"]),
            source_program_hash=str(data["source_program_hash"]),
            program_hash=str(data["program_hash"]),
            objective_value=float(data["objective_value"]),
            shots=int(data["shots"]),
            seed=None if data.get("seed") is None else int(data["seed"]),
            best_observed_candidate=AlgorithmCandidateIR.from_dict(
                _mapping(
                    data["best_observed_candidate"],
                    "best_observed_candidate",
                )
            ),
            feasible_probability=data["feasible_probability"],
            expected_constraint_violation_count=data[
                "expected_constraint_violation_count"
            ],
            best_observed_constraint_violation_count=data[
                "best_observed_constraint_violation_count"
            ],
            expected_selected_weight=data.get("expected_selected_weight"),
            baseline_objective=data["baseline_objective"],
            expected_objective_gap=data["expected_objective_gap"],
            best_observed_objective_gap=data["best_observed_objective_gap"],
            energy_breakdown=ProblemEnergyBreakdownIR.from_dict(
                _mapping(data["energy_breakdown"], "energy_breakdown")
            ),
            execution_evidence=(
                None
                if data.get("execution_evidence") is None
                else ObjectiveExecutionEvidenceIR.from_dict(
                    _mapping(data["execution_evidence"], "execution_evidence")
                )
            ),
            backend_job_id=(
                None
                if data.get("backend_job_id") is None
                else str(data["backend_job_id"])
            ),
            schema_version=str(
                data.get("schema_version", PROBLEM_EXECUTION_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> ProblemParameterEvaluationIR:
        """Restore one parameter evaluation from JSON text."""
        import json

        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("ProblemParameterEvaluationIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class ProblemOptimizationIR(IRMixin):
    """Typed search configuration and termination facts for one optimization."""

    optimization_id: str
    search_kind: Literal["parameter_sets", "optimizer"]
    evaluation_count: int
    best_evaluation_index: int
    optimizer: OptimizerConfig | None = None
    initial_parameters: Mapping[str, float] | None = None
    final_parameters: Mapping[str, float] | None = None
    final_objective: float | None = None
    termination: OptimizerTerminationIR | None = None
    starts: tuple[OptimizationStartIR, ...] = ()
    selected_start_index: int | None = None
    gradients: tuple[ObjectiveGradientIR, ...] = ()
    sampled_evaluations: tuple[SampledObjectiveEvaluationIR, ...] = ()
    sampled_selection: SampledSelectionIR | None = None
    schema_version: str = PROBLEM_EXECUTION_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_execution_schema(self.schema_version)
        _require_text(self.optimization_id, "optimization_id")
        if self.search_kind not in {"parameter_sets", "optimizer"}:
            raise ValueError(f"Unsupported search_kind: {self.search_kind!r}.")
        if (
            not isinstance(self.evaluation_count, int)
            or isinstance(self.evaluation_count, bool)
            or self.evaluation_count <= 0
        ):
            raise ValueError("evaluation_count must be a positive integer.")
        if (
            not isinstance(self.best_evaluation_index, int)
            or isinstance(self.best_evaluation_index, bool)
            or not 0 <= self.best_evaluation_index < self.evaluation_count
        ):
            raise ValueError("best_evaluation_index is outside the evaluation count.")

        if self.search_kind == "parameter_sets":
            if any(
                value is not None
                for value in (
                    self.optimizer,
                    self.initial_parameters,
                    self.final_parameters,
                    self.final_objective,
                    self.termination,
                    self.selected_start_index,
                )
            ):
                raise ValueError(
                    "parameter_sets optimization cannot contain optimizer fields."
                )
            if self.starts:
                raise ValueError(
                    "parameter_sets optimization cannot contain optimizer starts."
                )
            if self.gradients:
                raise ValueError(
                    "parameter_sets optimization cannot contain gradient history."
                )
            if self.sampled_evaluations or self.sampled_selection is not None:
                raise ValueError(
                    "parameter_sets optimization cannot contain sampled VQE evidence."
                )
            return

        if not isinstance(self.optimizer, OptimizerConfig):
            raise TypeError("optimizer search requires OptimizerConfig.")
        if not isinstance(self.termination, OptimizerTerminationIR):
            raise TypeError("optimizer search requires termination evidence.")
        if self.termination.nfev != self.evaluation_count:
            raise ValueError("termination nfev must match evaluation_count.")
        if not isinstance(self.gradients, tuple):
            object.__setattr__(self, "gradients", tuple(self.gradients))
        if any(not isinstance(item, ObjectiveGradientIR) for item in self.gradients):
            raise TypeError("gradients must contain ObjectiveGradientIR values.")
        if tuple(item.gradient_index for item in self.gradients) != tuple(
            range(len(self.gradients))
        ):
            raise ValueError("gradient indices must be contiguous and zero-based.")
        if self.optimizer.gradient is None and self.gradients:
            raise ValueError("gradient history requires optimizer GradientConfig.")
        if self.optimizer.gradient is not None and not self.gradients:
            raise ValueError("gradient optimizer requires gradient history.")
        if self.termination.njev != len(self.gradients):
            raise ValueError("termination njev must match gradient history.")
        if not isinstance(self.sampled_evaluations, tuple):
            object.__setattr__(
                self,
                "sampled_evaluations",
                tuple(self.sampled_evaluations),
            )
        if any(
            not isinstance(item, SampledObjectiveEvaluationIR)
            for item in self.sampled_evaluations
        ):
            raise TypeError(
                "sampled_evaluations must contain SampledObjectiveEvaluationIR values."
            )
        if self.sampled_evaluations:
            _validate_problem_sampled_optimization(self)
            expected_backend_count = sum(
                item.backend_execution_count for item in self.sampled_evaluations
            ) + sum(item.backend_execution_count for item in self.gradients)
        else:
            if self.sampled_selection is not None:
                raise ValueError("sampled_selection requires sampled_evaluations.")
            expected_backend_count = self.evaluation_count + sum(
                item.backend_execution_count for item in self.gradients
            )
        if self.termination.backend_execution_count != expected_backend_count:
            raise ValueError(
                "termination Backend cost must match objective and gradient evidence."
            )
        if self.gradients and len({item.plan_hash for item in self.gradients}) != 1:
            raise ValueError("all gradients must share one parameter-shift plan.")
        if not isinstance(self.starts, tuple):
            object.__setattr__(self, "starts", tuple(self.starts))
        if any(not isinstance(item, OptimizationStartIR) for item in self.starts):
            raise TypeError("starts must contain OptimizationStartIR values.")
        if self.starts:
            if len(self.starts) != self.optimizer.starts:
                raise ValueError("starts must match optimizer starts.")
            if tuple(item.start_index for item in self.starts) != tuple(
                range(len(self.starts))
            ):
                raise ValueError("start indices must be contiguous and zero-based.")
            expected_start = 0
            expected_gradient_start = 0
            for start in self.starts:
                validate_adam_start_evidence(start, self.optimizer)
                validate_spsa_start_evidence(start, self.optimizer)
                if start.evaluation_start_index != expected_start:
                    raise ValueError("starts must cover contiguous evaluation slices.")
                expected_start += start.evaluation_count
                if start.gradient_start_index != expected_gradient_start:
                    raise ValueError("starts must cover contiguous gradient slices.")
                expected_gradient_start += start.gradient_count
            if expected_start != self.evaluation_count:
                raise ValueError("starts must cover every evaluation exactly once.")
            if expected_gradient_start != len(self.gradients):
                raise ValueError("starts must cover every gradient exactly once.")
            if sum(start.backend_execution_count or 0 for start in self.starts) != (
                self.termination.backend_execution_count
            ):
                raise ValueError("start Backend costs must match termination evidence.")
            if (
                not isinstance(self.selected_start_index, int)
                or isinstance(self.selected_start_index, bool)
                or not 0 <= self.selected_start_index < len(self.starts)
            ):
                raise ValueError("selected_start_index is outside starts.")
            if (
                self.starts[self.selected_start_index].best_evaluation_index
                != self.best_evaluation_index
            ):
                raise ValueError("selected start must own the best evaluation.")
        elif self.selected_start_index is not None:
            raise ValueError("selected_start_index requires starts.")
        initial = _finite_parameter_mapping(
            self.initial_parameters,
            "initial_parameters",
        )
        final = _finite_parameter_mapping(
            self.final_parameters,
            "final_parameters",
        )
        if not initial or initial.keys() != final.keys():
            raise ValueError(
                "initial_parameters and final_parameters must share non-empty keys."
            )
        object.__setattr__(self, "initial_parameters", initial)
        object.__setattr__(self, "final_parameters", final)
        if self.final_objective is None:
            raise ValueError("optimizer search requires final_objective.")
        object.__setattr__(
            self,
            "final_objective",
            _finite(self.final_objective, "final_objective"),
        )
        if self.starts:
            assert self.selected_start_index is not None
            selected_start = self.starts[self.selected_start_index]
            if initial != selected_start.initial_parameters:
                raise ValueError(
                    "initial_parameters must match the selected optimizer start."
                )
            if final != selected_start.final_parameters:
                raise ValueError(
                    "final_parameters must match the selected optimizer start."
                )
            if not math.isclose(
                self.final_objective,
                selected_start.final_objective,
                rel_tol=_ENERGY_RELATIVE_TOLERANCE,
                abs_tol=_ENERGY_ABSOLUTE_TOLERANCE,
            ):
                raise ValueError(
                    "final_objective must match the selected optimizer start."
                )

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ProblemOptimizationIR:
        """Restore one optimization summary from JSON-compatible data."""
        return cls(
            optimization_id=str(data["optimization_id"]),
            search_kind=data["search_kind"],
            evaluation_count=int(data["evaluation_count"]),
            best_evaluation_index=int(data["best_evaluation_index"]),
            optimizer=(
                None
                if data.get("optimizer") is None
                else OptimizerConfig.from_dict(_mapping(data["optimizer"], "optimizer"))
            ),
            initial_parameters=(
                None
                if data.get("initial_parameters") is None
                else _finite_parameter_mapping(
                    data["initial_parameters"], "initial_parameters"
                )
            ),
            final_parameters=(
                None
                if data.get("final_parameters") is None
                else _finite_parameter_mapping(
                    data["final_parameters"], "final_parameters"
                )
            ),
            final_objective=(
                None
                if data.get("final_objective") is None
                else float(data["final_objective"])
            ),
            termination=(
                None
                if data.get("termination") is None
                else OptimizerTerminationIR.from_dict(
                    _mapping(data["termination"], "termination")
                )
            ),
            starts=tuple(
                OptimizationStartIR.from_dict(_mapping(item, "optimization_start"))
                for item in data.get("starts", ())
            ),
            selected_start_index=data.get("selected_start_index"),
            gradients=tuple(
                ObjectiveGradientIR.from_dict(_mapping(item, "gradient"))
                for item in data.get("gradients", ())
            ),
            sampled_evaluations=tuple(
                SampledObjectiveEvaluationIR.from_dict(
                    _mapping(item, "sampled_evaluation")
                )
                for item in data.get("sampled_evaluations", ())
            ),
            sampled_selection=(
                None
                if data.get("sampled_selection") is None
                else SampledSelectionIR.from_dict(
                    _mapping(data["sampled_selection"], "sampled_selection")
                )
            ),
            schema_version=str(
                data.get("schema_version", PROBLEM_EXECUTION_SCHEMA_VERSION)
            ),
        )

    @property
    def selected_objective_evaluation_index(self) -> int:
        """Return the objective point used for final Problem sampling."""
        if self.sampled_selection is not None:
            return self.sampled_selection.selected_source_evaluation_index
        return self.best_evaluation_index


def _validate_problem_sampled_optimization(
    optimization: ProblemOptimizationIR,
) -> None:
    """Recompute finite-shot VQE history and confirmation linkage.

    Sampled Pauli Jobs estimate Hamiltonian energy but do not contain a complete
    computational-basis distribution. They therefore belong to the optimization
    summary rather than ``ProblemExecutionResult.parameter_history``.
    """
    evaluations = optimization.sampled_evaluations
    optimizer = optimization.optimizer
    termination = optimization.termination
    assert optimizer is not None
    assert termination is not None
    if optimizer.method not in {"SPSA", "ADAM"}:
        raise ValueError("sampled Problem VQE optimization requires SPSA or ADAM.")
    if optimizer.method == "SPSA" and (
        optimizer.gradient is not None or optimization.gradients
    ):
        raise ValueError("sampled Problem SPSA cannot contain gradients.")
    if optimizer.method == "ADAM" and not optimization.gradients:
        raise ValueError("sampled Problem ADAM requires gradient evidence.")
    if len(evaluations) != optimization.evaluation_count:
        raise ValueError(
            "sampled evaluation count must match optimization evaluation_count."
        )
    if tuple(item.evaluation_index for item in evaluations) != tuple(
        range(len(evaluations))
    ):
        raise ValueError(
            "sampled evaluation indices must be contiguous and zero-based."
        )
    expected_best = min(
        optimization.starts,
        key=lambda item: (item.best_objective, item.best_evaluation_index),
    ).best_evaluation_index
    if optimization.best_evaluation_index != expected_best:
        raise ValueError(
            "best_evaluation_index must minimize sampled objective history."
        )
    first = evaluations[0]
    first_context = (
        first.noise_model,
        first.requested_options,
        first.simulation_method,
        first.backend_id,
    )
    parameter_names = tuple(first.parameter_bind.values)
    for evaluation in evaluations:
        if evaluation.plan != first.plan:
            raise ValueError("sampled evaluations must share one measurement plan.")
        if tuple(evaluation.parameter_bind.values) != parameter_names:
            raise ValueError("sampled evaluations must share one parameter schema.")
        if (
            evaluation.noise_model,
            evaluation.requested_options,
            evaluation.simulation_method,
            evaluation.backend_id,
        ) != first_context:
            raise ValueError("sampled evaluations must share one execution context.")

    selection = optimization.sampled_selection
    if selection is not None:
        if not isinstance(selection, SampledSelectionIR):
            raise TypeError("sampled_selection must be SampledSelectionIR or None.")
        if selection.evaluation_start_index != len(evaluations):
            raise ValueError(
                "sampled selection must start after optimizer evaluations."
            )
        ranked = (
            tuple(
                evaluations[index]
                for index in rank_spsa_source_evaluation_indices(optimization.starts)
            )
            if optimizer.method == "SPSA"
            else tuple(
                sorted(
                    evaluations,
                    key=lambda item: (item.energy, item.evaluation_index),
                )
            )
        )
        expected_sources: list[int] = []
        seen_bindings: set[str] = set()
        for evaluation in ranked:
            bind_hash = evaluation.parameter_bind.parameter_bind_hash
            if bind_hash in seen_bindings:
                continue
            seen_bindings.add(bind_hash)
            expected_sources.append(evaluation.evaluation_index)
            if len(expected_sources) == selection.config.candidate_count:
                break
        actual_sources = [
            candidate.source_evaluation_index for candidate in selection.candidates
        ]
        if actual_sources != expected_sources:
            raise ValueError(
                "sampled selection candidates must match ranked distinct optimizer "
                "points."
            )
        for candidate in selection.candidates:
            source = evaluations[candidate.source_evaluation_index]
            if candidate.source_evaluation_id != source.evaluation_id or (
                candidate.source_parameter_bind_hash
                != source.parameter_bind.parameter_bind_hash
            ):
                raise ValueError(
                    "sampled selection source must match optimizer history."
                )
            source_context = (
                source.noise_model,
                source.requested_options,
                source.simulation_method,
                source.backend_id,
            )
            if any(
                (
                    evaluation.noise_model,
                    evaluation.requested_options,
                    evaluation.simulation_method,
                    evaluation.backend_id,
                )
                != source_context
                for evaluation in candidate.evaluations
            ):
                raise ValueError(
                    "sampled confirmation context must match optimizer history."
                )

    for start in optimization.starts:
        history = evaluations[
            start.evaluation_start_index : start.evaluation_start_index
            + start.evaluation_count
        ]
        if not history:
            raise ValueError("optimizer start must own sampled evaluations.")
        if start.termination.method == "ADAM":
            start_gradients = optimization.gradients[
                start.gradient_start_index : start.gradient_start_index
                + start.gradient_count
            ]
            for iteration, gradient in zip(
                start.adam_iterations,
                start_gradients,
            ):
                if iteration.gradient_hash != gradient.gradient_hash:
                    raise ValueError(
                        "ADAM iteration gradient must match sampled Problem history."
                    )
                center = history[iteration.iteration_index]
                updated = history[iteration.iteration_index + 1]
                if dict(center.parameter_bind.values) != dict(
                    iteration.center_parameters
                ) or dict(updated.parameter_bind.values) != dict(
                    iteration.updated_parameters
                ):
                    raise ValueError(
                        "ADAM parameters must match sampled Problem history."
                    )
            continue
        assert start.spsa_initial_estimate is not None
        assert start.spsa_final_estimate is not None
        estimates = (
            start.spsa_initial_estimate,
            *(
                estimate
                for iteration in start.spsa_iterations
                for direction in iteration.directions
                for estimate in (direction.plus_estimate, direction.minus_estimate)
            ),
            start.spsa_final_estimate,
        )
        parameter_sets = (
            start.initial_parameters,
            *(
                parameters
                for iteration in start.spsa_iterations
                for direction in iteration.directions
                for parameters in (
                    direction.plus_parameters,
                    direction.minus_parameters,
                )
            ),
            start.final_parameters,
        )
        for estimate, expected_parameters in zip(estimates, parameter_sets):
            _validate_problem_spsa_estimate(
                estimate,
                history,
                expected_parameters,
            )
        local_best = min(
            estimates,
            key=lambda item: (
                item.pooled_objective,
                item.source_evaluation_offset,
            ),
        )
        if (
            start.best_evaluation_index
            != start.evaluation_start_index + local_best.source_evaluation_offset
            or not math.isclose(
                start.best_objective,
                local_best.pooled_objective,
                rel_tol=_ENERGY_RELATIVE_TOLERANCE,
                abs_tol=_ENERGY_ABSOLUTE_TOLERANCE,
            )
        ):
            raise ValueError("optimizer start best point must match pooled estimates.")


def _validate_problem_spsa_estimate(
    estimate: SPSAObjectiveEstimateIR,
    history: tuple[SampledObjectiveEvaluationIR, ...],
    expected_parameters: Mapping[str, float],
) -> None:
    """Match one pooled SPSA estimate to sampled Problem history."""
    for offset, expected_objective in zip(
        estimate.evaluation_offsets,
        estimate.objective_values,
    ):
        evaluation = history[offset]
        if dict(evaluation.parameter_bind.values) != dict(expected_parameters):
            raise ValueError("SPSA estimate parameters must match sampled history.")
        if not math.isclose(
            evaluation.energy,
            expected_objective,
            rel_tol=_ENERGY_RELATIVE_TOLERANCE,
            abs_tol=_ENERGY_ABSOLUTE_TOLERANCE,
        ):
            raise ValueError("SPSA estimate objectives must match sampled history.")


def _digital_evidence_context(
    evidence: ObjectiveExecutionEvidenceIR,
) -> tuple[object, object, str, object, object]:
    """Return the facts that must stay invariant across one optimization."""
    return (
        evidence.noise_model,
        evidence.requested_options,
        evidence.simulation_plan.method_selected,
        evidence.estimator_kind,
        evidence.source_kind,
    )


def _validate_problem_digital_evidence(
    history: tuple[ProblemParameterEvaluationIR, ...],
) -> None:
    """Keep every Backend-produced Digital objective in one execution context."""
    executed = tuple(
        item.execution_evidence
        for item in history
        if item.execution_evidence is not None
    )
    if not executed:
        return
    reference = _digital_evidence_context(executed[0])
    if any(_digital_evidence_context(item) != reference for item in executed[1:]):
        raise ValueError(
            "Digital parameter history mixes incompatible execution evidence."
        )


def _validate_problem_gradient_evidence(
    history: tuple[ProblemParameterEvaluationIR, ...],
    gradients: tuple[ObjectiveGradientIR, ...],
    *,
    sampled_history: tuple[SampledObjectiveEvaluationIR, ...] = (),
) -> None:
    """Require objective and parameter-shift Jobs to use one noise context."""
    if not gradients:
        return
    if sampled_history:
        source = sampled_history[0]
        expected = _sampled_problem_runtime_context(source)
        for gradient in gradients:
            for repeat in gradient.repeats:
                for pair in repeat.shift_pairs:
                    for evaluation in (
                        pair.positive_evaluation,
                        pair.negative_evaluation,
                    ):
                        if not isinstance(evaluation, SampledObjectiveEvaluationIR):
                            raise ValueError(
                                "sampled Problem gradients require sampled objectives."
                            )
                        if _sampled_problem_runtime_context(evaluation) != expected:
                            raise ValueError(
                                "Problem objective and gradient use incompatible "
                                "sampled execution evidence."
                            )
        return
    objective_evidence = history[0].execution_evidence
    if objective_evidence is None:
        raise ValueError("Problem gradients require Digital execution evidence.")
    expected = _digital_evidence_context(objective_evidence)
    for gradient in gradients:
        for repeat in gradient.repeats:
            for pair in repeat.shift_pairs:
                for evaluation in (
                    pair.positive_evaluation,
                    pair.negative_evaluation,
                ):
                    if not isinstance(evaluation, ObjectiveEvaluationIR):
                        raise ValueError(
                            "Problem gradients currently require exact objective "
                            "evidence."
                        )
                    if (
                        _digital_evidence_context(evaluation.execution_evidence)
                        != expected
                    ):
                        raise ValueError(
                            "Problem objective and gradient use incompatible "
                            "execution evidence."
                        )


def _sampled_problem_runtime_context(
    evaluation: SampledObjectiveEvaluationIR,
) -> tuple[object, ...]:
    """Return sampled facts invariant across center and shifted objectives."""
    evidence = evaluation.all_group_results[0].execution_evidence
    return (
        evaluation.plan.config,
        evaluation.plan.hamiltonian_hash,
        evaluation.plan.logical_order,
        evaluation.noise_model,
        evaluation.requested_options,
        evaluation.simulation_method,
        evaluation.estimator_kind,
        evidence.source_kind,
        evaluation.backend_id,
    )


def _validate_problem_exact_start_history(
    history: tuple[ProblemParameterEvaluationIR, ...],
    starts: tuple[OptimizationStartIR, ...],
) -> None:
    """Validate optimizer-start slices against complete Problem evaluations."""
    for start in starts:
        start_history = history[
            start.evaluation_start_index : start.evaluation_start_index
            + start.evaluation_count
        ]
        if any(item.seed != start.seed for item in start_history):
            raise ValueError("optimizer start seed does not match parameter_history.")
        if dict(start_history[0].parameter_bind.values) != dict(
            start.initial_parameters
        ):
            raise ValueError(
                "optimizer start initial parameters do not match parameter_history."
            )
        local_best = min(
            start_history,
            key=lambda item: (item.objective_value, item.evaluation_index),
        )
        if start.best_evaluation_index != local_best.evaluation_index:
            raise ValueError(
                "optimizer start best index does not match parameter_history."
            )
        if not math.isclose(
            start.best_objective,
            local_best.objective_value,
            rel_tol=_ENERGY_RELATIVE_TOLERANCE,
            abs_tol=_ENERGY_ABSOLUTE_TOLERANCE,
        ):
            raise ValueError(
                "optimizer start best objective does not match parameter_history."
            )
        if start.termination.method == "ADAM":
            if dict(start_history[-1].parameter_bind.values) != dict(
                start.final_parameters
            ):
                raise ValueError(
                    "ADAM final parameters do not match parameter_history."
                )
            if not math.isclose(
                start_history[-1].objective_value,
                start.final_objective,
                rel_tol=_ENERGY_RELATIVE_TOLERANCE,
                abs_tol=_ENERGY_ABSOLUTE_TOLERANCE,
            ):
                raise ValueError(
                    "ADAM final objective does not match parameter_history."
                )
            for iteration in start.adam_iterations:
                center = start_history[iteration.iteration_index]
                updated = start_history[iteration.iteration_index + 1]
                if dict(center.parameter_bind.values) != dict(
                    iteration.center_parameters
                ) or dict(updated.parameter_bind.values) != dict(
                    iteration.updated_parameters
                ):
                    raise ValueError(
                        "ADAM parameters do not match Problem parameter_history."
                    )
            continue
        if start.termination.method != "SPSA":
            continue
        if dict(start_history[-1].parameter_bind.values) != dict(
            start.final_parameters
        ):
            raise ValueError("SPSA final parameters do not match parameter_history.")
        if not math.isclose(
            start_history[-1].objective_value,
            start.final_objective,
            rel_tol=_ENERGY_RELATIVE_TOLERANCE,
            abs_tol=_ENERGY_ABSOLUTE_TOLERANCE,
        ):
            raise ValueError("SPSA final objective does not match parameter_history.")
        for spsa_iteration in start.spsa_iterations:
            for direction in spsa_iteration.directions:
                plus = start_history[direction.plus_evaluation_offset]
                minus = start_history[direction.minus_evaluation_offset]
                if dict(plus.parameter_bind.values) != dict(
                    direction.plus_parameters
                ) or dict(minus.parameter_bind.values) != dict(
                    direction.minus_parameters
                ):
                    raise ValueError(
                        "SPSA perturbation parameters do not match parameter_history."
                    )
                if not math.isclose(
                    plus.objective_value,
                    direction.plus_objective,
                    rel_tol=_ENERGY_RELATIVE_TOLERANCE,
                    abs_tol=_ENERGY_ABSOLUTE_TOLERANCE,
                ) or not math.isclose(
                    minus.objective_value,
                    direction.minus_objective,
                    rel_tol=_ENERGY_RELATIVE_TOLERANCE,
                    abs_tol=_ENERGY_ABSOLUTE_TOLERANCE,
                ):
                    raise ValueError(
                        "SPSA perturbation objectives do not match parameter_history."
                    )


def _validate_problem_sampled_execution(execution: ProblemExecutionResult) -> None:
    """Link sampled VQE optimization evidence to its final decoded sampling Job."""
    optimization = execution.optimization
    assert optimization is not None
    evaluations = optimization.sampled_evaluations
    if execution.mode != "digital" or execution.algorithm != "vqe":
        raise ValueError("sampled objective history is available only for Digital VQE.")
    if (
        len(execution.parameter_history) != 1
        or execution.selected_evaluation_index != 0
    ):
        raise ValueError(
            "sampled VQE keeps exactly one final decoded parameter evaluation."
        )
    expected_hamiltonian_hash = (
        execution.context.analysis.logical_hamiltonian.pauli_hamiltonian_hash
    )
    ansatz = execution.context.ansatz
    if ansatz is None or ansatz.circuit_hash is None:
        raise ValueError("sampled VQE execution requires complete ansatz source facts.")
    expected_parameter_names = tuple(
        item.name for item in execution.context.parameter_schema.parameters
    )
    for evaluation in evaluations:
        if evaluation.plan.hamiltonian_hash != expected_hamiltonian_hash:
            raise ValueError(
                "sampled measurement Hamiltonian does not match Problem analysis."
            )
        if evaluation.plan.logical_order != execution.logical_order:
            raise ValueError(
                "sampled measurement logical order does not match Problem."
            )
        if evaluation.plan.source_circuit_hash != ansatz.circuit_hash:
            raise ValueError("sampled measurement source does not match VQE ansatz.")
        if set(evaluation.parameter_bind.values) != set(expected_parameter_names):
            raise ValueError(
                "sampled objective parameters do not match Problem parameter schema."
            )

    selected = evaluations[optimization.selected_objective_evaluation_index]
    if selected.parameter_bind != execution.parameter_bind:
        raise ValueError(
            "final Problem sampling binding must match the selected sampled objective."
        )
    final_sampling = execution.metadata.get("final_sampling")
    if not isinstance(final_sampling, Mapping):
        raise ValueError("sampled VQE result is missing final_sampling evidence.")
    if final_sampling.get("source_evaluation_id") != selected.evaluation_id or (
        final_sampling.get("source_parameter_bind_hash")
        != selected.parameter_bind.parameter_bind_hash
    ):
        raise ValueError(
            "final sampling source must match the selected sampled objective."
        )
    if final_sampling.get("source_measurement_plan_hash") != selected.plan.plan_hash:
        raise ValueError("final sampling measurement source does not match selection.")
    if tuple(final_sampling.get("source_execution_evidence_hashes", ())) != (
        selected.execution_evidence_hashes
    ):
        raise ValueError("final sampling evidence does not match sampled groups.")
    selected_noise_hash = (
        None if selected.noise_model is None else selected.noise_model.stable_hash()
    )
    if final_sampling.get("noise_model_hash") != selected_noise_hash:
        raise ValueError("final sampling NoiseModel does not match sampled objective.")
    selected_options_hash = (
        None
        if selected.requested_options is None
        else selected.requested_options.stable_hash()
    )
    if final_sampling.get("requested_options_hash") != selected_options_hash:
        raise ValueError("final sampling options do not match sampled objective.")


def _uses_noisy_sampled_runtime_wrapper(execution: ProblemExecutionResult) -> bool:
    """Return whether typed sampled evidence permits an internal noise wrapper."""
    optimization = execution.optimization
    if not isinstance(optimization, ProblemOptimizationIR):
        return False
    evaluations = optimization.sampled_evaluations
    if not evaluations:
        return False
    selected = evaluations[optimization.selected_objective_evaluation_index]
    return selected.noise_model is not None


@dataclass(frozen=True)
class ProblemExecutionResult(IRMixin):
    """One decoded execution with source, binding, and sampling evidence."""

    execution_id: str
    mode: Literal["digital", "analog", "hybrid"]
    algorithm: Literal["qaoa", "vqe", "qaa"]
    topology: str | None
    compile_hash: str
    analysis_hash: str
    problem_hash: str
    logical_order: tuple[str, ...]
    context: ProblemExecutionContextIR
    parameter_bind: ParameterBindIR
    parameter_bind_hash: str
    result: ResultIR
    candidates: tuple[AlgorithmCandidateIR, ...]
    most_probable_candidate: AlgorithmCandidateIR
    best_observed_candidate: AlgorithmCandidateIR
    objective_value: float
    feasibility: bool | None
    constraint_violations: tuple[str, ...]
    candidate_energy_breakdowns: tuple[ProblemEnergyBreakdownIR, ...]
    parameter_history: tuple[ProblemParameterEvaluationIR, ...]
    selected_evaluation_index: int
    cardinality_subspace: CardinalitySubspaceEvidenceIR | None = None
    optimization: ProblemOptimizationIR | None = None
    baseline: ClassicalBaselineIR | None = None
    optimality_claim: Literal["not_claimed"] = "not_claimed"
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = PROBLEM_EXECUTION_SCHEMA_VERSION
    _objective_evaluation: InitVar[ProblemObjectiveEvaluation | None] = None

    def __post_init__(
        self,
        _objective_evaluation: ProblemObjectiveEvaluation | None,
    ) -> None:
        _require_execution_schema(self.schema_version)
        _require_text(self.execution_id, "execution_id")
        if self.mode not in _MODES:
            raise ValueError(f"Unsupported Problem execution mode: {self.mode!r}.")
        if self.algorithm not in _MODE_ALGORITHMS[self.mode]:
            raise ValueError("mode and algorithm do not form a supported combination.")
        if self.mode == "hybrid" and self.topology != "dad":
            raise ValueError("Hybrid execution requires topology='dad'.")
        if self.mode != "hybrid" and self.topology is not None:
            raise ValueError("Only Hybrid execution may declare a topology.")
        for name in ("compile_hash", "analysis_hash", "problem_hash"):
            _require_digest(getattr(self, name), name)
        object.__setattr__(self, "logical_order", tuple(self.logical_order))
        _require_unique_text(self.logical_order, "logical_order")
        if not isinstance(self.context, ProblemExecutionContextIR):
            raise TypeError("context must be ProblemExecutionContextIR.")
        if self.context.mode != self.mode or self.context.algorithm != self.algorithm:
            raise ValueError("context mode and algorithm do not match execution.")
        if self.context.topology != self.topology:
            raise ValueError("context topology does not match execution.")
        if self.context.compile_hash != self.compile_hash:
            raise ValueError("context compile_hash does not match execution.")
        if self.context.analysis_hash != self.analysis_hash:
            raise ValueError("context analysis_hash does not match execution.")
        if self.context.problem_hash != self.problem_hash:
            raise ValueError("context problem_hash does not match execution.")
        if self.context.analysis.canonical_problem.logical_order != self.logical_order:
            raise ValueError("context logical order does not match execution.")
        if not isinstance(self.parameter_bind, ParameterBindIR):
            raise TypeError("parameter_bind must be ParameterBindIR.")
        _require_digest(self.parameter_bind_hash, "parameter_bind_hash")
        if self.parameter_bind_hash != self.parameter_bind.parameter_bind_hash:
            raise ValueError("parameter_bind_hash does not match parameter_bind.")
        if not isinstance(self.result, ResultIR):
            raise TypeError("result must be ResultIR.")
        canonical = self.context.analysis.canonical_problem
        _validate_result(self.result, logical_order=canonical.logical_order)
        expected_cardinality = (
            None
            if self.context.ansatz is None
            else build_cardinality_subspace_evidence(
                self.context.ansatz,
                self.result,
            )
        )
        if self.cardinality_subspace != expected_cardinality:
            raise ValueError(
                "cardinality_subspace must match the Ansatz and execution Result."
            )
        object.__setattr__(self, "candidates", tuple(self.candidates))
        if not self.candidates or any(
            not isinstance(item, AlgorithmCandidateIR) for item in self.candidates
        ):
            raise ValueError(
                "candidates must contain decoded AlgorithmCandidateIR values."
            )
        bitstrings = tuple(item.bitstring for item in self.candidates)
        if len(bitstrings) != len(set(bitstrings)):
            raise ValueError("candidate bitstrings must be unique.")
        if self.candidates != tuple(sorted(self.candidates, key=_candidate_rank)):
            raise ValueError("candidates must use stable count/probability order.")
        expected_candidates = _decode_result_candidates(canonical, self.result)
        if self.candidates != expected_candidates:
            raise ValueError(
                "decoded candidates do not match the original Result evidence."
            )
        if self.most_probable_candidate != self.candidates[0]:
            raise ValueError("most_probable_candidate must be the first candidate.")
        expected_best = min(
            self.candidates,
            key=lambda item: (item.objective_value, item.bitstring),
        )
        if self.best_observed_candidate != expected_best:
            raise ValueError(
                "best_observed_candidate must minimize observed objective."
            )
        objective = _finite(self.objective_value, "objective_value")
        object.__setattr__(self, "objective_value", objective)
        if self.feasibility != self.best_observed_candidate.feasible:
            raise ValueError("feasibility must describe best_observed_candidate.")
        object.__setattr__(
            self,
            "constraint_violations",
            tuple(self.constraint_violations),
        )
        _require_unique_text(
            self.constraint_violations,
            "constraint_violations",
            allow_empty=True,
        )
        if (self.feasibility is False) != bool(self.constraint_violations):
            raise ValueError("constraint_violations must agree with infeasible status.")
        expected_violations = _constraint_violations(
            canonical,
            self.best_observed_candidate.bitstring,
        )
        if self.constraint_violations != expected_violations:
            raise ValueError(
                "constraint_violations do not match the canonical Problem."
            )
        object.__setattr__(
            self,
            "candidate_energy_breakdowns",
            tuple(self.candidate_energy_breakdowns),
        )
        if any(
            not isinstance(item, ProblemEnergyBreakdownIR)
            for item in self.candidate_energy_breakdowns
        ):
            raise TypeError(
                "candidate_energy_breakdowns must contain ProblemEnergyBreakdownIR."
            )
        if (
            tuple(item.bitstring for item in self.candidate_energy_breakdowns)
            != bitstrings
        ):
            raise ValueError(
                "candidate energy breakdowns must align with decoded candidates."
            )
        expected_candidate_breakdowns = evaluate_problem_energy_breakdowns(
            self.context.analysis.canonical_problem,
            (candidate.bitstring for candidate in self.candidates),
            penalty_analysis=self.context.analysis.penalty_analysis,
        )
        if self.candidate_energy_breakdowns != expected_candidate_breakdowns:
            raise ValueError(
                "candidate energy breakdowns do not match the canonical Problem."
            )
        if any(
            not math.isclose(
                breakdown.total_objective,
                candidate.objective_value,
                rel_tol=_ENERGY_RELATIVE_TOLERANCE,
                abs_tol=_ENERGY_ABSOLUTE_TOLERANCE,
            )
            for candidate, breakdown in zip(
                self.candidates,
                self.candidate_energy_breakdowns,
            )
        ):
            raise ValueError("candidate energy totals do not match decoded objectives.")
        object.__setattr__(self, "parameter_history", tuple(self.parameter_history))
        if not self.parameter_history or any(
            not isinstance(item, ProblemParameterEvaluationIR)
            for item in self.parameter_history
        ):
            raise ValueError("parameter_history must contain real evaluations.")
        if self.mode == "digital":
            if any(
                item.backend_job_id is not None and item.execution_evidence is None
                for item in self.parameter_history
            ):
                raise ValueError(
                    "executed Digital parameter history requires execution evidence."
                )
            _validate_problem_digital_evidence(self.parameter_history)
        elif any(
            item.execution_evidence is not None for item in self.parameter_history
        ):
            raise ValueError(
                "Analog and Hybrid parameter history cannot contain Digital "
                "execution evidence."
            )
        indices = tuple(item.evaluation_index for item in self.parameter_history)
        if indices != tuple(range(len(self.parameter_history))):
            raise ValueError(
                "parameter_history indices must be contiguous and zero-based."
            )
        if (
            not isinstance(self.selected_evaluation_index, int)
            or isinstance(self.selected_evaluation_index, bool)
            or not 0 <= self.selected_evaluation_index < len(self.parameter_history)
        ):
            raise ValueError("selected_evaluation_index is outside parameter_history.")
        selected = self.parameter_history[self.selected_evaluation_index]
        expected_selected = min(
            self.parameter_history,
            key=lambda item: (item.objective_value, item.evaluation_index),
        ).evaluation_index
        if self.selected_evaluation_index != expected_selected:
            raise ValueError(
                "selected_evaluation_index must minimize the parameter history."
            )
        # 带噪 Backend 会把源 Circuit 包装为内部 Hybrid Program。exact 路径从
        # parameter history 取证；sampled 路径必须由选中目标点的 typed evidence
        # 取证，后续还会核对 final sampling 的模型、选项及每组证据哈希。
        has_noisy_runtime_wrapper = (
            selected.execution_evidence is not None
            and selected.execution_evidence.noise_model is not None
        ) or _uses_noisy_sampled_runtime_wrapper(self)
        if (
            self.context.native_program_hash != self.result.program_hash
            and not has_noisy_runtime_wrapper
        ):
            raise ValueError("context Native Program does not match result.")
        if selected.parameter_bind != self.parameter_bind:
            raise ValueError(
                "selected history binding does not match the result binding."
            )
        if selected.result_hash != self.result.stable_hash():
            raise ValueError("selected history result hash does not match result.")
        if selected.result_id != self.result.result_id:
            raise ValueError("selected history result id does not match result.")
        if selected.program_hash != self.result.program_hash:
            raise ValueError("selected history program hash does not match result.")
        if selected.source_program_hash != self.context.native_program_hash:
            raise ValueError(
                "selected history source program does not match execution context."
            )
        if selected.shots != self.result.shots:
            raise ValueError("selected history shots do not match result.")
        if not math.isclose(
            selected.objective_value,
            self.objective_value,
            rel_tol=_ENERGY_RELATIVE_TOLERANCE,
            abs_tol=_ENERGY_ABSOLUTE_TOLERANCE,
        ):
            raise ValueError("selected history objective does not match result.")
        if _objective_evaluation is None:
            expected_selected_breakdown = expected_problem_energy_breakdown(
                self.context.analysis.canonical_problem,
                _result_weights(self.result),
                penalty_analysis=self.context.analysis.penalty_analysis,
            )
        else:
            _validate_objective_evaluation(
                analysis=self.context.analysis,
                best_observed_candidate=self.best_observed_candidate,
                objective_value=self.objective_value,
                objective_evaluation=_objective_evaluation,
            )
            expected_selected_breakdown = _objective_evaluation.energy_breakdown
        if selected.energy_breakdown != expected_selected_breakdown:
            raise ValueError(
                "selected history energy breakdown does not match result distribution."
            )
        expected_penalty_status = (
            "defined"
            if self.context.analysis.penalty_analysis is not None
            else "not_applicable"
        )
        if any(
            item.energy_breakdown.penalty_model_status != expected_penalty_status
            for item in self.parameter_history
        ):
            raise ValueError(
                "parameter history penalty status does not match Problem analysis."
            )
        if self.baseline is not None and not isinstance(
            self.baseline, ClassicalBaselineIR
        ):
            raise TypeError("baseline must be ClassicalBaselineIR or None.")
        expected_baseline = _canonical_baseline(canonical)
        if self.baseline != expected_baseline:
            raise ValueError("baseline does not match the canonical Problem.")
        expected_metrics = _problem_evaluation_metrics(
            canonical=canonical,
            result=self.result,
            best_observed_candidate=self.best_observed_candidate,
            baseline=self.baseline,
            objective_value=self.objective_value,
            objective_evaluation=_objective_evaluation,
        )
        actual_metrics = _ProblemEvaluationMetrics(
            best_observed_candidate=selected.best_observed_candidate,
            feasible_probability=selected.feasible_probability,
            expected_constraint_violation_count=(
                selected.expected_constraint_violation_count
            ),
            best_observed_constraint_violation_count=(
                selected.best_observed_constraint_violation_count
            ),
            expected_selected_weight=selected.expected_selected_weight,
            baseline_objective=selected.baseline_objective,
            expected_objective_gap=selected.expected_objective_gap,
            best_observed_objective_gap=selected.best_observed_objective_gap,
        )
        if actual_metrics != expected_metrics:
            raise ValueError(
                "selected parameter evaluation does not match result distribution."
            )
        if self.optimization is not None:
            if not isinstance(self.optimization, ProblemOptimizationIR):
                raise TypeError("optimization must be ProblemOptimizationIR or None.")
            sampled_history = self.optimization.sampled_evaluations
            if not sampled_history and (
                self.optimization.evaluation_count != len(self.parameter_history)
            ):
                raise ValueError(
                    "optimization evaluation_count must match parameter_history."
                )
            if not sampled_history and (
                self.optimization.best_evaluation_index
                != self.selected_evaluation_index
            ):
                raise ValueError(
                    "optimization best index must match selected_evaluation_index."
                )
            expected_parameter_names = tuple(
                item.name for item in self.context.parameter_schema.parameters
            )
            expected_hamiltonian_hash = (
                self.context.analysis.logical_hamiltonian.pauli_hamiltonian_hash
            )
            for gradient in self.optimization.gradients:
                if gradient.plan.logical_order != self.logical_order:
                    raise ValueError(
                        "optimization gradient logical order does not match Problem."
                    )
                if gradient.plan.parameter_names != expected_parameter_names:
                    raise ValueError(
                        "optimization gradient parameters do not match Problem."
                    )
                if gradient.plan.hamiltonian_hash != expected_hamiltonian_hash:
                    raise ValueError(
                        "optimization gradient Hamiltonian does not match Problem."
                    )
            _validate_problem_gradient_evidence(
                self.parameter_history,
                self.optimization.gradients,
                sampled_history=sampled_history,
            )
            if sampled_history:
                _validate_problem_sampled_execution(self)
            else:
                _validate_problem_exact_start_history(
                    self.parameter_history,
                    self.optimization.starts,
                )
        if self.optimality_claim != "not_claimed":
            raise ValueError("ProblemExecutionResult cannot claim global optimality.")
        if not isinstance(self.metadata, dict):
            raise TypeError("metadata must be a dictionary.")
        object.__setattr__(self, "metadata", dict(self.metadata))

    @property
    def execution_hash(self) -> str:
        """Return a stable hash of all execution and decoding evidence."""
        return self.stable_hash()

    def report(
        self,
        output: str | PathLike[str] | None = None,
        *,
        language: Literal["en", "zh"] = "en",
        title: str | None = None,
    ) -> ExperimentReport:
        """Build and optionally save the standard Problem experiment report."""
        from cascaqit.visualization import visualize

        report = visualize(self, profile="problem", title=title)
        if output is not None:
            report.save(output, language=language)
        return report

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ProblemExecutionResult:
        """Restore a Problem execution result from JSON-compatible data."""
        return cls(
            execution_id=str(data["execution_id"]),
            mode=data["mode"],
            algorithm=data["algorithm"],
            topology=(None if data.get("topology") is None else str(data["topology"])),
            compile_hash=str(data["compile_hash"]),
            analysis_hash=str(data["analysis_hash"]),
            problem_hash=str(data["problem_hash"]),
            logical_order=tuple(str(item) for item in data["logical_order"]),
            context=ProblemExecutionContextIR.from_dict(
                dict(_mapping(data["context"], "context"))
            ),
            parameter_bind=ParameterBindIR.from_dict(
                _mapping(data["parameter_bind"], "parameter_bind")
            ),
            parameter_bind_hash=str(data["parameter_bind_hash"]),
            result=ResultIR.from_dict(dict(_mapping(data["result"], "result"))),
            candidates=tuple(
                AlgorithmCandidateIR.from_dict(_mapping(item, "candidate"))
                for item in _sequence(data["candidates"], "candidates")
            ),
            most_probable_candidate=AlgorithmCandidateIR.from_dict(
                _mapping(
                    data["most_probable_candidate"],
                    "most_probable_candidate",
                )
            ),
            best_observed_candidate=AlgorithmCandidateIR.from_dict(
                _mapping(data["best_observed_candidate"], "best_observed_candidate")
            ),
            objective_value=float(data["objective_value"]),
            feasibility=data.get("feasibility"),
            constraint_violations=tuple(
                str(item) for item in data.get("constraint_violations", ())
            ),
            candidate_energy_breakdowns=tuple(
                ProblemEnergyBreakdownIR.from_dict(
                    _mapping(item, "candidate_energy_breakdown")
                )
                for item in _sequence(
                    data["candidate_energy_breakdowns"],
                    "candidate_energy_breakdowns",
                )
            ),
            parameter_history=tuple(
                ProblemParameterEvaluationIR.from_dict(
                    _mapping(item, "parameter_history item")
                )
                for item in _sequence(data["parameter_history"], "parameter_history")
            ),
            selected_evaluation_index=int(data["selected_evaluation_index"]),
            cardinality_subspace=(
                None
                if data.get("cardinality_subspace") is None
                else CardinalitySubspaceEvidenceIR.from_dict(
                    _mapping(data["cardinality_subspace"], "cardinality_subspace")
                )
            ),
            optimization=(
                None
                if data.get("optimization") is None
                else ProblemOptimizationIR.from_dict(
                    _mapping(data["optimization"], "optimization")
                )
            ),
            baseline=(
                None
                if data.get("baseline") is None
                else ClassicalBaselineIR.from_dict(
                    _mapping(data["baseline"], "baseline")
                )
            ),
            optimality_claim=data.get("optimality_claim", "not_claimed"),
            metadata=dict(_mapping(data.get("metadata", {}), "metadata")),
            schema_version=str(
                data.get("schema_version", PROBLEM_EXECUTION_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> ProblemExecutionResult:
        """Restore a Problem execution result from JSON text."""
        import json

        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("ProblemExecutionResult JSON must contain an object.")
        return cls.from_dict(data)


def _reject_non_digital_noise(
    compiled: ProblemCompileResult,
    *,
    noise: NoiseModel | None,
    operation: str,
) -> None:
    """Reject noisy Analog/Hybrid Problem requests before binding or Job creation."""
    if noise is None or compiled.mode == "digital":
        return
    raise CapabilityError(
        "Problem noise is currently available only for Digital QAOA/VQE.",
        code="PROBLEM_NOISY_MODE_UNSUPPORTED",
        stage="optimization" if operation == "optimize" else "execution",
        object_path=f"problem.compile.{compiled.mode}.{operation}.noise",
        metadata={
            "mode": compiled.mode,
            "algorithm": compiled.algorithm,
            "operation": operation,
        },
    )


def _digital_hamiltonian(compiled: ProblemCompileResult) -> PauliHamiltonian:
    """Return the typed Digital Hamiltonian after checking the union member."""
    hamiltonian = getattr(compiled, "hamiltonian", None)
    if not isinstance(hamiltonian, PauliHamiltonian):
        raise RuntimeError("Digital compile result lost its Pauli Hamiltonian.")
    return hamiltonian


def _digital_observable_objective(
    hamiltonian: PauliHamiltonian,
    observable_batch: ObservableBatchResultIR,
) -> float:
    """Reconstruct the Hamiltonian energy from the same Result used by decoding."""
    if len(observable_batch.items) != len(hamiltonian.terms):
        raise ValueError("Digital Observable batch does not cover the Hamiltonian.")
    energy = hamiltonian.constant
    for term, observable in zip(hamiltonian.terms, observable_batch.items):
        if term.observable.name != observable.name:
            raise ValueError("Digital Observable order does not match the Hamiltonian.")
        energy += term.coefficient * observable.expectation
    return float(energy)


def run_compiled_problem(
    compiled: ProblemCompileResult,
    *,
    params: Mapping[str, float] | None = None,
    shots: int = 1024,
    seed: int | None = 0,
    backend: LocalBackend | None = None,
    noise: NoiseModel | None = None,
    options: SimulationOptions | None = None,
    job_id: str | None = None,
) -> ProblemExecutionResult:
    """Bind, execute, and decode one compiled Problem program."""
    _non_negative_int(shots, "shots")
    _optional_seed(seed)
    _reject_non_digital_noise(compiled, noise=noise, operation="run")
    if compiled.mode == "hybrid" and shots == 0:
        raise ValueError(
            "Hybrid run() requires positive shots; use evaluate() for exact "
            "probabilities."
        )
    if compiled.mode == "digital" and noise is not None and shots == 0:
        raise ValueError(
            "Noisy Digital run() requires positive shots; use evaluate() for an "
            "exact-density objective."
        )
    record = _execute_compiled_problem(
        compiled,
        params=params,
        shots=shots,
        seed=seed,
        backend=backend,
        noise=noise,
        options=options,
        job_id=job_id,
    )
    return _decode_problem_execution(record)


def _execute_compiled_problem(
    compiled: ProblemCompileResult,
    *,
    params: Mapping[str, float] | None,
    shots: int,
    seed: int | None,
    backend: LocalBackend | None,
    noise: NoiseModel | None,
    options: SimulationOptions | None,
    job_id: str | None,
) -> _ProblemExecutionRecord:
    """Bind and execute once while deferring the public Problem projection."""
    bound = _bound_compile_result(compiled, params=params)
    parameter_bind = bound.parameter_bind
    if parameter_bind is None:
        raise RuntimeError("Bound Problem execution lost its parameter binding.")
    execution_backend = _execution_backend(bound, backend=backend, seed=seed)
    execution_program = _execution_program(bound)
    digital_hamiltonian = (
        _digital_hamiltonian(bound) if bound.mode == "digital" else None
    )
    planned_noisy_execution = None
    if noise is not None:
        if not isinstance(execution_program, Circuit):
            raise RuntimeError("Noisy Digital execution lost its bound Circuit.")
        planned_noisy_execution = validate_noisy_variational_request(
            execution_program,
            noise=noise,
            options=options,
            backend=execution_backend,
            seed=seed,
        )
    context = build_problem_execution_context(
        bound,
        execution_program=execution_program,
    )
    bind_hash = parameter_bind.parameter_bind_hash
    resolved_job_id = (
        f"problem.{bound.mode}.{bound.compile_hash[:12]}.{bind_hash[:12]}.run"
        if job_id is None
        else job_id
    )
    job = execution_backend.run(
        execution_program,
        shots=shots,
        seed=seed,
        job_id=resolved_job_id,
        observables=(
            digital_hamiltonian.observable_set()
            if digital_hamiltonian is not None
            else None
        ),
        noise=noise,
        options=options,
    )
    result = job.result()
    status = job.status()
    execution_evidence = None
    if bound.mode == "digital":
        observable_batch = result.observable_batch
        if observable_batch is None:
            raise RuntimeError(
                "Digital Problem execution did not return Observable evidence."
            )
        execution_evidence = build_objective_execution_evidence(
            result=result,
            observable_batch=observable_batch,
            noise=noise,
            options=options,
            requested_seed=seed,
            backend_id=status.backend_id,
            backend_job_id=status.job_id,
        )
        if (
            planned_noisy_execution is not None
            and execution_evidence.simulation_plan.execution_contract()
            != planned_noisy_execution.execution_contract()
        ):
            raise RuntimeError(
                "Noisy Problem SimulationPlan changed between preflight and execution."
            )
    return _ProblemExecutionRecord(
        bound=bound,
        context=context,
        parameter_bind=parameter_bind,
        result=result,
        result_hash=result.stable_hash(),
        execution_evidence=execution_evidence,
        seed=_result_seed(result, fallback=seed),
        backend_job_id=status.job_id,
        metadata={
            "backend_id": status.backend_id,
            "backend_job_id": status.job_id,
            "backend_execution_count": status.execution_count,
            "execution_program_hash": result.program_hash,
            "requested_seed": seed,
        },
    )


def _decode_problem_execution(
    record: _ProblemExecutionRecord,
    *,
    objective_evaluation: ProblemObjectiveEvaluation | None = None,
    optimization_finalization: _ProblemOptimizationFinalization | None = None,
) -> ProblemExecutionResult:
    """Project one raw execution through the existing public decoder contract."""
    bound = record.bound
    decoded = decode_problem_result(
        analysis=bound.analysis,
        mode=bound.mode,
        algorithm=bound.algorithm,
        topology=bound.topology,
        compile_hash=bound.compile_hash,
        context=record.context,
        parameter_bind=record.parameter_bind,
        result=record.result,
        source_program_hash=record.context.native_program_hash,
        execution_evidence=record.execution_evidence,
        seed=record.seed,
        backend_job_id=record.backend_job_id,
        metadata=record.metadata,
        _objective_evaluation=objective_evaluation,
        _result_hash=record.result_hash,
        _optimization_finalization=optimization_finalization,
    )
    _validate_digital_execution_objective(record, decoded.objective_value)
    return decoded


def _validate_digital_execution_objective(
    record: _ProblemExecutionRecord,
    objective_value: float,
) -> None:
    if record.bound.mode == "digital":
        observable_batch = record.result.observable_batch
        if observable_batch is None:
            raise RuntimeError(
                "Digital Problem execution did not return Observable evidence."
            )
        digital_hamiltonian = _digital_hamiltonian(record.bound)
        observable_objective = _digital_observable_objective(
            digital_hamiltonian,
            observable_batch,
        )
        if not math.isclose(
            observable_objective,
            objective_value,
            rel_tol=_ENERGY_RELATIVE_TOLERANCE,
            abs_tol=_ENERGY_ABSOLUTE_TOLERANCE,
        ):
            raise ValueError(
                "Digital Observable objective does not match Problem decoding."
            )


def build_problem_execution_context(
    compiled: ProblemCompileResult,
    *,
    execution_program: Circuit | AHSProgram | HybridProgram | None = None,
) -> ProblemExecutionContextIR:
    """Capture the selected compile facts and exact Native Program snapshot."""
    program = (
        _execution_program(compiled) if execution_program is None else execution_program
    )
    native_program: ProblemNativeProgramIR
    if compiled.mode == "digital":
        if not isinstance(program, Circuit):
            raise TypeError("Digital execution context requires a Circuit.")
        native_program = program.to_ir()
        native_program_hash = native_program.stable_hash()
    elif compiled.mode == "analog":
        if not isinstance(program, AHSProgram):
            raise TypeError("Analog execution context requires an AHSProgram.")
        native_program = program.to_ir()
        native_program_hash = native_program.stable_hash()
    else:
        if not isinstance(program, HybridProgram):
            raise TypeError("Hybrid execution context requires a HybridProgram.")
        native_program = program.to_ir()
        native_program_hash = program.stable_hash()

    identity_hash = hashlib.sha256(
        stable_json(
            {
                "compile_hash": compiled.compile_hash,
                "native_program_hash": native_program_hash,
                "parameter_bind": compiled.parameter_bind,
            }
        ).encode("utf-8")
    ).hexdigest()
    context_ansatz: AnsatzSpecIR | None = getattr(compiled, "ansatz", None)
    return ProblemExecutionContextIR(
        context_id=f"problem.context.{compiled.mode}.{identity_hash[:20]}",
        mode=compiled.mode,  # type: ignore[arg-type]
        algorithm=compiled.algorithm,  # type: ignore[arg-type]
        topology=compiled.topology,
        compile_hash=compiled.compile_hash,
        analysis=compiled.analysis,
        term_mapping=compiled.term_mapping,
        parameter_schema=compiled.parameter_schema,
        ansatz=context_ansatz,
        ansatz_spec_hash=(
            context_ansatz.spec_hash if context_ansatz is not None else None
        ),
        native_program=native_program,
        native_program_hash=native_program_hash,
        local_reference=compiled.local_reference,
        hardware_executable=compiled.hardware_executable,
        metadata={
            "native_program_kind": compiled.mode,
            "target_id": compiled.analysis.mapping_plan.target_id,
            "target_hash": compiled.analysis.mapping_plan.target_hash,
        },
    )


def evaluate_compiled_problem(
    compiled: ProblemCompileResult,
    *,
    params: Mapping[str, float] | None = None,
    seed: int | None = 0,
    backend: LocalBackend | None = None,
    noise: NoiseModel | None = None,
    options: SimulationOptions | None = None,
) -> ProblemExecutionResult:
    """Evaluate exact basis probabilities for one concrete parameter point."""
    # Hybrid execution currently requires a positive terminal measurement count.
    # One shot satisfies that runtime contract; the objective still uses the exact
    # probability vector returned by the ideal backend, never the one-shot count.
    shots = 1 if compiled.mode == "hybrid" or noise is not None else 0
    return run_compiled_problem(
        compiled,
        params=params,
        shots=shots,
        seed=seed,
        backend=backend,
        noise=noise,
        options=options,
    )


def optimize_compiled_problem(
    compiled: ProblemCompileResult,
    *,
    parameter_sets: Sequence[Mapping[str, float]] | None = None,
    optimizer: OptimizerConfig | None = None,
    initial_parameters: ParameterValues | None = None,
    shots: int = 0,
    seed: int | None = 0,
    backend: LocalBackend | None = None,
    noise: NoiseModel | None = None,
    options: SimulationOptions | None = None,
    parallel_workers: WorkerRequest = 1,
    measurement: PauliMeasurementConfig | None = None,
    sampled_selection: SampledSelectionConfig | None = None,
) -> ProblemExecutionResult:
    """Run exactly one discrete or configured optimizer strategy."""
    _reject_non_digital_noise(compiled, noise=noise, operation="optimize")
    _validate_parallel_workers(parallel_workers)
    if measurement is not None and not isinstance(measurement, PauliMeasurementConfig):
        raise TypeError("measurement must be PauliMeasurementConfig or None.")
    if sampled_selection is not None and not isinstance(
        sampled_selection,
        SampledSelectionConfig,
    ):
        raise TypeError("sampled_selection must be SampledSelectionConfig or None.")
    if sampled_selection is not None and measurement is None:
        raise ValueError("sampled_selection requires finite-shot VQE measurement.")
    if measurement is not None:
        if parameter_sets is not None:
            raise ValueError(
                "finite-shot VQE measurement requires configured optimizer search."
            )
        if compiled.mode != "digital" or compiled.algorithm != "vqe":
            raise CapabilityError(
                "Finite-shot Pauli objective measurement is available only for "
                "Digital VQE.",
                code="PROBLEM_SAMPLED_OBJECTIVE_UNSUPPORTED",
                stage="optimization",
                object_path=f"problem.compile.{compiled.mode}.optimize.measurement",
                metadata={"mode": compiled.mode, "algorithm": compiled.algorithm},
            )
    if (parameter_sets is None) == (optimizer is None):
        raise ValueError("Provide exactly one of parameter_sets or optimizer.")
    if parameter_sets is not None:
        if parallel_workers != 1:
            raise ValueError(
                "parallel_workers is available only with continuous multi-start "
                "optimization."
            )
        if initial_parameters is not None:
            raise ValueError("initial_parameters are available only with optimizer.")
        return _optimize_parameter_sets(
            compiled,
            parameter_sets=parameter_sets,
            shots=shots,
            seed=seed,
            backend=backend,
            noise=noise,
            options=options,
        )
    if not isinstance(optimizer, OptimizerConfig):
        raise TypeError("optimizer must be OptimizerConfig.")
    if measurement is not None:
        return _optimize_sampled_vqe_problem(
            compiled,
            optimizer=optimizer,
            initial_parameters=initial_parameters,
            shots=shots,
            seed=seed,
            backend=backend,
            measurement=measurement,
            sampled_selection=sampled_selection,
            noise=noise,
            options=options,
        )
    return _optimize_continuous_problem(
        compiled,
        optimizer=optimizer,
        initial_parameters=initial_parameters,
        shots=shots,
        seed=seed,
        backend=backend,
        noise=noise,
        options=options,
        parallel_workers=parallel_workers,
    )


def _optimize_parameter_sets(
    compiled: ProblemCompileResult,
    *,
    parameter_sets: Sequence[Mapping[str, float]],
    shots: int,
    seed: int | None,
    backend: LocalBackend | None,
    noise: NoiseModel | None,
    options: SimulationOptions | None,
) -> ProblemExecutionResult:
    """Execute caller-supplied points without applying a classical optimizer."""
    if not isinstance(parameter_sets, Sequence) or isinstance(
        parameter_sets, (str, bytes)
    ):
        raise TypeError("parameter_sets must be a sequence of mappings.")
    if not parameter_sets:
        raise ValueError("parameter_sets must not be empty.")
    _non_negative_int(shots, "shots")
    _optional_seed(seed)
    effective_shots = (
        1 if (compiled.mode == "hybrid" or noise is not None) and shots == 0 else shots
    )
    execution_backend = _execution_backend(compiled, backend=backend, seed=seed)
    executions = tuple(
        run_compiled_problem(
            compiled,
            params=params,
            shots=effective_shots,
            seed=seed,
            backend=execution_backend,
            noise=noise,
            options=options,
            job_id=(
                f"problem.{compiled.mode}.{compiled.compile_hash[:12]}."
                f"parameter-set.{index:06d}"
            ),
        )
        for index, params in enumerate(parameter_sets)
    )
    return _finalize_problem_optimization(
        compiled,
        executions=executions,
        search_kind="parameter_sets",
        requested_shots=shots,
        effective_shots=effective_shots,
    )


def _optimize_sampled_vqe_problem(
    compiled: ProblemCompileResult,
    *,
    optimizer: OptimizerConfig,
    initial_parameters: ParameterValues | None,
    shots: int,
    seed: int | None,
    backend: LocalBackend | None,
    measurement: PauliMeasurementConfig,
    sampled_selection: SampledSelectionConfig | None,
    noise: NoiseModel | None,
    options: SimulationOptions | None,
) -> ProblemExecutionResult:
    """Run finite-shot VQE while preserving one final decodable Problem result."""
    if compiled.mode != "digital" or compiled.algorithm != "vqe":
        raise RuntimeError("sampled VQE dispatch received a non-VQE compile result.")
    if getattr(compiled, "is_bound", False):
        raise ValueError("sampled VQE optimization requires an unbound compile result.")
    if not isinstance(getattr(compiled, "program", None), Circuit):
        raise RuntimeError("Digital VQE compile result lost its Circuit.")
    if shots <= 0:
        raise ValueError("finite-shot VQE optimization requires positive final shots.")
    _optional_seed(seed)
    config = resolve_problem_optimizer_config(compiled, optimizer)
    if config.method not in {"SPSA", "ADAM"}:
        raise ValueError("finite-shot VQE optimization requires SPSA or ADAM.")
    if config.method == "SPSA" and config.gradient is not None:
        raise ValueError("finite-shot VQE SPSA does not accept gradients.")

    program = cast(Circuit, compiled.program)
    hamiltonian = _digital_hamiltonian(compiled)
    ansatz = getattr(compiled, "ansatz", None)
    if not isinstance(ansatz, AnsatzSpecIR):
        raise RuntimeError("Digital VQE compile result lost its ansatz contract.")
    parameter_names = tuple(
        parameter.name for parameter in compiled.parameter_schema.parameters
    )
    algorithm_id = program.metadata.get("algorithm_id")
    if not isinstance(algorithm_id, str) or not algorithm_id.strip():
        raise ValueError("Digital VQE compile result is missing algorithm_id metadata.")
    resolved_seed = _problem_optimizer_seed(config, backend=backend, seed=seed)
    execution_backend = _execution_backend(
        compiled,
        backend=backend,
        seed=resolved_seed,
    )
    default_initial = _problem_default_initial_parameters(
        compiled,
        parameter_names=parameter_names,
    )
    effective_initial = (
        default_initial if initial_parameters is None else initial_parameters
    )
    run_hash = hashlib.sha256(
        stable_json(
            {
                "compile_hash": compiled.compile_hash,
                "optimizer": config,
                "initial_parameters": effective_initial,
                "measurement": measurement,
                "sampled_selection": sampled_selection,
                "noise": noise,
                "options": options,
                "shots": shots,
                "seed": resolved_seed,
            }
        ).encode("utf-8")
    ).hexdigest()
    algorithm_run_id = f"problem.vqe.sampled.{run_hash[:20]}"

    def evaluator(
        values: ParameterValues,
        *,
        backend: LocalBackend | None = None,
        evaluation_index: int = 0,
        algorithm_run_id: str | None = None,
        seed: int | None = None,
        measurement: PauliMeasurementConfig | None = None,
        noise: NoiseModel | None = None,
        options: SimulationOptions | None = None,
    ) -> SampledObjectiveEvaluationIR:
        if measurement is None:
            raise RuntimeError("sampled VQE evaluator lost its measurement config.")
        return execute_sampled_objective_evaluation(
            algorithm_id=algorithm_id,
            algorithm_run_id=algorithm_run_id,
            evaluation_index=evaluation_index,
            circuit=program,
            parameter_names=parameter_names,
            parameters=values,
            hamiltonian=hamiltonian,
            measurement=measurement,
            backend=backend,
            seed=seed,
            noise=noise,
            options=options,
        )

    def gradient_evaluator(
        values: ParameterValues,
        *,
        backend: LocalBackend | None = None,
        gradient_index: int = 0,
        objective_evaluation_offset: int = 0,
        max_backend_executions: int | None = None,
        algorithm_run_id: str | None = None,
        seed: int | None = None,
        config: GradientConfig | None = None,
        measurement: PauliMeasurementConfig | None = None,
        noise: NoiseModel | None = None,
        options: SimulationOptions | None = None,
    ) -> ObjectiveGradientIR:
        if measurement is None:
            raise RuntimeError("sampled VQE gradient lost its measurement config.")
        gradient_method = getattr(compiled, "gradient", None)
        if not callable(gradient_method):
            raise RuntimeError("Digital compile result lost its gradient method.")
        return cast(
            ObjectiveGradientIR,
            gradient_method(
                params=values,
                backend=backend,
                gradient_index=gradient_index,
                objective_evaluation_offset=objective_evaluation_offset,
                max_backend_executions=max_backend_executions,
                algorithm_run_id=algorithm_run_id,
                seed=seed,
                config=config,
                measurement=measurement,
                noise=noise,
                options=options,
            ),
        )

    variational = run_variational_optimization(
        algorithm_kind="vqe",
        algorithm_id=algorithm_id,
        layers=getattr(compiled, "layers", 1),
        parameter_names=parameter_names,
        hamiltonian=hamiltonian,
        ansatz=ansatz,
        evaluator=evaluator,
        circuit_builder=lambda: program.snapshot(),
        gradient_evaluator=gradient_evaluator,
        problem=None,
        backend=execution_backend,
        optimizer=config,
        initial_parameters=effective_initial,
        algorithm_run_id=algorithm_run_id,
        final_shots=shots,
        measurement=measurement,
        sampled_selection=sampled_selection,
        noise=noise,
        options=options,
    )
    evaluations = variational.evaluations
    selected_index = (
        variational.best_evaluation_index
        if variational.sampled_selection is None
        else variational.sampled_selection.selected_source_evaluation_index
    )
    selected_evaluation = evaluations[selected_index]
    final_result = variational.final_result
    if final_result is None:
        raise RuntimeError("sampled VQE workflow did not return final sampling.")

    # Rebuild the exact terminal Circuit through the same shared constructor used
    # by the standalone VQE workflow, then retain it in Problem execution context.
    final_program = build_final_sampling_circuit(
        circuit=program,
        best_evaluation=selected_evaluation,
        algorithm_run_id=algorithm_run_id,
    )
    if (
        noise is None
        and final_program.to_ir().stable_hash() != final_result.program_hash
    ):
        raise RuntimeError("sampled VQE final Circuit does not match its ResultIR.")
    bound = compiled.bind(selected_evaluation.parameter_bind.values)
    context = build_problem_execution_context(bound, execution_program=final_program)
    final_sampling = variational.metadata.get("final_sampling")
    final_seed = (
        resolved_seed
        if not isinstance(final_sampling, Mapping)
        else int(final_sampling.get("seed", resolved_seed))
    )
    canonical_metadata = canonicalize(variational.metadata)
    if not isinstance(canonical_metadata, dict):
        raise RuntimeError("sampled VQE metadata did not normalize to an object.")
    selected_start = variational.optimization_starts[
        variational.selected_start_index or 0
    ]
    semantic_hash = hashlib.sha256(
        stable_json(
            {
                "run_hash": run_hash,
                "evaluations": tuple(
                    {
                        "parameters": item.parameter_bind.values,
                        "energy": item.energy,
                        "energy_standard_error": item.energy_standard_error,
                        "plan_hash": item.plan.plan_hash,
                    }
                    for item in evaluations
                ),
                "sampled_selection": variational.sampled_selection,
            }
        ).encode("utf-8")
    ).hexdigest()
    optimization = ProblemOptimizationIR(
        optimization_id=f"problem.optimization.{semantic_hash[:20]}",
        search_kind="optimizer",
        evaluation_count=len(evaluations),
        best_evaluation_index=variational.best_evaluation_index,
        optimizer=variational.optimizer,
        initial_parameters=selected_start.initial_parameters,
        final_parameters=selected_start.final_parameters,
        final_objective=selected_start.final_objective,
        termination=variational.termination,
        starts=variational.optimization_starts,
        selected_start_index=variational.selected_start_index,
        gradients=variational.gradients,
        sampled_evaluations=evaluations,
        sampled_selection=variational.sampled_selection,
    )
    decoded = decode_problem_result(
        analysis=compiled.analysis,
        mode=compiled.mode,
        algorithm=compiled.algorithm,
        topology=compiled.topology,
        compile_hash=compiled.compile_hash,
        context=context,
        parameter_bind=selected_evaluation.parameter_bind,
        result=final_result,
        source_program_hash=context.native_program_hash,
        seed=final_seed,
        optimization=optimization,
        metadata=canonical_metadata,
    )
    execution_hash = hashlib.sha256(
        stable_json(
            {
                "compile_hash": compiled.compile_hash,
                "optimization": optimization,
                "result_hash": final_result.stable_hash(),
            }
        ).encode("utf-8")
    ).hexdigest()
    return replace(
        decoded,
        execution_id=f"problem.execution.optimize.{execution_hash[:20]}",
        optimization=optimization,
        baseline=_canonical_baseline(compiled.analysis.canonical_problem),
        metadata={
            **decoded.metadata,
            "execution_role": "sampled_vqe_optimization",
            "objective_estimator": "finite_shot_pauli_measurement",
            "selection_rule": variational.metadata["objective_selection_rule"],
            "requested_shots": shots,
            "effective_shots": shots,
        },
    )


def _optimize_continuous_problem(
    compiled: ProblemCompileResult,
    *,
    optimizer: OptimizerConfig,
    initial_parameters: ParameterValues | None,
    shots: int,
    seed: int | None,
    backend: LocalBackend | None,
    noise: NoiseModel | None,
    options: SimulationOptions | None,
    parallel_workers: WorkerRequest,
) -> ProblemExecutionResult:
    """Minimize the decoded expected objective through the shared optimizer."""
    _non_negative_int(shots, "shots")
    _optional_seed(seed)
    config = resolve_problem_optimizer_config(compiled, optimizer)
    if config.gradient is not None and compiled.mode != "digital":
        raise CapabilityError(
            "Problem gradient optimization is available only for Digital QAOA/VQE.",
            code="PROBLEM_GRADIENT_MODE_UNSUPPORTED",
            stage="optimization",
            object_path=f"problem.compile.{compiled.mode}.optimize.gradient",
            metadata={"mode": compiled.mode, "algorithm": compiled.algorithm},
        )
    parameter_names = tuple(
        parameter.name for parameter in compiled.parameter_schema.parameters
    )
    resolved_seed = _problem_optimizer_seed(config, backend=backend, seed=seed)
    algorithm_kind = cast(Literal["qaoa", "vqe", "qaa"], compiled.algorithm)
    plans = build_optimization_start_plans(
        algorithm_kind=algorithm_kind,
        layers=getattr(compiled, "layers", 1),
        parameter_names=parameter_names,
        optimizer=config,
        initial_parameters=initial_parameters,
        seed=resolved_seed,
        default_initial_parameters=_problem_default_initial_parameters(
            compiled,
            parameter_names=parameter_names,
        ),
    )
    effective_shots = (
        1 if (compiled.mode == "hybrid" or noise is not None) and shots == 0 else shots
    )
    execution_backend = _execution_backend(
        compiled,
        backend=backend,
        seed=resolved_seed,
    )
    run_hash = hashlib.sha256(
        stable_json(
            {
                "compile_hash": compiled.compile_hash,
                "optimizer": config,
                "starts": plans,
                "seed": resolved_seed,
                "shots": shots,
                "noise": noise,
                "options": options,
            }
        ).encode("utf-8")
    ).hexdigest()
    executions: list[ProblemExecutionResult] = []
    best_records: dict[int, _ProblemExecutionRecord] = {}
    objective_evaluations: list[ProblemObjectiveEvaluation] = []
    parameter_history: list[ProblemParameterEvaluationIR] = []
    objective_values: list[float] = []
    canonical = compiled.analysis.canonical_problem
    objective_plan = build_problem_objective_plan(
        canonical,
        penalty_analysis=compiled.analysis.penalty_analysis,
    )
    gradients: list[ObjectiveGradientIR] = []
    gradient_plan = None
    if config.gradient is not None:
        program = getattr(compiled, "program", None)
        hamiltonian = getattr(compiled, "hamiltonian", None)
        if not isinstance(program, Circuit) or not isinstance(
            hamiltonian,
            PauliHamiltonian,
        ):
            raise RuntimeError(
                "Digital compile result lost its Circuit or Pauli Hamiltonian."
            )
        gradient_plan = build_parameter_shift_plan(
            program,
            hamiltonian,
            config=config.gradient,
        )
    start_runs = _run_problem_optimization_starts(
        compiled,
        plans=plans,
        optimizer=config,
        parameter_names=parameter_names,
        effective_shots=effective_shots,
        execution_backend=execution_backend,
        noise=noise,
        options=options,
        run_hash=run_hash,
        objective_plan=objective_plan,
        gradient_plan=gradient_plan,
        parallel_workers=parallel_workers,
    )
    start_results: list[OptimizationStartIR] = []
    for start_run in start_runs:
        plan = start_run.plan
        evaluation_start_index = len(objective_values)
        gradient_start_index = len(gradients)
        outcome = start_run.outcome
        executions.extend(start_run.executions)
        objective_values.extend(outcome.objective_values)
        objective_evaluations.extend(start_run.objective_evaluations)
        parameter_history.extend(
            replace(
                item,
                evaluation_index=evaluation_start_index + item.evaluation_index,
            )
            for item in start_run.parameter_history
        )
        gradients.extend(start_run.gradients)
        global_best_index = evaluation_start_index + outcome.best_evaluation_index
        if start_run.best_record is not None:
            best_records[global_best_index] = start_run.best_record
        start_results.append(
            OptimizationStartIR(
                start_index=plan.start_index,
                seed=plan.seed,
                initialization=plan.initialization,
                evaluation_start_index=evaluation_start_index,
                evaluation_count=outcome.termination.nfev,
                best_evaluation_index=global_best_index,
                initial_parameters=dict(
                    zip(parameter_names, outcome.initial_parameters)
                ),
                final_parameters=dict(zip(parameter_names, outcome.final_parameters)),
                final_objective=outcome.final_objective,
                best_objective=(
                    min(
                        outcome.objective_estimates,
                        key=lambda item: (
                            item.pooled_objective,
                            item.source_evaluation_offset,
                        ),
                    ).pooled_objective
                    if outcome.objective_estimates
                    else objective_values[global_best_index]
                ),
                termination=outcome.termination,
                gradient_start_index=gradient_start_index,
                gradient_count=outcome.termination.njev,
                backend_execution_count=outcome.termination.backend_execution_count,
                adam_iterations=outcome.adam_iterations,
                adam_stopping_evidence=outcome.adam_stopping_evidence,
                spsa_iterations=outcome.spsa_iterations,
                spsa_initial_estimate=(
                    outcome.objective_estimates[0]
                    if outcome.objective_estimates
                    else None
                ),
                spsa_final_estimate=(
                    outcome.objective_estimates[-1]
                    if outcome.objective_estimates
                    else None
                ),
                spsa_learning_rate_calibration=(outcome.spsa_learning_rate_calibration),
                spsa_stopping_evidence=outcome.spsa_stopping_evidence,
            )
        )

    best_index = min(
        range(len(objective_values)),
        key=lambda index: (objective_values[index], index),
    )
    selected_start_index = next(
        item.start_index
        for item in start_results
        if item.best_evaluation_index == best_index
    )
    starts = tuple(start_results)
    selected_start = starts[selected_start_index]
    termination = aggregate_optimizer_termination(
        starts,
        selected_start_index=selected_start_index,
    )
    if objective_plan is None:
        return _finalize_problem_optimization(
            compiled,
            executions=tuple(executions),
            search_kind="optimizer",
            requested_shots=shots,
            effective_shots=effective_shots,
            expected_best_index=best_index,
            optimizer=config,
            initial_parameters=selected_start.initial_parameters,
            final_parameters=selected_start.final_parameters,
            final_objective=selected_start.final_objective,
            termination=termination,
            starts=starts,
            selected_start_index=selected_start_index,
            gradients=tuple(gradients),
        )

    return _finalize_problem_optimization(
        compiled,
        executions=(),
        search_kind="optimizer",
        requested_shots=shots,
        effective_shots=effective_shots,
        expected_best_index=best_index,
        parameter_history=tuple(parameter_history),
        selected_record=best_records[best_index],
        selected_objective_evaluation=objective_evaluations[best_index],
        optimizer=config,
        initial_parameters=selected_start.initial_parameters,
        final_parameters=selected_start.final_parameters,
        final_objective=selected_start.final_objective,
        termination=termination,
        starts=starts,
        selected_start_index=selected_start_index,
        gradients=tuple(gradients),
    )


def _run_problem_optimization_starts(
    compiled: ProblemCompileResult,
    *,
    plans: tuple[OptimizationStartPlan, ...],
    optimizer: OptimizerConfig,
    parameter_names: tuple[str, ...],
    effective_shots: int,
    execution_backend: LocalBackend,
    noise: NoiseModel | None,
    options: SimulationOptions | None,
    run_hash: str,
    objective_plan: ProblemObjectivePlan | None,
    gradient_plan: ParameterShiftPlanIR | None,
    parallel_workers: WorkerRequest,
) -> tuple[_ProblemOptimizationStartResult, ...]:
    if parallel_workers != 1 and optimizer.method in {"SPSA", "ADAM"}:
        raise CapabilityError(
            "Process-parallel optimizer starts do not support native SPSA or Adam.",
            code="PROBLEM_PARALLEL_OPTIMIZER_UNSUPPORTED",
            stage="optimization",
            object_path="problem.optimize.parallel_workers.optimizer",
            suggestion="Use parallel_workers=1 for native SPSA or Adam.",
            metadata={
                "optimizer": optimizer.method,
                "job_submitted": False,
                "algorithm_changed": False,
            },
        )
    if parallel_workers != 1 and compiled.mode != "hybrid":
        raise CapabilityError(
            "Parallel optimizer starts currently require a Hybrid Problem.",
            code="PROBLEM_PARALLEL_MODE_UNSUPPORTED",
            stage="optimization",
            object_path=f"problem.compile.{compiled.mode}.optimize.parallel_workers",
            suggestion="Use parallel_workers=1 for Digital or Analog optimization.",
            metadata={
                "mode": compiled.mode,
                "job_submitted": False,
                "algorithm_changed": False,
            },
        )
    if parallel_workers == 1 or len(plans) == 1:
        results: list[_ProblemOptimizationStartResult] = []
        evaluation_start_index = 0
        gradient_start_index = 0
        for plan in plans:
            result = _run_problem_optimization_start(
                compiled,
                plan=plan,
                optimizer=optimizer,
                parameter_names=parameter_names,
                effective_shots=effective_shots,
                execution_backend=execution_backend,
                noise=noise,
                options=options,
                run_hash=run_hash,
                objective_plan=objective_plan,
                gradient_plan=gradient_plan,
                evaluation_start_index=evaluation_start_index,
                gradient_start_index=gradient_start_index,
            )
            results.append(result)
            evaluation_start_index += result.outcome.termination.nfev
            gradient_start_index += result.outcome.termination.njev
        return tuple(results)

    if execution_backend.kernel_threads > 1:
        raise CapabilityError(
            "Process-parallel optimizer starts cannot also use kernel threads.",
            code="PROBLEM_NESTED_PARALLELISM_UNSUPPORTED",
            stage="optimization",
            object_path="problem.optimize.parallel_workers.backend.kernel_threads",
            suggestion=(
                "Use kernel_threads=1 with multiple optimizer starts, or run one "
                "start with parallel_workers=1."
            ),
            metadata={
                "parallel_workers": parallel_workers,
                "kernel_threads": execution_backend.kernel_threads,
                "job_submitted": False,
                "algorithm_changed": False,
            },
        )

    if execution_backend.store is not None:
        raise CapabilityError(
            "Parallel optimizer starts require independent in-memory Backends.",
            code="PROBLEM_PARALLEL_BACKEND_UNSUPPORTED",
            stage="optimization",
            object_path="problem.optimize.parallel_workers.backend",
            suggestion="Use LocalBackend without a persistent store or workers=1.",
            metadata={
                "backend_id": execution_backend.backend_id,
                "job_submitted": False,
                "algorithm_changed": False,
            },
        )

    per_task_peak_bytes, parent_reserve_bytes = _problem_parallel_memory_estimate(
        compiled,
        objective_plan=objective_plan,
    )
    policy = ParallelExecutionPlanner().resolve(
        ParallelExecutionRequest(
            task_count=len(plans),
            per_task_peak_bytes=per_task_peak_bytes,
            parent_reserve_bytes=parent_reserve_bytes,
            mode="auto" if parallel_workers == "auto" else "process",
            workers=parallel_workers,
        )
    )
    if policy.mode_selected == "serial":
        return _run_problem_optimization_starts(
            compiled,
            plans=plans,
            optimizer=optimizer,
            parameter_names=parameter_names,
            effective_shots=effective_shots,
            execution_backend=execution_backend,
            noise=noise,
            options=options,
            run_hash=run_hash,
            objective_plan=objective_plan,
            gradient_plan=gradient_plan,
            parallel_workers=1,
        )
    assert policy.start_method is not None
    compiled_payload = _serialize_hybrid_compile_result(compiled)
    backend_payload = _serialize_local_backend(execution_backend)
    tasks = tuple(
        _ProblemHybridOptimizationStartTask(
            compiled=compiled_payload,
            objective_plan=objective_plan,
            plan=_serialize_optimization_start_plan(plan),
            optimizer=optimizer.to_dict(),
            parameter_names=parameter_names,
            effective_shots=effective_shots,
            run_hash=run_hash,
            backend=backend_payload,
            noise=None if noise is None else noise.to_dict(),
            options=None if options is None else options.to_dict(),
        )
        for plan in plans
    )
    with reusable_process_executor(policy) as executor:
        futures = tuple(
            executor.submit(_run_problem_hybrid_optimization_start_worker, task)
            for task in tasks
        )
        try:
            payloads = tuple(future.result() for future in futures)
        except BaseException:
            for future in futures:
                future.cancel()
            wait(futures)
            raise
    return tuple(
        _deserialize_problem_optimization_start_result(payload, compiled=compiled)
        for payload in payloads
    )


def _run_problem_optimization_start(
    compiled: ProblemCompileResult,
    *,
    plan: OptimizationStartPlan,
    optimizer: OptimizerConfig,
    parameter_names: tuple[str, ...],
    effective_shots: int,
    execution_backend: LocalBackend,
    noise: NoiseModel | None,
    options: SimulationOptions | None,
    run_hash: str,
    objective_plan: ProblemObjectivePlan | None,
    gradient_plan: ParameterShiftPlanIR | None,
    evaluation_start_index: int,
    gradient_start_index: int,
) -> _ProblemOptimizationStartResult:
    executions: list[ProblemExecutionResult] = []
    execution_records: list[_ProblemExecutionRecord] = []
    objective_evaluations: list[ProblemObjectiveEvaluation] = []
    parameter_history: list[ProblemParameterEvaluationIR] = []
    objective_values: list[float] = []
    gradients: list[ObjectiveGradientIR] = []
    canonical = compiled.analysis.canonical_problem
    baseline = _canonical_baseline(canonical) if objective_plan is not None else None
    source_problem = (
        _canonical_source_problem(canonical) if objective_plan is not None else None
    )

    def objective(values: tuple[float, ...], evaluation_index: int) -> float:
        job_id = (
            f"problem.{compiled.mode}.{run_hash[:12]}."
            f"start.{plan.start_index:03d}.scipy.{evaluation_index:06d}"
        )
        params = dict(zip(parameter_names, values))
        if objective_plan is None:
            execution = run_compiled_problem(
                compiled,
                params=params,
                shots=effective_shots,
                seed=plan.seed,
                backend=execution_backend,
                noise=noise,
                options=options,
                job_id=job_id,
            )
            executions.append(execution)
            objective_values.append(execution.objective_value)
            return execution.objective_value

        record = _execute_compiled_problem(
            compiled,
            params=params,
            shots=effective_shots,
            seed=plan.seed,
            backend=execution_backend,
            noise=noise,
            options=options,
            job_id=job_id,
        )
        _validate_result(record.result, logical_order=canonical.logical_order)
        reduced = objective_plan.evaluate_result(record.result)
        _validate_digital_execution_objective(record, reduced.objective_value)
        assert source_problem is not None
        assert baseline is not None
        parameter_history.append(
            _build_lightweight_parameter_evaluation(
                evaluation_index=len(parameter_history),
                record=record,
                reduced=reduced,
                source_problem=source_problem,
                canonical=canonical,
                baseline=baseline,
            )
        )
        execution_records.append(record)
        objective_evaluations.append(reduced)
        objective_values.append(reduced.objective_value)
        return reduced.objective_value

    def gradient(
        values: tuple[float, ...],
        gradient_index: int,
    ) -> tuple[float, ...] | ObjectiveGradientIR:
        assert optimizer.gradient is not None
        assert gradient_plan is not None
        gradient_method = getattr(compiled, "gradient", None)
        if not callable(gradient_method):
            raise RuntimeError("Digital compile result lost its gradient method.")
        computed = cast(
            ObjectiveGradientIR,
            gradient_method(
                params=dict(zip(parameter_names, values)),
                backend=execution_backend,
                gradient_index=gradient_start_index + gradient_index,
                algorithm_run_id=f"problem.{run_hash[:20]}",
                seed=plan.seed,
                config=optimizer.gradient,
                noise=noise,
                options=options,
            ),
        )
        if computed.plan_hash != gradient_plan.plan_hash:
            raise RuntimeError("Problem gradient plan changed during optimization.")
        if (
            computed.backend_execution_count
            != gradient_plan.expected_objective_evaluation_count
        ):
            raise RuntimeError("Problem gradient Backend cost changed from plan.")
        gradients.append(computed)
        if optimizer.method == "ADAM":
            return computed
        return tuple(computed.gradient[name] for name in parameter_names)

    outcome = run_scalar_optimization(
        parameter_names=parameter_names,
        objective=objective,
        optimizer=optimizer,
        initial_parameters=plan.parameters,
        gradient=gradient if optimizer.gradient is not None else None,
        gradient_backend_execution_count=(
            0
            if gradient_plan is None
            else gradient_plan.expected_objective_evaluation_count
        ),
        seed=plan.seed,
        objective_evaluation_index_offset=evaluation_start_index,
        gradient_index_offset=gradient_start_index,
    )
    if tuple(objective_values) != outcome.objective_values:
        raise RuntimeError(
            "optimizer objective history does not match Problem execution evidence."
        )
    if outcome.termination.njev != len(gradients):
        raise RuntimeError("optimizer njev does not match Problem gradient history.")
    best_record = (
        None
        if objective_plan is None
        else execution_records[outcome.best_evaluation_index]
    )
    return _ProblemOptimizationStartResult(
        plan=plan,
        outcome=outcome,
        parameter_history=tuple(parameter_history),
        objective_evaluations=tuple(objective_evaluations),
        best_record=best_record,
        executions=tuple(executions),
        gradients=tuple(gradients),
    )


def _run_problem_hybrid_optimization_start_worker(
    task: _ProblemHybridOptimizationStartTask,
) -> dict[str, Any]:
    compiled = _deserialize_hybrid_compile_result(task.compiled)
    optimizer = OptimizerConfig.from_dict(task.optimizer)
    plan = _deserialize_optimization_start_plan(task.plan)
    backend = _deserialize_local_backend(task.backend)
    noise = None if task.noise is None else NoiseModel.from_dict(task.noise)
    options = (
        None if task.options is None else SimulationOptions.from_dict(task.options)
    )
    result = _run_problem_optimization_start(
        compiled,
        plan=plan,
        optimizer=optimizer,
        parameter_names=task.parameter_names,
        effective_shots=task.effective_shots,
        execution_backend=backend,
        noise=noise,
        options=options,
        run_hash=task.run_hash,
        objective_plan=task.objective_plan,
        gradient_plan=None,
        evaluation_start_index=0,
        gradient_start_index=0,
    )
    return _serialize_problem_optimization_start_result(result)


def _problem_parallel_memory_estimate(
    compiled: ProblemCompileResult,
    *,
    objective_plan: ProblemObjectivePlan | None,
) -> tuple[int, int]:
    dimension = int(compiled.resource_estimate.get("state_vector_dimension", 1))
    state_bytes = max(1, dimension) * 16
    objective_bytes = (
        0 if objective_plan is None else int(objective_plan.estimated_bytes)
    )
    per_task = max(256 * 1024**2, state_bytes * 64 + objective_bytes)
    parent_reserve = max(256 * 1024**2, state_bytes * 8 + objective_bytes)
    return per_task, parent_reserve


def _serialize_hybrid_compile_result(
    compiled: ProblemCompileResult,
) -> dict[str, Any]:
    from cascaqit.problems.compiler import ProblemHybridCompileResult

    if not isinstance(compiled, ProblemHybridCompileResult):
        raise TypeError("hybrid compile serialization requires Hybrid mode.")
    return {
        "analysis": compiled.analysis.to_dict(),
        "parameter_schema": compiled.parameter_schema.to_dict(),
        "parameter_bind": compiled.parameter_bind.to_dict(),
        "term_mapping": [item.to_dict() for item in compiled.term_mapping],
        "layers": compiled.layers,
        "diagnostics": [item.to_dict() for item in compiled.diagnostics],
        "metadata": dict(compiled.metadata),
        "compile_hash": compiled.compile_hash,
    }


def _deserialize_hybrid_compile_result(
    data: dict[str, Any],
) -> ProblemHybridCompileResult:
    from cascaqit.compiler.problem_hybrid import HybridDADLowerer
    from cascaqit.compiler.problem_mapping import ProblemTermMappingIR
    from cascaqit.diagnostics import DiagnosticsIR
    from cascaqit.parameters import ParameterBindIR, ParameterSchemaIR
    from cascaqit.problems.analysis import ProblemAnalysisResult
    from cascaqit.problems.compiler import ProblemHybridCompileResult

    analysis = ProblemAnalysisResult.from_dict(dict(data["analysis"]))
    parameter_schema = ParameterSchemaIR.from_dict(data["parameter_schema"])
    term_mapping = tuple(
        ProblemTermMappingIR.from_dict(dict(item)) for item in data["term_mapping"]
    )
    serialized_bind = ParameterBindIR.from_dict(data["parameter_bind"])
    program, parameter_bind = HybridDADLowerer().bind(
        analysis,
        parameter_schema=parameter_schema,
        term_mapping=term_mapping,
        values=serialized_bind.values,
        layers=int(data["layers"]),
    )
    compiled = ProblemHybridCompileResult(
        analysis=analysis,
        program=program,
        parameter_schema=parameter_schema,
        parameter_bind=parameter_bind,
        term_mapping=term_mapping,
        layers=int(data["layers"]),
        diagnostics=tuple(
            DiagnosticsIR.from_dict(dict(item)) for item in data["diagnostics"]
        ),
        metadata=dict(data["metadata"]),
    )
    if compiled.compile_hash != data["compile_hash"]:
        raise RuntimeError("Hybrid compile hash changed during worker restoration.")
    return compiled


def _serialize_local_backend(backend: LocalBackend) -> dict[str, Any]:
    return {
        "seed": backend.seed,
        "target": None if backend.target is None else backend.target.to_dict(),
        "analog_time_steps": backend.analog_time_steps,
        "created_at": backend.created_at,
        "backend_id": backend.backend_id,
        "kernel_threads": backend.kernel_threads,
    }


def _deserialize_local_backend(data: dict[str, Any]) -> LocalBackend:
    from cascaqit.targets import TargetSpec

    return LocalBackend(
        seed=data["seed"],
        target=(
            None
            if data["target"] is None
            else TargetSpec.from_dict(dict(data["target"]))
        ),
        analog_time_steps=int(data["analog_time_steps"]),
        created_at=data["created_at"],
        backend_id=str(data["backend_id"]),
        kernel_threads=int(data.get("kernel_threads", 1)),
    )


def _serialize_optimization_start_plan(
    plan: OptimizationStartPlan,
) -> dict[str, Any]:
    return {
        "start_index": plan.start_index,
        "seed": plan.seed,
        "initialization": plan.initialization,
        "parameters": list(plan.parameters),
    }


def _deserialize_optimization_start_plan(
    data: dict[str, Any],
) -> OptimizationStartPlan:
    return OptimizationStartPlan(
        start_index=int(data["start_index"]),
        seed=int(data["seed"]),
        initialization=data["initialization"],
        parameters=tuple(float(item) for item in data["parameters"]),
    )


def _serialize_problem_objective_evaluation(
    value: ProblemObjectiveEvaluation,
) -> dict[str, Any]:
    return {
        "objective_value": value.objective_value,
        "best_bitstring": value.best_bitstring,
        "feasible_probability": value.feasible_probability,
        "expected_constraint_violation_count": (
            value.expected_constraint_violation_count
        ),
        "best_observed_constraint_violation_count": (
            value.best_observed_constraint_violation_count
        ),
        "expected_selected_weight": value.expected_selected_weight,
        "energy_breakdown": value.energy_breakdown.to_dict(),
    }


def _deserialize_problem_objective_evaluation(
    data: dict[str, Any],
) -> ProblemObjectiveEvaluation:
    return ProblemObjectiveEvaluation(
        objective_value=float(data["objective_value"]),
        best_bitstring=str(data["best_bitstring"]),
        feasible_probability=data["feasible_probability"],
        expected_constraint_violation_count=data[
            "expected_constraint_violation_count"
        ],
        best_observed_constraint_violation_count=data[
            "best_observed_constraint_violation_count"
        ],
        expected_selected_weight=data["expected_selected_weight"],
        energy_breakdown=ProblemEnergyBreakdownIR.from_dict(
            data["energy_breakdown"]
        ),
    )


def _serialize_problem_execution_record(
    record: _ProblemExecutionRecord,
) -> dict[str, Any]:
    return {
        "context": record.context.to_dict(),
        "parameter_bind": record.parameter_bind.to_dict(),
        "result": record.result.to_dict(),
        "result_hash": record.result_hash,
        "execution_evidence": (
            None
            if record.execution_evidence is None
            else record.execution_evidence.to_dict()
        ),
        "seed": record.seed,
        "backend_job_id": record.backend_job_id,
        "metadata": dict(record.metadata),
    }


def _deserialize_problem_execution_record(
    data: dict[str, Any],
    *,
    compiled: ProblemCompileResult,
) -> _ProblemExecutionRecord:
    parameter_bind = ParameterBindIR.from_dict(data["parameter_bind"])
    result = ResultIR.from_dict(data["result"])
    result_hash = data.get("result_hash")
    if result_hash is None:
        result_hash = result.stable_hash()
    _require_digest(result_hash, "result_hash")
    bound = compiled.bind(parameter_bind.values)
    return _ProblemExecutionRecord(
        bound=bound,
        context=ProblemExecutionContextIR.from_dict(data["context"]),
        parameter_bind=parameter_bind,
        result=result,
        result_hash=result_hash,
        execution_evidence=(
            None
            if data["execution_evidence"] is None
            else ObjectiveExecutionEvidenceIR.from_dict(
                data["execution_evidence"]
            )
        ),
        seed=data["seed"],
        backend_job_id=str(data["backend_job_id"]),
        metadata=dict(data["metadata"]),
    )


def _serialize_problem_optimization_start_result(
    result: _ProblemOptimizationStartResult,
) -> dict[str, Any]:
    outcome = result.outcome
    return {
        "plan": _serialize_optimization_start_plan(result.plan),
        "outcome": {
            "initial_parameters": list(outcome.initial_parameters),
            "final_parameters": list(outcome.final_parameters),
            "final_objective": outcome.final_objective,
            "objective_values": list(outcome.objective_values),
            "best_evaluation_index": outcome.best_evaluation_index,
            "termination": outcome.termination.to_dict(),
            "gradient_values": [list(item) for item in outcome.gradient_values],
        },
        "parameter_history": [
            item.to_dict() for item in result.parameter_history
        ],
        "objective_evaluations": [
            _serialize_problem_objective_evaluation(item)
            for item in result.objective_evaluations
        ],
        "best_record": (
            None
            if result.best_record is None
            else _serialize_problem_execution_record(result.best_record)
        ),
        "executions": [item.to_dict() for item in result.executions],
        "gradients": [item.to_dict() for item in result.gradients],
    }


def _deserialize_problem_optimization_start_result(
    data: dict[str, Any],
    *,
    compiled: ProblemCompileResult,
) -> _ProblemOptimizationStartResult:
    raw_outcome = data["outcome"]
    outcome = ScalarOptimizationOutcome(
        initial_parameters=tuple(
            float(item) for item in raw_outcome["initial_parameters"]
        ),
        final_parameters=tuple(
            float(item) for item in raw_outcome["final_parameters"]
        ),
        final_objective=float(raw_outcome["final_objective"]),
        objective_values=tuple(
            float(item) for item in raw_outcome["objective_values"]
        ),
        best_evaluation_index=int(raw_outcome["best_evaluation_index"]),
        termination=OptimizerTerminationIR.from_dict(raw_outcome["termination"]),
        gradient_values=tuple(
            tuple(float(value) for value in item)
            for item in raw_outcome["gradient_values"]
        ),
    )
    return _ProblemOptimizationStartResult(
        plan=_deserialize_optimization_start_plan(data["plan"]),
        outcome=outcome,
        parameter_history=tuple(
            ProblemParameterEvaluationIR.from_dict(item)
            for item in data["parameter_history"]
        ),
        objective_evaluations=tuple(
            _deserialize_problem_objective_evaluation(item)
            for item in data["objective_evaluations"]
        ),
        best_record=(
            None
            if data["best_record"] is None
            else _deserialize_problem_execution_record(
                data["best_record"],
                compiled=compiled,
            )
        ),
        executions=tuple(
            ProblemExecutionResult.from_dict(item) for item in data["executions"]
        ),
        gradients=tuple(
            ObjectiveGradientIR.from_dict(item) for item in data["gradients"]
        ),
    )


def _validate_parallel_workers(value: WorkerRequest) -> None:
    if value == "auto":
        return
    if not isinstance(value, int) or isinstance(value, bool) or value <= 0:
        raise ValueError("parallel_workers must be 'auto' or a positive integer.")


def _build_lightweight_parameter_evaluation(
    *,
    evaluation_index: int,
    record: _ProblemExecutionRecord,
    reduced: ProblemObjectiveEvaluation,
    source_problem: QUBOProblemIR | IsingModelIR | MISInstance | MWISProblemIR,
    canonical: CanonicalProblemIR,
    baseline: ClassicalBaselineIR,
) -> ProblemParameterEvaluationIR:
    """Project one lookup result into real optimization-history evidence."""
    bitstring = reduced.best_bitstring
    candidate = decode_problem_candidate(
        source_problem,
        bitstring,
        count=(
            record.result.counts.get(bitstring)
            if bitstring in record.result.counts
            else None
        ),
        probability=_candidate_probability(record.result, bitstring),
        mis_penalty=(
            2.0
            if canonical.decoder.mis_penalty is None
            else canonical.decoder.mis_penalty
        ),
        mwis_penalty=canonical.decoder.mwis_penalty,
    )
    baseline_objective = (
        baseline.objective_value if baseline.status == "available" else None
    )
    return ProblemParameterEvaluationIR(
        evaluation_index=evaluation_index,
        parameter_bind=record.parameter_bind,
        result_id=record.result.result_id,
        result_hash=record.result_hash,
        source_program_hash=record.context.native_program_hash,
        program_hash=record.result.program_hash,
        objective_value=reduced.objective_value,
        shots=record.result.shots,
        seed=record.seed,
        best_observed_candidate=candidate,
        feasible_probability=reduced.feasible_probability,
        expected_constraint_violation_count=(
            reduced.expected_constraint_violation_count
        ),
        best_observed_constraint_violation_count=(
            reduced.best_observed_constraint_violation_count
        ),
        expected_selected_weight=reduced.expected_selected_weight,
        baseline_objective=baseline_objective,
        expected_objective_gap=(
            None
            if baseline_objective is None
            else reduced.objective_value - baseline_objective
        ),
        best_observed_objective_gap=(
            None
            if baseline_objective is None
            else candidate.objective_value - baseline_objective
        ),
        energy_breakdown=reduced.energy_breakdown,
        execution_evidence=record.execution_evidence,
        backend_job_id=record.backend_job_id,
    )


def _finalize_problem_optimization(
    compiled: ProblemCompileResult,
    *,
    executions: Sequence[ProblemExecutionResult],
    search_kind: Literal["parameter_sets", "optimizer"],
    requested_shots: int,
    effective_shots: int,
    expected_best_index: int | None = None,
    optimizer: OptimizerConfig | None = None,
    initial_parameters: Mapping[str, float] | None = None,
    final_parameters: Mapping[str, float] | None = None,
    final_objective: float | None = None,
    termination: OptimizerTerminationIR | None = None,
    starts: tuple[OptimizationStartIR, ...] = (),
    selected_start_index: int | None = None,
    gradients: tuple[ObjectiveGradientIR, ...] = (),
    parameter_history: Sequence[ProblemParameterEvaluationIR] | None = None,
    selected_record: _ProblemExecutionRecord | None = None,
    selected_objective_evaluation: ProblemObjectiveEvaluation | None = None,
) -> ProblemExecutionResult:
    """Select the best real execution and attach one typed optimization summary."""
    if parameter_history is None:
        if not executions:
            raise ValueError("optimization executions must not be empty.")
        if selected_record is not None:
            raise ValueError(
                "decoded optimization executions cannot include a selected record."
            )
        best_index = min(
            range(len(executions)),
            key=lambda index: (executions[index].objective_value, index),
        )
        best = executions[best_index]
        history = tuple(
            replace(execution.parameter_history[0], evaluation_index=index)
            for index, execution in enumerate(executions)
        )
    else:
        history = tuple(parameter_history)
        if not history:
            raise ValueError("parameter_history must not be empty.")
        if executions:
            raise ValueError(
                "lightweight parameter_history cannot be combined with executions."
            )
        if selected_record is None:
            raise ValueError(
                "lightweight parameter_history requires selected_record."
            )
        if selected_objective_evaluation is None:
            raise ValueError(
                "lightweight parameter_history requires its objective evaluation."
            )
        best_index = min(
            range(len(history)),
            key=lambda index: (history[index].objective_value, index),
        )
        best = None
    if expected_best_index is not None and expected_best_index != best_index:
        raise RuntimeError("Optimizer best index does not match Problem executions.")
    canonical = compiled.analysis.canonical_problem
    baseline = _canonical_baseline(canonical)
    summary_payload = {
        "compile_hash": compiled.compile_hash,
        "search_kind": search_kind,
        # Runtime result hashes can contain timing facts and are intentionally
        # retained in parameter_history rather than the semantic optimization id.
        # Fixed inputs and seeds therefore produce the same typed summary even
        # when two executions have different wall-clock evidence.
        "evaluations": tuple(
            {
                "evaluation_index": item.evaluation_index,
                "parameter_bind_hash": item.parameter_bind.parameter_bind_hash,
                "objective_value": item.objective_value,
                "best_observed_candidate": item.best_observed_candidate,
                "feasible_probability": item.feasible_probability,
                "expected_constraint_violation_count": (
                    item.expected_constraint_violation_count
                ),
                "best_observed_constraint_violation_count": (
                    item.best_observed_constraint_violation_count
                ),
                "baseline_objective": item.baseline_objective,
                "expected_objective_gap": item.expected_objective_gap,
                "best_observed_objective_gap": (item.best_observed_objective_gap),
                "energy_breakdown": item.energy_breakdown,
                "shots": item.shots,
                "seed": item.seed,
                "source_program_hash": item.source_program_hash,
                "execution_context": (
                    None
                    if item.execution_evidence is None
                    else {
                        "noise_model": item.execution_evidence.noise_model,
                        "requested_options": (
                            item.execution_evidence.requested_options
                        ),
                        "simulation_method": (
                            item.execution_evidence.simulation_plan.method_selected
                        ),
                        "estimator_kind": item.execution_evidence.estimator_kind,
                        "source_kind": item.execution_evidence.source_kind,
                    }
                ),
            }
            for item in history
        ),
        "best_evaluation_index": best_index,
        "optimizer": optimizer,
        "initial_parameters": initial_parameters,
        "final_parameters": final_parameters,
        "final_objective": final_objective,
        "termination": termination,
        "starts": starts,
        "selected_start_index": selected_start_index,
        "gradients": gradients,
    }
    summary_hash = hashlib.sha256(
        stable_json(summary_payload).encode("utf-8")
    ).hexdigest()
    optimization = ProblemOptimizationIR(
        optimization_id=f"problem.optimization.{summary_hash[:20]}",
        search_kind=search_kind,
        evaluation_count=len(history),
        best_evaluation_index=best_index,
        optimizer=optimizer,
        initial_parameters=initial_parameters,
        final_parameters=final_parameters,
        final_objective=final_objective,
        termination=termination,
        starts=starts,
        selected_start_index=selected_start_index,
        gradients=gradients,
    )
    optimization_hash = hashlib.sha256(
        stable_json(
            {
                "compile_hash": compiled.compile_hash,
                "history": history,
                "selected_evaluation_index": best_index,
                "optimization": optimization,
            }
        ).encode("utf-8")
    ).hexdigest()
    metadata = {
        "execution_role": (
            "parameter_set_optimization"
            if search_kind == "parameter_sets"
            else "continuous_optimization"
        ),
        "parameter_set_count": len(history),
        "optimizer_start_count": len(starts) if starts else None,
        "selected_start_index": selected_start_index,
        "selection_rule": "minimum_expected_objective_then_input_order",
        "canonical_problem_hash": canonical.problem_hash,
        "requested_shots": requested_shots,
        "effective_shots": effective_shots,
    }
    execution_id = f"problem.execution.optimize.{optimization_hash[:20]}"
    if selected_record is not None:
        return _decode_problem_execution(
            selected_record,
            objective_evaluation=selected_objective_evaluation,
            optimization_finalization=_ProblemOptimizationFinalization(
                execution_id=execution_id,
                parameter_history=history,
                selected_evaluation_index=best_index,
                optimization=optimization,
                metadata=metadata,
            ),
        )
    assert best is not None
    return replace(
        best,
        execution_id=execution_id,
        parameter_history=history,
        selected_evaluation_index=best_index,
        optimization=optimization,
        baseline=baseline,
        metadata={**best.metadata, **metadata},
        _objective_evaluation=selected_objective_evaluation,
    )


def resolve_problem_optimizer_config(
    compiled: ProblemCompileResult,
    optimizer: OptimizerConfig,
) -> OptimizerConfig:
    """Resolve complete finite bounds from explicit config or Parameter schema."""
    if not isinstance(optimizer, OptimizerConfig):
        raise TypeError("optimizer must be OptimizerConfig.")
    declarations = compiled.parameter_schema.parameters
    if optimizer.bounds:
        if len(optimizer.bounds) != len(declarations):
            raise ValueError("optimizer bounds must match Problem parameter count.")
        bounds = optimizer.bounds
    else:
        resolved: list[tuple[float, float]] = []
        for parameter in declarations:
            lower = parameter.lower_bound
            upper = parameter.upper_bound
            if parameter.name.startswith("gamma_"):
                lower = -math.pi if lower is None else lower
                upper = math.pi if upper is None else upper
            elif parameter.name.startswith("beta_"):
                lower = -math.pi / 2.0 if lower is None else lower
                upper = math.pi / 2.0 if upper is None else upper
            elif compiled.algorithm == "vqe":
                # 与 standalone VQE 保持同一默认角度域；显式 Parameter
                # 边界仍优先，用户提供的 optimizer bounds 也会在下方校验。
                lower = -math.pi if lower is None else lower
                upper = math.pi if upper is None else upper
            if lower is None or upper is None:
                raise ValueError(
                    "optimizer bounds are required when the Problem parameter "
                    f"schema does not fully bound '{parameter.name}'."
                )
            resolved.append((float(lower), float(upper)))
        bounds = tuple(resolved)

    for parameter, (lower, upper) in zip(declarations, bounds):
        if parameter.lower_bound is not None and lower < parameter.lower_bound:
            raise ValueError(
                f"optimizer lower bound for '{parameter.name}' is outside the "
                "Problem parameter schema."
            )
        if parameter.upper_bound is not None and upper > parameter.upper_bound:
            raise ValueError(
                f"optimizer upper bound for '{parameter.name}' is outside the "
                "Problem parameter schema."
            )
    return replace(optimizer, bounds=bounds)


def _problem_default_initial_parameters(
    compiled: ProblemCompileResult,
    *,
    parameter_names: tuple[str, ...],
) -> tuple[float, ...] | None:
    """Return a complete schema-default point when one is declared."""
    declarations = compiled.parameter_schema.by_name()
    if not all(declarations[name].default is not None for name in parameter_names):
        return None
    values = {
        name: float(declarations[name].default)  # type: ignore[arg-type]
        for name in parameter_names
    }
    parameter_bind = ParameterBindIR.create(
        parameter_bind_id=f"{compiled.analysis.analysis_id}.optimizer.initial",
        parameter_schema=compiled.parameter_schema,
        values=values,
        metadata={"binding_role": "continuous_optimizer_initial"},
    )
    return tuple(float(parameter_bind.values[name]) for name in parameter_names)


def _problem_optimizer_seed(
    optimizer: OptimizerConfig,
    *,
    backend: LocalBackend | None,
    seed: int | None,
) -> int:
    """Resolve one seed for initialization and every Backend evaluation."""
    if optimizer.seed is not None:
        return optimizer.seed
    if seed is not None:
        return seed
    if backend is not None and backend.seed is not None:
        return backend.seed
    return 0


def decode_problem_result(
    *,
    analysis: ProblemAnalysisResult,
    mode: str,
    algorithm: str,
    topology: str | None,
    compile_hash: str,
    context: ProblemExecutionContextIR,
    parameter_bind: ParameterBindIR,
    result: ResultIR,
    source_program_hash: str | None = None,
    execution_evidence: ObjectiveExecutionEvidenceIR | None = None,
    optimization: ProblemOptimizationIR | None = None,
    seed: int | None = None,
    backend_job_id: str | None = None,
    metadata: Mapping[str, Any] | None = None,
    _objective_evaluation: ProblemObjectiveEvaluation | None = None,
    _result_hash: str | None = None,
    _optimization_finalization: _ProblemOptimizationFinalization | None = None,
) -> ProblemExecutionResult:
    """Decode one ResultIR using shared canonical Problem facts."""
    if not isinstance(analysis, ProblemAnalysisResult):
        raise TypeError("analysis must be ProblemAnalysisResult.")
    if mode not in _MODES or algorithm not in _MODE_ALGORITHMS[mode]:
        raise ValueError("mode and algorithm do not form a supported combination.")
    _require_digest(compile_hash, "compile_hash")
    if not isinstance(context, ProblemExecutionContextIR):
        raise TypeError("context must be ProblemExecutionContextIR.")
    if context.analysis != analysis:
        raise ValueError("context analysis does not match decoder analysis.")
    if context.compile_hash != compile_hash:
        raise ValueError("context compile_hash does not match decoder input.")
    if not isinstance(parameter_bind, ParameterBindIR):
        raise TypeError("parameter_bind must be ParameterBindIR.")
    resolved_source_program_hash = (
        context.native_program_hash
        if source_program_hash is None
        else source_program_hash
    )
    _require_digest(resolved_source_program_hash, "source_program_hash")
    result_hash = result.stable_hash() if _result_hash is None else _result_hash
    _require_digest(result_hash, "result_hash")
    canonical = analysis.canonical_problem
    _validate_result(result, logical_order=canonical.logical_order)
    source_problem = _canonical_source_problem(canonical)
    ranked = _decode_result_candidates(canonical, result)
    best = min(ranked, key=lambda item: (item.objective_value, item.bitstring))
    if _objective_evaluation is None:
        objective = _expected_objective(source_problem, canonical, result)
        expected_breakdown = expected_problem_energy_breakdown(
            canonical,
            _result_weights(result),
            penalty_analysis=analysis.penalty_analysis,
        )
    else:
        _validate_objective_evaluation(
            analysis=analysis,
            best_observed_candidate=best,
            objective_value=_objective_evaluation.objective_value,
            objective_evaluation=_objective_evaluation,
        )
        objective = _objective_evaluation.objective_value
        expected_breakdown = _objective_evaluation.energy_breakdown
    if not math.isclose(
        expected_breakdown.total_objective,
        objective,
        rel_tol=_ENERGY_RELATIVE_TOLERANCE,
        abs_tol=_ENERGY_ABSOLUTE_TOLERANCE,
    ):
        raise ValueError(
            "Result objective does not match the canonical energy decomposition."
        )
    candidate_breakdowns = evaluate_problem_energy_breakdowns(
        canonical,
        (candidate.bitstring for candidate in ranked),
        penalty_analysis=analysis.penalty_analysis,
    )
    violations = _constraint_violations(canonical, best.bitstring)
    baseline = _canonical_baseline(canonical)
    metrics = _problem_evaluation_metrics(
        canonical=canonical,
        result=result,
        best_observed_candidate=best,
        baseline=baseline,
        objective_value=objective,
        objective_evaluation=_objective_evaluation,
    )
    history: tuple[ProblemParameterEvaluationIR, ...] = (
        ProblemParameterEvaluationIR(
            evaluation_index=0,
            parameter_bind=parameter_bind,
            result_id=result.result_id,
            result_hash=result_hash,
            source_program_hash=resolved_source_program_hash,
            program_hash=result.program_hash,
            objective_value=objective,
            shots=result.shots,
            seed=seed,
            best_observed_candidate=metrics.best_observed_candidate,
            feasible_probability=metrics.feasible_probability,
            expected_constraint_violation_count=(
                metrics.expected_constraint_violation_count
            ),
            best_observed_constraint_violation_count=(
                metrics.best_observed_constraint_violation_count
            ),
            expected_selected_weight=metrics.expected_selected_weight,
            baseline_objective=metrics.baseline_objective,
            expected_objective_gap=metrics.expected_objective_gap,
            best_observed_objective_gap=metrics.best_observed_objective_gap,
            energy_breakdown=expected_breakdown,
            execution_evidence=execution_evidence,
            backend_job_id=backend_job_id,
        ),
    )
    identity_hash = hashlib.sha256(
        stable_json(
            {
                "compile_hash": compile_hash,
                "parameter_bind_hash": parameter_bind.parameter_bind_hash,
                "result_hash": result_hash,
            }
        ).encode("utf-8")
    ).hexdigest()
    if _optimization_finalization is None:
        execution_id = f"problem.execution.{mode}.{identity_hash[:20]}"
        result_history = history
        selected_evaluation_index = 0
        result_optimization = optimization
        optimization_metadata: Mapping[str, Any] = {}
    else:
        if optimization is not None:
            raise ValueError(
                "optimization and internal optimization finalization are exclusive."
            )
        execution_id = _optimization_finalization.execution_id
        result_history = _optimization_finalization.parameter_history
        selected_evaluation_index = (
            _optimization_finalization.selected_evaluation_index
        )
        result_optimization = _optimization_finalization.optimization
        optimization_metadata = _optimization_finalization.metadata
    return ProblemExecutionResult(
        execution_id=execution_id,
        mode=mode,  # type: ignore[arg-type]
        algorithm=algorithm,  # type: ignore[arg-type]
        topology=topology,
        compile_hash=compile_hash,
        analysis_hash=analysis.analysis_hash,
        problem_hash=canonical.problem_hash,
        logical_order=canonical.logical_order,
        context=context,
        parameter_bind=parameter_bind,
        parameter_bind_hash=parameter_bind.parameter_bind_hash,
        result=result,
        candidates=ranked,
        most_probable_candidate=ranked[0],
        best_observed_candidate=best,
        objective_value=objective,
        feasibility=best.feasible,
        constraint_violations=violations,
        candidate_energy_breakdowns=candidate_breakdowns,
        parameter_history=result_history,
        selected_evaluation_index=selected_evaluation_index,
        cardinality_subspace=(
            None
            if context.ansatz is None
            else build_cardinality_subspace_evidence(context.ansatz, result)
        ),
        optimization=result_optimization,
        baseline=baseline,
        metadata={
            "decoder_id": canonical.decoder.decoder_id,
            "decoder_kind": canonical.decoder.decoder_kind,
            "objective_direction": canonical.objective_direction,
            "objective_estimator": (
                "result_probabilities"
                if result.probabilities is not None
                else "sample_counts"
            ),
            **({} if metadata is None else dict(metadata)),
            **dict(optimization_metadata),
        },
        _objective_evaluation=_objective_evaluation,
    )


def _bound_compile_result(
    compiled: ProblemCompileResult,
    *,
    params: Mapping[str, float] | None,
) -> ProblemCompileResult:
    if params is None:
        if getattr(compiled, "parameter_bind", None) is None:
            raise ValueError("params are required for an unbound compile result.")
        return compiled
    if not isinstance(params, Mapping):
        raise TypeError("params must be a mapping or None.")
    current = getattr(compiled, "parameter_bind", None)
    if compiled.mode == "digital" and current is not None:
        if dict(current.values) == dict(params):
            return compiled
        raise ValueError("A bound Digital compile result cannot use different params.")
    return compiled.bind(params)


def _execution_backend(
    compiled: ProblemCompileResult,
    *,
    backend: LocalBackend | None,
    seed: int | None,
) -> LocalBackend:
    if backend is not None:
        if not isinstance(backend, LocalBackend):
            raise TypeError("backend must be LocalBackend or None.")
        return backend
    target = getattr(compiled, "target", None)
    return LocalBackend(seed=seed, target=target)


def _execution_program(
    compiled: ProblemCompileResult,
) -> Circuit | AHSProgram | HybridProgram:
    if compiled.mode != "digital":
        if not isinstance(compiled.program, (AHSProgram, HybridProgram)):
            raise TypeError("Analog or Hybrid compile result has an invalid program.")
        return compiled.program
    program = compiled.program
    parameter_bind = compiled.parameter_bind
    if not isinstance(program, Circuit):
        raise TypeError("Digital compile result must contain a Circuit.")
    if parameter_bind is None:
        raise ValueError("Digital execution requires a bound compile result.")
    # QAOA circuits remain reusable and measurement-free in the compile result.
    # Execution gets a fresh terminal-measurement wrapper with explicit lineage.
    measured = Circuit(
        program.qubits,
        program_id=(
            f"program.problem.{compiled.compile_hash[:12]}."
            f"{parameter_bind.parameter_bind_hash[:12]}"
        ),
        metadata={
            "execution_role": "problem_sampling",
            "source_program_id": program.program_id,
            "compile_hash": compiled.compile_hash,
            "parameter_bind_hash": parameter_bind.parameter_bind_hash,
        },
    ).compose(program)
    measured.measure_all(key="problem")
    return measured


def _validate_result(result: ResultIR, *, logical_order: tuple[str, ...]) -> None:
    if not isinstance(result, ResultIR):
        raise TypeError("result must be ResultIR.")
    _require_text(result.result_id, "result.result_id")
    _require_digest(result.program_hash, "result.program_hash")
    _non_negative_int(result.shots, "result.shots")
    declared_order = _declared_result_order(result)
    if declared_order != logical_order:
        raise ValueError("Result logical order does not match the compiled Problem.")
    if (
        result.occupation_encoding.ground != 0
        or result.occupation_encoding.rydberg != 1
    ):
        raise ValueError("Result occupation encoding does not match Problem bits.")
    for bitstring, count in result.counts.items():
        _validate_bitstring(bitstring, logical_order)
        if not isinstance(count, int) or isinstance(count, bool) or count <= 0:
            raise ValueError("Result counts must contain positive integers.")
    if sum(result.counts.values()) != result.shots:
        raise ValueError("Result counts must sum to shots.")
    if len(result.samples) != result.shots:
        raise ValueError("Result samples must contain one entry per shot.")
    for bitstring in result.samples:
        _validate_bitstring(bitstring, logical_order)
    if Counter(result.samples) != Counter(result.counts):
        raise ValueError("Result samples must reproduce the declared counts.")
    if result.probabilities is not None:
        probability_mass = 0.0
        for bitstring, probability in result.probabilities.items():
            _validate_bitstring(bitstring, logical_order)
            value = _finite(probability, "result probability")
            if value < 0.0 or value > 1.0 + _PROBABILITY_TOLERANCE:
                raise ValueError("Result probabilities must be within [0, 1].")
            probability_mass += value
        if not math.isclose(
            probability_mass,
            1.0,
            rel_tol=0.0,
            abs_tol=_PROBABILITY_TOLERANCE,
        ):
            raise ValueError("Result probabilities must sum to one.")
    if not result.counts and not result.probabilities:
        raise ValueError("Result must contain counts or probabilities for decoding.")


def _declared_result_order(result: ResultIR) -> tuple[str, ...]:
    metadata = result.metadata.get("bitstring_ordering")
    if isinstance(metadata, Mapping):
        for key in ("logical_order", "qubit_order"):
            value = metadata.get(key)
            if isinstance(value, (list, tuple)) and all(
                isinstance(item, str) for item in value
            ):
                return tuple(value)
    for key in ("logical_order", "qubits"):
        value = result.bit_ordering.get(key)
        if isinstance(value, str) and value:
            return tuple(value.split(","))
        if isinstance(value, (list, tuple)) and all(
            isinstance(item, str) for item in value
        ):
            return tuple(value)
    raise ValueError("Result does not declare a usable logical order.")


def _candidate_bitstrings(result: ResultIR) -> tuple[str, ...]:
    if result.counts:
        return tuple(sorted(result.counts))
    assert result.probabilities is not None
    observed = tuple(
        sorted(
            bitstring
            for bitstring, probability in result.probabilities.items()
            if probability > _PROBABILITY_TOLERANCE
        )
    )
    if not observed:
        raise ValueError("Result probabilities do not contain a non-zero candidate.")
    return observed


def _candidate_probability(result: ResultIR, bitstring: str) -> float:
    if result.probabilities is not None:
        return float(result.probabilities.get(bitstring, 0.0))
    return result.counts[bitstring] / result.shots


def _candidate_rank(candidate: AlgorithmCandidateIR) -> tuple[int, float, str]:
    return (
        0 if candidate.count is None else -candidate.count,
        -float(0.0 if candidate.probability is None else candidate.probability),
        candidate.bitstring,
    )


def _expected_objective(
    source_problem: QUBOProblemIR | IsingModelIR | MISInstance | MWISProblemIR,
    canonical: CanonicalProblemIR,
    result: ResultIR,
) -> float:
    if result.probabilities is not None:
        weights: Iterable[tuple[str, float]] = result.probabilities.items()
    else:
        weights = (
            (bitstring, count / result.shots)
            for bitstring, count in result.counts.items()
        )
    return float(
        sum(
            probability
            * decode_problem_candidate(
                source_problem,
                bitstring,
                mis_penalty=(
                    2.0
                    if canonical.decoder.mis_penalty is None
                    else canonical.decoder.mis_penalty
                ),
                mwis_penalty=canonical.decoder.mwis_penalty,
            ).objective_value
            for bitstring, probability in weights
        )
    )


def _result_weights(result: ResultIR) -> tuple[tuple[str, float], ...]:
    """Return the complete normalized distribution used by objective evidence."""
    if result.probabilities is not None:
        return tuple(
            (bitstring, float(probability))
            for bitstring, probability in result.probabilities.items()
        )
    return tuple(
        (bitstring, count / result.shots) for bitstring, count in result.counts.items()
    )


def _constraint_violations(
    canonical: CanonicalProblemIR,
    bitstring: str,
) -> tuple[str, ...]:
    values = dict(zip(canonical.logical_order, (int(bit) for bit in bitstring)))
    return tuple(
        constraint.constraint_id
        for constraint in canonical.constraints
        if (
            sum(
                term.coefficient * values[term.variable]
                for term in constraint.linear_terms
            )
            > constraint.rhs
        )
    )


def _problem_evaluation_metrics(
    *,
    canonical: CanonicalProblemIR,
    result: ResultIR,
    best_observed_candidate: AlgorithmCandidateIR,
    baseline: ClassicalBaselineIR | None,
    objective_value: float,
    objective_evaluation: ProblemObjectiveEvaluation | None = None,
) -> _ProblemEvaluationMetrics:
    """Derive optimization metrics from the complete result distribution."""
    feasible_probability: float | None = None
    expected_violation_count: float | None = None
    best_violation_count: int | None = None
    expected_selected_weight: float | None = None
    if objective_evaluation is not None:
        feasible_probability = objective_evaluation.feasible_probability
        expected_violation_count = (
            objective_evaluation.expected_constraint_violation_count
        )
        best_violation_count = (
            objective_evaluation.best_observed_constraint_violation_count
        )
        expected_selected_weight = objective_evaluation.expected_selected_weight
    elif canonical.decoder.decoder_kind in {"mis", "mwis"}:
        if result.probabilities is not None:
            weights = tuple(result.probabilities.items())
        else:
            weights = tuple(
                (bitstring, count / result.shots)
                for bitstring, count in result.counts.items()
            )
        feasible_mass = 0.0
        violation_mass = 0.0
        for bitstring, probability in weights:
            violation_count = len(_constraint_violations(canonical, bitstring))
            if violation_count == 0:
                feasible_mass += probability
            violation_mass += probability * violation_count
        feasible_probability = min(max(float(feasible_mass), 0.0), 1.0)
        expected_violation_count = float(violation_mass)
        best_violation_count = len(
            _constraint_violations(canonical, best_observed_candidate.bitstring)
        )
        if canonical.decoder.decoder_kind == "mwis":
            node_weights = dict(canonical.decoder.node_weights)
            expected_selected_weight = float(
                sum(
                    probability
                    * sum(
                        node_weights[node] * int(bit)
                        for node, bit in zip(canonical.logical_order, bitstring)
                    )
                    for bitstring, probability in weights
                )
            )

    baseline_objective = (
        None
        if baseline is None or baseline.status != "available"
        else baseline.objective_value
    )
    if baseline_objective is None:
        expected_gap = None
        best_gap = None
    else:
        expected_gap = objective_value - baseline_objective
        best_gap = best_observed_candidate.objective_value - baseline_objective
    return _ProblemEvaluationMetrics(
        best_observed_candidate=best_observed_candidate,
        feasible_probability=feasible_probability,
        expected_constraint_violation_count=expected_violation_count,
        best_observed_constraint_violation_count=best_violation_count,
        expected_selected_weight=expected_selected_weight,
        baseline_objective=baseline_objective,
        expected_objective_gap=expected_gap,
        best_observed_objective_gap=best_gap,
    )


def _validate_objective_evaluation(
    *,
    analysis: ProblemAnalysisResult,
    best_observed_candidate: AlgorithmCandidateIR,
    objective_value: float,
    objective_evaluation: ProblemObjectiveEvaluation,
) -> None:
    """Reject stale or structurally incompatible request-local reductions."""
    if not isinstance(objective_evaluation, ProblemObjectiveEvaluation):
        raise TypeError(
            "_objective_evaluation must be ProblemObjectiveEvaluation or None."
        )
    if objective_evaluation.best_bitstring != best_observed_candidate.bitstring:
        raise ValueError(
            "Lightweight best bitstring does not match selected Problem decoding."
        )
    if not math.isclose(
        objective_evaluation.objective_value,
        objective_value,
        rel_tol=_ENERGY_RELATIVE_TOLERANCE,
        abs_tol=_ENERGY_ABSOLUTE_TOLERANCE,
    ):
        raise ValueError(
            "Lightweight objective does not match selected Problem decoding."
        )
    breakdown = objective_evaluation.energy_breakdown
    if not math.isclose(
        breakdown.total_objective,
        objective_evaluation.objective_value,
        rel_tol=_ENERGY_RELATIVE_TOLERANCE,
        abs_tol=_ENERGY_ABSOLUTE_TOLERANCE,
    ):
        raise ValueError(
            "Lightweight objective does not match its canonical energy breakdown."
        )
    penalty_analysis = analysis.penalty_analysis
    expected_penalties = (
        ()
        if penalty_analysis is None
        else tuple(
            (
                term.constraint_id,
                term.canonical_term_id,
                term.targets,
                term.coefficient,
            )
            for term in penalty_analysis.penalty_terms
        )
    )
    actual_penalties = tuple(
        (
            item.constraint_id,
            item.canonical_term_id,
            item.targets,
            item.coefficient,
        )
        for item in breakdown.constraint_penalties
    )
    if actual_penalties != expected_penalties:
        raise ValueError(
            "Lightweight energy breakdown does not match Problem penalty analysis."
        )
    expected_penalty_status = (
        "defined" if penalty_analysis is not None else "not_applicable"
    )
    if breakdown.penalty_model_status != expected_penalty_status:
        raise ValueError(
            "Lightweight energy breakdown does not match Problem penalty status."
        )
    decoder_kind = analysis.canonical_problem.decoder.decoder_kind
    if decoder_kind not in {"mis", "mwis"} and any(
        value is not None
        for value in (
            objective_evaluation.feasible_probability,
            objective_evaluation.expected_constraint_violation_count,
            objective_evaluation.best_observed_constraint_violation_count,
            objective_evaluation.expected_selected_weight,
        )
    ):
        raise ValueError(
            "Lightweight graph metrics do not match the Problem decoder."
        )
    if (
        decoder_kind == "mis"
        and objective_evaluation.expected_selected_weight is not None
    ):
        raise ValueError(
            "Lightweight selected weight does not match the MIS decoder."
        )
    if decoder_kind in {"mis", "mwis"}:
        best_violation_count = len(
            _constraint_violations(
                analysis.canonical_problem,
                best_observed_candidate.bitstring,
            )
        )
        if (
            objective_evaluation.best_observed_constraint_violation_count
            != best_violation_count
        ):
            raise ValueError(
                "Lightweight best violation count does not match Problem decoding."
            )


def _canonical_source_problem(
    canonical: CanonicalProblemIR,
) -> QUBOProblemIR | IsingModelIR | MISInstance | MWISProblemIR:
    metadata = {
        "source_problem_id": canonical.problem_id,
        "source_problem_hash": canonical.problem_hash,
        "source_problem_type": canonical.problem_type,
    }
    if canonical.decoder.decoder_kind == "mis":
        positions = dict(canonical.layout_hints)
        return MISInstance(
            node_positions=tuple(
                (
                    name,
                    positions.get(name, (float(index), 0.0)),
                )
                for index, name in enumerate(canonical.logical_order)
            ),
            edges=canonical.decoder.edges,
            metadata=metadata,
        )
    if canonical.decoder.decoder_kind == "mwis":
        return MWISProblemIR(
            problem_id=canonical.problem_id,
            nodes=canonical.logical_order,
            node_weights=canonical.decoder.node_weights,
            edges=canonical.decoder.edges,
            node_positions=canonical.layout_hints,
            metadata=metadata,
        )
    if canonical.decoder.decoder_kind == "qubo":
        return QUBOProblemIR(
            problem_id=canonical.problem_id,
            variables=canonical.logical_order,
            linear_terms=tuple(
                (term.variable, term.coefficient) for term in canonical.linear_terms
            ),
            quadratic_terms=tuple(
                (term.left, term.right, term.coefficient)
                for term in canonical.quadratic_terms
            ),
            offset=canonical.offset,
            metadata=metadata,
        )
    return IsingModelIR(
        problem_id=canonical.problem_id,
        spins=canonical.logical_order,
        fields=tuple(
            (term.variable, term.coefficient) for term in canonical.linear_terms
        ),
        couplings=tuple(
            (term.left, term.right, term.coefficient)
            for term in canonical.quadratic_terms
        ),
        offset=canonical.offset,
        metadata=metadata,
    )


def _canonical_baseline(canonical: CanonicalProblemIR) -> ClassicalBaselineIR:
    return bounded_exhaustive_baseline(
        _canonical_source_problem(canonical),
        mis_penalty=(
            2.0
            if canonical.decoder.mis_penalty is None
            else canonical.decoder.mis_penalty
        ),
        mwis_penalty=canonical.decoder.mwis_penalty,
    )


def _decode_result_candidates(
    canonical: CanonicalProblemIR,
    result: ResultIR,
) -> tuple[AlgorithmCandidateIR, ...]:
    """从原始 Result 分布重建候选，序列化候选不作为事实源。"""
    source_problem = _canonical_source_problem(canonical)
    candidates = tuple(
        decode_problem_candidate(
            source_problem,
            bitstring,
            count=(
                result.counts.get(bitstring) if bitstring in result.counts else None
            ),
            probability=_candidate_probability(result, bitstring),
            mis_penalty=(
                2.0
                if canonical.decoder.mis_penalty is None
                else canonical.decoder.mis_penalty
            ),
            mwis_penalty=canonical.decoder.mwis_penalty,
        )
        for bitstring in _candidate_bitstrings(result)
    )
    return tuple(sorted(candidates, key=_candidate_rank))


def _validate_bitstring(bitstring: object, logical_order: tuple[str, ...]) -> None:
    if (
        not isinstance(bitstring, str)
        or len(bitstring) != len(logical_order)
        or str.strip(bitstring, "01")
    ):
        raise ValueError("Result bitstrings must match the Problem logical order.")


def _result_seed(result: ResultIR, *, fallback: int | None) -> int | None:
    value = result.metadata.get("seed", fallback)
    _optional_seed(value)
    return value


def _require_digest(value: object, name: str) -> None:
    if not isinstance(value, str) or _DIGEST_PATTERN.fullmatch(value) is None:
        raise ValueError(f"{name} must be a lowercase SHA-256 digest.")


def _require_execution_schema(value: object) -> None:
    if value != PROBLEM_EXECUTION_SCHEMA_VERSION:
        raise ValueError(
            "Unsupported Problem execution schema_version: "
            f"{value!r}; expected {PROBLEM_EXECUTION_SCHEMA_VERSION!r}."
        )


def _require_text(value: object, name: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{name} must be a non-empty string.")


def _require_unique_text(
    values: tuple[str, ...],
    name: str,
    *,
    allow_empty: bool = False,
) -> None:
    if not values and not allow_empty:
        raise ValueError(f"{name} must not be empty.")
    if any(not isinstance(value, str) or not value.strip() for value in values):
        raise ValueError(f"{name} must contain non-empty strings.")
    if len(values) != len(set(values)):
        raise ValueError(f"{name} must be unique.")


def _non_negative_int(value: object, name: str) -> None:
    if not isinstance(value, int) or isinstance(value, bool) or value < 0:
        raise ValueError(f"{name} must be a non-negative integer.")


def _optional_seed(value: object) -> None:
    if value is not None and (
        not isinstance(value, int) or isinstance(value, bool) or value < 0
    ):
        raise ValueError("seed must be a non-negative integer or None.")


def _finite(value: object, name: str) -> float:
    if type(value) is float:
        if not math.isfinite(value):
            raise ValueError(f"{name} must be finite.")
        return value
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        raise TypeError(f"{name} must be a real number.")
    normalized = float(value)
    if not math.isfinite(normalized):
        raise ValueError(f"{name} must be finite.")
    return normalized


def _finite_parameter_mapping(value: object, name: str) -> dict[str, float]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{name} must be an object.")
    normalized: dict[str, float] = {}
    for raw_name, raw_value in value.items():
        parameter_name = str(raw_name)
        _require_text(parameter_name, f"{name} key")
        if parameter_name in normalized:
            raise ValueError(f"{name} contains duplicate parameter names.")
        normalized[parameter_name] = _finite(
            raw_value,
            f"{name}[{parameter_name}]",
        )
    return normalized


def _mapping(value: object, name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{name} must be an object.")
    return value


def _sequence(value: object, name: str) -> Sequence[Any]:
    if not isinstance(value, (list, tuple)):
        raise TypeError(f"{name} must be an array.")
    return value
