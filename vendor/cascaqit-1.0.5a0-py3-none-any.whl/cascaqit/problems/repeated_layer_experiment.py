"""Repeated Problem layer experiments with auditable statistical selection."""

from __future__ import annotations

import hashlib
import json
import math
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field, replace
from os import PathLike
from typing import TYPE_CHECKING, Any, Literal

from cascaqit.algorithms import (
    OptimizerConfig,
    PauliMeasurementConfig,
    SampledSelectionConfig,
)
from cascaqit.algorithms._layer_statistics import (
    LayerSampleSummary as _SampleSummary,
)
from cascaqit.algorithms._layer_statistics import (
    confidence_level as _shared_confidence_level,
)
from cascaqit.algorithms._layer_statistics import (
    derive_layer_run_seed,
    paired_improvement_summary,
    sample_summary,
)
from cascaqit.algorithms.ansatz import transfer_vqe_parameters
from cascaqit.algorithms.optimizer import build_optimization_start_plans
from cascaqit.native_ir.base import IRMixin, stable_json
from cascaqit.problems.execution import ProblemExecutionResult
from cascaqit.problems.layer_experiment import (
    PROBLEM_LAYER_OBJECTIVE_TOLERANCE,
    _execution_layers,
)

if TYPE_CHECKING:
    from cascaqit.visualization import ExperimentReport

__all__ = [
    "PROBLEM_REPEATED_LAYER_EXPERIMENT_SCHEMA_VERSION",
    "ProblemLayerStatisticsIR",
    "ProblemPairedImprovementIR",
    "ProblemRepeatedLayerExperimentResult",
    "ProblemRepeatedLayerRunIR",
    "ProblemRepeatedLayerStepIR",
    "build_problem_repeated_layer_experiment_result",
    "derive_problem_layer_run_seed",
]

PROBLEM_REPEATED_LAYER_EXPERIMENT_SCHEMA_VERSION = (
    "cascaqit.problem.repeated_layer_experiment.v2"
)
_DIGEST_LENGTH = 64
_STATISTIC_TOLERANCE = 1e-12


def problem_layer_objective(execution: ProblemExecutionResult) -> float:
    """Return the estimator used to compare one completed Problem layer run."""
    optimization = execution.optimization
    if optimization is not None and optimization.sampled_selection is not None:
        return optimization.sampled_selection.selected_candidate.energy
    return execution.objective_value


@dataclass(frozen=True)
class ProblemRepeatedLayerRunIR(IRMixin):
    """One complete optimizer run within a repeated layer experiment."""

    run_id: str
    layers: int
    repeat_index: int
    seed: int
    execution: ProblemExecutionResult
    schema_version: str = PROBLEM_REPEATED_LAYER_EXPERIMENT_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_schema(self.schema_version)
        _positive_int(self.layers, "layers")
        _non_negative_int(self.repeat_index, "repeat_index")
        _non_negative_int(self.seed, "seed")
        if not isinstance(self.execution, ProblemExecutionResult):
            raise TypeError("execution must be ProblemExecutionResult.")
        if _execution_layers(self.execution) != self.layers:
            raise ValueError("run execution layer count does not match layers.")
        expected_id = _run_id(
            layers=self.layers,
            repeat_index=self.repeat_index,
            seed=self.seed,
            execution_hash=self.execution.execution_hash,
        )
        if self.run_id != expected_id:
            raise ValueError("run_id does not match the repeated run facts.")

    @classmethod
    def create(
        cls,
        *,
        layers: int,
        repeat_index: int,
        seed: int,
        execution: ProblemExecutionResult,
    ) -> ProblemRepeatedLayerRunIR:
        """Create one run with a deterministic identity."""
        return cls(
            run_id=_run_id(
                layers=layers,
                repeat_index=repeat_index,
                seed=seed,
                execution_hash=execution.execution_hash,
            ),
            layers=layers,
            repeat_index=repeat_index,
            seed=seed,
            execution=execution,
        )

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ProblemRepeatedLayerRunIR:
        """Restore one repeated run from JSON-compatible data."""
        return cls(
            run_id=str(data["run_id"]),
            layers=int(data["layers"]),
            repeat_index=int(data["repeat_index"]),
            seed=int(data["seed"]),
            execution=ProblemExecutionResult.from_dict(
                _mapping(data["execution"], "execution")
            ),
            schema_version=str(
                data.get(
                    "schema_version",
                    PROBLEM_REPEATED_LAYER_EXPERIMENT_SCHEMA_VERSION,
                )
            ),
        )


@dataclass(frozen=True)
class ProblemLayerStatisticsIR(IRMixin):
    """Sample statistics recomputed from all optimizer runs at one layer."""

    layers: int
    runs: tuple[ProblemRepeatedLayerRunIR, ...]
    sample_count: int
    mean_objective: float
    sample_variance: float
    standard_error: float
    confidence_level: float
    confidence_interval_low: float
    confidence_interval_high: float
    schema_version: str = PROBLEM_REPEATED_LAYER_EXPERIMENT_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_schema(self.schema_version)
        _positive_int(self.layers, "layers")
        object.__setattr__(self, "runs", tuple(self.runs))
        if len(self.runs) < 2:
            raise ValueError("layer statistics require at least two repeated runs.")
        if any(not isinstance(run, ProblemRepeatedLayerRunIR) for run in self.runs):
            raise TypeError("runs must contain ProblemRepeatedLayerRunIR values.")
        if any(run.layers != self.layers for run in self.runs):
            raise ValueError("all repeated runs must match statistics layers.")
        if tuple(run.repeat_index for run in self.runs) != tuple(
            range(len(self.runs))
        ):
            raise ValueError("run repeat_index values must be contiguous from zero.")
        if len({run.seed for run in self.runs}) != len(self.runs):
            raise ValueError("run seeds must be unique within one layer.")
        level = _confidence_level(self.confidence_level)
        object.__setattr__(self, "confidence_level", level)
        expected = _sample_summary(self.objectives, confidence_level=level)
        if self.sample_count != len(self.runs):
            raise ValueError("sample_count does not match runs.")
        _require_statistic(self.mean_objective, expected.mean, "mean_objective")
        _require_statistic(
            self.sample_variance,
            expected.variance,
            "sample_variance",
        )
        _require_statistic(
            self.standard_error,
            expected.standard_error,
            "standard_error",
        )
        _require_statistic(
            self.confidence_interval_low,
            expected.interval_low,
            "confidence_interval_low",
        )
        _require_statistic(
            self.confidence_interval_high,
            expected.interval_high,
            "confidence_interval_high",
        )

    @classmethod
    def create(
        cls,
        runs: Sequence[ProblemRepeatedLayerRunIR],
        *,
        confidence_level: float,
    ) -> ProblemLayerStatisticsIR:
        """Build checked statistics from completed repeated runs."""
        normalized = tuple(runs)
        if not normalized:
            raise ValueError("runs must not be empty.")
        summary = _sample_summary(
            tuple(problem_layer_objective(run.execution) for run in normalized),
            confidence_level=_confidence_level(confidence_level),
        )
        return cls(
            layers=normalized[0].layers,
            runs=normalized,
            sample_count=len(normalized),
            mean_objective=summary.mean,
            sample_variance=summary.variance,
            standard_error=summary.standard_error,
            confidence_level=float(confidence_level),
            confidence_interval_low=summary.interval_low,
            confidence_interval_high=summary.interval_high,
        )

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ProblemLayerStatisticsIR:
        """Restore layer statistics and recheck every derived value."""
        return cls(
            layers=int(data["layers"]),
            runs=tuple(
                ProblemRepeatedLayerRunIR.from_dict(_mapping(item, "run"))
                for item in _sequence(data["runs"], "runs")
            ),
            sample_count=int(data["sample_count"]),
            mean_objective=float(data["mean_objective"]),
            sample_variance=float(data["sample_variance"]),
            standard_error=float(data["standard_error"]),
            confidence_level=float(data["confidence_level"]),
            confidence_interval_low=float(data["confidence_interval_low"]),
            confidence_interval_high=float(data["confidence_interval_high"]),
            schema_version=str(
                data.get(
                    "schema_version",
                    PROBLEM_REPEATED_LAYER_EXPERIMENT_SCHEMA_VERSION,
                )
            ),
        )

    @property
    def objectives(self) -> tuple[float, ...]:
        """Return the independently comparable objective for every repeat."""
        return tuple(problem_layer_objective(run.execution) for run in self.runs)


@dataclass(frozen=True)
class ProblemPairedImprovementIR(IRMixin):
    """Paired objective decrease from an incumbent to a candidate layer."""

    incumbent_layer: int
    candidate_layer: int
    differences: tuple[float, ...]
    sample_count: int
    mean_improvement: float
    sample_variance: float
    standard_error: float
    confidence_level: float
    lower_confidence_bound: float
    schema_version: str = PROBLEM_REPEATED_LAYER_EXPERIMENT_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_schema(self.schema_version)
        _positive_int(self.incumbent_layer, "incumbent_layer")
        _positive_int(self.candidate_layer, "candidate_layer")
        if self.incumbent_layer >= self.candidate_layer:
            raise ValueError("incumbent_layer must be shallower than candidate_layer.")
        object.__setattr__(
            self,
            "differences",
            tuple(_finite(value, "difference") for value in self.differences),
        )
        if len(self.differences) < 2:
            raise ValueError("paired improvement requires at least two differences.")
        level = _confidence_level(self.confidence_level)
        object.__setattr__(self, "confidence_level", level)
        expected = _paired_summary(
            self.differences,
            confidence_level=level,
        )
        if self.sample_count != len(self.differences):
            raise ValueError("sample_count does not match paired differences.")
        _require_statistic(
            self.mean_improvement,
            expected.mean,
            "mean_improvement",
        )
        _require_statistic(
            self.sample_variance,
            expected.variance,
            "sample_variance",
        )
        _require_statistic(
            self.standard_error,
            expected.standard_error,
            "standard_error",
        )
        _require_statistic(
            self.lower_confidence_bound,
            expected.interval_low,
            "lower_confidence_bound",
        )

    @classmethod
    def create(
        cls,
        incumbent: ProblemLayerStatisticsIR,
        candidate: ProblemLayerStatisticsIR,
        *,
        confidence_level: float,
    ) -> ProblemPairedImprovementIR:
        """Compare two layers by matching their stable repeat indices."""
        if not isinstance(incumbent, ProblemLayerStatisticsIR) or not isinstance(
            candidate, ProblemLayerStatisticsIR
        ):
            raise TypeError("incumbent and candidate must be layer statistics.")
        if incumbent.layers >= candidate.layers:
            raise ValueError("incumbent must be shallower than candidate.")
        if incumbent.sample_count != candidate.sample_count:
            raise ValueError("paired layers must have the same sample count.")
        differences = tuple(
            left - right
            for left, right in zip(incumbent.objectives, candidate.objectives)
        )
        summary = _paired_summary(
            differences,
            confidence_level=_confidence_level(confidence_level),
        )
        return cls(
            incumbent_layer=incumbent.layers,
            candidate_layer=candidate.layers,
            differences=differences,
            sample_count=len(differences),
            mean_improvement=summary.mean,
            sample_variance=summary.variance,
            standard_error=summary.standard_error,
            confidence_level=float(confidence_level),
            lower_confidence_bound=summary.interval_low,
        )

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ProblemPairedImprovementIR:
        """Restore paired evidence and recheck its statistics."""
        return cls(
            incumbent_layer=int(data["incumbent_layer"]),
            candidate_layer=int(data["candidate_layer"]),
            differences=tuple(float(item) for item in data["differences"]),
            sample_count=int(data["sample_count"]),
            mean_improvement=float(data["mean_improvement"]),
            sample_variance=float(data["sample_variance"]),
            standard_error=float(data["standard_error"]),
            confidence_level=float(data["confidence_level"]),
            lower_confidence_bound=float(data["lower_confidence_bound"]),
            schema_version=str(
                data.get(
                    "schema_version",
                    PROBLEM_REPEATED_LAYER_EXPERIMENT_SCHEMA_VERSION,
                )
            ),
        )


@dataclass(frozen=True)
class ProblemRepeatedLayerStepIR(IRMixin):
    """One layer's repeated evidence and the resulting selection state."""

    layers: int
    statistics: ProblemLayerStatisticsIR
    comparison: ProblemPairedImprovementIR | None
    material_improvement: bool
    incumbent_layer: int
    no_improvement_count: int
    schema_version: str = PROBLEM_REPEATED_LAYER_EXPERIMENT_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_schema(self.schema_version)
        _positive_int(self.layers, "layers")
        if not isinstance(self.statistics, ProblemLayerStatisticsIR):
            raise TypeError("statistics must be ProblemLayerStatisticsIR.")
        if self.statistics.layers != self.layers:
            raise ValueError("statistics layer count does not match step layers.")
        if self.comparison is not None and not isinstance(
            self.comparison, ProblemPairedImprovementIR
        ):
            raise TypeError("comparison must be ProblemPairedImprovementIR or None.")
        if not isinstance(self.material_improvement, bool):
            raise TypeError("material_improvement must be boolean.")
        _positive_int(self.incumbent_layer, "incumbent_layer")
        if self.incumbent_layer > self.layers:
            raise ValueError("incumbent_layer cannot exceed the executed layer.")
        _non_negative_int(self.no_improvement_count, "no_improvement_count")

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ProblemRepeatedLayerStepIR:
        """Restore one repeated layer step."""
        raw_comparison = data.get("comparison")
        return cls(
            layers=int(data["layers"]),
            statistics=ProblemLayerStatisticsIR.from_dict(
                _mapping(data["statistics"], "statistics")
            ),
            comparison=(
                None
                if raw_comparison is None
                else ProblemPairedImprovementIR.from_dict(
                    _mapping(raw_comparison, "comparison")
                )
            ),
            material_improvement=data["material_improvement"],
            incumbent_layer=int(data["incumbent_layer"]),
            no_improvement_count=int(data["no_improvement_count"]),
            schema_version=str(
                data.get(
                    "schema_version",
                    PROBLEM_REPEATED_LAYER_EXPERIMENT_SCHEMA_VERSION,
                )
            ),
        )


@dataclass(frozen=True)
class ProblemRepeatedLayerExperimentResult(IRMixin):
    """Completed repeated layer search with fully recomputable evidence."""

    experiment_id: str
    mode: Literal["digital", "hybrid"]
    algorithm: Literal["qaoa", "vqe"]
    problem_hash: str
    analysis_hash: str
    target_hash: str
    logical_order: tuple[str, ...]
    optimizer: OptimizerConfig
    max_layers: int
    repeats: int
    confidence_level: float
    min_improvement: float
    patience: int
    requested_shots: int
    seed: int
    measurement: PauliMeasurementConfig | None
    sampled_selection: SampledSelectionConfig | None
    steps: tuple[ProblemRepeatedLayerStepIR, ...]
    selected_step_index: int
    stop_reason: Literal["max_layers_reached", "patience_exhausted"]
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = PROBLEM_REPEATED_LAYER_EXPERIMENT_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_schema(self.schema_version)
        _require_text(self.experiment_id, "experiment_id")
        if self.mode not in {"digital", "hybrid"}:
            raise ValueError("repeated layer experiments require digital or hybrid.")
        if self.algorithm not in {"qaoa", "vqe"}:
            raise ValueError("repeated layer experiments require qaoa or vqe.")
        if self.mode == "hybrid" and self.algorithm != "qaoa":
            raise ValueError("hybrid repeated layer experiments require qaoa.")
        for value, name in (
            (self.problem_hash, "problem_hash"),
            (self.analysis_hash, "analysis_hash"),
            (self.target_hash, "target_hash"),
        ):
            _require_digest(value, name)
        object.__setattr__(self, "logical_order", tuple(self.logical_order))
        _require_unique_text(self.logical_order, "logical_order")
        _validate_base_optimizer(self.optimizer)
        _positive_int(self.max_layers, "max_layers")
        if not isinstance(self.repeats, int) or isinstance(self.repeats, bool):
            raise TypeError("repeats must be an integer.")
        if self.repeats < 2:
            raise ValueError("repeats must be at least two.")
        object.__setattr__(
            self,
            "confidence_level",
            _confidence_level(self.confidence_level),
        )
        threshold = _finite(self.min_improvement, "min_improvement")
        if threshold < 0.0:
            raise ValueError("min_improvement must be non-negative.")
        object.__setattr__(self, "min_improvement", threshold)
        _positive_int(self.patience, "patience")
        _non_negative_int(self.requested_shots, "requested_shots")
        _non_negative_int(self.seed, "seed")
        if self.measurement is not None and not isinstance(
            self.measurement, PauliMeasurementConfig
        ):
            raise TypeError("measurement must be PauliMeasurementConfig or None.")
        if self.sampled_selection is not None and not isinstance(
            self.sampled_selection, SampledSelectionConfig
        ):
            raise TypeError(
                "sampled_selection must be SampledSelectionConfig or None."
            )
        if (self.measurement is None) != (self.sampled_selection is None):
            raise ValueError(
                "measurement and sampled_selection must be configured together."
            )
        if self.measurement is not None and (
            self.mode != "digital" or self.algorithm != "vqe"
        ):
            raise ValueError("sampled repeated layers require Digital VQE.")
        object.__setattr__(self, "steps", tuple(self.steps))
        if not self.steps:
            raise ValueError("steps must contain at least one executed layer.")
        if len(self.steps) > self.max_layers:
            raise ValueError("executed layer count cannot exceed max_layers.")
        if tuple(step.layers for step in self.steps) != tuple(
            range(1, len(self.steps) + 1)
        ):
            raise ValueError("steps must contain contiguous layers starting at one.")
        if any(step.statistics.sample_count != self.repeats for step in self.steps):
            raise ValueError("every layer must contain the configured repeat count.")
        if (
            not isinstance(self.selected_step_index, int)
            or isinstance(self.selected_step_index, bool)
            or not 0 <= self.selected_step_index < len(self.steps)
        ):
            raise ValueError("selected_step_index is outside steps.")
        if self.stop_reason not in {"max_layers_reached", "patience_exhausted"}:
            raise ValueError(f"Unsupported stop_reason: {self.stop_reason!r}.")
        expected_metadata = {
            "selection_rule": "paired_student_t_lower_confidence_bound",
            "warm_start": "previous_layer_same_repeat_index",
            "global_optimality_claim": False,
            "backend_called_during_report": False,
            "layer_objective_source": (
                "decoded_final_objective"
                if self.measurement is None
                else "independent_confirmation_mean"
            ),
        }
        if not isinstance(self.metadata, dict) or any(
            self.metadata.get(key) != value
            for key, value in expected_metadata.items()
        ):
            raise ValueError("repeated layer experiment metadata is invalid.")
        object.__setattr__(self, "metadata", dict(self.metadata))
        self._validate_shared_execution_facts()
        self._validate_run_seeds_and_warm_starts()
        expected_steps, expected_selected, expected_reason = _step_evidence(
            tuple(step.statistics for step in self.steps),
            max_layers=self.max_layers,
            confidence_level=self.confidence_level,
            min_improvement=self.min_improvement,
            patience=self.patience,
        )
        if self.steps != expected_steps:
            raise ValueError("repeated layer step evidence does not match executions.")
        if self.selected_step_index != expected_selected:
            raise ValueError("selected_step_index does not match statistical evidence.")
        if self.stop_reason != expected_reason:
            raise ValueError("stop_reason does not match repeated layer history.")
        expected_id = _experiment_id(
            self.steps,
            optimizer=self.optimizer,
            max_layers=self.max_layers,
            repeats=self.repeats,
            confidence_level=self.confidence_level,
            min_improvement=self.min_improvement,
            patience=self.patience,
            requested_shots=self.requested_shots,
            seed=self.seed,
            measurement=self.measurement,
            sampled_selection=self.sampled_selection,
        )
        if self.experiment_id != expected_id:
            raise ValueError("experiment_id does not match repeated experiment facts.")

    @property
    def selected_layers(self) -> int:
        """Return the shallowest layer supported by the configured evidence."""
        return self.steps[self.selected_step_index].layers

    @property
    def selected_statistics(self) -> ProblemLayerStatisticsIR:
        """Return all repeated runs and statistics at the selected layer."""
        return self.steps[self.selected_step_index].statistics

    @property
    def executions(self) -> tuple[ProblemExecutionResult, ...]:
        """Return every optimizer execution in layer and repeat order."""
        return tuple(
            run.execution for step in self.steps for run in step.statistics.runs
        )

    @property
    def total_optimization_count(self) -> int:
        """Return the number of complete optimizer runs."""
        return len(self.executions)

    @property
    def total_evaluation_count(self) -> int:
        """Return all real objective evaluations across every repeated run."""
        return sum(
            execution.optimization.evaluation_count
            for execution in self.executions
            if execution.optimization is not None
        )

    @property
    def total_backend_execution_count(self) -> int:
        """Return optimizer objective and gradient Backend executions."""
        return sum(
            int(execution.optimization.termination.backend_execution_count or 0)
            for execution in self.executions
            if execution.optimization is not None
            and execution.optimization.termination is not None
        )

    @property
    def total_confirmation_backend_execution_count(self) -> int:
        """Return Backend executions used for independent confirmation."""
        return sum(
            0
            if execution.optimization is None
            or execution.optimization.sampled_selection is None
            else execution.optimization.sampled_selection.backend_execution_count
            for execution in self.executions
        )

    @property
    def total_workflow_backend_execution_count(self) -> int:
        """Return optimization, confirmation and final-sampling executions."""
        return (
            self.total_backend_execution_count
            + self.total_confirmation_backend_execution_count
            + len(self.executions)
        )

    @property
    def total_objective_shots(self) -> int:
        """Return shots consumed by sampled objective evaluations."""
        return sum(
            evaluation.total_shots
            for execution in self.executions
            if execution.optimization is not None
            for evaluation in execution.optimization.sampled_evaluations
        )

    @property
    def total_gradient_shots(self) -> int:
        """Return finite-shot parameter-shift samples across all runs."""
        return sum(
            gradient.total_shots
            for execution in self.executions
            if execution.optimization is not None
            for gradient in execution.optimization.gradients
        )

    @property
    def total_confirmation_shots(self) -> int:
        """Return shots consumed by independent candidate confirmation."""
        return sum(
            0
            if execution.optimization is None
            or execution.optimization.sampled_selection is None
            else execution.optimization.sampled_selection.total_shots
            for execution in self.executions
        )

    @property
    def total_final_sampling_shots(self) -> int:
        """Return shots consumed by final computational-basis sampling."""
        return sum(execution.result.shots for execution in self.executions)

    @property
    def total_workflow_shots(self) -> int:
        """Return shots across optimization, confirmation and final sampling."""
        return (
            self.total_objective_shots
            + self.total_gradient_shots
            + self.total_confirmation_shots
            + self.total_final_sampling_shots
        )

    def comparison_sources(self) -> dict[str, ProblemExecutionResult]:
        """Return every run under a stable layer/repeat label."""
        return {
            f"p={step.layers}/repeat={run.repeat_index + 1}": run.execution
            for step in self.steps
            for run in step.statistics.runs
        }

    def report(
        self,
        output: str | PathLike[str] | None = None,
        *,
        language: Literal["en", "zh"] = "en",
        title: str | None = None,
    ) -> ExperimentReport:
        """Build and optionally save the standard repeated-layer report."""
        from cascaqit.visualization import visualize

        report = visualize(self, profile="comparison", title=title)
        if output is not None:
            report.save(output, language=language)
        return report

    def _validate_shared_execution_facts(self) -> None:
        for step in self.steps:
            for run in step.statistics.runs:
                execution = run.execution
                mapping = execution.context.analysis.mapping_plan
                if execution.mode != self.mode or execution.algorithm != self.algorithm:
                    raise ValueError(
                        "repeated executions must share mode and algorithm."
                    )
                if execution.problem_hash != self.problem_hash:
                    raise ValueError("repeated executions must share problem_hash.")
                if execution.analysis_hash != self.analysis_hash:
                    raise ValueError("repeated executions must share analysis_hash.")
                if execution.logical_order != self.logical_order:
                    raise ValueError("repeated executions must share logical_order.")
                if mapping.target_hash != self.target_hash:
                    raise ValueError("repeated executions must share target_hash.")
                if execution.metadata.get("requested_shots") != self.requested_shots:
                    raise ValueError("repeated executions must share requested shots.")
                optimization = execution.optimization
                if optimization is None or optimization.search_kind != "optimizer":
                    raise ValueError(
                        "repeated runs require configured optimizer evidence."
                    )
                actual = optimization.optimizer
                if not isinstance(actual, OptimizerConfig):
                    raise ValueError("repeated runs must retain optimizer config.")
                normalized = replace(
                    actual,
                    seed=None,
                    bounds=(),
                    initialization="random",
                )
                if normalized != self.optimizer:
                    raise ValueError("repeated run optimizer does not match config.")
                if self.measurement is None:
                    if (
                        optimization.sampled_evaluations
                        or optimization.sampled_selection is not None
                    ):
                        raise ValueError(
                            "exact repeated layers cannot contain sampled evidence."
                        )
                else:
                    if (
                        not optimization.sampled_evaluations
                        or optimization.sampled_selection is None
                    ):
                        raise ValueError(
                            "sampled repeated layers require confirmation evidence."
                        )
                    if (
                        optimization.sampled_evaluations[0].plan.config
                        != self.measurement
                    ):
                        raise ValueError(
                            "sampled repeated layer measurement does not match config."
                        )
                    if optimization.sampled_selection.config != self.sampled_selection:
                        raise ValueError(
                            "sampled repeated layer selection does not match config."
                        )

    def _validate_run_seeds_and_warm_starts(self) -> None:
        seen_seeds: set[int] = set()
        for step_index, step in enumerate(self.steps):
            previous = None if step_index == 0 else self.steps[step_index - 1]
            for run in step.statistics.runs:
                expected_seed = derive_problem_layer_run_seed(
                    self.seed,
                    layers=step.layers,
                    repeat_index=run.repeat_index,
                )
                if run.seed != expected_seed:
                    raise ValueError(
                        "run seed does not match deterministic derivation."
                    )
                if run.seed in seen_seeds:
                    raise ValueError(
                        "derived run seeds must be unique in an experiment."
                    )
                seen_seeds.add(run.seed)
                optimization = run.execution.optimization
                assert optimization is not None
                if not isinstance(optimization.optimizer, OptimizerConfig):
                    raise ValueError("run optimizer evidence is missing.")
                if optimization.optimizer.seed != run.seed:
                    raise ValueError("optimizer seed does not match repeated run seed.")
                if not optimization.starts:
                    raise ValueError("repeated run must retain optimizer starts.")
                first_start = optimization.starts[0]
                if previous is None:
                    # 第一层初值由 Phase 317 的执行编排生成；这里至少拒绝
                    # schema default，防止不同 seed 实际落到同一个默认点。
                    if first_start.initialization != "explicit":
                        raise ValueError(
                            "first-layer repeated runs require seeded explicit starts."
                        )
                    continue
                prior_run = previous.statistics.runs[run.repeat_index]
                if first_start.initialization != "layerwise":
                    raise ValueError("later repeated runs require layerwise starts.")
                parameter_names = tuple(
                    parameter.name
                    for parameter in run.execution.context.parameter_schema.parameters
                )
                previous_parameters = dict(
                    prior_run.execution.parameter_bind.values
                )
                if self.algorithm == "vqe":
                    previous_ansatz = prior_run.execution.context.ansatz
                    current_ansatz = run.execution.context.ansatz
                    if previous_ansatz is None or current_ansatz is None:
                        raise ValueError(
                            "Repeated VQE executions must retain ansatz source facts."
                        )
                    previous_parameters = transfer_vqe_parameters(
                        previous_ansatz,
                        current_ansatz,
                        previous_parameters,
                    )
                plans = build_optimization_start_plans(
                    algorithm_kind=self.algorithm,
                    layers=step.layers,
                    parameter_names=parameter_names,
                    optimizer=optimization.optimizer,
                    initial_parameters=previous_parameters,
                    seed=run.seed,
                )
                expected = dict(zip(parameter_names, plans[0].parameters))
                if not _parameter_maps_close(
                    expected,
                    first_start.initial_parameters,
                ):
                    raise ValueError(
                        "layerwise start does not derive from the same repeat index."
                    )

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ProblemRepeatedLayerExperimentResult:
        """Restore a repeated experiment and recheck all evidence."""
        return cls(
            experiment_id=str(data["experiment_id"]),
            mode=data["mode"],
            algorithm=data["algorithm"],
            problem_hash=str(data["problem_hash"]),
            analysis_hash=str(data["analysis_hash"]),
            target_hash=str(data["target_hash"]),
            logical_order=tuple(str(item) for item in data["logical_order"]),
            optimizer=OptimizerConfig.from_dict(
                _mapping(data["optimizer"], "optimizer")
            ),
            max_layers=int(data["max_layers"]),
            repeats=int(data["repeats"]),
            confidence_level=float(data["confidence_level"]),
            min_improvement=float(data["min_improvement"]),
            patience=int(data["patience"]),
            requested_shots=int(data["requested_shots"]),
            seed=int(data["seed"]),
            measurement=(
                None
                if data.get("measurement") is None
                else PauliMeasurementConfig.from_dict(
                    _mapping(data["measurement"], "measurement")
                )
            ),
            sampled_selection=(
                None
                if data.get("sampled_selection") is None
                else SampledSelectionConfig.from_dict(
                    _mapping(data["sampled_selection"], "sampled_selection")
                )
            ),
            steps=tuple(
                ProblemRepeatedLayerStepIR.from_dict(_mapping(item, "step"))
                for item in _sequence(data["steps"], "steps")
            ),
            selected_step_index=int(data["selected_step_index"]),
            stop_reason=data["stop_reason"],
            metadata=dict(_mapping(data.get("metadata", {}), "metadata")),
            schema_version=str(
                data.get(
                    "schema_version",
                    PROBLEM_REPEATED_LAYER_EXPERIMENT_SCHEMA_VERSION,
                )
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> ProblemRepeatedLayerExperimentResult:
        """Restore a repeated experiment from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError(
                "ProblemRepeatedLayerExperimentResult JSON must contain an object."
            )
        return cls.from_dict(data)


def derive_problem_layer_run_seed(
    root_seed: int,
    *,
    layers: int,
    repeat_index: int,
) -> int:
    """Derive an order-independent 32-bit seed for one layer and repeat."""
    return derive_layer_run_seed(
        root_seed,
        layers=layers,
        repeat_index=repeat_index,
        namespace=PROBLEM_REPEATED_LAYER_EXPERIMENT_SCHEMA_VERSION,
    )


def build_problem_repeated_layer_experiment_result(
    runs_by_layer: Sequence[Sequence[ProblemRepeatedLayerRunIR]],
    *,
    optimizer: OptimizerConfig,
    max_layers: int,
    repeats: int,
    confidence_level: float,
    min_improvement: float,
    patience: int,
    requested_shots: int,
    seed: int,
    measurement: PauliMeasurementConfig | None = None,
    sampled_selection: SampledSelectionConfig | None = None,
) -> ProblemRepeatedLayerExperimentResult:
    """Build one checked result from already completed repeated executions."""
    if not isinstance(runs_by_layer, Sequence) or isinstance(
        runs_by_layer, (str, bytes)
    ):
        raise TypeError("runs_by_layer must be a sequence of layer runs.")
    normalized = tuple(tuple(layer_runs) for layer_runs in runs_by_layer)
    if not normalized or any(not layer_runs for layer_runs in normalized):
        raise ValueError("runs_by_layer must contain completed layer runs.")
    statistics = tuple(
        ProblemLayerStatisticsIR.create(
            layer_runs,
            confidence_level=confidence_level,
        )
        for layer_runs in normalized
    )
    steps, selected_step_index, stop_reason = _step_evidence(
        statistics,
        max_layers=max_layers,
        confidence_level=confidence_level,
        min_improvement=min_improvement,
        patience=patience,
    )
    baseline = normalized[0][0].execution
    target_hash = baseline.context.analysis.mapping_plan.target_hash
    result = ProblemRepeatedLayerExperimentResult(
        experiment_id=_experiment_id(
            steps,
            optimizer=optimizer,
            max_layers=max_layers,
            repeats=repeats,
            confidence_level=confidence_level,
            min_improvement=min_improvement,
            patience=patience,
            requested_shots=requested_shots,
            seed=seed,
            measurement=measurement,
            sampled_selection=sampled_selection,
        ),
        mode=baseline.mode,  # type: ignore[arg-type]
        algorithm=baseline.algorithm,  # type: ignore[arg-type]
        problem_hash=baseline.problem_hash,
        analysis_hash=baseline.analysis_hash,
        target_hash=target_hash,
        logical_order=baseline.logical_order,
        optimizer=optimizer,
        max_layers=max_layers,
        repeats=repeats,
        confidence_level=confidence_level,
        min_improvement=min_improvement,
        patience=patience,
        requested_shots=requested_shots,
        seed=seed,
        measurement=measurement,
        sampled_selection=sampled_selection,
        steps=steps,
        selected_step_index=selected_step_index,
        stop_reason=stop_reason,
        metadata={
            "selection_rule": "paired_student_t_lower_confidence_bound",
            "warm_start": "previous_layer_same_repeat_index",
            "global_optimality_claim": False,
            "backend_called_during_report": False,
            "layer_objective_source": (
                "decoded_final_objective"
                if measurement is None
                else "independent_confirmation_mean"
            ),
        },
    )
    return result


def _sample_summary(
    values: tuple[float, ...],
    *,
    confidence_level: float,
) -> _SampleSummary:
    return sample_summary(values, confidence=confidence_level)


def _paired_summary(
    differences: tuple[float, ...],
    *,
    confidence_level: float,
) -> _SampleSummary:
    return paired_improvement_summary(differences, confidence=confidence_level)


def _step_evidence(
    statistics: tuple[ProblemLayerStatisticsIR, ...],
    *,
    max_layers: int,
    confidence_level: float,
    min_improvement: float,
    patience: int,
) -> tuple[
    tuple[ProblemRepeatedLayerStepIR, ...],
    int,
    Literal["max_layers_reached", "patience_exhausted"],
]:
    _positive_int(max_layers, "max_layers")
    level = _confidence_level(confidence_level)
    threshold = _finite(min_improvement, "min_improvement")
    if threshold < 0.0:
        raise ValueError("min_improvement must be non-negative.")
    _positive_int(patience, "patience")
    if not statistics:
        raise ValueError("statistics must not be empty.")
    if len(statistics) > max_layers:
        raise ValueError("statistics count cannot exceed max_layers.")
    steps: list[ProblemRepeatedLayerStepIR] = []
    selected_index = 0
    no_improvement_count = 0
    for index, item in enumerate(statistics):
        layers = index + 1
        if item.layers != layers:
            raise ValueError("statistics must use contiguous layers starting at one.")
        if index == 0:
            comparison = None
            material = True
        else:
            comparison = ProblemPairedImprovementIR.create(
                statistics[selected_index],
                item,
                confidence_level=level,
            )
            lower = comparison.lower_confidence_bound
            material = (
                lower > PROBLEM_LAYER_OBJECTIVE_TOLERANCE
                and lower >= threshold
            )
            if material:
                selected_index = index
                no_improvement_count = 0
            else:
                no_improvement_count += 1
        steps.append(
            ProblemRepeatedLayerStepIR(
                layers=layers,
                statistics=item,
                comparison=comparison,
                material_improvement=material,
                incumbent_layer=selected_index + 1,
                no_improvement_count=no_improvement_count,
            )
        )
        if no_improvement_count >= patience and index + 1 < len(statistics):
            raise ValueError("statistics continue after configured early stop.")
    if no_improvement_count >= patience:
        reason: Literal["max_layers_reached", "patience_exhausted"] = (
            "patience_exhausted"
        )
    elif len(statistics) == max_layers:
        reason = "max_layers_reached"
    else:
        raise ValueError("incomplete repeated runs do not satisfy a stop condition.")
    return tuple(steps), selected_index, reason


def _validate_base_optimizer(optimizer: OptimizerConfig) -> None:
    if not isinstance(optimizer, OptimizerConfig):
        raise TypeError("optimizer must be OptimizerConfig.")
    if optimizer.seed is not None:
        raise ValueError("repeated experiment optimizer seed must be None.")
    if optimizer.bounds:
        raise ValueError("repeated experiment optimizer bounds must be empty.")
    if optimizer.initialization != "random":
        raise ValueError("repeated experiment optimizer initialization must be random.")


def _experiment_id(
    steps: tuple[ProblemRepeatedLayerStepIR, ...],
    *,
    optimizer: OptimizerConfig,
    max_layers: int,
    repeats: int,
    confidence_level: float,
    min_improvement: float,
    patience: int,
    requested_shots: int,
    seed: int,
    measurement: PauliMeasurementConfig | None,
    sampled_selection: SampledSelectionConfig | None,
) -> str:
    digest = hashlib.sha256(
        stable_json(
            {
                "run_ids": tuple(
                    run.run_id for step in steps for run in step.statistics.runs
                ),
                "optimizer": optimizer,
                "max_layers": max_layers,
                "repeats": repeats,
                "confidence_level": confidence_level,
                "min_improvement": min_improvement,
                "patience": patience,
                "requested_shots": requested_shots,
                "seed": seed,
                "measurement": measurement,
                "sampled_selection": sampled_selection,
            }
        ).encode("utf-8")
    ).hexdigest()[:20]
    return f"problem.repeated-layer-experiment.{digest}"


def _run_id(
    *,
    layers: int,
    repeat_index: int,
    seed: int,
    execution_hash: str,
) -> str:
    digest = hashlib.sha256(
        stable_json(
            {
                "layers": layers,
                "repeat_index": repeat_index,
                "seed": seed,
                "execution_hash": execution_hash,
            }
        ).encode("utf-8")
    ).hexdigest()[:20]
    return f"problem.layer-run.{digest}"


def _parameter_maps_close(
    left: Mapping[str, float],
    right: Mapping[str, float],
) -> bool:
    return left.keys() == right.keys() and all(
        math.isclose(float(left[name]), float(right[name]), rel_tol=0.0, abs_tol=1e-12)
        for name in left
    )


def _mapping(value: object, name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{name} must be a mapping.")
    return value


def _sequence(value: object, name: str) -> Sequence[Any]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        raise TypeError(f"{name} must be a sequence.")
    return value


def _finite(value: object, name: str) -> float:
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        raise TypeError(f"{name} must be a real number.")
    normalized = float(value)
    if not math.isfinite(normalized):
        raise ValueError(f"{name} must be finite.")
    return normalized


def _confidence_level(value: object) -> float:
    return _shared_confidence_level(value)


def _require_statistic(actual: object, expected: float, name: str) -> None:
    normalized = _finite(actual, name)
    if not math.isclose(
        normalized,
        expected,
        rel_tol=_STATISTIC_TOLERANCE,
        abs_tol=_STATISTIC_TOLERANCE,
    ):
        raise ValueError(f"{name} does not match repeated run evidence.")


def _positive_int(value: object, name: str) -> None:
    if not isinstance(value, int) or isinstance(value, bool) or value <= 0:
        raise ValueError(f"{name} must be a positive integer.")


def _non_negative_int(value: object, name: str) -> None:
    if not isinstance(value, int) or isinstance(value, bool) or value < 0:
        raise ValueError(f"{name} must be a non-negative integer.")


def _require_text(value: object, name: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{name} must be a non-empty string.")


def _require_digest(value: object, name: str) -> None:
    if (
        not isinstance(value, str)
        or len(value) != _DIGEST_LENGTH
        or any(character not in "0123456789abcdef" for character in value)
    ):
        raise ValueError(f"{name} must be a lowercase SHA-256 digest.")


def _require_unique_text(values: tuple[str, ...], name: str) -> None:
    if not values or any(not isinstance(item, str) or not item for item in values):
        raise ValueError(f"{name} must contain non-empty strings.")
    if len(values) != len(set(values)):
        raise ValueError(f"{name} values must be unique.")


def _require_schema(value: str) -> None:
    if value != PROBLEM_REPEATED_LAYER_EXPERIMENT_SCHEMA_VERSION:
        raise ValueError(
            f"Unsupported repeated layer experiment schema: {value!r}."
        )
