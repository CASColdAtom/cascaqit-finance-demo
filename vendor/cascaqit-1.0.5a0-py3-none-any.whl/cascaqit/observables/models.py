"""Typed Pauli observable declarations and batch result contracts."""

from __future__ import annotations

import json
import math
import re
from collections.abc import Iterable, Iterator, Mapping, Sequence
from dataclasses import dataclass
from enum import Enum
from typing import Any, TypeVar, Union, overload

from cascaqit.native_ir.base import IRMixin

__all__ = [
    "OBSERVABLE_SCHEMA_VERSION",
    "Observable",
    "ObservableBatchResultIR",
    "ObservableEstimatorKind",
    "ObservableResultIR",
    "ObservableSet",
    "ObservableSourceKind",
    "PauliBasis",
    "PauliI",
    "PauliProduct",
    "PauliTerm",
    "PauliX",
    "PauliY",
    "PauliZ",
    "PauliZZ",
]

OBSERVABLE_SCHEMA_VERSION = "cascaqit.observables.v1"
_DIGEST_PATTERN = re.compile(r"[0-9a-f]{64}")
_PHYSICAL_TOLERANCE = 1e-12


class PauliBasis(str, Enum):
    """One single-target factor in a Pauli product."""

    I = "I"  # noqa: E741 - standard Pauli identity symbol
    X = "X"
    Y = "Y"
    Z = "Z"


class ObservableSourceKind(str, Enum):
    """Physical fact source consumed by an observable evaluator."""

    STATE_VECTOR = "state_vector"
    SUBSPACE = "subspace"
    DENSITY_MATRIX = "density_matrix"
    TRAJECTORY_BATCH = "trajectory_batch"
    SAMPLES = "samples"
    MEASUREMENT_PLAN = "measurement_plan"


class ObservableEstimatorKind(str, Enum):
    """Estimator semantics used to produce one observable result."""

    EXACT_STATE = "exact_state"
    EXACT_DENSITY = "exact_density"
    TRAJECTORY_MEAN = "trajectory_mean"
    SAMPLE_MEAN = "sample_mean"


@dataclass(frozen=True)
class PauliTerm(IRMixin):
    """A Pauli basis factor attached to one logical target."""

    target: str
    basis: PauliBasis
    schema_version: str = OBSERVABLE_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_clean_text(self.target, "target")
        if not isinstance(self.basis, PauliBasis):
            try:
                basis = PauliBasis(self.basis)
            except (TypeError, ValueError) as exc:
                raise ValueError("basis must be one of I, X, Y, or Z.") from exc
            object.__setattr__(self, "basis", basis)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> PauliTerm:
        """Build a Pauli term from JSON-compatible data."""
        return cls(
            target=data["target"],
            basis=PauliBasis(data["basis"]),
            schema_version=str(
                data.get("schema_version", OBSERVABLE_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class Observable(IRMixin):
    """An ordered, named Pauli product over distinct logical targets."""

    name: str
    terms: tuple[PauliTerm, ...]
    schema_version: str = OBSERVABLE_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_clean_text(self.name, "name")
        if not isinstance(self.terms, tuple):
            object.__setattr__(self, "terms", tuple(self.terms))
        if not self.terms:
            raise ValueError("observable terms must not be empty.")
        if any(not isinstance(term, PauliTerm) for term in self.terms):
            raise TypeError("observable terms must contain PauliTerm values.")
        targets = self.targets
        if len(targets) != len(set(targets)):
            raise ValueError("observable terms contain duplicate targets.")

    @property
    def targets(self) -> tuple[str, ...]:
        """Return logical targets in declaration order."""
        return tuple(term.target for term in self.terms)

    @property
    def bases(self) -> tuple[PauliBasis, ...]:
        """Return Pauli bases in declaration order."""
        return tuple(term.basis for term in self.terms)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> Observable:
        """Build an observable from JSON-compatible data."""
        raw_terms = data.get("terms", ())
        if not isinstance(raw_terms, (list, tuple)):
            raise TypeError("observable terms must be an array.")
        return cls(
            name=data["name"],
            terms=tuple(
                PauliTerm.from_dict(_require_mapping(term, "term"))
                for term in raw_terms
            ),
            schema_version=str(
                data.get("schema_version", OBSERVABLE_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> Observable:
        """Build an observable from JSON text."""
        return cls.from_dict(_json_object(text, "Observable"))


@dataclass(frozen=True, init=False)
class ObservableSet(IRMixin):
    """An immutable, ordered collection of uniquely named observables."""

    observables: tuple[Observable, ...]
    schema_version: str

    def __init__(
        self,
        observables: Iterable[Observable],
        *,
        schema_version: str = OBSERVABLE_SCHEMA_VERSION,
    ) -> None:
        values = tuple(observables)
        if not values:
            raise ValueError("observable set must not be empty.")
        if any(not isinstance(item, Observable) for item in values):
            raise TypeError("observable set must contain Observable values.")
        names = tuple(item.name for item in values)
        if len(names) != len(set(names)):
            raise ValueError("observable set contains duplicate names.")
        object.__setattr__(self, "observables", values)
        object.__setattr__(self, "schema_version", schema_version)

    @property
    def names(self) -> tuple[str, ...]:
        """Return observable names in declaration order."""
        return tuple(item.name for item in self.observables)

    def by_name(self) -> dict[str, Observable]:
        """Return observables keyed by their stable unique names."""
        return {item.name: item for item in self.observables}

    def __iter__(self) -> Iterator[Observable]:
        return iter(self.observables)

    def __len__(self) -> int:
        return len(self.observables)

    @overload
    def __getitem__(self, index: int) -> Observable: ...

    @overload
    def __getitem__(self, index: slice) -> tuple[Observable, ...]: ...

    def __getitem__(self, index: int | slice) -> Observable | tuple[Observable, ...]:
        return self.observables[index]

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ObservableSet:
        """Build an observable set from JSON-compatible data."""
        raw_observables = data.get("observables", ())
        if not isinstance(raw_observables, (list, tuple)):
            raise TypeError("observables must be an array.")
        return cls(
            (
                Observable.from_dict(_require_mapping(item, "observable"))
                for item in raw_observables
            ),
            schema_version=str(
                data.get("schema_version", OBSERVABLE_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> ObservableSet:
        """Build an observable set from JSON text."""
        return cls.from_dict(_json_object(text, "ObservableSet"))


@dataclass(frozen=True)
class ObservableResultIR(IRMixin):
    """One evaluated Pauli product with explicit estimator evidence."""

    observable: Observable
    expectation: float
    variance: float
    standard_error: float
    sample_count: int | None
    source_kind: ObservableSourceKind
    source_hash: str
    estimator_kind: ObservableEstimatorKind
    schema_version: str = OBSERVABLE_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if not isinstance(self.observable, Observable):
            raise TypeError("observable must be Observable.")
        expectation = _physical_float(
            self.expectation,
            "expectation",
            minimum=-1.0,
            maximum=1.0,
        )
        variance = _physical_float(
            self.variance,
            "variance",
            minimum=0.0,
            maximum=1.0,
        )
        standard_error = _physical_float(
            self.standard_error,
            "standard_error",
            minimum=0.0,
            maximum=1.0,
        )
        object.__setattr__(self, "expectation", expectation)
        object.__setattr__(self, "variance", variance)
        object.__setattr__(self, "standard_error", standard_error)
        source_kind = _enum_value(
            self.source_kind,
            ObservableSourceKind,
            "source_kind",
        )
        estimator_kind = _enum_value(
            self.estimator_kind,
            ObservableEstimatorKind,
            "estimator_kind",
        )
        object.__setattr__(self, "source_kind", source_kind)
        object.__setattr__(self, "estimator_kind", estimator_kind)
        _require_digest(self.source_hash, "source_hash")
        _validate_estimator_source(estimator_kind, source_kind)

        # Variance is a property of measuring the quantum state. Standard
        # error exists only when trajectories or shots estimate its mean.
        if estimator_kind in {
            ObservableEstimatorKind.EXACT_STATE,
            ObservableEstimatorKind.EXACT_DENSITY,
        }:
            if self.sample_count is not None:
                raise ValueError("exact estimators must not define sample_count.")
            if standard_error != 0.0:
                raise ValueError("exact estimators must have zero standard_error.")
        else:
            _require_count(self.sample_count, "sample_count", 2)

    @property
    def name(self) -> str:
        """Return the stable user-facing observable name."""
        return self.observable.name

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ObservableResultIR:
        """Build one observable result from JSON-compatible data."""
        raw_count = data.get("sample_count")
        return cls(
            observable=Observable.from_dict(
                _require_mapping(data["observable"], "observable")
            ),
            expectation=data["expectation"],
            variance=data["variance"],
            standard_error=data["standard_error"],
            sample_count=raw_count,
            source_kind=ObservableSourceKind(data["source_kind"]),
            source_hash=data["source_hash"],
            estimator_kind=ObservableEstimatorKind(data["estimator_kind"]),
            schema_version=str(
                data.get("schema_version", OBSERVABLE_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> ObservableResultIR:
        """Build one observable result from JSON text."""
        return cls.from_dict(_json_object(text, "ObservableResultIR"))


@dataclass(frozen=True)
class ObservableBatchResultIR(IRMixin):
    """Ordered observable results derived from one declared evaluation source."""

    observable_set_hash: str
    items: tuple[ObservableResultIR, ...]
    schema_version: str = OBSERVABLE_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_digest(self.observable_set_hash, "observable_set_hash")
        if not isinstance(self.items, tuple):
            object.__setattr__(self, "items", tuple(self.items))
        if not self.items:
            raise ValueError("observable batch items must not be empty.")
        if any(not isinstance(item, ObservableResultIR) for item in self.items):
            raise TypeError("batch items must contain ObservableResultIR values.")

        reconstructed = ObservableSet(item.observable for item in self.items)
        if reconstructed.stable_hash() != self.observable_set_hash:
            raise ValueError(
                "batch items must match the requested observable declaration order."
            )

        # Direct batches point to one state, trajectory batch, or sample collection.
        # A measurement-plan batch points to one checked composite source whose
        # group-level Result evidence is owned by the algorithm measurement IR.
        sources = {(item.source_kind, item.source_hash) for item in self.items}
        if len(sources) != 1:
            raise ValueError("batch items must use the same source kind and hash.")

    @property
    def source_kind(self) -> ObservableSourceKind:
        """Return the common physical source kind."""
        return self.items[0].source_kind

    @property
    def source_hash(self) -> str:
        """Return the common physical source hash."""
        return self.items[0].source_hash

    @classmethod
    def from_results(
        cls,
        observable_set: ObservableSet,
        items: Sequence[ObservableResultIR],
    ) -> ObservableBatchResultIR:
        """Build and validate a batch against its original declaration."""
        if not isinstance(observable_set, ObservableSet):
            raise TypeError("observable_set must be ObservableSet.")
        return cls(
            observable_set_hash=observable_set.stable_hash(),
            items=tuple(items),
        )

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ObservableBatchResultIR:
        """Build a batch result from JSON-compatible data."""
        raw_items = data.get("items", ())
        if not isinstance(raw_items, (list, tuple)):
            raise TypeError("batch items must be an array.")
        return cls(
            observable_set_hash=data["observable_set_hash"],
            items=tuple(
                ObservableResultIR.from_dict(_require_mapping(item, "item"))
                for item in raw_items
            ),
            schema_version=str(
                data.get("schema_version", OBSERVABLE_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> ObservableBatchResultIR:
        """Build a batch result from JSON text."""
        return cls.from_dict(_json_object(text, "ObservableBatchResultIR"))


PauliInput = Union[PauliTerm, tuple[str, Union[PauliBasis, str]]]


def PauliProduct(
    terms: Iterable[PauliInput],
    *,
    name: str | None = None,
) -> Observable:
    """Build a typed Pauli product while preserving term declaration order."""
    normalized = tuple(_coerce_term(term) for term in terms)
    effective_name = _default_observable_name(normalized) if name is None else name
    return Observable(name=effective_name, terms=normalized)


def PauliI(target: str, *, name: str | None = None) -> Observable:
    """Build a single-target identity observable."""
    return PauliProduct(((target, PauliBasis.I),), name=name)


def PauliX(target: str, *, name: str | None = None) -> Observable:
    """Build a single-target Pauli-X observable."""
    return PauliProduct(((target, PauliBasis.X),), name=name)


def PauliY(target: str, *, name: str | None = None) -> Observable:
    """Build a single-target Pauli-Y observable."""
    return PauliProduct(((target, PauliBasis.Y),), name=name)


def PauliZ(target: str, *, name: str | None = None) -> Observable:
    """Build a single-target Pauli-Z observable."""
    return PauliProduct(((target, PauliBasis.Z),), name=name)


def PauliZZ(
    left: str,
    right: str,
    *,
    name: str | None = None,
) -> Observable:
    """Build a two-target Pauli-Z product observable."""
    return PauliProduct(
        ((left, PauliBasis.Z), (right, PauliBasis.Z)),
        name=name,
    )


def _coerce_term(term: PauliInput) -> PauliTerm:
    if isinstance(term, PauliTerm):
        return term
    if not isinstance(term, tuple) or len(term) != 2:
        raise TypeError("Pauli product terms must be PauliTerm or (target, basis).")
    target, basis = term
    if not isinstance(target, str):
        raise TypeError("Pauli target must be a string.")
    try:
        normalized_basis = basis if isinstance(basis, PauliBasis) else PauliBasis(basis)
    except (TypeError, ValueError) as exc:
        raise ValueError("Pauli basis must be one of I, X, Y, or Z.") from exc
    return PauliTerm(target=target, basis=normalized_basis)


def _default_observable_name(terms: tuple[PauliTerm, ...]) -> str:
    if not terms:
        raise ValueError("Pauli product terms must not be empty.")
    return "*".join(f"{term.basis.value}({term.target})" for term in terms)


def _validate_estimator_source(
    estimator: ObservableEstimatorKind,
    source: ObservableSourceKind,
) -> None:
    allowed = {
        ObservableEstimatorKind.EXACT_STATE: {
            ObservableSourceKind.STATE_VECTOR,
            ObservableSourceKind.SUBSPACE,
        },
        ObservableEstimatorKind.EXACT_DENSITY: {
            ObservableSourceKind.DENSITY_MATRIX,
        },
        ObservableEstimatorKind.TRAJECTORY_MEAN: {
            ObservableSourceKind.TRAJECTORY_BATCH,
        },
        ObservableEstimatorKind.SAMPLE_MEAN: {
            ObservableSourceKind.SAMPLES,
            ObservableSourceKind.MEASUREMENT_PLAN,
        },
    }
    if source not in allowed[estimator]:
        raise ValueError(
            f"estimator_kind '{estimator.value}' is incompatible with "
            f"source_kind '{source.value}'."
        )


def _physical_float(
    value: object,
    field_name: str,
    *,
    minimum: float,
    maximum: float,
) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{field_name} must be a real number.")
    result = float(value)
    if not math.isfinite(result):
        raise ValueError(f"{field_name} must be finite.")
    if result < minimum - _PHYSICAL_TOLERANCE or result > (
        maximum + _PHYSICAL_TOLERANCE
    ):
        raise ValueError(f"{field_name} must be between {minimum} and {maximum}.")
    return min(max(result, minimum), maximum)


def _require_count(value: object, field_name: str, minimum: int) -> None:
    if (
        isinstance(value, bool)
        or not isinstance(value, int)
        or value < minimum
    ):
        raise ValueError(f"{field_name} must be an integer >= {minimum}.")


def _require_clean_text(value: object, field_name: str) -> None:
    if not isinstance(value, str) or not value or value != value.strip():
        raise ValueError(f"{field_name} must be a non-empty trimmed string.")


def _require_digest(value: object, field_name: str) -> None:
    if not isinstance(value, str) or _DIGEST_PATTERN.fullmatch(value) is None:
        raise ValueError(f"{field_name} must be a lowercase SHA-256 digest.")


def _require_mapping(value: object, field_name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{field_name} must be an object.")
    return value


def _json_object(text: str, type_name: str) -> Mapping[str, Any]:
    data = json.loads(text)
    if not isinstance(data, Mapping):
        raise TypeError(f"{type_name} JSON must contain an object.")
    return data


_EnumT = TypeVar(
    "_EnumT",
    ObservableSourceKind,
    ObservableEstimatorKind,
)


def _enum_value(
    value: object,
    enum_type: type[_EnumT],
    field_name: str,
) -> _EnumT:
    if isinstance(value, enum_type):
        return value
    try:
        return enum_type(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{field_name} is not supported.") from exc
