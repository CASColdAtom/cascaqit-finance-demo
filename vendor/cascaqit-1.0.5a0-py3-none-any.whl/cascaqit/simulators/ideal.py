"""Scalable NumPy/SciPy ideal-state kernels."""

from __future__ import annotations

import math
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, replace
from functools import cache
from itertools import repeat
from typing import TYPE_CHECKING, Any, Literal, cast

import numpy as np
from numpy.typing import NDArray
from scipy.sparse.linalg import (  # type: ignore[import-untyped]
    LinearOperator,
    expm_multiply,
    onenormest,
)
from scipy.sparse.linalg._expm_multiply import (  # type: ignore[import-untyped]
    LazyOperatorNormInfo,
    _fragment_3_1,
)

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.digital import DigitalProgramIR, GateIR
from cascaqit.exceptions import ProgramValidationError
from cascaqit.native_ir import ProgramIR, WaveformIR
from cascaqit.observables import ObservableSet
from cascaqit.results import (
    ResultIR,
    ResultReferencesIR,
    SimulationSolverEvidenceIR,
    StateTransitionIR,
)
from cascaqit.simulators.adaptive import (
    fixed_step_solver_evidence,
    integrate_dop853_segments,
)
from cascaqit.simulators.addressing import site_addressing_provenance_metadata
from cascaqit.simulators.analog_timing import analog_control_boundaries
from cascaqit.simulators.array_state import (
    ArrayStateProvenance,
    StateVectorState,
    SubspaceState,
)
from cascaqit.simulators.execution_evidence import (
    aggregate_solver_evidence,
    not_applicable_solver_evidence,
    solver_evidence_from_provenance,
    solver_evidence_metadata,
)
from cascaqit.simulators.local_rabi import (
    sample_local_rabi_fields,
    site_phase_pattern_provenance_metadata,
)
from cascaqit.simulators.observable_evaluator import evaluate_observables
from cascaqit.simulators.planning import (
    SelectedSimulationIntegrator,
    SimulationIntegrator,
)
from cascaqit.simulators.register_evidence import collect_register_snapshot_evidence
from cascaqit.simulators.runtime_lineage import (
    build_runtime_references,
    build_runtime_trace,
    build_state_transition,
    runtime_lineage_metadata,
)
from cascaqit.simulators.waveform_sampling import sample_waveform as _sample_waveform

if TYPE_CHECKING:
    from cascaqit.simulators.local_hybrid import LocalExecutionBundle

__all__ = [
    "MatrixFreeAnalogStateVectorKernel",
    "NumpyDigitalStateVectorKernel",
    "build_blockade_basis",
    "blockade_basis_dimension",
    "run_scalable_analog_ideal",
    "run_scalable_digital_ideal",
    "run_scalable_hybrid_ideal",
    "validate_scalable_hybrid_bundle",
    "zero_state_vector",
]

ComplexArray = NDArray[np.complexfloating[Any, Any]]
ArrayDType = Literal["complex64", "complex128"]
# Cover complex addition and magnitude rounding before nextafter rounds upward.
_KRYLOV_NORM_BOUND_MARGIN = 1.0 + 8.0 * np.finfo(np.float64).eps
_MIN_THREADED_KRYLOV_STATES = 65_536


def zero_state_vector(
    logical_order: tuple[str, ...],
    *,
    dtype: ArrayDType = "complex128",
    producer: str = "zero_state_vector",
) -> StateVectorState:
    """Allocate the computational all-zero state without Python element copies."""
    if not logical_order:
        raise ValueError("logical_order must not be empty.")
    amplitudes = np.zeros(2 ** len(logical_order), dtype=np.dtype(dtype))
    amplitudes[0] = 1.0
    return StateVectorState(
        amplitudes=amplitudes,
        logical_order=logical_order,
        provenance=ArrayStateProvenance.initial(producer),
    )


def run_scalable_digital_ideal(
    program: DigitalProgramIR,
    *,
    shots: int,
    seed: int | None,
    dtype: ArrayDType,
    return_probabilities: bool,
    observables: ObservableSet | None = None,
) -> ResultIR:
    """Execute a Digital program through the scalable tensor-axis kernel."""
    order = tuple(program.circuit.qubits)
    initial_state = zero_state_vector(order, dtype=dtype)
    state = NumpyDigitalStateVectorKernel().evolve(
        program,
        initial_state,
    )
    result = _state_result(
        state,
        result_id=f"result.{program.program_id}",
        program_hash=program.stable_hash(),
        target_id="local.digital_simulator",
        shots=shots,
        seed=seed,
        return_probabilities=return_probabilities,
        program_kind="digital",
        observables=observables,
    )
    evidence = not_applicable_solver_evidence(
        integrator_requested="auto",
        logical_time=state.logical_time,
        time_unit=state.time_unit,
        consumer="NumpyDigitalStateVectorKernel",
    )
    transition = build_state_transition(
        transition_id=f"transition.0.{program.program_id}",
        order_index=0,
        block_id=program.program_id,
        program_kind="digital",
        program_hash=program.stable_hash(),
        kernel=state.provenance.producer,
        input_state_hash=initial_state.stable_hash(),
        output_state_hash=state.stable_hash(),
        input_logical_time=initial_state.logical_time,
        output_logical_time=state.logical_time,
        time_unit=state.time_unit,
        solver_evidence=evidence,
        metadata={"logical_order": list(state.logical_order)},
    )
    references = build_runtime_references(
        program_hash=program.stable_hash(),
        initial_state_hash=initial_state.stable_hash(),
        final_state_hash=state.stable_hash(),
    )
    trace = build_runtime_trace(
        trace_id=f"trace.{program.program_id}.scalable_digital",
        transitions=(transition,),
        references=references,
        execution_mode="standalone_digital",
        terminal_message="Terminal Digital sampling completed.",
        terminal_metadata={"shots": shots, "seed": seed},
    )
    return replace(
        result,
        metadata={
            **result.metadata,
            **solver_evidence_metadata(evidence),
            **runtime_lineage_metadata(
                transitions=(transition,),
                references=references,
                trace=trace,
            ),
        },
    )


def run_scalable_analog_ideal(
    program: ProgramIR,
    *,
    shots: int,
    seed: int | None,
    dtype: ArrayDType,
    steps: int,
    blockade_radius: float,
    target_id: str,
    return_probabilities: bool,
    use_subspace: bool = False,
    observables: ObservableSet | None = None,
    integrator_requested: SimulationIntegrator = "fixed_step_krylov",
    integrator_selected: SelectedSimulationIntegrator = "fixed_step_krylov",
    rtol: float = 1e-9,
    atol: float = 1e-11,
    max_steps: int = 10_000,
    kernel_threads: int = 1,
) -> ResultIR:
    """Execute an Analog program through the scalable matrix-free kernel."""
    order = _atom_order(program)
    kernel = MatrixFreeAnalogStateVectorKernel(
        steps=steps,
        blockade_radius=blockade_radius,
        integrator_requested=integrator_requested,
        integrator_selected=integrator_selected,
        rtol=rtol,
        atol=atol,
        max_steps=max_steps,
        kernel_threads=kernel_threads,
    )
    if use_subspace:
        basis_indices = build_blockade_basis(program, blockade_radius)
        amplitudes = np.zeros(basis_indices.size, dtype=np.dtype(dtype))
        amplitudes[0] = 1.0
        initial_state: StateVectorState | SubspaceState = SubspaceState(
            amplitudes=amplitudes,
            basis_indices=basis_indices,
            logical_order=order,
            provenance=ArrayStateProvenance.initial("zero_subspace_state"),
        )
        state: StateVectorState | SubspaceState = kernel.evolve_subspace(
            program,
            cast(SubspaceState, initial_state),
        )
    else:
        initial_state = zero_state_vector(order, dtype=dtype)
        state = kernel.evolve(program, initial_state)
    result = _state_result(
        state,
        result_id=f"result.{program.program_id}",
        program_hash=program.stable_hash(),
        target_id=target_id,
        shots=shots,
        seed=seed,
        return_probabilities=return_probabilities,
        program_kind="analog",
        observables=observables,
    )
    evidence = solver_evidence_from_provenance(
        state.provenance.metadata,
        object_path="simulation_state.provenance.solver_evidence",
    )
    transition = build_state_transition(
        transition_id=f"transition.0.{program.program_id}",
        order_index=0,
        block_id=program.program_id,
        program_kind="analog",
        program_hash=program.stable_hash(),
        kernel=state.provenance.producer,
        input_state_hash=initial_state.stable_hash(),
        output_state_hash=state.stable_hash(),
        input_logical_time=initial_state.logical_time,
        output_logical_time=state.logical_time,
        time_unit=state.time_unit,
        solver_evidence=evidence,
        metadata={"logical_order": list(state.logical_order)},
    )
    references = build_runtime_references(
        program_hash=program.stable_hash(),
        initial_state_hash=initial_state.stable_hash(),
        final_state_hash=state.stable_hash(),
    )
    trace = build_runtime_trace(
        trace_id=f"trace.{program.program_id}.scalable_analog",
        transitions=(transition,),
        references=references,
        execution_mode="standalone_analog",
        terminal_message="Terminal Analog sampling completed.",
        terminal_metadata={"shots": shots, "seed": seed},
    )
    return replace(
        result,
        metadata={
            **result.metadata,
            "register_snapshot": program.register.snapshot_evidence(),
            **solver_evidence_metadata(evidence),
            **runtime_lineage_metadata(
                transitions=(transition,),
                references=references,
                trace=trace,
            ),
        },
    )


def validate_scalable_hybrid_bundle(bundle: LocalExecutionBundle) -> None:
    """Validate the array-engine boundary without allocating its state vector."""
    from cascaqit.simulators.local_hybrid import (
        AnalogStepPayload,
        DigitalStepPayload,
        LocalExecutionBundle,
        MeasurementStepPayload,
    )

    if not isinstance(bundle, LocalExecutionBundle):
        raise TypeError("bundle must be LocalExecutionBundle.")
    if not isinstance(bundle.payloads[-1], MeasurementStepPayload):
        raise ProgramValidationError(
            "Scalable Hybrid execution requires one terminal measurement.",
            code="SCALABLE_HYBRID_MEASUREMENT_BOUNDARY_INVALID",
            stage="simulation",
            object_path="bundle.payloads",
        )
    for index, payload in enumerate(bundle.payloads[:-1]):
        if isinstance(payload, MeasurementStepPayload):
            raise ProgramValidationError(
                "Scalable Hybrid execution does not support mid-circuit measurement.",
                code="SCALABLE_HYBRID_MEASUREMENT_BOUNDARY_INVALID",
                stage="simulation",
                object_path=f"bundle.payloads[{index}]",
            )
        if isinstance(payload, DigitalStepPayload):
            diagnostics = tuple(
                item
                for item in payload.program.validate_ir_only()
                if item.severity == "error"
            )
            if diagnostics:
                raise ProgramValidationError(
                    "Hybrid Digital payload failed scalable preflight.",
                    code="SCALABLE_HYBRID_DIGITAL_PROGRAM_INVALID",
                    stage="simulation",
                    object_path=f"bundle.payloads[{index}].program",
                    diagnostics=diagnostics,
                )
        elif isinstance(payload, AnalogStepPayload):
            _validate_analog_inputs(payload.program, payload.logical_order)
        else:
            raise ProgramValidationError(
                "Hybrid bundle contains an unsupported quantum payload.",
                code="SCALABLE_HYBRID_PAYLOAD_UNSUPPORTED",
                stage="simulation",
                object_path=f"bundle.payloads[{index}]",
            )


def run_scalable_hybrid_ideal(
    bundle: LocalExecutionBundle,
    *,
    dtype: ArrayDType,
    steps: int,
    blockade_radius: float,
    target_id: str,
    return_probabilities: bool = True,
    observables: ObservableSet | None = None,
    integrator_requested: SimulationIntegrator = "fixed_step_krylov",
    integrator_selected: SelectedSimulationIntegrator = "fixed_step_krylov",
    rtol: float = 1e-9,
    atol: float = 1e-11,
    max_steps: int = 10_000,
    kernel_threads: int = 1,
) -> ResultIR:
    """Execute Digital-Analog blocks over one continuous NumPy state vector."""
    from cascaqit.simulators.local_hybrid import (
        AnalogStepPayload,
        DigitalStepPayload,
        MeasurementStepPayload,
    )

    validate_scalable_hybrid_bundle(bundle)
    measurement = cast(MeasurementStepPayload, bundle.payloads[-1])
    state = zero_state_vector(
        measurement.logical_order,
        dtype=dtype,
        producer="ScalableHybridInitialState",
    )
    initial_state = state
    transitions: list[StateTransitionIR] = []
    solver_evidences: list[SimulationSolverEvidenceIR] = []
    digital = NumpyDigitalStateVectorKernel()
    analog = MatrixFreeAnalogStateVectorKernel(
        steps=steps,
        blockade_radius=blockade_radius,
        integrator_requested=integrator_requested,
        integrator_selected=integrator_selected,
        rtol=rtol,
        atol=atol,
        max_steps=max_steps,
        kernel_threads=kernel_threads,
    )
    for index, payload in enumerate(bundle.payloads[:-1]):
        quantum_payload = cast(Any, payload)
        input_state = state
        if isinstance(quantum_payload, DigitalStepPayload):
            state = digital.evolve(quantum_payload.program, input_state)
            evidence = not_applicable_solver_evidence(
                integrator_requested=integrator_requested,
                logical_time=state.logical_time,
                time_unit=state.time_unit,
                consumer=state.provenance.producer,
            )
        else:
            state = analog.evolve(quantum_payload.program, input_state)
        input_hash = input_state.stable_hash()
        if state.provenance.parent_state_hash != input_hash:
            raise ProgramValidationError(
                "Scalable Hybrid state lineage is discontinuous.",
                code="SCALABLE_HYBRID_STATE_CHAIN_BROKEN",
                stage="simulation",
                object_path=f"bundle.payloads[{index}]",
            )
        transition_metadata: dict[str, Any] = {
            "payload_id": quantum_payload.payload_id,
            "payload_hash": quantum_payload.stable_hash(),
            "logical_order": list(state.logical_order),
            "producer": state.provenance.producer,
        }
        if isinstance(quantum_payload, AnalogStepPayload):
            evidence = solver_evidence_from_provenance(
                state.provenance.metadata,
                object_path=(
                    f"bundle.payloads[{index}].provenance.solver_evidence"
                ),
            )
            solver_evidences.append(evidence)
            addressing = state.provenance.metadata.get("site_addressing")
            if isinstance(addressing, dict):
                transition_metadata["site_addressing"] = addressing
            phase_pattern = state.provenance.metadata.get("site_phase_pattern")
            if isinstance(phase_pattern, dict):
                transition_metadata["site_phase_pattern"] = phase_pattern
        transitions.append(
            build_state_transition(
                transition_id=f"transition.{index}.{quantum_payload.block_id}",
                order_index=index,
                block_id=quantum_payload.block_id,
                program_kind=quantum_payload.payload_kind,
                program_hash=quantum_payload.program.stable_hash(),
                kernel=state.provenance.producer,
                input_state_hash=input_hash,
                output_state_hash=state.stable_hash(),
                input_logical_time=input_state.logical_time,
                output_logical_time=state.logical_time,
                time_unit=state.time_unit,
                solver_evidence=evidence,
                metadata=transition_metadata,
            )
        )
    result = _state_result(
        state,
        result_id=f"result.{bundle.bundle_id}",
        program_hash=bundle.base_plan.program_hash,
        target_id=target_id,
        shots=measurement.shots,
        seed=measurement.seed,
        return_probabilities=return_probabilities,
        program_kind="hybrid",
        observables=observables,
    )
    solver_evidence = aggregate_solver_evidence(
        solver_evidences,
        integrator_requested=integrator_requested,
        integrator_selected=integrator_selected,
        aggregation_scope="hybrid_quantum_blocks",
    )
    transition_tuple = tuple(transitions)
    references = build_runtime_references(
        program_hash=bundle.base_plan.program_hash,
        plan_hash=bundle.base_plan_hash,
        bundle_hash=bundle.stable_hash(),
        initial_state_hash=initial_state.stable_hash(),
        final_state_hash=state.stable_hash(),
        metadata={"graph_hash": bundle.base_plan.graph_hash},
    )
    trace = build_runtime_trace(
        trace_id=f"trace.{bundle.bundle_id}.scalable_hybrid",
        transitions=transition_tuple,
        references=references,
        execution_mode="local_hybrid_shared_state",
        terminal_message="Terminal computational-basis measurement completed.",
        terminal_metadata={
            "measurement_key": measurement.measurement_key,
            "shots": measurement.shots,
            "seed": measurement.seed,
        },
    )
    return replace(
        result,
        metadata={
            **result.metadata,
            **solver_evidence_metadata(solver_evidence),
            "bundle_hash": bundle.stable_hash(),
            **runtime_lineage_metadata(
                transitions=transition_tuple,
                references=references,
                trace=trace,
            ),
            "measurement": {
                "basis": measurement.basis,
                "key": measurement.measurement_key,
                "targets": list(measurement.logical_order),
            },
            "register_snapshots": collect_register_snapshot_evidence(
                payload.program
                for payload in bundle.payloads
                if isinstance(payload, AnalogStepPayload)
            ),
        },
    )


@dataclass(frozen=True)
class NumpyDigitalStateVectorKernel:
    """Apply local Digital gates through tensor axes, never a global unitary."""

    def evolve(
        self,
        program: DigitalProgramIR,
        initial_state: StateVectorState,
    ) -> StateVectorState:
        if not isinstance(program, DigitalProgramIR):
            raise TypeError("program must be DigitalProgramIR.")
        if not isinstance(initial_state, StateVectorState):
            raise TypeError("initial_state must be StateVectorState.")
        logical_order = tuple(program.circuit.qubits)
        if initial_state.logical_order != logical_order:
            raise ProgramValidationError(
                "Digital program order does not match scalable state order.",
                code="DIGITAL_ARRAY_STATE_LOGICAL_ORDER_MISMATCH",
                stage="simulation",
                object_path="simulation_state.logical_order",
            )
        diagnostics = tuple(
            item for item in program.validate_ir_only() if item.severity == "error"
        )
        if diagnostics:
            raise ProgramValidationError(
                "Digital program failed scalable kernel validation.",
                code="DIGITAL_ARRAY_STATE_PROGRAM_INVALID",
                stage="simulation",
                object_path="digital_program",
                diagnostics=diagnostics,
            )
        amplitudes = np.array(initial_state.amplitudes, copy=True)
        qubit_index = {name: index for index, name in enumerate(logical_order)}
        for gate in program.circuit.gates:
            amplitudes = self.apply_gate(
                amplitudes,
                gate,
                qubit_index=qubit_index,
            )
        return StateVectorState(
            amplitudes=amplitudes,
            logical_order=logical_order,
            basis=initial_state.basis,
            logical_time=initial_state.logical_time,
            time_unit=initial_state.time_unit,
            noise_context=initial_state.noise_context,
            provenance=ArrayStateProvenance(
                producer="NumpyDigitalStateVectorKernel",
                parent_state_hash=initial_state.stable_hash(),
                step_index=initial_state.provenance.step_index + 1,
                metadata={
                    "program_hash": program.stable_hash(),
                    "gate_count": len(program.circuit.gates),
                    "algorithm": "tensor_axis",
                },
            ),
        )

    def apply_gate(
        self,
        amplitudes: ComplexArray,
        gate: GateIR,
        *,
        qubit_index: dict[str, int],
    ) -> ComplexArray:
        """Apply one at-most-three-qubit gate to an existing state vector."""
        if gate.name == "i":
            return amplitudes
        targets = tuple(qubit_index[target] for target in gate.targets)
        matrix = _gate_matrix(gate, dtype=amplitudes.dtype)
        qubit_count = len(qubit_index)
        tensor = amplitudes.reshape((2,) * qubit_count)
        front_axes = tuple(range(len(targets)))
        moved = np.moveaxis(tensor, targets, front_axes)
        updated = _local_matrix_action(matrix, moved.reshape(matrix.shape[1], -1))
        restored = np.moveaxis(
            updated.reshape((2,) * qubit_count),
            front_axes,
            targets,
        )
        return np.ascontiguousarray(restored.reshape(-1))


@dataclass(frozen=True)
class MatrixFreeAnalogStateVectorKernel:
    """Evolve ideal AHS states with fixed Krylov or segmented DOP853."""

    steps: int = 32
    blockade_radius: float = 0.0
    integrator_requested: SimulationIntegrator = "fixed_step_krylov"
    integrator_selected: SelectedSimulationIntegrator = "fixed_step_krylov"
    rtol: float = 1e-9
    atol: float = 1e-11
    max_steps: int = 10_000
    kernel_threads: int = 1

    def __post_init__(self) -> None:
        if (
            not isinstance(self.steps, int)
            or isinstance(self.steps, bool)
            or self.steps <= 0
        ):
            raise ValueError("steps must be a positive integer.")
        if not math.isfinite(self.blockade_radius) or self.blockade_radius < 0.0:
            raise ValueError("blockade_radius must be finite and non-negative.")
        if self.integrator_requested not in {
            "auto",
            "adaptive_dop853",
            "fixed_step_krylov",
        }:
            raise ValueError("integrator_requested is unsupported.")
        if self.integrator_selected not in {
            "adaptive_dop853",
            "fixed_step_krylov",
        }:
            raise ValueError("Analog state evolution requires a selected integrator.")
        if (
            self.integrator_requested != "auto"
            and self.integrator_requested != self.integrator_selected
        ):
            raise ValueError("Explicit integrator request cannot be changed silently.")
        for value, field_name in ((self.rtol, "rtol"), (self.atol, "atol")):
            if not math.isfinite(value) or value <= 0.0:
                raise ValueError(f"{field_name} must be finite and positive.")
        if (
            not isinstance(self.max_steps, int)
            or isinstance(self.max_steps, bool)
            or self.max_steps <= 0
        ):
            raise ValueError("max_steps must be a positive integer.")
        if (
            not isinstance(self.kernel_threads, int)
            or isinstance(self.kernel_threads, bool)
            or self.kernel_threads <= 0
        ):
            raise ValueError("kernel_threads must be a positive integer.")

    def evolve(
        self,
        program: ProgramIR,
        initial_state: StateVectorState,
    ) -> StateVectorState:
        """Evolve a full Hilbert-space state without materializing Hamiltonian."""
        _validate_analog_inputs(program, initial_state.logical_order)
        evolved, evidence = self._propagate(
            program,
            initial_state.amplitudes,
            basis_indices=None,
            logical_time_offset=initial_state.logical_time,
        )
        return StateVectorState(
            amplitudes=evolved,
            logical_order=initial_state.logical_order,
            basis=initial_state.basis,
            logical_time=initial_state.logical_time + _duration(program),
            time_unit=initial_state.time_unit,
            noise_context=initial_state.noise_context,
            provenance=_analog_provenance(
                program,
                initial_state.stable_hash(),
                initial_state.provenance.step_index,
                representation="state_vector",
                evidence=evidence,
            ),
        )

    def evolve_subspace(
        self,
        program: ProgramIR,
        initial_state: SubspaceState,
    ) -> SubspaceState:
        """Evolve an explicit blockade basis with projected matrix-free flips."""
        _validate_analog_inputs(program, initial_state.logical_order)
        evolved, evidence = self._propagate(
            program,
            initial_state.amplitudes,
            basis_indices=initial_state.basis_indices,
            logical_time_offset=initial_state.logical_time,
        )
        return SubspaceState(
            amplitudes=evolved,
            basis_indices=initial_state.basis_indices,
            logical_order=initial_state.logical_order,
            basis=initial_state.basis,
            logical_time=initial_state.logical_time + _duration(program),
            time_unit=initial_state.time_unit,
            noise_context=initial_state.noise_context,
            provenance=_analog_provenance(
                program,
                initial_state.stable_hash(),
                initial_state.provenance.step_index,
                representation="subspace",
                evidence=evidence,
            ),
        )

    def _propagate(
        self,
        program: ProgramIR,
        amplitudes: ComplexArray,
        *,
        basis_indices: NDArray[np.integer[Any]] | None,
        logical_time_offset: float,
    ) -> tuple[ComplexArray, SimulationSolverEvidenceIR]:
        duration = _duration(program)
        if self.integrator_selected == "adaptive_dop853":

            def rhs(time: float, values: ComplexArray) -> ComplexArray:
                hamiltonian, _ = _analog_linear_operator(
                    program,
                    time=time,
                    dtype=values.dtype,
                    blockade_radius=self.blockade_radius,
                    basis_indices=basis_indices,
                )
                return np.asarray(-1j * hamiltonian.matvec(values))

            integration = integrate_dop853_segments(
                rhs,
                np.array(amplitudes, copy=True),
                boundaries=analog_control_boundaries(program),
                integrator_requested=self.integrator_requested,
                rtol=self.rtol,
                atol=self.atol,
                max_steps=self.max_steps,
                logical_time_offset=logical_time_offset,
            )
            state = np.asarray(integration.values, dtype=amplitudes.dtype)
            evidence = integration.evidence
        else:
            state = np.array(amplitudes, copy=True)
            dt = duration / self.steps
            diagonal_plan: _DiagonalKrylovPlan | None = None
            diagonal_krylov_workspace: _DiagonalKrylovWorkspace | None = None
            threaded_krylov_workspace: _ThreadedDiagonalKrylovWorkspace | None = None
            analog_diagonal_workspace: _AnalogDiagonalWorkspace | None = None
            executed_kernel_threads = 1
            diagonal_basis = (
                np.arange(state.size, dtype=np.int64)
                if basis_indices is None
                else np.asarray(basis_indices, dtype=np.int64)
            )
            try:
                for step in range(self.steps):
                    time = (step + 0.5) * dt
                    if state.dtype == np.dtype(np.complex128) and _analog_is_diagonal(
                        program,
                        time=time,
                    ):
                        if analog_diagonal_workspace is None:
                            analog_diagonal_workspace = (
                                _build_analog_diagonal_workspace(
                                    program,
                                    diagonal_basis,
                                    blockade_radius=self.blockade_radius,
                                )
                            )
                        diagonal = _analog_diagonal(
                            program,
                            diagonal_basis,
                            time=time,
                            blockade_radius=self.blockade_radius,
                            workspace=analog_diagonal_workspace,
                        ).astype(state.dtype, copy=False)
                        scale = -1j * dt
                        if (
                            diagonal_plan is None
                            or diagonal_plan.scale != scale
                            or not np.array_equal(diagonal_plan.diagonal, diagonal)
                        ):
                            diagonal_plan = _build_diagonal_krylov_plan(
                                diagonal,
                                scale=scale,
                            )
                        if (
                            self.kernel_threads > 1
                            and state.size >= _MIN_THREADED_KRYLOV_STATES
                        ):
                            if threaded_krylov_workspace is None:
                                threaded_krylov_workspace = (
                                    _build_threaded_diagonal_krylov_workspace(
                                        state,
                                        kernel_threads=self.kernel_threads,
                                    )
                                )
                            state = _apply_diagonal_krylov_plan_threaded(
                                diagonal_plan,
                                state,
                                workspace=threaded_krylov_workspace,
                            )
                            executed_kernel_threads = self.kernel_threads
                        else:
                            if diagonal_krylov_workspace is None:
                                diagonal_krylov_workspace = (
                                    _build_diagonal_krylov_workspace(state)
                                )
                            state = _apply_diagonal_krylov_plan(
                                diagonal_plan,
                                state,
                                workspace=diagonal_krylov_workspace,
                            )
                        continue
                    hamiltonian, trace = _analog_linear_operator(
                        program,
                        time=time,
                        dtype=state.dtype,
                        blockade_radius=self.blockade_radius,
                        basis_indices=basis_indices,
                    )
                    scaled = LinearOperator(
                        hamiltonian.shape,
                        matvec=lambda vector, op=hamiltonian: (
                            -1j * dt * op.matvec(vector)
                        ),
                        rmatvec=lambda vector, op=hamiltonian: (
                            1j * dt * op.rmatvec(vector)
                        ),
                        dtype=state.dtype,
                    )
                    state = np.asarray(
                        expm_multiply(scaled, state, traceA=-1j * dt * trace),
                        dtype=amplitudes.dtype,
                    )
            finally:
                if threaded_krylov_workspace is not None:
                    threaded_krylov_workspace.close()
            evidence = fixed_step_solver_evidence(
                integrator_requested=self.integrator_requested,
                steps=self.steps,
                duration=duration,
                logical_time_offset=logical_time_offset,
                time_unit="us",
                algorithm="scipy.sparse.linalg.expm_multiply",
            )
            if executed_kernel_threads > 1:
                evidence = replace(
                    evidence,
                    metadata={
                        **evidence.metadata,
                        "kernel_parallelism": "threaded_numpy_chunks",
                        "kernel_threads": executed_kernel_threads,
                    },
                )
        # A fixed-order reduction keeps optimizer starts stable when workers use
        # fewer BLAS threads than the parent process.
        norm_squared = np.sum(
            state.real * state.real + state.imag * state.imag,
            dtype=np.float64,
        )
        norm = math.sqrt(float(norm_squared))
        if norm <= 0.0 or not math.isfinite(norm):
            raise ProgramValidationError(
                "Analog propagation produced an invalid state norm.",
                code="ANALOG_ARRAY_STATE_NORM_INVALID",
                stage="simulation",
                object_path="simulation_state.amplitudes",
                metadata={"norm": norm},
            )
        normalized = np.asarray(state / norm, dtype=amplitudes.dtype)
        dtype_epsilon = float(np.finfo(normalized.real.dtype).eps)
        evidence = replace(
            evidence,
            metadata={
                **evidence.metadata,
                "norm_before_normalization": norm,
                "normalization_correction": abs(1.0 - norm),
                "output_dtype": str(normalized.dtype),
                "output_dtype_epsilon": dtype_epsilon,
                "requested_tolerance_below_output_precision": (
                    self.integrator_selected == "adaptive_dop853"
                    and (self.rtol < dtype_epsilon or self.atol < dtype_epsilon)
                ),
            },
        )
        return normalized, evidence


def build_blockade_basis(
    program: ProgramIR,
    blockade_radius: float,
) -> NDArray[np.int64]:
    """Return ordered full-space indexes that satisfy pair blockade constraints."""
    if not math.isfinite(blockade_radius) or blockade_radius < 0.0:
        raise ValueError("blockade_radius must be finite and non-negative.")
    atom_count = len(_atom_order(program))
    conflicts = _earlier_conflict_masks(program, blockade_radius)
    indices: list[int] = []

    # Unoccupied-first depth-first traversal preserves ascending full-space indexes.
    def visit(atom_index: int, occupied: int, basis_index: int) -> None:
        if atom_index == atom_count:
            indices.append(basis_index)
            return
        visit(atom_index + 1, occupied, basis_index)
        if occupied & conflicts[atom_index] == 0:
            bit = 1 << (atom_count - atom_index - 1)
            visit(atom_index + 1, occupied | (1 << atom_index), basis_index | bit)

    visit(0, 0, 0)
    return np.asarray(indices, dtype=np.int64)


def blockade_basis_dimension(program: ProgramIR, blockade_radius: float) -> int:
    """Count the explicit blockade basis without materializing basis indexes."""
    if not math.isfinite(blockade_radius) or blockade_radius < 0.0:
        raise ValueError("blockade_radius must be finite and non-negative.")
    atom_count = len(_atom_order(program))
    conflicts = _earlier_conflict_masks(program, blockade_radius)

    @cache
    def count(atom_index: int, occupied: int) -> int:
        if atom_index == atom_count:
            return 1
        total = count(atom_index + 1, occupied)
        if occupied & conflicts[atom_index] == 0:
            total += count(atom_index + 1, occupied | (1 << atom_index))
        return total

    return count(0, 0)


def _earlier_conflict_masks(
    program: ProgramIR,
    blockade_radius: float,
) -> tuple[int, ...]:
    masks = [0] * len(_atom_order(program))
    for left, right in _blockade_pairs(program, blockade_radius):
        masks[right] |= 1 << left
    return tuple(masks)


def _local_matrix_action(matrix: ComplexArray, values: ComplexArray) -> ComplexArray:
    output = np.zeros_like(values)
    for row in range(matrix.shape[0]):
        for column in range(matrix.shape[1]):
            coefficient = matrix[row, column]
            if coefficient != 0:
                output[row] += coefficient * values[column]
    return output


def _state_result(
    state: StateVectorState | SubspaceState,
    *,
    result_id: str,
    program_hash: str,
    target_id: str,
    shots: int,
    seed: int | None,
    return_probabilities: bool,
    program_kind: Literal["digital", "analog", "hybrid"],
    observables: ObservableSet | None = None,
) -> ResultIR:
    state_norm = float(np.linalg.norm(state.amplitudes))
    width = len(state.logical_order)
    probabilities: dict[str, float] | None = None
    if shots > 0 or return_probabilities:
        probabilities_array: NDArray[np.float64] = np.asarray(
            np.abs(state.amplitudes) ** 2,
            dtype=np.float64,
        )
        probability_sum = float(np.sum(probabilities_array))
        if probability_sum <= 0.0 or not math.isfinite(probability_sum):
            raise ProgramValidationError(
                "Scalable state has invalid total probability.",
                code="SCALABLE_STATE_PROBABILITY_INVALID",
                stage="simulation",
                object_path="simulation_state.amplitudes",
                metadata={"probability_sum": probability_sum},
            )
        probabilities_array = probabilities_array / probability_sum
        basis_indices = (
            None if isinstance(state, StateVectorState) else state.basis_indices
        )
        if shots > 0:
            sampled = np.random.default_rng(seed).choice(
                state.dimension,
                size=shots,
                p=probabilities_array,
            )
            samples = tuple(
                format(
                    (
                        int(index)
                        if basis_indices is None
                        else int(basis_indices[int(index)])
                    ),
                    f"0{width}b",
                )
                for index in sampled
            )
            counts = dict(Counter(samples))
        else:
            samples = ()
            counts = {}
        if return_probabilities:
            probabilities = {
                format(
                    index if basis_indices is None else int(basis_indices[index]),
                    f"0{width}b",
                ): float(value)
                for index, value in enumerate(probabilities_array)
            }
    else:
        samples = ()
        counts = {}
    diagnostic = DiagnosticsIR(
        diagnostic_id=f"simulation.scalable.{program_kind}.completed",
        stage="simulation",
        severity="info",
        code="SCALABLE_IDEAL_SIMULATION_COMPLETED",
        message="Scalable ideal state-vector simulation completed.",
        object_path="result",
        metadata={"program_kind": program_kind},
    )
    references = ResultReferencesIR(program_hash=program_hash)
    observable_batch = (
        None if observables is None else evaluate_observables(state, observables)
    )
    return ResultIR(
        result_id=result_id,
        program_hash=program_hash,
        target_id=target_id,
        shots=shots,
        counts=counts,
        samples=samples,
        probabilities=probabilities,
        observables={
            "state_norm": state_norm,
        },
        observable_batch=observable_batch,
        bit_ordering={
            "convention": "logical_order",
            "logical_order": ",".join(state.logical_order),
        },
        diagnostics=(diagnostic,),
        metadata={
            "seed": seed,
            "references": references.to_dict(),
            "simulator": {
                "name": "ScalableIdealEngine",
                "method": (
                    "state_vector"
                    if isinstance(state, StateVectorState)
                    else "subspace"
                ),
                "array_backend": "numpy.cpu",
                "program_kind": program_kind,
            },
            "bitstring_ordering": {
                "convention": "logical_order",
                "logical_order": list(state.logical_order),
                "bitstring_index": "left_to_right_matches_logical_order",
            },
            "simulation_state": state.to_dict(),
            "state_hash": state.stable_hash(),
            "state_bytes_returned": False,
            "offline_deterministic": True,
            "network_accessed": False,
        },
    )


def _analog_linear_operator(
    program: ProgramIR,
    *,
    time: float,
    dtype: np.dtype[Any],
    blockade_radius: float,
    basis_indices: NDArray[np.integer[Any]] | None,
) -> tuple[LinearOperator, complex]:
    atom_count = len(_atom_order(program))
    full_dimension = 2**atom_count
    basis = (
        np.arange(full_dimension, dtype=np.int64)
        if basis_indices is None
        else np.asarray(basis_indices, dtype=np.int64)
    )
    diagonal = _analog_diagonal(
        program,
        basis,
        time=time,
        blockade_radius=blockade_radius,
    ).astype(dtype, copy=False)
    rabi = _sample_waveform(program.hamiltonian.rabi, time)
    phase = _sample_phase(program, time)
    local_fields = sample_local_rabi_fields(program, time)
    lookup: NDArray[np.int64] | None = None
    if basis_indices is not None:
        lookup = np.full(full_dimension, -1, dtype=np.int64)
        lookup[basis] = np.arange(basis.size, dtype=np.int64)

    def matmat(matrix: NDArray[Any]) -> ComplexArray:
        values = np.asarray(matrix, dtype=dtype).reshape(basis.size, -1)
        output: ComplexArray = np.asarray(
            diagonal[:, np.newaxis] * values,
            dtype=dtype,
        )
        if rabi == 0.0 and not any(
            amplitude != 0.0 for amplitude, _, _ in local_fields
        ):
            return output
        # The batch axis is retained so one index traversal serves every vector.
        for atom_index in range(atom_count):
            mask = 1 << (atom_count - atom_index - 1)
            occupied = (basis & mask) != 0
            # Coefficients are indexed by the source basis state: g -> r uses
            # exp(+i*phase), while r -> g uses its Hermitian conjugate.
            global_coefficient = rabi * np.where(
                occupied,
                np.exp(-1j * phase),
                np.exp(1j * phase),
            )
            local_coefficient: ComplexArray = np.zeros(basis.size, dtype=dtype)
            # Addressed lasers are coherent fields: every declared complex
            # amplitude contributes before the Hamiltonian flips this site.
            for local_amplitude, local_phases, weights in local_fields:
                local_phase = local_phases[atom_index]
                local_coefficient += np.asarray(
                    local_amplitude
                    * weights[atom_index]
                    * np.where(
                        occupied,
                        np.exp(-1j * local_phase),
                        np.exp(1j * local_phase),
                    ),
                    dtype=dtype,
                )
            # Global and addressed lasers are coherent fields, so their complex
            # amplitudes add before the Hamiltonian acts on the state.
            coefficient = 0.5 * (global_coefficient + local_coefficient)
            flipped = basis ^ mask
            if lookup is None:
                output[flipped] += coefficient[:, np.newaxis] * values
            else:
                targets = lookup[flipped]
                valid = targets >= 0
                output[targets[valid]] += coefficient[valid, np.newaxis] * values[valid]
        return np.asarray(output, dtype=dtype)

    def matvec(vector: NDArray[Any]) -> ComplexArray:
        return matmat(vector).reshape(-1)

    operator = LinearOperator(
        (basis.size, basis.size),
        matvec=matvec,
        matmat=matmat,
        rmatvec=matvec,
        rmatmat=matmat,
        dtype=dtype,
    )
    return operator, complex(np.sum(diagonal))


@dataclass(frozen=True, eq=False)
class _DiagonalKrylovPlan:
    """SciPy-compatible plan for repeated exact diagonal expm actions."""

    diagonal: ComplexArray
    scale: complex
    mu: complex
    m_star: int
    scaling_steps: int
    tolerance: float


@dataclass(frozen=True, eq=False)
class _DiagonalKrylovWorkspace:
    current: ComplexArray
    accumulated: ComplexArray
    next_term: ComplexArray
    magnitudes: NDArray[np.float64]


@dataclass(frozen=True, eq=False)
class _ThreadedDiagonalKrylovWorkspace:
    current: ComplexArray
    accumulated: ComplexArray
    next_term: ComplexArray
    magnitudes: NDArray[np.float64]
    chunks: tuple[tuple[int, int], ...]
    executor: ThreadPoolExecutor

    def close(self) -> None:
        self.executor.shutdown(wait=True, cancel_futures=True)


@dataclass(frozen=True, eq=False)
class _AnalogDiagonalWorkspace:
    basis_size: int
    atom_count: int
    occupations: tuple[NDArray[np.bool_], ...]
    interaction_occupations: tuple[tuple[float, NDArray[np.bool_]], ...]


def _analog_is_diagonal(program: ProgramIR, *, time: float) -> bool:
    """Return whether the sampled Hamiltonian has no off-diagonal Rabi action."""
    if _sample_waveform(program.hamiltonian.rabi, time) != 0.0:
        return False
    return not any(
        amplitude != 0.0
        for amplitude, _, _ in sample_local_rabi_fields(program, time)
    )


def _build_diagonal_krylov_plan(
    diagonal: ComplexArray,
    *,
    scale: complex,
) -> _DiagonalKrylovPlan:
    """Build the same norm and Taylor plan used by SciPy expm_multiply."""
    diagonal = np.asarray(diagonal, dtype=np.complex128)
    if diagonal.ndim != 1 or diagonal.size == 0:
        raise ValueError("diagonal must be a non-empty one-dimensional array.")
    trace = complex(np.sum(diagonal))
    mu = scale * trace / float(diagonal.size)
    centered = _diagonal_centered_operator(diagonal, scale=scale, mu=mu)
    one_norm = float(onenormest(centered))
    tolerance = 2**-53
    if one_norm == 0.0:
        m_star, scaling_steps = 0, 1
    else:
        norm_info = LazyOperatorNormInfo(
            centered,
            A_1_norm=one_norm,
            ell=2,
        )
        m_star, scaling_steps = _fragment_3_1(
            norm_info,
            1,
            tolerance,
            ell=2,
        )
    return _DiagonalKrylovPlan(
        diagonal=diagonal,
        scale=scale,
        mu=mu,
        m_star=int(m_star),
        scaling_steps=int(scaling_steps),
        tolerance=tolerance,
    )


def _diagonal_centered_operator(
    diagonal: ComplexArray,
    *,
    scale: complex,
    mu: complex,
) -> LinearOperator:
    """Create the centered action with SciPy's original arithmetic ordering."""
    dimension = int(diagonal.size)

    def action(values: NDArray[Any], *, adjoint: bool) -> ComplexArray:
        raw = np.asarray(values, dtype=np.complex128)
        shaped = raw.reshape(dimension, -1)
        hamiltonian_action = np.asarray(
            diagonal[:, np.newaxis] * shaped,
            dtype=np.complex128,
        )
        factor = np.conj(scale) if adjoint else scale
        shift = -np.conj(mu) if adjoint else -mu
        scaled = factor * hamiltonian_action
        shifted = shift * shaped
        return np.asarray(scaled + shifted, dtype=np.complex128).reshape(raw.shape)

    return LinearOperator(
        (dimension, dimension),
        matvec=lambda vector: action(vector, adjoint=False),
        matmat=lambda matrix: action(matrix, adjoint=False),
        rmatvec=lambda vector: action(vector, adjoint=True),
        rmatmat=lambda matrix: action(matrix, adjoint=True),
        dtype=np.dtype(np.complex128),
    )


def _apply_diagonal_krylov_plan(
    plan: _DiagonalKrylovPlan,
    vector: ComplexArray,
    *,
    workspace: _DiagonalKrylovWorkspace | None = None,
) -> ComplexArray:
    """Apply SciPy's simple-core recurrence with reusable NumPy work arrays."""
    values = np.asarray(vector, dtype=np.complex128)
    if values.ndim != 1 or values.size != plan.diagonal.size:
        raise ValueError("vector shape does not match the diagonal Krylov plan.")
    if workspace is None:
        workspace = _build_diagonal_krylov_workspace(values)
    elif workspace.current.shape != values.shape:
        raise ValueError("Krylov workspace shape does not match the vector.")
    current = workspace.current
    accumulated = workspace.accumulated
    next_term = workspace.next_term
    np.copyto(current, values)
    np.copyto(accumulated, current)
    eta = np.exp(plan.mu / float(plan.scaling_steps))

    for _ in range(plan.scaling_steps):
        previous_norm = _workspace_infinity_norm(current, workspace.magnitudes)
        accumulated_norm_upper = previous_norm
        for order in range(plan.m_star):
            coefficient = 1.0 / float(plan.scaling_steps * (order + 1))
            np.multiply(plan.diagonal, current, out=next_term)
            np.multiply(plan.scale, next_term, out=next_term)
            np.multiply(-plan.mu, current, out=current)
            np.add(next_term, current, out=next_term)
            np.multiply(coefficient, next_term, out=next_term)
            next_norm = _workspace_infinity_norm(next_term, workspace.magnitudes)
            np.add(accumulated, next_term, out=accumulated)
            norm_sum = previous_norm + next_norm
            # A conservative triangle bound rejects impossible stop checks without
            # scanning the full accumulated vector at every Krylov order.
            accumulated_norm_upper = math.nextafter(
                (accumulated_norm_upper + next_norm)
                * _KRYLOV_NORM_BOUND_MARGIN,
                math.inf,
            )
            should_stop = False
            if norm_sum <= plan.tolerance * accumulated_norm_upper:
                accumulated_norm = _workspace_infinity_norm(
                    accumulated,
                    workspace.magnitudes,
                )
                should_stop = norm_sum <= plan.tolerance * accumulated_norm
                accumulated_norm_upper = accumulated_norm
            current, next_term = next_term, current
            if should_stop:
                break
            previous_norm = next_norm
        np.multiply(eta, accumulated, out=accumulated)
        current[...] = accumulated
    return accumulated


def _apply_diagonal_krylov_plan_threaded(
    plan: _DiagonalKrylovPlan,
    vector: ComplexArray,
    *,
    workspace: _ThreadedDiagonalKrylovWorkspace,
) -> ComplexArray:
    """Apply the recurrence over disjoint NumPy chunks in persistent threads."""
    values = np.asarray(vector, dtype=np.complex128)
    if values.ndim != 1 or values.size != plan.diagonal.size:
        raise ValueError("vector shape does not match the diagonal Krylov plan.")
    if workspace.current.shape != values.shape:
        raise ValueError("threaded Krylov workspace shape does not match the vector.")
    current = workspace.current
    accumulated = workspace.accumulated
    next_term = workspace.next_term
    np.copyto(current, values)
    np.copyto(accumulated, current)
    eta = np.exp(plan.mu / float(plan.scaling_steps))

    for _ in range(plan.scaling_steps):
        previous_norm = _threaded_workspace_infinity_norm(current, workspace)
        accumulated_norm_upper = previous_norm
        for order in range(plan.m_star):
            coefficient = 1.0 / float(plan.scaling_steps * (order + 1))
            next_norm = max(
                workspace.executor.map(
                    _threaded_krylov_step,
                    repeat(plan),
                    repeat(current),
                    repeat(next_term),
                    repeat(accumulated),
                    repeat(workspace.magnitudes),
                    repeat(coefficient),
                    workspace.chunks,
                ),
                default=0.0,
            )
            norm_sum = previous_norm + next_norm
            accumulated_norm_upper = math.nextafter(
                (accumulated_norm_upper + next_norm)
                * _KRYLOV_NORM_BOUND_MARGIN,
                math.inf,
            )
            should_stop = False
            if norm_sum <= plan.tolerance * accumulated_norm_upper:
                accumulated_norm = _threaded_workspace_infinity_norm(
                    accumulated,
                    workspace,
                )
                should_stop = norm_sum <= plan.tolerance * accumulated_norm
                accumulated_norm_upper = accumulated_norm
            current, next_term = next_term, current
            if should_stop:
                break
            previous_norm = next_norm
        tuple(
            workspace.executor.map(
                _threaded_scale_copy,
                repeat(eta),
                repeat(accumulated),
                repeat(current),
                workspace.chunks,
            )
        )
    return accumulated


def _threaded_krylov_step(
    plan: _DiagonalKrylovPlan,
    current: ComplexArray,
    next_term: ComplexArray,
    accumulated: ComplexArray,
    magnitudes: NDArray[np.float64],
    coefficient: float,
    chunk: tuple[int, int],
) -> float:
    start, stop = chunk
    current_chunk = current[start:stop]
    next_chunk = next_term[start:stop]
    np.multiply(plan.diagonal[start:stop], current_chunk, out=next_chunk)
    np.multiply(plan.scale, next_chunk, out=next_chunk)
    np.multiply(-plan.mu, current_chunk, out=current_chunk)
    np.add(next_chunk, current_chunk, out=next_chunk)
    np.multiply(coefficient, next_chunk, out=next_chunk)
    magnitude_chunk = magnitudes[start:stop]
    np.absolute(next_chunk, out=magnitude_chunk)
    local_norm = float(magnitude_chunk.max(initial=0.0))
    np.add(accumulated[start:stop], next_chunk, out=accumulated[start:stop])
    return local_norm


def _threaded_workspace_infinity_norm(
    values: ComplexArray,
    workspace: _ThreadedDiagonalKrylovWorkspace,
) -> float:
    return max(
        workspace.executor.map(
            _threaded_norm_chunk,
            repeat(values),
            repeat(workspace.magnitudes),
            workspace.chunks,
        ),
        default=0.0,
    )


def _threaded_norm_chunk(
    values: ComplexArray,
    magnitudes: NDArray[np.float64],
    chunk: tuple[int, int],
) -> float:
    start, stop = chunk
    magnitude_chunk = magnitudes[start:stop]
    np.absolute(values[start:stop], out=magnitude_chunk)
    return float(magnitude_chunk.max(initial=0.0))


def _threaded_scale_copy(
    eta: complex,
    accumulated: ComplexArray,
    current: ComplexArray,
    chunk: tuple[int, int],
) -> None:
    start, stop = chunk
    accumulated_chunk = accumulated[start:stop]
    np.multiply(eta, accumulated_chunk, out=accumulated_chunk)
    current[start:stop] = accumulated_chunk


def _build_diagonal_krylov_workspace(
    vector: ComplexArray,
) -> _DiagonalKrylovWorkspace:
    values = np.asarray(vector, dtype=np.complex128)
    if values.ndim != 1 or values.size == 0:
        raise ValueError("Krylov workspace requires a non-empty vector.")
    return _DiagonalKrylovWorkspace(
        current=np.empty_like(values),
        accumulated=np.empty_like(values),
        next_term=np.empty_like(values),
        magnitudes=np.empty(values.size, dtype=np.float64),
    )


def _build_threaded_diagonal_krylov_workspace(
    vector: ComplexArray,
    *,
    kernel_threads: int,
) -> _ThreadedDiagonalKrylovWorkspace:
    values = np.asarray(vector, dtype=np.complex128)
    if values.ndim != 1 or values.size == 0:
        raise ValueError("threaded Krylov workspace requires a non-empty vector.")
    if (
        not isinstance(kernel_threads, int)
        or isinstance(kernel_threads, bool)
        or kernel_threads <= 1
    ):
        raise ValueError("threaded Krylov workspace requires at least two threads.")
    chunks = tuple(
        (
            values.size * index // kernel_threads,
            values.size * (index + 1) // kernel_threads,
        )
        for index in range(kernel_threads)
    )
    return _ThreadedDiagonalKrylovWorkspace(
        current=np.empty_like(values),
        accumulated=np.empty_like(values),
        next_term=np.empty_like(values),
        magnitudes=np.empty(values.size, dtype=np.float64),
        chunks=chunks,
        executor=ThreadPoolExecutor(max_workers=kernel_threads),
    )


def _workspace_infinity_norm(
    values: ComplexArray,
    magnitudes: NDArray[np.float64],
) -> float:
    np.absolute(values, out=magnitudes)
    return float(magnitudes.max(initial=0.0))


def _build_analog_diagonal_workspace(
    program: ProgramIR,
    basis: NDArray[np.int64],
    *,
    blockade_radius: float,
) -> _AnalogDiagonalWorkspace:
    atom_count = len(_atom_order(program))
    occupations = tuple(
        (basis & (1 << (atom_count - atom_index - 1))) != 0
        for atom_index in range(atom_count)
    )
    interaction_occupations = tuple(
        (strength, occupations[left] * occupations[right])
        for left, right, strength in _interaction_pairs(program, blockade_radius)
    )
    return _AnalogDiagonalWorkspace(
        basis_size=int(basis.size),
        atom_count=atom_count,
        occupations=occupations,
        interaction_occupations=interaction_occupations,
    )


def _analog_diagonal(
    program: ProgramIR,
    basis: NDArray[np.int64],
    *,
    time: float,
    blockade_radius: float,
    workspace: _AnalogDiagonalWorkspace | None = None,
) -> NDArray[np.float64]:
    atom_count = len(_atom_order(program))
    if workspace is None:
        workspace = _build_analog_diagonal_workspace(
            program,
            basis,
            blockade_radius=blockade_radius,
        )
    elif workspace.basis_size != basis.size or workspace.atom_count != atom_count:
        raise ValueError("Analog diagonal workspace does not match the basis.")
    detuning = _sample_waveform(program.hamiltonian.detuning, time)
    diagonal = np.zeros(basis.size, dtype=np.float64)
    for occupied in workspace.occupations:
        diagonal -= detuning * occupied
    for term in program.hamiltonian.local_detuning_terms:
        local_value = _sample_waveform(term.waveform, time)
        for atom_index, weight in enumerate(term.addressing.weights_at(time)):
            diagonal -= local_value * weight * workspace.occupations[atom_index]
    for strength, occupied_pair in workspace.interaction_occupations:
        diagonal += strength * occupied_pair
    return diagonal


def _validate_analog_inputs(
    program: ProgramIR,
    logical_order: tuple[str, ...],
) -> None:
    if not isinstance(program, ProgramIR):
        raise TypeError("program must be ProgramIR.")
    if logical_order != _atom_order(program):
        raise ProgramValidationError(
            "Analog register order does not match scalable state order.",
            code="ANALOG_ARRAY_STATE_LOGICAL_ORDER_MISMATCH",
            stage="simulation",
            object_path="simulation_state.logical_order",
        )


def _analog_provenance(
    program: ProgramIR,
    parent_hash: str,
    parent_step: int,
    *,
    representation: str,
    evidence: SimulationSolverEvidenceIR,
) -> ArrayStateProvenance:
    return ArrayStateProvenance(
        producer="MatrixFreeAnalogStateVectorKernel",
        parent_state_hash=parent_hash,
        step_index=parent_step + 1,
        metadata={
            "program_hash": program.stable_hash(),
            "algorithm": (
                "adaptive_dop853"
                if evidence.integrator_selected == "adaptive_dop853"
                else "piecewise_midpoint_expm_multiply"
            ),
            "integrator_selected": evidence.integrator_selected,
            "representation": representation,
            "steps": evidence.accepted_steps,
            "solver_evidence": evidence.to_dict(),
            "solver_evidence_hash": evidence.stable_hash(),
            **site_addressing_provenance_metadata(
                program,
                consumer=f"MatrixFreeAnalogStateVectorKernel.{representation}",
            ),
            **site_phase_pattern_provenance_metadata(
                program,
                consumer=f"MatrixFreeAnalogStateVectorKernel.{representation}",
            ),
        },
    )


def _atom_order(program: ProgramIR) -> tuple[str, ...]:
    return tuple(str(site.atom_id) for site in program.register.sites if site.is_active)


def _duration(program: ProgramIR) -> float:
    waveforms = [program.hamiltonian.rabi, program.hamiltonian.detuning]
    waveforms.extend(term.waveform for term in program.hamiltonian.local_detuning_terms)
    for term in program.hamiltonian.local_rabi_terms:
        waveforms.append(term.rabi)
        if isinstance(term.phase, WaveformIR):
            waveforms.append(term.phase)
    return max(waveform.duration for waveform in waveforms)


def _sample_phase(program: ProgramIR, time: float) -> float:
    phase = program.hamiltonian.phase
    if isinstance(phase, WaveformIR):
        return _sample_waveform(phase, time)
    return float(phase)


def _sample_control_phase(phase: WaveformIR | float, time: float) -> float:
    return _sample_waveform(phase, time) if isinstance(phase, WaveformIR) else phase


def _blockade_pairs(
    program: ProgramIR,
    blockade_radius: float,
) -> tuple[tuple[int, int], ...]:
    sites = tuple(site for site in program.register.sites if site.is_active)
    return tuple(
        (left, right)
        for left in range(len(sites))
        for right in range(left + 1, len(sites))
        if math.dist(sites[left].position, sites[right].position) < blockade_radius
    )


def _interaction_pairs(
    program: ProgramIR,
    blockade_radius: float,
) -> tuple[tuple[int, int, float], ...]:
    sites = tuple(site for site in program.register.sites if site.is_active)
    pairs: list[tuple[int, int, float]] = []
    for left in range(len(sites)):
        for right in range(left + 1, len(sites)):
            distance = math.dist(sites[left].position, sites[right].position)
            if distance <= 0.0:
                strength = 1e6
            elif distance < blockade_radius:
                strength = (blockade_radius / distance) ** 6 * math.pi
            else:
                strength = 0.0
            if strength:
                pairs.append((left, right, strength))
    return tuple(pairs)


def _gate_matrix(gate: GateIR, *, dtype: np.dtype[Any]) -> ComplexArray:
    name = gate.name
    values: object
    if name == "x":
        values = ((0, 1), (1, 0))
    elif name == "y":
        values = ((0, -1j), (1j, 0))
    elif name == "z":
        values = ((1, 0), (0, -1))
    elif name == "h":
        scale = 1 / math.sqrt(2)
        values = ((scale, scale), (scale, -scale))
    elif name in {"s", "sdg", "t", "tdg", "p"}:
        angle = {
            "s": math.pi / 2,
            "sdg": -math.pi / 2,
            "t": math.pi / 4,
            "tdg": -math.pi / 4,
            "p": gate.parameters.get("theta", gate.parameters.get("lambda", 0.0)),
        }[name]
        values = ((1, 0), (0, np.exp(1j * angle)))
    elif name in {"rx", "ry", "rz"}:
        return _rotation_matrix(name, gate.parameters["theta"], dtype=dtype)
    elif name == "u":
        theta = gate.parameters["theta"]
        phi = gate.parameters["phi"]
        lam = gate.parameters["lambda"]
        values = (
            (math.cos(theta / 2), -np.exp(1j * lam) * math.sin(theta / 2)),
            (
                np.exp(1j * phi) * math.sin(theta / 2),
                np.exp(1j * (phi + lam)) * math.cos(theta / 2),
            ),
        )
    elif name in {"cx", "cy", "cz", "swap"}:
        return _two_qubit_matrix(name, dtype=dtype)
    elif name == "ccx":
        matrix = np.eye(8, dtype=dtype)
        matrix[[6, 7]] = matrix[[7, 6]]
        return matrix
    else:
        raise ProgramValidationError(
            f"Digital gate '{name}' is not supported by the scalable kernel.",
            code="DIGITAL_ARRAY_GATE_UNSUPPORTED",
            stage="simulation",
            object_path=f"digital_gates.{gate.gate_id}.name",
        )
    return np.asarray(values, dtype=dtype)


def _rotation_matrix(
    name: str,
    theta: float,
    *,
    dtype: np.dtype[Any],
) -> ComplexArray:
    cosine = math.cos(theta / 2)
    sine = math.sin(theta / 2)
    if name == "rx":
        values = ((cosine, -1j * sine), (-1j * sine, cosine))
    elif name == "ry":
        values = ((cosine, -sine), (sine, cosine))
    else:
        values = (
            (np.exp(-0.5j * theta), 0),
            (0, np.exp(0.5j * theta)),
        )
    return np.asarray(values, dtype=dtype)


def _two_qubit_matrix(name: str, *, dtype: np.dtype[Any]) -> ComplexArray:
    matrix = np.eye(4, dtype=dtype)
    if name == "cx":
        matrix[[2, 3]] = matrix[[3, 2]]
    elif name == "cy":
        matrix[2:, 2:] = np.asarray(((0, -1j), (1j, 0)), dtype=dtype)
    elif name == "cz":
        matrix[3, 3] = -1
    else:
        matrix[[1, 2]] = matrix[[2, 1]]
    return matrix
