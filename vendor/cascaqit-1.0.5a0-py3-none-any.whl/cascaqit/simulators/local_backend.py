"""Unified offline Backend for Native Digital, Analog, and Hybrid programs."""

from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping
from dataclasses import dataclass, replace
from datetime import datetime, timezone
from os import PathLike
from typing import TYPE_CHECKING, Any, Literal, cast, overload

from cascaqit.backends.execution import (
    ExecutionJobProtocol,
    LocalBackendCapabilityIR,
    LocalExecutionJob,
)
from cascaqit.backends.job_history import (
    JobDefinitionIR,
    JobHistoryPage,
    JobHistoryQuery,
    JobKind,
    JobProgramKind,
    RetryPolicy,
)
from cascaqit.backends.job_state import JobState
from cascaqit.backends.job_store import SQLiteJobStore
from cascaqit.backends.persistent_execution import PersistentLocalExecutionJob
from cascaqit.backends.persistent_sweep import PersistentLocalHybridScanJob
from cascaqit.control import (
    ControlSystemIR,
    build_control_schedule,
    validate_control_schedule,
)
from cascaqit.exceptions import CapabilityError, ProgramValidationError
from cascaqit.native_ir import ProgramIR, SimulatorConfigIR
from cascaqit.native_ir.base import stable_json
from cascaqit.results import ResultIR
from cascaqit.simulators.digital import (
    _SIMULATOR_SUPPORTED_GATES,
    LocalDigitalSimulator,
    _validate_program_for_simulation,
)
from cascaqit.simulators.execution_evidence import (
    execution_config_metadata,
    require_result_solver_evidence,
)
from cascaqit.simulators.ideal import (
    blockade_basis_dimension,
    run_scalable_analog_ideal,
    run_scalable_digital_ideal,
    run_scalable_hybrid_ideal,
    validate_scalable_hybrid_bundle,
)
from cascaqit.simulators.local_ahs import AnalogStateVectorKernel
from cascaqit.simulators.local_hybrid import (
    _HYBRID_ANALOG_WAVEFORMS,
    AnalogStepAdapter,
    AnalogStepPayload,
    LocalHybridScanFailurePolicy,
    LocalHybridScanItemOutcome,
    LocalHybridScanJob,
    LocalHybridSimulator,
    _derive_scan_seed,
    _make_scan_item_executor,
)
from cascaqit.simulators.parallel_execution import (
    ParallelExecutionPlanner,
    ParallelExecutionRequest,
)
from cascaqit.simulators.physical_noise import (
    NoiseModel,
    run_physical_noisy_hybrid,
    validate_physical_noise_bundle,
)
from cascaqit.simulators.planning import (
    SimulationExecutionPlan,
    SimulationOptions,
    SimulationPlanner,
    SimulationPlanningRequest,
)

if TYPE_CHECKING:
    from cascaqit.analog import AHSProgram
    from cascaqit.digital import Circuit, DigitalProgramIR
    from cascaqit.hybrid import HybridProgram
    from cascaqit.observables import ObservableSet
    from cascaqit.parameters import ParameterScan
    from cascaqit.targets import TargetSpec

__all__ = ["LocalBackend"]

_REFERENCE_DIGITAL_MAX_SITES = 4
_REFERENCE_ANALOG_MAX_SITES = 5
_REFERENCE_HYBRID_MAX_SITES = 2


@dataclass(frozen=True)
class LocalBackend:
    """Recommended offline Backend for all current Native program kinds."""

    seed: int | None = None
    target: TargetSpec | None = None
    analog_time_steps: int = 400
    created_at: str | None = None
    backend_id: str = "local.simulator"
    store: str | PathLike[str] | None = None
    kernel_threads: int = 1

    def __post_init__(self) -> None:
        from cascaqit.targets import TargetSpec

        _validate_seed(self.seed)
        if self.target is not None and not isinstance(self.target, TargetSpec):
            raise TypeError("target must be TargetSpec or None.")
        if (
            not isinstance(self.analog_time_steps, int)
            or isinstance(self.analog_time_steps, bool)
            or self.analog_time_steps <= 0
        ):
            raise ValueError("analog_time_steps must be a positive integer.")
        if not isinstance(self.backend_id, str) or not self.backend_id.strip():
            raise ValueError("backend_id must be a non-empty string.")
        if self.store is not None and (
            not isinstance(self.store, (str, PathLike)) or not str(self.store)
        ):
            raise ValueError("store must be a non-empty path or None.")
        if (
            not isinstance(self.kernel_threads, int)
            or isinstance(self.kernel_threads, bool)
            or self.kernel_threads <= 0
        ):
            raise ValueError("kernel_threads must be a positive integer.")

    @property
    def capability(self) -> LocalBackendCapabilityIR:
        """Return the resource-driven offline execution capability."""
        return LocalBackendCapabilityIR(
            backend_id=self.backend_id,
            supported_digital_gates=tuple(sorted(_SIMULATOR_SUPPORTED_GATES)),
            supported_analog_waveforms=tuple(sorted(_HYBRID_ANALOG_WAVEFORMS)),
            executable_simulation_methods=(
                "state_vector",
                "subspace",
                "density_matrix",
                "trajectory",
            ),
            unified_scan_supported=True,
            noise_supported=True,
        )

    @overload
    def run(
        self,
        program: HybridProgram,
        *,
        params: None = None,
        sweep: ParameterScan,
        noise: NoiseModel | None = None,
        options: SimulationOptions | None = None,
        shots: int | None = None,
        seed: int | None = None,
        job_id: str | None = None,
        config: SimulatorConfigIR | None = None,
        observables: ObservableSet | None = None,
        failure_policy: LocalHybridScanFailurePolicy = "fail_fast",
        retry: RetryPolicy | None = None,
        idempotency_key: str | None = None,
    ) -> LocalHybridScanJob | PersistentLocalHybridScanJob: ...

    @overload
    def run(
        self,
        program: Circuit | DigitalProgramIR | AHSProgram | ProgramIR | HybridProgram,
        *,
        params: Mapping[str, bool | int | float] | None = None,
        sweep: None = None,
        noise: NoiseModel | None = None,
        options: SimulationOptions | None = None,
        shots: int | None = None,
        seed: int | None = None,
        job_id: str | None = None,
        config: SimulatorConfigIR | None = None,
        observables: ObservableSet | None = None,
        failure_policy: LocalHybridScanFailurePolicy = "fail_fast",
        retry: RetryPolicy | None = None,
        idempotency_key: str | None = None,
    ) -> ExecutionJobProtocol: ...

    def run(
        self,
        program: (Circuit | DigitalProgramIR | AHSProgram | ProgramIR | HybridProgram),
        *,
        params: Mapping[str, bool | int | float] | None = None,
        sweep: ParameterScan | None = None,
        noise: NoiseModel | None = None,
        options: SimulationOptions | None = None,
        shots: int | None = None,
        seed: int | None = None,
        job_id: str | None = None,
        config: SimulatorConfigIR | None = None,
        observables: ObservableSet | None = None,
        failure_policy: LocalHybridScanFailurePolicy = "fail_fast",
        retry: RetryPolicy | None = None,
        idempotency_key: str | None = None,
    ) -> ExecutionJobProtocol | LocalHybridScanJob | PersistentLocalHybridScanJob:
        """Preflight one Native program and return a submitted local Job."""
        if retry is not None and not isinstance(retry, RetryPolicy):
            raise TypeError("retry must be RetryPolicy or None.")
        if idempotency_key is not None and (
            not isinstance(idempotency_key, str) or not idempotency_key.strip()
        ):
            raise ValueError("idempotency_key must be a non-empty string or None.")
        if self.store is None:
            if retry is not None or idempotency_key is not None:
                raise CapabilityError(
                    "Job retry and idempotency require LocalBackend(store=...).",
                    code="LOCAL_BACKEND_STORE_REQUIRED",
                    stage="backend",
                    object_path="backend.run.retry",
                )
            return self._run_in_memory(
                program,
                params=params,
                sweep=sweep,
                noise=noise,
                options=options,
                shots=shots,
                seed=seed,
                job_id=job_id,
                config=config,
                observables=observables,
                failure_policy=failure_policy,
            )
        if sweep is not None:
            from cascaqit.hybrid import HybridProgram

            if not isinstance(program, HybridProgram):
                raise CapabilityError(
                    "Persistent parameter sweeps require HybridProgram.",
                    code="LOCAL_BACKEND_SWEEP_PROGRAM_UNSUPPORTED",
                    stage="backend",
                    object_path="backend.run.sweep",
                )
            return self._run_persistent_sweep(
                program,
                sweep=sweep,
                noise=noise,
                options=options,
                shots=shots,
                seed=seed,
                job_id=job_id,
                config=config,
                observables=observables,
                failure_policy=failure_policy,
                retry=RetryPolicy() if retry is None else retry,
                idempotency_key=idempotency_key,
            )
        return self._run_persistent(
            program,
            params=params,
            noise=noise,
            options=options,
            shots=shots,
            seed=seed,
            job_id=job_id,
            config=config,
            observables=observables,
            failure_policy=failure_policy,
            retry=RetryPolicy() if retry is None else retry,
            idempotency_key=idempotency_key,
        )

    def _run_in_memory(
        self,
        program: (Circuit | DigitalProgramIR | AHSProgram | ProgramIR | HybridProgram),
        *,
        params: Mapping[str, bool | int | float] | None = None,
        sweep: ParameterScan | None = None,
        noise: NoiseModel | None = None,
        options: SimulationOptions | None = None,
        shots: int | None = None,
        seed: int | None = None,
        job_id: str | None = None,
        config: SimulatorConfigIR | None = None,
        observables: ObservableSet | None = None,
        failure_policy: LocalHybridScanFailurePolicy = "fail_fast",
    ) -> ExecutionJobProtocol | LocalHybridScanJob:
        """Preflight one Native program and return a submitted local Job."""
        _validate_optional_shots(shots)
        _validate_seed(seed)
        if params is not None and not isinstance(params, Mapping):
            raise TypeError("params must be a mapping or None.")
        if params is not None and sweep is not None:
            raise ValueError("params and sweep are mutually exclusive.")
        if options is not None and not isinstance(options, SimulationOptions):
            raise TypeError("options must be SimulationOptions or None.")
        if noise is not None and not isinstance(noise, NoiseModel):
            raise TypeError("noise must be canonical NoiseModel or None.")
        if config is not None and not isinstance(config, SimulatorConfigIR):
            raise TypeError("config must be SimulatorConfigIR or None.")
        if self.kernel_threads > 1 and sweep is not None:
            raise CapabilityError(
                "Kernel threads cannot be combined with parameter sweep workers.",
                code="LOCAL_BACKEND_NESTED_PARALLELISM_UNSUPPORTED",
                stage="backend",
                object_path="backend.run.sweep.kernel_threads",
                suggestion="Use kernel_threads=1 for sweeps or submit one bind.",
                metadata={"kernel_threads": self.kernel_threads},
            )
        if self.kernel_threads > 1 and noise is not None:
            raise CapabilityError(
                "Kernel threads are not available for noisy simulation workers.",
                code="LOCAL_BACKEND_KERNEL_THREADS_UNSUPPORTED",
                stage="backend",
                object_path="backend.run.noise.kernel_threads",
                suggestion="Use kernel_threads=1 for noisy simulation.",
                metadata={"kernel_threads": self.kernel_threads},
            )

        from cascaqit.analog import AHSProgram
        from cascaqit.digital import Circuit, DigitalProgramIR
        from cascaqit.hybrid import HybridProgram, HybridProgramIR, LocalExecutionPlan
        from cascaqit.observables import ObservableSet

        if observables is not None and not isinstance(observables, ObservableSet):
            raise TypeError("observables must be ObservableSet or None.")
        if noise is not None and not isinstance(program, HybridProgram):
            wrapped = _wrap_noisy_single_program(program, params=params)
            return self._run_in_memory(
                wrapped,
                noise=noise,
                options=options,
                shots=shots,
                seed=seed,
                job_id=job_id,
                config=config,
                observables=observables,
            )

        if isinstance(program, HybridProgram):
            hybrid_shots = (
                shots
                if shots is not None
                else (1000 if config is None else config.shots)
            )
            hybrid_seed = _effective_execution_seed(
                requested_seed=seed,
                config_seed=None if config is None else config.seed,
                backend_seed=self.seed,
                options=options,
            )
            hybrid_return_probabilities = (
                True if config is None else config.return_probabilities
            )
            resolved_seed = hybrid_seed
            simulation_plan = _plan_execution(
                program_kind="hybrid",
                logical_sites=_hybrid_logical_sites(program),
                options=_resolved_options(options, seed=resolved_seed),
                time_integration_required=_hybrid_has_analog(program),
                noisy=noise is not None,
                requires_trajectory=(
                    False if noise is None else noise.requires_trajectory
                ),
            )
            if noise is None:
                _require_ideal_method(simulation_plan)
            else:
                _require_noisy_method(simulation_plan)
            if sweep is not None:
                execution_steps = _hybrid_execution_steps(
                    program,
                    analog_steps=min(
                        self.analog_time_steps,
                        simulation_plan.max_steps,
                    ),
                )
                builder = program.execution_builder(
                    shots=hybrid_shots,
                    seed=resolved_seed,
                    parameterized=True,
                )
                if noise is not None or observables is not None:
                    # Parameter binding can change numerical values but not the
                    # block/gate/schedule shape. Probe the first valid BindSet so
                    # structural execution prerequisites fail before Job creation.
                    expansion = sweep.expand(program.parameters)
                    if not expansion.has_errors:
                        probe = builder.build(
                            bind_set=expansion.bind_sets[0],
                            bundle_id=f"local_scan_preflight.{sweep.scan_id}",
                        )
                        if probe.bundle is None:
                            raise ProgramValidationError(
                                "Sweep failed payload binding preflight.",
                                code="LOCAL_BACKEND_SWEEP_PREFLIGHT_FAILED",
                                stage="backend",
                                object_path="backend.run.sweep",
                                diagnostics=probe.diagnostics,
                            )
                        _validate_observable_targets(
                            observables,
                            probe.bundle.payloads[0].logical_order,
                        )
                        _validate_noisy_observable_compatibility(
                            observables,
                            noise,
                            probe.bundle.payloads[0].logical_order,
                        )
                        if noise is not None:
                            validate_physical_noise_bundle(
                                probe.bundle,
                                noise,
                                method=cast(
                                    Literal["density_matrix", "trajectory"],
                                    simulation_plan.method_selected,
                                ),
                            )
                from cascaqit.targets import MockNeutralAtomTarget

                scan_target = self.target or MockNeutralAtomTarget.v0_1()
                execution_metadata = _simulation_plan_metadata(
                    simulation_plan
                )
                reference_simulator = _reference_hybrid_simulator(
                    steps=execution_steps,
                )
                item_executor = _make_scan_item_executor(
                    simulation_plan,
                    simulator=reference_simulator,
                    initial_state=None,
                    backend_id=self.backend_id,
                    backend_called=True,
                    execution_metadata=execution_metadata,
                    analog_time_steps=self.analog_time_steps,
                    blockade_radius=float(
                        scan_target.metadata.get("blockade_radius", 0.0)
                    ),
                    return_probabilities=hybrid_return_probabilities,
                    noise_model=noise,
                    observables=observables,
                )
                return builder.submit_scan(
                    sweep,
                    program.parameters,
                    failure_policy=failure_policy,
                    job_id=job_id,
                    backend_id=self.backend_id,
                    backend_called=True,
                    execution_metadata=execution_metadata,
                    _execution_plan=simulation_plan,
                    _item_executor=item_executor,
                )
            return self._run_hybrid(
                program,
                params=params,
                shots=hybrid_shots,
                seed=resolved_seed,
                job_id=job_id,
                simulation_plan=simulation_plan,
                return_probabilities=hybrid_return_probabilities,
                noise_model=noise,
                observables=observables,
            )
        if isinstance(program, (HybridProgramIR, LocalExecutionPlan)):
            raise CapabilityError(
                "Hybrid IR and plans are not direct Backend.run inputs.",
                code="LOCAL_BACKEND_PROGRAM_NOT_EXECUTABLE",
                stage="backend",
                object_path="backend.run.program",
                suggestion="Use HybridProgram.from_ir(...) before Backend.run().",
                metadata={"actual_type": type(program).__name__},
            )
        if sweep is not None:
            raise CapabilityError(
                "Parameter sweeps require HybridProgram.",
                code="LOCAL_BACKEND_SWEEP_PROGRAM_UNSUPPORTED",
                stage="backend",
                object_path="backend.run.sweep",
                suggestion="Wrap Digital or Analog work in HybridProgram for sweep.",
                metadata={"actual_type": type(program).__name__},
            )
        effective_config = _single_program_config(
            config,
            shots=shots,
            seed=seed,
            backend_seed=self.seed,
            options=options,
        )
        effective_shots = effective_config.shots
        effective_seed = effective_config.seed
        # _single_program_config owns the deterministic fallback, so every local
        # runner receives an integer even though the generic IR permits None.
        assert effective_seed is not None
        if isinstance(program, (Circuit, DigitalProgramIR)):
            if params is not None:
                if not isinstance(program, Circuit):
                    raise CapabilityError(
                        "Bound DigitalProgramIR does not accept params.",
                        code="LOCAL_BACKEND_PARAMS_PROGRAM_UNSUPPORTED",
                        stage="backend",
                        object_path="backend.run.params",
                    )
                program = program.bind(
                    {name: float(value) for name, value in params.items()}
                )
            digital_native = (
                program.to_program()
                if isinstance(program, Circuit)
                else DigitalProgramIR.from_dict(program.to_dict())
            )
            _validate_observable_targets(
                observables,
                tuple(digital_native.circuit.qubits),
            )
            resolved_options = _resolved_options(options, seed=effective_seed)
            simulation_plan = _plan_execution(
                program_kind="digital",
                logical_sites=len(digital_native.circuit.qubits),
                options=resolved_options,
                time_integration_required=False,
            )
            _require_ideal_method(simulation_plan)
            use_reference = (
                observables is None
                and simulation_plan.dtype == "complex128"
                and simulation_plan.logical_sites <= _REFERENCE_DIGITAL_MAX_SITES
            )
            errors = tuple(
                item
                for item in _validate_program_for_simulation(
                    digital_native,
                    max_qubits=(
                        _REFERENCE_DIGITAL_MAX_SITES
                        if use_reference
                        else simulation_plan.logical_sites
                    ),
                )
                if item.severity == "error"
            )
            if errors:
                raise ProgramValidationError(
                    "Digital program failed local Backend preflight.",
                    code="LOCAL_BACKEND_PROGRAM_INVALID",
                    stage="backend",
                    object_path="backend.run.program",
                    suggestion="Resolve Digital program diagnostics before run().",
                    metadata={"diagnostic_codes": [item.code for item in errors]},
                    diagnostics=errors,
                )
            resolved_job_id = _job_id(
                job_id,
                kind="digital",
                program_hash=digital_native.stable_hash(),
            )
            digital_simulator = LocalDigitalSimulator(
                seed=effective_seed,
                max_qubits=_REFERENCE_DIGITAL_MAX_SITES,
                created_at=self.created_at,
            )
            return LocalExecutionJob(
                job_id=resolved_job_id,
                program_kind="digital",
                program_hash=digital_native.stable_hash(),
                runner=lambda: _with_backend_metadata(
                    (
                        digital_simulator.run(digital_native, config=effective_config)
                        if use_reference
                        else run_scalable_digital_ideal(
                            digital_native,
                            shots=effective_shots,
                            seed=effective_seed,
                            dtype=simulation_plan.dtype,
                            return_probabilities=(
                                effective_config.return_probabilities
                            ),
                            observables=observables,
                        )
                    ),
                    backend_id=self.backend_id,
                    selected_simulator=(
                        "LocalDigitalSimulator"
                        if use_reference
                        else "ScalableIdealEngine"
                    ),
                    simulation_plan=simulation_plan,
                ),
                backend_id=self.backend_id,
            )
        if isinstance(program, (AHSProgram, ProgramIR)):
            if params is not None:
                if not isinstance(program, AHSProgram):
                    raise CapabilityError(
                        "Bound ProgramIR does not accept params.",
                        code="LOCAL_BACKEND_PARAMS_PROGRAM_UNSUPPORTED",
                        stage="backend",
                        object_path="backend.run.params",
                    )
                program = program.bind(
                    {name: float(value) for name, value in params.items()}
                )
            analog_native = (
                program.to_ir()
                if isinstance(program, AHSProgram)
                else ProgramIR.from_dict(program.to_dict())
            )
            _validate_observable_targets(
                observables,
                analog_native.register.active_atom_ids,
            )
            resolved_options = _resolved_options(options, seed=effective_seed)
            resolved_target = _local_analog_target(analog_native, self.target)
            from cascaqit.validation import validate_program

            errors = tuple(
                item
                for item in validate_program(
                    analog_native,
                    resolved_target,
                    shots=effective_shots or 1,
                )
                if item.severity == "error"
            )
            if errors:
                raise ProgramValidationError(
                    "Analog program failed local Backend preflight.",
                    code="LOCAL_BACKEND_PROGRAM_INVALID",
                    stage="backend",
                    object_path="backend.run.program",
                    suggestion="Resolve Analog program diagnostics before run().",
                    metadata={"diagnostic_codes": [item.code for item in errors]},
                    diagnostics=errors,
                )
            blockade_radius = float(
                resolved_target.metadata.get("blockade_radius", 0.0)
            )
            blockade_dimension = _effective_blockade_dimension(
                analog_native,
                blockade_radius=blockade_radius,
                options=resolved_options,
            )
            simulation_plan = _plan_execution(
                program_kind="analog",
                logical_sites=len(analog_native.register.active_sites),
                options=resolved_options,
                time_integration_required=True,
                blockade_dimension=blockade_dimension,
            )
            _require_ideal_method(simulation_plan)
            resolved_job_id = _job_id(
                job_id,
                kind="analog",
                program_hash=analog_native.stable_hash(),
            )
            execution_steps = min(
                self.analog_time_steps,
                simulation_plan.max_steps,
            )
            _validate_kernel_thread_resources(
                simulation_plan,
                kernel_threads=self.kernel_threads,
            )
            return LocalExecutionJob(
                job_id=resolved_job_id,
                program_kind="analog",
                program_hash=analog_native.stable_hash(),
                runner=lambda: _with_backend_metadata(
                    run_scalable_analog_ideal(
                        analog_native,
                        shots=effective_shots,
                        seed=effective_seed,
                        dtype=simulation_plan.dtype,
                        steps=execution_steps,
                        blockade_radius=blockade_radius,
                        target_id=resolved_target.target_id,
                        return_probabilities=effective_config.return_probabilities,
                        use_subspace=(
                            simulation_plan.method_selected == "subspace"
                        ),
                        observables=observables,
                        integrator_requested=simulation_plan.integrator_requested,
                        integrator_selected=simulation_plan.integrator_selected,
                        rtol=simulation_plan.rtol,
                        atol=simulation_plan.atol,
                        max_steps=simulation_plan.max_steps,
                        kernel_threads=self.kernel_threads,
                    ),
                    backend_id=self.backend_id,
                    selected_simulator="ScalableIdealEngine",
                    simulation_plan=simulation_plan,
                    report_evidence={
                        "control_report_evidence": [
                            _control_report_evidence(
                                analog_native,
                                resolved_target,
                                block_id=analog_native.program_id,
                            )
                        ]
                    },
                ),
                backend_id=self.backend_id,
            )
        raise CapabilityError(
            "LocalBackend does not support this program type.",
            code="LOCAL_BACKEND_PROGRAM_UNSUPPORTED",
            stage="backend",
            object_path="backend.run.program",
            suggestion="Use Circuit, AHSProgram, Native IR, or HybridProgram.",
            metadata={"actual_type": type(program).__name__},
        )

    def resume(
        self,
        job_id: str,
    ) -> PersistentLocalExecutionJob | PersistentLocalHybridScanJob:
        """Restore a persistent local Job handle from its frozen definition."""
        if self.store is None:
            raise CapabilityError(
                "resume() requires LocalBackend(store=...).",
                code="LOCAL_BACKEND_STORE_REQUIRED",
                stage="backend",
                object_path="backend.resume",
            )
        store = SQLiteJobStore(self.store)
        definition = store.load_definition(job_id)
        if definition.backend_id != self.backend_id:
            raise CapabilityError(
                "Stored Job backend id does not match this LocalBackend.",
                code="LOCAL_BACKEND_RESUME_BACKEND_MISMATCH",
                stage="backend",
                object_path="backend.resume.job_id",
            )
        if definition.job_kind == "sweep":
            return self._persistent_sweep_job(store, definition)
        return PersistentLocalExecutionJob(
            store=store,
            definition=definition,
            runner_factory=lambda: self._job_from_definition(definition),
        )

    def history(
        self,
        *,
        limit: int = 20,
        cursor: str | None = None,
        statuses: tuple[JobState, ...] | None = None,
        program_kinds: tuple[JobProgramKind, ...] | None = None,
        job_kinds: tuple[JobKind, ...] | None = None,
        created_after: str | None = None,
        created_before: str | None = None,
    ) -> JobHistoryPage:
        """Return immutable persistent Job summaries from the configured store."""
        if self.store is None:
            raise CapabilityError(
                "history() requires LocalBackend(store=...).",
                code="LOCAL_BACKEND_STORE_REQUIRED",
                stage="backend",
                object_path="backend.history",
            )
        query = JobHistoryQuery(
            limit=limit,
            cursor=cursor,
            statuses=() if statuses is None else statuses,
            program_kinds=() if program_kinds is None else program_kinds,
            job_kinds=() if job_kinds is None else job_kinds,
            created_after=created_after,
            created_before=created_before,
        )
        return SQLiteJobStore(self.store).history(query)

    def _job_from_definition(
        self,
        definition: JobDefinitionIR,
    ) -> ExecutionJobProtocol:
        from cascaqit.digital import DigitalProgramIR
        from cascaqit.hybrid import HybridProgram
        from cascaqit.observables import ObservableSet
        from cascaqit.targets import TargetSpec

        payload = definition.program_payload()
        spec = definition.execution_spec()
        if definition.program_payload_kind == "DigitalProgramIR":
            program: DigitalProgramIR | ProgramIR | HybridProgram = (
                DigitalProgramIR.from_dict(payload)
            )
            params = None
        elif definition.program_payload_kind == "ProgramIR":
            program = ProgramIR.from_dict(payload)
            params = None
        elif definition.program_payload_kind == "HybridProgramIR":
            from cascaqit.hybrid import HybridProgramIR

            program = HybridProgram.from_ir(HybridProgramIR.from_dict(payload))
            params = None
        else:
            raise CapabilityError(
                "Stored Job program payload kind is unsupported.",
                code="LOCAL_BACKEND_RESUME_PAYLOAD_UNSUPPORTED",
                stage="backend",
                object_path="job.definition.program_payload_kind",
            )
        target_data = spec.get("target")
        transient = replace(
            self,
            store=None,
            seed=int(spec["seed"]),
            target=(
                None
                if target_data is None
                else TargetSpec.from_dict(cast(dict[str, Any], target_data))
            ),
            analog_time_steps=int(spec["analog_time_steps"]),
        )
        config_data = spec.get("config")
        options_data = spec.get("options")
        noise_data = spec.get("noise")
        observables_data = spec.get("observables")
        return cast(
            ExecutionJobProtocol,
            transient._run_in_memory(
                program,
                params=params,
                noise=(
                    None
                    if noise_data is None
                    else NoiseModel.from_dict(cast(dict[str, Any], noise_data))
                ),
                options=(
                    None
                    if options_data is None
                    else SimulationOptions.from_dict(
                        cast(dict[str, Any], options_data)
                    )
                ),
                shots=int(spec["shots"]),
                seed=int(spec["seed"]),
                job_id=definition.job_id,
                config=(
                    None
                    if config_data is None
                    else SimulatorConfigIR.from_dict(
                        cast(dict[str, Any], config_data)
                    )
                ),
                observables=(
                    None
                    if observables_data is None
                    else ObservableSet.from_dict(
                        cast(dict[str, Any], observables_data)
                    )
                ),
                failure_policy=cast(
                    LocalHybridScanFailurePolicy,
                    spec["failure_policy"],
                ),
            ),
        )

    def _run_persistent(
        self,
        program: Circuit | DigitalProgramIR | AHSProgram | ProgramIR | HybridProgram,
        *,
        params: Mapping[str, bool | int | float] | None,
        noise: NoiseModel | None,
        options: SimulationOptions | None,
        shots: int | None,
        seed: int | None,
        job_id: str | None,
        config: SimulatorConfigIR | None,
        observables: ObservableSet | None,
        failure_policy: LocalHybridScanFailurePolicy,
        retry: RetryPolicy,
        idempotency_key: str | None,
    ) -> PersistentLocalExecutionJob:
        from cascaqit.analog import AHSProgram
        from cascaqit.digital import Circuit, DigitalProgramIR

        assert self.store is not None
        store = SQLiteJobStore(self.store)
        probe = self._run_in_memory(
            program,
            params=params,
            noise=noise,
            options=options,
            shots=shots,
            seed=seed,
            job_id=job_id,
            config=config,
            observables=observables,
            failure_policy=failure_policy,
        )
        program_kind: Literal["digital", "analog", "hybrid"]
        if isinstance(program, (Circuit, DigitalProgramIR)):
            program_kind = "digital"
            if isinstance(program, Circuit):
                bound_digital = (
                    program
                    if params is None
                    else program.bind(
                        {name: float(value) for name, value in params.items()}
                    )
                )
                payload = bound_digital.to_program().to_dict()
            else:
                payload = program.to_dict()
            payload_kind = "DigitalProgramIR"
            effective = _single_program_config(
                config,
                shots=shots,
                seed=seed,
                backend_seed=self.seed,
                options=options,
            )
            program_hash = str(cast(Any, probe).program_hash)
        elif isinstance(program, (AHSProgram, ProgramIR)):
            program_kind = "analog"
            if isinstance(program, AHSProgram):
                bound_analog = (
                    program
                    if params is None
                    else program.bind(
                        {name: float(value) for name, value in params.items()}
                    )
                )
                payload = bound_analog.to_ir().to_dict()
            else:
                payload = program.to_dict()
            payload_kind = "ProgramIR"
            effective = _single_program_config(
                config,
                shots=shots,
                seed=seed,
                backend_seed=self.seed,
                options=options,
            )
            program_hash = str(cast(Any, probe).program_hash)
        else:
            program_kind = "hybrid"
            bound_hybrid = program if params is None else program.bind(params)
            payload = bound_hybrid.to_ir().to_dict()
            payload_kind = "HybridProgramIR"
            effective_seed = _effective_execution_seed(
                requested_seed=seed,
                config_seed=None if config is None else config.seed,
                backend_seed=self.seed,
                options=options,
            )
            effective_shots = (
                shots
                if shots is not None
                else (1000 if config is None else config.shots)
            )
            effective = SimulatorConfigIR(shots=effective_shots, seed=effective_seed)
            program_hash = program.stable_hash()

        identity = store.reserve_submission(program_kind, program_hash)
        resolved_idempotency = (
            identity.idempotency_key
            if idempotency_key is None
            else idempotency_key
        )
        resolved_job_id = job_id
        if resolved_job_id is None:
            resolved_job_id = (
                identity.job_id
                if idempotency_key is None
                else (
                    f"local_job.{program_kind}."
                    f"{_stable_text_hash(idempotency_key)[:16]}"
                )
            )
        execution_spec = {
            "seed": effective.seed,
            "shots": effective.shots,
            "params": None if params is None else dict(params),
            "config": None if config is None else config.to_dict(),
            "options": None if options is None else options.to_dict(),
            "noise": None if noise is None else noise.to_dict(),
            "observables": None if observables is None else observables.to_dict(),
            "failure_policy": failure_policy,
            "analog_time_steps": self.analog_time_steps,
            "target": None if self.target is None else self.target.to_dict(),
        }
        definition = JobDefinitionIR.create(
            job_id=resolved_job_id,
            backend_id=self.backend_id,
            job_kind="single",
            program_kind=program_kind,
            program_payload_kind=payload_kind,
            program_payload=payload,
            program_hash=program_hash,
            parameter_bind=(None if params is None else dict(params)),
            parameter_bind_hash=(
                None
                if params is None
                else hashlib.sha256(stable_json(dict(params)).encode()).hexdigest()
            ),
            execution_spec=execution_spec,
            retry_policy=retry,
            idempotency_key=resolved_idempotency,
            idempotency_explicit=idempotency_key is not None,
            created_at=self.created_at or _utc_now(),
        )
        created = store.create_definition(
            definition,
            submission_sequence=identity.sequence,
        )
        frozen = created.definition

        def factory() -> ExecutionJobProtocol:
            transient = replace(self, store=None)
            return cast(
                ExecutionJobProtocol,
                transient._run_in_memory(
                    program,
                    params=params,
                    noise=noise,
                    options=options,
                    shots=shots,
                    seed=seed,
                    job_id=frozen.job_id,
                    config=config,
                    observables=observables,
                    failure_policy=failure_policy,
                ),
            )

        return PersistentLocalExecutionJob(
            store=store,
            definition=frozen,
            runner_factory=factory,
        )

    def _run_persistent_sweep(
        self,
        program: HybridProgram,
        *,
        sweep: ParameterScan,
        noise: NoiseModel | None,
        options: SimulationOptions | None,
        shots: int | None,
        seed: int | None,
        job_id: str | None,
        config: SimulatorConfigIR | None,
        observables: ObservableSet | None,
        failure_policy: LocalHybridScanFailurePolicy,
        retry: RetryPolicy,
        idempotency_key: str | None,
    ) -> PersistentLocalHybridScanJob:
        """Freeze a sweep into independently executable bound child programs."""
        assert self.store is not None
        store = SQLiteJobStore(self.store)
        probe = self._run_in_memory(
            program,
            sweep=sweep,
            noise=noise,
            options=options,
            shots=shots,
            seed=seed,
            job_id=job_id,
            config=config,
            observables=observables,
            failure_policy=failure_policy,
        )
        if not isinstance(probe, LocalHybridScanJob):
            raise AssertionError(
                "Hybrid sweep preflight must return LocalHybridScanJob."
            )

        identity = store.reserve_submission("hybrid", program.stable_hash())
        resolved_job_id = job_id
        if resolved_job_id is None:
            resolved_job_id = (
                identity.job_id
                if idempotency_key is None
                else f"local_job.hybrid.{_stable_text_hash(idempotency_key)[:16]}"
            )
        effective_seed = probe.resource_plan.root_seed
        effective_shots = (
            shots if shots is not None else (1000 if config is None else config.shots)
        )
        children = []
        for index, bind_set in enumerate(probe.bind_sets):
            bound = program.bind(dict(bind_set.values))
            children.append(
                {
                    "scan_index": index,
                    "child_id": f"{resolved_job_id}.{index:06d}",
                    "bind_set": bind_set.to_dict(),
                    "bind_hash": bind_set.parameter_bind_hash,
                    "seed": _derive_scan_seed(effective_seed, index),
                    "program_payload": bound.to_ir().to_dict(),
                    "program_hash": bound.stable_hash(),
                }
            )
        execution_spec = {
            "seed": effective_seed,
            "shots": effective_shots,
            "config": None if config is None else config.to_dict(),
            "options": None if options is None else options.to_dict(),
            "noise": None if noise is None else noise.to_dict(),
            "observables": None if observables is None else observables.to_dict(),
            "failure_policy": failure_policy,
            "analog_time_steps": self.analog_time_steps,
            "target": None if self.target is None else self.target.to_dict(),
        }
        scan_spec = {
            "scan": sweep.to_dict(),
            "parameter_schema_hash": probe.parameter_schema_hash,
            "plan_hash": probe.builder.plan.stable_hash(),
            "graph_hash": probe.builder.plan.graph_hash,
            "resource_plan": probe.resource_plan.to_dict(),
            "execution_metadata": probe.execution_metadata,
            "children": children,
        }
        definition = JobDefinitionIR.create(
            job_id=resolved_job_id,
            backend_id=self.backend_id,
            job_kind="sweep",
            program_kind="hybrid",
            program_payload_kind="MaterializedHybridSweepIR",
            program_payload={
                "program_id": program.program_id,
                "program_hash": program.stable_hash(),
            },
            program_hash=program.stable_hash(),
            execution_spec=execution_spec,
            retry_policy=retry,
            idempotency_key=(
                identity.idempotency_key
                if idempotency_key is None
                else idempotency_key
            ),
            idempotency_explicit=idempotency_key is not None,
            created_at=self.created_at or _utc_now(),
            scan_spec=scan_spec,
        )
        created = store.create_definition(
            definition,
            submission_sequence=identity.sequence,
        )
        return self._persistent_sweep_job(store, created.definition)

    def _persistent_sweep_job(
        self,
        store: SQLiteJobStore,
        definition: JobDefinitionIR,
    ) -> PersistentLocalHybridScanJob:
        """Rebuild the child runner solely from frozen sweep definition data."""
        from cascaqit.hybrid import HybridProgram, HybridProgramIR
        from cascaqit.observables import ObservableSet
        from cascaqit.parameters import ParameterBindIR
        from cascaqit.targets import MockNeutralAtomTarget, TargetSpec

        spec = definition.execution_spec()

        def child_runner(child: Any) -> LocalHybridScanItemOutcome:
            bound = HybridProgram.from_ir(
                HybridProgramIR.from_dict(json.loads(child.program_payload_json))
            )
            child_options = (
                None
                if spec.get("options") is None
                else SimulationOptions.from_dict(cast(dict[str, Any], spec["options"]))
            )
            child_noise = (
                None
                if spec.get("noise") is None
                else NoiseModel.from_dict(cast(dict[str, Any], spec["noise"]))
            )
            child_observables = (
                None
                if spec.get("observables") is None
                else ObservableSet.from_dict(
                    cast(dict[str, Any], spec["observables"])
                )
            )
            simulation_plan = _plan_execution(
                program_kind="hybrid",
                logical_sites=_hybrid_logical_sites(bound),
                options=_resolved_options(child_options, seed=child.seed),
                time_integration_required=_hybrid_has_analog(bound),
                noisy=child_noise is not None,
                requires_trajectory=(
                    False if child_noise is None else child_noise.requires_trajectory
                ),
            )
            if child_noise is None:
                _require_ideal_method(simulation_plan)
            else:
                _require_noisy_method(simulation_plan)
            builder = bound.execution_builder(
                shots=int(spec["shots"]),
                seed=child.seed,
            )
            built = builder.build(
                bundle_id=f"persistent-sweep-bundle.{child.child_id}"
            )
            if built.bundle is None:
                raise ProgramValidationError(
                    "Stored sweep child failed bundle reconstruction.",
                    code="JOB_SWEEP_CHILD_RECONSTRUCTION_FAILED",
                    stage="backend",
                    object_path=f"job.sweep.children[{child.scan_index}]",
                    diagnostics=built.diagnostics,
                )
            target_data = spec.get("target")
            target = (
                MockNeutralAtomTarget.v0_1()
                if target_data is None
                else TargetSpec.from_dict(cast(dict[str, Any], target_data))
            )
            execution_steps = _hybrid_execution_steps(
                bound,
                analog_steps=min(
                    int(spec["analog_time_steps"]),
                    simulation_plan.max_steps,
                ),
            )
            executor = _make_scan_item_executor(
                simulation_plan,
                simulator=_reference_hybrid_simulator(steps=execution_steps),
                initial_state=None,
                backend_id=definition.backend_id,
                backend_called=True,
                execution_metadata=_simulation_plan_metadata(
                    simulation_plan
                ),
                analog_time_steps=int(spec["analog_time_steps"]),
                blockade_radius=float(target.metadata.get("blockade_radius", 0.0)),
                return_probabilities=(
                    True
                    if spec.get("config") is None
                    else bool(
                        cast(dict[str, Any], spec["config"])[
                            "return_probabilities"
                        ]
                    )
                ),
                noise_model=child_noise,
                observables=child_observables,
            )
            measurement = executor(built.bundle, child.child_id)
            bind_set = ParameterBindIR.from_json(child.bind_set_json)
            return LocalHybridScanItemOutcome(
                scan_index=child.scan_index,
                bind_set=bind_set,
                state="completed",
                job_id=child.child_id,
                bundle_id=built.bundle.bundle_id,
                measurement_result=measurement,
                diagnostics=measurement.diagnostics,
                trace=measurement.trace,
                metadata={
                    "parameter_bind_hash": child.bind_hash,
                    "bundle_hash": measurement.bundle_hash,
                    "scan_seed": child.seed,
                },
            )

        return PersistentLocalHybridScanJob(
            store=store,
            definition=definition,
            child_runner_factory=child_runner,
        )

    def _run_hybrid(
        self,
        program: HybridProgram,
        *,
        params: Mapping[str, bool | int | float] | None,
        shots: int,
        seed: int,
        job_id: str | None,
        simulation_plan: SimulationExecutionPlan,
        return_probabilities: bool,
        noise_model: NoiseModel | None,
        observables: ObservableSet | None,
    ) -> ExecutionJobProtocol:
        prepared = program.prepare(params=params, shots=shots, seed=seed)
        if prepared.bundle is None:
            raise ProgramValidationError(
                "HybridProgram failed local Backend preflight.",
                code="LOCAL_BACKEND_PROGRAM_INVALID",
                stage="backend",
                object_path="backend.run.program",
                suggestion="Resolve every prepare diagnostic before run().",
                metadata={
                    "diagnostic_codes": [item.code for item in prepared.diagnostics],
                    "prepare_diagnostics": [
                        item.to_dict() for item in prepared.diagnostics
                    ],
                },
            )
        bundle = prepared.bundle
        _validate_observable_targets(
            observables,
            bundle.payloads[0].logical_order,
        )
        _validate_noisy_observable_compatibility(
            observables,
            noise_model,
            bundle.payloads[0].logical_order,
        )
        execution_steps = _hybrid_execution_steps(
            program,
            analog_steps=min(
                self.analog_time_steps,
                simulation_plan.max_steps,
            ),
        )
        resolved_job_id = _job_id(
            job_id,
            kind="hybrid",
            program_hash=program.stable_hash(),
        )
        if noise_model is not None:
            validate_scalable_hybrid_bundle(bundle)
            from cascaqit.targets import MockNeutralAtomTarget

            resolved_target = self.target or MockNeutralAtomTarget.v0_1()
            report_evidence = _hybrid_control_report_evidence(
                bundle,
                explicit_target=self.target,
            )
            blockade_radius = float(
                resolved_target.metadata.get("blockade_radius", 0.0)
            )
            method = cast(
                Literal["density_matrix", "trajectory"],
                simulation_plan.method_selected,
            )
            validate_physical_noise_bundle(
                bundle,
                noise_model,
                method=method,
            )
            return LocalExecutionJob(
                job_id=resolved_job_id,
                program_kind="hybrid",
                program_hash=program.stable_hash(),
                runner=lambda: _with_backend_metadata(
                    run_physical_noisy_hybrid(
                        bundle,
                        noise_model,
                        method=method,
                        dtype=simulation_plan.dtype,
                        trajectories=simulation_plan.trajectories,
                        # The shared noisy runner always constructs its Analog
                        # kernel, even for a Digital-only wrapped program.  One is
                        # a valid dormant configuration; Result evidence remains
                        # zero/not_applicable because no time slice is executed.
                        steps=max(1, execution_steps),
                        chunk_size=min(16, simulation_plan.trajectories),
                        workers=simulation_plan.workers,
                        blockade_radius=blockade_radius,
                        target_id=self.backend_id,
                        return_probabilities=return_probabilities,
                        observables=observables,
                        integrator_requested=simulation_plan.integrator_requested,
                        integrator_selected=simulation_plan.integrator_selected,
                        rtol=simulation_plan.rtol,
                        atol=simulation_plan.atol,
                        max_steps=simulation_plan.max_steps,
                    ),
                    backend_id=self.backend_id,
                    selected_simulator=(
                        "ExactDensityNoiseEngine"
                        if method == "density_matrix"
                        else "BatchedTrajectoryNoiseEngine"
                    ),
                    simulation_plan=simulation_plan,
                    workers=simulation_plan.workers,
                    seed=seed,
                    report_evidence=report_evidence,
                ),
                backend_id=self.backend_id,
            )
        validate_scalable_hybrid_bundle(bundle)
        from cascaqit.targets import MockNeutralAtomTarget

        resolved_target = self.target or MockNeutralAtomTarget.v0_1()
        report_evidence = _hybrid_control_report_evidence(
            bundle,
            explicit_target=self.target,
        )
        _validate_kernel_thread_resources(
            simulation_plan,
            kernel_threads=self.kernel_threads,
        )
        return LocalExecutionJob(
            job_id=resolved_job_id,
            program_kind="hybrid",
            program_hash=program.stable_hash(),
            runner=lambda: _with_backend_metadata(
                run_scalable_hybrid_ideal(
                    bundle,
                    dtype=simulation_plan.dtype,
                    steps=max(1, execution_steps),
                    blockade_radius=float(
                        resolved_target.metadata.get("blockade_radius", 0.0)
                    ),
                    target_id=self.backend_id,
                    return_probabilities=return_probabilities,
                    observables=observables,
                    integrator_requested=simulation_plan.integrator_requested,
                    integrator_selected=simulation_plan.integrator_selected,
                    rtol=simulation_plan.rtol,
                    atol=simulation_plan.atol,
                    max_steps=simulation_plan.max_steps,
                    kernel_threads=self.kernel_threads,
                ),
                backend_id=self.backend_id,
                selected_simulator="ScalableIdealEngine",
                simulation_plan=simulation_plan,
                seed=seed,
                report_evidence=report_evidence,
            ),
            backend_id=self.backend_id,
        )


def _with_backend_metadata(
    result: ResultIR,
    *,
    backend_id: str,
    selected_simulator: str,
    simulation_plan: SimulationExecutionPlan,
    workers: int | None = None,
    seed: int | None = None,
    report_evidence: Mapping[str, Any] | None = None,
) -> ResultIR:
    evidence = require_result_solver_evidence(result.metadata, plan=simulation_plan)
    effective_seed = simulation_plan.seed if seed is None else seed
    executed_workers = (
        int(evidence.metadata.get("kernel_threads", 1))
        if workers is None
        else workers
    )
    return replace(
        result,
        metadata={
            **_simulation_plan_metadata(simulation_plan),
            **execution_config_metadata(
                simulation_plan,
                evidence,
                workers=executed_workers,
                seed=effective_seed,
                execution_scope="job",
            ),
            **result.metadata,
            **({} if report_evidence is None else dict(report_evidence)),
            "backend_id": backend_id,
            "selected_simulator": selected_simulator,
            "backend_called": True,
            "offline_deterministic": True,
            "network_accessed": False,
            "execution_package_created": False,
        },
    )


def _control_report_evidence(
    program: ProgramIR,
    target: TargetSpec,
    *,
    block_id: str,
) -> dict[str, Any]:
    """Freeze the public Target checks that governed one local Analog run."""
    control_system = ControlSystemIR.from_target_spec(target)
    schedule = build_control_schedule(program, control_system)
    diagnostics = (
        *schedule.diagnostics,
        *validate_control_schedule(schedule, control_system, program),
    )
    return {
        "block_id": block_id,
        "program_hash": program.stable_hash(),
        "target_id": target.target_id,
        "schedule": schedule.to_dict(),
        "diagnostics": [item.to_dict() for item in diagnostics],
        "diagnostic_count": len(diagnostics),
        "has_errors": any(item.severity == "error" for item in diagnostics),
        "production_channel_allocation_performed": False,
    }


def _hybrid_control_report_evidence(
    bundle: Any,
    *,
    explicit_target: TargetSpec | None,
) -> dict[str, Any]:
    """Collect control evidence for every Analog block in bundle order."""
    rows = []
    for payload in bundle.payloads:
        if not isinstance(payload, AnalogStepPayload):
            continue
        target = _local_analog_target(payload.program, explicit_target)
        rows.append(
            _control_report_evidence(
                payload.program,
                target,
                block_id=payload.block_id,
            )
        )
    return {"control_report_evidence": rows}


def _plan_execution(
    *,
    program_kind: Literal["digital", "analog", "hybrid"],
    logical_sites: int,
    options: SimulationOptions,
    time_integration_required: bool,
    blockade_dimension: int | None = None,
    noisy: bool = False,
    requires_trajectory: bool = False,
) -> SimulationExecutionPlan:
    return SimulationPlanner().plan(
        SimulationPlanningRequest(
            program_kind=program_kind,
            logical_sites=logical_sites,
            noisy=noisy,
            requires_trajectory=requires_trajectory,
            time_integration_required=time_integration_required,
            options=options,
            blockade_dimension=blockade_dimension,
        )
    )


def _validate_kernel_thread_resources(
    simulation_plan: SimulationExecutionPlan,
    *,
    kernel_threads: int,
) -> None:
    if kernel_threads == 1:
        return
    ParallelExecutionPlanner().resolve(
        ParallelExecutionRequest(
            task_count=1,
            per_task_peak_bytes=simulation_plan.estimate.estimated_peak_bytes,
            mode="kernel_threads",
            workers=1,
            kernel_threads=kernel_threads,
            memory_fraction=1.0,
            max_memory_bytes=simulation_plan.budget_bytes,
        )
    )


def _resolved_options(
    options: SimulationOptions | None,
    *,
    seed: int,
) -> SimulationOptions:
    # One resolved seed must drive planning, stochastic kernels, and sampling.
    # Replacing an options seed here prevents the plan from describing a value
    # different from the one embedded in the terminal measurement payload.
    if options is not None:
        return replace(options, seed=seed)
    return SimulationOptions(seed=seed)


def _require_ideal_method(plan: SimulationExecutionPlan) -> None:
    if plan.method_selected in {"state_vector", "subspace"}:
        return
    raise CapabilityError(
        "The resource plan requires a noisy-state engine not available yet.",
        code="SIMULATION_SCALABLE_ENGINE_NOT_AVAILABLE",
        stage="simulation",
        object_path="simulation_plan.method_selected",
        suggestion="Use a supported ideal state-vector or subspace method.",
        metadata={
            "simulation_plan": plan.to_dict(),
            "simulation_plan_hash": plan.stable_hash(),
            "large_array_allocated": False,
        },
    )


def _require_noisy_method(plan: SimulationExecutionPlan) -> None:
    if plan.method_selected in {"density_matrix", "trajectory"}:
        return
    raise CapabilityError(
        "The resource plan did not select a physical noisy-state method.",
        code="SIMULATION_NOISY_ENGINE_NOT_SELECTED",
        stage="simulation",
        object_path="simulation_plan.method_selected",
        metadata={
            "simulation_plan": plan.to_dict(),
            "large_array_allocated": False,
        },
    )


def _simulation_plan_metadata(
    plan: SimulationExecutionPlan,
) -> dict[str, object]:
    return {
        "simulation_plan": plan.to_dict(),
        "simulation_plan_hash": plan.stable_hash(),
        "simulation_resource_estimate": plan.estimate.to_dict(),
        "simulation_plan_truthfulness": plan.truthfulness,
        "simulation_truthfulness": (
            "physical_state_evolution" if plan.noisy else "ideal_state_evolution"
        ),
    }


def _wrap_noisy_single_program(
    program: Circuit | DigitalProgramIR | AHSProgram | ProgramIR,
    *,
    params: Mapping[str, bool | int | float] | None,
) -> HybridProgram:
    """Express a single program through the same physical-noise Hybrid runner."""
    from cascaqit.analog import AHSProgram
    from cascaqit.digital import Circuit, DigitalProgramIR
    from cascaqit.hybrid import HybridProgram

    payload: Circuit | DigitalProgramIR | AHSProgram | ProgramIR = program
    if params is not None:
        if isinstance(program, (Circuit, AHSProgram)):
            payload = program.bind(
                {name: float(value) for name, value in params.items()}
            )
        else:
            raise CapabilityError(
                "Bound Native IR does not accept params.",
                code="LOCAL_BACKEND_PARAMS_PROGRAM_UNSUPPORTED",
                stage="backend",
                object_path="backend.run.params",
            )

    # A standalone program owns its terminal measurement, while the internal
    # physical-noise wrapper owns the equivalent Hybrid measurement step.
    # Normalize to measurement-free numeric payloads so both public contracts
    # stay strict without applying measurement twice.
    if isinstance(payload, Circuit):
        digital = payload.to_program()
        payload = replace(
            digital,
            circuit=replace(digital.circuit, measurements=()),
        )
    elif isinstance(payload, DigitalProgramIR):
        payload = replace(
            payload,
            circuit=replace(payload.circuit, measurements=()),
        )
    elif isinstance(payload, AHSProgram):
        payload = replace(payload.to_ir(), measurements=())
    elif isinstance(payload, ProgramIR):
        payload = replace(payload, measurements=())

    # 保留源 program identity。算法优化会用相同线路结构提交多次独立
    # evaluation；若包装器使用固定 id，这些执行会错误地产生相同 ResultIR id。
    wrapper = HybridProgram(f"noise.wrapper.{payload.program_id}")
    if isinstance(payload, (Circuit, DigitalProgramIR)):
        wrapper = wrapper.digital("digital", payload)
    elif isinstance(payload, (AHSProgram, ProgramIR)):
        wrapper = wrapper.analog("analog", payload)
    else:
        raise TypeError("physical noise wrapper received an unsupported program.")
    return wrapper.measure_all()


def _local_analog_target(
    program: ProgramIR,
    explicit_target: TargetSpec | None,
) -> TargetSpec:
    """Resolve a validation target without imposing mock hardware geometry locally."""
    if explicit_target is not None:
        return explicit_target
    from cascaqit.targets import MockNeutralAtomTarget

    target = (
        MockNeutralAtomTarget.local_ahs_v0_1()
        if (
            program.hamiltonian.local_detuning_terms
            or program.hamiltonian.local_rabi_terms
        )
        else MockNeutralAtomTarget.v0_1()
    )
    active_sites = program.register.active_sites
    # Let validation produce REGISTER_NO_ACTIVE_ATOMS before geometry code
    # attempts to derive a local target region from an empty logical register.
    if not active_sites:
        return target
    x_values = tuple(float(site.position[0]) for site in active_sites)
    y_values = tuple(float(site.position[1]) for site in active_sites)
    margin = max(float(target.min_atom_spacing), 1.0)
    region = target.programmable_region
    if (
        len(active_sites) <= target.max_atoms
        and min(x_values) >= region.x_min
        and max(x_values) <= region.x_max
        and min(y_values) >= region.y_min
        and max(y_values) <= region.y_max
    ):
        return target
    return replace(
        target,
        target_id="local.simulator.analog",
        target_name="Local resource-driven Analog simulator",
        max_atoms=max(target.max_atoms, len(active_sites)),
        programmable_region=replace(
            region,
            x_min=min(region.x_min, min(x_values) - margin),
            x_max=max(region.x_max, max(x_values) + margin),
            y_min=min(region.y_min, min(y_values) - margin),
            y_max=max(region.y_max, max(y_values) + margin),
        ),
        metadata={
            **target.metadata,
            "resource_driven_local_target": True,
            "register_site_count": len(active_sites),
        },
    )


def _effective_blockade_dimension(
    program: ProgramIR,
    *,
    blockade_radius: float,
    options: SimulationOptions,
) -> int | None:
    if options.blockade_mode == "full" or blockade_radius <= 0.0:
        return None
    dimension = blockade_basis_dimension(program, blockade_radius)
    full_dimension = 2 ** sum(site.is_active for site in program.register.sites)
    return dimension if dimension < full_dimension else None


def _hybrid_logical_sites(program: HybridProgram) -> int:
    logical_ids = {
        block.mapping.get(resource.logical_id, resource.logical_id)
        for block in program.blocks
        if block.block_kind != "measurement"
        for resource in block.logical_resources
    }
    if not logical_ids:
        raise ProgramValidationError(
            "HybridProgram has no quantum logical sites to simulate.",
            code="LOCAL_BACKEND_PROGRAM_INVALID",
            stage="backend",
            object_path="backend.run.program.blocks",
        )
    return len(logical_ids)


def _hybrid_has_analog(program: HybridProgram) -> bool:
    """Return whether the executable Hybrid program advances physical time."""
    return any(block.block_kind == "analog" for block in program.blocks)


def _job_id(
    requested: str | None,
    *,
    kind: str,
    program_hash: str,
) -> str:
    value = f"local_job.{kind}.{program_hash[:16]}" if requested is None else requested
    if not isinstance(value, str) or not value.strip():
        raise ValueError("job_id must be a non-empty string.")
    return value


def _stable_text_hash(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _validate_optional_shots(value: object) -> None:
    if value is not None and (
        not isinstance(value, int) or isinstance(value, bool) or value < 0
    ):
        raise ValueError("shots must be a non-negative integer or None.")


def _validate_seed(value: object) -> None:
    if value is not None and (not isinstance(value, int) or isinstance(value, bool)):
        raise TypeError("seed must be an integer or None.")


def _validate_observable_targets(
    observables: ObservableSet | None,
    logical_order: tuple[str, ...],
) -> None:
    """Reject target mapping errors before a lazy Job can be created."""
    if observables is None:
        return
    available = set(logical_order)
    for index, observable in enumerate(observables):
        unknown = tuple(
            target for target in observable.targets if target not in available
        )
        if unknown:
            raise ProgramValidationError(
                f"Observable '{observable.name}' uses unknown logical targets.",
                code="LOCAL_BACKEND_OBSERVABLE_TARGET_UNKNOWN",
                stage="backend",
                object_path=f"backend.run.observables[{index}].targets",
                suggestion="Use target ids from the program logical order.",
                metadata={
                    "unknown_targets": list(unknown),
                    "logical_order": list(logical_order),
                },
            )


def _validate_noisy_observable_compatibility(
    observables: ObservableSet | None,
    noise_model: NoiseModel | None,
    logical_order: tuple[str, ...],
) -> None:
    """Reject Pauli targets whose physical qubit can become an erasure."""
    if observables is None or noise_model is None:
        return
    atom_loss = noise_model.channel("atom_loss")
    if atom_loss is None or atom_loss.parameters["probability"] <= 0.0:
        return
    loss_targets = (
        set(logical_order)
        if atom_loss.targets == "all"
        else set(atom_loss.targets)
    )
    blocked = tuple(
        observable.name
        for observable in observables
        if any(target in loss_targets for target in observable.targets)
    )
    if blocked:
        raise CapabilityError(
            "Pauli observables are undefined on atom-loss erasure targets.",
            code="LOCAL_BACKEND_OBSERVABLE_ERASURE_UNSUPPORTED",
            stage="backend",
            object_path="backend.run.observables",
            suggestion="Remove lost targets or evaluate an erasure-aware quantity.",
            metadata={
                "observable_names": list(blocked),
                "atom_loss_targets": sorted(loss_targets),
            },
        )


def _single_program_config(
    config: SimulatorConfigIR | None,
    *,
    shots: int | None,
    seed: int | None,
    backend_seed: int | None,
    options: SimulationOptions | None,
) -> SimulatorConfigIR:
    base = config or SimulatorConfigIR(
        shots=1000,
        seed=backend_seed,
        return_probabilities=True,
    )
    effective_seed = _effective_execution_seed(
        requested_seed=seed,
        config_seed=None if config is None else config.seed,
        backend_seed=backend_seed,
        options=options,
    )
    return replace(
        base,
        shots=base.shots if shots is None else shots,
        seed=effective_seed,
    )


def _effective_execution_seed(
    *,
    requested_seed: int | None,
    config_seed: int | None,
    backend_seed: int | None,
    options: SimulationOptions | None,
) -> int:
    """Resolve the sole root seed in user-facing precedence order.

    An explicit run override wins, followed by the explicit simulator config,
    backend default, and SimulationOptions.  Zero is the final deterministic
    fallback, so offline execution never delegates seed selection to the OS.
    """
    for candidate in (
        requested_seed,
        config_seed,
        backend_seed,
        None if options is None else options.seed,
        0,
    ):
        if candidate is not None:
            return candidate
    raise AssertionError("the deterministic zero seed fallback is unreachable")


def _hybrid_execution_steps(
    program: HybridProgram,
    *,
    analog_steps: int,
) -> int:
    """Return the available fixed slices only when Analog work exists."""
    if any(block.block_kind == "analog" for block in program.blocks):
        return analog_steps
    return 0


def _reference_hybrid_simulator(*, steps: int) -> LocalHybridSimulator:
    """Construct the small reference runner with the backend's actual step limit."""
    if steps == 0:
        return LocalHybridSimulator()
    return LocalHybridSimulator(
        analog_adapter=AnalogStepAdapter(
            kernel=AnalogStateVectorKernel(
                steps=steps,
                max_hilbert_dim=4,
            )
        )
    )
