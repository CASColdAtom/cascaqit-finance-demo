"""Internal cross-platform policy for bounded local parallel execution."""

from __future__ import annotations

import atexit
import math
import multiprocessing
import os
import platform
import sys
import threading
from collections.abc import Iterator
from concurrent.futures import ProcessPoolExecutor
from concurrent.futures.process import BrokenProcessPool
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Any, Literal, Union, cast

from cascaqit.exceptions import CapabilityError
from cascaqit.simulators.planning import HostResourceSnapshot

PARALLEL_POLICY_SCHEMA_VERSION = "cascaqit.parallel.execution.v1"
PARALLEL_WORKER_ENVIRONMENT_KEY = "CASCAQIT_PARALLEL_WORKER"
BLAS_THREAD_ENVIRONMENT_KEYS = (
    "OMP_NUM_THREADS",
    "OPENBLAS_NUM_THREADS",
    "MKL_NUM_THREADS",
    "BLIS_NUM_THREADS",
    "VECLIB_MAXIMUM_THREADS",
    "NUMEXPR_NUM_THREADS",
    "GOTO_NUM_THREADS",
)

ParallelMode = Literal["auto", "serial", "process", "kernel_threads"]
SelectedParallelMode = Literal["serial", "process", "kernel_threads"]
ProcessStartMethod = Literal["auto", "spawn", "forkserver"]
SelectedProcessStartMethod = Literal["spawn", "forkserver"]
WorkerRequest = Union[int, Literal["auto"]]

_WORKER_THREADPOOL_LIMITER: Any | None = None
_REUSABLE_PROCESS_EXECUTOR_IDLE_SECONDS = 60.0
_REUSABLE_PROCESS_EXECUTOR_LOCK = threading.Condition(threading.RLock())
_REUSABLE_PROCESS_EXECUTOR: ProcessPoolExecutor | None = None
_REUSABLE_PROCESS_EXECUTOR_SIGNATURE: tuple[Any, ...] | None = None
_REUSABLE_PROCESS_EXECUTOR_USERS = 0
_REUSABLE_PROCESS_EXECUTOR_TIMER: threading.Timer | None = None


@dataclass(frozen=True)
class ParallelExecutionRequest:
    """Resource inputs for one group of independent local tasks."""

    task_count: int
    per_task_peak_bytes: int
    parent_reserve_bytes: int = 0
    mode: ParallelMode = "auto"
    workers: WorkerRequest = "auto"
    kernel_threads: int = 1
    memory_fraction: float = 0.8
    max_memory_bytes: int | None = None
    start_method: ProcessStartMethod = "auto"
    host: HostResourceSnapshot | None = None

    def __post_init__(self) -> None:
        _positive_int(self.task_count, "task_count")
        _positive_int(self.per_task_peak_bytes, "per_task_peak_bytes")
        _nonnegative_int(self.parent_reserve_bytes, "parent_reserve_bytes")
        if self.mode not in {"auto", "serial", "process", "kernel_threads"}:
            raise ValueError("mode must be auto, serial, process or kernel_threads.")
        if self.workers != "auto":
            _positive_int(self.workers, "workers")
        _positive_int(self.kernel_threads, "kernel_threads")
        if (
            not isinstance(self.memory_fraction, (int, float))
            or isinstance(self.memory_fraction, bool)
            or not math.isfinite(float(self.memory_fraction))
            or not 0.0 < float(self.memory_fraction) <= 1.0
        ):
            raise ValueError("memory_fraction must be finite and in (0, 1].")
        if self.max_memory_bytes is not None:
            _positive_int(self.max_memory_bytes, "max_memory_bytes")
        if self.start_method not in {"auto", "spawn", "forkserver"}:
            raise ValueError("start_method must be auto, spawn or forkserver.")
        if self.host is not None and not isinstance(
            self.host, HostResourceSnapshot
        ):
            raise TypeError("host must be HostResourceSnapshot or None.")
        if self.mode != "kernel_threads" and self.kernel_threads != 1:
            raise ValueError(
                "kernel_threads can exceed one only in kernel_threads mode."
            )
        if self.mode == "kernel_threads":
            if self.task_count != 1:
                raise ValueError("kernel_threads mode requires exactly one task.")
            if self.workers not in {"auto", 1}:
                raise ValueError("kernel_threads mode uses exactly one process.")
        if self.mode == "serial" and self.workers not in {"auto", 1}:
            raise ValueError("serial mode uses exactly one worker.")
        if self.mode in {"serial", "kernel_threads"} and self.start_method != "auto":
            raise ValueError("start_method applies only to process execution.")
        object.__setattr__(self, "memory_fraction", float(self.memory_fraction))


@dataclass(frozen=True)
class ParallelExecutionPolicy:
    """Immutable scheduling evidence excluded from semantic hashes."""

    mode_requested: ParallelMode
    mode_selected: SelectedParallelMode
    workers_requested: WorkerRequest
    process_workers: int
    kernel_threads: int
    task_count: int
    per_task_peak_bytes: int
    parent_reserve_bytes: int
    memory_budget_bytes: int
    memory_worker_limit: int
    cpu_budget: int
    start_method: SelectedProcessStartMethod | None
    platform_system: str
    platform_machine: str
    nested_worker: bool
    worker_environment: dict[str, str]
    selection_reasons: tuple[str, ...]
    schema_version: str = PARALLEL_POLICY_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.mode_requested not in {
            "auto",
            "serial",
            "process",
            "kernel_threads",
        }:
            raise ValueError("mode_requested is invalid.")
        if self.mode_selected not in {"serial", "process", "kernel_threads"}:
            raise ValueError("mode_selected is invalid.")
        if self.workers_requested != "auto":
            _positive_int(self.workers_requested, "workers_requested")
        for name in (
            "process_workers",
            "kernel_threads",
            "task_count",
            "per_task_peak_bytes",
            "memory_budget_bytes",
            "memory_worker_limit",
            "cpu_budget",
        ):
            _positive_int(getattr(self, name), name)
        _nonnegative_int(self.parent_reserve_bytes, "parent_reserve_bytes")
        if self.process_workers > self.task_count:
            raise ValueError("process_workers cannot exceed task_count.")
        if self.process_workers * self.kernel_threads > self.cpu_budget:
            raise ValueError("parallel policy exceeds its CPU budget.")
        if (
            self.parent_reserve_bytes
            + self.process_workers * self.per_task_peak_bytes
            > self.memory_budget_bytes
        ):
            raise ValueError("parallel policy exceeds its memory budget.")
        if self.mode_selected == "process":
            if self.process_workers < 2 or self.start_method is None:
                raise ValueError("process mode requires workers and a start method.")
            expected_keys = {
                PARALLEL_WORKER_ENVIRONMENT_KEY,
                *BLAS_THREAD_ENVIRONMENT_KEYS,
            }
            if set(self.worker_environment) != expected_keys:
                raise ValueError("process worker environment is incomplete.")
            if set(self.worker_environment.values()) != {"1"}:
                raise ValueError("process worker thread limits must be one.")
        else:
            if self.process_workers != 1 or self.start_method is not None:
                raise ValueError("non-process policy must use one process.")
            if self.worker_environment:
                raise ValueError("non-process policy cannot set child environment.")
        if self.mode_selected != "kernel_threads" and self.kernel_threads != 1:
            raise ValueError("kernel thread count is inconsistent with selected mode.")
        if not self.platform_system or not self.platform_machine:
            raise ValueError("platform identity must be non-empty.")
        if not self.selection_reasons or any(
            not item for item in self.selection_reasons
        ):
            raise ValueError("selection_reasons must contain non-empty values.")
        if self.schema_version != PARALLEL_POLICY_SCHEMA_VERSION:
            raise ValueError("parallel policy schema_version is unsupported.")
        object.__setattr__(self, "worker_environment", dict(self.worker_environment))
        object.__setattr__(self, "selection_reasons", tuple(self.selection_reasons))

    def to_dict(self) -> dict[str, Any]:
        """Return diagnostic evidence that explicitly excludes semantic hashing."""

        return {
            "mode_requested": self.mode_requested,
            "mode_selected": self.mode_selected,
            "workers_requested": self.workers_requested,
            "process_workers": self.process_workers,
            "kernel_threads": self.kernel_threads,
            "task_count": self.task_count,
            "per_task_peak_bytes": self.per_task_peak_bytes,
            "parent_reserve_bytes": self.parent_reserve_bytes,
            "memory_budget_bytes": self.memory_budget_bytes,
            "memory_worker_limit": self.memory_worker_limit,
            "cpu_budget": self.cpu_budget,
            "start_method": self.start_method,
            "platform_system": self.platform_system,
            "platform_machine": self.platform_machine,
            "nested_worker": self.nested_worker,
            "worker_environment": dict(self.worker_environment),
            "selection_reasons": list(self.selection_reasons),
            "semantic_hash_included": False,
            "schema_version": self.schema_version,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ParallelExecutionPolicy:
        if data.get("semantic_hash_included") is not False:
            raise ValueError("parallel policy evidence must exclude semantic hashes.")
        return cls(
            mode_requested=data["mode_requested"],
            mode_selected=data["mode_selected"],
            workers_requested=data["workers_requested"],
            process_workers=int(data["process_workers"]),
            kernel_threads=int(data["kernel_threads"]),
            task_count=int(data["task_count"]),
            per_task_peak_bytes=int(data["per_task_peak_bytes"]),
            parent_reserve_bytes=int(data["parent_reserve_bytes"]),
            memory_budget_bytes=int(data["memory_budget_bytes"]),
            memory_worker_limit=int(data["memory_worker_limit"]),
            cpu_budget=int(data["cpu_budget"]),
            start_method=data.get("start_method"),
            platform_system=str(data["platform_system"]),
            platform_machine=str(data["platform_machine"]),
            nested_worker=bool(data["nested_worker"]),
            worker_environment=dict(data["worker_environment"]),
            selection_reasons=tuple(data["selection_reasons"]),
            schema_version=str(data.get("schema_version", "")),
        )


class ParallelExecutionPlanner:
    """Resolve one bounded policy before any task is submitted."""

    def resolve(self, request: ParallelExecutionRequest) -> ParallelExecutionPolicy:
        if not isinstance(request, ParallelExecutionRequest):
            raise TypeError("request must be ParallelExecutionRequest.")
        host = request.host or HostResourceSnapshot.detect()
        system, machine = _platform_identity()
        memory_budget = int(host.available_memory_bytes * request.memory_fraction)
        if request.max_memory_bytes is not None:
            memory_budget = min(memory_budget, request.max_memory_bytes)
        remaining_memory = memory_budget - request.parent_reserve_bytes
        memory_worker_limit = (
            0
            if remaining_memory <= 0
            else remaining_memory // request.per_task_peak_bytes
        )
        if memory_worker_limit < 1:
            raise _resource_error(
                request,
                host,
                memory_budget,
                memory_worker_limit,
                reason="one task does not fit the local memory budget",
            )
        nested_worker = os.environ.get(PARALLEL_WORKER_ENVIRONMENT_KEY) == "1"

        if request.mode == "kernel_threads":
            if request.kernel_threads > host.cpu_count:
                raise _resource_error(
                    request,
                    host,
                    memory_budget,
                    memory_worker_limit,
                    reason="kernel thread count exceeds the effective CPU budget",
                )
            return _policy(
                request=request,
                host=host,
                system=system,
                machine=machine,
                memory_budget=memory_budget,
                memory_worker_limit=memory_worker_limit,
                mode_selected="kernel_threads",
                process_workers=1,
                kernel_threads=request.kernel_threads,
                start_method=None,
                nested_worker=nested_worker,
                worker_environment={},
                reasons=("PARALLEL_KERNEL_THREADS_SELECTED",),
            )

        if request.mode == "serial":
            return _serial_policy(
                request,
                host,
                system,
                machine,
                memory_budget,
                memory_worker_limit,
                nested_worker,
                "PARALLEL_EXPLICIT_SERIAL",
            )

        requested_workers = (
            host.cpu_count if request.workers == "auto" else request.workers
        )
        if nested_worker:
            return _serial_policy(
                request,
                host,
                system,
                machine,
                memory_budget,
                memory_worker_limit,
                True,
                "PARALLEL_NESTED_WORKER_SERIALIZED",
            )
        if request.workers != "auto" and (
            request.workers > host.cpu_count
            or request.workers > memory_worker_limit
        ):
            raise _resource_error(
                request,
                host,
                memory_budget,
                memory_worker_limit,
                reason="explicit process workers exceed CPU or memory capacity",
            )
        selected_workers = min(
            request.task_count,
            requested_workers,
            host.cpu_count,
            memory_worker_limit,
        )
        if selected_workers < 2:
            reason = (
                "PARALLEL_SINGLE_TASK_SERIAL"
                if request.task_count == 1
                else "PARALLEL_SINGLE_WORKER_CAPACITY"
            )
            return _serial_policy(
                request,
                host,
                system,
                machine,
                memory_budget,
                memory_worker_limit,
                False,
                reason,
            )
        if not _process_platform_supported(system, machine):
            if request.mode == "process":
                raise CapabilityError(
                    "Process parallelism is unsupported on this platform.",
                    code="PARALLEL_PROCESS_PLATFORM_UNSUPPORTED",
                    stage="simulation",
                    object_path="parallel_execution.platform",
                    suggestion="Use serial execution on a supported native platform.",
                    metadata={
                        "platform_system": system,
                        "platform_machine": machine,
                        "job_submitted": False,
                    },
                )
            return _serial_policy(
                request,
                host,
                system,
                machine,
                memory_budget,
                memory_worker_limit,
                False,
                "PARALLEL_PLATFORM_SERIAL_FALLBACK",
            )

        start_method = _select_start_method(
            system,
            request.start_method,
            _available_start_methods(),
        )
        worker_environment = {
            PARALLEL_WORKER_ENVIRONMENT_KEY: "1",
            **{key: "1" for key in BLAS_THREAD_ENVIRONMENT_KEYS},
        }
        reason = (
            "PARALLEL_AUTO_PROCESS_SELECTED"
            if request.mode == "auto"
            else "PARALLEL_EXPLICIT_PROCESS_SELECTED"
        )
        return _policy(
            request=request,
            host=host,
            system=system,
            machine=machine,
            memory_budget=memory_budget,
            memory_worker_limit=memory_worker_limit,
            mode_selected="process",
            process_workers=selected_workers,
            kernel_threads=1,
            start_method=start_method,
            nested_worker=False,
            worker_environment=worker_environment,
            reasons=(reason,),
        )


def initialize_parallel_worker(environment: dict[str, str]) -> None:
    """Apply child-only environment and loaded native thread-pool limits."""

    global _WORKER_THREADPOOL_LIMITER
    allowed = {PARALLEL_WORKER_ENVIRONMENT_KEY, *BLAS_THREAD_ENVIRONMENT_KEYS}
    invalid_value = any(value != "1" for value in environment.values())
    if set(environment) != allowed or invalid_value:
        raise ValueError("parallel worker environment is invalid.")
    os.environ.update(environment)
    from threadpoolctl import threadpool_limits  # type: ignore[import-untyped]

    _WORKER_THREADPOOL_LIMITER = threadpool_limits(limits=1)


@contextmanager
def reusable_process_executor(
    policy: ParallelExecutionPolicy,
) -> Iterator[ProcessPoolExecutor]:
    """Lease the process-local bounded executor for one independent task group."""

    executor = _acquire_reusable_process_executor(policy)
    broken = False
    try:
        yield executor
    except BrokenProcessPool:
        broken = True
        raise
    finally:
        _release_reusable_process_executor(executor, broken=broken)


def shutdown_reusable_process_executor(*, wait: bool = True) -> None:
    """Close idle reusable workers, primarily for explicit application shutdown."""

    global _REUSABLE_PROCESS_EXECUTOR
    global _REUSABLE_PROCESS_EXECUTOR_SIGNATURE
    global _REUSABLE_PROCESS_EXECUTOR_TIMER
    executor: ProcessPoolExecutor | None = None
    with _REUSABLE_PROCESS_EXECUTOR_LOCK:
        while _REUSABLE_PROCESS_EXECUTOR_USERS:
            _REUSABLE_PROCESS_EXECUTOR_LOCK.wait()
        if _REUSABLE_PROCESS_EXECUTOR_TIMER is not None:
            _REUSABLE_PROCESS_EXECUTOR_TIMER.cancel()
            _REUSABLE_PROCESS_EXECUTOR_TIMER = None
        executor = _REUSABLE_PROCESS_EXECUTOR
        _REUSABLE_PROCESS_EXECUTOR = None
        _REUSABLE_PROCESS_EXECUTOR_SIGNATURE = None
    if executor is not None:
        executor.shutdown(wait=wait, cancel_futures=True)


def _acquire_reusable_process_executor(
    policy: ParallelExecutionPolicy,
) -> ProcessPoolExecutor:
    global _REUSABLE_PROCESS_EXECUTOR
    global _REUSABLE_PROCESS_EXECUTOR_SIGNATURE
    global _REUSABLE_PROCESS_EXECUTOR_TIMER
    global _REUSABLE_PROCESS_EXECUTOR_USERS
    if policy.mode_selected != "process" or policy.start_method is None:
        raise ValueError("reusable process executor requires process policy")
    signature = (
        policy.start_method,
        policy.process_workers,
        tuple(sorted(policy.worker_environment.items())),
    )
    stale: ProcessPoolExecutor | None = None
    with _REUSABLE_PROCESS_EXECUTOR_LOCK:
        while _REUSABLE_PROCESS_EXECUTOR_USERS:
            _REUSABLE_PROCESS_EXECUTOR_LOCK.wait()
        if _REUSABLE_PROCESS_EXECUTOR_TIMER is not None:
            _REUSABLE_PROCESS_EXECUTOR_TIMER.cancel()
            _REUSABLE_PROCESS_EXECUTOR_TIMER = None
        if (
            _REUSABLE_PROCESS_EXECUTOR is not None
            and signature != _REUSABLE_PROCESS_EXECUTOR_SIGNATURE
        ):
            stale = _REUSABLE_PROCESS_EXECUTOR
            _REUSABLE_PROCESS_EXECUTOR = None
            _REUSABLE_PROCESS_EXECUTOR_SIGNATURE = None
        if _REUSABLE_PROCESS_EXECUTOR is None:
            context = multiprocessing.get_context(policy.start_method)
            _REUSABLE_PROCESS_EXECUTOR = ProcessPoolExecutor(
                max_workers=policy.process_workers,
                mp_context=context,
                initializer=initialize_parallel_worker,
                initargs=(policy.worker_environment,),
            )
            _REUSABLE_PROCESS_EXECUTOR_SIGNATURE = signature
        executor = _REUSABLE_PROCESS_EXECUTOR
        _REUSABLE_PROCESS_EXECUTOR_USERS += 1
    if stale is not None:
        stale.shutdown(wait=False, cancel_futures=True)
    return executor


def _release_reusable_process_executor(
    executor: ProcessPoolExecutor,
    *,
    broken: bool,
) -> None:
    global _REUSABLE_PROCESS_EXECUTOR
    global _REUSABLE_PROCESS_EXECUTOR_SIGNATURE
    global _REUSABLE_PROCESS_EXECUTOR_TIMER
    global _REUSABLE_PROCESS_EXECUTOR_USERS
    discarded: ProcessPoolExecutor | None = None
    with _REUSABLE_PROCESS_EXECUTOR_LOCK:
        if executor is not _REUSABLE_PROCESS_EXECUTOR:
            return
        _REUSABLE_PROCESS_EXECUTOR_USERS -= 1
        if broken:
            discarded = _REUSABLE_PROCESS_EXECUTOR
            _REUSABLE_PROCESS_EXECUTOR = None
            _REUSABLE_PROCESS_EXECUTOR_SIGNATURE = None
        elif _REUSABLE_PROCESS_EXECUTOR_USERS == 0:
            timer = threading.Timer(
                _REUSABLE_PROCESS_EXECUTOR_IDLE_SECONDS,
                _expire_reusable_process_executor,
                args=(executor,),
            )
            timer.daemon = True
            timer.start()
            _REUSABLE_PROCESS_EXECUTOR_TIMER = timer
        _REUSABLE_PROCESS_EXECUTOR_LOCK.notify_all()
    if discarded is not None:
        discarded.shutdown(wait=False, cancel_futures=True)


def _expire_reusable_process_executor(executor: ProcessPoolExecutor) -> None:
    global _REUSABLE_PROCESS_EXECUTOR
    global _REUSABLE_PROCESS_EXECUTOR_SIGNATURE
    global _REUSABLE_PROCESS_EXECUTOR_TIMER
    with _REUSABLE_PROCESS_EXECUTOR_LOCK:
        if (
            executor is not _REUSABLE_PROCESS_EXECUTOR
            or _REUSABLE_PROCESS_EXECUTOR_USERS
        ):
            return
        _REUSABLE_PROCESS_EXECUTOR = None
        _REUSABLE_PROCESS_EXECUTOR_SIGNATURE = None
        _REUSABLE_PROCESS_EXECUTOR_TIMER = None
    executor.shutdown(wait=False, cancel_futures=True)


def _serial_policy(
    request: ParallelExecutionRequest,
    host: HostResourceSnapshot,
    system: str,
    machine: str,
    memory_budget: int,
    memory_worker_limit: int,
    nested_worker: bool,
    reason: str,
) -> ParallelExecutionPolicy:
    return _policy(
        request=request,
        host=host,
        system=system,
        machine=machine,
        memory_budget=memory_budget,
        memory_worker_limit=memory_worker_limit,
        mode_selected="serial",
        process_workers=1,
        kernel_threads=1,
        start_method=None,
        nested_worker=nested_worker,
        worker_environment={},
        reasons=(reason,),
    )


def _policy(
    *,
    request: ParallelExecutionRequest,
    host: HostResourceSnapshot,
    system: str,
    machine: str,
    memory_budget: int,
    memory_worker_limit: int,
    mode_selected: SelectedParallelMode,
    process_workers: int,
    kernel_threads: int,
    start_method: SelectedProcessStartMethod | None,
    nested_worker: bool,
    worker_environment: dict[str, str],
    reasons: tuple[str, ...],
) -> ParallelExecutionPolicy:
    return ParallelExecutionPolicy(
        mode_requested=request.mode,
        mode_selected=mode_selected,
        workers_requested=request.workers,
        process_workers=process_workers,
        kernel_threads=kernel_threads,
        task_count=request.task_count,
        per_task_peak_bytes=request.per_task_peak_bytes,
        parent_reserve_bytes=request.parent_reserve_bytes,
        memory_budget_bytes=memory_budget,
        memory_worker_limit=memory_worker_limit,
        cpu_budget=host.cpu_count,
        start_method=start_method,
        platform_system=system,
        platform_machine=machine,
        nested_worker=nested_worker,
        worker_environment=worker_environment,
        selection_reasons=reasons,
    )


def _resource_error(
    request: ParallelExecutionRequest,
    host: HostResourceSnapshot,
    memory_budget: int,
    memory_worker_limit: int,
    *,
    reason: str,
) -> CapabilityError:
    error: CapabilityError = CapabilityError(
        "Parallel execution exceeds the local CPU or memory budget.",
        code="PARALLEL_RESOURCE_BUDGET_EXCEEDED",
        stage="simulation",
        object_path="parallel_execution.resources",
        suggestion="Reduce workers or tasks, or increase the explicit memory budget.",
        metadata={
            "reason": reason,
            "task_count": request.task_count,
            "workers_requested": request.workers,
            "per_task_peak_bytes": request.per_task_peak_bytes,
            "parent_reserve_bytes": request.parent_reserve_bytes,
            "memory_budget_bytes": memory_budget,
            "memory_worker_limit": memory_worker_limit,
            "cpu_budget": host.cpu_count,
            "job_submitted": False,
            "algorithm_changed": False,
        },
    )
    return error


def _select_start_method(
    system: str,
    requested: ProcessStartMethod,
    available: tuple[str, ...],
) -> SelectedProcessStartMethod:
    allowed = (
        ("spawn", "forkserver") if system.startswith("linux") else ("spawn",)
    )
    if requested == "auto":
        for candidate in allowed:
            if candidate in available:
                return cast(SelectedProcessStartMethod, candidate)
    elif requested in allowed and requested in available:
        return requested
    raise CapabilityError(
        "The requested multiprocessing start method is unavailable.",
        code="PARALLEL_START_METHOD_UNAVAILABLE",
        stage="simulation",
        object_path="parallel_execution.start_method",
        suggestion="Use spawn, or forkserver on a supported Linux host.",
        metadata={
            "platform_system": system,
            "start_method_requested": requested,
            "start_methods_available": list(available),
            "job_submitted": False,
        },
    )


def _process_platform_supported(system: str, machine: str) -> bool:
    normalized = machine.lower()
    if system == "win32":
        return normalized in {"amd64", "x86_64"}
    if system.startswith("linux"):
        return normalized in {"amd64", "x86_64"}
    if system == "darwin":
        return normalized in {"arm64", "aarch64"}
    return False


def _platform_identity() -> tuple[str, str]:
    return sys.platform, platform.machine().lower()


def _available_start_methods() -> tuple[str, ...]:
    return tuple(multiprocessing.get_all_start_methods())


def _positive_int(value: object, field_name: str) -> None:
    if not isinstance(value, int) or isinstance(value, bool) or value <= 0:
        raise ValueError(f"{field_name} must be a positive integer.")


def _nonnegative_int(value: object, field_name: str) -> None:
    if not isinstance(value, int) or isinstance(value, bool) or value < 0:
        raise ValueError(f"{field_name} must be a non-negative integer.")


atexit.register(shutdown_reusable_process_executor)
