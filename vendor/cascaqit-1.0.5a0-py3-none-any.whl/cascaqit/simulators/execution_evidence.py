"""Canonical projection from executed solver facts to Result metadata."""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from typing import Any, Literal, cast

from cascaqit.exceptions import ProgramValidationError
from cascaqit.results import (
    SimulationExecutionConfigIR,
    SimulationSolverEvidenceIR,
    simulation_solver_evidence_from_metadata,
)
from cascaqit.simulators.planning import (
    SelectedSimulationIntegrator,
    SimulationExecutionPlan,
    SimulationIntegrator,
)

ExecutionScope = Literal["job", "scan", "scan_item"]


def not_applicable_solver_evidence(
    *,
    integrator_requested: SimulationIntegrator,
    logical_time: float = 0.0,
    time_unit: str = "us",
    consumer: str,
) -> SimulationSolverEvidenceIR:
    """Record that the executed path had no time-integration operation."""
    return SimulationSolverEvidenceIR(
        integrator_requested=integrator_requested,
        integrator_selected="not_applicable",
        tolerance_applied=False,
        relative_tolerance=None,
        absolute_tolerance=None,
        accepted_steps=0,
        function_evaluations=None,
        segment_count=0,
        rejected_steps=None,
        rejected_steps_available=False,
        min_step_size=None,
        max_step_size=None,
        initial_time=logical_time,
        final_time=logical_time,
        time_unit=time_unit,
        termination_reason="not_applicable",
        metadata={"consumer": consumer},
    )


def solver_evidence_from_provenance(
    metadata: Mapping[str, Any],
    *,
    object_path: str,
) -> SimulationSolverEvidenceIR:
    """Read evidence emitted by one numerical kernel provenance record."""
    raw = metadata.get("solver_evidence")
    if not isinstance(raw, dict):
        raise ProgramValidationError(
            "Executed Analog kernel omitted solver evidence.",
            code="SIMULATION_SOLVER_EVIDENCE_MISSING",
            stage="simulation",
            object_path=object_path,
        )
    return SimulationSolverEvidenceIR.from_dict(raw)


def aggregate_solver_evidence(
    evidences: Iterable[SimulationSolverEvidenceIR],
    *,
    integrator_requested: SimulationIntegrator,
    integrator_selected: SelectedSimulationIntegrator,
    aggregation_scope: str,
) -> SimulationSolverEvidenceIR:
    """Aggregate executed components without inventing unavailable statistics."""
    components = tuple(evidences)
    if integrator_selected == "not_applicable":
        if any(item.integrator_selected != "not_applicable" for item in components):
            raise ValueError("not-applicable aggregate cannot contain solver work.")
        return not_applicable_solver_evidence(
            integrator_requested=integrator_requested,
            consumer=aggregation_scope,
        )
    if not components:
        raise ProgramValidationError(
            "Time-integrated execution produced no solver evidence.",
            code="SIMULATION_SOLVER_EVIDENCE_MISSING",
            stage="simulation",
            object_path="result.metadata.simulation_solver_evidence",
        )
    if any(item.integrator_selected != integrator_selected for item in components):
        raise ProgramValidationError(
            "Executed solver evidence disagrees with the selected integrator.",
            code="SIMULATION_SOLVER_EVIDENCE_MISMATCH",
            stage="simulation",
            object_path="result.metadata.simulation_solver_evidence",
        )
    relative_tolerances = {
        item.relative_tolerance
        for item in components
        if item.relative_tolerance is not None
    }
    absolute_tolerances = {
        item.absolute_tolerance
        for item in components
        if item.absolute_tolerance is not None
    }
    if len(relative_tolerances) > 1 or len(absolute_tolerances) > 1:
        raise ProgramValidationError(
            "Component solver tolerances are inconsistent.",
            code="SIMULATION_SOLVER_TOLERANCE_MISMATCH",
            stage="simulation",
            object_path="result.metadata.simulation_solver_evidence",
        )
    function_evaluations = (
        sum(cast(int, item.function_evaluations) for item in components)
        if all(item.function_evaluations is not None for item in components)
        else None
    )
    rejected_steps_available = all(
        item.rejected_steps_available for item in components
    )
    rejected_steps = (
        sum(cast(int, item.rejected_steps) for item in components)
        if rejected_steps_available
        else None
    )
    min_steps = tuple(
        item.min_step_size for item in components if item.min_step_size is not None
    )
    max_steps = tuple(
        item.max_step_size for item in components if item.max_step_size is not None
    )
    executed_kernel_threads = max(
        int(item.metadata.get("kernel_threads", 1)) for item in components
    )
    aggregate_metadata: dict[str, object] = {
        "aggregation_scope": aggregation_scope,
        "component_count": len(components),
        "component_evidence_hashes": [item.stable_hash() for item in components],
    }
    if executed_kernel_threads > 1:
        aggregate_metadata.update(
            {
                "kernel_parallelism": "threaded_numpy_chunks",
                "kernel_threads": executed_kernel_threads,
            }
        )
    return SimulationSolverEvidenceIR(
        integrator_requested=integrator_requested,
        integrator_selected=integrator_selected,
        tolerance_applied=integrator_selected == "adaptive_dop853",
        relative_tolerance=(
            next(iter(relative_tolerances)) if relative_tolerances else None
        ),
        absolute_tolerance=(
            next(iter(absolute_tolerances)) if absolute_tolerances else None
        ),
        accepted_steps=sum(item.accepted_steps for item in components),
        function_evaluations=function_evaluations,
        segment_count=sum(item.segment_count for item in components),
        rejected_steps=rejected_steps,
        rejected_steps_available=rejected_steps_available,
        min_step_size=min(min_steps) if min_steps else None,
        max_step_size=max(max_steps) if max_steps else None,
        initial_time=min(item.initial_time for item in components),
        final_time=max(item.final_time for item in components),
        time_unit=components[0].time_unit,
        termination_reason="completed",
        metadata=aggregate_metadata,
    )


def solver_evidence_metadata(
    evidence: SimulationSolverEvidenceIR,
) -> dict[str, object]:
    """Return the canonical Result metadata projection for solver evidence."""
    return {
        "simulation_solver_evidence": evidence.to_dict(),
        "simulation_solver_evidence_hash": evidence.stable_hash(),
    }


def require_result_solver_evidence(
    metadata: dict[str, Any],
    *,
    plan: SimulationExecutionPlan,
) -> SimulationSolverEvidenceIR:
    """Return actual evidence, synthesizing only a provable no-op case."""
    evidence = simulation_solver_evidence_from_metadata(metadata)
    if evidence is None and plan.integrator_selected == "not_applicable":
        evidence = not_applicable_solver_evidence(
            integrator_requested=plan.integrator_requested,
            consumer="time_integration_not_required",
        )
    if evidence is None:
        raise ProgramValidationError(
            "Executed simulator omitted required solver evidence.",
            code="SIMULATION_SOLVER_EVIDENCE_MISSING",
            stage="simulation",
            object_path="result.metadata.simulation_solver_evidence",
        )
    if (
        evidence.integrator_requested != plan.integrator_requested
        or evidence.integrator_selected != plan.integrator_selected
    ):
        raise ProgramValidationError(
            "Executed solver evidence disagrees with the simulation plan.",
            code="SIMULATION_SOLVER_EVIDENCE_MISMATCH",
            stage="simulation",
            object_path="result.metadata.simulation_solver_evidence",
            metadata={
                "planned_requested": plan.integrator_requested,
                "planned_selected": plan.integrator_selected,
                "executed_requested": evidence.integrator_requested,
                "executed_selected": evidence.integrator_selected,
            },
        )
    return evidence


def execution_config_metadata(
    plan: SimulationExecutionPlan,
    evidence: SimulationSolverEvidenceIR,
    *,
    workers: int,
    seed: int,
    execution_scope: ExecutionScope,
) -> dict[str, object]:
    """Build execution config only after a kernel has emitted actual evidence."""
    step_semantics = cast(
        Literal[
            "not_applicable",
            "adaptive_accepted_steps",
            "fixed_time_slices",
        ],
        {
            "not_applicable": "not_applicable",
            "adaptive_dop853": "adaptive_accepted_steps",
            "fixed_step_krylov": "fixed_time_slices",
        }[evidence.integrator_selected],
    )
    seed_semantics = cast(
        Literal["effective_seed", "root_seed", "derived_scan_seed"],
        {
            "job": "effective_seed",
            "scan": "root_seed",
            "scan_item": "derived_scan_seed",
        }[execution_scope],
    )
    config = SimulationExecutionConfigIR(
        method=plan.method_selected,
        device=plan.device,
        dtype=plan.dtype,
        relative_tolerance=plan.rtol,
        absolute_tolerance=plan.atol,
        integrator_requested=evidence.integrator_requested,
        integrator_selected=evidence.integrator_selected,
        solver_evidence_hash=evidence.stable_hash(),
        tolerance_applied=evidence.tolerance_applied,
        steps=evidence.accepted_steps,
        step_semantics=step_semantics,
        workers=workers,
        worker_semantics=(
            "scan_concurrency" if execution_scope == "scan" else "kernel_concurrency"
        ),
        seed=seed,
        seed_semantics=seed_semantics,
        execution_scope=execution_scope,
        trajectories=(
            plan.trajectories if plan.method_selected == "trajectory" else None
        ),
    )
    return {
        **solver_evidence_metadata(evidence),
        "simulation_execution_config": config.to_dict(),
    }
