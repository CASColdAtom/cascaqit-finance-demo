"""Resource-driven simulation planning contracts and deterministic preflight."""

from __future__ import annotations

import ctypes
import math
import os
import sys
from dataclasses import dataclass, field
from importlib.metadata import version
from pathlib import Path
from typing import Any, Literal, Union

import numpy as np

from cascaqit.exceptions import CapabilityError
from cascaqit.native_ir.base import IRMixin

__all__ = [
    "HostResourceSnapshot",
    "SimulationCandidateIR",
    "SimulationExecutionPlan",
    "SimulationIntegrator",
    "SelectedSimulationIntegrator",
    "SimulationOptions",
    "SimulationPlanner",
    "SimulationPlanningRequest",
    "SimulationResourceEstimate",
    "SweepResourcePlanIR",
]

SIMULATION_PLANNING_SCHEMA_VERSION = "cascaqit.simulation.planning.v1"
SimulationMethod = Literal[
    "auto",
    "state_vector",
    "subspace",
    "density_matrix",
    "trajectory",
]
SelectedSimulationMethod = Literal[
    "state_vector",
    "subspace",
    "density_matrix",
    "trajectory",
]
SimulationIntegrator = Literal[
    "auto",
    "adaptive_dop853",
    "fixed_step_krylov",
]
SelectedSimulationIntegrator = Literal[
    "not_applicable",
    "adaptive_dop853",
    "fixed_step_krylov",
]
SimulationDevice = Literal["auto", "cpu", "gpu"]
SelectedSimulationDevice = Literal["cpu"]
SimulationDType = Literal["complex64", "complex128"]
BlockadeMode = Literal["auto", "full", "subspace"]
ProgramKind = Literal["digital", "analog", "hybrid"]
CandidateStatus = Literal["selected", "eligible", "rejected"]
WorkerRequest = Union[int, Literal["auto"]]
SweepFailurePolicy = Literal["fail_fast", "continue_on_error"]

_METHODS: tuple[SelectedSimulationMethod, ...] = (
    "state_vector",
    "subspace",
    "density_matrix",
    "trajectory",
)
_INTEGRATORS: tuple[SimulationIntegrator, ...] = (
    "auto",
    "adaptive_dop853",
    "fixed_step_krylov",
)
_MAX_EXACT_DIMENSION_EXPONENT = 4096


@dataclass(frozen=True)
class SimulationOptions(IRMixin):
    """User-facing numerical method, resource, and accuracy controls."""

    method: SimulationMethod = "auto"
    integrator: SimulationIntegrator = "auto"
    device: SimulationDevice = "auto"
    dtype: SimulationDType = "complex128"
    max_memory_bytes: int | None = None
    memory_fraction: float = 0.8
    max_wall_time_seconds: float | None = None
    workers: WorkerRequest = "auto"
    trajectories: int = 256
    target_statistical_error: float | None = None
    rtol: float = 1e-9
    atol: float = 1e-11
    max_steps: int = 10000
    blockade_mode: BlockadeMode = "auto"
    seed: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = SIMULATION_PLANNING_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.method not in {"auto", *_METHODS}:
            raise ValueError("method is not a supported simulation method.")
        if self.integrator not in _INTEGRATORS:
            raise ValueError("integrator is not a supported simulation integrator.")
        if self.device not in {"auto", "cpu", "gpu"}:
            raise ValueError("device must be auto, cpu, or gpu.")
        if self.dtype not in {"complex64", "complex128"}:
            raise ValueError("dtype must be complex64 or complex128.")
        _optional_positive_int(self.max_memory_bytes, "max_memory_bytes")
        if (
            not isinstance(self.memory_fraction, (int, float))
            or isinstance(self.memory_fraction, bool)
            or not math.isfinite(float(self.memory_fraction))
            or not 0.0 < float(self.memory_fraction) <= 1.0
        ):
            raise ValueError("memory_fraction must be finite and in (0, 1].")
        _optional_positive_float(
            self.max_wall_time_seconds,
            "max_wall_time_seconds",
        )
        if self.workers != "auto":
            _positive_int(self.workers, "workers")
        _positive_int(self.trajectories, "trajectories")
        if self.trajectories < 2:
            raise ValueError(
                "trajectories must be at least 2 for confidence intervals."
            )
        _optional_positive_float(
            self.target_statistical_error,
            "target_statistical_error",
        )
        _positive_float(self.rtol, "rtol")
        _positive_float(self.atol, "atol")
        _positive_int(self.max_steps, "max_steps")
        if self.blockade_mode not in {"auto", "full", "subspace"}:
            raise ValueError("blockade_mode must be auto, full, or subspace.")
        if not isinstance(self.seed, int) or isinstance(self.seed, bool):
            raise TypeError("seed must be an integer.")
        if not isinstance(self.metadata, dict):
            raise TypeError("metadata must be a dictionary.")
        object.__setattr__(self, "memory_fraction", float(self.memory_fraction))
        object.__setattr__(self, "rtol", float(self.rtol))
        object.__setattr__(self, "atol", float(self.atol))
        object.__setattr__(self, "metadata", dict(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SimulationOptions:
        return cls(
            method=data.get("method", "auto"),
            integrator=data.get("integrator", "auto"),
            device=data.get("device", "auto"),
            dtype=data.get("dtype", "complex128"),
            max_memory_bytes=data.get("max_memory_bytes"),
            memory_fraction=data.get("memory_fraction", 0.8),
            max_wall_time_seconds=data.get("max_wall_time_seconds"),
            workers=data.get("workers", "auto"),
            trajectories=data.get("trajectories", 256),
            target_statistical_error=data.get("target_statistical_error"),
            rtol=data.get("rtol", 1e-9),
            atol=data.get("atol", 1e-11),
            max_steps=data.get("max_steps", 10000),
            blockade_mode=data.get("blockade_mode", "auto"),
            seed=data.get("seed", 0),
            metadata=dict(data.get("metadata", {})),
            schema_version=str(
                data.get("schema_version", SIMULATION_PLANNING_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class HostResourceSnapshot(IRMixin):
    """Immutable CPU host resources used for one planning decision."""

    total_memory_bytes: int
    available_memory_bytes: int
    cpu_count: int
    source: str = "caller"
    schema_version: str = SIMULATION_PLANNING_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _positive_int(self.total_memory_bytes, "total_memory_bytes")
        _positive_int(self.available_memory_bytes, "available_memory_bytes")
        if self.available_memory_bytes > self.total_memory_bytes:
            raise ValueError("available_memory_bytes cannot exceed total memory.")
        _positive_int(self.cpu_count, "cpu_count")
        if not isinstance(self.source, str) or not self.source.strip():
            raise ValueError("source must be a non-empty string.")

    @classmethod
    def detect(cls) -> HostResourceSnapshot:
        """Detect an effective CPU and memory budget without optional packages."""
        total, available = _host_memory_bytes()
        return cls(
            total_memory_bytes=total,
            available_memory_bytes=available,
            cpu_count=_effective_cpu_count(),
            source="platform.effective_resource_probe",
        )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> HostResourceSnapshot:
        return cls(
            total_memory_bytes=int(data["total_memory_bytes"]),
            available_memory_bytes=int(data["available_memory_bytes"]),
            cpu_count=int(data["cpu_count"]),
            source=str(data.get("source", "caller")),
            schema_version=str(
                data.get("schema_version", SIMULATION_PLANNING_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class SimulationResourceEstimate(IRMixin):
    """Conservative byte accounting for one simulation method candidate."""

    method: SelectedSimulationMethod
    logical_sites: int
    hilbert_dimension: int
    state_dimension: int
    dtype: SimulationDType
    itemsize_bytes: int
    trajectories: int
    workers: int
    state_bytes: int
    operator_bytes: int
    workspace_bytes: int
    worker_copy_bytes: int
    sampling_bytes: int
    result_buffer_bytes: int
    estimated_peak_bytes: int
    schema_version: str = SIMULATION_PLANNING_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.method not in _METHODS:
            raise ValueError("estimate method is unsupported.")
        for field_name in (
            "logical_sites",
            "hilbert_dimension",
            "state_dimension",
            "itemsize_bytes",
            "trajectories",
            "workers",
        ):
            _positive_int(getattr(self, field_name), field_name)
        for field_name in (
            "state_bytes",
            "operator_bytes",
            "workspace_bytes",
            "worker_copy_bytes",
            "sampling_bytes",
            "result_buffer_bytes",
            "estimated_peak_bytes",
        ):
            value = getattr(self, field_name)
            if not isinstance(value, int) or isinstance(value, bool) or value < 0:
                raise ValueError(f"{field_name} must be a non-negative integer.")
        expected = (
            self.state_bytes
            + self.operator_bytes
            + self.workspace_bytes
            + self.worker_copy_bytes
            + self.sampling_bytes
            + self.result_buffer_bytes
        )
        if self.estimated_peak_bytes != expected:
            raise ValueError("estimated_peak_bytes must equal all byte components.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SimulationResourceEstimate:
        return cls(
            method=data["method"],
            logical_sites=int(data["logical_sites"]),
            hilbert_dimension=int(data["hilbert_dimension"]),
            state_dimension=int(data["state_dimension"]),
            dtype=data["dtype"],
            itemsize_bytes=int(data["itemsize_bytes"]),
            trajectories=int(data["trajectories"]),
            workers=int(data["workers"]),
            state_bytes=int(data["state_bytes"]),
            operator_bytes=int(data["operator_bytes"]),
            workspace_bytes=int(data["workspace_bytes"]),
            worker_copy_bytes=int(data["worker_copy_bytes"]),
            sampling_bytes=int(data["sampling_bytes"]),
            result_buffer_bytes=int(data["result_buffer_bytes"]),
            estimated_peak_bytes=int(data["estimated_peak_bytes"]),
            schema_version=str(
                data.get("schema_version", SIMULATION_PLANNING_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class SimulationCandidateIR(IRMixin):
    """One selected, eligible, or rejected planner method candidate."""

    method: SelectedSimulationMethod
    status: CandidateStatus
    reason_codes: tuple[str, ...]
    estimate: SimulationResourceEstimate | None = None
    schema_version: str = SIMULATION_PLANNING_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.method not in _METHODS:
            raise ValueError("candidate method is unsupported.")
        if self.status not in {"selected", "eligible", "rejected"}:
            raise ValueError("candidate status is invalid.")
        if not self.reason_codes or any(not item.strip() for item in self.reason_codes):
            raise ValueError("candidate reason_codes must not be empty.")
        if self.estimate is not None and not isinstance(
            self.estimate,
            SimulationResourceEstimate,
        ):
            raise TypeError("estimate must be SimulationResourceEstimate or None.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SimulationCandidateIR:
        estimate = data.get("estimate")
        return cls(
            method=data["method"],
            status=data["status"],
            reason_codes=tuple(str(item) for item in data["reason_codes"]),
            estimate=(
                None
                if estimate is None
                else SimulationResourceEstimate.from_dict(estimate)
            ),
            schema_version=str(
                data.get("schema_version", SIMULATION_PLANNING_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class SimulationPlanningRequest(IRMixin):
    """Complete deterministic input to SimulationPlanner."""

    program_kind: ProgramKind
    logical_sites: int
    noisy: bool = False
    requires_trajectory: bool = False
    blockade_dimension: int | None = None
    time_integration_required: bool | None = None
    options: SimulationOptions = field(default_factory=SimulationOptions)
    host: HostResourceSnapshot | None = None
    schema_version: str = SIMULATION_PLANNING_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.program_kind not in {"digital", "analog", "hybrid"}:
            raise ValueError("program_kind must be digital, analog, or hybrid.")
        _positive_int(self.logical_sites, "logical_sites")
        if self.logical_sites > _MAX_EXACT_DIMENSION_EXPONENT:
            raise CapabilityError(
                "Hilbert dimension exponent is unsafe to materialize.",
                code="SIMULATION_DIMENSION_OVERFLOW",
                stage="simulation",
                object_path="simulation_planning.logical_sites",
                suggestion="Use a constrained subspace or reduce logical sites.",
                metadata={"logical_sites": self.logical_sites},
            )
        if not isinstance(self.noisy, bool):
            raise TypeError("noisy must be a boolean.")
        if not isinstance(self.requires_trajectory, bool):
            raise TypeError("requires_trajectory must be a boolean.")
        if self.requires_trajectory and not self.noisy:
            raise ValueError("requires_trajectory requires noisy=True.")
        if self.blockade_dimension is not None:
            _positive_int(self.blockade_dimension, "blockade_dimension")
            if self.blockade_dimension > 2**self.logical_sites:
                raise ValueError("blockade_dimension cannot exceed Hilbert dimension.")
        if self.time_integration_required is not None and not isinstance(
            self.time_integration_required,
            bool,
        ):
            raise TypeError("time_integration_required must be a boolean or None.")
        if self.time_integration_required is None:
            object.__setattr__(
                self,
                "time_integration_required",
                self.program_kind != "digital",
            )
        if not isinstance(self.options, SimulationOptions):
            raise TypeError("options must be SimulationOptions.")
        if self.host is not None and not isinstance(self.host, HostResourceSnapshot):
            raise TypeError("host must be HostResourceSnapshot or None.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SimulationPlanningRequest:
        host = data.get("host")
        return cls(
            program_kind=data["program_kind"],
            logical_sites=int(data["logical_sites"]),
            noisy=bool(data.get("noisy", False)),
            requires_trajectory=bool(data.get("requires_trajectory", False)),
            blockade_dimension=data.get("blockade_dimension"),
            time_integration_required=data.get("time_integration_required"),
            options=SimulationOptions.from_dict(dict(data.get("options", {}))),
            host=None if host is None else HostResourceSnapshot.from_dict(host),
            schema_version=str(
                data.get("schema_version", SIMULATION_PLANNING_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class SimulationExecutionPlan(IRMixin):
    """Accepted method and complete auditable resource planning decision."""

    plan_id: str
    program_kind: ProgramKind
    logical_sites: int
    noisy: bool
    method_requested: SimulationMethod
    method_selected: SelectedSimulationMethod
    integrator_requested: SimulationIntegrator
    integrator_selected: SelectedSimulationIntegrator
    state_representation: str
    device: SelectedSimulationDevice
    dtype: SimulationDType
    hilbert_dimension: int
    budget_bytes: int
    estimate: SimulationResourceEstimate
    candidates: tuple[SimulationCandidateIR, ...]
    workers: int
    trajectories: int
    rtol: float
    atol: float
    max_steps: int
    seed: int
    options_hash: str
    host_hash: str
    truthfulness: Literal["planning_only"] = "planning_only"
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = SIMULATION_PLANNING_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if not self.plan_id.strip():
            raise ValueError("plan_id must not be empty.")
        if self.method_selected not in _METHODS:
            raise ValueError("method_selected is unsupported.")
        if self.integrator_requested not in _INTEGRATORS:
            raise ValueError("integrator_requested is unsupported.")
        if self.integrator_selected not in {
            "not_applicable",
            "adaptive_dop853",
            "fixed_step_krylov",
        }:
            raise ValueError("integrator_selected is unsupported.")
        if (
            self.program_kind == "digital"
            and self.integrator_selected != "not_applicable"
        ):
            raise ValueError("Digital execution cannot select a time integrator.")
        if (
            self.program_kind == "analog"
            and self.integrator_selected == "not_applicable"
        ):
            raise ValueError("Analog execution requires a selected time integrator.")
        if (
            self.method_selected == "trajectory"
            and self.metadata.get("time_integration_required") is not False
            and self.integrator_selected != "fixed_step_krylov"
        ):
            raise ValueError("Trajectory execution requires fixed_step_krylov.")
        if (
            self.integrator_requested != "auto"
            and self.integrator_selected != self.integrator_requested
        ):
            raise ValueError("Explicit integrator request cannot be changed silently.")
        _positive_int(self.budget_bytes, "budget_bytes")
        if self.estimate.estimated_peak_bytes > self.budget_bytes:
            raise ValueError("accepted plan estimate cannot exceed budget.")
        selected = tuple(item for item in self.candidates if item.status == "selected")
        if len(selected) != 1 or selected[0].method != self.method_selected:
            raise ValueError("candidates must contain exactly one selected method.")
        if self.estimate != selected[0].estimate:
            raise ValueError("plan estimate must match the selected candidate.")
        for field_name in ("options_hash", "host_hash"):
            _require_hash(getattr(self, field_name), field_name)
        if self.truthfulness != "planning_only":
            raise ValueError("Simulation execution plans must be planning_only.")
        if not isinstance(self.metadata, dict):
            raise TypeError("metadata must be a dictionary.")
        object.__setattr__(self, "metadata", dict(self.metadata))

    def execution_contract(self) -> dict[str, Any]:
        """Return numerical execution facts without dynamic host telemetry."""
        return {
            "program_kind": self.program_kind,
            "logical_sites": self.logical_sites,
            "noisy": self.noisy,
            "method_requested": self.method_requested,
            "method_selected": self.method_selected,
            "integrator_requested": self.integrator_requested,
            "integrator_selected": self.integrator_selected,
            "state_representation": self.state_representation,
            "device": self.device,
            "dtype": self.dtype,
            "hilbert_dimension": self.hilbert_dimension,
            "workers": self.workers,
            "trajectories": self.trajectories,
            "rtol": self.rtol,
            "atol": self.atol,
            "max_steps": self.max_steps,
            "seed": self.seed,
            "options_hash": self.options_hash,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SimulationExecutionPlan:
        return cls(
            plan_id=str(data["plan_id"]),
            program_kind=data["program_kind"],
            logical_sites=int(data["logical_sites"]),
            noisy=bool(data["noisy"]),
            method_requested=data["method_requested"],
            method_selected=data["method_selected"],
            integrator_requested=data["integrator_requested"],
            integrator_selected=data["integrator_selected"],
            state_representation=str(data["state_representation"]),
            device=data["device"],
            dtype=data["dtype"],
            hilbert_dimension=int(data["hilbert_dimension"]),
            budget_bytes=int(data["budget_bytes"]),
            estimate=SimulationResourceEstimate.from_dict(data["estimate"]),
            candidates=tuple(
                SimulationCandidateIR.from_dict(item)
                for item in data["candidates"]
            ),
            workers=int(data["workers"]),
            trajectories=int(data["trajectories"]),
            rtol=float(data["rtol"]),
            atol=float(data["atol"]),
            max_steps=int(data["max_steps"]),
            seed=int(data["seed"]),
            options_hash=str(data["options_hash"]),
            host_hash=str(data["host_hash"]),
            truthfulness=data.get("truthfulness", "planning_only"),
            metadata=dict(data.get("metadata", {})),
            schema_version=str(
                data.get("schema_version", SIMULATION_PLANNING_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class SweepResourcePlanIR(IRMixin):
    """Memory-bounded worker decision for one fully expanded parameter sweep."""

    bind_count: int
    requested_workers: WorkerRequest
    selected_workers: int
    per_run_peak_bytes: int
    per_result_bytes: int
    result_buffer_bytes: int
    estimated_peak_bytes: int
    budget_bytes: int
    failure_policy: SweepFailurePolicy
    root_seed: int
    selection_reasons: tuple[str, ...]
    schema_version: str = SIMULATION_PLANNING_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _positive_int(self.bind_count, "bind_count")
        if self.requested_workers != "auto":
            _positive_int(self.requested_workers, "requested_workers")
        _positive_int(self.selected_workers, "selected_workers")
        if self.selected_workers > self.bind_count:
            raise ValueError("selected_workers cannot exceed bind_count.")
        for field_name in (
            "per_run_peak_bytes",
            "per_result_bytes",
            "result_buffer_bytes",
            "estimated_peak_bytes",
            "budget_bytes",
        ):
            _positive_int(getattr(self, field_name), field_name)
        if self.result_buffer_bytes != self.bind_count * self.per_result_bytes:
            raise ValueError("result_buffer_bytes must cover every sweep item.")
        expected_peak = (
            self.result_buffer_bytes
            + self.selected_workers * self.per_run_peak_bytes
        )
        if self.estimated_peak_bytes != expected_peak:
            raise ValueError(
                "estimated_peak_bytes must include retained results and active runs."
            )
        if self.estimated_peak_bytes > self.budget_bytes:
            raise ValueError("accepted sweep resource plan cannot exceed budget.")
        if self.failure_policy not in {"fail_fast", "continue_on_error"}:
            raise ValueError("failure_policy is invalid.")
        if not isinstance(self.root_seed, int) or isinstance(self.root_seed, bool):
            raise TypeError("root_seed must be an integer.")
        if not self.selection_reasons or any(
            not isinstance(reason, str) or not reason.strip()
            for reason in self.selection_reasons
        ):
            raise ValueError("selection_reasons must contain non-empty strings.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SweepResourcePlanIR:
        """Restore an auditable sweep resource decision."""
        return cls(
            bind_count=int(data["bind_count"]),
            requested_workers=data["requested_workers"],
            selected_workers=int(data["selected_workers"]),
            per_run_peak_bytes=int(data["per_run_peak_bytes"]),
            per_result_bytes=int(data["per_result_bytes"]),
            result_buffer_bytes=int(data["result_buffer_bytes"]),
            estimated_peak_bytes=int(data["estimated_peak_bytes"]),
            budget_bytes=int(data["budget_bytes"]),
            failure_policy=data["failure_policy"],
            root_seed=int(data["root_seed"]),
            selection_reasons=tuple(str(item) for item in data["selection_reasons"]),
            schema_version=str(
                data.get("schema_version", SIMULATION_PLANNING_SCHEMA_VERSION)
            ),
        )


class SimulationPlanner:
    """Choose one method from semantics and a conservative host memory budget."""

    def plan(self, request: SimulationPlanningRequest) -> SimulationExecutionPlan:
        if not isinstance(request, SimulationPlanningRequest):
            raise TypeError("request must be SimulationPlanningRequest.")
        options = request.options
        host = request.host or HostResourceSnapshot.detect()
        if options.device == "gpu":
            raise CapabilityError(
                "GPU array backends are not available.",
                code="SIMULATION_DEVICE_UNAVAILABLE",
                stage="simulation",
                object_path="simulation_options.device",
                suggestion="Use device='cpu' or device='auto'.",
                metadata={"device": options.device},
            )
        requested_workers = (
            host.cpu_count
            if options.workers == "auto"
            else min(options.workers, host.cpu_count)
        )
        host_budget = int(host.available_memory_bytes * options.memory_fraction)
        budget = (
            host_budget
            if options.max_memory_bytes is None
            else min(host_budget, options.max_memory_bytes)
        )
        candidates = self._candidates(
            request,
            budget_bytes=budget,
            requested_workers=requested_workers,
        )
        selected_method = self._select(request, candidates, budget)
        selected_integrator = _selected_integrator(request, selected_method)
        selected_estimate = next(
            item.estimate for item in candidates if item.method == selected_method
        )
        assert selected_estimate is not None
        selected_candidates = tuple(
            SimulationCandidateIR(
                method=item.method,
                status=("selected" if item.method == selected_method else item.status),
                reason_codes=(
                    (*item.reason_codes, "SIMULATION_METHOD_SELECTED")
                    if item.method == selected_method
                    else item.reason_codes
                ),
                estimate=item.estimate,
            )
            for item in candidates
        )
        return SimulationExecutionPlan(
            plan_id=(
                f"simulation_plan.{request.program_kind}."
                f"{request.logical_sites}.{selected_method}.{selected_integrator}"
            ),
            program_kind=request.program_kind,
            logical_sites=request.logical_sites,
            noisy=request.noisy,
            method_requested=options.method,
            method_selected=selected_method,
            integrator_requested=options.integrator,
            integrator_selected=selected_integrator,
            state_representation=selected_method,
            device="cpu",
            dtype=options.dtype,
            hilbert_dimension=2**request.logical_sites,
            budget_bytes=budget,
            estimate=selected_estimate,
            candidates=selected_candidates,
            workers=selected_estimate.workers,
            trajectories=options.trajectories,
            rtol=options.rtol,
            atol=options.atol,
            max_steps=options.max_steps,
            seed=options.seed,
            options_hash=options.stable_hash(),
            host_hash=host.stable_hash(),
            metadata={
                "numpy_version": np.__version__,
                "scipy_version": version("scipy"),
                "memory_fraction": options.memory_fraction,
                "host_snapshot_source": host.source,
                "max_wall_time_seconds": options.max_wall_time_seconds,
                "target_statistical_error": options.target_statistical_error,
                "blockade_dimension": request.blockade_dimension,
                "requires_trajectory": request.requires_trajectory,
                "time_integration_required": request.time_integration_required,
                "workers_requested": options.workers,
                "workers_cpu_limit": requested_workers,
                "array_backend": "numpy",
                "network_accessed": False,
            },
        )

    def plan_sweep(
        self,
        execution_plan: SimulationExecutionPlan,
        *,
        bind_count: int,
        failure_policy: SweepFailurePolicy,
    ) -> SweepResourcePlanIR:
        """Choose scan concurrency without retaining unbounded completed results."""
        if not isinstance(execution_plan, SimulationExecutionPlan):
            raise TypeError("execution_plan must be SimulationExecutionPlan.")
        _positive_int(bind_count, "bind_count")
        if failure_policy not in {"fail_fast", "continue_on_error"}:
            raise ValueError("failure_policy is invalid.")

        estimate = execution_plan.estimate
        # A scan worker executes one point with one internal kernel worker. In
        # particular, trajectory scan items must not inherit the standalone
        # trajectory pool's copies and then multiply them by scan concurrency.
        per_run_peak = estimate.estimated_peak_bytes - estimate.worker_copy_bytes
        per_result = max(4096, estimate.result_buffer_bytes)
        result_buffer = bind_count * per_result
        remaining = execution_plan.budget_bytes - result_buffer
        memory_workers = 0 if remaining <= 0 else remaining // per_run_peak
        policy_limit = 1 if failure_policy == "fail_fast" else bind_count
        scan_worker_limit = int(
            execution_plan.metadata.get(
                "workers_cpu_limit",
                execution_plan.workers,
            )
        )
        selected_workers = min(
            scan_worker_limit,
            bind_count,
            policy_limit,
            memory_workers,
        )
        if selected_workers < 1:
            raise CapabilityError(
                "Parameter sweep exceeds the local simulation memory budget.",
                code="SIMULATION_SWEEP_RESOURCE_BUDGET_EXCEEDED",
                stage="simulation",
                object_path="simulation_planning.sweep",
                suggestion=(
                    "Increase max_memory_bytes, reduce sweep points, or reduce "
                    "the per-run state space."
                ),
                metadata={
                    "bind_count": bind_count,
                    "requested_workers": execution_plan.metadata.get(
                        "workers_requested",
                        execution_plan.workers,
                    ),
                    "per_run_peak_bytes": per_run_peak,
                    "per_result_bytes": per_result,
                    "result_buffer_bytes": result_buffer,
                    "budget_bytes": execution_plan.budget_bytes,
                    "job_created": False,
                    "large_array_allocated": False,
                },
            )

        reasons = ["SWEEP_MEMORY_BOUNDED_WORKER_POOL"]
        if failure_policy == "fail_fast":
            # Strict fail-fast stays serial so no point can execute after the first
            # observed failure and later be mislabeled as not_run.
            reasons.append("SWEEP_STRICT_FAIL_FAST_SERIALIZED")
        if selected_workers < scan_worker_limit:
            reasons.append("SWEEP_WORKERS_REDUCED_BY_RESOURCE_OR_POLICY")
        else:
            reasons.append("SWEEP_REQUESTED_WORKERS_ACCEPTED")
        requested = execution_plan.metadata.get(
            "workers_requested",
            execution_plan.workers,
        )
        return SweepResourcePlanIR(
            bind_count=bind_count,
            requested_workers=requested,
            selected_workers=selected_workers,
            per_run_peak_bytes=per_run_peak,
            per_result_bytes=per_result,
            result_buffer_bytes=result_buffer,
            estimated_peak_bytes=(
                result_buffer + selected_workers * per_run_peak
            ),
            budget_bytes=execution_plan.budget_bytes,
            failure_policy=failure_policy,
            root_seed=execution_plan.seed,
            selection_reasons=tuple(reasons),
        )

    def estimate(
        self,
        method: SelectedSimulationMethod,
        *,
        logical_sites: int,
        dtype: SimulationDType = "complex128",
        trajectories: int = 256,
        workers: int = 1,
        subspace_dimension: int | None = None,
        workspace_factor: float | None = None,
    ) -> SimulationResourceEstimate:
        """Return deterministic conservative byte accounting for one candidate."""
        if method not in _METHODS:
            raise ValueError("method is unsupported.")
        _positive_int(logical_sites, "logical_sites")
        if logical_sites > _MAX_EXACT_DIMENSION_EXPONENT:
            raise CapabilityError(
                "Hilbert dimension exponent is unsafe to materialize.",
                code="SIMULATION_DIMENSION_OVERFLOW",
                stage="simulation",
                object_path="simulation_planning.logical_sites",
            )
        _positive_int(trajectories, "trajectories")
        _positive_int(workers, "workers")
        if workspace_factor is not None:
            _positive_float(workspace_factor, "workspace_factor")
        hilbert_dimension = 2**logical_sites
        itemsize = int(np.dtype(dtype).itemsize)
        state_dimension = hilbert_dimension
        effective_trajectories = 1
        if method == "subspace":
            if subspace_dimension is None:
                raise ValueError("subspace method requires subspace_dimension.")
            _positive_int(subspace_dimension, "subspace_dimension")
            if subspace_dimension > hilbert_dimension:
                raise ValueError("subspace_dimension exceeds Hilbert dimension.")
            state_dimension = subspace_dimension
        if method == "density_matrix":
            state_dimension = hilbert_dimension * hilbert_dimension
        elif method == "trajectory":
            effective_trajectories = trajectories
            state_dimension = trajectories * hilbert_dimension
        state_bytes = itemsize * state_dimension
        operator_dimension = (
            hilbert_dimension * hilbert_dimension
            if method == "density_matrix"
            else hilbert_dimension
        )
        operator_bytes = itemsize * operator_dimension * 2
        resolved_workspace_factor = (
            {
                "state_vector": 2.0,
                "subspace": 2.0,
                "density_matrix": 3.0,
                # Immutable handoff, Krylov input/output, and ensemble reduction
                # keep several full batches live at once in the NumPy CPU engine.
                "trajectory": 7.0,
            }[method]
            if workspace_factor is None
            else float(workspace_factor)
        )
        workspace_bytes = math.ceil(state_bytes * resolved_workspace_factor)
        worker_copy_bytes = state_bytes * max(0, workers - 1)
        sampling_bytes = max(4096, min(hilbert_dimension, 2**20) * 8)
        result_buffer_bytes = max(4096, effective_trajectories * 16)
        estimated_peak = (
            state_bytes
            + operator_bytes
            + workspace_bytes
            + worker_copy_bytes
            + sampling_bytes
            + result_buffer_bytes
        )
        return SimulationResourceEstimate(
            method=method,
            logical_sites=logical_sites,
            hilbert_dimension=hilbert_dimension,
            state_dimension=state_dimension,
            dtype=dtype,
            itemsize_bytes=itemsize,
            trajectories=effective_trajectories,
            workers=workers,
            state_bytes=state_bytes,
            operator_bytes=operator_bytes,
            workspace_bytes=workspace_bytes,
            worker_copy_bytes=worker_copy_bytes,
            sampling_bytes=sampling_bytes,
            result_buffer_bytes=result_buffer_bytes,
            estimated_peak_bytes=estimated_peak,
        )

    def _candidates(
        self,
        request: SimulationPlanningRequest,
        *,
        budget_bytes: int,
        requested_workers: int,
    ) -> tuple[SimulationCandidateIR, ...]:
        candidates: list[SimulationCandidateIR] = []
        for method in _METHODS:
            semantic_reason = _semantic_rejection(method, request)
            estimate: SimulationResourceEstimate | None = None
            if method != "subspace" or request.blockade_dimension is not None:
                single_worker = self.estimate(
                    method,
                    logical_sites=request.logical_sites,
                    dtype=request.options.dtype,
                    trajectories=request.options.trajectories,
                    workers=1,
                    subspace_dimension=request.blockade_dimension,
                    workspace_factor=_execution_workspace_factor(
                        request.program_kind,
                        method,
                        _candidate_integrator(request, method),
                    ),
                )
                method_workers = 1
                if method == "trajectory":
                    # Only the standalone trajectory engine consumes a kernel
                    # worker pool. Sweep concurrency is planned separately.
                    affordable_workers = max(
                        1,
                        1
                        + max(0, budget_bytes - single_worker.estimated_peak_bytes)
                        // single_worker.state_bytes,
                    )
                    method_workers = min(requested_workers, affordable_workers)
                estimate = self.estimate(
                    method,
                    logical_sites=request.logical_sites,
                    dtype=request.options.dtype,
                    trajectories=request.options.trajectories,
                    workers=method_workers,
                    subspace_dimension=request.blockade_dimension,
                    workspace_factor=_execution_workspace_factor(
                        request.program_kind,
                        method,
                        _candidate_integrator(request, method),
                    ),
                )
            reasons: list[str] = []
            if semantic_reason is not None:
                reasons.append(semantic_reason)
            integrator_reason = _integrator_rejection(method, request)
            if integrator_reason is not None:
                reasons.append(integrator_reason)
            if estimate is not None and estimate.estimated_peak_bytes > budget_bytes:
                reasons.append("SIMULATION_RESOURCE_BUDGET_EXCEEDED")
            candidates.append(
                SimulationCandidateIR(
                    method=method,
                    status="rejected" if reasons else "eligible",
                    reason_codes=(
                        tuple(reasons)
                        if reasons
                        else ("SIMULATION_METHOD_ELIGIBLE",)
                    ),
                    estimate=estimate,
                )
            )
        return tuple(candidates)

    def _select(
        self,
        request: SimulationPlanningRequest,
        candidates: tuple[SimulationCandidateIR, ...],
        budget_bytes: int,
    ) -> SelectedSimulationMethod:
        options = request.options
        by_method = {item.method: item for item in candidates}
        if options.method != "auto":
            requested = by_method[options.method]
            if requested.status == "rejected":
                semantic = tuple(
                    code
                    for code in requested.reason_codes
                    if code != "SIMULATION_RESOURCE_BUDGET_EXCEEDED"
                )
                code = (
                    "SIMULATION_INTEGRATOR_INAPPLICABLE"
                    if "SIMULATION_INTEGRATOR_INAPPLICABLE" in semantic
                    else (
                        "SIMULATION_METHOD_INAPPLICABLE"
                        if semantic
                        else "SIMULATION_RESOURCE_BUDGET_EXCEEDED"
                    )
                )
                raise _planning_error(
                    code,
                    request,
                    candidates,
                    budget_bytes,
                )
            return options.method
        preference: tuple[SelectedSimulationMethod, ...]
        if request.noisy:
            preference = ("density_matrix", "trajectory")
        elif (
            request.blockade_dimension is not None
            and options.blockade_mode != "full"
        ):
            preference = ("subspace", "state_vector")
        else:
            preference = ("state_vector",)
        for method in preference:
            if by_method[method].status == "eligible":
                return method
        error_code = (
            "SIMULATION_INTEGRATOR_INAPPLICABLE"
            if any(
                "SIMULATION_INTEGRATOR_INAPPLICABLE" in item.reason_codes
                for item in by_method.values()
            )
            else "SIMULATION_RESOURCE_BUDGET_EXCEEDED"
        )
        raise _planning_error(
            error_code,
            request,
            candidates,
            budget_bytes,
        )


def _semantic_rejection(
    method: SelectedSimulationMethod,
    request: SimulationPlanningRequest,
) -> str | None:
    if method in {"state_vector", "subspace"} and request.noisy:
        return "SIMULATION_METHOD_REQUIRES_IDEAL_MODEL"
    if method in {"density_matrix", "trajectory"} and not request.noisy:
        return "SIMULATION_METHOD_REQUIRES_NOISE_MODEL"
    if method == "density_matrix" and request.requires_trajectory:
        return "SIMULATION_DENSITY_LACKS_OCCUPATION_STATE"
    if method == "subspace":
        if request.options.blockade_mode == "full":
            return "SIMULATION_SUBSPACE_DISABLED"
        if request.blockade_dimension is None:
            return "SIMULATION_SUBSPACE_BASIS_UNAVAILABLE"
    return None


def _integrator_rejection(
    method: SelectedSimulationMethod,
    request: SimulationPlanningRequest,
) -> str | None:
    requested = request.options.integrator
    if not request.time_integration_required:
        return (
            None
            if requested == "auto"
            else "SIMULATION_INTEGRATOR_INAPPLICABLE"
        )
    if method == "trajectory" and requested == "adaptive_dop853":
        return "SIMULATION_INTEGRATOR_INAPPLICABLE"
    return None


def _candidate_integrator(
    request: SimulationPlanningRequest,
    method: SelectedSimulationMethod,
) -> SelectedSimulationIntegrator:
    if not request.time_integration_required:
        return "not_applicable"
    if method == "trajectory":
        return "fixed_step_krylov"
    if request.options.integrator == "fixed_step_krylov":
        return "fixed_step_krylov"
    return "adaptive_dop853"


def _selected_integrator(
    request: SimulationPlanningRequest,
    method: SelectedSimulationMethod,
) -> SelectedSimulationIntegrator:
    rejection = _integrator_rejection(method, request)
    if rejection is not None:
        raise _planning_error(
            rejection,
            request,
            (),
            0,
        )
    return _candidate_integrator(request, method)


def _execution_workspace_factor(
    program_kind: ProgramKind,
    method: SelectedSimulationMethod,
    integrator: SelectedSimulationIntegrator,
) -> float | None:
    if integrator == "adaptive_dop853":
        # DOP853 retains the current state, derivative and extended RK stages.
        # Twenty-two state-sized buffers is conservative for NumPy/SciPy work arrays.
        return 22.0
    if method != "state_vector":
        return None
    # Tensor gates hold fewer live vectors than SciPy Krylov propagation.
    if program_kind == "digital":
        return 3.0
    return 22.0


def _planning_error(
    code: str,
    request: SimulationPlanningRequest,
    candidates: tuple[SimulationCandidateIR, ...],
    budget_bytes: int,
) -> CapabilityError:
    error: CapabilityError = CapabilityError(
        "Simulation planning rejected every applicable method.",
        code=code,
        stage="simulation",
        object_path="simulation_planning.candidates",
        suggestion=(
            "Increase max_memory_bytes, reduce the state space or trajectories, "
            "or select an applicable method."
        ),
        metadata={
            "program_kind": request.program_kind,
            "logical_sites": request.logical_sites,
            "method_requested": request.options.method,
            "integrator_requested": request.options.integrator,
            "budget_bytes": budget_bytes,
            "candidates": [item.to_dict() for item in candidates],
            "large_array_allocated": False,
        },
    )
    return error


def _physical_memory_bytes() -> int:
    """返回主机物理内存总量，平台探测失败时使用保守回退值。

    Windows 不提供 ``os.sysconf``，必须通过 Kernel32 查询。这里保留统一回退，
    避免资源探测失败阻断模拟任务，但正常 Windows 环境不会再固定报告 8 GiB。
    """

    try:
        if sys.platform == "win32":
            total = _windows_physical_memory_bytes()
        else:
            page_size = int(os.sysconf("SC_PAGE_SIZE"))
            pages = int(os.sysconf("SC_PHYS_PAGES"))
            total = page_size * pages
    except (AttributeError, OSError, TypeError, ValueError):
        total = 8 * 1024**3
    return max(total, 1)


def _host_memory_bytes() -> tuple[int, int]:
    """Return the memory visible to this process and its current availability."""

    try:
        if sys.platform == "win32":
            total, available = _windows_memory_bytes()
        else:
            total = _physical_memory_bytes()
            available = _available_memory_bytes(total)
            if sys.platform.startswith("linux"):
                limit, cgroup_available = _linux_cgroup_memory_bytes()
                if limit is not None:
                    total = min(total, limit)
                if cgroup_available is not None:
                    available = min(available, cgroup_available)
    except (AttributeError, OSError, TypeError, ValueError):
        total = _physical_memory_bytes()
        available = total
    total = max(int(total), 1)
    available = max(1, min(int(available), total))
    return total, available


def _available_memory_bytes(total: int) -> int:
    try:
        sysconf = getattr(os, "sysconf", None)
        if sysconf is None:
            raise AttributeError("os.sysconf is unavailable")
        page_size = int(sysconf("SC_PAGE_SIZE"))
        pages = int(sysconf("SC_AVPHYS_PAGES"))
        available = page_size * pages
    except (AttributeError, OSError, TypeError, ValueError):
        available = total
    return max(1, min(available, total))


def _linux_cgroup_memory_bytes() -> tuple[int | None, int | None]:
    """Read cgroup v2 or v1 memory limits without assuming a container runtime."""

    candidates = (
        (
            Path("/sys/fs/cgroup/memory.max"),
            Path("/sys/fs/cgroup/memory.current"),
        ),
        (
            Path("/sys/fs/cgroup/memory/memory.limit_in_bytes"),
            Path("/sys/fs/cgroup/memory/memory.usage_in_bytes"),
        ),
    )
    for limit_path, usage_path in candidates:
        try:
            limit_text = limit_path.read_text(encoding="ascii").strip()
            if limit_text == "max":
                return None, None
            limit = int(limit_text)
            usage = int(usage_path.read_text(encoding="ascii").strip())
        except (FileNotFoundError, OSError, UnicodeError, ValueError):
            continue
        if limit <= 0:
            continue
        return limit, max(1, limit - max(0, usage))
    return None, None


def _effective_cpu_count() -> int:
    """Choose a conservative process CPU budget across hosts and containers."""

    logical = max(os.cpu_count() or 1, 1)
    limits = [logical, _physical_cpu_count(logical)]
    affinity = _affinity_cpu_count()
    if affinity is not None:
        limits.append(affinity)
    if sys.platform.startswith("linux"):
        quota = _linux_cpu_quota_count()
        if quota is not None:
            limits.append(quota)
    return max(1, min(value for value in limits if value > 0))


def _physical_cpu_count(logical_fallback: int) -> int:
    try:
        if sys.platform == "win32":
            detected = _windows_physical_cpu_count()
        elif sys.platform == "darwin":
            detected = _macos_physical_cpu_count()
        elif sys.platform.startswith("linux"):
            detected = _linux_physical_cpu_count()
        else:
            detected = logical_fallback
    except (AttributeError, OSError, TypeError, ValueError):
        detected = logical_fallback
    return max(1, min(int(detected), logical_fallback))


def _affinity_cpu_count() -> int | None:
    get_affinity = getattr(os, "sched_getaffinity", None)
    if get_affinity is not None:
        try:
            return max(len(get_affinity(0)), 1)
        except OSError:
            pass
    if sys.platform != "win32":
        return None
    try:
        return _windows_affinity_cpu_count()
    except (AttributeError, OSError, TypeError, ValueError):
        return None


def _linux_physical_cpu_count() -> int:
    allowed = getattr(os, "sched_getaffinity", lambda _pid: ())(0)
    allowed_ids = {int(item) for item in allowed}
    cores: set[tuple[str, str]] = set()
    for cpu_path in Path("/sys/devices/system/cpu").glob("cpu[0-9]*"):
        cpu_id = int(cpu_path.name[3:])
        if allowed_ids and cpu_id not in allowed_ids:
            continue
        topology = cpu_path / "topology"
        try:
            package = (topology / "physical_package_id").read_text(
                encoding="ascii"
            ).strip()
            core = (topology / "core_id").read_text(encoding="ascii").strip()
        except (FileNotFoundError, OSError, UnicodeError, ValueError):
            continue
        cores.add((package, core))
    if not cores:
        raise OSError("Linux CPU topology is unavailable")
    return len(cores)


def _linux_cpu_quota_count() -> int | None:
    candidates = (
        (Path("/sys/fs/cgroup/cpu.max"), None),
        (
            Path("/sys/fs/cgroup/cpu/cpu.cfs_quota_us"),
            Path("/sys/fs/cgroup/cpu/cpu.cfs_period_us"),
        ),
    )
    for quota_path, period_path in candidates:
        try:
            if period_path is None:
                quota_text, period_text = quota_path.read_text(
                    encoding="ascii"
                ).split()
                if quota_text == "max":
                    return None
                quota = int(quota_text)
                period = int(period_text)
            else:
                quota = int(quota_path.read_text(encoding="ascii").strip())
                period = int(period_path.read_text(encoding="ascii").strip())
        except (FileNotFoundError, OSError, UnicodeError, ValueError):
            continue
        if quota <= 0 or period <= 0:
            return None
        return max(1, quota // period)
    return None


def _windows_physical_cpu_count() -> int:
    relation_processor_core = 0
    kernel32 = _windows_dll("kernel32")
    query = kernel32.GetLogicalProcessorInformationEx
    query.argtypes = [ctypes.c_int, ctypes.c_void_p, ctypes.POINTER(ctypes.c_ulong)]
    query.restype = ctypes.c_int
    length = ctypes.c_ulong(0)
    query(relation_processor_core, None, ctypes.byref(length))
    if length.value == 0:
        raise OSError("GetLogicalProcessorInformationEx size query failed")
    buffer = ctypes.create_string_buffer(length.value)
    if not query(relation_processor_core, buffer, ctypes.byref(length)):
        error_code = _windows_last_error()
        raise OSError(error_code, "GetLogicalProcessorInformationEx failed")
    offset = 0
    cores = 0
    while offset < length.value:
        record_size = ctypes.c_ulong.from_buffer(buffer, offset + 4).value
        if record_size < 8 or offset + record_size > length.value:
            raise OSError("invalid Windows processor topology record")
        cores += 1
        offset += record_size
    if cores == 0:
        raise OSError("Windows processor topology returned no cores")
    return cores


def _windows_affinity_cpu_count() -> int:
    kernel32 = _windows_dll("kernel32")
    kernel32.GetCurrentProcess.restype = ctypes.c_void_p
    get_mask = kernel32.GetProcessAffinityMask
    get_mask.argtypes = [
        ctypes.c_void_p,
        ctypes.POINTER(ctypes.c_size_t),
        ctypes.POINTER(ctypes.c_size_t),
    ]
    get_mask.restype = ctypes.c_int
    process_mask = ctypes.c_size_t()
    system_mask = ctypes.c_size_t()
    if not get_mask(
        kernel32.GetCurrentProcess(),
        ctypes.byref(process_mask),
        ctypes.byref(system_mask),
    ):
        error_code = _windows_last_error()
        raise OSError(error_code, "GetProcessAffinityMask failed")
    return max(bin(int(process_mask.value)).count("1"), 1)


def _macos_physical_cpu_count() -> int:
    libc = ctypes.CDLL("libc.dylib", use_errno=True)
    sysctl = libc.sysctlbyname
    sysctl.argtypes = [
        ctypes.c_char_p,
        ctypes.c_void_p,
        ctypes.POINTER(ctypes.c_size_t),
        ctypes.c_void_p,
        ctypes.c_size_t,
    ]
    sysctl.restype = ctypes.c_int
    value = ctypes.c_uint()
    size = ctypes.c_size_t(ctypes.sizeof(value))
    if sysctl(
        b"hw.physicalcpu",
        ctypes.byref(value),
        ctypes.byref(size),
        None,
        0,
    ):
        error_code = ctypes.get_errno()
        raise OSError(error_code, "sysctlbyname hw.physicalcpu failed")
    return int(value.value)


class _WindowsMemoryStatusEx(ctypes.Structure):
    """与 Windows ``MEMORYSTATUSEX`` 结构保持相同的字段顺序和宽度。"""

    _fields_ = [
        ("dwLength", ctypes.c_ulong),
        ("dwMemoryLoad", ctypes.c_ulong),
        ("ullTotalPhys", ctypes.c_ulonglong),
        ("ullAvailPhys", ctypes.c_ulonglong),
        ("ullTotalPageFile", ctypes.c_ulonglong),
        ("ullAvailPageFile", ctypes.c_ulonglong),
        ("ullTotalVirtual", ctypes.c_ulonglong),
        ("ullAvailVirtual", ctypes.c_ulonglong),
        ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
    ]


def _windows_physical_memory_bytes() -> int:
    """通过 Kernel32 获取 Windows 物理内存总量，不读取注册表或外部命令。"""

    total, _available = _windows_memory_bytes()
    return total


def _windows_memory_bytes() -> tuple[int, int]:
    """Return total and currently available Windows physical memory."""

    # WinDLL 只在 Windows Python 中存在。本函数仅由 win32 分支调用，属性缺失时
    # 由上层统一异常处理覆盖精简 Python runtime 等异常环境。
    kernel32 = _windows_dll("kernel32")
    memory_status = kernel32.GlobalMemoryStatusEx
    memory_status.argtypes = [ctypes.POINTER(_WindowsMemoryStatusEx)]
    memory_status.restype = ctypes.c_int

    status = _WindowsMemoryStatusEx()
    status.dwLength = ctypes.sizeof(status)
    if not memory_status(ctypes.byref(status)):
        error_code = _windows_last_error()
        raise OSError(error_code, "GlobalMemoryStatusEx failed")
    return int(status.ullTotalPhys), int(status.ullAvailPhys)


def _windows_dll(name: str) -> Any:
    """Load a Win32 DLL while keeping non-Windows type checking importable."""

    constructor = getattr(ctypes, "WinDLL", None)
    if constructor is None:
        raise OSError("WinDLL is unavailable on this Python runtime")
    return constructor(name, use_last_error=True)


def _windows_last_error() -> int:
    """Read the Win32 thread-local error code through its platform-only API."""

    getter = getattr(ctypes, "get_last_error", None)
    return 0 if getter is None else int(getter())


def _positive_int(value: object, field_name: str) -> None:
    if not isinstance(value, int) or isinstance(value, bool) or value <= 0:
        raise ValueError(f"{field_name} must be a positive integer.")


def _optional_positive_int(value: object, field_name: str) -> None:
    if value is not None:
        _positive_int(value, field_name)


def _positive_float(value: object, field_name: str) -> None:
    if (
        not isinstance(value, (int, float))
        or isinstance(value, bool)
        or not math.isfinite(float(value))
        or float(value) <= 0.0
    ):
        raise ValueError(f"{field_name} must be finite and positive.")


def _optional_positive_float(value: object, field_name: str) -> None:
    if value is not None:
        _positive_float(value, field_name)


def _require_hash(value: object, field_name: str) -> None:
    if (
        not isinstance(value, str)
        or len(value) != 64
        or any(character not in "0123456789abcdef" for character in value)
    ):
        raise ValueError(f"{field_name} must be a lowercase SHA-256 digest.")
