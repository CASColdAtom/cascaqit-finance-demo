"""Structured diagnostics for CASCAQit."""

from __future__ import annotations

from cascaqit.diagnostics.models import DiagnosticsIR
from cascaqit.diagnostics.taxonomy import (
    diagnostic_taxonomy_summary,
    with_diagnostic_taxonomy,
)

__all__ = [
    "DiagnosticsIR",
    "diagnostic_taxonomy_summary",
    "with_diagnostic_taxonomy",
]
