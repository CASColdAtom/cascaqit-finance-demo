"""Diagnostic IR models."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Literal

from cascaqit.native_ir.base import IRMixin
from cascaqit.native_ir.models import SCHEMA_VERSION

__all__ = ["DiagnosticsIR"]

DiagnosticStage = Literal[
    "validation",
    "discretization",
    "compilation",
    "simulation",
    "serialization",
]
DiagnosticSeverity = Literal["info", "warning", "error"]


@dataclass(frozen=True)
class DiagnosticsIR(IRMixin):
    """Machine-readable diagnostic message."""

    diagnostic_id: str
    stage: DiagnosticStage
    severity: DiagnosticSeverity
    code: str
    message: str
    schema_version: str = SCHEMA_VERSION
    object_path: str | None = None
    suggestion: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DiagnosticsIR:
        """Build a diagnostic from a JSON-compatible dictionary."""
        return cls(
            diagnostic_id=str(data["diagnostic_id"]),
            stage=data["stage"],
            severity=data["severity"],
            code=str(data["code"]),
            message=str(data["message"]),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            object_path=data.get("object_path"),
            suggestion=data.get("suggestion"),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> DiagnosticsIR:
        """Build a diagnostic from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("DiagnosticsIR JSON must contain an object.")
        return cls.from_dict(data)
