"""Lightweight diagnostic taxonomy helpers."""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import replace
from typing import Any

from cascaqit.diagnostics.models import DiagnosticsIR

__all__ = ["diagnostic_taxonomy_summary", "with_diagnostic_taxonomy"]

_DEFAULT_STAGE_BY_CATEGORY = {
    "artifact_access": "artifact_access",
    "backend": "backend",
    "blocked": "runtime",
    "calibration": "compilation",
    "cloud": "backend",
    "compiler": "compilation",
    "control": "compilation",
    "digital": "validation",
    "discretization": "compilation",
    "execution_package": "serialization",
    "execution_capability": "validation",
    "noise": "simulation",
    "result_consistency": "runtime",
    "result_adapter": "serialization",
    "runtime": "runtime",
    "schema": "schema",
    "simulation": "simulation",
    "target": "validation",
    "validation": "validation",
}


def with_diagnostic_taxonomy(
    diagnostic: DiagnosticsIR,
    *,
    reason_category: str,
    taxonomy_stage: str | None = None,
    action: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> DiagnosticsIR:
    """Return a copy with normalized diagnostic taxonomy metadata."""
    category = str(reason_category)
    merged = dict(diagnostic.metadata)
    merged.update(
        {
            "reason_category": category,
            "taxonomy_stage": taxonomy_stage
            or _DEFAULT_STAGE_BY_CATEGORY.get(category, diagnostic.stage),
            "actionable": bool(diagnostic.suggestion or action),
        }
    )
    if action is not None:
        merged["action"] = action
    if metadata:
        merged.update(metadata)
    return replace(diagnostic, metadata=merged)


def diagnostic_taxonomy_summary(
    diagnostics: Iterable[DiagnosticsIR],
) -> dict[str, Any]:
    """Summarize diagnostic taxonomy metadata without mutating diagnostics."""
    by_reason_category: dict[str, int] = {}
    by_taxonomy_stage: dict[str, int] = {}
    actionable_count = 0
    total = 0
    missing_taxonomy: list[str] = []
    for diagnostic in diagnostics:
        total += 1
        category = diagnostic.metadata.get("reason_category")
        stage = diagnostic.metadata.get("taxonomy_stage")
        if isinstance(category, str) and category:
            by_reason_category[category] = by_reason_category.get(category, 0) + 1
        else:
            missing_taxonomy.append(diagnostic.code)
        if isinstance(stage, str) and stage:
            by_taxonomy_stage[stage] = by_taxonomy_stage.get(stage, 0) + 1
        if diagnostic.suggestion or bool(diagnostic.metadata.get("actionable")):
            actionable_count += 1
    return {
        "taxonomy_version": "diagnostic_taxonomy.v0_21",
        "total": total,
        "by_reason_category": by_reason_category,
        "by_taxonomy_stage": by_taxonomy_stage,
        "actionable_count": actionable_count,
        "missing_taxonomy_codes": sorted(set(missing_taxonomy)),
    }
