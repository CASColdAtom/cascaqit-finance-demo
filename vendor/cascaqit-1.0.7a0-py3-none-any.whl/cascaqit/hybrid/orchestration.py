"""Immutable contracts shared by hybrid programs, graphs, and compilers."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Literal

from cascaqit.hybrid.diagnostics import ORCHESTRATION_SCHEMA_VERSION
from cascaqit.native_ir.base import IRMixin
from cascaqit.syntax import (
    SemanticArgumentHIR,
    SemanticBlockHIR,
    SemanticInvocationHIR,
    SemanticLogicalResourceHIR,
    SourceSpan,
)

__all__ = ["BlockDependency", "HybridProgramBlock"]

HybridBlockKind = Literal["digital", "analog", "measurement"]
DependencyType = Literal[
    "quantum_state",
    "classical_value",
    "parameter",
    "timing",
    "resource",
]


def _require_identifier(value: str, *, field_name: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field_name} must be a non-empty string.")


@dataclass(frozen=True)
class HybridProgramBlock(IRMixin):
    """One resolved HIR invocation retained by the orchestration layer."""

    block_id: str
    declaration_node_id: str
    invocation_node_id: str
    block_name: str
    block_kind: HybridBlockKind
    arguments: tuple[SemanticArgumentHIR, ...] = ()
    logical_resources: tuple[SemanticLogicalResourceHIR, ...] = ()
    mapping: dict[str, str] = field(default_factory=dict)
    required_capabilities: tuple[str, ...] = ()
    source_span: SourceSpan | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = ORCHESTRATION_SCHEMA_VERSION

    def __post_init__(self) -> None:
        for field_name in (
            "block_id",
            "declaration_node_id",
            "invocation_node_id",
            "block_name",
        ):
            _require_identifier(getattr(self, field_name), field_name=field_name)
        if self.block_kind not in {"digital", "analog", "measurement"}:
            raise ValueError("invalid block_kind.")
        if any(
            not isinstance(argument, SemanticArgumentHIR)
            for argument in self.arguments
        ):
            raise TypeError("arguments must contain SemanticArgumentHIR values.")
        if any(
            not isinstance(resource, SemanticLogicalResourceHIR)
            for resource in self.logical_resources
        ):
            raise TypeError(
                "logical_resources must contain SemanticLogicalResourceHIR values."
            )
        if self.source_span is not None and not isinstance(
            self.source_span, SourceSpan
        ):
            raise TypeError("source_span must be SourceSpan or None.")
        logical_ids = {resource.logical_id for resource in self.logical_resources}
        unknown_mapping_ids = sorted(set(self.mapping) - logical_ids)
        if unknown_mapping_ids:
            raise ValueError(
                "mapping contains unknown logical ids: "
                + ", ".join(unknown_mapping_ids)
            )
        targets = tuple(self.mapping.values())
        if len(set(targets)) != len(targets):
            raise ValueError("mapping targets must be unique within a block.")
        if any(not capability.strip() for capability in self.required_capabilities):
            raise ValueError("required capabilities must be non-empty strings.")

    @classmethod
    def from_hir(
        cls,
        declaration: SemanticBlockHIR,
        invocation: SemanticInvocationHIR,
    ) -> HybridProgramBlock:
        """Create an orchestration block from a matched declaration and call."""
        if invocation.block_node_id != declaration.node_id:
            raise ValueError("invocation does not reference the declaration.")
        if invocation.block_name != declaration.name:
            raise ValueError("invocation and declaration names do not match.")
        if invocation.block_kind != declaration.block_kind:
            raise ValueError("invocation and declaration block kinds do not match.")
        return cls(
            block_id=invocation.node_id,
            declaration_node_id=declaration.node_id,
            invocation_node_id=invocation.node_id,
            block_name=declaration.name,
            block_kind=declaration.block_kind,
            arguments=invocation.arguments,
            logical_resources=declaration.logical_resources,
            mapping=dict(invocation.mapping),
            required_capabilities=declaration.required_capabilities,
            source_span=invocation.source_span or declaration.source_span,
            metadata={
                "declaration_syntax_node_id": declaration.syntax_node_id,
                "invocation_syntax_node_id": invocation.syntax_node_id,
            },
        )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> HybridProgramBlock:
        """Build an orchestration block from a dictionary."""
        span_data = data.get("source_span")
        return cls(
            block_id=str(data["block_id"]),
            declaration_node_id=str(data["declaration_node_id"]),
            invocation_node_id=str(data["invocation_node_id"]),
            block_name=str(data["block_name"]),
            block_kind=data["block_kind"],
            arguments=tuple(
                SemanticArgumentHIR.from_dict(item)
                for item in data.get("arguments", ())
            ),
            logical_resources=tuple(
                SemanticLogicalResourceHIR.from_dict(item)
                for item in data.get("logical_resources", ())
            ),
            mapping={
                str(key): str(value) for key, value in data.get("mapping", {}).items()
            },
            required_capabilities=tuple(
                str(item) for item in data.get("required_capabilities", ())
            ),
            source_span=(
                None if span_data is None else SourceSpan.from_dict(span_data)
            ),
            metadata=dict(data.get("metadata", {})),
            schema_version=str(
                data.get("schema_version", ORCHESTRATION_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> HybridProgramBlock:
        """Build an orchestration block from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("HybridProgramBlock JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class BlockDependency(IRMixin):
    """A typed dependency between two orchestration blocks."""

    dependency_id: str
    source_block_id: str
    target_block_id: str
    dependency_type: DependencyType
    source_span: SourceSpan | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = ORCHESTRATION_SCHEMA_VERSION

    def __post_init__(self) -> None:
        for field_name in (
            "dependency_id",
            "source_block_id",
            "target_block_id",
        ):
            _require_identifier(getattr(self, field_name), field_name=field_name)
        if self.source_block_id == self.target_block_id:
            raise ValueError("dependency endpoints must be different blocks.")
        if self.dependency_type not in {
            "quantum_state",
            "classical_value",
            "parameter",
            "timing",
            "resource",
        }:
            raise ValueError("invalid dependency_type.")
        if self.source_span is not None and not isinstance(
            self.source_span, SourceSpan
        ):
            raise TypeError("source_span must be SourceSpan or None.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> BlockDependency:
        """Build a block dependency from a dictionary."""
        span_data = data.get("source_span")
        return cls(
            dependency_id=str(data["dependency_id"]),
            source_block_id=str(data["source_block_id"]),
            target_block_id=str(data["target_block_id"]),
            dependency_type=data["dependency_type"],
            source_span=(
                None if span_data is None else SourceSpan.from_dict(span_data)
            ),
            metadata=dict(data.get("metadata", {})),
            schema_version=str(
                data.get("schema_version", ORCHESTRATION_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> BlockDependency:
        """Build a block dependency from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("BlockDependency JSON must contain an object.")
        return cls.from_dict(data)
