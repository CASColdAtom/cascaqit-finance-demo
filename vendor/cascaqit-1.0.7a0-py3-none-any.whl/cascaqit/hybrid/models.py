"""Hybrid planning and boundary models for ordered mixed-mode programs."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Literal, Union

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.digital import CircuitIR, DigitalMeasurementIR
from cascaqit.native_ir import ProgramIR
from cascaqit.native_ir.base import IRMixin
from cascaqit.native_ir.models import SCHEMA_VERSION

__all__ = [
    "AnalogBlockIR",
    "DigitalBlockIR",
    "HybridBackendReadinessIR",
    "HybridBlockStateSummaryIR",
    "HybridBoundaryDiagnosticIR",
    "HybridProgramIR",
    "HybridSimulationPlanIR",
    "MeasureBlockIR",
    "assess_hybrid_backend_readiness",
    "build_hybrid_program",
    "build_hybrid_simulation_plan",
    "diagnose_hybrid_execution_support",
]

BlockType = Literal["digital", "analog", "measure"]
HybridValidationMode = Literal["ir_only"]
HybridStateKind = Literal[
    "state_vector",
    "analog_state_vector",
    "measurement_samples",
    "classical_register",
    "unsupported",
    "none",
]
HybridBoundaryStatus = Literal["ok", "warning", "error"]
HybridBackendReadinessStatus = Literal["blocked"]


@dataclass(frozen=True)
class DigitalBlockIR(IRMixin):
    """Digital block inside a hybrid program."""

    block_id: str
    circuit: CircuitIR
    start_time: float | None = None
    duration: float | None = None
    time_unit: str = "us"
    block_type: Literal["digital"] = "digital"
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DigitalBlockIR:
        """Build a digital block from a JSON-compatible dictionary."""
        return cls(
            block_id=str(data["block_id"]),
            circuit=CircuitIR.from_dict(data["circuit"]),
            start_time=None
            if data.get("start_time") is None
            else float(data["start_time"]),
            duration=None if data.get("duration") is None else float(data["duration"]),
            time_unit=str(data.get("time_unit", "us")),
            block_type=data.get("block_type", "digital"),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> DigitalBlockIR:
        """Build a digital block from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("DigitalBlockIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class AnalogBlockIR(IRMixin):
    """Analog AHS block inside a hybrid program."""

    block_id: str
    program: ProgramIR
    start_time: float | None = None
    duration: float | None = None
    time_unit: str = "us"
    block_type: Literal["analog"] = "analog"
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> AnalogBlockIR:
        """Build an analog block from a JSON-compatible dictionary."""
        return cls(
            block_id=str(data["block_id"]),
            program=ProgramIR.from_dict(data["program"]),
            start_time=None
            if data.get("start_time") is None
            else float(data["start_time"]),
            duration=None if data.get("duration") is None else float(data["duration"]),
            time_unit=str(data.get("time_unit", "us")),
            block_type=data.get("block_type", "analog"),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> AnalogBlockIR:
        """Build an analog block from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("AnalogBlockIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class MeasureBlockIR(IRMixin):
    """Terminal measurement block inside a hybrid program."""

    block_id: str
    measurements: tuple[DigitalMeasurementIR, ...]
    start_time: float | None = None
    duration: float | None = None
    time_unit: str = "us"
    block_type: Literal["measure"] = "measure"
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> MeasureBlockIR:
        """Build a measure block from a JSON-compatible dictionary."""
        return cls(
            block_id=str(data["block_id"]),
            measurements=tuple(
                DigitalMeasurementIR.from_dict(measurement)
                for measurement in data.get("measurements", ())
            ),
            start_time=None
            if data.get("start_time") is None
            else float(data["start_time"]),
            duration=None if data.get("duration") is None else float(data["duration"]),
            time_unit=str(data.get("time_unit", "us")),
            block_type=data.get("block_type", "measure"),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> MeasureBlockIR:
        """Build a measure block from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("MeasureBlockIR JSON must contain an object.")
        return cls.from_dict(data)


HybridBlockIR = Union[DigitalBlockIR, AnalogBlockIR, MeasureBlockIR]


@dataclass(frozen=True)
class HybridBlockStateSummaryIR(IRMixin):
    """Plan-time input/output state summary for one hybrid block."""

    block_id: str
    block_type: BlockType
    input_state_kind: HybridStateKind
    output_state_kind: HybridStateKind
    start_time: float | None = None
    duration: float | None = None
    time_unit: str = "us"
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> HybridBlockStateSummaryIR:
        """Build a block state summary from a dictionary."""
        return cls(
            block_id=str(data["block_id"]),
            block_type=data["block_type"],
            input_state_kind=data["input_state_kind"],
            output_state_kind=data["output_state_kind"],
            start_time=None
            if data.get("start_time") is None
            else float(data["start_time"]),
            duration=None if data.get("duration") is None else float(data["duration"]),
            time_unit=str(data.get("time_unit", "us")),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )


@dataclass(frozen=True)
class HybridBoundaryDiagnosticIR(IRMixin):
    """Plan-time diagnostic for a boundary between two hybrid blocks."""

    boundary_id: str
    left_block_id: str
    right_block_id: str
    left_block_type: BlockType
    right_block_type: BlockType
    status: HybridBoundaryStatus
    code: str
    message: str
    schema_version: str = SCHEMA_VERSION
    object_path: str | None = None
    suggestion: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> HybridBoundaryDiagnosticIR:
        """Build a boundary diagnostic from a dictionary."""
        return cls(
            boundary_id=str(data["boundary_id"]),
            left_block_id=str(data["left_block_id"]),
            right_block_id=str(data["right_block_id"]),
            left_block_type=data["left_block_type"],
            right_block_type=data["right_block_type"],
            status=data["status"],
            code=str(data["code"]),
            message=str(data["message"]),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            object_path=data.get("object_path"),
            suggestion=data.get("suggestion"),
            metadata=dict(data.get("metadata", {})),
        )


@dataclass(frozen=True)
class HybridSimulationPlanIR(IRMixin):
    """Deterministic plan-only artifact for hybrid simulation review."""

    plan_id: str
    program_id: str
    executable: bool
    execution_mode: Literal["plan_only"] = "plan_only"
    block_states: tuple[HybridBlockStateSummaryIR, ...] = ()
    boundary_diagnostics: tuple[HybridBoundaryDiagnosticIR, ...] = ()
    diagnostics: tuple[DiagnosticsIR, ...] = ()
    mapping: dict[str, str] = field(default_factory=dict)
    timeline: tuple[dict[str, Any], ...] = ()
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> HybridSimulationPlanIR:
        """Build a hybrid simulation plan from a dictionary."""
        return cls(
            plan_id=str(data["plan_id"]),
            program_id=str(data["program_id"]),
            executable=bool(data["executable"]),
            execution_mode=data.get("execution_mode", "plan_only"),
            block_states=tuple(
                HybridBlockStateSummaryIR.from_dict(item)
                for item in data.get("block_states", ())
            ),
            boundary_diagnostics=tuple(
                HybridBoundaryDiagnosticIR.from_dict(item)
                for item in data.get("boundary_diagnostics", ())
            ),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(item) for item in data.get("diagnostics", ())
            ),
            mapping={
                str(key): str(value)
                for key, value in data.get("mapping", {}).items()
            },
            timeline=tuple(dict(item) for item in data.get("timeline", ())),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> HybridSimulationPlanIR:
        """Build a hybrid simulation plan from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("HybridSimulationPlanIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class HybridBackendReadinessIR(IRMixin):
    """Metadata-only readiness result for blocked hybrid backend execution."""

    readiness_id: str
    program_id: str
    status: HybridBackendReadinessStatus
    requested_mode: Literal["backend_run"] = "backend_run"
    plan_id: str | None = None
    blocking_diagnostics: tuple[DiagnosticsIR, ...] = ()
    diagnostics: tuple[DiagnosticsIR, ...] = ()
    package_built: bool = False
    backend_submitted: bool = False
    full_daqc_state_handoff: bool = False
    mixed_state_handoff_executed: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> HybridBackendReadinessIR:
        """Build hybrid backend readiness from a dictionary."""
        return cls(
            readiness_id=str(data["readiness_id"]),
            program_id=str(data["program_id"]),
            status=data.get("status", "blocked"),
            requested_mode=data.get("requested_mode", "backend_run"),
            plan_id=data.get("plan_id"),
            blocking_diagnostics=tuple(
                DiagnosticsIR.from_dict(item)
                for item in data.get("blocking_diagnostics", ())
            ),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(item)
                for item in data.get("diagnostics", ())
            ),
            package_built=bool(data.get("package_built", False)),
            backend_submitted=bool(data.get("backend_submitted", False)),
            full_daqc_state_handoff=bool(
                data.get("full_daqc_state_handoff", False)
            ),
            mixed_state_handoff_executed=bool(
                data.get("mixed_state_handoff_executed", False)
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> HybridBackendReadinessIR:
        """Build hybrid backend readiness from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("HybridBackendReadinessIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class HybridProgramIR(IRMixin):
    """Legacy IR-only wrapper for linear block-sequence review."""

    program_id: str
    blocks: tuple[HybridBlockIR, ...]
    mapping: dict[str, str]
    schema_version: str = SCHEMA_VERSION
    program_type: Literal["hybrid"] = "hybrid"
    validation_mode: HybridValidationMode = "ir_only"
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> HybridProgramIR:
        """Build a hybrid program from a JSON-compatible dictionary."""
        return cls(
            program_id=str(data["program_id"]),
            blocks=tuple(_block_from_dict(block) for block in data.get("blocks", ())),
            mapping={
                str(key): str(value)
                for key, value in data.get("mapping", {}).items()
            },
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            program_type=data.get("program_type", "hybrid"),
            validation_mode=data.get("validation_mode", "ir_only"),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> HybridProgramIR:
        """Build a hybrid program from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("HybridProgramIR JSON must contain an object.")
        return cls.from_dict(data)

    def validate_ir_only(self) -> tuple[DiagnosticsIR, ...]:
        """Validate hybrid IR shape without claiming execution support."""
        diagnostics: list[DiagnosticsIR] = []
        if not self.blocks:
            diagnostics.append(
                _hybrid_diagnostic(
                    code="HYBRID_EMPTY_BLOCK_SEQUENCE",
                    message="Hybrid programs require at least one block.",
                    object_path="hybrid_program.blocks",
                    severity="error",
                )
            )
            return tuple(diagnostics)
        block_ids = [block.block_id for block in self.blocks]
        if len(set(block_ids)) != len(block_ids):
            diagnostics.append(
                _hybrid_diagnostic(
                    code="HYBRID_DUPLICATE_BLOCK_ID",
                    message="Hybrid block identifiers must be unique.",
                    object_path="hybrid_program.blocks",
                    severity="error",
                )
            )
        diagnostics.extend(_validate_mapping(self))
        diagnostics.extend(_validate_block_sequence(self.blocks))
        diagnostics.extend(_validate_block_payloads(self.blocks))
        if not diagnostics:
            diagnostics.append(
                DiagnosticsIR(
                    diagnostic_id="hybrid.ir.valid",
                    stage="validation",
                    severity="info",
                    code="HYBRID_IR_VALID",
                    message="Hybrid program is valid as IR-only data.",
                    object_path="hybrid_program",
                    metadata={"validation_mode": "ir_only"},
                )
            )
        return tuple(diagnostics)

    def block_timeline(self) -> tuple[dict[str, Any], ...]:
        """Return a JSON-compatible block timeline summary."""
        return tuple(
            {
                "block_id": block.block_id,
                "block_type": block.block_type,
                "start_time": block.start_time,
                "duration": block.duration,
                "time_unit": block.time_unit,
            }
            for block in self.blocks
        )


def build_hybrid_program(
    *,
    program_id: str,
    blocks: tuple[HybridBlockIR, ...] | list[HybridBlockIR],
    mapping: dict[str, str],
    metadata: dict[str, Any] | None = None,
) -> HybridProgramIR:
    """Build a legacy HybridProgramIR review artifact."""
    return HybridProgramIR(
        program_id=program_id,
        blocks=tuple(blocks),
        mapping=dict(mapping),
        metadata={} if metadata is None else dict(metadata),
    )


def build_hybrid_simulation_plan(program: HybridProgramIR) -> HybridSimulationPlanIR:
    """Build a plan-only hybrid simulation review artifact."""
    validation = program.validate_ir_only()
    blocking = tuple(
        diagnostic
        for diagnostic in validation
        if diagnostic.severity in {"warning", "error"}
    )
    block_states = tuple(_block_state_summary(block) for block in program.blocks)
    boundaries = _boundary_diagnostics(program.blocks)
    diagnostics = (
        blocking
        if blocking
        else (
            DiagnosticsIR(
                diagnostic_id="hybrid.simulation.plan.created",
                stage="simulation",
                severity="info",
                code="HYBRID_SIMULATION_PLAN_CREATED",
                message=(
                    "Hybrid simulation plan was created without executing blocks."
                ),
                object_path="hybrid_simulation_plan",
                suggestion=(
                    "Use the plan to review mapping and state handoff boundaries."
                ),
                metadata={"program_id": program.program_id},
            ),
        )
    )
    warning_or_error_boundaries = [
        boundary
        for boundary in boundaries
        if boundary.status in {"warning", "error"}
    ]
    return HybridSimulationPlanIR(
        plan_id=f"hybrid_plan.{program.program_id}",
        program_id=program.program_id,
        executable=not blocking and not warning_or_error_boundaries,
        block_states=block_states,
        boundary_diagnostics=boundaries,
        diagnostics=diagnostics,
        mapping=dict(program.mapping),
        timeline=program.block_timeline(),
        metadata={
            "block_count": len(program.blocks),
            "boundary_count": len(boundaries),
            "plan_only": True,
            "execution_boundary": _hybrid_execution_boundary(
                program,
                blocking=blocking,
                warning_or_error_boundaries=tuple(warning_or_error_boundaries),
            ),
            "full_daqc_state_handoff": False,
        },
    )


def assess_hybrid_backend_readiness(
    program: HybridProgramIR,
) -> HybridBackendReadinessIR:
    """Return a structured blocked-readiness artifact for hybrid backend runs."""
    plan = build_hybrid_simulation_plan(program)
    diagnostics = list(_hybrid_backend_blocking_diagnostics(program, plan))
    return HybridBackendReadinessIR(
        readiness_id=f"hybrid_backend_readiness.{program.program_id}",
        program_id=program.program_id,
        status="blocked",
        plan_id=plan.plan_id,
        blocking_diagnostics=tuple(diagnostics),
        diagnostics=tuple(diagnostics),
        package_built=False,
        backend_submitted=False,
        full_daqc_state_handoff=False,
        mixed_state_handoff_executed=False,
        metadata={
            "program_type": program.program_type,
            "requested_mode": "backend_run",
            "plan_executable": plan.executable,
            "execution_boundary": plan.metadata.get(
                "execution_boundary",
                _hybrid_execution_boundary(
                    program,
                    blocking=(),
                    warning_or_error_boundaries=(),
                ),
            ),
            "boundary_codes": [
                boundary.code for boundary in plan.boundary_diagnostics
            ],
            "mapping_summary": _hybrid_mapping_summary(program),
            "timeline_summary": _hybrid_timeline_summary(program),
            "measurement_boundary_summary": (
                _hybrid_measurement_boundary_summary(program, plan)
            ),
            "blocked_reason_categories": sorted(
                {
                    str(diagnostic.metadata.get("reason_category", "hybrid"))
                    for diagnostic in diagnostics
                }
            ),
            "compiler_invoked": False,
            "package_builder_invoked": False,
            "backend_invoked": False,
            "safe_subset_simulation_allowed": True,
        },
    )


def diagnose_hybrid_execution_support(
    program: HybridProgramIR,
    *,
    capability: str = "execution",
) -> tuple[DiagnosticsIR, ...]:
    """Return diagnostics that hybrid execution is currently unsupported."""
    validation = program.validate_ir_only()
    blocking = [
        diagnostic
        for diagnostic in validation
        if diagnostic.severity in {"warning", "error"}
    ]
    if blocking:
        return tuple(blocking)
    code = {
        "backend": "HYBRID_BACKEND_UNSUPPORTED",
        "execution": "HYBRID_EXECUTION_UNSUPPORTED",
        "simulation": "HYBRID_SIMULATION_UNSUPPORTED",
    }.get(capability, "HYBRID_CAPABILITY_UNSUPPORTED")
    return (
        DiagnosticsIR(
            diagnostic_id=f"hybrid.{code.lower()}",
            stage="validation",
            severity="warning",
            code=code,
            message=(
                "Hybrid programs are supported as serializable IR only; "
                f"{capability} is not implemented in this release."
            ),
            object_path="hybrid_program",
            suggestion=(
                "Use the analog AHS path for executable local workflows, or "
                "keep this HybridProgramIR as an architecture-level contract."
            ),
            metadata={
                "program_id": program.program_id,
                "capability": capability,
                "validation_mode": program.validation_mode,
            },
        ),
    )


def _hybrid_backend_blocking_diagnostics(
    program: HybridProgramIR,
    plan: HybridSimulationPlanIR,
) -> tuple[DiagnosticsIR, ...]:
    diagnostics: list[DiagnosticsIR] = []
    validation_blockers = [
        diagnostic
        for diagnostic in program.validate_ir_only()
        if diagnostic.severity in {"warning", "error"}
    ]
    diagnostics.extend(validation_blockers)
    diagnostics.append(_hybrid_mapping_backend_diagnostic(program, plan))
    diagnostics.append(_hybrid_timeline_backend_diagnostic(program, plan))
    diagnostics.append(_hybrid_measurement_backend_diagnostic(program, plan))
    for boundary in plan.boundary_diagnostics:
        if boundary.code != "HYBRID_STATE_HANDOFF_UNSUPPORTED":
            continue
        diagnostics.append(
            DiagnosticsIR(
                diagnostic_id=f"hybrid.backend.{boundary.code.lower()}",
                stage="validation",
                severity="error",
                code=boundary.code,
                message=(
                    "Hybrid backend execution is blocked because analog/digital "
                    "state handoff is not implemented."
                ),
                object_path=boundary.object_path,
                suggestion=(
                    "Use plan-only review or an explicitly supported safe local "
                    "simulation subset; do not build an execution package."
                ),
                metadata={
                    **boundary.metadata,
                    "program_id": program.program_id,
                    "plan_id": plan.plan_id,
                    "boundary_id": boundary.boundary_id,
                    "reason_category": "handoff",
                    "blocked_boundary": "analog_digital_state_handoff",
                    "left_block_id": boundary.left_block_id,
                    "right_block_id": boundary.right_block_id,
                    "requested_mode": "backend_run",
                    "full_daqc_state_handoff": False,
                    "package_built": False,
                    "backend_submitted": False,
                },
            )
        )
    diagnostics.append(
        DiagnosticsIR(
            diagnostic_id="hybrid.backend.execution_unsupported",
            stage="validation",
            severity="error",
            code="HYBRID_BACKEND_EXECUTION_BLOCKED",
            message=(
                "Hybrid backend execution is blocked in this release; full DAQC "
                "lowering and arbitrary state handoff are not implemented."
            ),
            object_path="hybrid_program",
            suggestion=(
                "Keep the hybrid program as a plan artifact or use a supported "
                "single-kind execution path."
            ),
            metadata={
                "program_id": program.program_id,
                "plan_id": plan.plan_id,
                "reason_category": "backend",
                "blocked_boundary": "hybrid_backend_execution",
                "full_daqc_state_handoff": False,
                "package_built": False,
                "backend_submitted": False,
            },
        )
    )
    return tuple(diagnostics)


def _hybrid_execution_boundary(
    program: HybridProgramIR,
    *,
    blocking: tuple[DiagnosticsIR, ...],
    warning_or_error_boundaries: tuple[HybridBoundaryDiagnosticIR, ...],
) -> dict[str, Any]:
    block_types = tuple(block.block_type for block in program.blocks)
    has_digital = "digital" in block_types
    has_analog = "analog" in block_types
    has_measure = "measure" in block_types
    has_mixed_state_handoff = any(
        boundary.code == "HYBRID_STATE_HANDOFF_UNSUPPORTED"
        for boundary in warning_or_error_boundaries
    )
    invalid = bool(blocking) or any(
        boundary.status == "error" for boundary in warning_or_error_boundaries
    )
    digital_only_subset = has_digital and not has_analog
    analog_single_block_subset = (
        has_analog and not has_digital and not has_measure and len(program.blocks) == 1
    )
    local_executable_subset = (
        not invalid
        and not has_mixed_state_handoff
        and (digital_only_subset or analog_single_block_subset)
    )
    if invalid:
        boundary_kind = "invalid_plan"
    elif has_mixed_state_handoff:
        boundary_kind = "plan_only_mixed_handoff"
    elif local_executable_subset:
        boundary_kind = "local_executable_subset"
    else:
        boundary_kind = "plan_only_unsupported_shape"
    return {
        "boundary_kind": boundary_kind,
        "plan_only": True,
        "local_executable_subset": local_executable_subset,
        "digital_only_subset": digital_only_subset,
        "analog_single_block_subset": analog_single_block_subset,
        "mixed_analog_digital_state_handoff": has_mixed_state_handoff,
        "hybrid_backend_execution": "blocked",
        "full_daqc_state_handoff": False,
        "package_built": False,
        "backend_submitted": False,
    }


def _hybrid_mapping_backend_diagnostic(
    program: HybridProgramIR,
    plan: HybridSimulationPlanIR,
) -> DiagnosticsIR:
    summary = _hybrid_mapping_summary(program)
    return DiagnosticsIR(
        diagnostic_id="hybrid.backend.mapping_review_required",
        stage="validation",
        severity="error",
        code="HYBRID_MAPPING_REVIEW_REQUIRED",
        message=(
            "Hybrid backend execution is blocked until qubit/atom mapping "
            "handoff semantics are implemented."
        ),
        object_path="hybrid_program.mapping",
        suggestion=(
            "Review mapping as plan metadata only; do not construct a backend "
            "execution package."
        ),
        metadata={
            **summary,
            "program_id": program.program_id,
            "plan_id": plan.plan_id,
            "reason_category": "mapping",
            "package_built": False,
            "backend_submitted": False,
        },
    )


def _hybrid_timeline_backend_diagnostic(
    program: HybridProgramIR,
    plan: HybridSimulationPlanIR,
) -> DiagnosticsIR:
    summary = _hybrid_timeline_summary(program)
    return DiagnosticsIR(
        diagnostic_id="hybrid.backend.timeline_review_required",
        stage="validation",
        severity="error",
        code="HYBRID_TIMELINE_REVIEW_REQUIRED",
        message=(
            "Hybrid backend execution is blocked until mixed analog/digital "
            "timeline lowering is implemented."
        ),
        object_path="hybrid_program.blocks",
        suggestion="Use the timeline as a plan-only review artifact.",
        metadata={
            **summary,
            "program_id": program.program_id,
            "plan_id": plan.plan_id,
            "reason_category": "timeline",
            "full_daqc_state_handoff": False,
            "package_built": False,
            "backend_submitted": False,
        },
    )


def _hybrid_measurement_backend_diagnostic(
    program: HybridProgramIR,
    plan: HybridSimulationPlanIR,
) -> DiagnosticsIR:
    summary = _hybrid_measurement_boundary_summary(program, plan)
    return DiagnosticsIR(
        diagnostic_id="hybrid.backend.measurement_boundary_review_required",
        stage="validation",
        severity="error",
        code="HYBRID_MEASUREMENT_BOUNDARY_REVIEW_REQUIRED",
        message=(
            "Hybrid backend execution is blocked until measurement boundary "
            "handoff and readout routing are implemented."
        ),
        object_path="hybrid_program.blocks",
        suggestion="Keep measurement boundary information in the plan artifact.",
        metadata={
            **summary,
            "program_id": program.program_id,
            "plan_id": plan.plan_id,
            "reason_category": "measurement",
            "package_built": False,
            "backend_submitted": False,
        },
    )


def _block_state_summary(block: HybridBlockIR) -> HybridBlockStateSummaryIR:
    if isinstance(block, DigitalBlockIR):
        input_state: HybridStateKind = "state_vector"
        output_state: HybridStateKind = "state_vector"
        metadata = {
            "qubits": list(block.circuit.qubits),
            "gate_count": len(block.circuit.gates),
        }
    elif isinstance(block, AnalogBlockIR):
        input_state = "analog_state_vector"
        output_state = "analog_state_vector"
        metadata = {
            "atom_count": len(
                tuple(site for site in block.program.register.sites if site.is_active)
            ),
            "program_hash": block.program.stable_hash(),
        }
    else:
        input_state = "state_vector"
        output_state = "measurement_samples"
        metadata = {
            "measurement_count": len(block.measurements),
            "measurement_keys": [measurement.key for measurement in block.measurements],
        }
    return HybridBlockStateSummaryIR(
        block_id=block.block_id,
        block_type=block.block_type,
        input_state_kind=input_state,
        output_state_kind=output_state,
        start_time=block.start_time,
        duration=block.duration,
        time_unit=block.time_unit,
        metadata=metadata,
    )


def _hybrid_mapping_summary(program: HybridProgramIR) -> dict[str, Any]:
    digital_qubits: set[str] = set()
    measured_qubits: set[str] = set()
    atom_count = 0
    for block in program.blocks:
        if isinstance(block, DigitalBlockIR):
            digital_qubits.update(str(qubit) for qubit in block.circuit.qubits)
        if isinstance(block, MeasureBlockIR):
            for measurement in block.measurements:
                measured_qubits.update(str(target) for target in measurement.targets)
        if isinstance(block, AnalogBlockIR):
            atom_count += len(
                tuple(site for site in block.program.register.sites if site.is_active)
            )
    mapped_qubits = set(program.mapping)
    return {
        "mapping": dict(program.mapping),
        "mapping_count": len(program.mapping),
        "digital_qubits": sorted(digital_qubits),
        "mapped_qubits": sorted(mapped_qubits),
        "unmapped_digital_qubits": sorted(digital_qubits - mapped_qubits),
        "measured_qubits": sorted(measured_qubits),
        "unmapped_measured_qubits": sorted(measured_qubits - mapped_qubits),
        "analog_atom_count": atom_count,
        "mapping_required_for_backend": True,
    }


def _hybrid_timeline_summary(program: HybridProgramIR) -> dict[str, Any]:
    timeline = program.block_timeline()
    timed_blocks = [
        block
        for block in timeline
        if block.get("start_time") is not None or block.get("duration") is not None
    ]
    total_duration = None
    stops: list[float] = []
    for block in timeline:
        start = block.get("start_time")
        duration = block.get("duration")
        if isinstance(start, (int, float)) and isinstance(duration, (int, float)):
            stops.append(float(start) + float(duration))
    if stops:
        total_duration = max(stops)
    return {
        "block_count": len(program.blocks),
        "timeline": list(timeline),
        "timed_block_count": len(timed_blocks),
        "total_duration": total_duration,
        "timeline_lowering_supported": False,
        "full_daqc_state_handoff": False,
    }


def _hybrid_measurement_boundary_summary(
    program: HybridProgramIR,
    plan: HybridSimulationPlanIR,
) -> dict[str, Any]:
    measure_blocks = [
        block for block in program.blocks if isinstance(block, MeasureBlockIR)
    ]
    measurement_keys = [
        measurement.key
        for block in measure_blocks
        for measurement in block.measurements
    ]
    measurement_targets = sorted(
        {
            str(target)
            for block in measure_blocks
            for measurement in block.measurements
            for target in measurement.targets
        }
    )
    terminal_measurement = bool(program.blocks) and isinstance(
        program.blocks[-1],
        MeasureBlockIR,
    )
    return {
        "measurement_block_count": len(measure_blocks),
        "measurement_keys": measurement_keys,
        "measurement_targets": measurement_targets,
        "terminal_measurement": terminal_measurement,
        "measurement_boundary_codes": [
            boundary.code
            for boundary in plan.boundary_diagnostics
            if boundary.right_block_type == "measure"
            or boundary.left_block_type == "measure"
        ],
        "measurement_boundary_supported_for_backend": False,
    }


def _boundary_diagnostics(
    blocks: tuple[HybridBlockIR, ...],
) -> tuple[HybridBoundaryDiagnosticIR, ...]:
    diagnostics: list[HybridBoundaryDiagnosticIR] = []
    for index, (left, right) in enumerate(zip(blocks, blocks[1:])):
        diagnostics.append(_boundary_diagnostic(index, left, right))
    return tuple(diagnostics)


def _boundary_diagnostic(
    index: int,
    left: HybridBlockIR,
    right: HybridBlockIR,
) -> HybridBoundaryDiagnosticIR:
    boundary_id = f"boundary.{index}.{left.block_id}.{right.block_id}"
    if left.block_type == "measure":
        return _plan_boundary(
            boundary_id=boundary_id,
            left=left,
            right=right,
            status="error",
            code="HYBRID_BOUNDARY_AFTER_MEASURE_INVALID",
            message="Measure blocks must terminate the hybrid sequence.",
            suggestion="Move measurement to the terminal block.",
        )
    if (
        left.block_type in {"digital", "analog"}
        and right.block_type in {"digital", "analog"}
        and left.block_type != right.block_type
    ):
        return _plan_boundary(
            boundary_id=boundary_id,
            left=left,
            right=right,
            status="warning",
            code="HYBRID_STATE_HANDOFF_UNSUPPORTED",
            message=(
                "Analog-digital state handoff is not executable in this release."
            ),
            suggestion=(
                "Use this plan as a review artifact; do not treat it as DAQC "
                "execution."
            ),
        )
    if right.block_type == "measure":
        return _plan_boundary(
            boundary_id=boundary_id,
            left=left,
            right=right,
            status="ok",
            code="HYBRID_MEASUREMENT_TERMINATION_OK",
            message="Terminal measurement boundary is plan-compatible.",
        )
    return _plan_boundary(
        boundary_id=boundary_id,
        left=left,
        right=right,
        status="ok",
        code="HYBRID_BOUNDARY_PLAN_COMPATIBLE",
        message="Hybrid block boundary is plan-compatible.",
    )


def _plan_boundary(
    *,
    boundary_id: str,
    left: HybridBlockIR,
    right: HybridBlockIR,
    status: HybridBoundaryStatus,
    code: str,
    message: str,
    suggestion: str | None = None,
) -> HybridBoundaryDiagnosticIR:
    left_state = _block_state_summary(left)
    right_state = _block_state_summary(right)
    return HybridBoundaryDiagnosticIR(
        boundary_id=boundary_id,
        left_block_id=left.block_id,
        right_block_id=right.block_id,
        left_block_type=left.block_type,
        right_block_type=right.block_type,
        status=status,
        code=code,
        message=message,
        object_path=f"hybrid_program.boundaries.{boundary_id}",
        suggestion=suggestion,
        metadata={
            "left_output_state_kind": left_state.output_state_kind,
            "right_input_state_kind": right_state.input_state_kind,
        },
    )


def _block_from_dict(data: dict[str, Any]) -> HybridBlockIR:
    block_type = data.get("block_type")
    if block_type == "digital":
        return DigitalBlockIR.from_dict(data)
    if block_type == "analog":
        return AnalogBlockIR.from_dict(data)
    if block_type == "measure":
        return MeasureBlockIR.from_dict(data)
    raise ValueError(f"Unsupported hybrid block_type: {block_type!r}")


def _validate_mapping(program: HybridProgramIR) -> tuple[DiagnosticsIR, ...]:
    diagnostics: list[DiagnosticsIR] = []
    if not program.mapping:
        diagnostics.append(
            _hybrid_diagnostic(
                code="HYBRID_MAPPING_MISSING",
                message="Hybrid programs require shared atom/qubit mapping metadata.",
                object_path="hybrid_program.mapping",
                severity="error",
            )
        )
    for qubit, atom in program.mapping.items():
        if not qubit or not atom:
            diagnostics.append(
                _hybrid_diagnostic(
                    code="HYBRID_MAPPING_INVALID",
                    message="Hybrid mapping keys and values must be non-empty.",
                    object_path="hybrid_program.mapping",
                    severity="error",
                )
            )
    return tuple(diagnostics)


def _validate_block_sequence(
    blocks: tuple[HybridBlockIR, ...],
) -> tuple[DiagnosticsIR, ...]:
    diagnostics: list[DiagnosticsIR] = []
    seen_measure = False
    previous_start: float | None = None
    for index, block in enumerate(blocks):
        object_path = f"hybrid_program.blocks[{index}]"
        if seen_measure:
            diagnostics.append(
                _hybrid_diagnostic(
                    code="HYBRID_BLOCK_AFTER_MEASURE",
                    message="Measure blocks must terminate the hybrid sequence.",
                    object_path=object_path,
                    severity="error",
                )
            )
        if block.block_type == "measure":
            seen_measure = True
        if block.duration is not None and block.duration < 0.0:
            diagnostics.append(
                _hybrid_diagnostic(
                    code="HYBRID_BLOCK_TIMING_INVALID",
                    message="Hybrid block duration must be non-negative.",
                    object_path=f"{object_path}.duration",
                    severity="error",
                )
            )
        if block.start_time is not None:
            if block.start_time < 0.0:
                diagnostics.append(
                    _hybrid_diagnostic(
                        code="HYBRID_BLOCK_TIMING_INVALID",
                        message="Hybrid block start time must be non-negative.",
                        object_path=f"{object_path}.start_time",
                        severity="error",
                    )
                )
            if previous_start is not None and block.start_time < previous_start:
                diagnostics.append(
                    _hybrid_diagnostic(
                        code="HYBRID_BLOCK_SEQUENCE_NONLINEAR",
                        message="Hybrid block start times must be non-decreasing.",
                        object_path=f"{object_path}.start_time",
                        severity="error",
                    )
                )
            previous_start = block.start_time
    return tuple(diagnostics)


def _validate_block_payloads(
    blocks: tuple[HybridBlockIR, ...],
) -> tuple[DiagnosticsIR, ...]:
    diagnostics: list[DiagnosticsIR] = []
    for index, block in enumerate(blocks):
        object_path = f"hybrid_program.blocks[{index}]"
        if isinstance(block, DigitalBlockIR):
            diagnostics.extend(
                _with_path_prefix(
                    block.circuit.validate_ir_only(),
                    f"{object_path}.circuit",
                )
            )
        if isinstance(block, AnalogBlockIR) and block.program.program_type != "analog":
            diagnostics.append(
                _hybrid_diagnostic(
                    code="HYBRID_ANALOG_BLOCK_INVALID",
                    message="Analog blocks must wrap analog ProgramIR objects.",
                    object_path=f"{object_path}.program",
                    severity="error",
                )
            )
        if isinstance(block, MeasureBlockIR) and not block.measurements:
            diagnostics.append(
                _hybrid_diagnostic(
                    code="HYBRID_MEASURE_BLOCK_EMPTY",
                    message="Measure blocks require at least one measurement.",
                    object_path=f"{object_path}.measurements",
                    severity="error",
                )
            )
    return tuple(
        diagnostic
        for diagnostic in diagnostics
        if diagnostic.code != "DIGITAL_IR_VALID"
    )


def _with_path_prefix(
    diagnostics: tuple[DiagnosticsIR, ...],
    prefix: str,
) -> tuple[DiagnosticsIR, ...]:
    updated: list[DiagnosticsIR] = []
    for diagnostic in diagnostics:
        object_path = diagnostic.object_path
        updated.append(
            DiagnosticsIR(
                diagnostic_id=f"hybrid.{diagnostic.diagnostic_id}",
                stage=diagnostic.stage,
                severity=diagnostic.severity,
                code=diagnostic.code,
                message=diagnostic.message,
                object_path=(
                    prefix if object_path is None else f"{prefix}.{object_path}"
                ),
                suggestion=diagnostic.suggestion,
                metadata=dict(diagnostic.metadata),
            )
        )
    return tuple(updated)


def _hybrid_diagnostic(
    *,
    code: str,
    message: str,
    object_path: str,
    severity: Literal["info", "warning", "error"] = "warning",
    metadata: dict[str, Any] | None = None,
) -> DiagnosticsIR:
    return DiagnosticsIR(
        diagnostic_id=f"hybrid.{code.lower()}",
        stage="validation",
        severity=severity,
        code=code,
        message=message,
        object_path=object_path,
        suggestion="Fix the HybridProgramIR shape before using it as a contract.",
        metadata={} if metadata is None else dict(metadata),
    )
