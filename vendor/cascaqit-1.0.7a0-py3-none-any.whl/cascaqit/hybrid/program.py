"""User-facing immutable hybrid program orchestration model."""

from __future__ import annotations

import copy
import hashlib
import json
from collections.abc import Iterable, Mapping
from dataclasses import dataclass, field, replace
from types import MappingProxyType
from typing import TYPE_CHECKING, Any, NoReturn

from cascaqit.hybrid.diagnostics import (
    ORCHESTRATION_SCHEMA_VERSION,
    OrchestrationDiagnosticIR,
)
from cascaqit.hybrid.orchestration import BlockDependency, HybridProgramBlock
from cascaqit.native_ir.base import IRMixin, canonicalize, stable_json
from cascaqit.parameters import (
    Parameter,
    ParameterBindIR,
    ParameterManager,
    ParameterTargetIR,
)
from cascaqit.syntax import (
    SemanticArgumentHIR,
    SemanticLogicalResourceHIR,
    SemanticProgramHIR,
    SourceMap,
    SourceMapEntry,
    SourceSpan,
)

if TYPE_CHECKING:
    from cascaqit.analog import AHSProgram
    from cascaqit.digital import Circuit, DigitalProgramIR
    from cascaqit.hybrid.compiler import HybridCompileResult
    from cascaqit.hybrid.models import HybridProgramIR
    from cascaqit.native_ir import ProgramIR
    from cascaqit.parameters import ParameterScan
    from cascaqit.simulators.local_hybrid import (
        LocalExecutionBundleResult,
        LocalHybridExecutionBuilder,
        LocalProgramFactory,
    )
    from cascaqit.simulators.planning import SimulationOptions

__all__ = ["HybridAnalysisResult", "HybridProgram"]


def _require_identifier(value: str, *, field_name: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field_name} must be a non-empty string.")


@dataclass(frozen=True)
class HybridAnalysisResult(IRMixin):
    """Analysis view shared by fluent and syntax/HIR Hybrid programs."""

    program_hash: str
    parameter_schema_hash: str
    diagnostics: tuple[OrchestrationDiagnosticIR, ...] = ()
    ast: object | None = None
    hir: SemanticProgramHIR | None = None
    schema_version: str = ORCHESTRATION_SCHEMA_VERSION

    @property
    def has_errors(self) -> bool:
        return any(item.severity == "error" for item in self.diagnostics)


@dataclass(frozen=True)
class HybridProgram(IRMixin):
    """One immutable user API for fluent, syntax/HIR, and executable Hybrid work."""

    program_id: str
    syntax_hash: str = "0" * 64
    blocks: tuple[HybridProgramBlock, ...] = ()
    dependencies: tuple[BlockDependency, ...] = ()
    source_map: SourceMap = field(default_factory=SourceMap)
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = ORCHESTRATION_SCHEMA_VERSION
    _payloads: Mapping[str, object] = field(
        default_factory=dict,
        repr=False,
        compare=False,
    )
    _hir: SemanticProgramHIR | None = field(
        default=None,
        repr=False,
        compare=False,
    )

    def __post_init__(self) -> None:
        _require_identifier(self.program_id, field_name="program_id")
        if len(self.syntax_hash) != 64 or any(
            character not in "0123456789abcdef" for character in self.syntax_hash
        ):
            raise ValueError("syntax_hash must be a lowercase SHA-256 hex digest.")
        if any(not isinstance(block, HybridProgramBlock) for block in self.blocks):
            raise TypeError("blocks must contain HybridProgramBlock values.")
        if any(
            not isinstance(dependency, BlockDependency)
            for dependency in self.dependencies
        ):
            raise TypeError("dependencies must contain BlockDependency values.")
        if not isinstance(self.source_map, SourceMap):
            raise TypeError("source_map must be SourceMap.")
        if not isinstance(self._payloads, Mapping):
            raise TypeError("payloads must be a mapping.")
        unknown_payloads = sorted(
            set(self._payloads) - {block.block_id for block in self.blocks}
        )
        if unknown_payloads:
            raise ValueError(
                "payloads reference unknown blocks: " + ", ".join(unknown_payloads)
            )
        object.__setattr__(self, "_payloads", MappingProxyType(dict(self._payloads)))
        if self._hir is not None and not isinstance(self._hir, SemanticProgramHIR):
            raise TypeError("hir must be SemanticProgramHIR or None.")

    @classmethod
    def from_hir(cls, hir: SemanticProgramHIR) -> HybridProgram:
        """Create a user program from successfully analyzed semantic HIR."""
        if not isinstance(hir, SemanticProgramHIR):
            raise TypeError("hir must be SemanticProgramHIR.")
        declarations = {block.node_id: block for block in hir.blocks}
        blocks: list[HybridProgramBlock] = []
        for invocation in hir.invocations:
            declaration = declarations.get(invocation.block_node_id)
            if declaration is None:
                raise ValueError(
                    f"invocation references unknown block '{invocation.block_node_id}'."
                )
            blocks.append(HybridProgramBlock.from_hir(declaration, invocation))
        return cls(
            program_id=hir.program_id,
            syntax_hash=hir.syntax_hash,
            blocks=tuple(blocks),
            source_map=hir.source_map,
            metadata={
                "hir_node_id": hir.node_id,
                "hir_syntax_node_id": hir.syntax_node_id,
                "hir_hash": hir.stable_hash(),
            },
            _hir=hir,
        )

    @property
    def parameters(self) -> ParameterManager:
        """Return the automatically collected canonical parameter view."""
        manager = ParameterManager()
        declarations: dict[str, Parameter] = {}
        for block in self.blocks:
            payload = self._payloads.get(block.block_id)
            for parameter in _payload_parameters(payload):
                previous = declarations.get(parameter.name)
                if previous is not None and previous != parameter:
                    raise ValueError(
                        f"parameter '{parameter.name}' has conflicting declarations."
                    )
                if previous is None:
                    manager = manager.declare(parameter)
                    declarations[parameter.name] = parameter
                manager = manager.map_target(
                    ParameterTargetIR(
                        target_id=f"target.{block.block_id}.{parameter.name}",
                        parameter_name=parameter.name,
                        block_id=block.block_id,
                        argument_name=parameter.name,
                        dtype=parameter.dtype,
                        unit=parameter.unit,
                    )
                )
        return manager

    def digital(
        self,
        name: str,
        circuit: Circuit | DigitalProgramIR,
        *,
        mapping: Mapping[str, str] | None = None,
    ) -> HybridProgram:
        """Append one typed Digital payload."""
        return self._append_payload("digital", name, circuit, mapping=mapping)

    def analog(
        self,
        name: str,
        program: AHSProgram | ProgramIR,
        *,
        mapping: Mapping[str, str] | None = None,
    ) -> HybridProgram:
        """Append one typed Analog payload."""
        return self._append_payload("analog", name, program, mapping=mapping)

    def measure_all(
        self,
        *,
        name: str = "measure",
        key: str = "result",
    ) -> HybridProgram:
        """Append terminal computational-basis measurement for all logical ids."""
        _require_identifier(name, field_name="name")
        _require_identifier(key, field_name="key")
        if any(block.block_kind == "measurement" for block in self.blocks):
            raise ValueError("HybridProgram supports one terminal measurement.")
        logical_ids = _program_logical_ids(self.blocks)
        if not logical_ids:
            raise ValueError("measure_all() requires a Digital or Analog block.")
        index = len(self.blocks)
        block_id = f"block.{index:04d}.{name}"
        resources = tuple(
            _logical_resource(block_id, logical_id, "qubit")
            for logical_id in logical_ids
        )
        inherited_mapping: dict[str, str] = {}
        for existing in self.blocks:
            inherited_mapping.update(existing.mapping)
        block = HybridProgramBlock(
            block_id=block_id,
            declaration_node_id=f"declaration.{block_id}",
            invocation_node_id=block_id,
            block_name=name,
            block_kind="measurement",
            logical_resources=resources,
            mapping={
                logical_id: inherited_mapping.get(logical_id, logical_id)
                for logical_id in logical_ids
            },
            metadata={"payload_owned": True, "measurement_key": key},
        )
        return self._append_block(block)

    def with_payload(self, block_name_or_id: str, payload: object) -> HybridProgram:
        """Attach a typed payload to one existing HIR block."""
        _require_identifier(block_name_or_id, field_name="block_name_or_id")
        block_id = (
            block_name_or_id
            if block_name_or_id in {block.block_id for block in self.blocks}
            else self.resolve_block_id(block_name_or_id)
        )
        block = next(item for item in self.blocks if item.block_id == block_id)
        _validate_payload_kind(block.block_kind, payload)
        snapshot = _snapshot_payload(payload)
        arguments = _merge_parameter_arguments(block, _payload_parameters(snapshot))
        updated = replace(
            block,
            arguments=arguments,
            metadata={
                **block.metadata,
                "payload_owned": True,
                "payload_hash": _payload_declaration_hash(snapshot),
                "payload_parameter_names": [
                    parameter.name for parameter in _payload_parameters(snapshot)
                ],
            },
        )
        payloads = {**self._payloads, block_id: snapshot}
        return replace(
            self,
            blocks=tuple(
                updated if item.block_id == block_id else item
                for item in self.blocks
            ),
            _payloads=payloads,
        )

    def payload(self, block_name_or_id: str) -> object:
        """Return the typed payload owned by one block."""
        block_id = (
            block_name_or_id
            if block_name_or_id in self._payloads
            else self.resolve_block_id(block_name_or_id)
        )
        try:
            return _snapshot_payload(self._payloads[block_id])
        except KeyError as exc:
            raise ValueError(f"block '{block_name_or_id}' has no payload.") from exc

    def bind(self, values: Mapping[str, bool | int | float]) -> HybridProgram:
        """Return a program with canonical values projected into every payload."""
        manager = self.parameters
        binding = manager.bind(values, bind_id=f"bind.{self.program_id}")
        if binding.bind_set is None:
            from cascaqit.exceptions import ProgramValidationError

            raise ProgramValidationError(
                "Hybrid parameter binding failed.",
                code="HYBRID_PARAMETER_BIND_INVALID",
                stage="compile",
                object_path="hybrid.parameters",
                metadata={
                    "diagnostic_codes": [item.code for item in binding.diagnostics],
                    "parameter_diagnostics": [
                        item.to_dict() for item in binding.diagnostics
                    ],
                },
            )
        return self._bind_set(binding.bind_set)

    def analyze(self) -> HybridAnalysisResult:
        """Return diagnostics plus retained HIR for advanced users."""
        manager = self.parameters
        return HybridAnalysisResult(
            program_hash=self.stable_hash(),
            parameter_schema_hash=manager.schema.stable_hash(),
            diagnostics=self.validate(),
            hir=self._hir,
        )

    def execution_builder(
        self,
        *,
        params: Mapping[str, bool | int | float] | None = None,
        shots: int = 1000,
        seed: int = 0,
        measurement_key: str | None = None,
        parameterized: bool = False,
    ) -> LocalHybridExecutionBuilder:
        """Create the advanced builder with all owned payloads attached."""
        from cascaqit.exceptions import ProgramValidationError
        from cascaqit.simulators.local_hybrid import LocalHybridExecutionBuilder

        if parameterized and params is not None:
            raise ValueError("parameterized builder cannot also receive params.")
        source = self if parameterized else self._bind_defaults_or_values(params)
        compiled = source.compile()
        if compiled.plan is None:
            raise ProgramValidationError(
                "Hybrid program failed compile preflight.",
                code="HYBRID_COMPILE_INVALID",
                stage="compile",
                object_path="hybrid.program",
                metadata={
                    "diagnostic_codes": [item.code for item in compiled.diagnostics]
                },
                diagnostics=compiled.diagnostics,
            )
        builder = LocalHybridExecutionBuilder(compiled.plan)
        for step in compiled.plan.steps:
            block = next(
                item for item in source.blocks if item.block_id == step.block_id
            )
            if step.kernel_kind == "measurement":
                builder.measure(
                    step.block_id,
                    targets=tuple(step.mapping),
                    shots=shots,
                    seed=seed,
                    key=measurement_key
                    or str(block.metadata.get("measurement_key", "result")),
                )
                continue
            payload = source._payloads.get(step.block_id)
            if payload is None:
                raise ProgramValidationError(
                    f"Hybrid block '{step.block_id}' has no payload.",
                    code="HYBRID_PAYLOAD_MISSING",
                    stage="compile",
                    object_path=f"hybrid.blocks.{step.block_id}.payload",
                )
            if parameterized and _payload_parameters(payload):
                factory = _payload_factory(payload)
                if step.kernel_kind == "digital":
                    builder.bind_digital_factory(step.block_id, factory)
                else:
                    builder.bind_analog_factory(step.block_id, factory)
            elif step.kernel_kind == "digital":
                builder.bind_digital(step.block_id, payload)  # type: ignore[arg-type]
            else:
                builder.bind_analog(step.block_id, payload)  # type: ignore[arg-type]
        return builder

    def prepare(
        self,
        *,
        params: Mapping[str, bool | int | float] | None = None,
        shots: int = 1000,
        seed: int = 0,
        measurement_key: str | None = None,
        bundle_id: str | None = None,
    ) -> LocalExecutionBundleResult:
        """Compile and build one local execution bundle."""
        return self.execution_builder(
            params=params,
            shots=shots,
            seed=seed,
            measurement_key=measurement_key,
        ).build(bundle_id=bundle_id)

    def run(
        self,
        *,
        backend: object | None = None,
        params: Mapping[str, bool | int | float] | None = None,
        sweep: ParameterScan | None = None,
        noise: object | None = None,
        options: SimulationOptions | None = None,
        shots: int = 1000,
        seed: int | None = None,
    ) -> object:
        """Submit through the unified backend entrypoint.

        ``None`` means that the backend still owns seed resolution.  This keeps an
        explicitly configured ``SimulationOptions.seed`` from being shadowed by a
        facade default before planning and execution see the same root seed.
        """
        if backend is None:
            from cascaqit.simulators import LocalBackend

            backend = LocalBackend(seed=seed)
        run = getattr(backend, "run", None)
        if not callable(run):
            raise TypeError("backend must provide run().")
        return run(
            self,
            params=params,
            sweep=sweep,
            noise=noise,
            options=options,
            shots=shots,
            seed=seed,
        )

    def add(
        self,
        block: HybridProgramBlock,
        *,
        index: int | None = None,
    ) -> HybridProgram:
        """Return a program with one block inserted at the requested index."""
        if not isinstance(block, HybridProgramBlock):
            raise TypeError("block must be HybridProgramBlock.")
        blocks = list(self.blocks)
        if index is None:
            blocks.append(block)
        else:
            if index < 0 or index > len(blocks):
                raise IndexError("index is outside the insertion range.")
            blocks.insert(index, block)
        return replace(self, blocks=tuple(blocks))

    def _append_payload(
        self,
        block_kind: str,
        name: str,
        payload: object,
        *,
        mapping: Mapping[str, str] | None,
    ) -> HybridProgram:
        _require_identifier(name, field_name="name")
        if any(block.block_kind == "measurement" for block in self.blocks):
            raise ValueError("Digital and Analog blocks cannot follow measurement.")
        _validate_payload_kind(block_kind, payload)
        snapshot = _snapshot_payload(payload)
        index = len(self.blocks)
        block_id = f"block.{index:04d}.{name}"
        logical_ids = _payload_logical_ids(snapshot)
        resource_kind = "qubit" if block_kind == "digital" else "atom"
        resources = tuple(
            _logical_resource(block_id, logical_id, resource_kind)
            for logical_id in logical_ids
        )
        resolved_mapping = {logical_id: logical_id for logical_id in logical_ids}
        if mapping is not None:
            if not isinstance(mapping, Mapping):
                raise TypeError("mapping must be a mapping or None.")
            unknown = sorted(set(mapping) - set(logical_ids))
            if unknown:
                raise ValueError(
                    "mapping contains unknown logical ids: " + ", ".join(unknown)
                )
            resolved_mapping.update(
                {str(logical_id): str(target) for logical_id, target in mapping.items()}
            )
        block = HybridProgramBlock(
            block_id=block_id,
            declaration_node_id=f"declaration.{block_id}",
            invocation_node_id=block_id,
            block_name=name,
            block_kind=block_kind,  # type: ignore[arg-type]
            arguments=_parameter_arguments(block_id, _payload_parameters(snapshot)),
            logical_resources=resources,
            mapping=resolved_mapping,
            metadata={
                "payload_owned": True,
                "payload_hash": _payload_declaration_hash(snapshot),
                "payload_parameter_names": [
                    parameter.name for parameter in _payload_parameters(snapshot)
                ],
            },
        )
        return self._append_block(block, payload=snapshot)

    def _append_block(
        self,
        block: HybridProgramBlock,
        *,
        payload: object | None = None,
    ) -> HybridProgram:
        payloads = dict(self._payloads)
        if payload is not None:
            payloads[block.block_id] = payload
        return replace(self, blocks=(*self.blocks, block), _payloads=payloads)

    def _bind_set(self, bind_set: ParameterBindIR) -> HybridProgram:
        if not isinstance(bind_set, ParameterBindIR):
            raise TypeError("bind_set must be ParameterBindIR.")
        if bind_set.parameter_schema_hash != self.parameters.schema.stable_hash():
            raise ValueError("bind_set does not match this HybridProgram schema.")
        payloads: dict[str, object] = {}
        blocks: list[HybridProgramBlock] = []
        for block in self.blocks:
            payload = self._payloads.get(block.block_id)
            bound_payload = _bind_payload(payload, bind_set)
            if bound_payload is not None:
                payloads[block.block_id] = bound_payload
            arguments = tuple(
                _bound_argument(argument, bind_set)
                if argument.name in bind_set.values
                else argument
                for argument in block.arguments
            )
            metadata = dict(block.metadata)
            if bound_payload is not None:
                metadata["payload_hash"] = _payload_declaration_hash(bound_payload)
                metadata["parameter_bind_hash"] = bind_set.parameter_bind_hash
            blocks.append(replace(block, arguments=arguments, metadata=metadata))
        return replace(self, blocks=tuple(blocks), _payloads=payloads)

    def _bind_defaults_or_values(
        self,
        values: Mapping[str, bool | int | float] | None,
    ) -> HybridProgram:
        if not self.parameters.schema.parameters:
            if values:
                raise ValueError("program has no parameters to bind.")
            return self
        if all(
            argument.binding_state != "unbound"
            for block in self.blocks
            for argument in block.arguments
        ):
            if values:
                raise ValueError("program is already bound; params must be omitted.")
            return self
        binding = self.parameters.bind(
            {} if values is None else values,
            bind_id=f"bind.{self.program_id}",
        )
        if binding.bind_set is None:
            from cascaqit.exceptions import ProgramValidationError

            raise ProgramValidationError(
                "Hybrid parameter binding failed.",
                code="HYBRID_PARAMETER_BIND_INVALID",
                stage="compile",
                object_path="hybrid.parameters",
                metadata={
                    "diagnostic_codes": [item.code for item in binding.diagnostics],
                    "parameter_diagnostics": [
                        item.to_dict() for item in binding.diagnostics
                    ],
                },
            )
        return self._bind_set(binding.bind_set)

    def block_ids(self, block_name: str) -> tuple[str, ...]:
        """Return invocation ids for a declared block name in program order."""
        _require_identifier(block_name, field_name="block_name")
        return tuple(
            block.block_id for block in self.blocks if block.block_name == block_name
        )

    def resolve_block_id(self, block_name: str) -> str:
        """Return the unique invocation id for a block name."""
        matches = self.block_ids(block_name)
        if not matches:
            raise ValueError(f"unknown block name '{block_name}'.")
        if len(matches) > 1:
            raise ValueError(
                f"block name '{block_name}' is ambiguous across "
                f"{len(matches)} invocations; use an explicit block id."
            )
        return matches[0]

    def remove(self, block_id: str) -> HybridProgram:
        """Return a program without the identified block and its dependencies."""
        _require_identifier(block_id, field_name="block_id")
        if block_id not in {block.block_id for block in self.blocks}:
            raise ValueError(f"unknown block_id '{block_id}'.")
        return replace(
            self,
            blocks=tuple(block for block in self.blocks if block.block_id != block_id),
            dependencies=tuple(
                dependency
                for dependency in self.dependencies
                if block_id
                not in {dependency.source_block_id, dependency.target_block_id}
            ),
            _payloads={
                key: value for key, value in self._payloads.items() if key != block_id
            },
        )

    def compose(self, other: HybridProgram) -> HybridProgram:
        """Return a program formed by appending another program."""
        if not isinstance(other, HybridProgram):
            raise TypeError("other must be HybridProgram.")
        return replace(
            self,
            blocks=(*self.blocks, *other.blocks),
            dependencies=(*self.dependencies, *other.dependencies),
            source_map=_merge_source_maps(self.source_map, other.source_map),
            metadata={
                **self.metadata,
                "composed_program_ids": [*_composed_ids(self), other.program_id],
            },
            _payloads={**self._payloads, **other._payloads},
            _hir=None,
        )

    def reorder(self, block_id: str, new_index: int) -> HybridProgram:
        """Return a program with one block moved to a new position."""
        _require_identifier(block_id, field_name="block_id")
        if new_index < 0 or new_index >= len(self.blocks):
            raise IndexError("new_index is outside the block range.")
        blocks = list(self.blocks)
        try:
            current_index = next(
                index
                for index, block in enumerate(blocks)
                if block.block_id == block_id
            )
        except StopIteration as exc:
            raise ValueError(f"unknown block_id '{block_id}'.") from exc
        block = blocks.pop(current_index)
        blocks.insert(new_index, block)
        return replace(self, blocks=tuple(blocks))

    def set_execution_order(self, block_ids: Iterable[str]) -> HybridProgram:
        """Return a program ordered by an exact permutation of current block ids."""
        requested = tuple(block_ids)
        current = tuple(block.block_id for block in self.blocks)
        if len(requested) != len(current) or set(requested) != set(current):
            raise ValueError(
                "block_ids must be an exact permutation of program blocks."
            )
        by_id = {block.block_id: block for block in self.blocks}
        return replace(self, blocks=tuple(by_id[block_id] for block_id in requested))

    def add_dependency(self, dependency: BlockDependency) -> HybridProgram:
        """Return a program with one explicit typed dependency."""
        if not isinstance(dependency, BlockDependency):
            raise TypeError("dependency must be BlockDependency.")
        return replace(self, dependencies=(*self.dependencies, dependency))

    def validate(self) -> tuple[OrchestrationDiagnosticIR, ...]:
        """Return deterministic diagnostics without constructing a graph."""
        diagnostics: list[OrchestrationDiagnosticIR] = []
        diagnostics.extend(_validate_blocks(self.blocks))
        diagnostics.extend(_validate_dependencies(self.blocks, self.dependencies))
        diagnostics.extend(_validate_mapping_continuity(self.blocks))
        diagnostics.extend(_validate_measurement_lifecycle(self.blocks))
        return tuple(diagnostics)

    def compile(
        self,
        *,
        allowed_capabilities: Iterable[str] | None = None,
    ) -> HybridCompileResult:
        """Compile this program to a graph and non-executable local plan."""
        from cascaqit.hybrid.compiler import compile_hybrid_program

        return compile_hybrid_program(
            self,
            allowed_capabilities=allowed_capabilities,
        )

    def to_ir(self) -> HybridProgramIR:
        """Export one fully bound HybridProgramIR execution boundary."""
        from cascaqit.digital import Circuit, DigitalMeasurementIR, DigitalProgramIR
        from cascaqit.hybrid.models import (
            AnalogBlockIR,
            DigitalBlockIR,
            HybridProgramIR,
            MeasureBlockIR,
        )
        from cascaqit.native_ir import ProgramIR

        blocks: list[DigitalBlockIR | AnalogBlockIR | MeasureBlockIR] = []
        for block in self.blocks:
            if block.block_kind == "measurement":
                key = str(block.metadata.get("measurement_key", "result"))
                blocks.append(
                    MeasureBlockIR(
                        block_id=block.block_id,
                        measurements=(
                            DigitalMeasurementIR.measure(
                                tuple(block.mapping),
                                key=key,
                                measurement_id=f"measurement.{block.block_id}",
                            ),
                        ),
                        metadata=dict(block.metadata),
                    )
                )
                continue
            payload = self._payloads.get(block.block_id)
            if payload is None:
                _raise_payload_export_error(block.block_id, "missing")
            if isinstance(payload, Circuit):
                if not payload.is_bound:
                    _raise_payload_export_error(block.block_id, "unbound")
                digital = payload.to_program()
                if digital.circuit.measurements:
                    _raise_embedded_measurement_error(block.block_id, "Digital")
                blocks.append(
                    DigitalBlockIR(
                        block_id=block.block_id,
                        circuit=digital.circuit,
                        metadata=dict(block.metadata),
                    )
                )
            elif isinstance(payload, DigitalProgramIR):
                if payload.circuit.measurements:
                    _raise_embedded_measurement_error(block.block_id, "Digital")
                blocks.append(
                    DigitalBlockIR(
                        block_id=block.block_id,
                        circuit=payload.circuit,
                        metadata=dict(block.metadata),
                    )
                )
            elif isinstance(payload, ProgramIR):
                if payload.measurements:
                    _raise_embedded_measurement_error(block.block_id, "Analog")
                blocks.append(
                    AnalogBlockIR(
                        block_id=block.block_id,
                        program=payload,
                        metadata=dict(block.metadata),
                    )
                )
            else:
                from cascaqit.analog import AHSProgram

                if not isinstance(payload, AHSProgram):
                    _raise_payload_export_error(block.block_id, "unsupported")
                if not payload.is_bound:
                    _raise_payload_export_error(block.block_id, "unbound")
                analog = payload._to_hybrid_block_ir()
                if analog.measurements:
                    _raise_embedded_measurement_error(block.block_id, "Analog")
                blocks.append(
                    AnalogBlockIR(
                        block_id=block.block_id,
                        program=analog,
                        metadata=dict(block.metadata),
                    )
                )
        mapping: dict[str, str] = {}
        for block in self.blocks:
            mapping.update(block.mapping)
        metadata = dict(self.metadata)
        metadata.setdefault("hybrid_program_hash", self.stable_hash())
        return HybridProgramIR(
            program_id=self.program_id,
            blocks=tuple(blocks),
            mapping=mapping,
            metadata=metadata,
        )

    @classmethod
    def from_ir(cls, program: HybridProgramIR) -> HybridProgram:
        """Restore a bound typed HybridProgram from HybridProgramIR."""
        from cascaqit.digital import DigitalProgramIR
        from cascaqit.hybrid.models import (
            AnalogBlockIR,
            DigitalBlockIR,
            HybridProgramIR,
            MeasureBlockIR,
        )

        if not isinstance(program, HybridProgramIR):
            raise TypeError("program must be HybridProgramIR.")
        restored = cls(program_id=program.program_id, metadata=dict(program.metadata))
        for item in program.blocks:
            if isinstance(item, DigitalBlockIR):
                restored = restored.digital(
                    item.block_id,
                    DigitalProgramIR(program_id=item.block_id, circuit=item.circuit),
                    mapping={
                        logical_id: program.mapping.get(logical_id, logical_id)
                        for logical_id in item.circuit.qubits
                    },
                )
                restored = _restore_last_block_identity(
                    restored,
                    block_id=item.block_id,
                    metadata=item.metadata,
                )
            elif isinstance(item, AnalogBlockIR):
                restored = restored.analog(
                    item.block_id,
                    item.program,
                    mapping={
                        atom_id: program.mapping.get(atom_id, atom_id)
                        for atom_id in item.program.register.active_atom_ids
                    },
                )
                restored = _restore_last_block_identity(
                    restored,
                    block_id=item.block_id,
                    metadata=item.metadata,
                )
            elif isinstance(item, MeasureBlockIR):
                if len(item.measurements) != 1:
                    raise ValueError("HybridProgramIR measurement requires one entry.")
                measurement = item.measurements[0]
                restored = restored.measure_all(
                    name=item.block_id,
                    key=measurement.key,
                )
                restored = _restore_last_block_identity(
                    restored,
                    block_id=item.block_id,
                    metadata=item.metadata,
                )
            else:  # pragma: no cover - closed union defensive check
                raise TypeError("HybridProgramIR contains an unsupported block.")
        return restored

    def to_dict(self) -> dict[str, Any]:
        """Serialize orchestration facts without private runtime payload objects."""
        data = canonicalize(
            {
                "program_id": self.program_id,
                "syntax_hash": self.syntax_hash,
                "blocks": self.blocks,
                "dependencies": self.dependencies,
                "source_map": self.source_map,
                "metadata": self.metadata,
                "schema_version": self.schema_version,
            }
        )
        if not isinstance(data, dict):  # pragma: no cover - fixed mapping input
            raise TypeError("HybridProgram must serialize to an object.")
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> HybridProgram:
        """Build a hybrid program from a dictionary."""
        return cls(
            program_id=str(data["program_id"]),
            syntax_hash=str(data["syntax_hash"]),
            blocks=tuple(
                HybridProgramBlock.from_dict(item) for item in data.get("blocks", ())
            ),
            dependencies=tuple(
                BlockDependency.from_dict(item)
                for item in data.get("dependencies", ())
            ),
            source_map=SourceMap.from_dict(data.get("source_map", {})),
            metadata=dict(data.get("metadata", {})),
            schema_version=str(
                data.get("schema_version", ORCHESTRATION_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> HybridProgram:
        """Build a hybrid program from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("HybridProgram JSON must contain an object.")
        return cls.from_dict(data)


def _payload_parameters(payload: object | None) -> tuple[Parameter, ...]:
    from cascaqit.analog import AHSProgram
    from cascaqit.digital import Circuit

    if isinstance(payload, (Circuit, AHSProgram)):
        return payload.parameters
    return ()


def _restore_last_block_identity(
    program: HybridProgram,
    *,
    block_id: str,
    metadata: Mapping[str, Any],
) -> HybridProgram:
    previous = program.blocks[-1]
    restored = replace(
        previous,
        block_id=block_id,
        declaration_node_id=f"declaration.{block_id}",
        invocation_node_id=block_id,
        block_name=block_id,
        metadata=dict(metadata),
    )
    payloads = dict(program._payloads)
    payload = payloads.pop(previous.block_id, None)
    if payload is not None:
        payloads[block_id] = payload
    return replace(
        program,
        blocks=(*program.blocks[:-1], restored),
        _payloads=payloads,
    )


def _snapshot_payload(payload: object) -> object:
    from cascaqit.analog import AHSProgram
    from cascaqit.digital import Circuit, DigitalProgramIR
    from cascaqit.native_ir import ProgramIR

    if isinstance(payload, Circuit):
        circuit_snapshot = copy.copy(payload)
        circuit_snapshot._gates = list(payload._gates)
        circuit_snapshot._measurements = list(payload._measurements)
        circuit_snapshot._parameters = list(payload._parameters)
        circuit_snapshot._metadata = dict(payload._metadata)
        circuit_snapshot._bound_parameter_values = (
            None
            if payload._bound_parameter_values is None
            else dict(payload._bound_parameter_values)
        )
        return circuit_snapshot
    if isinstance(payload, AHSProgram):
        ahs_snapshot = copy.copy(payload)
        ahs_snapshot._measurements = list(payload._measurements)
        ahs_snapshot._parameters = list(payload._parameters)
        ahs_snapshot._resolved_values = dict(payload._resolved_values)
        return ahs_snapshot
    if isinstance(payload, DigitalProgramIR):
        return DigitalProgramIR.from_dict(payload.to_dict())
    if isinstance(payload, ProgramIR):
        return ProgramIR.from_dict(payload.to_dict())
    raise TypeError("unsupported Hybrid payload type.")


def _payload_logical_ids(payload: object) -> tuple[str, ...]:
    from cascaqit.analog import AHSProgram
    from cascaqit.digital import Circuit, DigitalProgramIR
    from cascaqit.native_ir import ProgramIR

    if isinstance(payload, Circuit):
        return payload.qubits
    if isinstance(payload, DigitalProgramIR):
        return payload.circuit.qubits
    if isinstance(payload, AHSProgram):
        return payload._register.to_ir().active_atom_ids
    if isinstance(payload, ProgramIR):
        return payload.register.active_atom_ids
    raise TypeError("unsupported Hybrid payload type.")


def _program_logical_ids(
    blocks: tuple[HybridProgramBlock, ...],
) -> tuple[str, ...]:
    ordered: list[str] = []
    for block in blocks:
        for resource in block.logical_resources:
            logical_id = block.mapping.get(resource.logical_id, resource.logical_id)
            if logical_id not in ordered:
                ordered.append(logical_id)
    return tuple(ordered)


def _logical_resource(
    block_id: str,
    logical_id: str,
    resource_kind: str,
) -> SemanticLogicalResourceHIR:
    return SemanticLogicalResourceHIR(
        node_id=f"resource.{block_id}.{logical_id}",
        syntax_node_id=f"resource.{block_id}.{logical_id}",
        logical_id=logical_id,
        resource_kind=resource_kind,  # type: ignore[arg-type]
    )


def _parameter_arguments(
    block_id: str,
    parameters: tuple[Parameter, ...],
) -> tuple[SemanticArgumentHIR, ...]:
    return tuple(
        SemanticArgumentHIR(
            node_id=f"argument.{block_id}.{parameter.name}",
            syntax_node_id=f"argument.{block_id}.{parameter.name}",
            name=parameter.name,
            dtype=parameter.dtype,
            unit=parameter.unit,
            binding_state="unbound",
            value=None,
            value_source="unbound",
        )
        for parameter in parameters
    )


def _validate_payload_kind(block_kind: str, payload: object) -> None:
    from cascaqit.analog import AHSProgram
    from cascaqit.digital import Circuit, DigitalProgramIR
    from cascaqit.native_ir import ProgramIR

    expected: tuple[type[object], ...]
    if block_kind == "digital":
        expected = (Circuit, DigitalProgramIR)
    elif block_kind == "analog":
        expected = (AHSProgram, ProgramIR)
    else:
        raise ValueError("payloads can only be attached to Digital or Analog blocks.")
    if not isinstance(payload, expected):
        raise TypeError(
            f"{block_kind} block cannot own payload type {type(payload).__name__}."
        )


def _merge_parameter_arguments(
    block: HybridProgramBlock,
    parameters: tuple[Parameter, ...],
) -> tuple[SemanticArgumentHIR, ...]:
    by_name = {argument.name: argument for argument in block.arguments}
    merged: list[SemanticArgumentHIR] = []
    parameter_names = {parameter.name for parameter in parameters}
    for parameter in parameters:
        existing = by_name.get(parameter.name)
        if existing is not None:
            if existing.dtype != parameter.dtype or existing.unit != parameter.unit:
                raise ValueError(
                    f"parameter '{parameter.name}' conflicts with HIR declaration."
                )
            merged.append(existing)
        else:
            merged.extend(_parameter_arguments(block.block_id, (parameter,)))
    merged.extend(
        argument
        for argument in block.arguments
        if argument.name not in parameter_names
    )
    return tuple(merged)


def _payload_declaration_hash(payload: object) -> str:
    if isinstance(payload, IRMixin):
        declaration: object = payload.to_dict()
    else:
        declaration = getattr(payload, "__dict__", payload)
    return hashlib.sha256(stable_json(declaration).encode("utf-8")).hexdigest()


def _bind_payload(
    payload: object | None,
    bind_set: ParameterBindIR,
) -> object | None:
    from cascaqit.analog import AHSProgram
    from cascaqit.digital import Circuit

    parameters = _payload_parameters(payload)
    if not parameters:
        return None if payload is None else _snapshot_payload(payload)
    values = {
        parameter.name: float(bind_set.values[parameter.name])
        for parameter in parameters
    }
    if isinstance(payload, (Circuit, AHSProgram)):
        return payload.bind(values)
    return _snapshot_payload(payload)


def _bound_argument(
    argument: SemanticArgumentHIR,
    bind_set: ParameterBindIR,
) -> SemanticArgumentHIR:
    value = bind_set.values[argument.name]
    return replace(
        argument,
        binding_state="bound",
        value=value,
        value_source="literal",
        source_symbol=None,
    )


def _payload_factory(payload: object) -> LocalProgramFactory:
    snapshot = _snapshot_payload(payload)
    parameter_names = tuple(
        parameter.name for parameter in _payload_parameters(snapshot)
    )

    def factory(
        bind_set: ParameterBindIR,
    ) -> Circuit | DigitalProgramIR | AHSProgram | ProgramIR:
        from cascaqit.analog import AHSProgram
        from cascaqit.digital import Circuit, DigitalProgramIR
        from cascaqit.native_ir import ProgramIR

        values = {
            name: float(bind_set.values[name]) for name in parameter_names
        }
        if isinstance(snapshot, (Circuit, AHSProgram)):
            return snapshot.bind(values)
        if isinstance(snapshot, (DigitalProgramIR, ProgramIR)):
            return _snapshot_payload(snapshot)  # type: ignore[return-value]
        raise TypeError("unsupported Hybrid payload type.")

    return factory


def _raise_payload_export_error(block_id: str, reason: str) -> NoReturn:
    from cascaqit.exceptions import ProgramValidationError

    raise ProgramValidationError(
        f"Hybrid block '{block_id}' cannot be exported: payload is {reason}.",
        code="HYBRID_PAYLOAD_EXPORT_INVALID",
        stage="compile",
        object_path=f"hybrid.blocks.{block_id}.payload",
        suggestion="Attach and bind every Digital or Analog payload before to_ir().",
        metadata={"block_id": block_id, "reason": reason},
    )


def _raise_embedded_measurement_error(block_id: str, block_kind: str) -> NoReturn:
    """Reject block-local measurement owned by the enclosing Hybrid program."""
    from cascaqit.exceptions import ProgramValidationError

    raise ProgramValidationError(
        f"{block_kind} Hybrid block '{block_id}' contains embedded measurement.",
        code="HYBRID_BLOCK_MEASUREMENT_FORBIDDEN",
        stage="compile",
        object_path=f"hybrid.blocks.{block_id}.payload.measurements",
        suggestion=(
            "Remove the block-local measurement and terminate the Hybrid "
            "program with measure_all()."
        ),
        metadata={"block_id": block_id, "block_kind": block_kind.lower()},
    )


def _validate_blocks(
    blocks: tuple[HybridProgramBlock, ...],
) -> list[OrchestrationDiagnosticIR]:
    diagnostics: list[OrchestrationDiagnosticIR] = []
    if not blocks:
        diagnostics.append(
            _diagnostic(
                code="HYBRID_PROGRAM_EMPTY",
                message="HybridProgram requires at least one block.",
                object_path="program.blocks",
                suggestion="Add a resolved block invocation before compiling.",
            )
        )
        return diagnostics
    seen: set[str] = set()
    for index, block in enumerate(blocks):
        if block.block_id in seen:
            diagnostics.append(
                _diagnostic(
                    code="HYBRID_DUPLICATE_BLOCK_ID",
                    message=f"Duplicate block id '{block.block_id}'.",
                    object_path=f"program.blocks[{index}]",
                    source_span=block.source_span,
                    metadata={"block_id": block.block_id},
                )
            )
        seen.add(block.block_id)
        for argument in block.arguments:
            if argument.binding_state == "unbound":
                payload_parameters = block.metadata.get(
                    "payload_parameter_names",
                    (),
                )
                if (
                    block.metadata.get("payload_owned") is True
                    and isinstance(payload_parameters, (list, tuple))
                    and argument.name in payload_parameters
                ):
                    continue
                diagnostics.append(
                    _diagnostic(
                        code="HYBRID_PARAMETER_UNBOUND",
                        message=(
                            f"Parameter '{argument.name}' is unbound in block "
                            f"'{block.block_id}'."
                        ),
                        object_path=f"program.blocks[{index}].arguments.{argument.name}",
                        source_span=argument.source_span or block.source_span,
                        suggestion="Bind all required arguments before compiling.",
                        metadata={
                            "block_id": block.block_id,
                            "parameter": argument.name,
                        },
                    )
                )
    return diagnostics


def _validate_dependencies(
    blocks: tuple[HybridProgramBlock, ...],
    dependencies: tuple[BlockDependency, ...],
) -> list[OrchestrationDiagnosticIR]:
    diagnostics: list[OrchestrationDiagnosticIR] = []
    block_ids = {block.block_id for block in blocks}
    dependency_ids: set[str] = set()
    semantic_edges: set[tuple[str, str, str]] = set()
    for index, dependency in enumerate(dependencies):
        path = f"program.dependencies[{index}]"
        if dependency.dependency_id in dependency_ids:
            diagnostics.append(
                _diagnostic(
                    code="HYBRID_DUPLICATE_DEPENDENCY_ID",
                    message=f"Duplicate dependency id '{dependency.dependency_id}'.",
                    object_path=path,
                    source_span=dependency.source_span,
                )
            )
        dependency_ids.add(dependency.dependency_id)
        edge_key = (
            dependency.source_block_id,
            dependency.target_block_id,
            dependency.dependency_type,
        )
        if edge_key in semantic_edges:
            diagnostics.append(
                _diagnostic(
                    code="HYBRID_DUPLICATE_DEPENDENCY",
                    message="Duplicate typed dependency endpoints.",
                    object_path=path,
                    source_span=dependency.source_span,
                    metadata={"dependency_id": dependency.dependency_id},
                )
            )
        semantic_edges.add(edge_key)
        for endpoint_name, block_id in (
            ("source", dependency.source_block_id),
            ("target", dependency.target_block_id),
        ):
            if block_id not in block_ids:
                diagnostics.append(
                    _diagnostic(
                        code="HYBRID_DEPENDENCY_UNKNOWN_BLOCK",
                        message=(
                            f"Dependency {endpoint_name} references unknown block "
                            f"'{block_id}'."
                        ),
                        object_path=f"{path}.{endpoint_name}_block_id",
                        source_span=dependency.source_span,
                        metadata={
                            "dependency_id": dependency.dependency_id,
                            "block_id": block_id,
                        },
                    )
                )
    return diagnostics


def _validate_mapping_continuity(
    blocks: tuple[HybridProgramBlock, ...],
) -> list[OrchestrationDiagnosticIR]:
    diagnostics: list[OrchestrationDiagnosticIR] = []
    logical_targets: dict[str, tuple[str, str]] = {}
    for index, block in enumerate(blocks):
        for logical_id, target in sorted(block.mapping.items()):
            previous = logical_targets.get(logical_id)
            if previous is not None and previous[0] != target:
                diagnostics.append(
                    _diagnostic(
                        code="HYBRID_MAPPING_CONFLICT",
                        message=(
                            f"Logical resource '{logical_id}' maps to both "
                            f"'{previous[0]}' and '{target}'."
                        ),
                        object_path=f"program.blocks[{index}].mapping.{logical_id}",
                        source_span=block.source_span,
                        suggestion="Use one explicit target for a shared logical id.",
                        metadata={
                            "logical_id": logical_id,
                            "previous_block_id": previous[1],
                            "block_id": block.block_id,
                        },
                    )
                )
            else:
                logical_targets[logical_id] = (target, block.block_id)
    return diagnostics


def _validate_measurement_lifecycle(
    blocks: tuple[HybridProgramBlock, ...],
) -> list[OrchestrationDiagnosticIR]:
    diagnostics: list[OrchestrationDiagnosticIR] = []
    for index, block in enumerate(blocks[:-1]):
        if block.block_kind != "measurement":
            continue
        if any(
            later.block_kind in {"digital", "analog"}
            for later in blocks[index + 1 :]
        ):
            diagnostics.append(
                _diagnostic(
                    code="HYBRID_MEASUREMENT_NOT_TERMINAL",
                    message="Measurement must terminate the quantum block sequence.",
                    object_path=f"program.blocks[{index}]",
                    source_span=block.source_span,
                    suggestion="Move measurement after all quantum blocks.",
                    metadata={"block_id": block.block_id},
                )
            )
    return diagnostics


def _merge_source_maps(left: SourceMap, right: SourceMap) -> SourceMap:
    entries_by_id: dict[str, SourceMapEntry] = {
        entry.node_id: entry for entry in left.entries
    }
    for entry in right.entries:
        previous = entries_by_id.get(entry.node_id)
        if previous is not None and previous != entry:
            raise ValueError(f"conflicting source map entry '{entry.node_id}'.")
        entries_by_id[entry.node_id] = entry
    return SourceMap(entries=tuple(entries_by_id[key] for key in sorted(entries_by_id)))


def _composed_ids(program: HybridProgram) -> tuple[str, ...]:
    value = program.metadata.get("composed_program_ids", ())
    if isinstance(value, (list, tuple)):
        return tuple(str(item) for item in value)
    return ()


def _diagnostic(
    *,
    code: str,
    message: str,
    object_path: str,
    source_span: SourceSpan | None = None,
    suggestion: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> OrchestrationDiagnosticIR:
    suffix = code.lower().removeprefix("hybrid_").replace("_", ".")
    return OrchestrationDiagnosticIR(
        diagnostic_id=f"orchestration.{suffix}",
        stage="orchestration",
        severity="error",
        code=code,
        message=message,
        object_path=object_path,
        source_span=source_span,
        suggestion=suggestion,
        metadata={} if metadata is None else metadata,
    )
