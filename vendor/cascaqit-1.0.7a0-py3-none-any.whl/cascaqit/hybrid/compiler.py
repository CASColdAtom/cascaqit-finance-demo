"""Deterministic compilation from HybridProgram to a local execution plan."""

from __future__ import annotations

import json
from collections.abc import Iterable
from dataclasses import dataclass, field
from typing import Any, Literal

from cascaqit.hybrid.diagnostics import (
    ORCHESTRATION_SCHEMA_VERSION,
    OrchestrationDiagnosticIR,
)
from cascaqit.hybrid.graph import HybridBlockGraphIR, build_hybrid_block_graph
from cascaqit.hybrid.orchestration import HybridProgramBlock
from cascaqit.hybrid.program import HybridProgram
from cascaqit.native_ir.base import IRMixin
from cascaqit.syntax import SemanticArgumentHIR, SourceMap, SourceSpan

__all__ = [
    "HybridCompileResult",
    "LocalExecutionPlan",
    "LocalExecutionStep",
    "compile_hybrid_program",
]

KernelKind = Literal["digital", "analog", "measurement"]


@dataclass(frozen=True)
class LocalExecutionStep(IRMixin):
    """One ordered kernel invocation in a future local hybrid runner."""

    step_id: str
    order_index: int
    block_id: str
    kernel_kind: KernelKind
    argument_bindings: tuple[SemanticArgumentHIR, ...] = ()
    mapping: dict[str, str] = field(default_factory=dict)
    required_capabilities: tuple[str, ...] = ()
    payload_required: bool = True
    payload_ref: str | None = None
    source_span: SourceSpan | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = ORCHESTRATION_SCHEMA_VERSION

    def __post_init__(self) -> None:
        for field_name in ("step_id", "block_id"):
            value = getattr(self, field_name)
            if not isinstance(value, str) or not value.strip():
                raise ValueError(f"{field_name} must be a non-empty string.")
        if self.order_index < 0:
            raise ValueError("order_index must be non-negative.")
        if self.kernel_kind not in {"digital", "analog", "measurement"}:
            raise ValueError("invalid kernel_kind.")
        if any(
            not isinstance(argument, SemanticArgumentHIR)
            for argument in self.argument_bindings
        ):
            raise TypeError(
                "argument_bindings must contain SemanticArgumentHIR values."
            )
        if not self.payload_required:
            raise ValueError("v1 local execution steps must require a payload.")
        if self.payload_ref is not None:
            raise ValueError("v1 local execution steps cannot bind a payload_ref.")
        if self.source_span is not None and not isinstance(
            self.source_span, SourceSpan
        ):
            raise TypeError("source_span must be SourceSpan or None.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> LocalExecutionStep:
        """Build a local execution step from a dictionary."""
        span_data = data.get("source_span")
        return cls(
            step_id=str(data["step_id"]),
            order_index=int(data["order_index"]),
            block_id=str(data["block_id"]),
            kernel_kind=data["kernel_kind"],
            argument_bindings=tuple(
                SemanticArgumentHIR.from_dict(item)
                for item in data.get("argument_bindings", ())
            ),
            mapping={
                str(key): str(value) for key, value in data.get("mapping", {}).items()
            },
            required_capabilities=tuple(
                str(item) for item in data.get("required_capabilities", ())
            ),
            payload_required=bool(data.get("payload_required", True)),
            payload_ref=data.get("payload_ref"),
            source_span=(
                None if span_data is None else SourceSpan.from_dict(span_data)
            ),
            metadata=dict(data.get("metadata", {})),
            schema_version=str(
                data.get("schema_version", ORCHESTRATION_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class LocalExecutionPlan(IRMixin):
    """A deterministic local plan that honestly records missing payloads."""

    plan_id: str
    program_id: str
    program_hash: str
    graph_hash: str
    steps: tuple[LocalExecutionStep, ...]
    execution_ready: bool
    payload_requirements: tuple[str, ...]
    required_capabilities: tuple[str, ...] = ()
    source_map: SourceMap = field(default_factory=SourceMap)
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = ORCHESTRATION_SCHEMA_VERSION

    def __post_init__(self) -> None:
        for field_name in ("plan_id", "program_id"):
            value = getattr(self, field_name)
            if not isinstance(value, str) or not value.strip():
                raise ValueError(f"{field_name} must be a non-empty string.")
        for field_name in ("program_hash", "graph_hash"):
            value = getattr(self, field_name)
            if len(value) != 64 or any(
                character not in "0123456789abcdef" for character in value
            ):
                raise ValueError(
                    f"{field_name} must be a lowercase SHA-256 hex digest."
                )
        if not self.steps:
            raise ValueError("local execution plan steps must not be empty.")
        if tuple(step.order_index for step in self.steps) != tuple(
            range(len(self.steps))
        ):
            raise ValueError("step order_index values must be contiguous.")
        if len({step.block_id for step in self.steps}) != len(self.steps):
            raise ValueError("local execution plan block ids must be unique.")
        if self.execution_ready:
            raise ValueError("v1 local execution plans cannot be execution-ready.")
        if len(self.payload_requirements) != len(self.steps):
            raise ValueError("each step must have one payload requirement.")
        if not isinstance(self.source_map, SourceMap):
            raise TypeError("source_map must be SourceMap.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> LocalExecutionPlan:
        """Build a local execution plan from a dictionary."""
        return cls(
            plan_id=str(data["plan_id"]),
            program_id=str(data["program_id"]),
            program_hash=str(data["program_hash"]),
            graph_hash=str(data["graph_hash"]),
            steps=tuple(
                LocalExecutionStep.from_dict(item) for item in data.get("steps", ())
            ),
            execution_ready=bool(data["execution_ready"]),
            payload_requirements=tuple(
                str(item) for item in data.get("payload_requirements", ())
            ),
            required_capabilities=tuple(
                str(item) for item in data.get("required_capabilities", ())
            ),
            source_map=SourceMap.from_dict(data.get("source_map", {})),
            metadata=dict(data.get("metadata", {})),
            schema_version=str(
                data.get("schema_version", ORCHESTRATION_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> LocalExecutionPlan:
        """Build a local execution plan from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("LocalExecutionPlan JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class HybridCompileResult(IRMixin):
    """Compiled graph and plan, or diagnostics that blocked plan creation."""

    graph: HybridBlockGraphIR | None
    plan: LocalExecutionPlan | None
    diagnostics: tuple[OrchestrationDiagnosticIR, ...] = ()
    schema_version: str = ORCHESTRATION_SCHEMA_VERSION

    @property
    def has_errors(self) -> bool:
        """Return whether compilation emitted an error."""
        return any(item.severity == "error" for item in self.diagnostics)

    def __post_init__(self) -> None:
        if self.has_errors and self.plan is not None:
            raise ValueError("compile result with errors must not expose a plan.")
        if not self.has_errors and (self.graph is None or self.plan is None):
            raise ValueError("successful compile result requires graph and plan.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> HybridCompileResult:
        """Build a hybrid compile result from a dictionary."""
        graph_data = data.get("graph")
        plan_data = data.get("plan")
        return cls(
            graph=(
                None
                if graph_data is None
                else HybridBlockGraphIR.from_dict(graph_data)
            ),
            plan=(
                None if plan_data is None else LocalExecutionPlan.from_dict(plan_data)
            ),
            diagnostics=tuple(
                OrchestrationDiagnosticIR.from_dict(item)
                for item in data.get("diagnostics", ())
            ),
            schema_version=str(
                data.get("schema_version", ORCHESTRATION_SCHEMA_VERSION)
            ),
        )


def compile_hybrid_program(
    program: HybridProgram,
    *,
    allowed_capabilities: Iterable[str] | None = None,
) -> HybridCompileResult:
    """Compile a user program without invoking a backend or numerical kernel."""
    if not isinstance(program, HybridProgram):
        raise TypeError("program must be HybridProgram.")
    graph_result = build_hybrid_block_graph(program)
    if graph_result.graph is None:
        return HybridCompileResult(
            graph=None,
            plan=None,
            diagnostics=graph_result.diagnostics,
        )
    graph = graph_result.graph
    capability_diagnostics = _validate_capabilities(graph, allowed_capabilities)
    if capability_diagnostics:
        return HybridCompileResult(
            graph=graph,
            plan=None,
            diagnostics=capability_diagnostics,
        )

    nodes_by_id = {node.block_id: node for node in graph.nodes}
    steps = tuple(
        _execution_step(index, nodes_by_id[block_id])
        for index, block_id in enumerate(graph.topological_order)
    )
    payload_requirements = tuple(
        f"payload:{step.block_id}:{step.kernel_kind}" for step in steps
    )
    required_capabilities = tuple(
        sorted(
            {
                capability
                for step in steps
                for capability in step.required_capabilities
            }
        )
    )
    plan = LocalExecutionPlan(
        plan_id=f"local_plan.{program.program_id}",
        program_id=program.program_id,
        program_hash=program.stable_hash(),
        graph_hash=graph.stable_hash(),
        steps=steps,
        execution_ready=False,
        payload_requirements=payload_requirements,
        required_capabilities=required_capabilities,
        source_map=graph.source_map,
        metadata={
            "payload_binding": "required",
            "kernel_execution": False,
            "backend_called": False,
            "mixed_state_handoff_executed": False,
        },
    )
    return HybridCompileResult(
        graph=graph,
        plan=plan,
        diagnostics=(
            _compile_diagnostic(
                code="HYBRID_PLAN_PAYLOAD_REQUIRED",
                severity="warning",
                message=(
                    "LocalExecutionPlan was created, but numerical block payloads "
                    "are not bound."
                ),
                object_path="plan.payload_requirements",
                suggestion=(
                    "Attach typed payloads to HybridProgram before LocalBackend "
                    "execution."
                ),
                metadata={"requirements": list(payload_requirements)},
            ),
        ),
    )


def _execution_step(index: int, block: HybridProgramBlock) -> LocalExecutionStep:
    return LocalExecutionStep(
        step_id=f"step.{index}.{block.block_id}",
        order_index=index,
        block_id=block.block_id,
        kernel_kind=block.block_kind,
        argument_bindings=block.arguments,
        mapping=dict(block.mapping),
        required_capabilities=block.required_capabilities,
        payload_required=True,
        payload_ref=None,
        source_span=block.source_span,
        metadata={
            "declaration_node_id": block.declaration_node_id,
            "invocation_node_id": block.invocation_node_id,
        },
    )


def _validate_capabilities(
    graph: HybridBlockGraphIR,
    allowed_capabilities: Iterable[str] | None,
) -> tuple[OrchestrationDiagnosticIR, ...]:
    if allowed_capabilities is None:
        return ()
    allowed = set(allowed_capabilities)
    diagnostics: list[OrchestrationDiagnosticIR] = []
    for node in graph.nodes:
        missing = tuple(
            sorted(set(node.required_capabilities).difference(allowed))
        )
        if missing:
            diagnostics.append(
                _compile_diagnostic(
                    code="HYBRID_COMPILE_CAPABILITY_UNSUPPORTED",
                    severity="error",
                    message=(
                        f"Block '{node.block_id}' requires unsupported capabilities: "
                        + ", ".join(missing)
                    ),
                    object_path=f"graph.nodes.{node.block_id}.required_capabilities",
                    source_span=node.source_span,
                    suggestion="Compile with a capability set that supports the block.",
                    metadata={
                        "block_id": node.block_id,
                        "missing_capabilities": list(missing),
                    },
                )
            )
    return tuple(diagnostics)


def _compile_diagnostic(
    *,
    code: str,
    severity: Literal["info", "warning", "error"],
    message: str,
    object_path: str,
    source_span: SourceSpan | None = None,
    suggestion: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> OrchestrationDiagnosticIR:
    suffix = code.lower().removeprefix("hybrid_").replace("_", ".")
    return OrchestrationDiagnosticIR(
        diagnostic_id=f"compile.{suffix}",
        stage="compile",
        severity=severity,
        code=code,
        message=message,
        object_path=object_path,
        source_span=source_span,
        suggestion=suggestion,
        metadata={} if metadata is None else metadata,
    )
