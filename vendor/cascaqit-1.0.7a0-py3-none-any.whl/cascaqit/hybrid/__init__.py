"""Hybrid plan, backend-blocked, and safe-subset API contracts."""

from __future__ import annotations

from importlib import import_module
from typing import Any

from cascaqit.hybrid.compiler import (
    HybridCompileResult,
    LocalExecutionPlan,
    LocalExecutionStep,
    compile_hybrid_program,
)
from cascaqit.hybrid.diagnostics import (
    ORCHESTRATION_SCHEMA_VERSION,
    OrchestrationDiagnosticIR,
)
from cascaqit.hybrid.graph import (
    HybridBlockGraphBuildResult,
    HybridBlockGraphIR,
    build_hybrid_block_graph,
)
from cascaqit.hybrid.models import (
    AnalogBlockIR,
    DigitalBlockIR,
    HybridBackendReadinessIR,
    HybridBlockStateSummaryIR,
    HybridBoundaryDiagnosticIR,
    HybridProgramIR,
    HybridSimulationPlanIR,
    MeasureBlockIR,
    assess_hybrid_backend_readiness,
    build_hybrid_program,
    build_hybrid_simulation_plan,
    diagnose_hybrid_execution_support,
)
from cascaqit.hybrid.orchestration import BlockDependency, HybridProgramBlock
from cascaqit.hybrid.program import HybridAnalysisResult, HybridProgram

_EXPORT_MODULES: dict[str, str] = {
    "HybridDAQCBoundaryGapItemIR": "cascaqit.hybrid.boundary_gap",
    "HybridDAQCBoundaryGapMatrixIR": "cascaqit.hybrid.boundary_gap",
    "build_hybrid_daqc_boundary_gap_matrix": "cascaqit.hybrid.boundary_gap",
}

__all__ = [
    "AnalogBlockIR",
    "BlockDependency",
    "DigitalBlockIR",
    "HybridBackendReadinessIR",
    "HybridBlockGraphBuildResult",
    "HybridBlockGraphIR",
    "HybridBlockStateSummaryIR",
    "HybridBoundaryDiagnosticIR",
    "HybridDAQCBoundaryGapItemIR",
    "HybridDAQCBoundaryGapMatrixIR",
    "HybridProgramIR",
    "HybridAnalysisResult",
    "HybridProgram",
    "HybridProgramBlock",
    "HybridSimulationPlanIR",
    "MeasureBlockIR",
    "HybridCompileResult",
    "LocalExecutionPlan",
    "LocalExecutionStep",
    "ORCHESTRATION_SCHEMA_VERSION",
    "OrchestrationDiagnosticIR",
    "assess_hybrid_backend_readiness",
    "build_hybrid_block_graph",
    "build_hybrid_daqc_boundary_gap_matrix",
    "build_hybrid_program",
    "build_hybrid_simulation_plan",
    "diagnose_hybrid_execution_support",
    "compile_hybrid_program",
]


def __getattr__(name: str) -> Any:
    """Lazily resolve hybrid exports that depend on the hybrid package itself."""
    try:
        module_name = _EXPORT_MODULES[name]
    except KeyError as exc:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}") from exc
    value = getattr(import_module(module_name), name)
    globals()[name] = value
    return value
