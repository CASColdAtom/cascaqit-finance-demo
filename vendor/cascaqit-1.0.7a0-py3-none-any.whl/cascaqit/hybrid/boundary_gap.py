"""Hybrid DAQC boundary gap matrix contracts."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Literal

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.hybrid.models import (
    HybridBackendReadinessIR,
    HybridProgramIR,
    HybridSimulationPlanIR,
    assess_hybrid_backend_readiness,
    build_hybrid_simulation_plan,
)
from cascaqit.native_ir.base import IRMixin, canonicalize
from cascaqit.native_ir.models import SCHEMA_VERSION

__all__ = [
    "HybridDAQCBoundaryGapItemIR",
    "HybridDAQCBoundaryGapMatrixIR",
    "HybridDAQCBoundaryGapStatus",
    "build_hybrid_daqc_boundary_gap_matrix",
]

HybridDAQCBoundaryGapStatus = Literal[
    "implemented",
    "plan-only",
    "safe-local-subset",
    "blocked",
    "not implemented",
]

_STATUSES: tuple[HybridDAQCBoundaryGapStatus, ...] = (
    "implemented",
    "plan-only",
    "safe-local-subset",
    "blocked",
    "not implemented",
)


@dataclass(frozen=True)
class HybridDAQCBoundaryGapItemIR(IRMixin):
    """Single row in the hybrid DAQC boundary gap matrix."""

    capability_id: str
    boundary_layer: str
    status: HybridDAQCBoundaryGapStatus
    current_evidence: str
    gap: str
    recommendation: str
    priority: int
    blocks_backend_execution: bool = False
    full_daqc_state_handoff: bool = False
    hybrid_hardware_backend_execution: bool = False
    package_built: bool = False
    backend_submitted: bool = False
    metadata_only: bool = True
    network_accessed: bool = False
    external_dependency_required: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Validate item invariants that keep the matrix side-effect free."""
        if self.status not in _STATUSES:
            raise ValueError(f"unsupported hybrid DAQC boundary status: {self.status}")
        if self.priority < 1:
            raise ValueError("priority must be positive.")
        if self.full_daqc_state_handoff:
            raise ValueError("Hybrid DAQC gap items must not claim DAQC handoff.")
        if self.hybrid_hardware_backend_execution:
            raise ValueError(
                "Hybrid DAQC gap items must not claim hardware backend execution."
            )
        if self.package_built:
            raise ValueError("Hybrid DAQC gap items must not claim package build.")
        if self.backend_submitted:
            raise ValueError("Hybrid DAQC gap items must not claim backend submit.")
        if not self.metadata_only:
            raise ValueError("Hybrid DAQC gap items must be metadata-only.")
        if self.network_accessed:
            raise ValueError("Hybrid DAQC gap items must not access networks.")
        if self.external_dependency_required:
            raise ValueError(
                "Hybrid DAQC gap items must not require external dependencies."
            )
        object.__setattr__(self, "metadata", canonicalize(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> HybridDAQCBoundaryGapItemIR:
        """Build a hybrid DAQC boundary gap item from a dictionary."""
        return cls(
            capability_id=str(data["capability_id"]),
            boundary_layer=str(data["boundary_layer"]),
            status=data["status"],
            current_evidence=str(data["current_evidence"]),
            gap=str(data["gap"]),
            recommendation=str(data["recommendation"]),
            priority=int(data["priority"]),
            blocks_backend_execution=bool(
                data.get("blocks_backend_execution", False)
            ),
            full_daqc_state_handoff=bool(
                data.get("full_daqc_state_handoff", False)
            ),
            hybrid_hardware_backend_execution=bool(
                data.get("hybrid_hardware_backend_execution", False)
            ),
            package_built=bool(data.get("package_built", False)),
            backend_submitted=bool(data.get("backend_submitted", False)),
            metadata_only=bool(data.get("metadata_only", True)),
            network_accessed=bool(data.get("network_accessed", False)),
            external_dependency_required=bool(
                data.get("external_dependency_required", False)
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )


@dataclass(frozen=True)
class HybridDAQCBoundaryGapMatrixIR(IRMixin):
    """Metadata-only gap matrix for hybrid DAQC execution boundaries."""

    matrix_id: str
    program_id: str
    plan_id: str | None
    readiness_id: str | None
    items: tuple[HybridDAQCBoundaryGapItemIR, ...]
    recommended_next_focus: tuple[str, ...]
    diagnostics: tuple[DiagnosticsIR, ...] = ()
    derived_view: bool = True
    metadata_only: bool = True
    full_daqc_state_handoff: bool = False
    hybrid_hardware_backend_execution: bool = False
    package_built: bool = False
    backend_submitted: bool = False
    network_accessed: bool = False
    external_dependency_required: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize rows and enforce blocked live-execution boundaries."""
        if not self.derived_view:
            raise ValueError("Hybrid DAQC gap matrix must remain a derived view.")
        if not self.metadata_only:
            raise ValueError("Hybrid DAQC gap matrix must be metadata-only.")
        if self.full_daqc_state_handoff:
            raise ValueError("Hybrid DAQC gap matrix must not claim DAQC handoff.")
        if self.hybrid_hardware_backend_execution:
            raise ValueError(
                "Hybrid DAQC gap matrix must not claim hardware backend execution."
            )
        if self.package_built:
            raise ValueError("Hybrid DAQC gap matrix must not claim package build.")
        if self.backend_submitted:
            raise ValueError("Hybrid DAQC gap matrix must not claim backend submit.")
        if self.network_accessed:
            raise ValueError("Hybrid DAQC gap matrix must not access networks.")
        if self.external_dependency_required:
            raise ValueError(
                "Hybrid DAQC gap matrix must not require external dependencies."
            )
        object.__setattr__(
            self,
            "items",
            tuple(
                item if isinstance(item, HybridDAQCBoundaryGapItemIR)
                else HybridDAQCBoundaryGapItemIR.from_dict(item)
                for item in self.items
            ),
        )
        object.__setattr__(
            self,
            "diagnostics",
            tuple(
                item if isinstance(item, DiagnosticsIR)
                else DiagnosticsIR.from_dict(item)
                for item in self.diagnostics
            ),
        )
        object.__setattr__(self, "metadata", canonicalize(self.metadata))

    @property
    def status_counts(self) -> dict[str, int]:
        """Return deterministic status counts."""
        return {
            status: sum(1 for item in self.items if item.status == status)
            for status in _STATUSES
        }

    @property
    def blocking_capabilities(self) -> tuple[str, ...]:
        """Return capability ids that block hybrid backend execution."""
        return tuple(
            item.capability_id for item in self.items
            if item.blocks_backend_execution
        )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> HybridDAQCBoundaryGapMatrixIR:
        """Build a hybrid DAQC boundary gap matrix from a dictionary."""
        return cls(
            matrix_id=str(data["matrix_id"]),
            program_id=str(data["program_id"]),
            plan_id=data.get("plan_id"),
            readiness_id=data.get("readiness_id"),
            items=tuple(
                HybridDAQCBoundaryGapItemIR.from_dict(item)
                for item in data.get("items", ())
            ),
            recommended_next_focus=tuple(
                str(item) for item in data.get("recommended_next_focus", ())
            ),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(item)
                for item in data.get("diagnostics", ())
            ),
            derived_view=bool(data.get("derived_view", True)),
            metadata_only=bool(data.get("metadata_only", True)),
            full_daqc_state_handoff=bool(
                data.get("full_daqc_state_handoff", False)
            ),
            hybrid_hardware_backend_execution=bool(
                data.get("hybrid_hardware_backend_execution", False)
            ),
            package_built=bool(data.get("package_built", False)),
            backend_submitted=bool(data.get("backend_submitted", False)),
            network_accessed=bool(data.get("network_accessed", False)),
            external_dependency_required=bool(
                data.get("external_dependency_required", False)
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> HybridDAQCBoundaryGapMatrixIR:
        """Build a hybrid DAQC boundary gap matrix from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError(
                "HybridDAQCBoundaryGapMatrixIR JSON must contain an object."
            )
        return cls.from_dict(data)


def build_hybrid_daqc_boundary_gap_matrix(
    program: HybridProgramIR,
    *,
    plan: HybridSimulationPlanIR | None = None,
    readiness: HybridBackendReadinessIR | None = None,
    matrix_id: str | None = None,
) -> HybridDAQCBoundaryGapMatrixIR:
    """Build a metadata-only gap matrix for a hybrid DAQC program boundary."""
    if not isinstance(program, HybridProgramIR):
        raise TypeError("program must be HybridProgramIR.")
    resolved_plan = build_hybrid_simulation_plan(program) if plan is None else plan
    resolved_readiness = (
        assess_hybrid_backend_readiness(program) if readiness is None else readiness
    )
    if not isinstance(resolved_plan, HybridSimulationPlanIR):
        raise TypeError("plan must be HybridSimulationPlanIR or None.")
    if not isinstance(resolved_readiness, HybridBackendReadinessIR):
        raise TypeError("readiness must be HybridBackendReadinessIR or None.")
    if resolved_plan.program_id != program.program_id:
        raise ValueError("plan program_id must match program.")
    if resolved_readiness.program_id != program.program_id:
        raise ValueError("readiness program_id must match program.")

    boundary = dict(resolved_plan.metadata.get("execution_boundary", {}))
    local_subset = bool(boundary.get("local_executable_subset", False))
    mixed_handoff = bool(boundary.get("mixed_analog_digital_state_handoff", False))
    blocking_codes = tuple(
        diagnostic.code for diagnostic in resolved_readiness.blocking_diagnostics
    )
    items = (
        _item(
            "hybrid_ir_construction",
            "ir",
            "implemented",
            "HybridProgramIR validates linear block sequences and mapping metadata.",
            "Block semantics remain intentionally narrow.",
            "Keep HybridProgramIR as the construction boundary before lowering.",
            1,
            metadata={"validation_mode": program.validation_mode},
        ),
        _item(
            "hybrid_plan_only_simulation",
            "simulation",
            "plan-only",
            "HybridSimulationPlanIR records block states and boundary diagnostics.",
            "Plan artifacts do not execute mixed analog/digital state handoff.",
            "Use plan review as the default mixed DAQC workflow.",
            1,
            metadata={
                "plan_id": resolved_plan.plan_id,
                "plan_executable": resolved_plan.executable,
                "boundary_kind": boundary.get("boundary_kind"),
            },
        ),
        _item(
            "hybrid_safe_local_subset",
            "simulation",
            "safe-local-subset",
            _safe_subset_evidence(boundary, local_subset),
            "Safe local execution is limited to digital-only or single analog blocks.",
            "Do not generalize safe subsets to full DAQC execution.",
            2,
            metadata={
                "local_executable_subset": local_subset,
                "digital_only_subset": bool(boundary.get("digital_only_subset", False)),
                "analog_single_block_subset": bool(
                    boundary.get("analog_single_block_subset", False)
                ),
            },
        ),
        _item(
            "hybrid_backend_execution",
            "backend",
            "blocked",
            "HybridBackendReadinessIR always blocks backend execution.",
            "No execution package build or backend submission path is enabled.",
            "Keep hybrid backend execution blocked until full lowering is designed.",
            1,
            blocks=True,
            metadata={
                "readiness_id": resolved_readiness.readiness_id,
                "blocking_codes": blocking_codes,
            },
        ),
        _item(
            "full_daqc_state_handoff",
            "handoff",
            "not implemented",
            _handoff_evidence(mixed_handoff, resolved_readiness),
            "Analog/digital quantum state continuity is undefined.",
            (
                "Specify state representation, measurement boundary, and error "
                "model first."
            ),
            1,
            blocks=True,
            metadata={
                "mixed_analog_digital_state_handoff": mixed_handoff,
                "full_daqc_state_handoff": False,
            },
        ),
    )
    return HybridDAQCBoundaryGapMatrixIR(
        matrix_id=matrix_id or f"hybrid_daqc_gap.{program.program_id}",
        program_id=program.program_id,
        plan_id=resolved_plan.plan_id,
        readiness_id=resolved_readiness.readiness_id,
        items=items,
        recommended_next_focus=(
            "full_daqc_state_handoff_semantics",
            "hybrid_lowering_contract",
            "hybrid_backend_execution_readiness",
        ),
        diagnostics=(
            DiagnosticsIR(
                diagnostic_id="hybrid_daqc_gap.metadata_only",
                stage="validation",
                severity="info",
                code="HYBRID_DAQC_GAP_MATRIX_METADATA_ONLY",
                message=(
                    "Hybrid DAQC boundary gap matrix is metadata-only and does "
                    "not build packages or submit backends."
                ),
                object_path="hybrid_daqc_boundary_gap_matrix",
                metadata={"program_id": program.program_id},
            ),
            DiagnosticsIR(
                diagnostic_id="hybrid_daqc_gap.backend_blocked",
                stage="validation",
                severity="warning",
                code="HYBRID_DAQC_BACKEND_EXECUTION_BLOCKED",
                message="Hybrid hardware backend execution remains blocked.",
                object_path="hybrid_daqc_boundary_gap_matrix.boundaries",
                metadata={
                    "program_id": program.program_id,
                    "full_daqc_state_handoff": False,
                },
            ),
        ),
        metadata={
            "status_vocabulary": _STATUSES,
            "boundary_kind": boundary.get("boundary_kind"),
            "safe_local_subset": local_subset,
            "mixed_analog_digital_state_handoff": mixed_handoff,
        },
    )


def _item(
    capability_id: str,
    boundary_layer: str,
    status: HybridDAQCBoundaryGapStatus,
    current_evidence: str,
    gap: str,
    recommendation: str,
    priority: int,
    *,
    blocks: bool = False,
    metadata: dict[str, Any] | None = None,
) -> HybridDAQCBoundaryGapItemIR:
    return HybridDAQCBoundaryGapItemIR(
        capability_id=capability_id,
        boundary_layer=boundary_layer,
        status=status,
        current_evidence=current_evidence,
        gap=gap,
        recommendation=recommendation,
        priority=priority,
        blocks_backend_execution=blocks,
        metadata={} if metadata is None else metadata,
    )


def _safe_subset_evidence(boundary: dict[str, Any], local_subset: bool) -> str:
    if local_subset:
        return "Current program is inside the supported safe local subset."
    return (
        "Safe local subsets exist, but this program is outside the executable "
        f"subset because boundary_kind={boundary.get('boundary_kind')!r}."
    )


def _handoff_evidence(
    mixed_handoff: bool,
    readiness: HybridBackendReadinessIR,
) -> str:
    if mixed_handoff:
        return "Plan diagnostics contain unsupported analog/digital state handoff."
    if readiness.full_daqc_state_handoff:
        return "Readiness unexpectedly claims full DAQC state handoff."
    return "No full DAQC state handoff implementation is present."
