"""Deterministic typed block graph construction for hybrid programs."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any

from cascaqit.hybrid.diagnostics import (
    ORCHESTRATION_SCHEMA_VERSION,
    OrchestrationDiagnosticIR,
)
from cascaqit.hybrid.orchestration import BlockDependency, HybridProgramBlock
from cascaqit.hybrid.program import HybridProgram
from cascaqit.native_ir.base import IRMixin
from cascaqit.syntax import SourceMap, SourceSpan

__all__ = [
    "HybridBlockGraphBuildResult",
    "HybridBlockGraphIR",
    "build_hybrid_block_graph",
]

_DEPENDENCY_ORDER = {
    "quantum_state": 0,
    "classical_value": 1,
    "parameter": 2,
    "timing": 3,
    "resource": 4,
}


@dataclass(frozen=True)
class HybridBlockGraphIR(IRMixin):
    """An immutable typed DAG compiled from one user HybridProgram."""

    graph_id: str
    program_id: str
    program_hash: str
    nodes: tuple[HybridProgramBlock, ...]
    edges: tuple[BlockDependency, ...]
    topological_order: tuple[str, ...]
    source_map: SourceMap = field(default_factory=SourceMap)
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = ORCHESTRATION_SCHEMA_VERSION

    def __post_init__(self) -> None:
        for field_name in ("graph_id", "program_id"):
            value = getattr(self, field_name)
            if not isinstance(value, str) or not value.strip():
                raise ValueError(f"{field_name} must be a non-empty string.")
        if len(self.program_hash) != 64 or any(
            character not in "0123456789abcdef" for character in self.program_hash
        ):
            raise ValueError("program_hash must be a lowercase SHA-256 hex digest.")
        if not self.nodes:
            raise ValueError("graph nodes must not be empty.")
        node_ids = tuple(node.block_id for node in self.nodes)
        if len(set(node_ids)) != len(node_ids):
            raise ValueError("graph node ids must be unique.")
        if len(set(self.topological_order)) != len(self.topological_order):
            raise ValueError("topological_order must not contain duplicate ids.")
        if set(self.topological_order) != set(node_ids):
            raise ValueError("topological_order must be a permutation of graph nodes.")
        edge_ids: set[str] = set()
        edge_keys: set[tuple[str, str, str]] = set()
        for edge in self.edges:
            if edge.dependency_id in edge_ids:
                raise ValueError("graph dependency ids must be unique.")
            edge_ids.add(edge.dependency_id)
            key = (
                edge.source_block_id,
                edge.target_block_id,
                edge.dependency_type,
            )
            if key in edge_keys:
                raise ValueError("graph typed dependencies must be unique.")
            edge_keys.add(key)
            if (
                edge.source_block_id not in node_ids
                or edge.target_block_id not in node_ids
            ):
                raise ValueError("graph dependency references an unknown node.")
        positions = {
            node_id: index for index, node_id in enumerate(self.topological_order)
        }
        if any(
            positions[edge.source_block_id] >= positions[edge.target_block_id]
            for edge in self.edges
        ):
            raise ValueError("topological_order violates a graph dependency.")
        if not isinstance(self.source_map, SourceMap):
            raise TypeError("source_map must be SourceMap.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> HybridBlockGraphIR:
        """Build a block graph from a dictionary."""
        return cls(
            graph_id=str(data["graph_id"]),
            program_id=str(data["program_id"]),
            program_hash=str(data["program_hash"]),
            nodes=tuple(
                HybridProgramBlock.from_dict(item) for item in data.get("nodes", ())
            ),
            edges=tuple(
                BlockDependency.from_dict(item) for item in data.get("edges", ())
            ),
            topological_order=tuple(
                str(item) for item in data.get("topological_order", ())
            ),
            source_map=SourceMap.from_dict(data.get("source_map", {})),
            metadata=dict(data.get("metadata", {})),
            schema_version=str(
                data.get("schema_version", ORCHESTRATION_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> HybridBlockGraphIR:
        """Build a block graph from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("HybridBlockGraphIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class HybridBlockGraphBuildResult(IRMixin):
    """A graph or the blocking diagnostics that prevented graph construction."""

    graph: HybridBlockGraphIR | None
    diagnostics: tuple[OrchestrationDiagnosticIR, ...] = ()
    schema_version: str = ORCHESTRATION_SCHEMA_VERSION

    @property
    def has_errors(self) -> bool:
        """Return whether graph construction emitted an error."""
        return any(item.severity == "error" for item in self.diagnostics)

    def __post_init__(self) -> None:
        if self.has_errors and self.graph is not None:
            raise ValueError("graph build with errors must not expose a graph.")
        if not self.has_errors and self.graph is None:
            raise ValueError("graph build without errors must expose a graph.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> HybridBlockGraphBuildResult:
        """Build a graph result from a dictionary."""
        graph_data = data.get("graph")
        return cls(
            graph=(
                None
                if graph_data is None
                else HybridBlockGraphIR.from_dict(graph_data)
            ),
            diagnostics=tuple(
                OrchestrationDiagnosticIR.from_dict(item)
                for item in data.get("diagnostics", ())
            ),
            schema_version=str(
                data.get("schema_version", ORCHESTRATION_SCHEMA_VERSION)
            ),
        )


def build_hybrid_block_graph(program: HybridProgram) -> HybridBlockGraphBuildResult:
    """Validate a user program and lower it to a deterministic typed DAG."""
    if not isinstance(program, HybridProgram):
        raise TypeError("program must be HybridProgram.")
    diagnostics = list(program.validate())
    if diagnostics:
        return HybridBlockGraphBuildResult(graph=None, diagnostics=tuple(diagnostics))

    auto_edges = _automatic_edges(program.blocks)
    edges, duplicate_diagnostics = _merge_edges(auto_edges, program.dependencies)
    diagnostics.extend(duplicate_diagnostics)
    if diagnostics:
        return HybridBlockGraphBuildResult(graph=None, diagnostics=tuple(diagnostics))

    topological_order, cycle = _stable_topological_order(program.blocks, edges)
    if cycle:
        return HybridBlockGraphBuildResult(
            graph=None,
            diagnostics=(
                _graph_diagnostic(
                    code="HYBRID_GRAPH_CYCLE",
                    message="Hybrid block dependencies contain a cycle.",
                    object_path="graph.edges",
                    suggestion="Remove backward or cyclic dependencies.",
                    metadata={"cycle_block_ids": cycle},
                ),
            ),
        )

    graph = HybridBlockGraphIR(
        graph_id=f"graph.{program.program_id}",
        program_id=program.program_id,
        program_hash=program.stable_hash(),
        nodes=program.blocks,
        edges=edges,
        topological_order=topological_order,
        source_map=program.source_map,
        metadata={
            "syntax_hash": program.syntax_hash,
            "dependency_counts": _dependency_counts(edges),
            "parallel_quantum_execution": False,
        },
    )
    return HybridBlockGraphBuildResult(graph=graph)


def _automatic_edges(
    blocks: tuple[HybridProgramBlock, ...],
) -> tuple[BlockDependency, ...]:
    edges: list[BlockDependency] = []
    for left, right in zip(blocks, blocks[1:]):
        edges.append(_edge(left, right, "timing", metadata={"automatic": True}))
        if left.block_kind in {"digital", "analog"} and right.block_kind in {
            "digital",
            "analog",
            "measurement",
        }:
            edges.append(
                _edge(left, right, "quantum_state", metadata={"automatic": True})
            )

    source_symbols: dict[str, list[HybridProgramBlock]] = {}
    for block in blocks:
        for argument in block.arguments:
            if argument.source_symbol is not None:
                source_symbols.setdefault(argument.source_symbol, []).append(block)
    for symbol, consumers in sorted(source_symbols.items()):
        for left, right in zip(consumers, consumers[1:]):
            edges.append(
                _edge(
                    left,
                    right,
                    "parameter",
                    metadata={"automatic": True, "symbol": symbol},
                )
            )

    for left_index, left in enumerate(blocks):
        left_targets = set(left.mapping.values())
        for right in blocks[left_index + 1 :]:
            shared_targets = tuple(sorted(left_targets & set(right.mapping.values())))
            if shared_targets:
                edges.append(
                    _edge(
                        left,
                        right,
                        "resource",
                        metadata={
                            "automatic": True,
                            "shared_targets": list(shared_targets),
                        },
                    )
                )
    return tuple(edges)


def _edge(
    source: HybridProgramBlock,
    target: HybridProgramBlock,
    dependency_type: str,
    *,
    metadata: dict[str, Any],
) -> BlockDependency:
    return BlockDependency(
        dependency_id=(
            f"dependency.{dependency_type}.{source.block_id}.{target.block_id}"
        ),
        source_block_id=source.block_id,
        target_block_id=target.block_id,
        dependency_type=dependency_type,  # type: ignore[arg-type]
        source_span=target.source_span,
        metadata=metadata,
    )


def _merge_edges(
    automatic: tuple[BlockDependency, ...],
    explicit: tuple[BlockDependency, ...],
) -> tuple[tuple[BlockDependency, ...], list[OrchestrationDiagnosticIR]]:
    edges: list[BlockDependency] = []
    diagnostics: list[OrchestrationDiagnosticIR] = []
    seen: dict[tuple[str, str, str], BlockDependency] = {}
    for edge in (*automatic, *explicit):
        key = (
            edge.source_block_id,
            edge.target_block_id,
            edge.dependency_type,
        )
        previous = seen.get(key)
        if previous is not None:
            diagnostics.append(
                _graph_diagnostic(
                    code="HYBRID_GRAPH_DUPLICATE_EDGE",
                    message="Graph contains duplicate typed dependency endpoints.",
                    object_path="graph.edges",
                    source_span=edge.source_span,
                    suggestion="Remove the redundant explicit dependency.",
                    metadata={
                        "dependency_id": edge.dependency_id,
                        "existing_dependency_id": previous.dependency_id,
                    },
                )
            )
            continue
        seen[key] = edge
        edges.append(edge)
    index = {
        block_id: position
        for position, block_id in enumerate(
            dict.fromkeys(
                block_id
                for edge in edges
                for block_id in (edge.source_block_id, edge.target_block_id)
            )
        )
    }
    edges.sort(
        key=lambda edge: (
            index[edge.source_block_id],
            index[edge.target_block_id],
            _DEPENDENCY_ORDER[edge.dependency_type],
            edge.dependency_id,
        )
    )
    return tuple(edges), diagnostics


def _stable_topological_order(
    blocks: tuple[HybridProgramBlock, ...],
    edges: tuple[BlockDependency, ...],
) -> tuple[tuple[str, ...], tuple[str, ...]]:
    block_order = {block.block_id: index for index, block in enumerate(blocks)}
    successors: dict[str, set[str]] = {block.block_id: set() for block in blocks}
    indegree = {block.block_id: 0 for block in blocks}
    for edge in edges:
        if edge.target_block_id not in successors[edge.source_block_id]:
            successors[edge.source_block_id].add(edge.target_block_id)
            indegree[edge.target_block_id] += 1
    ready = sorted(
        (block_id for block_id, degree in indegree.items() if degree == 0),
        key=block_order.__getitem__,
    )
    ordered: list[str] = []
    while ready:
        block_id = ready.pop(0)
        ordered.append(block_id)
        for successor in sorted(
            successors[block_id], key=block_order.__getitem__
        ):
            indegree[successor] -= 1
            if indegree[successor] == 0:
                ready.append(successor)
                ready.sort(key=block_order.__getitem__)
    if len(ordered) == len(blocks):
        return tuple(ordered), ()
    cycle = tuple(
        block.block_id for block in blocks if block.block_id not in set(ordered)
    )
    return (), cycle


def _dependency_counts(edges: tuple[BlockDependency, ...]) -> dict[str, int]:
    counts = {dependency_type: 0 for dependency_type in _DEPENDENCY_ORDER}
    for edge in edges:
        counts[edge.dependency_type] += 1
    return counts


def _graph_diagnostic(
    *,
    code: str,
    message: str,
    object_path: str,
    source_span: SourceSpan | None = None,
    suggestion: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> OrchestrationDiagnosticIR:
    suffix = code.lower().removeprefix("hybrid_").replace("_", ".")
    return OrchestrationDiagnosticIR(
        diagnostic_id=f"orchestration.{suffix}",
        stage="orchestration",
        severity="error",
        code=code,
        message=message,
        object_path=object_path,
        source_span=source_span,
        suggestion=suggestion,
        metadata={} if metadata is None else metadata,
    )
