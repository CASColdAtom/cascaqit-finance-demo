"""Structured SDK error IR contracts."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Literal

from cascaqit.backends.config import BackendErrorIR
from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.diagnostics.models import DiagnosticSeverity, DiagnosticStage
from cascaqit.native_ir.base import IRMixin, canonicalize
from cascaqit.native_ir.models import SCHEMA_VERSION
from cascaqit.readiness.audit import redact_audit_metadata

__all__ = [
    "ErrorIR",
    "ErrorCategory",
    "ErrorSeverity",
    "build_error_from_backend_error",
    "build_error_from_diagnostic",
    "diagnostic_from_error",
]

ErrorCategory = Literal[
    "validation",
    "discretization",
    "compilation",
    "simulation",
    "serialization",
    "backend",
    "runtime",
    "configuration",
    "capability",
    "calibration",
    "unknown",
]
ErrorSeverity = Literal["info", "warning", "error", "critical"]

_CATEGORY_BY_DIAGNOSTIC_STAGE: dict[str, ErrorCategory] = {
    "validation": "validation",
    "discretization": "discretization",
    "compilation": "compilation",
    "simulation": "simulation",
    "serialization": "serialization",
}
_CATEGORY_BY_BACKEND_ERROR: dict[str, ErrorCategory] = {
    "configuration": "configuration",
    "transport": "backend",
    "submission": "backend",
    "status": "backend",
    "result": "backend",
    "cancellation": "runtime",
    "capability": "capability",
    "calibration": "calibration",
    "unknown": "unknown",
}
_DIAGNOSTIC_STAGE_BY_ERROR_STAGE: dict[str, DiagnosticStage] = {
    "validation": "validation",
    "discretization": "discretization",
    "compilation": "compilation",
    "simulation": "simulation",
    "serialization": "serialization",
}


@dataclass(frozen=True)
class ErrorIR(IRMixin):
    """Structured, serializable user-visible error contract."""

    error_id: str
    category: ErrorCategory
    severity: ErrorSeverity
    code: str
    message: str
    stage: str | None = None
    object_path: str | None = None
    suggestion: str | None = None
    retryable: bool = False
    trace_references: dict[str, Any] = field(default_factory=dict)
    source_hashes: dict[str, Any] = field(default_factory=dict)
    source: dict[str, Any] = field(default_factory=dict)
    diagnostics: tuple[DiagnosticsIR, ...] = ()
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize nested payloads and redact sensitive metadata."""
        object.__setattr__(
            self,
            "trace_references",
            redact_audit_metadata(dict(self.trace_references)),
        )
        object.__setattr__(
            self,
            "source_hashes",
            redact_audit_metadata(dict(self.source_hashes)),
        )
        object.__setattr__(self, "source", redact_audit_metadata(dict(self.source)))
        object.__setattr__(
            self,
            "diagnostics",
            tuple(_diagnostic_from_any(item) for item in self.diagnostics),
        )
        object.__setattr__(self, "metadata", redact_audit_metadata(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ErrorIR:
        """Build an error IR from a dictionary."""
        if not isinstance(data, dict):
            raise TypeError("ErrorIR dictionary payload must be an object.")
        return cls(
            error_id=str(data["error_id"]),
            category=data["category"],
            severity=data["severity"],
            code=str(data["code"]),
            message=str(data["message"]),
            stage=data.get("stage"),
            object_path=data.get("object_path"),
            suggestion=data.get("suggestion"),
            retryable=bool(data.get("retryable", False)),
            trace_references=dict(data.get("trace_references", {})),
            source_hashes=dict(data.get("source_hashes", {})),
            source=dict(data.get("source", {})),
            diagnostics=tuple(
                _diagnostic_from_any(item) for item in data.get("diagnostics", ())
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> ErrorIR:
        """Build an error IR from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("ErrorIR JSON must contain an object.")
        return cls.from_dict(data)


def build_error_from_diagnostic(
    diagnostic: DiagnosticsIR,
    *,
    error_id: str | None = None,
    retryable: bool = False,
    trace_references: dict[str, Any] | None = None,
    source_hashes: dict[str, Any] | None = None,
    metadata: dict[str, Any] | None = None,
) -> ErrorIR:
    """Convert a diagnostic into a structured error IR."""
    if not isinstance(diagnostic, DiagnosticsIR):
        raise TypeError("diagnostic must be DiagnosticsIR.")
    return ErrorIR(
        error_id=error_id or f"error.{diagnostic.diagnostic_id}",
        category=_CATEGORY_BY_DIAGNOSTIC_STAGE.get(diagnostic.stage, "unknown"),
        severity=_severity_from_diagnostic(diagnostic.severity),
        code=diagnostic.code,
        message=diagnostic.message,
        stage=diagnostic.stage,
        object_path=diagnostic.object_path,
        suggestion=diagnostic.suggestion,
        retryable=retryable,
        trace_references={} if trace_references is None else trace_references,
        source_hashes={} if source_hashes is None else source_hashes,
        source={
            "source_kind": "DiagnosticsIR",
            "source_id": diagnostic.diagnostic_id,
            "source_hash": diagnostic.stable_hash(),
        },
        diagnostics=(diagnostic,),
        metadata={
            "builder": "build_error_from_diagnostic",
            "diagnostic_metadata": canonicalize(diagnostic.metadata),
            **({} if metadata is None else metadata),
        },
    )


def build_error_from_backend_error(
    backend_error: BackendErrorIR,
    *,
    error_id: str | None = None,
    stage: str = "backend",
    object_path: str | None = None,
    suggestion: str | None = None,
    trace_references: dict[str, Any] | None = None,
    source_hashes: dict[str, Any] | None = None,
    metadata: dict[str, Any] | None = None,
) -> ErrorIR:
    """Convert a backend error into a redacted structured error IR."""
    if not isinstance(backend_error, BackendErrorIR):
        raise TypeError("backend_error must be BackendErrorIR.")
    redacted = backend_error.redacted()
    diagnostic = _diagnostic_from_backend_error(
        redacted,
        stage=stage,
        object_path=object_path,
        suggestion=suggestion,
    )
    return ErrorIR(
        error_id=error_id or redacted.error_id,
        category=_CATEGORY_BY_BACKEND_ERROR.get(redacted.category, "backend"),
        severity="error",
        code=redacted.code,
        message=redacted.message,
        stage=stage,
        object_path=object_path,
        suggestion=suggestion,
        retryable=redacted.retryable,
        trace_references={} if trace_references is None else trace_references,
        source_hashes={} if source_hashes is None else source_hashes,
        source={
            "source_kind": "BackendErrorIR",
            "source_id": redacted.error_id,
            "source_hash": redacted.stable_hash(),
            "backend_id": redacted.backend_id,
            "backend_category": redacted.category,
        },
        diagnostics=(diagnostic,),
        metadata={
            "builder": "build_error_from_backend_error",
            "backend_error": redacted.to_dict(),
            **({} if metadata is None else metadata),
        },
    )


def diagnostic_from_error(error: ErrorIR) -> DiagnosticsIR:
    """Convert structured ErrorIR back into a diagnostic view."""
    if not isinstance(error, ErrorIR):
        raise TypeError("error must be ErrorIR.")
    return DiagnosticsIR(
        diagnostic_id=f"diagnostic.{error.error_id}",
        stage=_diagnostic_stage(error.stage),
        severity=_diagnostic_severity(error.severity),
        code=error.code,
        message=error.message,
        object_path=error.object_path,
        suggestion=error.suggestion,
        metadata={
            "source_error_id": error.error_id,
            "category": error.category,
            "retryable": error.retryable,
            "trace_references": canonicalize(error.trace_references),
            "source_hashes": canonicalize(error.source_hashes),
        },
    )


def _diagnostic_from_backend_error(
    error: BackendErrorIR,
    *,
    stage: str,
    object_path: str | None,
    suggestion: str | None,
) -> DiagnosticsIR:
    return DiagnosticsIR(
        diagnostic_id=f"backend_error.{error.error_id}",
        stage=_diagnostic_stage(stage),
        severity="error",
        code=error.code,
        message=error.message,
        object_path=object_path,
        suggestion=suggestion,
        metadata={
            "backend_id": error.backend_id,
            "backend_category": error.category,
            "retryable": error.retryable,
            "raw_error": canonicalize(error.raw_error),
        },
    )


def _severity_from_diagnostic(severity: str) -> ErrorSeverity:
    if severity == "error":
        return "error"
    if severity == "warning":
        return "warning"
    return "info"


def _diagnostic_severity(severity: ErrorSeverity) -> DiagnosticSeverity:
    if severity == "critical":
        return "error"
    if severity == "error":
        return "error"
    if severity == "warning":
        return "warning"
    return "info"


def _diagnostic_stage(stage: str | None) -> DiagnosticStage:
    if stage is None:
        return "serialization"
    return _DIAGNOSTIC_STAGE_BY_ERROR_STAGE.get(stage, "serialization")


def _diagnostic_from_any(item: DiagnosticsIR | dict[str, Any]) -> DiagnosticsIR:
    if isinstance(item, DiagnosticsIR):
        return item
    if isinstance(item, dict):
        return DiagnosticsIR.from_dict(item)
    raise TypeError("diagnostics entries must be DiagnosticsIR or dictionaries.")
