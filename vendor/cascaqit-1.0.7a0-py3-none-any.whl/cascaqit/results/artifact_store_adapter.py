"""Replayable artifact store adapter SPI contracts."""

from __future__ import annotations

import json
from dataclasses import dataclass, field, replace
from typing import Any, Literal, Protocol
from urllib.parse import urlsplit, urlunsplit

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.native_ir.base import IRMixin, canonicalize
from cascaqit.native_ir.models import SCHEMA_VERSION
from cascaqit.results.artifact_store import (
    ArtifactStoreError,
    ArtifactStoreRecordIR,
)
from cascaqit.results.models import ArtifactRefIR

__all__ = [
    "ArtifactByteTransferPreflightIR",
    "ArtifactStoreAdapterProtocol",
    "FixtureReplayArtifactStoreAdapter",
    "build_artifact_byte_transfer_preflight",
    "redact_artifact_ref_for_adapter",
]

ArtifactByteTransferStatus = Literal["blocked", "ready"]
_SECRET_KEY_MARKERS = (
    "access_key",
    "api_key",
    "apikey",
    "authorization",
    "credential",
    "password",
    "private_key",
    "secret",
    "signature",
    "token",
    "x-amz",
)


class ArtifactStoreAdapterProtocol(Protocol):
    """Future artifact store SPI over metadata-first artifact records."""

    def list_metadata(
        self,
        *,
        artifact_kind: str | None = None,
        include_expired: bool = False,
    ) -> tuple[ArtifactStoreRecordIR, ...]:
        """List artifact metadata without reading artifact bytes."""

    def head_metadata(self, artifact_id: str) -> ArtifactStoreRecordIR:
        """Return public metadata for an artifact without a byte transfer."""

    def get_metadata(self, artifact_id: str) -> ArtifactStoreRecordIR:
        """Return public metadata for an artifact without a byte transfer."""

    def get_bytes(
        self,
        artifact_id: str,
        *,
        byte_transfer_enabled: bool = False,
        expected_checksum: str | None = None,
    ) -> ArtifactByteTransferPreflightIR:
        """Return a byte-transfer preflight marker, not artifact bytes."""


@dataclass(frozen=True)
class ArtifactByteTransferPreflightIR(IRMixin):
    """Public artifact byte-transfer preflight report.

    The default fixture/replay contract never reads bytes. A future live
    implementation can use the same report shape before performing an explicit
    opt-in transfer outside deterministic tests.
    """

    preflight_id: str
    artifact_id: str
    status: ArtifactByteTransferStatus
    byte_transfer_requested: bool
    byte_transfer_enabled: bool
    diagnostics: tuple[DiagnosticsIR, ...]
    checksum_verified: bool = False
    checksum_match: bool | None = None
    artifact_bytes_read: bool = False
    network_accessed: bool = False
    signed_url_exported: bool = False
    raw_secret_loaded: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Enforce deterministic metadata-only preflight boundaries."""
        if self.artifact_bytes_read:
            raise ValueError("Artifact byte preflight cannot read artifact bytes.")
        if self.network_accessed:
            raise ValueError("Artifact byte preflight cannot access networks.")
        if self.signed_url_exported:
            raise ValueError("Artifact byte preflight cannot export signed URLs.")
        if self.raw_secret_loaded:
            raise ValueError("Artifact byte preflight cannot load raw secrets.")
        object.__setattr__(
            self,
            "diagnostics",
            tuple(_diagnostic_from_any(item) for item in self.diagnostics),
        )
        object.__setattr__(self, "metadata", _redact_mapping(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ArtifactByteTransferPreflightIR:
        """Build an artifact byte-transfer preflight report from a dictionary."""
        return cls(
            preflight_id=str(data["preflight_id"]),
            artifact_id=str(data["artifact_id"]),
            status=data["status"],
            byte_transfer_requested=bool(data["byte_transfer_requested"]),
            byte_transfer_enabled=bool(data["byte_transfer_enabled"]),
            diagnostics=tuple(
                _diagnostic_from_any(item) for item in data.get("diagnostics", ())
            ),
            checksum_verified=bool(data.get("checksum_verified", False)),
            checksum_match=data.get("checksum_match"),
            artifact_bytes_read=bool(data.get("artifact_bytes_read", False)),
            network_accessed=bool(data.get("network_accessed", False)),
            signed_url_exported=bool(data.get("signed_url_exported", False)),
            raw_secret_loaded=bool(data.get("raw_secret_loaded", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> ArtifactByteTransferPreflightIR:
        """Build an artifact byte-transfer preflight report from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("ArtifactByteTransferPreflightIR JSON must be an object.")
        return cls.from_dict(data)


class FixtureReplayArtifactStoreAdapter:
    """Deterministic metadata-only adapter backed by local artifact records."""

    def __init__(
        self,
        *,
        records: tuple[ArtifactStoreRecordIR, ...],
        current_time: str = "offline",
    ) -> None:
        self.current_time = current_time
        self._records = {
            record.artifact.artifact_id: _public_record(record)
            for record in records
        }
        self.byte_preflights: list[ArtifactByteTransferPreflightIR] = []

    def list_metadata(
        self,
        *,
        artifact_kind: str | None = None,
        include_expired: bool = False,
    ) -> tuple[ArtifactStoreRecordIR, ...]:
        """List public artifact metadata with optional filters."""
        records = []
        for record in self._records.values():
            if (
                artifact_kind is not None
                and record.artifact.artifact_kind != artifact_kind
            ):
                continue
            if not include_expired and _is_expired(
                record.artifact,
                current_time=self.current_time,
            ):
                continue
            records.append(record)
        return tuple(
            sorted(records, key=lambda record: record.artifact.artifact_id)
        )

    def head_metadata(self, artifact_id: str) -> ArtifactStoreRecordIR:
        """Return public metadata for an artifact without reading bytes."""
        return self.get_metadata(artifact_id)

    def get_metadata(self, artifact_id: str) -> ArtifactStoreRecordIR:
        """Return public metadata for an artifact without reading bytes."""
        if artifact_id not in self._records:
            raise ArtifactStoreError(
                f"Unknown artifact_id: {artifact_id}",
                diagnostics=(
                    _diagnostic(
                        diagnostic_id=f"artifact_adapter.{artifact_id}.missing",
                        code="ARTIFACT_METADATA_MISSING",
                        message="Artifact metadata is not present in this adapter.",
                        object_path="artifact_id",
                        severity="error",
                    ),
                ),
            )
        return self._records[artifact_id]

    def get_bytes(
        self,
        artifact_id: str,
        *,
        byte_transfer_enabled: bool = False,
        expected_checksum: str | None = None,
    ) -> ArtifactByteTransferPreflightIR:
        """Return a byte-transfer preflight report, never artifact bytes."""
        record = self.get_metadata(artifact_id)
        preflight = build_artifact_byte_transfer_preflight(
            record,
            byte_transfer_enabled=byte_transfer_enabled,
            expected_checksum=expected_checksum,
            current_time=self.current_time,
        )
        self.byte_preflights.append(preflight)
        return preflight


def build_artifact_byte_transfer_preflight(
    record: ArtifactStoreRecordIR,
    *,
    byte_transfer_enabled: bool = False,
    expected_checksum: str | None = None,
    current_time: str = "offline",
) -> ArtifactByteTransferPreflightIR:
    """Build an explicit byte-transfer preflight without reading bytes."""
    public_record = _public_record(record)
    artifact = public_record.artifact
    diagnostics = list(public_record.diagnostics)
    diagnostics.extend(
        _byte_transfer_diagnostics(
            artifact,
            byte_transfer_enabled=byte_transfer_enabled,
            expected_checksum=expected_checksum,
            current_time=current_time,
        )
    )
    checksum_match = None
    if expected_checksum is not None:
        checksum_match = artifact.checksum == expected_checksum
    return ArtifactByteTransferPreflightIR(
        preflight_id=f"artifact_byte_transfer.{artifact.artifact_id}",
        artifact_id=artifact.artifact_id,
        status="ready" if byte_transfer_enabled else "blocked",
        byte_transfer_requested=True,
        byte_transfer_enabled=byte_transfer_enabled,
        diagnostics=tuple(diagnostics),
        checksum_verified=expected_checksum is not None,
        checksum_match=checksum_match,
        artifact_bytes_read=False,
        network_accessed=False,
        signed_url_exported=False,
        raw_secret_loaded=False,
        metadata={
            "metadata_only": True,
            "redacted_storage_uri": artifact.storage_uri,
            "byte_transfer_adapter": "fixture_replay",
        },
    )


def redact_artifact_ref_for_adapter(artifact: ArtifactRefIR) -> ArtifactRefIR:
    """Return a public artifact ref with signed URL details removed."""
    return replace(
        artifact,
        storage_uri=_redact_storage_uri(artifact.storage_uri),
        metadata=_redact_mapping(artifact.metadata),
    )


def _public_record(record: ArtifactStoreRecordIR) -> ArtifactStoreRecordIR:
    return replace(
        record,
        artifact=redact_artifact_ref_for_adapter(record.artifact),
        diagnostics=tuple(_diagnostic_from_any(item) for item in record.diagnostics),
        metadata=_redact_mapping(
            {
                **record.metadata,
                "metadata_only": True,
                "signed_url_exported": False,
                "artifact_bytes_read": False,
            }
        ),
    )


def _byte_transfer_diagnostics(
    artifact: ArtifactRefIR,
    *,
    byte_transfer_enabled: bool,
    expected_checksum: str | None,
    current_time: str,
) -> tuple[DiagnosticsIR, ...]:
    diagnostics: list[DiagnosticsIR] = [
        _diagnostic(
            diagnostic_id=f"artifact_adapter.{artifact.artifact_id}.byte_transfer",
            code=(
                "ARTIFACT_BYTE_TRANSFER_READY"
                if byte_transfer_enabled
                else "ARTIFACT_BYTE_TRANSFER_DISABLED"
            ),
            message=(
                "Artifact byte transfer was explicitly enabled for preflight only."
                if byte_transfer_enabled
                else "Artifact byte transfer is disabled by the fixture adapter."
            ),
            object_path="artifact",
            severity="info" if byte_transfer_enabled else "warning",
        )
    ]
    if expected_checksum is not None and artifact.checksum != expected_checksum:
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"artifact_adapter.{artifact.artifact_id}.checksum",
                code="ARTIFACT_BYTE_CHECKSUM_MISMATCH",
                message="Expected checksum does not match artifact metadata.",
                object_path="artifact.checksum",
                severity="error",
                metadata={
                    "expected_checksum": expected_checksum,
                    "actual_checksum": artifact.checksum,
                },
            )
        )
    if _is_expired(artifact, current_time=current_time):
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"artifact_adapter.{artifact.artifact_id}.expired",
                code="ARTIFACT_EXPIRED",
                message="Artifact metadata is expired.",
                object_path="artifact.expires_at",
                severity="error",
                metadata={"expires_at": artifact.expires_at},
            )
        )
    return tuple(diagnostics)


def _redact_storage_uri(storage_uri: str) -> str:
    parts = urlsplit(storage_uri)
    if not parts.query:
        return storage_uri
    redacted_query = tuple(
        query_part
        for query_part in parts.query.split("&")
        if not _is_secret_key(query_part.split("=", 1)[0])
    )
    query = "&".join(redacted_query)
    if query != parts.query:
        return urlunsplit((parts.scheme, parts.netloc, parts.path, query, ""))
    return storage_uri


def _redact_mapping(value: dict[str, Any]) -> dict[str, Any]:
    redacted: dict[str, Any] = {}
    for key, item in canonicalize(value).items():
        if _is_secret_key(key):
            redacted[key] = "[REDACTED]"
        elif isinstance(item, dict):
            redacted[key] = _redact_mapping(item)
        elif isinstance(item, str) and _looks_like_signed_url(item):
            redacted[key] = _redact_storage_uri(item)
        else:
            redacted[key] = item
    return redacted


def _looks_like_signed_url(value: str) -> bool:
    return "://" in value and "?" in value


def _is_secret_key(key: str) -> bool:
    lowered = key.lower()
    return any(marker in lowered for marker in _SECRET_KEY_MARKERS)


def _diagnostic(
    *,
    diagnostic_id: str,
    code: str,
    message: str,
    object_path: str,
    severity: Literal["info", "warning", "error"],
    metadata: dict[str, Any] | None = None,
) -> DiagnosticsIR:
    return DiagnosticsIR(
        diagnostic_id=diagnostic_id,
        stage="serialization",
        severity=severity,
        code=code,
        message=message,
        object_path=object_path,
        metadata={} if metadata is None else _redact_mapping(metadata),
    )


def _diagnostic_from_any(value: Any) -> DiagnosticsIR:
    if isinstance(value, DiagnosticsIR):
        return value
    if isinstance(value, dict):
        return DiagnosticsIR.from_dict(value)
    raise TypeError("diagnostics must contain DiagnosticsIR values.")


def _is_expired(artifact: ArtifactRefIR, *, current_time: str) -> bool:
    if artifact.expires_at is None or current_time == "offline":
        return False
    return artifact.expires_at < current_time
