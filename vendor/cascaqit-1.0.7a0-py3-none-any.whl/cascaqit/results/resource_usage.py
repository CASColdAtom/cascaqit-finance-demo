"""Process-level resource measurement for synchronous local simulation."""

from __future__ import annotations

import sys
import time
from dataclasses import dataclass
from typing import Literal

from cascaqit.results.models import SimulationResourceUsageIR

__all__ = [
    "LocalResourceMeasurement",
    "estimated_peak_bytes_from_metadata",
]


def _process_peak_rss_bytes() -> int | None:
    """Return the process high-water RSS using the host's native unit."""
    try:
        import resource
    except ImportError:  # pragma: no cover - exercised only on non-POSIX hosts.
        return None
    peak = int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    # Darwin reports bytes; Linux and the other supported POSIX hosts report KiB.
    return peak if sys.platform == "darwin" else peak * 1024


@dataclass(frozen=True)
class LocalResourceMeasurement:
    """Start snapshot used to derive one immutable resource-usage report."""

    started_at: float
    baseline_peak_rss_bytes: int | None

    @classmethod
    def start(cls) -> LocalResourceMeasurement:
        """Capture time and process high-water RSS immediately before execution."""
        return cls(
            started_at=time.perf_counter(),
            baseline_peak_rss_bytes=_process_peak_rss_bytes(),
        )

    def finish(
        self,
        *,
        measurement_scope: Literal["job", "scan", "scan_item"],
        estimated_peak_bytes: int | None,
        rss_owned_by_parent_scan: bool = False,
    ) -> SimulationResourceUsageIR:
        """Finish measurement without claiming memory that cannot be attributed."""
        wall_time = max(0.0, time.perf_counter() - self.started_at)
        if rss_owned_by_parent_scan:
            # Concurrent points share one process high-water mark. Only the parent
            # scan can own that observation without double-counting memory.
            return SimulationResourceUsageIR(
                measurement_scope=measurement_scope,
                wall_time_seconds=wall_time,
                actual_peak_rss_bytes=None,
                baseline_peak_rss_bytes=None,
                incremental_peak_rss_bytes=None,
                estimated_peak_bytes=estimated_peak_bytes,
                estimate_error_fraction=None,
                estimate_within_tolerance=None,
                measurement_status="owned_by_parent_scan",
                rss_semantics="owned_by_parent_scan",
            )

        actual_peak = _process_peak_rss_bytes()
        baseline_peak = self.baseline_peak_rss_bytes
        if actual_peak is None or baseline_peak is None:
            return SimulationResourceUsageIR(
                measurement_scope=measurement_scope,
                wall_time_seconds=wall_time,
                actual_peak_rss_bytes=None,
                baseline_peak_rss_bytes=None,
                incremental_peak_rss_bytes=None,
                estimated_peak_bytes=estimated_peak_bytes,
                estimate_error_fraction=None,
                estimate_within_tolerance=None,
                measurement_status="rss_unavailable",
                rss_semantics="unavailable",
            )

        incremental_peak = max(0, actual_peak - baseline_peak)
        status: Literal[
            "measured",
            "baseline_dominated",
            "estimate_unavailable",
        ]
        if estimated_peak_bytes is None:
            status = "estimate_unavailable"
            estimate_error = None
            within_tolerance = None
        elif incremental_peak == 0:
            # A process high-water mark can be dominated by earlier work. Zero
            # growth is not evidence that this execution allocated no memory.
            status = "baseline_dominated"
            estimate_error = None
            within_tolerance = None
        else:
            status = "measured"
            estimate_error = (
                abs(estimated_peak_bytes - incremental_peak) / incremental_peak
            )
            within_tolerance = estimate_error <= 0.2
        return SimulationResourceUsageIR(
            measurement_scope=measurement_scope,
            wall_time_seconds=wall_time,
            actual_peak_rss_bytes=actual_peak,
            baseline_peak_rss_bytes=baseline_peak,
            incremental_peak_rss_bytes=incremental_peak,
            estimated_peak_bytes=estimated_peak_bytes,
            estimate_error_fraction=estimate_error,
            estimate_within_tolerance=within_tolerance,
            measurement_status=status,
            rss_semantics="process_high_water_mark",
        )


def estimated_peak_bytes_from_metadata(metadata: dict[str, object]) -> int | None:
    """Read the canonical planner estimate without accepting bool as an integer."""
    estimate = metadata.get("simulation_resource_estimate")
    if not isinstance(estimate, dict):
        return None
    value = estimate.get("estimated_peak_bytes")
    if not isinstance(value, int) or isinstance(value, bool) or value < 0:
        return None
    return value
