"""Result IR models."""

from __future__ import annotations

import json
import math
from dataclasses import dataclass, field, replace
from typing import Any, Literal

from cascaqit.backends.job_state import JobState, validate_job_state
from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.native_ir.base import IRMixin
from cascaqit.native_ir.models import (
    SCHEMA_VERSION,
    UNSPECIFIED_BIT_ORDER_CONVENTION,
    OccupationEncoding,
)
from cascaqit.observables import ObservableBatchResultIR

__all__ = [
    "ArtifactRefIR",
    "BatchItemResultRefIR",
    "BatchResultIR",
    "ResultIR",
    "ResultReferencesIR",
    "RunTraceEventIR",
    "RunTraceIR",
    "StateTransitionIR",
    "SimulationExecutionConfigIR",
    "SimulationResourceUsageIR",
    "SimulationSolverEvidenceIR",
    "simulation_solver_evidence_from_metadata",
    "simulation_execution_config_from_metadata",
    "resource_usage_from_metadata",
    "result_references_from_metadata",
    "result_references_projection_matches_metadata",
    "result_references_from_result",
    "state_transitions_from_metadata",
    "validate_state_transition_chain",
]

SimulationExecutionScope = Literal["job", "scan", "scan_item"]
SimulationWorkerSemantics = Literal["kernel_concurrency", "scan_concurrency"]
SimulationSeedSemantics = Literal[
    "effective_seed",
    "root_seed",
    "derived_scan_seed",
]
SimulationStepSemantics = Literal[
    "not_applicable",
    "adaptive_accepted_steps",
    "fixed_time_slices",
]
SimulationIntegratorRequest = Literal[
    "auto",
    "adaptive_dop853",
    "fixed_step_krylov",
]
SimulationIntegratorSelection = Literal[
    "not_applicable",
    "adaptive_dop853",
    "fixed_step_krylov",
]
SimulationSolverTermination = Literal[
    "completed",
    "not_applicable",
    "max_steps_exceeded",
    "solver_failed",
]

ResourceMeasurementScope = Literal["job", "scan", "scan_item"]
ResourceMeasurementStatus = Literal[
    "measured",
    "baseline_dominated",
    "estimate_unavailable",
    "rss_unavailable",
    "owned_by_parent_scan",
]

ArtifactKind = Literal[
    "raw_hardware_result",
    "raw_cloud_result",
    "executor_log",
    "compiled_payload",
    "calibration_snapshot",
    "target_snapshot",
    "other",
]

_RESULT_SECRET_KEY_MARKERS = (
    "access_key",
    "api_key",
    "apikey",
    "authorization",
    "credential",
    "password",
    "private_key",
    "secret",
    "token",
)


@dataclass(frozen=True)
class ArtifactRefIR(IRMixin):
    """Reference to a large or external execution artifact."""

    artifact_id: str
    artifact_kind: ArtifactKind
    storage_uri: str
    checksum: str
    size_bytes: int
    content_type: str
    retention_policy: str
    created_at: str | None = None
    expires_at: str | None = None
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Redact secret-like artifact metadata."""
        object.__setattr__(self, "metadata", _redact_result_mapping(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ArtifactRefIR:
        """Build an artifact reference from a JSON-compatible dictionary."""
        return cls(
            artifact_id=str(data["artifact_id"]),
            artifact_kind=data["artifact_kind"],
            storage_uri=str(data["storage_uri"]),
            checksum=str(data["checksum"]),
            size_bytes=int(data["size_bytes"]),
            content_type=str(data["content_type"]),
            retention_policy=str(data["retention_policy"]),
            created_at=data.get("created_at"),
            expires_at=data.get("expires_at"),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> ArtifactRefIR:
        """Build an artifact reference from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("ArtifactRefIR JSON must contain an object.")
        return cls.from_dict(data)

RunTraceStage = Literal[
    "draft",
    "bound",
    "validated",
    "discretized",
    "compiled",
    "packaged",
    "queued",
    "running",
    "completed",
    "failed",
    "cancelled",
]


@dataclass(frozen=True)
class ResultReferencesIR(IRMixin):
    """Hashes and snapshot references needed to reproduce a result."""

    program_hash: str
    plan_hash: str | None = None
    bundle_hash: str | None = None
    initial_state_hash: str | None = None
    final_state_hash: str | None = None
    discretized_program_hash: str | None = None
    compiled_program_hash: str | None = None
    execution_package_id: str | None = None
    target_snapshot_hash: str | None = None
    calibration_snapshot_hash: str | None = None
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Redact secret-like reproducibility metadata."""
        object.__setattr__(self, "metadata", _redact_result_mapping(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ResultReferencesIR:
        """Build result references from a JSON-compatible dictionary."""
        return cls(
            program_hash=str(data["program_hash"]),
            plan_hash=data.get("plan_hash"),
            bundle_hash=data.get("bundle_hash"),
            initial_state_hash=data.get("initial_state_hash"),
            final_state_hash=data.get("final_state_hash"),
            discretized_program_hash=data.get("discretized_program_hash"),
            compiled_program_hash=data.get("compiled_program_hash"),
            execution_package_id=data.get("execution_package_id"),
            target_snapshot_hash=data.get("target_snapshot_hash"),
            calibration_snapshot_hash=data.get("calibration_snapshot_hash"),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )


@dataclass(frozen=True)
class StateTransitionIR(IRMixin):
    """Canonical amplitude-free evidence for one quantum-state transition."""

    transition_id: str
    order_index: int
    block_id: str
    program_kind: Literal["digital", "analog"]
    program_hash: str
    kernel: str
    input_state_hash: str
    output_state_hash: str
    input_logical_time: float
    output_logical_time: float
    time_unit: str
    solver_evidence_hash: str
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = SCHEMA_VERSION

    def __post_init__(self) -> None:
        for field_name in ("transition_id", "block_id", "kernel", "time_unit"):
            value = getattr(self, field_name)
            if not isinstance(value, str) or not value.strip():
                raise ValueError(f"{field_name} must be a non-empty string.")
        if (
            not isinstance(self.order_index, int)
            or isinstance(self.order_index, bool)
            or self.order_index < 0
        ):
            raise ValueError("order_index must be a non-negative integer.")
        if self.program_kind not in {"digital", "analog"}:
            raise ValueError("program_kind must be digital or analog.")
        for field_name in (
            "program_hash",
            "input_state_hash",
            "output_state_hash",
            "solver_evidence_hash",
        ):
            _require_sha256(getattr(self, field_name), field_name)
        for field_name in ("input_logical_time", "output_logical_time"):
            value = getattr(self, field_name)
            if (
                not isinstance(value, (int, float))
                or isinstance(value, bool)
                or not math.isfinite(value)
                or value < 0.0
            ):
                raise ValueError(f"{field_name} must be finite and non-negative.")
            object.__setattr__(self, field_name, float(value))
        if self.output_logical_time < self.input_logical_time:
            raise ValueError("State transition logical time cannot move backwards.")
        if not isinstance(self.metadata, dict):
            raise TypeError("metadata must be a dictionary.")
        if (
            self.program_kind == "digital"
            and self.output_logical_time != self.input_logical_time
            and self.metadata.get("time_advance_source") != "noise_model"
        ):
            raise ValueError("Digital transition must not advance logical time.")
        if (
            self.program_kind == "analog"
            and self.output_logical_time <= self.input_logical_time
        ):
            raise ValueError("Analog transition must advance logical time.")
        object.__setattr__(self, "metadata", _redact_result_mapping(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> StateTransitionIR:
        """Build one state transition from JSON-compatible data."""
        return cls(
            transition_id=str(data["transition_id"]),
            order_index=data["order_index"],
            block_id=str(data["block_id"]),
            program_kind=data["program_kind"],
            program_hash=str(data["program_hash"]),
            kernel=str(data["kernel"]),
            input_state_hash=str(data["input_state_hash"]),
            output_state_hash=str(data["output_state_hash"]),
            input_logical_time=data["input_logical_time"],
            output_logical_time=data["output_logical_time"],
            time_unit=str(data["time_unit"]),
            solver_evidence_hash=str(data["solver_evidence_hash"]),
            metadata=dict(data.get("metadata", {})),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
        )

    @classmethod
    def from_json(cls, text: str) -> StateTransitionIR:
        """Build one state transition from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("StateTransitionIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class RunTraceEventIR(IRMixin):
    """A minimal lifecycle trace event for a local or backend run."""

    stage: RunTraceStage
    event_time: str
    status: str
    schema_version: str = SCHEMA_VERSION
    message: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Redact secret-like trace event metadata."""
        object.__setattr__(self, "metadata", _redact_result_mapping(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> RunTraceEventIR:
        """Build a run trace event from a JSON-compatible dictionary."""
        return cls(
            stage=data["stage"],
            event_time=str(data["event_time"]),
            status=str(data["status"]),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            message=data.get("message"),
            metadata=dict(data.get("metadata", {})),
        )


@dataclass(frozen=True)
class RunTraceIR(IRMixin):
    """Minimal run trace associated with a ResultIR."""

    trace_id: str
    events: tuple[RunTraceEventIR, ...]
    references: ResultReferencesIR
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Redact secret-like trace metadata."""
        object.__setattr__(self, "metadata", _redact_result_mapping(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> RunTraceIR:
        """Build a run trace from a JSON-compatible dictionary."""
        return cls(
            trace_id=str(data["trace_id"]),
            events=tuple(
                RunTraceEventIR.from_dict(event)
                for event in data.get("events", ())
            ),
            references=ResultReferencesIR.from_dict(data["references"]),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )


@dataclass(frozen=True)
class SimulationSolverEvidenceIR(IRMixin):
    """Executed integrator statistics without inferred or planning-only values."""

    integrator_requested: SimulationIntegratorRequest
    integrator_selected: SimulationIntegratorSelection
    tolerance_applied: bool
    relative_tolerance: float | None
    absolute_tolerance: float | None
    accepted_steps: int
    function_evaluations: int | None
    segment_count: int
    rejected_steps: int | None
    rejected_steps_available: bool
    min_step_size: float | None
    max_step_size: float | None
    initial_time: float
    final_time: float
    time_unit: str
    termination_reason: SimulationSolverTermination
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.integrator_requested not in {
            "auto",
            "adaptive_dop853",
            "fixed_step_krylov",
        }:
            raise ValueError("integrator_requested is unsupported.")
        if self.integrator_selected not in {
            "not_applicable",
            "adaptive_dop853",
            "fixed_step_krylov",
        }:
            raise ValueError("integrator_selected is unsupported.")
        if not isinstance(self.tolerance_applied, bool):
            raise TypeError("tolerance_applied must be a boolean.")
        for field_name in ("relative_tolerance", "absolute_tolerance"):
            value = getattr(self, field_name)
            if value is not None:
                _positive_finite_float(value, field_name)
                object.__setattr__(self, field_name, float(value))
        for field_name in ("accepted_steps", "segment_count"):
            value = getattr(self, field_name)
            if not isinstance(value, int) or isinstance(value, bool) or value < 0:
                raise ValueError(f"{field_name} must be a non-negative integer.")
        if self.function_evaluations is not None and (
            not isinstance(self.function_evaluations, int)
            or isinstance(self.function_evaluations, bool)
            or self.function_evaluations < 0
        ):
            raise ValueError(
                "function_evaluations must be a non-negative integer or None."
            )
        if not isinstance(self.rejected_steps_available, bool):
            raise TypeError("rejected_steps_available must be a boolean.")
        if self.rejected_steps_available:
            if (
                not isinstance(self.rejected_steps, int)
                or isinstance(self.rejected_steps, bool)
                or self.rejected_steps < 0
            ):
                raise ValueError(
                    "available rejected_steps must be a non-negative integer."
                )
        elif self.rejected_steps is not None:
            raise ValueError(
                "rejected_steps must be None when the integrator does not expose it."
            )
        for field_name in ("min_step_size", "max_step_size"):
            value = getattr(self, field_name)
            if value is not None:
                _positive_finite_float(value, field_name)
                object.__setattr__(self, field_name, float(value))
        if (
            self.min_step_size is not None
            and self.max_step_size is not None
            and self.min_step_size > self.max_step_size
        ):
            raise ValueError("min_step_size cannot exceed max_step_size.")
        for field_name in ("initial_time", "final_time"):
            value = getattr(self, field_name)
            if (
                not isinstance(value, (int, float))
                or isinstance(value, bool)
                or not math.isfinite(value)
                or value < 0.0
            ):
                raise ValueError(f"{field_name} must be finite and non-negative.")
            object.__setattr__(self, field_name, float(value))
        if self.final_time < self.initial_time:
            raise ValueError("final_time cannot precede initial_time.")
        if not isinstance(self.time_unit, str) or not self.time_unit.strip():
            raise ValueError("time_unit must be a non-empty string.")
        if self.termination_reason not in {
            "completed",
            "not_applicable",
            "max_steps_exceeded",
            "solver_failed",
        }:
            raise ValueError("termination_reason is unsupported.")
        if self.integrator_selected == "adaptive_dop853":
            if not self.tolerance_applied:
                raise ValueError("adaptive_dop853 must apply its tolerances.")
            if self.relative_tolerance is None or self.absolute_tolerance is None:
                raise ValueError("adaptive_dop853 requires rtol and atol evidence.")
        elif self.tolerance_applied:
            raise ValueError(
                "Only adaptive_dop853 can mark tolerance_applied as true."
            )
        if self.integrator_selected == "not_applicable":
            if self.termination_reason != "not_applicable":
                raise ValueError(
                    "not_applicable integrator requires not_applicable termination."
                )
            if self.accepted_steps != 0 or self.segment_count != 0:
                raise ValueError("not_applicable integrator cannot report steps.")
        elif self.termination_reason == "not_applicable":
            raise ValueError(
                "executed integrators cannot use not_applicable termination."
            )
        object.__setattr__(self, "metadata", _redact_result_mapping(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SimulationSolverEvidenceIR:
        """Restore executed solver evidence from JSON-compatible data."""
        return cls(
            integrator_requested=data["integrator_requested"],
            integrator_selected=data["integrator_selected"],
            tolerance_applied=data["tolerance_applied"],
            relative_tolerance=data.get("relative_tolerance"),
            absolute_tolerance=data.get("absolute_tolerance"),
            accepted_steps=data["accepted_steps"],
            function_evaluations=data.get("function_evaluations"),
            segment_count=data["segment_count"],
            rejected_steps=data.get("rejected_steps"),
            rejected_steps_available=data["rejected_steps_available"],
            min_step_size=data.get("min_step_size"),
            max_step_size=data.get("max_step_size"),
            initial_time=data["initial_time"],
            final_time=data["final_time"],
            time_unit=str(data["time_unit"]),
            termination_reason=data["termination_reason"],
            metadata=dict(data.get("metadata", {})),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
        )


@dataclass(frozen=True)
class SimulationResourceUsageIR(IRMixin):
    """Observed wall-time and process-memory evidence for one local execution."""

    measurement_scope: ResourceMeasurementScope
    wall_time_seconds: float
    actual_peak_rss_bytes: int | None
    baseline_peak_rss_bytes: int | None
    incremental_peak_rss_bytes: int | None
    estimated_peak_bytes: int | None
    estimate_error_fraction: float | None
    estimate_within_tolerance: bool | None
    measurement_status: ResourceMeasurementStatus
    rss_semantics: Literal[
        "process_high_water_mark",
        "owned_by_parent_scan",
        "unavailable",
    ]
    schema_version: str = SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.measurement_scope not in {"job", "scan", "scan_item"}:
            raise ValueError("invalid resource measurement scope.")
        if (
            not isinstance(self.wall_time_seconds, (int, float))
            or isinstance(self.wall_time_seconds, bool)
            or not math.isfinite(self.wall_time_seconds)
            or self.wall_time_seconds < 0.0
        ):
            raise ValueError("wall_time_seconds must be finite and non-negative.")
        for name, value in (
            ("actual_peak_rss_bytes", self.actual_peak_rss_bytes),
            ("baseline_peak_rss_bytes", self.baseline_peak_rss_bytes),
            ("incremental_peak_rss_bytes", self.incremental_peak_rss_bytes),
            ("estimated_peak_bytes", self.estimated_peak_bytes),
        ):
            if value is not None and (
                not isinstance(value, int) or isinstance(value, bool) or value < 0
            ):
                raise ValueError(f"{name} must be a non-negative integer or None.")
        if self.estimate_error_fraction is not None and (
            not isinstance(self.estimate_error_fraction, (int, float))
            or isinstance(self.estimate_error_fraction, bool)
            or not math.isfinite(self.estimate_error_fraction)
            or self.estimate_error_fraction < 0.0
        ):
            raise ValueError(
                "estimate_error_fraction must be finite, non-negative, or None."
            )
        if self.estimate_within_tolerance is not None and not isinstance(
            self.estimate_within_tolerance,
            bool,
        ):
            raise TypeError("estimate_within_tolerance must be bool or None.")
        if self.measurement_status not in {
            "measured",
            "baseline_dominated",
            "estimate_unavailable",
            "rss_unavailable",
            "owned_by_parent_scan",
        }:
            raise ValueError("invalid resource measurement status.")
        if self.rss_semantics not in {
            "process_high_water_mark",
            "owned_by_parent_scan",
            "unavailable",
        }:
            raise ValueError("invalid RSS measurement semantics.")

        rss_values = (
            self.actual_peak_rss_bytes,
            self.baseline_peak_rss_bytes,
            self.incremental_peak_rss_bytes,
        )
        if self.measurement_status in {"rss_unavailable", "owned_by_parent_scan"}:
            if any(value is not None for value in rss_values):
                raise ValueError("unattributed RSS measurements cannot contain bytes.")
            expected_semantics = (
                "owned_by_parent_scan"
                if self.measurement_status == "owned_by_parent_scan"
                else "unavailable"
            )
            if self.rss_semantics != expected_semantics:
                raise ValueError("RSS semantics must match measurement status.")
        else:
            if any(value is None for value in rss_values):
                raise ValueError("measured RSS evidence requires all byte fields.")
            actual = self.actual_peak_rss_bytes
            baseline = self.baseline_peak_rss_bytes
            incremental = self.incremental_peak_rss_bytes
            assert actual is not None
            assert baseline is not None
            assert incremental is not None
            if incremental != max(0, actual - baseline):
                raise ValueError("incremental RSS must match actual minus baseline.")
            if self.rss_semantics != "process_high_water_mark":
                raise ValueError("measured RSS must use process high-water semantics.")

        if self.measurement_status == "measured":
            if (
                self.estimated_peak_bytes is None
                or not self.incremental_peak_rss_bytes
            ):
                raise ValueError(
                    "measured estimate error requires positive RSS growth."
                )
            expected_error = abs(
                self.estimated_peak_bytes - self.incremental_peak_rss_bytes
            ) / self.incremental_peak_rss_bytes
            if self.estimate_error_fraction is None or not math.isclose(
                self.estimate_error_fraction,
                expected_error,
                rel_tol=1e-12,
                abs_tol=1e-12,
            ):
                raise ValueError("estimate error must match observed RSS growth.")
            if self.estimate_within_tolerance != (expected_error <= 0.2):
                raise ValueError("estimate tolerance flag must use the 20% gate.")
        elif self.measurement_status == "baseline_dominated":
            if (
                self.estimated_peak_bytes is None
                or self.incremental_peak_rss_bytes != 0
            ):
                raise ValueError(
                    "baseline-dominated evidence requires an estimate and zero growth."
                )
        elif self.measurement_status == "estimate_unavailable":
            if self.estimated_peak_bytes is not None:
                raise ValueError(
                    "estimate-unavailable evidence cannot contain an estimate."
                )
        elif self.measurement_status == "owned_by_parent_scan":
            if self.measurement_scope != "scan_item":
                raise ValueError("only scan items can delegate RSS to a parent scan.")
        if self.measurement_status != "measured" and (
            self.estimate_error_fraction is not None
            or self.estimate_within_tolerance is not None
        ):
            raise ValueError("unmeasured estimate error fields must be None.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SimulationResourceUsageIR:
        """Build resource evidence from a JSON-compatible dictionary."""
        return cls(
            measurement_scope=data["measurement_scope"],
            wall_time_seconds=float(data["wall_time_seconds"]),
            actual_peak_rss_bytes=data.get("actual_peak_rss_bytes"),
            baseline_peak_rss_bytes=data.get("baseline_peak_rss_bytes"),
            incremental_peak_rss_bytes=data.get("incremental_peak_rss_bytes"),
            estimated_peak_bytes=data.get("estimated_peak_bytes"),
            estimate_error_fraction=data.get("estimate_error_fraction"),
            estimate_within_tolerance=data.get("estimate_within_tolerance"),
            measurement_status=data["measurement_status"],
            rss_semantics=data["rss_semantics"],
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
        )


@dataclass(frozen=True)
class SimulationExecutionConfigIR(IRMixin):
    """Executed local-simulation configuration with explicit ownership semantics.

    A planning decision is not sufficient evidence of what a kernel consumed.  This
    projection therefore records the effective seed, actual concurrency owner, and
    fixed-step configuration after backend dispatch has selected an implementation.
    """

    method: Literal["state_vector", "subspace", "density_matrix", "trajectory"]
    device: Literal["cpu"]
    dtype: Literal["complex64", "complex128"]
    relative_tolerance: float
    absolute_tolerance: float
    integrator_requested: SimulationIntegratorRequest
    integrator_selected: SimulationIntegratorSelection
    solver_evidence_hash: str
    tolerance_applied: bool
    steps: int
    step_semantics: SimulationStepSemantics
    workers: int
    worker_semantics: SimulationWorkerSemantics
    seed: int
    seed_semantics: SimulationSeedSemantics
    execution_scope: SimulationExecutionScope
    trajectories: int | None = None
    schema_version: str = SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.method not in {
            "state_vector",
            "subspace",
            "density_matrix",
            "trajectory",
        }:
            raise ValueError("method is not a supported simulation method.")
        if self.device != "cpu":
            raise ValueError("device must be cpu for current local execution.")
        if self.dtype not in {"complex64", "complex128"}:
            raise ValueError("dtype must be complex64 or complex128.")
        for name, value in (
            ("relative_tolerance", self.relative_tolerance),
            ("absolute_tolerance", self.absolute_tolerance),
        ):
            if (
                not isinstance(value, (int, float))
                or isinstance(value, bool)
                or not math.isfinite(value)
                or value <= 0.0
            ):
                raise ValueError(f"{name} must be finite and positive.")
            object.__setattr__(self, name, float(value))
        if self.integrator_requested not in {
            "auto",
            "adaptive_dop853",
            "fixed_step_krylov",
        }:
            raise ValueError("integrator_requested is unsupported.")
        if self.integrator_selected not in {
            "not_applicable",
            "adaptive_dop853",
            "fixed_step_krylov",
        }:
            raise ValueError("integrator_selected is unsupported.")
        if (
            not isinstance(self.solver_evidence_hash, str)
            or len(self.solver_evidence_hash) != 64
            or any(
                character not in "0123456789abcdef"
                for character in self.solver_evidence_hash
            )
        ):
            raise ValueError("solver_evidence_hash must be a lowercase SHA-256 digest.")
        if not isinstance(self.tolerance_applied, bool):
            raise TypeError("tolerance_applied must be a boolean.")
        if (
            not isinstance(self.steps, int)
            or isinstance(self.steps, bool)
            or self.steps < 0
        ):
            raise ValueError("steps must be a non-negative integer.")
        if self.step_semantics not in {
            "not_applicable",
            "adaptive_accepted_steps",
            "fixed_time_slices",
        }:
            raise ValueError("step_semantics is unsupported.")
        if self.step_semantics == "not_applicable" and self.steps != 0:
            raise ValueError("not-applicable steps must be zero.")
        if self.step_semantics != "not_applicable" and self.steps == 0:
            raise ValueError("executed steps must be positive.")
        expected_step_semantics = {
            "not_applicable": "not_applicable",
            "adaptive_dop853": "adaptive_accepted_steps",
            "fixed_step_krylov": "fixed_time_slices",
        }[self.integrator_selected]
        if self.step_semantics != expected_step_semantics:
            raise ValueError("integrator and step semantics are inconsistent.")
        if self.integrator_selected == "adaptive_dop853":
            if not self.tolerance_applied:
                raise ValueError("adaptive integrator must apply its tolerances.")
        elif self.tolerance_applied:
            raise ValueError("only the adaptive integrator can apply tolerances.")
        if (
            self.integrator_requested != "auto"
            and self.integrator_selected != self.integrator_requested
        ):
            raise ValueError("explicit integrator request cannot change at execution.")
        if (
            not isinstance(self.workers, int)
            or isinstance(self.workers, bool)
            or self.workers <= 0
        ):
            raise ValueError("workers must be a positive integer.")
        if self.worker_semantics not in {
            "kernel_concurrency",
            "scan_concurrency",
        }:
            raise ValueError("worker_semantics is unsupported.")
        if not isinstance(self.seed, int) or isinstance(self.seed, bool):
            raise TypeError("seed must be an integer.")
        if self.seed_semantics not in {
            "effective_seed",
            "root_seed",
            "derived_scan_seed",
        }:
            raise ValueError("seed_semantics is unsupported.")
        if self.execution_scope not in {"job", "scan", "scan_item"}:
            raise ValueError("execution_scope is unsupported.")
        expected_semantics = {
            "job": ("kernel_concurrency", "effective_seed"),
            "scan": ("scan_concurrency", "root_seed"),
            "scan_item": ("kernel_concurrency", "derived_scan_seed"),
        }[self.execution_scope]
        if (self.worker_semantics, self.seed_semantics) != expected_semantics:
            raise ValueError(
                "worker and seed semantics must match the execution scope."
            )
        if self.method == "trajectory":
            if (
                not isinstance(self.trajectories, int)
                or isinstance(self.trajectories, bool)
                or self.trajectories < 2
            ):
                raise ValueError(
                    "trajectory execution requires at least two trajectories."
                )
        elif self.trajectories is not None:
            raise ValueError("trajectories applies only to trajectory execution.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SimulationExecutionConfigIR:
        """Build executed simulation evidence from a JSON-compatible dictionary."""
        return cls(
            method=data["method"],
            device=data["device"],
            dtype=data["dtype"],
            relative_tolerance=data["relative_tolerance"],
            absolute_tolerance=data["absolute_tolerance"],
            integrator_requested=data["integrator_requested"],
            integrator_selected=data["integrator_selected"],
            solver_evidence_hash=data["solver_evidence_hash"],
            tolerance_applied=data["tolerance_applied"],
            steps=data["steps"],
            step_semantics=data["step_semantics"],
            workers=data["workers"],
            worker_semantics=data["worker_semantics"],
            seed=data["seed"],
            seed_semantics=data["seed_semantics"],
            execution_scope=data["execution_scope"],
            trajectories=data.get("trajectories"),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
        )


@dataclass(frozen=True)
class ResultIR(IRMixin):
    """Unified result model for MVP simulator and mock backends."""

    result_id: str
    program_hash: str
    target_id: str
    shots: int
    counts: dict[str, int]
    samples: tuple[str, ...]
    probabilities: dict[str, float] | None = None
    observables: dict[str, Any] = field(default_factory=dict)
    observable_batch: ObservableBatchResultIR | None = None
    bit_ordering: dict[str, Any] = field(
        default_factory=lambda: {"convention": UNSPECIFIED_BIT_ORDER_CONVENTION}
    )
    occupation_encoding: OccupationEncoding = field(default_factory=OccupationEncoding)
    diagnostics: tuple[DiagnosticsIR, ...] = ()
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Redact secret-like result metadata."""
        if self.observable_batch is not None and not isinstance(
            self.observable_batch,
            ObservableBatchResultIR,
        ):
            raise TypeError(
                "observable_batch must be ObservableBatchResultIR or None."
            )
        object.__setattr__(self, "metadata", _redact_result_mapping(self.metadata))

    def to_dict(self) -> dict[str, Any]:
        """Return wire data while preserving absent-field hash compatibility."""
        data = super().to_dict()
        if self.observable_batch is None:
            data.pop("observable_batch")
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ResultIR:
        """Build a result IR from the MVP JSON representation."""
        raw_observable_batch = data.get("observable_batch")
        if raw_observable_batch is not None and not isinstance(
            raw_observable_batch,
            dict,
        ):
            raise TypeError("observable_batch must be an object or null.")
        return cls(
            result_id=str(data["result_id"]),
            program_hash=str(data["program_hash"]),
            target_id=str(data["target_id"]),
            shots=int(data["shots"]),
            counts={str(key): int(value) for key, value in data["counts"].items()},
            samples=tuple(str(sample) for sample in data["samples"]),
            probabilities=None
            if data.get("probabilities") is None
            else {
                str(key): float(value)
                for key, value in data["probabilities"].items()
            },
            observables=dict(data.get("observables", {})),
            observable_batch=(
                None
                if raw_observable_batch is None
                else ObservableBatchResultIR.from_dict(raw_observable_batch)
            ),
            bit_ordering=dict(data.get("bit_ordering", {})),
            occupation_encoding=OccupationEncoding.from_dict(
                data.get("occupation_encoding", {})
            ),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(diagnostic)
                for diagnostic in data.get("diagnostics", ())
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> ResultIR:
        """Build a result IR from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("ResultIR JSON must contain an object.")
        return cls.from_dict(data)

    def artifact_refs(self) -> tuple[ArtifactRefIR, ...]:
        """Return structured artifact references stored in metadata."""
        return _artifact_refs_from_metadata(self.metadata)

    def resource_usage(self) -> SimulationResourceUsageIR | None:
        """Return structured local resource evidence when this result has it."""
        return resource_usage_from_metadata(self.metadata)

    def execution_config(self) -> SimulationExecutionConfigIR | None:
        """Return executed local-simulation configuration when available."""
        return simulation_execution_config_from_metadata(self.metadata)

    def solver_evidence(self) -> SimulationSolverEvidenceIR | None:
        """Return executed time-integrator evidence when available."""
        return simulation_solver_evidence_from_metadata(self.metadata)

    def state_transitions(self) -> tuple[StateTransitionIR, ...]:
        """Return canonical quantum-state transitions for this result."""
        return state_transitions_from_metadata(self.metadata)

    def with_artifact_refs(self, artifacts: tuple[ArtifactRefIR, ...]) -> ResultIR:
        """Return a copy with structured artifact refs in metadata."""
        return replace_metadata_artifacts(self, artifacts)


def result_references_from_metadata(
    metadata: dict[str, Any],
) -> ResultReferencesIR | None:
    """Parse stable result references from ResultIR metadata if present."""
    raw = metadata.get("references")
    if not isinstance(raw, dict):
        return None
    if not isinstance(raw.get("program_hash"), str) or not raw["program_hash"]:
        return None
    return ResultReferencesIR.from_dict(raw)


def resource_usage_from_metadata(
    metadata: dict[str, Any],
) -> SimulationResourceUsageIR | None:
    """Parse local execution resource evidence from result-like metadata."""
    raw = metadata.get("simulation_resource_usage")
    if raw is None:
        return None
    if not isinstance(raw, dict):
        raise TypeError("simulation_resource_usage metadata must be a dictionary.")
    return SimulationResourceUsageIR.from_dict(raw)


def simulation_execution_config_from_metadata(
    metadata: dict[str, Any],
) -> SimulationExecutionConfigIR | None:
    """Parse executed configuration without inferring facts for external backends."""
    raw = metadata.get("simulation_execution_config")
    if raw is None:
        return None
    if not isinstance(raw, dict):
        raise TypeError("simulation_execution_config metadata must be a dictionary.")
    return SimulationExecutionConfigIR.from_dict(raw)


def simulation_solver_evidence_from_metadata(
    metadata: dict[str, Any],
) -> SimulationSolverEvidenceIR | None:
    """Parse executed solver evidence without inferring it from a plan."""
    raw = metadata.get("simulation_solver_evidence")
    if raw is None:
        return None
    if not isinstance(raw, dict):
        raise TypeError("simulation_solver_evidence metadata must be a dictionary.")
    return SimulationSolverEvidenceIR.from_dict(raw)


def state_transitions_from_metadata(
    metadata: dict[str, Any],
) -> tuple[StateTransitionIR, ...]:
    """Parse the canonical transition sequence without reading derived views."""
    raw = metadata.get("state_transitions")
    if raw is None:
        return ()
    if not isinstance(raw, list):
        raise TypeError("state_transitions metadata must be a list.")
    return tuple(StateTransitionIR.from_dict(item) for item in raw)


def validate_state_transition_chain(
    transitions: tuple[StateTransitionIR, ...],
    *,
    initial_state_hash: str,
    final_state_hash: str,
) -> None:
    """Validate order, state hashes, logical time, and terminal identity."""
    if not transitions:
        raise ValueError("State transition chain must not be empty.")
    _require_sha256(initial_state_hash, "initial_state_hash")
    _require_sha256(final_state_hash, "final_state_hash")
    if tuple(item.order_index for item in transitions) != tuple(
        range(len(transitions))
    ):
        raise ValueError("State transitions must use contiguous order indices.")
    if transitions[0].input_state_hash != initial_state_hash:
        raise ValueError("First transition must reference the initial state.")
    for left, right in zip(transitions, transitions[1:]):
        if left.output_state_hash != right.input_state_hash:
            raise ValueError("State transition hash chain is broken.")
        if left.output_logical_time != right.input_logical_time:
            raise ValueError("State transition logical-time chain is broken.")
        if left.time_unit != right.time_unit:
            raise ValueError("State transition time units must match.")
    if transitions[-1].output_state_hash != final_state_hash:
        raise ValueError("Last transition must reference the final state.")


def result_references_projection_matches_metadata(
    *,
    metadata: dict[str, Any],
    projection: dict[str, Any],
) -> bool:
    """Return whether a projected references payload matches metadata source."""
    references = result_references_from_metadata(metadata)
    if references is None:
        return projection == {}
    return references.to_dict() == projection


def result_references_from_result(result: ResultIR) -> ResultReferencesIR | None:
    """Return stable result references without changing ResultIR schema."""
    return result_references_from_metadata(result.metadata)


@dataclass(frozen=True)
class BatchItemResultRefIR(IRMixin):
    """Reference summary for one item in a batch result."""

    item_index: int
    parameter_bind_id: str
    parameter_bind_hash: str | None
    execution_package_id: str
    backend_job_id: str
    status: str
    result_id: str | None = None
    references: ResultReferencesIR | None = None
    diagnostics: tuple[DiagnosticsIR, ...] = ()
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Redact secret-like batch item metadata."""
        validate_job_state(self.status, field_name="BatchItemResultRefIR.status")
        object.__setattr__(self, "metadata", _redact_result_mapping(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> BatchItemResultRefIR:
        """Build a batch item result reference from a dictionary."""
        references = data.get("references")
        return cls(
            item_index=int(data["item_index"]),
            parameter_bind_id=str(data["parameter_bind_id"]),
            parameter_bind_hash=data.get("parameter_bind_hash"),
            execution_package_id=str(data["execution_package_id"]),
            backend_job_id=str(data["backend_job_id"]),
            status=validate_job_state(
                data["status"], field_name="BatchItemResultRefIR.status"
            ),
            result_id=data.get("result_id"),
            references=None
            if references is None
            else ResultReferencesIR.from_dict(references),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(diagnostic)
                for diagnostic in data.get("diagnostics", ())
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )


@dataclass(frozen=True)
class BatchResultIR(IRMixin):
    """Summary-first result model for batch runtime outputs."""

    batch_result_id: str
    batch_id: str
    status: JobState
    total_items: int
    created_count: int
    queued_count: int
    running_count: int
    completed_count: int
    partially_completed_count: int
    failed_count: int
    cancelled_count: int
    expired_count: int
    compiled_program_hash: str
    backend_id: str
    trace_id: str
    items: tuple[BatchItemResultRefIR, ...]
    diagnostics: tuple[DiagnosticsIR, ...] = ()
    aggregate_counts: dict[str, int] = field(default_factory=dict)
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Redact secret-like batch result metadata."""
        validate_job_state(self.status, field_name="BatchResultIR.status")
        object.__setattr__(self, "metadata", _redact_result_mapping(self.metadata))

    @classmethod
    def from_batch_run(cls, batch_run: Any) -> BatchResultIR:
        """Build a batch summary from a BatchRunResult runtime artifact."""
        artifact_refs = _batch_artifact_refs(batch_run)
        result_count = sum(item.result is not None for item in batch_run.items)
        metadata = {
            "runtime": dict(batch_run.metadata),
            "workload_type": "batch_job",
            "contract_summary": {
                "parameter_bind_count": len(batch_run.items),
                "result_count": result_count,
                "results_match_completed_count": (
                    result_count == batch_run.status.completed_count
                ),
                "diagnostic_codes": [
                    diagnostic.code for diagnostic in batch_run.diagnostics
                ],
            },
            "item_evidence_summaries": [
                _batch_item_evidence_summary(item) for item in batch_run.items
            ],
            "execution_boundary": {
                "metadata_only": True,
                "artifact_bytes_read": False,
                "backend_called_after_run": False,
                "network_accessed": False,
                "hardware_execution": False,
                "cloud_execution": False,
            },
        }
        if artifact_refs:
            metadata["artifact_refs"] = [
                artifact.to_dict() for artifact in artifact_refs
            ]
        return cls(
            batch_result_id=f"batch_result.{batch_run.batch_id}",
            batch_id=batch_run.batch_id,
            status=batch_run.status.state,
            total_items=batch_run.status.total_items,
            created_count=batch_run.status.created_count,
            queued_count=batch_run.status.queued_count,
            running_count=batch_run.status.running_count,
            completed_count=batch_run.status.completed_count,
            partially_completed_count=(
                batch_run.status.partially_completed_count
            ),
            failed_count=batch_run.status.failed_count,
            cancelled_count=batch_run.status.cancelled_count,
            expired_count=batch_run.status.expired_count,
            compiled_program_hash=batch_run.compiled_program.stable_hash(),
            backend_id=batch_run.status.backend_id,
            trace_id=batch_run.status.trace_id,
            items=tuple(_item_ref(item) for item in batch_run.items),
            diagnostics=tuple(batch_run.diagnostics),
            aggregate_counts=_aggregate_counts(batch_run),
            metadata=metadata,
        )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> BatchResultIR:
        """Build a batch result from a JSON-compatible dictionary."""
        return cls(
            batch_result_id=str(data["batch_result_id"]),
            batch_id=str(data["batch_id"]),
            status=validate_job_state(
                data["status"], field_name="BatchResultIR.status"
            ),
            total_items=int(data["total_items"]),
            created_count=int(data["created_count"]),
            queued_count=int(data["queued_count"]),
            running_count=int(data["running_count"]),
            completed_count=int(data["completed_count"]),
            partially_completed_count=int(data["partially_completed_count"]),
            failed_count=int(data["failed_count"]),
            cancelled_count=int(data["cancelled_count"]),
            expired_count=int(data["expired_count"]),
            compiled_program_hash=str(data["compiled_program_hash"]),
            backend_id=str(data["backend_id"]),
            trace_id=str(data["trace_id"]),
            items=tuple(
                BatchItemResultRefIR.from_dict(item)
                for item in data.get("items", ())
            ),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(diagnostic)
                for diagnostic in data.get("diagnostics", ())
            ),
            aggregate_counts={
                str(key): int(value)
                for key, value in data.get("aggregate_counts", {}).items()
            },
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> BatchResultIR:
        """Build a batch result from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("BatchResultIR JSON must contain an object.")
        return cls.from_dict(data)

    def artifact_refs(self) -> tuple[ArtifactRefIR, ...]:
        """Return structured artifact refs stored in batch metadata."""
        return _artifact_refs_from_metadata(self.metadata)

    def item_artifact_refs(self) -> tuple[ArtifactRefIR, ...]:
        """Return structured artifact refs from all item metadata records."""
        artifacts: list[ArtifactRefIR] = []
        for item in self.items:
            artifacts.extend(_artifact_refs_from_metadata(item.metadata))
        return tuple(artifacts)


def _item_ref(item: Any) -> BatchItemResultRefIR:
    result = item.result
    references = None
    if result is not None:
        references = result_references_from_result(result)
    return BatchItemResultRefIR(
        item_index=item.item_index,
        parameter_bind_id=item.parameter_bind_id,
        parameter_bind_hash=item.metadata.get("parameter_bind_hash"),
        execution_package_id=item.execution_package_id,
        backend_job_id=item.job_id,
        status=item.status.state,
        result_id=None if result is None else result.result_id,
        references=references,
        diagnostics=tuple(item.diagnostics),
        metadata={
            "backend_status_message": item.status.message,
            "has_result": result is not None,
            "has_references": references is not None,
            "parameter_bind_id": item.parameter_bind_id,
        },
    )


def _batch_item_evidence_summary(item: Any) -> dict[str, Any]:
    result = item.result
    references = None if result is None else result_references_from_result(result)
    raw_trace = {} if result is None else result.metadata.get("run_trace", {})
    trace_id = (
        str(raw_trace["trace_id"])
        if isinstance(raw_trace, dict) and raw_trace.get("trace_id") is not None
        else None
    )
    return {
        "item_index": item.item_index,
        "parameter_bind_id": item.parameter_bind_id,
        "status": item.status.state,
        "result_id": None if result is None else result.result_id,
        "execution_package_id": item.execution_package_id,
        "has_result": result is not None,
        "has_references": references is not None,
        "references": {} if references is None else references.to_dict(),
        "trace_id": trace_id,
        "diagnostic_count": len(item.diagnostics),
        "metadata_only": True,
        "fact_source": "BatchResultIR.items",
        "derived_view": True,
        "artifact_bytes_read": False,
        "backend_called_after_run": False,
        "network_accessed": False,
        "hardware_execution": False,
        "cloud_execution": False,
    }


def _aggregate_counts(batch_run: Any) -> dict[str, int]:
    counts: dict[str, int] = {}
    for item in batch_run.items:
        if item.result is None:
            continue
        for bitstring, value in item.result.counts.items():
            counts[bitstring] = counts.get(bitstring, 0) + value
    return counts


def _batch_artifact_refs(batch_run: Any) -> tuple[ArtifactRefIR, ...]:
    artifacts: list[ArtifactRefIR] = []
    for item in batch_run.items:
        if item.result is not None:
            artifacts.extend(item.result.artifact_refs())
    return tuple(artifacts)


def replace_metadata_artifacts(
    result: ResultIR,
    artifacts: tuple[ArtifactRefIR, ...],
) -> ResultIR:
    """Return a ResultIR copy with artifact refs stored in metadata."""
    return replace(
        result,
        metadata={
            **result.metadata,
            "artifact_refs": [artifact.to_dict() for artifact in artifacts],
        },
    )


def _artifact_refs_from_metadata(metadata: dict[str, Any]) -> tuple[ArtifactRefIR, ...]:
    raw_artifacts = metadata.get("artifact_refs", ())
    if not isinstance(raw_artifacts, (list, tuple)):
        return ()
    artifacts: list[ArtifactRefIR] = []
    for raw_artifact in raw_artifacts:
        if isinstance(raw_artifact, dict):
            artifacts.append(ArtifactRefIR.from_dict(raw_artifact))
    return tuple(artifacts)


def _redact_result_mapping(data: dict[str, Any]) -> dict[str, Any]:
    redacted: dict[str, Any] = {}
    for key, value in data.items():
        lowered = str(key).lower()
        if any(token in lowered for token in _RESULT_SECRET_KEY_MARKERS):
            redacted[str(key)] = "<redacted>"
        else:
            redacted[str(key)] = _redact_result_value(value)
    return redacted


def _redact_result_value(value: Any) -> Any:
    if isinstance(value, dict):
        return _redact_result_mapping(value)
    if isinstance(value, list):
        return [_redact_result_value(item) for item in value]
    if isinstance(value, tuple):
        return tuple(_redact_result_value(item) for item in value)
    return value


def _require_sha256(value: object, field_name: str) -> None:
    if (
        not isinstance(value, str)
        or len(value) != 64
        or any(character not in "0123456789abcdef" for character in value)
    ):
        raise ValueError(f"{field_name} must be a lowercase SHA-256 digest.")


def _positive_finite_float(value: object, field_name: str) -> None:
    if (
        not isinstance(value, (int, float))
        or isinstance(value, bool)
        or not math.isfinite(value)
        or value <= 0.0
    ):
        raise ValueError(f"{field_name} must be finite and positive.")
