"""Metadata-only artifact access request and pagination contracts."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, cast

from cascaqit.diagnostics import DiagnosticsIR, with_diagnostic_taxonomy
from cascaqit.native_ir.base import IRMixin
from cascaqit.native_ir.models import SCHEMA_VERSION
from cascaqit.results.models import ArtifactRefIR, ResultIR

__all__ = [
    "ArtifactListRequestIR",
    "ArtifactListResponseIR",
    "ArtifactPageRefIR",
    "build_artifact_access_summary",
    "build_result_artifact_list_response",
    "diagnose_artifact_access_response",
]

_OFFLINE_SOURCE = "offline_placeholder"
_SECRET_KEY_MARKERS = (
    "access_key",
    "api_key",
    "apikey",
    "authorization",
    "credential",
    "password",
    "private_key",
    "secret",
    "token",
)


@dataclass(frozen=True)
class ArtifactPageRefIR(IRMixin):
    """Placeholder page reference for artifact metadata listing."""

    page_ref_id: str
    source: str = _OFFLINE_SOURCE
    page_token: str | None = None
    next_page_token: str | None = None
    page_size: int | None = None
    has_more: bool = False
    live_store_accessed: bool = False
    bytes_transferred: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Enforce metadata-only pagination placeholders."""
        _ensure_metadata_only_access(
            source=self.source,
            live_store_accessed=self.live_store_accessed,
            bytes_transferred=self.bytes_transferred,
            model_name="ArtifactPageRefIR",
        )
        if self.page_size is not None and self.page_size < 0:
            raise ValueError("page_size must be non-negative.")
        object.__setattr__(self, "metadata", _redact_mapping(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ArtifactPageRefIR:
        """Build an artifact page reference from a dictionary."""
        page_size = data.get("page_size")
        return cls(
            page_ref_id=str(data["page_ref_id"]),
            source=str(data.get("source", _OFFLINE_SOURCE)),
            page_token=data.get("page_token"),
            next_page_token=data.get("next_page_token"),
            page_size=None if page_size is None else int(page_size),
            has_more=bool(data.get("has_more", False)),
            live_store_accessed=bool(data.get("live_store_accessed", False)),
            bytes_transferred=bool(data.get("bytes_transferred", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> ArtifactPageRefIR:
        """Build an artifact page reference from JSON text."""
        return cls.from_dict(_json_object(text, "ArtifactPageRefIR"))


@dataclass(frozen=True)
class ArtifactListRequestIR(IRMixin):
    """Metadata-only artifact listing request contract."""

    request_id: str
    backend_id: str | None = None
    result_id: str | None = None
    job_id: str | None = None
    artifact_kind: str | None = None
    retention_policy: str | None = None
    include_expired: bool = False
    page: ArtifactPageRefIR | None = None
    source: str = _OFFLINE_SOURCE
    metadata_only: bool = True
    live_store_accessed: bool = False
    bytes_transferred: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Enforce request boundaries and normalize nested page references."""
        _ensure_metadata_only_access(
            source=self.source,
            live_store_accessed=self.live_store_accessed,
            bytes_transferred=self.bytes_transferred,
            model_name="ArtifactListRequestIR",
        )
        if not self.metadata_only:
            raise ValueError("ArtifactListRequestIR must remain metadata-only.")
        if self.page is not None and not isinstance(self.page, ArtifactPageRefIR):
            raise TypeError("page must be ArtifactPageRefIR or None.")
        object.__setattr__(self, "metadata", _redact_mapping(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ArtifactListRequestIR:
        """Build an artifact list request from a dictionary."""
        return cls(
            request_id=str(data["request_id"]),
            backend_id=data.get("backend_id"),
            result_id=data.get("result_id"),
            job_id=data.get("job_id"),
            artifact_kind=data.get("artifact_kind"),
            retention_policy=data.get("retention_policy"),
            include_expired=bool(data.get("include_expired", False)),
            page=_page_ref_from_optional(data.get("page")),
            source=str(data.get("source", _OFFLINE_SOURCE)),
            metadata_only=bool(data.get("metadata_only", True)),
            live_store_accessed=bool(data.get("live_store_accessed", False)),
            bytes_transferred=bool(data.get("bytes_transferred", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> ArtifactListRequestIR:
        """Build an artifact list request from JSON text."""
        return cls.from_dict(_json_object(text, "ArtifactListRequestIR"))


@dataclass(frozen=True)
class ArtifactListResponseIR(IRMixin):
    """Metadata-only artifact listing response contract."""

    response_id: str
    request: ArtifactListRequestIR
    artifacts: tuple[ArtifactRefIR, ...]
    page: ArtifactPageRefIR
    source: str = _OFFLINE_SOURCE
    metadata_only: bool = True
    live_store_accessed: bool = False
    bytes_transferred: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize artifacts and enforce metadata-only response boundaries."""
        if not isinstance(self.request, ArtifactListRequestIR):
            raise TypeError("request must be ArtifactListRequestIR.")
        if not isinstance(self.page, ArtifactPageRefIR):
            raise TypeError("page must be ArtifactPageRefIR.")
        _ensure_metadata_only_access(
            source=self.source,
            live_store_accessed=self.live_store_accessed,
            bytes_transferred=self.bytes_transferred,
            model_name="ArtifactListResponseIR",
        )
        if not self.metadata_only:
            raise ValueError("ArtifactListResponseIR must remain metadata-only.")
        object.__setattr__(
            self,
            "artifacts",
            tuple(_artifact_ref_from_any(item) for item in self.artifacts),
        )
        object.__setattr__(self, "metadata", _redact_mapping(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ArtifactListResponseIR:
        """Build an artifact list response from a dictionary."""
        return cls(
            response_id=str(data["response_id"]),
            request=_request_from_any(data["request"]),
            artifacts=tuple(
                _artifact_ref_from_any(item) for item in data.get("artifacts", ())
            ),
            page=_page_ref_from_any(data["page"]),
            source=str(data.get("source", _OFFLINE_SOURCE)),
            metadata_only=bool(data.get("metadata_only", True)),
            live_store_accessed=bool(data.get("live_store_accessed", False)),
            bytes_transferred=bool(data.get("bytes_transferred", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> ArtifactListResponseIR:
        """Build an artifact list response from JSON text."""
        return cls.from_dict(_json_object(text, "ArtifactListResponseIR"))


def build_artifact_access_summary(
    response: ArtifactListResponseIR,
) -> dict[str, Any]:
    """Summarize artifact access metadata without reading artifact bytes."""
    if not isinstance(response, ArtifactListResponseIR):
        raise TypeError("response must be ArtifactListResponseIR.")
    artifact_ids = [artifact.artifact_id for artifact in response.artifacts]
    retention_policies = sorted(
        {artifact.retention_policy for artifact in response.artifacts}
    )
    return {
        "summary_id": f"artifact_access.{response.response_id}",
        "schema_version": SCHEMA_VERSION,
        "request_id": response.request.request_id,
        "response_id": response.response_id,
        "artifact_ids": artifact_ids,
        "artifact_count": len(artifact_ids),
        "retention_policies": retention_policies,
        "page": response.page.to_dict(),
        "source": _OFFLINE_SOURCE,
        "fact_source": "ArtifactListResponseIR",
        "derived_view": True,
        "metadata_only": True,
        "live_store_accessed": False,
        "bytes_transferred": False,
        "artifact_bytes_read": False,
        "backend_called": False,
        "network_accessed": False,
        "hardware_execution": False,
        "cloud_execution": False,
        "inline_artifact_count": sum(
            1 for artifact in response.artifacts if _is_inline_placeholder(artifact)
        ),
        "external_artifact_count": sum(
            1 for artifact in response.artifacts if not _is_inline_placeholder(artifact)
        ),
        "expired_artifact_count": sum(
            1 for artifact in response.artifacts if _is_expired_artifact(artifact)
        ),
        "checksum_count": sum(
            1 for artifact in response.artifacts if bool(artifact.checksum)
        ),
    }


def build_result_artifact_list_response(
    result: ResultIR,
    *,
    request_id: str | None = None,
    response_id: str | None = None,
    backend_id: str | None = None,
    job_id: str | None = None,
    page_token: str | None = None,
    page_size: int | None = None,
    include_expired: bool = False,
    metadata: dict[str, Any] | None = None,
) -> ArtifactListResponseIR:
    """Build a metadata-only paginated artifact response for a result."""
    if not isinstance(result, ResultIR):
        raise TypeError("result must be ResultIR.")
    all_artifacts = tuple(
        artifact
        for artifact in result.artifact_refs()
        if include_expired or not _is_expired_artifact(artifact)
    )
    offset = _page_offset(page_token)
    if page_size is None:
        page_items = all_artifacts[offset:]
        next_page_token = None
        has_more = False
    else:
        if page_size < 0:
            raise ValueError("page_size must be non-negative.")
        end = offset + page_size
        page_items = all_artifacts[offset:end]
        has_more = end < len(all_artifacts)
        next_page_token = f"offset:{end}" if has_more else None
    request = ArtifactListRequestIR(
        request_id=request_id or f"artifact_list_request.{result.result_id}",
        backend_id=backend_id,
        result_id=result.result_id,
        job_id=job_id,
        include_expired=include_expired,
        page=ArtifactPageRefIR(
            page_ref_id=f"artifact_page_request.{result.result_id}",
            page_token=page_token,
            page_size=page_size,
            metadata={
                "pagination_contract": "metadata_only",
            },
        ),
        metadata={
            "source": "ResultIR.artifact_refs",
            **({} if metadata is None else metadata),
        },
    )
    page = ArtifactPageRefIR(
        page_ref_id=f"artifact_page.{result.result_id}",
        page_token=page_token,
        next_page_token=next_page_token,
        page_size=page_size,
        has_more=has_more,
        metadata={
            "total_artifact_count": len(all_artifacts),
            "returned_artifact_count": len(page_items),
            "pagination_contract": "metadata_only",
            "bytes_read": False,
        },
    )
    return ArtifactListResponseIR(
        response_id=response_id or f"artifact_list_response.{result.result_id}",
        request=request,
        artifacts=page_items,
        page=page,
        metadata={
            "source": "ResultIR.artifact_refs",
            "result_id": result.result_id,
            **({} if metadata is None else metadata),
        },
    )


def diagnose_artifact_access_response(
    response: ArtifactListResponseIR,
) -> tuple[DiagnosticsIR, ...]:
    """Return metadata-only artifact pagination diagnostics."""
    if not isinstance(response, ArtifactListResponseIR):
        raise TypeError("response must be ArtifactListResponseIR.")
    diagnostics = [
        _diagnostic(
            diagnostic_id=f"diagnostic.{response.response_id}.offline",
            severity="info",
            code="ARTIFACT_ACCESS_METADATA_ONLY",
            message=(
                "Artifact pagination returns references and metadata only; "
                "artifact bytes were not read."
            ),
            metadata={
                "response_id": response.response_id,
                "artifact_count": len(response.artifacts),
                "live_store_accessed": False,
                "bytes_transferred": False,
            },
        )
    ]
    for artifact in response.artifacts:
        if _is_inline_placeholder(artifact):
            diagnostics.append(
                _diagnostic(
                    diagnostic_id=f"diagnostic.{artifact.artifact_id}.inline",
                    severity="info",
                    code="ARTIFACT_REFERENCE_INLINE_PLACEHOLDER",
                    message="Artifact reference is an inline placeholder.",
                    object_path="artifacts",
                    metadata={"artifact_id": artifact.artifact_id},
                )
            )
        else:
            diagnostics.append(
                _diagnostic(
                    diagnostic_id=f"diagnostic.{artifact.artifact_id}.external",
                    severity="info",
                    code="ARTIFACT_REFERENCE_EXTERNAL",
                    message="Artifact reference points to an external location.",
                    object_path="artifacts",
                    metadata={
                        "artifact_id": artifact.artifact_id,
                        "storage_uri": artifact.storage_uri,
                    },
                )
            )
        if artifact.checksum:
            diagnostics.append(
                _diagnostic(
                    diagnostic_id=f"diagnostic.{artifact.artifact_id}.checksum",
                    severity="info",
                    code="ARTIFACT_CHECKSUM_METADATA_PRESENT",
                    message="Artifact reference carries checksum metadata.",
                    object_path="artifacts.checksum",
                    metadata={
                        "artifact_id": artifact.artifact_id,
                        "checksum": artifact.checksum,
                    },
                )
            )
        if _is_expired_artifact(artifact):
            diagnostics.append(
                _diagnostic(
                    diagnostic_id=f"diagnostic.{artifact.artifact_id}.expired",
                    severity="warning",
                    code="ARTIFACT_REFERENCE_EXPIRED",
                    message="Artifact reference is marked expired by metadata.",
                    object_path="artifacts.expires_at",
                    metadata={
                        "artifact_id": artifact.artifact_id,
                        "expires_at": artifact.expires_at,
                    },
                )
            )
    if response.page.has_more:
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"diagnostic.{response.response_id}.has_more",
                severity="info",
                code="ARTIFACT_PAGE_HAS_MORE",
                message="More artifact references are available via next_page_token.",
                object_path="page.next_page_token",
                metadata={"next_page_token": response.page.next_page_token},
            )
        )
    return tuple(diagnostics)


def _ensure_metadata_only_access(
    *,
    source: str,
    live_store_accessed: bool,
    bytes_transferred: bool,
    model_name: str,
) -> None:
    if source != _OFFLINE_SOURCE:
        raise ValueError(f'{model_name} source must be "{_OFFLINE_SOURCE}".')
    if live_store_accessed:
        raise ValueError(f"{model_name} cannot record live store access.")
    if bytes_transferred:
        raise ValueError(f"{model_name} must not transfer artifact bytes.")


def _artifact_ref_from_any(value: Any) -> ArtifactRefIR:
    if isinstance(value, ArtifactRefIR):
        return value
    if isinstance(value, dict):
        return ArtifactRefIR.from_dict(value)
    raise TypeError("artifacts must contain ArtifactRefIR values.")


def _request_from_any(value: Any) -> ArtifactListRequestIR:
    if isinstance(value, ArtifactListRequestIR):
        return value
    if isinstance(value, dict):
        return ArtifactListRequestIR.from_dict(value)
    raise TypeError("request must be ArtifactListRequestIR or object.")


def _page_ref_from_any(value: Any) -> ArtifactPageRefIR:
    if isinstance(value, ArtifactPageRefIR):
        return value
    if isinstance(value, dict):
        return ArtifactPageRefIR.from_dict(value)
    raise TypeError("page must be ArtifactPageRefIR or object.")


def _page_ref_from_optional(value: Any) -> ArtifactPageRefIR | None:
    if value is None:
        return None
    return _page_ref_from_any(value)


def _page_offset(page_token: str | None) -> int:
    if page_token is None:
        return 0
    if not page_token.startswith("offset:"):
        raise ValueError("page_token must use offset:<n> format.")
    offset = int(page_token.split(":", 1)[1])
    if offset < 0:
        raise ValueError("page_token offset must be non-negative.")
    return offset


def _is_inline_placeholder(artifact: ArtifactRefIR) -> bool:
    storage_uri = artifact.storage_uri.lower()
    storage_marker = str(artifact.metadata.get("storage", "")).lower()
    return (
        storage_uri.startswith("memory://")
        or storage_uri.startswith("inline://")
        or storage_marker == "inline_placeholder"
    )


def _is_expired_artifact(artifact: ArtifactRefIR) -> bool:
    if artifact.expires_at is None:
        return False
    return str(artifact.expires_at).lower() in {"expired", "offline_expired"}


def _diagnostic(
    *,
    diagnostic_id: str,
    severity: str,
    code: str,
    message: str,
    object_path: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> DiagnosticsIR:
    if severity not in ("info", "warning", "error"):
        raise ValueError(f"Unsupported diagnostic severity: {severity}")
    return with_diagnostic_taxonomy(
        DiagnosticsIR(
            diagnostic_id=diagnostic_id,
            stage="validation",
            severity=cast(Any, severity),
            code=code,
            message=message,
            object_path=object_path,
            metadata={} if metadata is None else _redact_mapping(metadata),
        ),
        reason_category="artifact_access",
        action="inspect_artifact_reference_metadata",
    )


def _json_object(text: str, model_name: str) -> dict[str, Any]:
    data = json.loads(text)
    if not isinstance(data, dict):
        raise TypeError(f"{model_name} JSON must contain an object.")
    return data


def _redact_mapping(data: dict[str, Any]) -> dict[str, Any]:
    redacted: dict[str, Any] = {}
    for key, value in data.items():
        lowered = str(key).lower()
        if any(token in lowered for token in _SECRET_KEY_MARKERS):
            redacted[str(key)] = "<redacted>"
        else:
            redacted[str(key)] = _redact_value(value)
    return redacted


def _redact_value(value: Any) -> Any:
    if isinstance(value, dict):
        return _redact_mapping(value)
    if isinstance(value, list):
        return [_redact_value(item) for item in value]
    if isinstance(value, tuple):
        return tuple(_redact_value(item) for item in value)
    return value
