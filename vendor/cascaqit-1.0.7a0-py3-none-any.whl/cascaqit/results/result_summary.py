"""User-facing ResultIR / DiagnosticsIR / RunTraceIR summaries."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.native_ir.base import IRMixin, canonicalize
from cascaqit.native_ir.models import SCHEMA_VERSION
from cascaqit.readiness.audit import redact_audit_metadata
from cascaqit.results.models import ResultIR, RunTraceIR

__all__ = [
    "ResultDiagnosticsTraceSummaryIR",
    "build_result_diagnostics_trace_summary",
]


@dataclass(frozen=True)
class ResultDiagnosticsTraceSummaryIR(IRMixin):
    """Read-only summary derived only from ResultIR, diagnostics, and run trace."""

    summary_id: str
    result_id: str
    target_id: str
    shots: int
    counts_summary: dict[str, Any]
    probabilities_summary: dict[str, Any]
    diagnostic_summary: dict[str, Any]
    trace_summary: dict[str, Any]
    references: dict[str, Any]
    backend_boundary: dict[str, Any]
    metadata_summary: dict[str, Any]
    metadata_only: bool = True
    derived_view: bool = True
    source_result_mutated: bool = False
    artifact_bytes_read: bool = False
    backend_called: bool = False
    network_accessed: bool = False
    object_store_accessed: bool = False
    signed_url_issued: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize summary payloads and enforce no-side-effect boundaries."""
        if not self.metadata_only:
            raise ValueError("ResultDiagnosticsTraceSummaryIR must be metadata-only.")
        if not self.derived_view:
            raise ValueError("ResultDiagnosticsTraceSummaryIR must be a derived view.")
        if self.source_result_mutated:
            raise ValueError(
                "ResultDiagnosticsTraceSummaryIR must not mutate source ResultIR."
            )
        if self.artifact_bytes_read:
            raise ValueError(
                "ResultDiagnosticsTraceSummaryIR must not read artifact bytes."
            )
        if self.backend_called:
            raise ValueError("ResultDiagnosticsTraceSummaryIR must not call backends.")
        if self.network_accessed:
            raise ValueError("ResultDiagnosticsTraceSummaryIR cannot access networks.")
        if self.object_store_accessed:
            raise ValueError(
                "ResultDiagnosticsTraceSummaryIR cannot access object stores."
            )
        if self.signed_url_issued:
            raise ValueError(
                "ResultDiagnosticsTraceSummaryIR cannot issue signed URLs."
            )
        object.__setattr__(self, "counts_summary", canonicalize(self.counts_summary))
        object.__setattr__(
            self,
            "probabilities_summary",
            canonicalize(self.probabilities_summary),
        )
        object.__setattr__(
            self,
            "diagnostic_summary",
            canonicalize(self.diagnostic_summary),
        )
        object.__setattr__(self, "trace_summary", canonicalize(self.trace_summary))
        object.__setattr__(
            self,
            "references",
            redact_audit_metadata(dict(self.references)),
        )
        object.__setattr__(
            self,
            "backend_boundary",
            canonicalize(self.backend_boundary),
        )
        object.__setattr__(
            self,
            "metadata_summary",
            canonicalize(self.metadata_summary),
        )
        object.__setattr__(self, "metadata", redact_audit_metadata(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ResultDiagnosticsTraceSummaryIR:
        """Build a summary from a JSON-compatible dictionary."""
        if not isinstance(data, dict):
            raise TypeError(
                "ResultDiagnosticsTraceSummaryIR dictionary must be an object."
            )
        return cls(
            summary_id=str(data["summary_id"]),
            result_id=str(data["result_id"]),
            target_id=str(data["target_id"]),
            shots=int(data["shots"]),
            counts_summary=dict(data["counts_summary"]),
            probabilities_summary=dict(data["probabilities_summary"]),
            diagnostic_summary=dict(data["diagnostic_summary"]),
            trace_summary=dict(data["trace_summary"]),
            references=dict(data.get("references", {})),
            backend_boundary=dict(data["backend_boundary"]),
            metadata_summary=dict(data["metadata_summary"]),
            metadata_only=bool(data.get("metadata_only", True)),
            derived_view=bool(data.get("derived_view", True)),
            source_result_mutated=bool(data.get("source_result_mutated", False)),
            artifact_bytes_read=bool(data.get("artifact_bytes_read", False)),
            backend_called=bool(data.get("backend_called", False)),
            network_accessed=bool(data.get("network_accessed", False)),
            object_store_accessed=bool(data.get("object_store_accessed", False)),
            signed_url_issued=bool(data.get("signed_url_issued", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> ResultDiagnosticsTraceSummaryIR:
        """Build a summary from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError(
                "ResultDiagnosticsTraceSummaryIR JSON must contain an object."
            )
        return cls.from_dict(data)


def build_result_diagnostics_trace_summary(
    result: ResultIR,
    *,
    summary_id: str | None = None,
) -> ResultDiagnosticsTraceSummaryIR:
    """Build a no-side-effect user summary from ResultIR only."""
    if not isinstance(result, ResultIR):
        raise TypeError("result must be ResultIR.")
    result_before = result.to_dict()
    trace = _run_trace_from_result(result)
    references = _references(result, trace)
    summary = ResultDiagnosticsTraceSummaryIR(
        summary_id=summary_id or f"result_diagnostics_trace_summary.{result.result_id}",
        result_id=result.result_id,
        target_id=result.target_id,
        shots=result.shots,
        counts_summary=_counts_summary(result),
        probabilities_summary=_probabilities_summary(result),
        diagnostic_summary=_diagnostic_summary(result.diagnostics),
        trace_summary=_trace_summary(trace),
        references=references,
        backend_boundary=_backend_boundary(result),
        metadata_summary=_metadata_summary(result),
        metadata_only=True,
        derived_view=True,
        source_result_mutated=False,
        artifact_bytes_read=False,
        backend_called=False,
        network_accessed=False,
        object_store_accessed=False,
        signed_url_issued=False,
        metadata={
            "source": "ResultIR",
            "inputs": ["ResultIR", "DiagnosticsIR", "RunTraceIR"],
            "summary_is_fact_source": False,
            "fact_source": "ResultIR",
        },
    )
    if result.to_dict() != result_before:
        raise ValueError("Result diagnostics trace summary mutated source ResultIR.")
    return summary


def _counts_summary(result: ResultIR) -> dict[str, Any]:
    return {
        "total": sum(result.counts.values()),
        "outcome_count": len(result.counts),
        "top_outcome": _top_count(result.counts),
        "has_counts": bool(result.counts),
    }


def _top_count(counts: dict[str, int]) -> dict[str, Any] | None:
    if not counts:
        return None
    key, value = max(counts.items(), key=lambda item: (item[1], item[0]))
    return {"outcome": key, "count": value}


def _probabilities_summary(result: ResultIR) -> dict[str, Any]:
    probabilities = result.probabilities
    if probabilities is None:
        return {
            "available": False,
            "outcome_count": 0,
            "probability_mass": None,
            "top_outcome": None,
        }
    return {
        "available": True,
        "outcome_count": len(probabilities),
        "probability_mass": sum(probabilities.values()),
        "top_outcome": _top_probability(probabilities),
    }


def _top_probability(probabilities: dict[str, float]) -> dict[str, Any] | None:
    if not probabilities:
        return None
    key, value = max(probabilities.items(), key=lambda item: (item[1], item[0]))
    return {"outcome": key, "probability": value}


def _diagnostic_summary(
    diagnostics: tuple[DiagnosticsIR, ...],
) -> dict[str, Any]:
    by_severity: dict[str, int] = {}
    for diagnostic in diagnostics:
        by_severity[diagnostic.severity] = (
            by_severity.get(diagnostic.severity, 0) + 1
        )
    return {
        "count": len(diagnostics),
        "codes": [diagnostic.code for diagnostic in diagnostics],
        "by_severity": by_severity,
        "has_errors": any(diagnostic.severity == "error" for diagnostic in diagnostics),
        "has_warnings": any(
            diagnostic.severity == "warning" for diagnostic in diagnostics
        ),
    }


def _trace_summary(trace: RunTraceIR | None) -> dict[str, Any]:
    if trace is None:
        return {
            "available": False,
            "trace_id": None,
            "status": "missing",
            "event_count": 0,
            "stages": [],
            "terminal_stage": None,
        }
    stages = [event.stage for event in trace.events]
    terminal_stage = None if not stages else stages[-1]
    return {
        "available": True,
        "trace_id": trace.trace_id,
        "status": "completed" if terminal_stage == "completed" else terminal_stage,
        "event_count": len(trace.events),
        "stages": stages,
        "terminal_stage": terminal_stage,
    }


def _references(result: ResultIR, trace: RunTraceIR | None) -> dict[str, Any]:
    raw_references = result.metadata.get("references")
    if isinstance(raw_references, dict):
        return dict(raw_references)
    if trace is not None:
        return trace.references.to_dict()
    return {"program_hash": result.program_hash}


def _backend_boundary(result: ResultIR) -> dict[str, Any]:
    metadata = result.metadata
    backend = metadata.get("backend")
    backend_metadata = backend if isinstance(backend, dict) else {}
    return {
        "backend_id": backend_metadata.get("backend_id"),
        "backend_kind": backend_metadata.get("backend_kind"),
        "program_type": backend_metadata.get("program_type")
        or metadata.get("program_type"),
        "package_execution": _bool_flag(metadata, "package_execution"),
        "physical_result": _bool_flag(metadata, "physical_result"),
        "hardware_execution": _bool_flag(metadata, "hardware_execution"),
        "cloud_execution": _bool_flag(metadata, "cloud_execution"),
        "cloud_compile_used": _bool_flag(metadata, "cloud_compile_used"),
        "dry_run": bool(metadata.get("dry_run", False)),
        "network_accessed": _bool_flag(metadata, "network_accessed"),
    }


def _bool_flag(metadata: dict[str, Any], key: str) -> bool:
    value = metadata.get(key)
    if isinstance(value, bool):
        return value
    backend = metadata.get("backend")
    if isinstance(backend, dict) and isinstance(backend.get(key), bool):
        return bool(backend[key])
    runtime = metadata.get("runtime")
    if isinstance(runtime, dict) and isinstance(runtime.get(key), bool):
        return bool(runtime[key])
    return False


def _metadata_summary(result: ResultIR) -> dict[str, Any]:
    metadata = result.metadata
    artifact_refs = result.artifact_refs()
    return {
        "metadata_keys": sorted(metadata),
        "artifact_ref_count": len(artifact_refs),
        "artifact_kinds": sorted(
            {artifact.artifact_kind for artifact in artifact_refs}
        ),
        "has_run_trace": isinstance(metadata.get("run_trace"), dict),
        "has_references": isinstance(metadata.get("references"), dict),
        "has_backend_metadata": isinstance(metadata.get("backend"), dict),
        "metadata_only": True,
    }


def _run_trace_from_result(result: ResultIR) -> RunTraceIR | None:
    raw_trace = result.metadata.get("run_trace")
    if not isinstance(raw_trace, dict):
        return None
    try:
        return RunTraceIR.from_dict(raw_trace)
    except (KeyError, TypeError, ValueError):
        return None
