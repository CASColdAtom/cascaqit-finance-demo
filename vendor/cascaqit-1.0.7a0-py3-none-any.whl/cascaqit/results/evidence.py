"""Current consumer-facing result evidence helpers."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.native_ir.base import IRMixin, canonicalize
from cascaqit.native_ir.models import SCHEMA_VERSION
from cascaqit.readiness.audit import redact_audit_metadata
from cascaqit.results.models import (
    ArtifactRefIR,
    ResultIR,
    RunTraceIR,
    result_references_from_result,
)

__all__ = ["ResultEvidenceIR", "build_result_evidence"]


@dataclass(frozen=True)
class ResultEvidenceIR(IRMixin):
    """Side-effect-free summary of execution evidence carried by a result."""

    evidence_id: str
    result_id: str
    program_hash: str
    target_id: str
    references: dict[str, Any]
    trace_id: str | None
    trace_summary: dict[str, Any]
    diagnostics: tuple[DiagnosticsIR, ...]
    artifact_refs: tuple[dict[str, Any], ...]
    bit_order: dict[str, Any]
    measurement_mapping: dict[str, Any]
    backend_boundary: dict[str, Any]
    execution_config: dict[str, Any] | None
    solver_evidence: dict[str, Any] | None
    state_transitions: tuple[dict[str, Any], ...]
    fact_source: str = "ResultIR"
    derived_view: bool = True
    metadata_only: bool = True
    source_result_mutated: bool = False
    artifact_bytes_read: bool = False
    backend_called: bool = False
    network_accessed: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.fact_source != "ResultIR":
            raise ValueError("ResultEvidenceIR fact_source must be ResultIR.")
        if not self.derived_view:
            raise ValueError("ResultEvidenceIR must remain a derived view.")
        if not self.metadata_only:
            raise ValueError("ResultEvidenceIR must be metadata-only.")
        if self.source_result_mutated:
            raise ValueError("ResultEvidenceIR must not mutate source ResultIR.")
        if self.artifact_bytes_read:
            raise ValueError("ResultEvidenceIR must not read artifact bytes.")
        if self.backend_called:
            raise ValueError("ResultEvidenceIR must not call backends.")
        if self.network_accessed:
            raise ValueError("ResultEvidenceIR cannot access networks.")
        object.__setattr__(self, "references", _redacted_canonical(self.references))
        object.__setattr__(
            self,
            "trace_summary",
            _redacted_canonical(self.trace_summary),
        )
        object.__setattr__(
            self,
            "diagnostics",
            tuple(_diagnostic_from_any(item) for item in self.diagnostics),
        )
        object.__setattr__(
            self,
            "artifact_refs",
            tuple(_artifact_ref_from_any(item) for item in self.artifact_refs),
        )
        object.__setattr__(self, "bit_order", _redacted_canonical(self.bit_order))
        object.__setattr__(
            self,
            "measurement_mapping",
            _redacted_canonical(self.measurement_mapping),
        )
        object.__setattr__(
            self,
            "backend_boundary",
            _redacted_canonical(self.backend_boundary),
        )
        object.__setattr__(
            self,
            "execution_config",
            None
            if self.execution_config is None
            else _redacted_canonical(self.execution_config),
        )
        object.__setattr__(
            self,
            "solver_evidence",
            None
            if self.solver_evidence is None
            else _redacted_canonical(self.solver_evidence),
        )
        object.__setattr__(
            self,
            "state_transitions",
            tuple(_redacted_canonical(item) for item in self.state_transitions),
        )
        object.__setattr__(self, "metadata", redact_audit_metadata(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ResultEvidenceIR:
        if not isinstance(data, dict):
            raise TypeError("ResultEvidenceIR dictionary must be an object.")
        return cls(
            evidence_id=str(data["evidence_id"]),
            result_id=str(data["result_id"]),
            program_hash=str(data["program_hash"]),
            target_id=str(data["target_id"]),
            references=dict(data.get("references", {})),
            trace_id=(
                None if data.get("trace_id") is None else str(data["trace_id"])
            ),
            trace_summary=dict(data.get("trace_summary", {})),
            diagnostics=tuple(data.get("diagnostics", ())),
            artifact_refs=tuple(data.get("artifact_refs", ())),
            bit_order=dict(data.get("bit_order", {})),
            measurement_mapping=dict(data.get("measurement_mapping", {})),
            backend_boundary=dict(data.get("backend_boundary", {})),
            execution_config=(
                None
                if data.get("execution_config") is None
                else dict(data["execution_config"])
            ),
            solver_evidence=(
                None
                if data.get("solver_evidence") is None
                else dict(data["solver_evidence"])
            ),
            state_transitions=tuple(
                dict(item) for item in data.get("state_transitions", ())
            ),
            fact_source=str(data.get("fact_source", "ResultIR")),
            derived_view=bool(data.get("derived_view", True)),
            metadata_only=bool(data.get("metadata_only", True)),
            source_result_mutated=bool(data.get("source_result_mutated", False)),
            artifact_bytes_read=bool(data.get("artifact_bytes_read", False)),
            backend_called=bool(data.get("backend_called", False)),
            network_accessed=bool(data.get("network_accessed", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> ResultEvidenceIR:
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("ResultEvidenceIR JSON must contain an object.")
        return cls.from_dict(data)


def build_result_evidence(
    result: ResultIR,
    *,
    evidence_id: str | None = None,
) -> ResultEvidenceIR:
    """Build evidence from public result fields without executing work."""
    if not isinstance(result, ResultIR):
        raise TypeError("result must be a native ResultIR instance.")
    references = result_references_from_result(result)
    execution_config = result.execution_config()
    solver_evidence = result.solver_evidence()
    return ResultEvidenceIR(
        evidence_id=evidence_id or f"result_evidence.{result.result_id}",
        result_id=result.result_id,
        program_hash=result.program_hash,
        target_id=result.target_id,
        references={} if references is None else references.to_dict(),
        trace_id=_trace_id(result),
        trace_summary=_trace_summary(result),
        diagnostics=tuple(result.diagnostics),
        artifact_refs=tuple(artifact.to_dict() for artifact in result.artifact_refs()),
        bit_order=dict(result.bit_ordering),
        measurement_mapping=_measurement_mapping(result),
        backend_boundary=_backend_boundary(result),
        execution_config=(
            None if execution_config is None else execution_config.to_dict()
        ),
        solver_evidence=(
            None if solver_evidence is None else solver_evidence.to_dict()
        ),
        state_transitions=tuple(
            transition.to_dict() for transition in result.state_transitions()
        ),
        metadata={
            "has_references": references is not None,
            "diagnostic_count": len(result.diagnostics),
            "artifact_ref_count": len(result.artifact_refs()),
            "fact_source": "ResultIR",
            "derived_view": True,
        },
    )


def _trace_id(result: ResultIR) -> str | None:
    raw_trace = result.metadata.get("run_trace")
    if isinstance(raw_trace, dict) and raw_trace.get("trace_id") is not None:
        return str(raw_trace["trace_id"])
    if not isinstance(raw_trace, dict):
        return None
    try:
        return RunTraceIR.from_dict(raw_trace).trace_id
    except (TypeError, KeyError, ValueError):
        return None


def _trace_summary(result: ResultIR) -> dict[str, Any]:
    raw_trace = result.metadata.get("run_trace")
    if not isinstance(raw_trace, dict):
        return {
            "trace_present": False,
            "trace_id": None,
            "event_count": 0,
            "terminal_stage": None,
        }
    try:
        trace = RunTraceIR.from_dict(raw_trace)
    except (TypeError, KeyError, ValueError):
        return {
            "trace_present": True,
            "trace_parseable": False,
            "trace_id": raw_trace.get("trace_id"),
            "event_count": 0,
            "terminal_stage": None,
        }
    return {
        "trace_present": True,
        "trace_parseable": True,
        "trace_id": trace.trace_id,
        "event_count": len(trace.events),
        "terminal_stage": None if not trace.events else trace.events[-1].stage,
    }


def _measurement_mapping(result: ResultIR) -> dict[str, Any]:
    value = result.metadata.get("measurement_mapping", {})
    return dict(value) if isinstance(value, dict) else {}


def _backend_boundary(result: ResultIR) -> dict[str, Any]:
    metadata = result.metadata
    return {
        "backend_name": metadata.get("backend_name"),
        "backend_kind": metadata.get("backend_kind"),
        "backend_job_id": metadata.get("backend_job_id"),
        "hardware_execution": bool(metadata.get("hardware_execution", False)),
        "cloud_execution": bool(metadata.get("cloud_execution", False)),
        "dry_run": bool(metadata.get("dry_run", False)),
        "metadata_only": bool(metadata.get("metadata_only", False)),
        "network_accessed": bool(metadata.get("network_accessed", False)),
        "fact_source": "ResultIR.metadata",
    }


def _diagnostic_from_any(item: DiagnosticsIR | dict[str, Any]) -> DiagnosticsIR:
    if isinstance(item, DiagnosticsIR):
        return item
    if isinstance(item, dict):
        return DiagnosticsIR.from_dict(item)
    raise TypeError("diagnostics must contain DiagnosticsIR or dictionaries.")


def _artifact_ref_from_any(item: dict[str, Any] | ArtifactRefIR) -> dict[str, Any]:
    if isinstance(item, ArtifactRefIR):
        return item.to_dict()
    if isinstance(item, dict):
        if any(key in item for key in ("content", "bytes", "raw_bytes")):
            raise ValueError("ResultEvidenceIR artifact refs must not contain bytes.")
        return _redacted_canonical(item)
    raise TypeError("artifact_refs must contain dictionaries or ArtifactRefIR.")


def _redacted_canonical(data: dict[str, Any]) -> dict[str, Any]:
    value = canonicalize(data)
    if not isinstance(value, dict):
        raise TypeError("canonical evidence payload must be a dictionary.")
    return redact_audit_metadata(value)
