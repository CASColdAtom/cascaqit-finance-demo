"""Artifact metadata store protocol and in-memory fake implementation."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Literal, Protocol

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.exceptions import CASCAQitRuntimeError
from cascaqit.native_ir.base import IRMixin
from cascaqit.native_ir.models import SCHEMA_VERSION
from cascaqit.results.models import ArtifactRefIR, BatchResultIR, ResultIR

__all__ = [
    "ArtifactStoreError",
    "ArtifactStoreProtocol",
    "ArtifactStoreRecordIR",
    "FakeArtifactStore",
]


class ArtifactStoreError(CASCAQitRuntimeError):
    """Raised when artifact metadata cannot be stored or retrieved."""

    def __init__(
        self,
        message: str,
        *,
        diagnostics: tuple[DiagnosticsIR, ...] = (),
    ) -> None:
        super().__init__(
            message,
            code="ARTIFACT_STORE_ERROR",
            stage="serialization",
            diagnostics=diagnostics,
        )
        self.diagnostics = diagnostics


class ArtifactStoreProtocol(Protocol):
    """Metadata-only artifact store boundary."""

    def put_metadata(self, artifact: ArtifactRefIR) -> ArtifactStoreRecordIR:
        """Store validated artifact metadata."""

    def get_metadata(self, artifact_id: str) -> ArtifactStoreRecordIR:
        """Return stored artifact metadata."""

    def list_metadata(
        self,
        *,
        artifact_kind: str | None = None,
        include_expired: bool = False,
    ) -> tuple[ArtifactStoreRecordIR, ...]:
        """List stored artifact metadata records."""


@dataclass(frozen=True)
class ArtifactStoreRecordIR(IRMixin):
    """Stored artifact metadata plus validation diagnostics."""

    artifact: ArtifactRefIR
    status: str
    diagnostics: tuple[DiagnosticsIR, ...] = ()
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ArtifactStoreRecordIR:
        """Build an artifact store record from a dictionary."""
        return cls(
            artifact=ArtifactRefIR.from_dict(data["artifact"]),
            status=str(data["status"]),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(diagnostic)
                for diagnostic in data.get("diagnostics", ())
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> ArtifactStoreRecordIR:
        """Build an artifact store record from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("ArtifactStoreRecordIR JSON must contain an object.")
        return cls.from_dict(data)


class FakeArtifactStore:
    """Deterministic in-memory metadata store for artifact refs."""

    def __init__(
        self,
        *,
        accepted_content_types: tuple[str, ...] = (
            "application/json",
            "text/plain",
        ),
        current_time: str = "offline",
    ) -> None:
        self.accepted_content_types = accepted_content_types
        self.current_time = current_time
        self._records: dict[str, ArtifactStoreRecordIR] = {}

    def put_metadata(self, artifact: ArtifactRefIR) -> ArtifactStoreRecordIR:
        """Validate and store artifact metadata only."""
        diagnostics = _artifact_diagnostics(
            artifact,
            accepted_content_types=self.accepted_content_types,
            current_time=self.current_time,
        )
        has_error = any(
            diagnostic.severity == "error" for diagnostic in diagnostics
        )
        if has_error:
            raise ArtifactStoreError(
                f"Artifact metadata is invalid: {artifact.artifact_id}",
                diagnostics=diagnostics,
            )
        record = ArtifactStoreRecordIR(
            artifact=artifact,
            status="available",
            diagnostics=diagnostics,
            metadata={
                "store": "fake_in_memory",
                "metadata_only": True,
            },
        )
        self._records[artifact.artifact_id] = record
        return record

    def get_metadata(self, artifact_id: str) -> ArtifactStoreRecordIR:
        """Return stored artifact metadata or raise a structured error."""
        if artifact_id not in self._records:
            raise ArtifactStoreError(
                f"Unknown artifact_id: {artifact_id}",
                diagnostics=(
                    _diagnostic(
                        diagnostic_id=f"artifact.{artifact_id}.missing",
                        code="ARTIFACT_METADATA_MISSING",
                        message="Artifact metadata is not present in this store.",
                        object_path="artifact_id",
                        severity="error",
                    ),
                ),
            )
        return self._records[artifact_id]

    def list_metadata(
        self,
        *,
        artifact_kind: str | None = None,
        include_expired: bool = False,
    ) -> tuple[ArtifactStoreRecordIR, ...]:
        """List metadata records with optional kind and expiry filters."""
        records = []
        for record in self._records.values():
            if (
                artifact_kind is not None
                and record.artifact.artifact_kind != artifact_kind
            ):
                continue
            if not include_expired and _is_expired(
                record.artifact,
                current_time=self.current_time,
            ):
                continue
            records.append(record)
        return tuple(
            sorted(records, key=lambda record: record.artifact.artifact_id)
        )

    def put_result_artifacts(
        self,
        result: ResultIR,
    ) -> tuple[ArtifactStoreRecordIR, ...]:
        """Store all artifact refs attached to a ResultIR."""
        return tuple(self.put_metadata(artifact) for artifact in result.artifact_refs())

    def put_batch_result_artifacts(
        self,
        batch_result: BatchResultIR,
    ) -> tuple[ArtifactStoreRecordIR, ...]:
        """Store aggregated and item-level artifact refs from a BatchResultIR."""
        artifacts = batch_result.artifact_refs() + batch_result.item_artifact_refs()
        unique: dict[str, ArtifactRefIR] = {
            artifact.artifact_id: artifact for artifact in artifacts
        }
        return tuple(self.put_metadata(artifact) for artifact in unique.values())


def _artifact_diagnostics(
    artifact: ArtifactRefIR,
    *,
    accepted_content_types: tuple[str, ...],
    current_time: str,
) -> tuple[DiagnosticsIR, ...]:
    diagnostics: list[DiagnosticsIR] = []
    if not _is_hex_sha256(artifact.checksum):
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"artifact.{artifact.artifact_id}.checksum",
                code="ARTIFACT_CHECKSUM_INVALID",
                message="Artifact checksum must be a SHA-256 hex digest.",
                object_path="artifact.checksum",
                severity="error",
            )
        )
    if artifact.size_bytes < 0:
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"artifact.{artifact.artifact_id}.size",
                code="ARTIFACT_SIZE_INVALID",
                message="Artifact size_bytes cannot be negative.",
                object_path="artifact.size_bytes",
                severity="error",
            )
        )
    if artifact.content_type not in accepted_content_types:
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"artifact.{artifact.artifact_id}.content_type",
                code="ARTIFACT_CONTENT_TYPE_UNSUPPORTED",
                message="Artifact content_type is not accepted by this store.",
                object_path="artifact.content_type",
                severity="error",
                metadata={"content_type": artifact.content_type},
            )
        )
    if _is_expired(artifact, current_time=current_time):
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"artifact.{artifact.artifact_id}.expired",
                code="ARTIFACT_EXPIRED",
                message="Artifact metadata is expired.",
                object_path="artifact.expires_at",
                severity="error",
                metadata={"expires_at": artifact.expires_at},
            )
        )
    if not diagnostics:
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"artifact.{artifact.artifact_id}.metadata_valid",
                code="ARTIFACT_METADATA_VALID",
                message="Artifact metadata validated by fake store.",
                object_path="artifact",
                severity="info",
            )
        )
    return tuple(diagnostics)


def _diagnostic(
    *,
    diagnostic_id: str,
    code: str,
    message: str,
    object_path: str,
    severity: Literal["info", "warning", "error"],
    metadata: dict[str, Any] | None = None,
) -> DiagnosticsIR:
    return DiagnosticsIR(
        diagnostic_id=diagnostic_id,
        stage="serialization",
        severity=severity,
        code=code,
        message=message,
        object_path=object_path,
        metadata={} if metadata is None else metadata,
    )


def _is_hex_sha256(value: str) -> bool:
    return len(value) == 64 and all(
        character in "0123456789abcdef" for character in value
    )


def _is_expired(artifact: ArtifactRefIR, *, current_time: str) -> bool:
    if artifact.expires_at is None:
        return False
    return artifact.expires_at < current_time
