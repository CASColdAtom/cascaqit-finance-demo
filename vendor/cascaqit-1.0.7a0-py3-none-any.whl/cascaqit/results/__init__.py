"""Result models for CASCAQit."""

from __future__ import annotations

from importlib import import_module
from typing import Any

from cascaqit.results.artifact_access import (
    ArtifactListRequestIR,
    ArtifactListResponseIR,
    ArtifactPageRefIR,
    build_artifact_access_summary,
    build_result_artifact_list_response,
    diagnose_artifact_access_response,
)
from cascaqit.results.artifact_object_store_contract import (
    ArtifactObjectStoreContractIR,
    build_artifact_object_store_contract,
)
from cascaqit.results.artifact_store import (
    ArtifactStoreError,
    ArtifactStoreProtocol,
    ArtifactStoreRecordIR,
    FakeArtifactStore,
)
from cascaqit.results.artifact_store_adapter import (
    ArtifactByteTransferPreflightIR,
    ArtifactStoreAdapterProtocol,
    FixtureReplayArtifactStoreAdapter,
    build_artifact_byte_transfer_preflight,
    redact_artifact_ref_for_adapter,
)
from cascaqit.results.evidence import (
    ResultEvidenceIR,
    build_result_evidence,
)
from cascaqit.results.models import (
    ArtifactRefIR,
    BatchItemResultRefIR,
    BatchResultIR,
    ResultIR,
    ResultReferencesIR,
    RunTraceEventIR,
    RunTraceIR,
    SimulationExecutionConfigIR,
    SimulationResourceUsageIR,
    SimulationSolverEvidenceIR,
    StateTransitionIR,
    resource_usage_from_metadata,
    result_references_from_metadata,
    result_references_from_result,
    result_references_projection_matches_metadata,
    simulation_execution_config_from_metadata,
    simulation_solver_evidence_from_metadata,
    state_transitions_from_metadata,
    validate_state_transition_chain,
)
from cascaqit.results.observability import (
    ArtifactManifestIR,
    build_artifact_manifest,
    measurement_mapping_summary,
    result_retention_metadata,
    result_trace_link_metadata,
    with_result_observability_metadata,
)
from cascaqit.results.result_summary import (
    ResultDiagnosticsTraceSummaryIR,
    build_result_diagnostics_trace_summary,
)

_EXPORT_MODULES: dict[str, str] = {
    "ResultViewIR": "cascaqit.results.result_view",
    "build_result_view": "cascaqit.results.result_view",
}

__all__ = [
    "ArtifactListRequestIR",
    "ArtifactListResponseIR",
    "ArtifactManifestIR",
    "ArtifactPageRefIR",
    "ArtifactRefIR",
    "ArtifactByteTransferPreflightIR",
    "ArtifactObjectStoreContractIR",
    "ArtifactStoreAdapterProtocol",
    "ArtifactStoreError",
    "ArtifactStoreProtocol",
    "ArtifactStoreRecordIR",
    "BatchItemResultRefIR",
    "BatchResultIR",
    "FakeArtifactStore",
    "FixtureReplayArtifactStoreAdapter",
    "ResultIR",
    "ResultReferencesIR",
    "RunTraceEventIR",
    "RunTraceIR",
    "StateTransitionIR",
    "SimulationExecutionConfigIR",
    "SimulationResourceUsageIR",
    "SimulationSolverEvidenceIR",
    "simulation_solver_evidence_from_metadata",
    "simulation_execution_config_from_metadata",
    "state_transitions_from_metadata",
    "validate_state_transition_chain",
    "resource_usage_from_metadata",
    "result_references_from_metadata",
    "result_references_projection_matches_metadata",
    "result_references_from_result",
    "ResultEvidenceIR",
    "ResultDiagnosticsTraceSummaryIR",
    "ResultViewIR",
    "build_artifact_access_summary",
    "build_artifact_byte_transfer_preflight",
    "build_artifact_object_store_contract",
    "build_artifact_manifest",
    "build_result_evidence",
    "build_result_diagnostics_trace_summary",
    "build_result_view",
    "build_result_artifact_list_response",
    "diagnose_artifact_access_response",
    "measurement_mapping_summary",
    "redact_artifact_ref_for_adapter",
    "result_retention_metadata",
    "result_trace_link_metadata",
    "with_result_observability_metadata",
]


def __getattr__(name: str) -> Any:
    """Lazily resolve result helper exports without importing interop early."""
    try:
        module_name = _EXPORT_MODULES[name]
    except KeyError as exc:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}") from exc
    value = getattr(import_module(module_name), name)
    globals()[name] = value
    return value
