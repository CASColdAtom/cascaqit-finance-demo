"""Current result artifact metadata helpers."""

from __future__ import annotations

import json
from dataclasses import dataclass, field, replace
from typing import Any

from cascaqit.native_ir.base import IRMixin
from cascaqit.native_ir.models import SCHEMA_VERSION
from cascaqit.results.models import ArtifactRefIR, ResultIR, RunTraceIR

__all__ = [
    "ArtifactManifestIR",
    "build_artifact_manifest",
    "measurement_mapping_summary",
    "result_retention_metadata",
    "result_trace_link_metadata",
    "with_result_observability_metadata",
]


@dataclass(frozen=True)
class ArtifactManifestIR(IRMixin):
    """Metadata-only summary of result artifact references."""

    manifest_id: str
    source_result_id: str
    artifact_count: int
    total_size_bytes: int
    artifacts: tuple[dict[str, Any], ...]
    retention: dict[str, Any]
    metadata_only: bool = True
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ArtifactManifestIR:
        return cls(
            manifest_id=str(data["manifest_id"]),
            source_result_id=str(data["source_result_id"]),
            artifact_count=int(data["artifact_count"]),
            total_size_bytes=int(data["total_size_bytes"]),
            artifacts=tuple(dict(item) for item in data.get("artifacts", ())),
            retention=dict(data["retention"]),
            metadata_only=bool(data.get("metadata_only", True)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> ArtifactManifestIR:
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("ArtifactManifestIR JSON must contain an object.")
        return cls.from_dict(data)


def build_artifact_manifest(
    result: ResultIR,
    *,
    manifest_id: str | None = None,
    retention_policy: str | None = None,
) -> ArtifactManifestIR:
    """Summarize artifact references without reading their bytes."""
    if not isinstance(result, ResultIR):
        raise TypeError("build_artifact_manifest accepts ResultIR.")
    artifacts = result.artifact_refs()
    return ArtifactManifestIR(
        manifest_id=manifest_id or f"artifact_manifest.{result.result_id}",
        source_result_id=result.result_id,
        artifact_count=len(artifacts),
        total_size_bytes=sum(item.size_bytes for item in artifacts),
        artifacts=tuple(_artifact_manifest_entry(item) for item in artifacts),
        retention=result_retention_metadata(
            result,
            artifacts=artifacts,
            retention_policy=retention_policy,
        ),
        metadata={
            "source": "ResultIR.metadata.artifact_refs",
            "stores_artifact_bytes": False,
            "artifact_kinds": sorted({item.artifact_kind for item in artifacts}),
        },
    )


def measurement_mapping_summary(
    measurement_mapping: dict[str, Any] | None,
) -> dict[str, Any]:
    """Return compact measurement mapping facts."""
    mapping = {} if measurement_mapping is None else measurement_mapping
    raw_measurements = mapping.get("measurements", ())
    measurements = (
        raw_measurements if isinstance(raw_measurements, (list, tuple)) else ()
    )
    bases: list[str] = []
    result_keys: list[str] = []
    site_counts: list[int] = []
    target_modes: list[str] = []
    for measurement in measurements:
        if not isinstance(measurement, dict):
            continue
        if measurement.get("basis") is not None:
            bases.append(str(measurement["basis"]))
        if measurement.get("result_key") is not None:
            result_keys.append(str(measurement["result_key"]))
        sites = measurement.get("sites", ())
        if isinstance(sites, (list, tuple)):
            site_counts.append(len(sites))
        targets = measurement.get("requested_targets", measurement.get("targets"))
        if targets is not None:
            target_modes.append(str(targets))
    return {
        "measurement_count": len(measurements),
        "basis_set": sorted(set(bases)),
        "result_keys": result_keys,
        "measured_site_count": sum(site_counts),
        "target_modes": sorted(set(target_modes)),
        "has_mapping": bool(mapping),
        "metadata_only": True,
    }


def result_trace_link_metadata(
    result: ResultIR,
    *,
    cloud_trace_id: str | None = None,
    local_trace_id: str | None = None,
) -> dict[str, Any]:
    """Build local/cloud trace correlation metadata."""
    if not isinstance(result, ResultIR):
        raise TypeError("result_trace_link_metadata accepts ResultIR.")
    run_trace = _run_trace_from_result(result)
    resolved_local_id = (
        local_trace_id
        or (None if run_trace is None else run_trace.trace_id)
        or result.metadata.get("trace_id")
    )
    return {
        "result_id": result.result_id,
        "local_trace_id": resolved_local_id,
        "cloud_trace_id": cloud_trace_id,
        "correlation_status": (
            "linked" if resolved_local_id and cloud_trace_id else "placeholder"
        ),
        "metadata_only": True,
    }


def result_retention_metadata(
    result: ResultIR,
    *,
    artifacts: tuple[ArtifactRefIR, ...] | None = None,
    retention_policy: str | None = None,
) -> dict[str, Any]:
    """Build expiration and retention summary metadata."""
    if not isinstance(result, ResultIR):
        raise TypeError("result_retention_metadata accepts ResultIR.")
    refs = result.artifact_refs() if artifacts is None else artifacts
    expirations = [item.expires_at for item in refs if item.expires_at is not None]
    policies = sorted({item.retention_policy for item in refs})
    return {
        "retention_policy": retention_policy or _default_retention_policy(policies),
        "artifact_retention_policies": policies,
        "artifact_count": len(refs),
        "expires_at": min(expirations) if expirations else None,
        "result_expiration_status": (
            "expires_with_artifacts" if expirations else "not_declared"
        ),
        "metadata_only": True,
    }


def with_result_observability_metadata(
    result: ResultIR,
    *,
    measurement_mapping: dict[str, Any] | None = None,
    cloud_trace_id: str | None = None,
    retention_policy: str | None = None,
) -> ResultIR:
    """Return a result copy with artifact and trace summaries."""
    if not isinstance(result, ResultIR):
        raise TypeError("with_result_observability_metadata accepts ResultIR.")
    manifest = build_artifact_manifest(result, retention_policy=retention_policy)
    return replace(
        result,
        metadata={
            **result.metadata,
            "artifact_manifest_summary": manifest.to_dict(),
            "measurement_mapping_summary": measurement_mapping_summary(
                measurement_mapping
            ),
            "trace_links": result_trace_link_metadata(
                result,
                cloud_trace_id=cloud_trace_id,
            ),
            "retention": manifest.retention,
        },
    )


def _artifact_manifest_entry(artifact: ArtifactRefIR) -> dict[str, Any]:
    return {
        "artifact_id": artifact.artifact_id,
        "artifact_kind": artifact.artifact_kind,
        "storage_uri": artifact.storage_uri,
        "checksum": artifact.checksum,
        "size_bytes": artifact.size_bytes,
        "content_type": artifact.content_type,
        "retention_policy": artifact.retention_policy,
        "created_at": artifact.created_at,
        "expires_at": artifact.expires_at,
        "metadata": dict(artifact.metadata),
    }


def _run_trace_from_result(result: ResultIR) -> RunTraceIR | None:
    raw_trace = result.metadata.get("run_trace")
    if not isinstance(raw_trace, dict):
        return None
    try:
        return RunTraceIR.from_dict(raw_trace)
    except (KeyError, TypeError, ValueError):
        return None


def _default_retention_policy(policies: list[str]) -> str:
    if not policies:
        return "result-metadata-only"
    if len(policies) == 1:
        return policies[0]
    return "mixed"
