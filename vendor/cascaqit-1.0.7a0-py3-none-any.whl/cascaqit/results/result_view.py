"""Native result view contracts for runtime ergonomics."""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.native_ir.base import IRMixin, canonicalize
from cascaqit.native_ir.models import SCHEMA_VERSION
from cascaqit.readiness.audit import redact_audit_metadata
from cascaqit.results import (
    ArtifactManifestIR,
    ResultIR,
    RunTraceIR,
    result_references_from_result,
)

__all__ = ["ResultViewIR", "build_result_view"]


@dataclass(frozen=True)
class ResultViewIR(IRMixin):
    """Read-only native view over public result facts."""

    view_id: str
    result_id: str
    program_hash: str
    target_id: str
    shots: int
    counts: dict[str, int]
    samples: tuple[str, ...]
    probabilities: dict[str, float] | None
    observable_batch: dict[str, Any] | None
    bit_order: dict[str, Any]
    measurement_mapping: dict[str, Any]
    metadata: dict[str, Any]
    diagnostics: tuple[DiagnosticsIR, ...]
    artifact_refs: tuple[dict[str, Any], ...]
    artifact_manifest_summary: dict[str, Any]
    trace_id: str | None
    result_references: dict[str, Any]
    execution_config: dict[str, Any] | None
    solver_evidence: dict[str, Any] | None
    state_transitions: tuple[dict[str, Any], ...]
    metadata_only: bool = True
    source_result_mutated: bool = False
    result_interpreted: bool = False
    artifact_bytes_read: bool = False
    backend_called: bool = False
    network_accessed: bool = False
    schema_version: str = SCHEMA_VERSION

    def __post_init__(self) -> None:
        """Normalize view payloads and enforce no-side-effect boundaries."""
        if not self.metadata_only:
            raise ValueError("ResultViewIR must be metadata-only.")
        if self.source_result_mutated:
            raise ValueError("ResultViewIR must not mutate source ResultIR.")
        if self.result_interpreted:
            raise ValueError("ResultViewIR must not interpret result payloads.")
        if self.artifact_bytes_read:
            raise ValueError("ResultViewIR must not read artifact bytes.")
        if self.backend_called:
            raise ValueError("ResultViewIR must not call backends.")
        if self.network_accessed:
            raise ValueError("ResultViewIR cannot access networks.")
        object.__setattr__(self, "counts", dict(self.counts))
        object.__setattr__(self, "samples", tuple(str(item) for item in self.samples))
        object.__setattr__(
            self,
            "probabilities",
            None if self.probabilities is None else dict(self.probabilities),
        )
        object.__setattr__(
            self,
            "observable_batch",
            None
            if self.observable_batch is None
            else canonicalize(self.observable_batch),
        )
        object.__setattr__(self, "bit_order", canonicalize(self.bit_order))
        object.__setattr__(
            self,
            "measurement_mapping",
            canonicalize(self.measurement_mapping),
        )
        object.__setattr__(self, "metadata", redact_audit_metadata(self.metadata))
        object.__setattr__(
            self,
            "diagnostics",
            tuple(_diagnostic_from_any(item) for item in self.diagnostics),
        )
        object.__setattr__(
            self,
            "artifact_refs",
            tuple(_artifact_ref_from_any(item) for item in self.artifact_refs),
        )
        object.__setattr__(
            self,
            "artifact_manifest_summary",
            canonicalize(self.artifact_manifest_summary),
        )
        object.__setattr__(
            self,
            "result_references",
            redact_audit_metadata(dict(self.result_references)),
        )
        object.__setattr__(
            self,
            "execution_config",
            None
            if self.execution_config is None
            else canonicalize(self.execution_config),
        )
        object.__setattr__(
            self,
            "solver_evidence",
            None
            if self.solver_evidence is None
            else canonicalize(self.solver_evidence),
        )
        object.__setattr__(
            self,
            "state_transitions",
            tuple(canonicalize(item) for item in self.state_transitions),
        )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ResultViewIR:
        """Build a result view from a JSON-compatible dictionary."""
        if not isinstance(data, dict):
            raise TypeError("ResultViewIR dictionary must be an object.")
        return cls(
            view_id=str(data["view_id"]),
            result_id=str(data["result_id"]),
            program_hash=str(data["program_hash"]),
            target_id=str(data["target_id"]),
            shots=int(data["shots"]),
            counts={str(key): int(value) for key, value in data["counts"].items()},
            samples=tuple(str(item) for item in data.get("samples", ())),
            probabilities=None
            if data.get("probabilities") is None
            else {
                str(key): float(value)
                for key, value in data["probabilities"].items()
            },
            observable_batch=(
                None
                if data.get("observable_batch") is None
                else dict(data["observable_batch"])
            ),
            bit_order=dict(data.get("bit_order", {})),
            measurement_mapping=dict(data.get("measurement_mapping", {})),
            metadata=dict(data.get("metadata", {})),
            diagnostics=tuple(
                _diagnostic_from_any(item) for item in data.get("diagnostics", ())
            ),
            artifact_refs=tuple(
                _artifact_ref_from_any(item) for item in data.get("artifact_refs", ())
            ),
            artifact_manifest_summary=dict(
                data.get("artifact_manifest_summary", {})
            ),
            trace_id=data.get("trace_id"),
            result_references=dict(data.get("result_references", {})),
            execution_config=(
                None
                if data.get("execution_config") is None
                else dict(data["execution_config"])
            ),
            solver_evidence=(
                None
                if data.get("solver_evidence") is None
                else dict(data["solver_evidence"])
            ),
            state_transitions=tuple(
                dict(item) for item in data.get("state_transitions", ())
            ),
            metadata_only=bool(data.get("metadata_only", True)),
            source_result_mutated=bool(data.get("source_result_mutated", False)),
            result_interpreted=bool(data.get("result_interpreted", False)),
            artifact_bytes_read=bool(data.get("artifact_bytes_read", False)),
            backend_called=bool(data.get("backend_called", False)),
            network_accessed=bool(data.get("network_accessed", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
        )

    @classmethod
    def from_json(cls, text: str) -> ResultViewIR:
        """Build a result view from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("ResultViewIR JSON must contain an object.")
        return cls.from_dict(data)


def build_result_view(
    result: ResultIR,
    *,
    artifact_manifest: ArtifactManifestIR | None = None,
    view_id: str | None = None,
) -> ResultViewIR:
    """Build a metadata-only view without mutating ResultIR or reading artifacts."""
    if not isinstance(result, ResultIR):
        raise TypeError(
            "result must be a native ResultIR instance."
        )
    if artifact_manifest is not None and not isinstance(
        artifact_manifest,
        ArtifactManifestIR,
    ):
        raise TypeError(
            "artifact_manifest must be ArtifactManifestIR or None. Use "
            "build_artifact_manifest(result) for metadata-only artifact summaries."
        )
    references = result_references_from_result(result)
    execution_config = result.execution_config()
    solver_evidence = result.solver_evidence()
    return ResultViewIR(
        view_id=view_id or f"result_view.{result.result_id}",
        result_id=result.result_id,
        program_hash=result.program_hash,
        target_id=result.target_id,
        shots=result.shots,
        counts=dict(result.counts),
        samples=tuple(result.samples),
        probabilities=None
        if result.probabilities is None
        else dict(result.probabilities),
        observable_batch=(
            None
            if result.observable_batch is None
            else result.observable_batch.to_dict()
        ),
        bit_order=dict(result.bit_ordering),
        measurement_mapping=_measurement_mapping(result),
        metadata=dict(result.metadata),
        diagnostics=tuple(result.diagnostics),
        artifact_refs=tuple(artifact.to_dict() for artifact in result.artifact_refs()),
        artifact_manifest_summary=_artifact_manifest_summary(artifact_manifest),
        trace_id=_trace_id(result),
        result_references={} if references is None else references.to_dict(),
        execution_config=(
            None if execution_config is None else execution_config.to_dict()
        ),
        solver_evidence=None if solver_evidence is None else solver_evidence.to_dict(),
        state_transitions=tuple(
            transition.to_dict() for transition in result.state_transitions()
        ),
        metadata_only=True,
        source_result_mutated=False,
        result_interpreted=False,
        artifact_bytes_read=False,
        backend_called=False,
        network_accessed=False,
    )


def _measurement_mapping(result: ResultIR) -> dict[str, Any]:
    """Read optional public measurement metadata without private package facts."""
    value = result.metadata.get("measurement_mapping", {})
    return dict(value) if isinstance(value, dict) else {}


def _artifact_manifest_summary(
    artifact_manifest: ArtifactManifestIR | None,
) -> dict[str, Any]:
    if artifact_manifest is None:
        return {
            "manifest_id": None,
            "artifact_count": None,
            "total_size_bytes": None,
            "metadata_only": True,
            "attached": False,
            "stores_artifact_bytes": False,
        }
    return {
        "manifest_id": artifact_manifest.manifest_id,
        "artifact_count": artifact_manifest.artifact_count,
        "total_size_bytes": artifact_manifest.total_size_bytes,
        "metadata_only": artifact_manifest.metadata_only,
        "attached": True,
        "stores_artifact_bytes": bool(
            artifact_manifest.metadata.get("stores_artifact_bytes", False)
        ),
    }


def _trace_id(result: ResultIR) -> str | None:
    raw_trace = result.metadata.get("run_trace")
    if isinstance(raw_trace, dict) and raw_trace.get("trace_id") is not None:
        return str(raw_trace["trace_id"])
    if not isinstance(raw_trace, dict):
        return None
    try:
        return RunTraceIR.from_dict(raw_trace).trace_id
    except (TypeError, KeyError, ValueError):
        return None


def _diagnostic_from_any(item: DiagnosticsIR | dict[str, Any]) -> DiagnosticsIR:
    if isinstance(item, DiagnosticsIR):
        return item
    if isinstance(item, dict):
        return DiagnosticsIR.from_dict(item)
    raise TypeError("diagnostics must contain DiagnosticsIR or dictionaries.")


def _artifact_ref_from_any(item: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(item, dict):
        raise TypeError("artifact_refs must contain dictionaries.")
    canonical = canonicalize(dict(item))
    if not isinstance(canonical, dict):
        raise TypeError("artifact_refs must canonicalize to dictionaries.")
    return canonical
