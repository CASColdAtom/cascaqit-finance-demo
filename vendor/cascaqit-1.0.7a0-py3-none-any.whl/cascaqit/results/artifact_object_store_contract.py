"""Artifact object store readiness contracts."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Literal, cast

from cascaqit.diagnostics import DiagnosticsIR, with_diagnostic_taxonomy
from cascaqit.native_ir.base import IRMixin
from cascaqit.native_ir.models import SCHEMA_VERSION
from cascaqit.results.artifact_store import ArtifactStoreRecordIR
from cascaqit.results.artifact_store_adapter import (
    ArtifactByteTransferPreflightIR,
)

__all__ = [
    "ArtifactObjectStoreContractIR",
    "ArtifactObjectStoreContractStatus",
    "build_artifact_object_store_contract",
]

ArtifactObjectStoreContractStatus = Literal["blocked", "ready"]

_SECRET_KEY_MARKERS = (
    "access_key",
    "api_key",
    "apikey",
    "authorization",
    "credential",
    "password",
    "private_key",
    "secret",
    "signature",
    "signed_url",
    "token",
    "x-amz",
)


@dataclass(frozen=True)
class ArtifactObjectStoreContractIR(IRMixin):
    """Metadata-only object store contract over artifact records."""

    contract_id: str
    store_id: str
    status: ArtifactObjectStoreContractStatus
    records: tuple[ArtifactStoreRecordIR, ...]
    diagnostics: tuple[DiagnosticsIR, ...]
    byte_transfer_preflight: ArtifactByteTransferPreflightIR | None = None
    retention_policies: tuple[str, ...] = ()
    signed_reference_policy: str = "metadata_reference_only"
    metadata_only: bool = True
    object_store_accessed: bool = False
    network_accessed: bool = False
    artifact_bytes_read: bool = False
    signed_url_exported: bool = False
    raw_secret_loaded: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize nested IRs and reject live object-store side effects."""
        if self.status not in ("blocked", "ready"):
            raise ValueError(f"Unsupported artifact object store status: {self.status}")
        if not self.metadata_only:
            raise ValueError("ArtifactObjectStoreContractIR must be metadata-only.")
        if self.object_store_accessed:
            raise ValueError(
                "ArtifactObjectStoreContractIR cannot access object stores."
            )
        if self.network_accessed:
            raise ValueError("ArtifactObjectStoreContractIR cannot access networks.")
        if self.artifact_bytes_read:
            raise ValueError(
                "ArtifactObjectStoreContractIR cannot read artifact bytes."
            )
        if self.signed_url_exported:
            raise ValueError("ArtifactObjectStoreContractIR cannot export signed URLs.")
        if self.raw_secret_loaded:
            raise ValueError("ArtifactObjectStoreContractIR cannot load raw secrets.")
        object.__setattr__(
            self,
            "records",
            tuple(_record_from_any(record) for record in self.records),
        )
        object.__setattr__(
            self,
            "diagnostics",
            tuple(_diagnostic_from_any(item) for item in self.diagnostics),
        )
        object.__setattr__(
            self,
            "retention_policies",
            tuple(str(policy) for policy in self.retention_policies),
        )
        if self.byte_transfer_preflight is not None and not isinstance(
            self.byte_transfer_preflight,
            ArtifactByteTransferPreflightIR,
        ):
            raise TypeError(
                "byte_transfer_preflight must be "
                "ArtifactByteTransferPreflightIR or None."
            )
        object.__setattr__(self, "metadata", _redact_mapping(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ArtifactObjectStoreContractIR:
        """Build an artifact object store contract from a dictionary."""
        return cls(
            contract_id=str(data["contract_id"]),
            store_id=str(data["store_id"]),
            status=cast(ArtifactObjectStoreContractStatus, data["status"]),
            records=tuple(_record_from_any(item) for item in data.get("records", ())),
            diagnostics=tuple(
                _diagnostic_from_any(item) for item in data.get("diagnostics", ())
            ),
            byte_transfer_preflight=_byte_preflight_from_optional(
                data.get("byte_transfer_preflight")
            ),
            retention_policies=tuple(
                str(policy) for policy in data.get("retention_policies", ())
            ),
            signed_reference_policy=str(
                data.get("signed_reference_policy", "metadata_reference_only")
            ),
            metadata_only=bool(data.get("metadata_only", True)),
            object_store_accessed=bool(data.get("object_store_accessed", False)),
            network_accessed=bool(data.get("network_accessed", False)),
            artifact_bytes_read=bool(data.get("artifact_bytes_read", False)),
            signed_url_exported=bool(data.get("signed_url_exported", False)),
            raw_secret_loaded=bool(data.get("raw_secret_loaded", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> ArtifactObjectStoreContractIR:
        """Build an artifact object store contract from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError(
                "ArtifactObjectStoreContractIR JSON must contain an object."
            )
        return cls.from_dict(data)


def build_artifact_object_store_contract(
    records: tuple[ArtifactStoreRecordIR, ...],
    *,
    store_id: str = "artifact_store.fixture",
    byte_transfer_preflight: ArtifactByteTransferPreflightIR | None = None,
    signed_reference_policy: str = "metadata_reference_only",
    contract_id: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> ArtifactObjectStoreContractIR:
    """Build an object store contract without touching artifact bytes."""
    normalized_records = tuple(_record_from_any(record) for record in records)
    if byte_transfer_preflight is not None and not isinstance(
        byte_transfer_preflight,
        ArtifactByteTransferPreflightIR,
    ):
        raise TypeError(
            "byte_transfer_preflight must be ArtifactByteTransferPreflightIR or None."
        )
    diagnostics = [_offline_diagnostic(store_id)]
    diagnostics.extend(_record_diagnostics(normalized_records))
    diagnostics.extend(_byte_preflight_diagnostics(byte_transfer_preflight))
    diagnostics.extend(_signed_reference_diagnostics(signed_reference_policy))
    status: ArtifactObjectStoreContractStatus = (
        "blocked"
        if any(diagnostic.severity == "error" for diagnostic in diagnostics)
        else "ready"
    )
    retention_policies = tuple(
        sorted({record.artifact.retention_policy for record in normalized_records})
    )
    return ArtifactObjectStoreContractIR(
        contract_id=contract_id or f"artifact_object_store_contract.{store_id}",
        store_id=store_id,
        status=status,
        records=normalized_records,
        diagnostics=tuple(diagnostics),
        byte_transfer_preflight=byte_transfer_preflight,
        retention_policies=retention_policies,
        signed_reference_policy=signed_reference_policy,
        metadata_only=True,
        object_store_accessed=False,
        network_accessed=False,
        artifact_bytes_read=False,
        signed_url_exported=False,
        raw_secret_loaded=False,
        metadata={
            "contract_kind": "artifact_object_store",
            "record_count": len(normalized_records),
            "metadata_only": True,
            "no_byte_read_default": True,
            "fake_store_conformance": True,
            "byte_transfer_preflight_status": None
            if byte_transfer_preflight is None
            else byte_transfer_preflight.status,
            **({} if metadata is None else metadata),
        },
    )


def _offline_diagnostic(store_id: str) -> DiagnosticsIR:
    return _diagnostic(
        diagnostic_id=f"artifact_object_store.{store_id}.metadata_only",
        severity="info",
        code="ARTIFACT_OBJECT_STORE_METADATA_ONLY",
        message=(
            "Artifact object store contract records metadata and references only; "
            "it does not read bytes, access object stores, or export signed URLs."
        ),
        metadata={
            "store_id": store_id,
            "metadata_only": True,
            "object_store_accessed": False,
            "network_accessed": False,
            "artifact_bytes_read": False,
        },
    )


def _record_diagnostics(
    records: tuple[ArtifactStoreRecordIR, ...],
) -> list[DiagnosticsIR]:
    diagnostics: list[DiagnosticsIR] = []
    if not records:
        diagnostics.append(
            _diagnostic(
                diagnostic_id="artifact_object_store.records.empty",
                severity="warning",
                code="ARTIFACT_OBJECT_STORE_RECORDS_EMPTY",
                message="No artifact metadata records were supplied.",
                object_path="records",
            )
        )
        return diagnostics
    for record in records:
        if record.status not in ("available", "expired", "missing"):
            diagnostics.append(
                _diagnostic(
                    diagnostic_id=f"artifact_object_store.{record.artifact.artifact_id}.status",
                    severity="error",
                    code="ARTIFACT_OBJECT_STORE_RECORD_STATUS_UNSUPPORTED",
                    message="Artifact store record status is unsupported.",
                    object_path="records.status",
                    metadata={"status": record.status},
                )
            )
        if record.artifact.size_bytes < 0:
            diagnostics.append(
                _diagnostic(
                    diagnostic_id=f"artifact_object_store.{record.artifact.artifact_id}.size",
                    severity="error",
                    code="ARTIFACT_OBJECT_STORE_SIZE_INVALID",
                    message="Artifact size metadata cannot be negative.",
                    object_path="records.artifact.size_bytes",
                )
            )
        if _looks_like_signed_url(record.artifact.storage_uri):
            diagnostics.append(
                _diagnostic(
                    diagnostic_id=f"artifact_object_store.{record.artifact.artifact_id}.signed_uri",
                    severity="error",
                    code="ARTIFACT_OBJECT_STORE_SIGNED_URI_NOT_REDACTED",
                    message="Artifact storage URI appears to contain signed URL data.",
                    object_path="records.artifact.storage_uri",
                )
            )
        if record.artifact.retention_policy == "":
            diagnostics.append(
                _diagnostic(
                    diagnostic_id=f"artifact_object_store.{record.artifact.artifact_id}.retention",
                    severity="error",
                    code="ARTIFACT_OBJECT_STORE_RETENTION_POLICY_MISSING",
                    message="Artifact metadata must carry a retention policy.",
                    object_path="records.artifact.retention_policy",
                )
            )
    return diagnostics


def _byte_preflight_diagnostics(
    preflight: ArtifactByteTransferPreflightIR | None,
) -> list[DiagnosticsIR]:
    if preflight is None:
        return [
            _diagnostic(
                diagnostic_id="artifact_object_store.byte_preflight.absent",
                severity="info",
                code="ARTIFACT_OBJECT_STORE_BYTE_PREFLIGHT_ABSENT",
                message=(
                    "No byte transfer preflight was supplied; byte reads remain "
                    "disabled."
                ),
                object_path="byte_transfer_preflight",
            )
        ]
    diagnostics: list[DiagnosticsIR] = []
    if (
        preflight.artifact_bytes_read
        or preflight.network_accessed
        or preflight.signed_url_exported
        or preflight.raw_secret_loaded
    ):
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"artifact_object_store.{preflight.artifact_id}.byte_preflight",
                severity="error",
                code="ARTIFACT_OBJECT_STORE_BYTE_PREFLIGHT_UNSAFE",
                message="Byte preflight violated metadata-only boundaries.",
                object_path="byte_transfer_preflight",
            )
        )
    if preflight.status == "ready" and preflight.byte_transfer_enabled:
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"artifact_object_store.{preflight.artifact_id}.byte_ready",
                severity="warning",
                code="ARTIFACT_OBJECT_STORE_BYTE_TRANSFER_READY_NOT_EXECUTED",
                message=(
                    "Byte transfer preflight is ready, but this contract still "
                    "does not read artifact bytes."
                ),
                object_path="byte_transfer_preflight.status",
            )
        )
    return diagnostics


def _signed_reference_diagnostics(policy: str) -> list[DiagnosticsIR]:
    if policy != "metadata_reference_only":
        return [
            _diagnostic(
                diagnostic_id="artifact_object_store.signed_reference.policy",
                severity="error",
                code="ARTIFACT_OBJECT_STORE_SIGNED_REFERENCE_POLICY_UNSUPPORTED",
                message=(
                    "Only metadata_reference_only signed reference policy is "
                    "supported."
                ),
                object_path="signed_reference_policy",
                metadata={"signed_reference_policy": policy},
            )
        ]
    return []


def _diagnostic(
    *,
    diagnostic_id: str,
    severity: Literal["info", "warning", "error"],
    code: str,
    message: str,
    object_path: str | None = None,
    suggestion: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> DiagnosticsIR:
    return with_diagnostic_taxonomy(
        DiagnosticsIR(
            diagnostic_id=diagnostic_id,
            stage="serialization",
            severity=severity,
            code=code,
            message=message,
            object_path=object_path,
            suggestion=suggestion,
            metadata={} if metadata is None else _redact_mapping(metadata),
        ),
        reason_category="runtime",
        action="serialize",
    )


def _record_from_any(value: Any) -> ArtifactStoreRecordIR:
    if isinstance(value, ArtifactStoreRecordIR):
        return value
    if isinstance(value, dict):
        return ArtifactStoreRecordIR.from_dict(value)
    raise TypeError("records must contain ArtifactStoreRecordIR values.")


def _byte_preflight_from_optional(
    value: Any,
) -> ArtifactByteTransferPreflightIR | None:
    if value is None:
        return None
    if isinstance(value, ArtifactByteTransferPreflightIR):
        return value
    if isinstance(value, dict):
        return ArtifactByteTransferPreflightIR.from_dict(value)
    raise TypeError(
        "byte_transfer_preflight must be ArtifactByteTransferPreflightIR, "
        "object, or null."
    )


def _diagnostic_from_any(value: Any) -> DiagnosticsIR:
    if isinstance(value, DiagnosticsIR):
        return _redact_diagnostic(value)
    if isinstance(value, dict):
        return _redact_diagnostic(DiagnosticsIR.from_dict(value))
    raise TypeError("diagnostics must contain DiagnosticsIR objects.")


def _redact_diagnostic(diagnostic: DiagnosticsIR) -> DiagnosticsIR:
    return DiagnosticsIR(
        diagnostic_id=diagnostic.diagnostic_id,
        stage=diagnostic.stage,
        severity=diagnostic.severity,
        code=diagnostic.code,
        message=diagnostic.message,
        schema_version=diagnostic.schema_version,
        object_path=diagnostic.object_path,
        suggestion=diagnostic.suggestion,
        metadata=_redact_mapping(diagnostic.metadata),
    )


def _looks_like_signed_url(value: str) -> bool:
    lowered = value.lower()
    return "signature=" in lowered or "x-amz-signature" in lowered


def _redact_mapping(data: dict[str, Any]) -> dict[str, Any]:
    redacted: dict[str, Any] = {}
    for key, value in data.items():
        lowered = str(key).lower()
        if any(token in lowered for token in _SECRET_KEY_MARKERS):
            redacted[str(key)] = value if isinstance(value, bool) else "<redacted>"
        else:
            redacted[str(key)] = _redact_value(value)
    return redacted


def _redact_value(value: Any) -> Any:
    if isinstance(value, dict):
        return _redact_mapping(value)
    if isinstance(value, list):
        return [_redact_value(item) for item in value]
    if isinstance(value, tuple):
        return tuple(_redact_value(item) for item in value)
    return value
