"""Control and channel capability IR models."""

from __future__ import annotations

import json
import math
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Literal

from cascaqit.control.types import ChannelType, validate_channel_type
from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.native_ir.base import IRMixin
from cascaqit.native_ir.models import SCHEMA_VERSION

if TYPE_CHECKING:
    from cascaqit.targets.models import (
        AnalogOperationCapability,
        ChannelCrosstalkCapability,
        ChannelTimingCapability,
        TargetSpec,
    )

__all__ = [
    "AddressingModeIR",
    "BeamIR",
    "ChannelCrosstalkConstraintIR",
    "ChannelSpecIR",
    "ChannelTimingConstraintIR",
    "ControlOperationIR",
    "ControlScheduleIR",
    "ControlSystemIR",
    "control_system_summary_for_target",
    "diagnose_control_support",
]

AddressingMode = Literal["global", "local", "patterned", "unsupported"]
CrosstalkOverlapPolicy = Literal[
    "allowed",
    "forbidden",
    "calibration_required",
]


@dataclass(frozen=True)
class AddressingModeIR(IRMixin):
    """Addressing mode capability for a control channel."""

    mode_id: str
    mode: AddressingMode
    scope: str
    supports_site_mask: bool = False
    supports_time_dependence: bool = True
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> AddressingModeIR:
        """Build addressing mode IR from a dictionary."""
        return cls(
            mode_id=str(data["mode_id"]),
            mode=data["mode"],
            scope=str(data["scope"]),
            supports_site_mask=bool(data.get("supports_site_mask", False)),
            supports_time_dependence=bool(
                data.get("supports_time_dependence", True)
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> AddressingModeIR:
        """Build addressing mode IR from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("AddressingModeIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class BeamIR(IRMixin):
    """Beam capability descriptor used by channel specs."""

    beam_id: str
    beam_role: str
    wavelength_nm: float | None = None
    waist_um: float | None = None
    power_range: tuple[float, float] | None = None
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> BeamIR:
        """Build beam IR from a dictionary."""
        power_range = data.get("power_range")
        return cls(
            beam_id=str(data["beam_id"]),
            beam_role=str(data["beam_role"]),
            wavelength_nm=None
            if data.get("wavelength_nm") is None
            else float(data["wavelength_nm"]),
            waist_um=None
            if data.get("waist_um") is None
            else float(data["waist_um"]),
            power_range=None
            if power_range is None
            else (float(power_range[0]), float(power_range[1])),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> BeamIR:
        """Build beam IR from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("BeamIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class ChannelTimingConstraintIR(IRMixin):
    """Public timing and signal constraints attached to one control channel."""

    constraint_id: str
    channel_id: str
    concurrency_group: str | None = None
    max_concurrent_operations: int | None = None
    mutually_exclusive_channel_ids: tuple[str, ...] = ()
    bandwidth_limit: float | None = None
    bandwidth_unit: str | None = None
    max_slew_rate: float | None = None
    slew_rate_unit: str | None = None
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.constraint_id or not self.channel_id:
            raise ValueError("constraint_id and channel_id must not be empty.")
        if (
            self.max_concurrent_operations is not None
            and self.max_concurrent_operations <= 0
        ):
            raise ValueError("max_concurrent_operations must be positive.")
        _validate_optional_positive_limit(
            self.bandwidth_limit,
            self.bandwidth_unit,
            value_name="bandwidth_limit",
            unit_name="bandwidth_unit",
        )
        _validate_optional_positive_limit(
            self.max_slew_rate,
            self.slew_rate_unit,
            value_name="max_slew_rate",
            unit_name="slew_rate_unit",
        )
        if len(set(self.mutually_exclusive_channel_ids)) != len(
            self.mutually_exclusive_channel_ids
        ):
            raise ValueError("mutually_exclusive_channel_ids must be unique.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ChannelTimingConstraintIR:
        """Build a timing constraint from its current JSON shape."""
        return cls(
            constraint_id=str(data["constraint_id"]),
            channel_id=str(data["channel_id"]),
            concurrency_group=data["concurrency_group"],
            max_concurrent_operations=None
            if data["max_concurrent_operations"] is None
            else int(data["max_concurrent_operations"]),
            mutually_exclusive_channel_ids=tuple(
                str(item) for item in data["mutually_exclusive_channel_ids"]
            ),
            bandwidth_limit=None
            if data["bandwidth_limit"] is None
            else float(data["bandwidth_limit"]),
            bandwidth_unit=data["bandwidth_unit"],
            max_slew_rate=None
            if data["max_slew_rate"] is None
            else float(data["max_slew_rate"]),
            slew_rate_unit=data["slew_rate_unit"],
            schema_version=str(data["schema_version"]),
            metadata=dict(data["metadata"]),
        )


@dataclass(frozen=True)
class ChannelCrosstalkConstraintIR(IRMixin):
    """Public overlap constraint for one ordered pair of control channels."""

    constraint_id: str
    left_channel_id: str
    right_channel_id: str
    overlap_policy: CrosstalkOverlapPolicy
    max_overlap_duration: float | None = None
    time_unit: str = "us"
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.constraint_id:
            raise ValueError("constraint_id must not be empty.")
        if not self.left_channel_id or not self.right_channel_id:
            raise ValueError("Crosstalk channel ids must not be empty.")
        if self.left_channel_id == self.right_channel_id:
            raise ValueError("Crosstalk constraints require two different channels.")
        if self.overlap_policy not in {
            "allowed",
            "forbidden",
            "calibration_required",
        }:
            raise ValueError(f"Unsupported overlap policy: {self.overlap_policy!r}.")
        if self.max_overlap_duration is not None:
            if self.max_overlap_duration <= 0:
                raise ValueError("max_overlap_duration must be positive.")
            if self.overlap_policy != "allowed":
                raise ValueError(
                    f"{self.overlap_policy} crosstalk cannot declare a numeric "
                    "max_overlap_duration."
                )
        if not self.time_unit:
            raise ValueError("time_unit must not be empty.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ChannelCrosstalkConstraintIR:
        """Build a crosstalk constraint from its current JSON shape."""
        return cls(
            constraint_id=str(data["constraint_id"]),
            left_channel_id=str(data["left_channel_id"]),
            right_channel_id=str(data["right_channel_id"]),
            overlap_policy=data["overlap_policy"],
            max_overlap_duration=None
            if data["max_overlap_duration"] is None
            else float(data["max_overlap_duration"]),
            time_unit=str(data["time_unit"]),
            schema_version=str(data["schema_version"]),
            metadata=dict(data["metadata"]),
        )


@dataclass(frozen=True)
class ChannelSpecIR(IRMixin):
    """Control channel capability descriptor."""

    channel_id: str
    channel_type: ChannelType
    addressing: AddressingModeIR
    supported_operations: tuple[str, ...]
    value_unit: str
    time_unit: str = "us"
    value_range: tuple[float, float] | None = None
    resolution: float | None = None
    beams: tuple[BeamIR, ...] = ()
    timing_constraint: ChannelTimingConstraintIR | None = None
    crosstalk_constraints: tuple[ChannelCrosstalkConstraintIR, ...] = ()
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.channel_id:
            raise ValueError("channel_id must not be empty.")
        object.__setattr__(
            self,
            "channel_type",
            validate_channel_type(self.channel_type),
        )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ChannelSpecIR:
        """Build channel spec IR from a dictionary."""
        value_range = data.get("value_range")
        return cls(
            channel_id=str(data["channel_id"]),
            channel_type=data["channel_type"],
            addressing=AddressingModeIR.from_dict(data["addressing"]),
            supported_operations=tuple(
                str(operation)
                for operation in data.get("supported_operations", ())
            ),
            value_unit=str(data["value_unit"]),
            time_unit=str(data.get("time_unit", "us")),
            value_range=None
            if value_range is None
            else (float(value_range[0]), float(value_range[1])),
            resolution=None
            if data.get("resolution") is None
            else float(data["resolution"]),
            beams=tuple(
                BeamIR.from_dict(beam) for beam in data.get("beams", ())
            ),
            timing_constraint=None
            if data["timing_constraint"] is None
            else ChannelTimingConstraintIR.from_dict(data["timing_constraint"]),
            crosstalk_constraints=tuple(
                ChannelCrosstalkConstraintIR.from_dict(item)
                for item in data["crosstalk_constraints"]
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> ChannelSpecIR:
        """Build channel spec IR from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("ChannelSpecIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class ControlSystemIR(IRMixin):
    """Target-level control system capability summary."""

    control_system_id: str
    target_id: str
    channels: tuple[ChannelSpecIR, ...]
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        channel_ids = [channel.channel_id for channel in self.channels]
        if len(channel_ids) != len(set(channel_ids)):
            raise ValueError("ControlSystemIR channel ids must be unique.")
        known_channels = set(channel_ids)
        constraint_ids: list[str] = []
        for channel in self.channels:
            timing = channel.timing_constraint
            if timing is not None:
                constraint_ids.append(timing.constraint_id)
                if timing.channel_id != channel.channel_id:
                    raise ValueError(
                        "Timing constraint channel_id must match its owner channel."
                    )
                if channel.channel_id in timing.mutually_exclusive_channel_ids:
                    raise ValueError(
                        "A channel cannot be mutually exclusive with itself."
                    )
                unknown = set(timing.mutually_exclusive_channel_ids) - known_channels
                if unknown:
                    raise ValueError(
                        "Timing constraint references unknown channel ids: "
                        f"{sorted(unknown)!r}."
                    )
            for crosstalk in channel.crosstalk_constraints:
                constraint_ids.append(crosstalk.constraint_id)
                if crosstalk.left_channel_id != channel.channel_id:
                    raise ValueError(
                        "Crosstalk left_channel_id must match its owner channel."
                    )
                pair = {crosstalk.left_channel_id, crosstalk.right_channel_id}
                unknown = pair - known_channels
                if unknown:
                    raise ValueError(
                        "Crosstalk constraint references unknown channel ids: "
                        f"{sorted(unknown)!r}."
                    )
        if len(constraint_ids) != len(set(constraint_ids)):
            raise ValueError("ControlSystemIR constraint ids must be unique.")

    @classmethod
    def from_target_spec(cls, target: TargetSpec) -> ControlSystemIR:
        """Build the draft control system summary from a target spec."""
        global_mode = AddressingModeIR(
            mode_id="addressing.global",
            mode="global",
            scope="all_active_sites",
            supports_site_mask=False,
            supports_time_dependence=True,
            metadata={"source": "TargetSpec"},
        )
        channels: tuple[ChannelSpecIR, ...] = (
            ChannelSpecIR(
                channel_id="rydberg.rabi.global",
                channel_type="rydberg_rabi",
                addressing=global_mode,
                supported_operations=("global_rydberg_drive",),
                value_unit=target.frequency_unit,
                time_unit=target.time_unit,
                value_range=target.rabi_range,
                resolution=target.amplitude_resolution,
                timing_constraint=_timing_constraint_for_target(
                    target, "rydberg.rabi.global"
                ),
                crosstalk_constraints=_crosstalk_constraints_for_target(
                    target, "rydberg.rabi.global"
                ),
                metadata={"target_capability": "global_rabi"},
            ),
            ChannelSpecIR(
                channel_id="rydberg.detuning.global",
                channel_type="rydberg_detuning",
                addressing=global_mode,
                supported_operations=("global_rydberg_drive",),
                value_unit=target.frequency_unit,
                time_unit=target.time_unit,
                value_range=target.detuning_range,
                resolution=target.detuning_resolution,
                timing_constraint=_timing_constraint_for_target(
                    target, "rydberg.detuning.global"
                ),
                crosstalk_constraints=_crosstalk_constraints_for_target(
                    target, "rydberg.detuning.global"
                ),
                metadata={"target_capability": "global_detuning"},
            ),
            ChannelSpecIR(
                channel_id="rydberg.phase.global",
                channel_type="rydberg_phase",
                addressing=global_mode,
                supported_operations=("global_rydberg_drive",),
                value_unit="rad",
                time_unit=target.time_unit,
                value_range=target.phase_range,
                resolution=target.phase_resolution,
                timing_constraint=_timing_constraint_for_target(
                    target, "rydberg.phase.global"
                ),
                crosstalk_constraints=_crosstalk_constraints_for_target(
                    target, "rydberg.phase.global"
                ),
                metadata={"target_capability": "global_phase"},
            ),
        )
        local_detuning = _local_detuning_channel(target)
        if local_detuning is not None:
            channels = (*channels, local_detuning)
        local_rabi = _local_rabi_channel(target)
        if local_rabi is not None:
            channels = (*channels, local_rabi)
        channels = (*channels, *_declared_non_executable_channels(target))
        return cls(
            control_system_id=f"control.{target.target_id}",
            target_id=target.target_id,
            channels=channels,
            metadata={
                "source": "TargetSpec",
                "target_name": target.target_name,
                "control_model": "phase40_draft",
            },
        )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ControlSystemIR:
        """Build control system IR from a dictionary."""
        return cls(
            control_system_id=str(data["control_system_id"]),
            target_id=str(data["target_id"]),
            channels=tuple(
                ChannelSpecIR.from_dict(channel)
                for channel in data.get("channels", ())
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> ControlSystemIR:
        """Build control system IR from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("ControlSystemIR JSON must contain an object.")
        return cls.from_dict(data)

    def channel_by_id(self) -> dict[str, ChannelSpecIR]:
        """Return channels keyed by channel id."""
        return {channel.channel_id: channel for channel in self.channels}

    def channel_summary(self) -> dict[str, Any]:
        """Return a JSON-compatible summary suitable for Target capabilities."""
        return {
            "control_system_id": self.control_system_id,
            "target_id": self.target_id,
            "channel_count": len(self.channels),
            "channels": [
                {
                    "channel_id": channel.channel_id,
                    "channel_type": channel.channel_type,
                    "addressing_mode": channel.addressing.mode,
                    "supported_operations": list(channel.supported_operations),
                    "value_unit": channel.value_unit,
                    "time_unit": channel.time_unit,
                }
                for channel in self.channels
            ],
            "schema_version": self.schema_version,
        }


@dataclass(frozen=True)
class ControlOperationIR(IRMixin):
    """One time-bounded operation assigned to a projected control channel."""

    operation_id: str
    operation_kind: str
    channel_id: str
    start_time: float
    end_time: float
    target_site_ids: tuple[str, ...]
    source_hash: str
    waveform_hash: str | None = None
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.operation_id or not self.operation_kind or not self.channel_id:
            raise ValueError("Operation id, kind, and channel id must not be empty.")
        if not math.isfinite(self.start_time) or not math.isfinite(self.end_time):
            raise ValueError("Control operation times must be finite.")
        if self.end_time <= self.start_time:
            raise ValueError("end_time must be greater than start_time.")
        _validate_sha256(self.source_hash, "source_hash")
        if self.waveform_hash is not None:
            _validate_sha256(self.waveform_hash, "waveform_hash")
        if len(set(self.target_site_ids)) != len(self.target_site_ids):
            raise ValueError("target_site_ids must be unique.")

    @property
    def duration(self) -> float:
        """Return the operation duration in the channel's time unit."""
        return self.end_time - self.start_time

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ControlOperationIR:
        """Build a control operation from its current JSON shape."""
        return cls(
            operation_id=str(data["operation_id"]),
            operation_kind=str(data["operation_kind"]),
            channel_id=str(data["channel_id"]),
            start_time=float(data["start_time"]),
            end_time=float(data["end_time"]),
            target_site_ids=tuple(str(item) for item in data["target_site_ids"]),
            source_hash=str(data["source_hash"]),
            waveform_hash=data["waveform_hash"],
            schema_version=str(data["schema_version"]),
            metadata=dict(data["metadata"]),
        )


@dataclass(frozen=True)
class ControlScheduleIR(IRMixin):
    """Deterministically ordered control operations with source provenance."""

    schedule_id: str
    program_hash: str
    control_system_hash: str
    operations: tuple[ControlOperationIR, ...]
    diagnostics: tuple[DiagnosticsIR, ...] = ()
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.schedule_id:
            raise ValueError("schedule_id must not be empty.")
        _validate_sha256(self.program_hash, "program_hash")
        _validate_sha256(self.control_system_hash, "control_system_hash")
        operation_ids = [operation.operation_id for operation in self.operations]
        if len(operation_ids) != len(set(operation_ids)):
            raise ValueError("ControlScheduleIR operation ids must be unique.")
        order = [
            (operation.start_time, operation.end_time, operation.operation_id)
            for operation in self.operations
        ]
        if order != sorted(order):
            raise ValueError("Control operations must use deterministic order.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ControlScheduleIR:
        """Build a control schedule from its current JSON shape."""
        return cls(
            schedule_id=str(data["schedule_id"]),
            program_hash=str(data["program_hash"]),
            control_system_hash=str(data["control_system_hash"]),
            operations=tuple(
                ControlOperationIR.from_dict(item) for item in data["operations"]
            ),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(item) for item in data["diagnostics"]
            ),
            schema_version=str(data["schema_version"]),
            metadata=dict(data["metadata"]),
        )

    @classmethod
    def from_json(cls, text: str) -> ControlScheduleIR:
        """Build a control schedule from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("ControlScheduleIR JSON must contain an object.")
        return cls.from_dict(data)


def control_system_summary_for_target(target: TargetSpec) -> dict[str, Any]:
    """Return a control channel summary for a target capability map."""
    return ControlSystemIR.from_target_spec(target).channel_summary()


def _local_detuning_channel(target: TargetSpec) -> ChannelSpecIR | None:
    typed = target.typed_capabilities
    if typed is None:
        return None
    capability = next(
        (
            item
            for item in typed.analog_operations
            if item.operation == "local_detuning"
        ),
        None,
    )
    if (
        capability is None
        or capability.status not in {"supported", "experimental"}
    ):
        return None
    addressing = _local_addressing_mode(
        capability,
        target_operation="local_detuning",
    )
    if addressing is None:
        return None
    return ChannelSpecIR(
        channel_id="rydberg.detuning.local",
        channel_type="rydberg_detuning",
        addressing=addressing,
        supported_operations=("local_detuning",),
        value_unit=target.frequency_unit,
        time_unit=target.time_unit,
        value_range=target.detuning_range,
        resolution=target.detuning_resolution,
        timing_constraint=_timing_constraint_for_target(
            target, "rydberg.detuning.local"
        ),
        crosstalk_constraints=_crosstalk_constraints_for_target(
            target, "rydberg.detuning.local"
        ),
        metadata={
            "target_capability": "local_detuning",
            "capability_status": capability.status,
            "execution_scope": "local_simulator_only",
            "hardware_submit": "unsupported",
            "cloud_submit": "unsupported",
        },
    )


def _local_rabi_channel(target: TargetSpec) -> ChannelSpecIR | None:
    """Project experimental site-addressed Rabi capability into control IR."""
    typed = target.typed_capabilities
    if typed is None:
        return None
    capability = next(
        (
            item
            for item in typed.analog_operations
            if item.operation == "local_rabi"
        ),
        None,
    )
    if (
        capability is None
        or capability.status not in {"supported", "experimental"}
    ):
        return None
    addressing = _local_addressing_mode(
        capability,
        target_operation="local_rabi",
    )
    if addressing is None:
        return None
    return ChannelSpecIR(
        channel_id="rydberg.rabi.local",
        channel_type="rydberg_rabi",
        addressing=addressing,
        supported_operations=("local_rabi",),
        # The shared phase rotates this complex drive; it is not a second
        # independently addressed site mask or a claimed hardware channel.
        value_unit=target.frequency_unit,
        time_unit=target.time_unit,
        value_range=target.rabi_range,
        resolution=target.amplitude_resolution,
        timing_constraint=_timing_constraint_for_target(target, "rydberg.rabi.local"),
        crosstalk_constraints=_crosstalk_constraints_for_target(
            target, "rydberg.rabi.local"
        ),
        metadata={
            "target_capability": "local_rabi",
            "capability_status": capability.status,
            "phase_unit": "rad",
            "execution_scope": "local_simulator_only",
            "hardware_submit": "unsupported",
            "cloud_submit": "unsupported",
        },
    )


def _local_addressing_mode(
    capability: AnalogOperationCapability,
    *,
    target_operation: str,
) -> AddressingModeIR | None:
    """Project detailed Target modes into the shared patterned channel mode."""
    supported = set(capability.addressing)
    canonical = {
        "site_pattern_static",
        "site_mask_static",
        "site_mask_piecewise",
    }
    if not supported.intersection(canonical):
        return None
    supports_site_mask = bool(
        supported.intersection({"site_mask_static", "site_mask_piecewise"})
    )
    supports_time_dependence = "site_mask_piecewise" in supported
    return AddressingModeIR(
        mode_id="addressing.site_frames",
        mode="patterned",
        scope=(
            "active_sites_by_time_dependent_frames"
            if supports_time_dependence
            else "active_sites_by_static_addressing"
        ),
        supports_site_mask=supports_site_mask,
        supports_time_dependence=supports_time_dependence,
        metadata={
            "source": "TargetSpec.typed_capabilities",
            "target_operation": target_operation,
            "supported_addressing": list(capability.addressing),
            "mask_interpolation": capability.metadata.get("mask_interpolation"),
        },
    )


def _declared_non_executable_channels(
    target: TargetSpec,
) -> tuple[ChannelSpecIR, ...]:
    """Project typed vocabulary without implying a scheduler or runtime consumer."""
    typed = target.typed_capabilities
    if typed is None:
        return ()
    channels: list[ChannelSpecIR] = []
    for capability in typed.analog_operations:
        if capability.channel_type is None or capability.status not in {
            "unsupported",
            "ir_only",
        }:
            continue
        channel_type = validate_channel_type(capability.channel_type)
        addressing = _declared_addressing_mode(capability)
        channels.append(
            ChannelSpecIR(
                channel_id=f"{channel_type}.{capability.operation}",
                channel_type=channel_type,
                addressing=addressing,
                supported_operations=(
                    (capability.operation,)
                    if capability.status == "ir_only"
                    else ()
                ),
                # Physical ranges are intentionally absent until a Target provides
                # calibration-backed semantics and an executable consumer.
                value_unit=target.frequency_unit,
                time_unit=target.time_unit,
                value_range=None,
                resolution=None,
                metadata={
                    **capability.metadata,
                    "target_capability": capability.operation,
                    "declared_operation": capability.operation,
                    "capability_status": capability.status,
                    "runtime_consumer": False,
                    "scheduler_support": False,
                },
            )
        )
    return tuple(channels)


def _declared_addressing_mode(
    capability: AnalogOperationCapability,
) -> AddressingModeIR:
    addressing = set(capability.addressing)
    if addressing.intersection(
        {
            "patterned",
            "site_pattern_static",
            "site_mask_static",
            "site_mask_piecewise",
        }
    ):
        mode: AddressingMode = "patterned"
        scope = "declared_site_pattern_or_mask"
    elif "local" in addressing:
        mode = "local"
        scope = "declared_local_addressing"
    elif "global" in addressing:
        mode = "global"
        scope = "declared_global_addressing"
    else:
        mode = "unsupported"
        scope = "addressing_not_available"
    return AddressingModeIR(
        mode_id=f"addressing.{capability.operation}",
        mode=mode,
        scope=scope,
        supports_site_mask=bool(
            addressing.intersection(
                {"site_mask_static", "site_mask_piecewise"}
            )
        ),
        supports_time_dependence="site_mask_piecewise" in addressing,
        metadata={
            "declared_only": True,
            "supported_addressing": list(capability.addressing),
        },
    )


def _timing_constraint_for_target(
    target: TargetSpec,
    channel_id: str,
) -> ChannelTimingConstraintIR | None:
    """Project an explicitly declared Target timing fact without defaults."""
    typed = target.typed_capabilities
    if typed is None:
        return None
    capability = next(
        (item for item in typed.control_timing if item.channel_id == channel_id),
        None,
    )
    if capability is None:
        return None
    return _timing_constraint_from_capability(capability)


def _timing_constraint_from_capability(
    capability: ChannelTimingCapability,
) -> ChannelTimingConstraintIR:
    return ChannelTimingConstraintIR(
        constraint_id=f"timing.{capability.channel_id}",
        channel_id=capability.channel_id,
        concurrency_group=capability.concurrency_group,
        max_concurrent_operations=capability.max_concurrent_operations,
        mutually_exclusive_channel_ids=(
            capability.mutually_exclusive_channel_ids
        ),
        bandwidth_limit=capability.bandwidth_limit,
        bandwidth_unit=capability.bandwidth_unit,
        max_slew_rate=capability.max_slew_rate,
        slew_rate_unit=capability.slew_rate_unit,
        metadata={**capability.metadata, "source": "TargetSpec.typed_capabilities"},
    )


def _crosstalk_constraints_for_target(
    target: TargetSpec,
    channel_id: str,
) -> tuple[ChannelCrosstalkConstraintIR, ...]:
    """Project only pair facts owned by the requested left-hand channel."""
    typed = target.typed_capabilities
    if typed is None:
        return ()
    return tuple(
        _crosstalk_constraint_from_capability(capability)
        for capability in typed.control_crosstalk
        if capability.left_channel_id == channel_id
    )


def _crosstalk_constraint_from_capability(
    capability: ChannelCrosstalkCapability,
) -> ChannelCrosstalkConstraintIR:
    return ChannelCrosstalkConstraintIR(
        constraint_id=(
            f"crosstalk.{capability.left_channel_id}.{capability.right_channel_id}"
        ),
        left_channel_id=capability.left_channel_id,
        right_channel_id=capability.right_channel_id,
        overlap_policy=capability.overlap_policy,
        max_overlap_duration=capability.max_overlap_duration,
        time_unit=capability.time_unit,
        metadata={**capability.metadata, "source": "TargetSpec.typed_capabilities"},
    )


def _validate_optional_positive_limit(
    value: float | None,
    unit: str | None,
    *,
    value_name: str,
    unit_name: str,
) -> None:
    if (value is None) != (unit is None):
        raise ValueError(f"{value_name} and {unit_name} must be provided together.")
    if value is not None and value <= 0:
        raise ValueError(f"{value_name} must be positive.")
    if unit is not None and not unit:
        raise ValueError(f"{unit_name} must not be empty.")


def _validate_sha256(value: str, field_name: str) -> None:
    is_hex = all(character in "0123456789abcdef" for character in value)
    if len(value) != 64 or not is_hex:
        raise ValueError(f"{field_name} must be a 64-character SHA-256 digest.")


def diagnose_control_support(
    control_system: ControlSystemIR,
    *,
    required_channel_type: str | None = None,
    required_addressing: str | None = None,
    required_operation: str | None = None,
) -> tuple[DiagnosticsIR, ...]:
    """Return diagnostics for channel/addressing/operation requirements."""
    diagnostics: list[DiagnosticsIR] = []
    candidate_channels = list(control_system.channels)
    if required_channel_type is not None:
        candidate_channels = [
            channel
            for channel in candidate_channels
            if channel.channel_type == required_channel_type
        ]
        if not candidate_channels:
            diagnostics.append(
                _diagnostic(
                    code="CONTROL_CHANNEL_UNSUPPORTED",
                    message="Required control channel type is not supported.",
                    object_path="control_system.channels",
                    metadata={"required_channel_type": required_channel_type},
                )
            )
            return tuple(diagnostics)
        runnable_channels = [
            channel
            for channel in candidate_channels
            if channel.metadata.get("capability_status")
            not in {"unsupported", "ir_only"}
        ]
        if not runnable_channels:
            ir_only = any(
                channel.metadata.get("capability_status") == "ir_only"
                for channel in candidate_channels
            )
            diagnostics.append(
                _diagnostic(
                    code=(
                        "CONTROL_CHANNEL_IR_ONLY"
                        if ir_only
                        else "CONTROL_CHANNEL_UNSUPPORTED"
                    ),
                    message=(
                        "Required control channel is available as IR only; no "
                        "runtime consumer is implemented."
                        if ir_only
                        else "Required control channel type is not supported."
                    ),
                    object_path="control_system.channels",
                    metadata={
                        "required_channel_type": required_channel_type,
                        "declared_channel_ids": [
                            channel.channel_id for channel in candidate_channels
                        ],
                        "runtime_consumer": False,
                    },
                )
            )
            return tuple(diagnostics)
        candidate_channels = runnable_channels
    if required_addressing is not None:
        addressing_matches = [
            channel
            for channel in candidate_channels
            if channel.addressing.mode == required_addressing
        ]
        if not addressing_matches:
            diagnostics.append(
                _diagnostic(
                    code="CONTROL_ADDRESSING_UNSUPPORTED",
                    message="Required addressing mode is not supported.",
                    object_path="control_system.channels.addressing",
                    metadata={"required_addressing": required_addressing},
                )
            )
            return tuple(diagnostics)
        candidate_channels = addressing_matches
    if required_operation is not None:
        operation_matches = [
            channel
            for channel in candidate_channels
            if required_operation in channel.supported_operations
        ]
        if not operation_matches:
            diagnostics.append(
                _diagnostic(
                    code="CONTROL_OPERATION_UNSUPPORTED",
                    message="Required operation is not supported.",
                    object_path="control_system.channels.supported_operations",
                    metadata={"required_operation": required_operation},
                )
            )
            return tuple(diagnostics)
        candidate_channels = operation_matches
    diagnostics.append(
        DiagnosticsIR(
            diagnostic_id="control.supported",
            stage="validation",
            severity="info",
            code="CONTROL_REQUIREMENT_SUPPORTED",
            message="Control requirement is supported by at least one channel.",
            object_path="control_system.channels",
            metadata={
                "matching_channel_ids": [
                    channel.channel_id for channel in candidate_channels
                ]
            },
        )
    )
    return tuple(diagnostics)


def _diagnostic(
    *,
    code: str,
    message: str,
    object_path: str,
    metadata: dict[str, Any],
) -> DiagnosticsIR:
    return DiagnosticsIR(
        diagnostic_id=f"control.{code.lower()}",
        stage="validation",
        severity="warning",
        code=code,
        message=message,
        object_path=object_path,
        suggestion=(
            "Select a target/control system with the required channel "
            "capability, or lower the program to supported controls."
        ),
        metadata=metadata,
    )
