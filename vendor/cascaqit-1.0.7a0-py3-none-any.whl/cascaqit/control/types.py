"""Shared control-channel vocabulary."""

from __future__ import annotations

from typing import Literal, cast

ChannelType = Literal[
    "rydberg_rabi",
    "rydberg_detuning",
    "rydberg_phase",
    "raman",
    "microwave",
    "dmm",
    "tweezer",
    "readout",
    "other",
]

CHANNEL_TYPES = frozenset(
    {
        "rydberg_rabi",
        "rydberg_detuning",
        "rydberg_phase",
        "raman",
        "microwave",
        "dmm",
        "tweezer",
        "readout",
        "other",
    }
)


def validate_channel_type(value: object) -> ChannelType:
    """Return a known channel type without collapsing unknown values to other."""
    if not isinstance(value, str) or value not in CHANNEL_TYPES:
        raise ValueError(f"Unsupported control channel type: {value!r}.")
    return cast(ChannelType, value)
