"""Program-derived control schedules and public Target constraint checks."""

from __future__ import annotations

import math
from typing import Any, Literal

import numpy as np
from scipy.interpolate import PchipInterpolator  # type: ignore[import-untyped]

from cascaqit.control.models import (
    ChannelCrosstalkConstraintIR,
    ChannelTimingConstraintIR,
    ControlOperationIR,
    ControlScheduleIR,
    ControlSystemIR,
)
from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.native_ir.base import IRMixin
from cascaqit.native_ir.models import ProgramIR, SiteAddressingIR, WaveformIR

__all__ = ["build_control_schedule", "validate_control_schedule"]

Severity = Literal["info", "warning", "error"]


def build_control_schedule(
    program: ProgramIR,
    control_system: ControlSystemIR,
) -> ControlScheduleIR:
    """Project one Analog ProgramIR into deterministic canonical channels.

    This projection records the simultaneous Hamiltonian terms already present
    in ProgramIR. It does not allocate physical channels or claim a production
    schedule.
    """
    operations: list[ControlOperationIR] = []
    diagnostics: list[DiagnosticsIR] = []
    active_site_ids = program.register.active_site_ids

    _append_operation(
        operations,
        diagnostics,
        operation_id="operation.global_rabi",
        operation_kind="global_rabi",
        channel_id="rydberg.rabi.global",
        waveform=program.hamiltonian.rabi,
        source=program.hamiltonian.rabi,
        target_site_ids=active_site_ids,
        program_path="hamiltonian.terms.rabi",
    )
    _append_operation(
        operations,
        diagnostics,
        operation_id="operation.global_detuning",
        operation_kind="global_detuning",
        channel_id="rydberg.detuning.global",
        waveform=program.hamiltonian.detuning,
        source=program.hamiltonian.detuning,
        target_site_ids=active_site_ids,
        program_path="hamiltonian.terms.detuning",
    )
    if isinstance(program.hamiltonian.phase, WaveformIR):
        _append_operation(
            operations,
            diagnostics,
            operation_id="operation.global_phase",
            operation_kind="global_phase",
            channel_id="rydberg.phase.global",
            waveform=program.hamiltonian.phase,
            source=program.hamiltonian.phase,
            target_site_ids=active_site_ids,
            program_path="hamiltonian.terms.phase",
        )

    for index, detuning_term in enumerate(
        program.hamiltonian.local_detuning_terms
    ):
        _append_operation(
            operations,
            diagnostics,
            operation_id=f"operation.local_detuning.{index}",
            operation_kind="local_detuning",
            channel_id="rydberg.detuning.local",
            waveform=detuning_term.waveform,
            source=detuning_term,
            target_site_ids=_addressed_site_ids(detuning_term.addressing),
            program_path=f"hamiltonian.terms.local_detuning_terms[{index}].waveform",
        )
    for index, rabi_term in enumerate(program.hamiltonian.local_rabi_terms):
        _append_operation(
            operations,
            diagnostics,
            operation_id=f"operation.local_rabi.{index}",
            operation_kind="local_rabi",
            channel_id="rydberg.rabi.local",
            waveform=rabi_term.rabi,
            source=rabi_term,
            target_site_ids=_addressed_site_ids(rabi_term.addressing),
            program_path=f"hamiltonian.terms.local_rabi_terms[{index}].rabi",
        )

    ordered = tuple(
        sorted(
            operations,
            key=lambda item: (item.start_time, item.end_time, item.operation_id),
        )
    )
    return ControlScheduleIR(
        schedule_id=f"schedule.{program.program_id}.control",
        program_hash=program.stable_hash(),
        control_system_hash=control_system.stable_hash(),
        operations=ordered,
        diagnostics=tuple(diagnostics),
        metadata={
            "projection": "program_ir_control_terms",
            "production_channel_allocation_performed": False,
            "time_origin": 0.0,
            "time_unit": program.unit_conventions.time,
        },
    )


def validate_control_schedule(
    schedule: ControlScheduleIR,
    control_system: ControlSystemIR,
    program: ProgramIR,
) -> tuple[DiagnosticsIR, ...]:
    """Validate an actual projected schedule against declared public facts."""
    diagnostics: list[DiagnosticsIR] = []
    channels = control_system.channel_by_id()
    operations_by_channel = _operations_by_channel(schedule)

    if schedule.program_hash != program.stable_hash():
        diagnostics.append(
            _diagnostic(
                code="CONTROL_SCHEDULE_PROGRAM_HASH_MISMATCH",
                severity="error",
                message="Control schedule does not belong to this ProgramIR.",
                object_path="control_schedule.program_hash",
                suffix=schedule.schedule_id,
                suggestion="Rebuild the schedule from the current program snapshot.",
                metadata={
                    "schedule_program_hash": schedule.program_hash,
                    "actual_program_hash": program.stable_hash(),
                },
            )
        )
    if schedule.control_system_hash != control_system.stable_hash():
        diagnostics.append(
            _diagnostic(
                code="CONTROL_SCHEDULE_SYSTEM_HASH_MISMATCH",
                severity="error",
                message="Control schedule does not belong to this control system.",
                object_path="control_schedule.control_system_hash",
                suffix=schedule.schedule_id,
                suggestion="Rebuild the schedule from the current Target facts.",
                metadata={
                    "schedule_control_system_hash": schedule.control_system_hash,
                    "actual_control_system_hash": control_system.stable_hash(),
                },
            )
        )

    diagnostics.extend(
        _undeclared_constraint_diagnostics(operations_by_channel, control_system)
    )
    diagnostics.extend(_concurrency_diagnostics(schedule, control_system))
    diagnostics.extend(_mutual_exclusion_diagnostics(schedule, control_system))

    for operation in schedule.operations:
        channel = channels.get(operation.channel_id)
        if channel is None:
            diagnostics.append(
                _diagnostic(
                    code="CONTROL_CHANNEL_UNDECLARED",
                    severity="warning",
                    message="Program control has no matching channel in this Target.",
                    object_path=_operation_path(operation),
                    suffix=operation.operation_id,
                    suggestion="Use a Target that declares this control channel.",
                    metadata={
                        "operation_id": operation.operation_id,
                        "channel_id": operation.channel_id,
                    },
                )
            )
            continue
        timing = channel.timing_constraint
        if timing is None:
            continue
        waveform = _waveform_for_operation(program, operation)
        if timing.bandwidth_limit is not None:
            diagnostics.append(
                _bandwidth_diagnostic(operation, waveform, timing)
            )
        if timing.max_slew_rate is not None:
            diagnostics.append(_slew_diagnostic(operation, waveform, timing))

    diagnostics.extend(_crosstalk_diagnostics(schedule, control_system))
    return tuple(diagnostics)


def _append_operation(
    operations: list[ControlOperationIR],
    diagnostics: list[DiagnosticsIR],
    *,
    operation_id: str,
    operation_kind: str,
    channel_id: str,
    waveform: WaveformIR,
    source: IRMixin,
    target_site_ids: tuple[str, ...],
    program_path: str,
) -> None:
    duration = waveform.duration
    if (
        isinstance(duration, bool)
        or not isinstance(duration, (int, float))
        or not math.isfinite(float(duration))
        or float(duration) <= 0.0
    ):
        diagnostics.append(
            _diagnostic(
                code="CONTROL_SCHEDULE_OPERATION_INVALID",
                severity="error",
                message="Control operation duration must be finite and positive.",
                object_path=f"{program_path}.duration",
                suffix=operation_id,
                suggestion="Fix the waveform duration before schedule validation.",
                metadata={
                    "operation_id": operation_id,
                    "channel_id": channel_id,
                    "duration": duration,
                },
            )
        )
        return
    operations.append(
        ControlOperationIR(
            operation_id=operation_id,
            operation_kind=operation_kind,
            channel_id=channel_id,
            start_time=0.0,
            end_time=float(duration),
            target_site_ids=target_site_ids,
            source_hash=source.stable_hash(),
            waveform_hash=waveform.stable_hash(),
            metadata={
                "program_path": program_path,
                "waveform_kind": waveform.kind,
                "value_unit": waveform.value_unit,
                "time_unit": waveform.time_unit,
                "production_assigned": False,
            },
        )
    )


def _addressed_site_ids(addressing: SiteAddressingIR) -> tuple[str, ...]:
    return tuple(
        site_id
        for site_index, site_id in enumerate(addressing.site_ids)
        if any(frame[site_index] > 0.0 for frame in addressing.weights)
    )


def _operations_by_channel(
    schedule: ControlScheduleIR,
) -> dict[str, tuple[ControlOperationIR, ...]]:
    channel_ids = sorted({operation.channel_id for operation in schedule.operations})
    return {
        channel_id: tuple(
            operation
            for operation in schedule.operations
            if operation.channel_id == channel_id
        )
        for channel_id in channel_ids
    }


def _undeclared_constraint_diagnostics(
    operations_by_channel: dict[str, tuple[ControlOperationIR, ...]],
    control_system: ControlSystemIR,
) -> list[DiagnosticsIR]:
    """Keep missing local experiment facts visible without noisy global defaults."""
    channels = control_system.channel_by_id()
    constrained_pairs = {
        channel_id
        for channel in control_system.channels
        for constraint in channel.crosstalk_constraints
        for channel_id in (
            constraint.left_channel_id,
            constraint.right_channel_id,
        )
    }
    diagnostics: list[DiagnosticsIR] = []
    for channel_id, operations in operations_by_channel.items():
        if not channel_id.endswith(".local"):
            continue
        channel = channels.get(channel_id)
        if channel is None:
            continue
        timing = channel.timing_constraint
        has_timing_fact = timing is not None and any(
            (
                timing.concurrency_group is not None,
                timing.max_concurrent_operations is not None,
                bool(timing.mutually_exclusive_channel_ids),
                timing.bandwidth_limit is not None,
                timing.max_slew_rate is not None,
            )
        )
        if has_timing_fact or channel_id in constrained_pairs:
            continue
        diagnostics.append(
            _diagnostic(
                code="CONTROL_CONSTRAINT_UNDECLARED",
                severity="warning",
                message="Target does not declare constraints for this local channel.",
                object_path=_operation_path(operations[0]),
                suffix=channel_id,
                suggestion=(
                    "Treat the channel as unchecked until Target timing or "
                    "crosstalk facts are available."
                ),
                metadata={
                    "channel_id": channel_id,
                    "operation_ids": [item.operation_id for item in operations],
                    "constraint_status": "unavailable",
                },
            )
        )
    return diagnostics


def _concurrency_diagnostics(
    schedule: ControlScheduleIR,
    control_system: ControlSystemIR,
) -> list[DiagnosticsIR]:
    groups: dict[str, list[tuple[ControlOperationIR, int]]] = {}
    for channel in control_system.channels:
        timing = channel.timing_constraint
        if (
            timing is None
            or timing.concurrency_group is None
            or timing.max_concurrent_operations is None
        ):
            continue
        for operation in schedule.operations:
            if operation.channel_id == channel.channel_id:
                groups.setdefault(timing.concurrency_group, []).append(
                    (operation, timing.max_concurrent_operations)
                )

    diagnostics: list[DiagnosticsIR] = []
    for group_id, group_operations in sorted(groups.items()):
        limits = {limit for _, limit in group_operations}
        if len(limits) != 1:
            diagnostics.append(
                _diagnostic(
                    code="CONTROL_CONCURRENCY_FACT_CONFLICT",
                    severity="error",
                    message="Target publishes conflicting limits for one group.",
                    object_path="control_system.channels.timing_constraint",
                    suffix=group_id,
                    suggestion="Publish one max-concurrency value for the group.",
                    metadata={"group_id": group_id, "limits": sorted(limits)},
                )
            )
            continue
        limit = next(iter(limits))
        maximum = _maximum_concurrency(
            tuple(operation for operation, _ in group_operations)
        )
        exceeded = maximum > limit
        diagnostics.append(
            _diagnostic(
                code=(
                    "CONTROL_CONCURRENCY_EXCEEDED"
                    if exceeded
                    else "CONTROL_CONCURRENCY_SUPPORTED"
                ),
                severity="error" if exceeded else "info",
                message=(
                    "Control concurrency exceeds the declared group limit."
                    if exceeded
                    else "Control concurrency is within the declared group limit."
                ),
                object_path="control_schedule.operations",
                suffix=group_id,
                suggestion=(
                    "Reduce overlapping local control terms."
                    if exceeded
                    else None
                ),
                metadata={
                    "group_id": group_id,
                    "actual_max_concurrency": maximum,
                    "max_concurrent_operations": limit,
                    "operation_ids": [
                        operation.operation_id for operation, _ in group_operations
                    ],
                },
            )
        )
    return diagnostics


def _maximum_concurrency(operations: tuple[ControlOperationIR, ...]) -> int:
    events = sorted(
        (
            (time, delta)
            for operation in operations
            for time, delta in (
                (operation.start_time, 1),
                (operation.end_time, -1),
            )
        ),
        # Half-open intervals make an end event precede a start at the same time.
        key=lambda item: (item[0], item[1]),
    )
    current = 0
    maximum = 0
    for _, delta in events:
        current += delta
        maximum = max(maximum, current)
    return maximum


def _mutual_exclusion_diagnostics(
    schedule: ControlScheduleIR,
    control_system: ControlSystemIR,
) -> list[DiagnosticsIR]:
    operations = _operations_by_channel(schedule)
    checked_pairs: set[tuple[str, str]] = set()
    diagnostics: list[DiagnosticsIR] = []
    for channel in control_system.channels:
        timing = channel.timing_constraint
        if timing is None:
            continue
        for other_channel_id in timing.mutually_exclusive_channel_ids:
            pair = _ordered_pair(channel.channel_id, other_channel_id)
            if pair in checked_pairs:
                continue
            checked_pairs.add(pair)
            overlap = _maximum_pair_overlap(
                operations.get(pair[0], ()),
                operations.get(pair[1], ()),
            )
            violated = overlap > 0.0
            diagnostics.append(
                _diagnostic(
                    code=(
                        "CONTROL_MUTUAL_EXCLUSION_VIOLATED"
                        if violated
                        else "CONTROL_MUTUAL_EXCLUSION_SUPPORTED"
                    ),
                    severity="error" if violated else "info",
                    message=(
                        "Mutually exclusive channels overlap in the schedule."
                        if violated
                        else "Mutually exclusive channels do not overlap."
                    ),
                    object_path="control_schedule.operations",
                    suffix=".".join(pair),
                    suggestion=(
                        "Remove one overlapping control term or use another Target."
                        if violated
                        else None
                    ),
                    metadata={
                        "channel_ids": list(pair),
                        "actual_overlap_duration": overlap,
                        "time_unit": "us",
                    },
                )
            )
    return diagnostics


def _bandwidth_diagnostic(
    operation: ControlOperationIR,
    waveform: WaveformIR | None,
    timing: ChannelTimingConstraintIR,
) -> DiagnosticsIR:
    estimate = None if waveform is None else _bandwidth_estimate_mhz(waveform)
    if estimate is None or timing.bandwidth_unit != "MHz":
        return _analysis_unavailable_diagnostic(
            operation,
            kind="bandwidth",
            limit=timing.bandwidth_limit,
            unit=timing.bandwidth_unit,
        )
    assert timing.bandwidth_limit is not None
    exceeded = estimate > timing.bandwidth_limit + 1e-12
    return _diagnostic(
        code=(
            "CONTROL_BANDWIDTH_EXCEEDED"
            if exceeded
            else "CONTROL_BANDWIDTH_SUPPORTED"
        ),
        severity="error" if exceeded else "info",
        message=(
            "Waveform knot-spacing bandwidth bound exceeds the Target limit."
            if exceeded
            else "Waveform knot-spacing bandwidth bound is within the Target limit."
        ),
        object_path=_operation_path(operation),
        suffix=operation.operation_id,
        suggestion=(
            "Increase knot spacing or use a Target with a higher bandwidth limit."
            if exceeded
            else None
        ),
        metadata={
            "operation_id": operation.operation_id,
            "channel_id": operation.channel_id,
            "estimated_bandwidth": estimate,
            "bandwidth_limit": timing.bandwidth_limit,
            "bandwidth_unit": timing.bandwidth_unit,
            "estimate_semantics": "nyquist_bound_from_minimum_knot_spacing",
        },
    )


def _slew_diagnostic(
    operation: ControlOperationIR,
    waveform: WaveformIR | None,
    timing: ChannelTimingConstraintIR,
) -> DiagnosticsIR:
    estimate = None if waveform is None else _maximum_slew(waveform)
    expected_unit = None if waveform is None else _slew_unit(waveform)
    if estimate is None or timing.slew_rate_unit != expected_unit:
        return _analysis_unavailable_diagnostic(
            operation,
            kind="slew",
            limit=timing.max_slew_rate,
            unit=timing.slew_rate_unit,
            actual_unit=expected_unit,
        )
    assert timing.max_slew_rate is not None
    exceeded = estimate > timing.max_slew_rate + 1e-12
    return _diagnostic(
        code="CONTROL_SLEW_EXCEEDED" if exceeded else "CONTROL_SLEW_SUPPORTED",
        severity="error" if exceeded else "info",
        message=(
            "Waveform segment slew exceeds the Target limit."
            if exceeded
            else "Waveform segment slew is within the Target limit."
        ),
        object_path=_operation_path(operation),
        suffix=operation.operation_id,
        suggestion=(
            "Reduce adjacent value changes or increase their time separation."
            if exceeded
            else None
        ),
        metadata={
            "operation_id": operation.operation_id,
            "channel_id": operation.channel_id,
            "actual_max_slew_rate": estimate,
            "max_slew_rate": timing.max_slew_rate,
            "slew_rate_unit": timing.slew_rate_unit,
            "estimate_semantics": "maximum_actual_waveform_segment_derivative",
        },
    )


def _analysis_unavailable_diagnostic(
    operation: ControlOperationIR,
    *,
    kind: str,
    limit: float | None,
    unit: str | None,
    actual_unit: str | None = None,
) -> DiagnosticsIR:
    return _diagnostic(
        code=f"CONTROL_{kind.upper()}_ANALYSIS_UNAVAILABLE",
        severity="warning",
        message=f"{kind.capitalize()} cannot be checked from this waveform or unit.",
        object_path=_operation_path(operation),
        suffix=operation.operation_id,
        suggestion="Bind and validate the waveform using Target-compatible units.",
        metadata={
            "operation_id": operation.operation_id,
            "channel_id": operation.channel_id,
            "declared_limit": limit,
            "declared_unit": unit,
            "waveform_derived_unit": actual_unit,
            "constraint_status": "unavailable",
        },
    )


def _bandwidth_estimate_mhz(waveform: WaveformIR) -> float | None:
    if waveform.kind == "constant":
        return 0.0 if _finite_values(waveform.values) else None
    times = _valid_times(waveform)
    if times is None or len(times) < 2 or waveform.time_unit != "us":
        return None
    minimum_spacing = min(right - left for left, right in zip(times, times[1:]))
    return 0.5 / minimum_spacing


def _maximum_slew(waveform: WaveformIR) -> float | None:
    values = _finite_values(waveform.values)
    if values is None:
        return None
    if waveform.kind == "constant":
        return 0.0 if len(values) == 1 else None
    times = _valid_times(waveform)
    if times is None or len(times) != len(values) or len(times) < 2:
        return None
    if waveform.kind == "piecewise_constant":
        return (
            0.0
            if all(
                abs(right - left) <= 1e-12
                for left, right in zip(values, values[1:])
            )
            else math.inf
        )
    if waveform.kind in {"linear", "piecewise_linear"}:
        return max(
            abs((right_value - left_value) / (right_time - left_time))
            for left_time, right_time, left_value, right_value in zip(
                times,
                times[1:],
                values,
                values[1:],
            )
        )
    if waveform.kind == "interpolated":
        return _maximum_pchip_slew(times, values)
    return None


def _maximum_pchip_slew(
    times: tuple[float, ...],
    values: tuple[float, ...],
) -> float | None:
    try:
        interpolator = PchipInterpolator(times, values, extrapolate=False)
    except (TypeError, ValueError):
        return None
    coefficients = np.asarray(interpolator.c, dtype=float)
    maximum = 0.0
    for index, (left, right) in enumerate(zip(times, times[1:])):
        width = right - left
        cubic, quadratic, linear = (
            float(coefficients[0, index]),
            float(coefficients[1, index]),
            float(coefficients[2, index]),
        )
        candidates = [0.0, width]
        if abs(cubic) > 1e-15:
            vertex = -quadratic / (3.0 * cubic)
            if 0.0 < vertex < width:
                candidates.append(vertex)
        derivatives = (
            abs(3.0 * cubic * x * x + 2.0 * quadratic * x + linear)
            for x in candidates
        )
        maximum = max(maximum, *derivatives)
    return maximum


def _finite_values(values: tuple[float, ...] | None) -> tuple[float, ...] | None:
    if values is None or not values:
        return None
    if any(
        isinstance(value, bool)
        or not isinstance(value, (int, float))
        or not math.isfinite(float(value))
        for value in values
    ):
        return None
    return tuple(float(value) for value in values)


def _valid_times(waveform: WaveformIR) -> tuple[float, ...] | None:
    times = waveform.times
    if times is None or not times:
        return None
    if any(
        isinstance(value, bool)
        or not isinstance(value, (int, float))
        or not math.isfinite(float(value))
        for value in times
    ):
        return None
    normalized = tuple(float(value) for value in times)
    if any(right <= left for left, right in zip(normalized, normalized[1:])):
        return None
    return normalized


def _slew_unit(waveform: WaveformIR) -> str | None:
    if waveform.time_unit != "us":
        return None
    if waveform.value_unit == "rad/us":
        return "rad/us^2"
    if waveform.value_unit == "rad":
        return "rad/us"
    return None


def _crosstalk_diagnostics(
    schedule: ControlScheduleIR,
    control_system: ControlSystemIR,
) -> list[DiagnosticsIR]:
    operations = _operations_by_channel(schedule)
    constraints = sorted(
        (
            constraint
            for channel in control_system.channels
            for constraint in channel.crosstalk_constraints
        ),
        key=lambda item: item.constraint_id,
    )
    return [
        _crosstalk_diagnostic(
            constraint,
            _maximum_pair_overlap(
                operations.get(constraint.left_channel_id, ()),
                operations.get(constraint.right_channel_id, ()),
            ),
        )
        for constraint in constraints
    ]


def _crosstalk_diagnostic(
    constraint: ChannelCrosstalkConstraintIR,
    overlap: float,
) -> DiagnosticsIR:
    metadata = {
        "constraint_id": constraint.constraint_id,
        "channel_ids": [
            constraint.left_channel_id,
            constraint.right_channel_id,
        ],
        "overlap_policy": constraint.overlap_policy,
        "actual_overlap_duration": overlap,
        "max_overlap_duration": constraint.max_overlap_duration,
        "time_unit": constraint.time_unit,
    }
    if overlap <= 0.0:
        return _diagnostic(
            code="CONTROL_CROSSTALK_NO_OVERLAP",
            severity="info",
            message="Crosstalk-constrained channels do not overlap.",
            object_path="control_schedule.operations",
            suffix=constraint.constraint_id,
            suggestion=None,
            metadata=metadata,
        )
    if constraint.overlap_policy == "forbidden":
        return _diagnostic(
            code="CONTROL_CROSSTALK_FORBIDDEN",
            severity="error",
            message="The Target forbids this channel overlap.",
            object_path="control_schedule.operations",
            suffix=constraint.constraint_id,
            suggestion="Remove the overlap before compile or submission.",
            metadata=metadata,
        )
    if constraint.overlap_policy == "calibration_required":
        return _diagnostic(
            code="CONTROL_CROSSTALK_CALIBRATION_REQUIRED",
            severity="warning",
            message="This overlap requires calibration facts not present publicly.",
            object_path="control_schedule.operations",
            suffix=constraint.constraint_id,
            suggestion="Resolve the pair against an authorized calibration snapshot.",
            metadata={**metadata, "constraint_status": "calibration_required"},
        )
    if (
        constraint.max_overlap_duration is not None
        and overlap > constraint.max_overlap_duration + 1e-12
    ):
        return _diagnostic(
            code="CONTROL_CROSSTALK_OVERLAP_EXCEEDED",
            severity="error",
            message="Channel overlap exceeds the Target's public bound.",
            object_path="control_schedule.operations",
            suffix=constraint.constraint_id,
            suggestion="Shorten or remove the overlapping control interval.",
            metadata=metadata,
        )
    return _diagnostic(
        code="CONTROL_CROSSTALK_ALLOWED",
        severity="info",
        message="Channel overlap is allowed by the declared Target policy.",
        object_path="control_schedule.operations",
        suffix=constraint.constraint_id,
        suggestion=None,
        metadata=metadata,
    )


def _maximum_pair_overlap(
    left: tuple[ControlOperationIR, ...],
    right: tuple[ControlOperationIR, ...],
) -> float:
    return max(
        (
            max(
                0.0,
                min(left_operation.end_time, right_operation.end_time)
                - max(left_operation.start_time, right_operation.start_time),
            )
            for left_operation in left
            for right_operation in right
        ),
        default=0.0,
    )


def _waveform_for_operation(
    program: ProgramIR,
    operation: ControlOperationIR,
) -> WaveformIR | None:
    if operation.operation_kind == "global_rabi":
        return program.hamiltonian.rabi
    if operation.operation_kind == "global_detuning":
        return program.hamiltonian.detuning
    if operation.operation_kind == "global_phase":
        phase = program.hamiltonian.phase
        return phase if isinstance(phase, WaveformIR) else None
    try:
        index = int(operation.operation_id.rsplit(".", maxsplit=1)[1])
    except (IndexError, ValueError):
        return None
    if operation.operation_kind == "local_detuning":
        detuning_terms = program.hamiltonian.local_detuning_terms
        return (
            detuning_terms[index].waveform
            if 0 <= index < len(detuning_terms)
            else None
        )
    if operation.operation_kind == "local_rabi":
        rabi_terms = program.hamiltonian.local_rabi_terms
        return rabi_terms[index].rabi if 0 <= index < len(rabi_terms) else None
    return None


def _ordered_pair(left: str, right: str) -> tuple[str, str]:
    return (left, right) if left <= right else (right, left)


def _operation_path(operation: ControlOperationIR) -> str:
    value = operation.metadata.get("program_path")
    return value if isinstance(value, str) else "control_schedule.operations"


def _diagnostic(
    *,
    code: str,
    severity: Severity,
    message: str,
    object_path: str,
    suffix: str,
    suggestion: str | None,
    metadata: dict[str, Any],
) -> DiagnosticsIR:
    normalized_suffix = suffix.replace("[", ".").replace("]", "")
    return DiagnosticsIR(
        diagnostic_id=f"control.{code.lower()}.{normalized_suffix}",
        stage="validation",
        severity=severity,
        code=code,
        message=message,
        object_path=object_path,
        suggestion=suggestion,
        metadata=metadata,
    )
