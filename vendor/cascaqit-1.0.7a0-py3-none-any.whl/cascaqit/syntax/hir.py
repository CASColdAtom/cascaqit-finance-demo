"""Resolved semantic HIR models for the hybrid Python frontend."""

from __future__ import annotations

import json
import math
from dataclasses import dataclass, field
from typing import Any, Literal, Union

from cascaqit.native_ir.base import IRMixin
from cascaqit.syntax.diagnostics import FrontendDiagnosticIR
from cascaqit.syntax.source import SYNTAX_SCHEMA_VERSION, SourceMap, SourceSpan

__all__ = [
    "SemanticAnalysisResult",
    "SemanticArgumentHIR",
    "SemanticBlockHIR",
    "SemanticInvocationHIR",
    "SemanticLogicalResourceHIR",
    "SemanticParameterHIR",
    "SemanticProgramHIR",
    "SymbolBinding",
]

SemanticBlockKind = Literal["digital", "analog", "measurement"]
SemanticDType = Literal["float", "int", "bool"]
SemanticResourceKind = Literal["qubit", "atom", "classical_bit"]
BindingState = Literal["bound", "defaulted", "unbound"]
ValueSource = Literal["literal", "symbol", "default", "unbound"]
SemanticScalar = Union[bool, int, float]


def _require_identifier(value: str, *, field_name: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field_name} must be a non-empty string.")


def _validate_optional_span(span: SourceSpan | None) -> None:
    if span is not None and not isinstance(span, SourceSpan):
        raise TypeError("source_span must be SourceSpan or None.")


def _validate_scalar(value: object, *, field_name: str) -> None:
    if isinstance(value, (bool, int)):
        return
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError(f"{field_name} must be finite.")
        return
    raise TypeError(f"{field_name} must be bool, int, or float.")


@dataclass(frozen=True)
class SymbolBinding(IRMixin):
    """A typed external symbol available during semantic analysis."""

    name: str
    dtype: SemanticDType
    value: SemanticScalar
    unit: str | None = None
    source_span: SourceSpan | None = None
    schema_version: str = SYNTAX_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_identifier(self.name, field_name="name")
        if self.dtype not in {"float", "int", "bool"}:
            raise ValueError("dtype must be float, int, or bool.")
        _validate_scalar(self.value, field_name="symbol value")
        _validate_typed_value(
            self.value,
            dtype=self.dtype,
            field_name="symbol value",
        )
        if self.unit is not None and not self.unit.strip():
            raise ValueError("unit must be None or a non-empty string.")
        _validate_optional_span(self.source_span)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SymbolBinding:
        """Build a symbol binding from a dictionary."""
        return cls(
            name=str(data["name"]),
            dtype=data["dtype"],
            value=data["value"],
            unit=None if data.get("unit") is None else str(data["unit"]),
            source_span=_span_from_data(data.get("source_span")),
            schema_version=str(
                data.get("schema_version", SYNTAX_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class SemanticParameterHIR(IRMixin):
    """A resolved block parameter declaration."""

    node_id: str
    syntax_node_id: str
    name: str
    dtype: SemanticDType
    unit: str | None
    required: bool
    default: SemanticScalar | None = None
    source_span: SourceSpan | None = None
    schema_version: str = SYNTAX_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _validate_semantic_node(self.node_id, self.syntax_node_id)
        _require_identifier(self.name, field_name="name")
        if self.dtype not in {"float", "int", "bool"}:
            raise ValueError("dtype must be float, int, or bool.")
        if self.default is not None:
            _validate_scalar(self.default, field_name="default")
            _validate_typed_value(
                self.default,
                dtype=self.dtype,
                field_name="default",
            )
        _validate_optional_span(self.source_span)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SemanticParameterHIR:
        """Build a semantic parameter from a dictionary."""
        return cls(
            node_id=str(data["node_id"]),
            syntax_node_id=str(data["syntax_node_id"]),
            name=str(data["name"]),
            dtype=data["dtype"],
            unit=None if data.get("unit") is None else str(data["unit"]),
            required=bool(data["required"]),
            default=data.get("default"),
            source_span=_span_from_data(data.get("source_span")),
            schema_version=str(
                data.get("schema_version", SYNTAX_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class SemanticLogicalResourceHIR(IRMixin):
    """A resolved logical resource declaration."""

    node_id: str
    syntax_node_id: str
    logical_id: str
    resource_kind: SemanticResourceKind
    source_span: SourceSpan | None = None
    schema_version: str = SYNTAX_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _validate_semantic_node(self.node_id, self.syntax_node_id)
        _require_identifier(self.logical_id, field_name="logical_id")
        if self.resource_kind not in {"qubit", "atom", "classical_bit"}:
            raise ValueError(
                "resource_kind must be qubit, atom, or classical_bit."
            )
        _validate_optional_span(self.source_span)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SemanticLogicalResourceHIR:
        """Build a semantic logical resource from a dictionary."""
        return cls(
            node_id=str(data["node_id"]),
            syntax_node_id=str(data["syntax_node_id"]),
            logical_id=str(data["logical_id"]),
            resource_kind=data["resource_kind"],
            source_span=_span_from_data(data.get("source_span")),
            schema_version=str(
                data.get("schema_version", SYNTAX_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class SemanticArgumentHIR(IRMixin):
    """A typed and resolved invocation argument."""

    node_id: str
    syntax_node_id: str
    name: str
    dtype: SemanticDType
    unit: str | None
    binding_state: BindingState
    value: SemanticScalar | None
    value_source: ValueSource
    source_symbol: str | None = None
    source_span: SourceSpan | None = None
    schema_version: str = SYNTAX_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _validate_semantic_node(self.node_id, self.syntax_node_id)
        _require_identifier(self.name, field_name="name")
        if self.dtype not in {"float", "int", "bool"}:
            raise ValueError("dtype must be float, int, or bool.")
        if self.binding_state not in {"bound", "defaulted", "unbound"}:
            raise ValueError("invalid binding_state.")
        if self.value_source not in {"literal", "symbol", "default", "unbound"}:
            raise ValueError("invalid value_source.")
        if self.binding_state == "unbound":
            if self.value is not None or self.value_source != "unbound":
                raise ValueError("unbound argument must not contain a value.")
        elif self.value is None:
            raise ValueError("bound argument must contain a value.")
        else:
            _validate_scalar(self.value, field_name="argument value")
            _validate_typed_value(
                self.value,
                dtype=self.dtype,
                field_name="argument value",
            )
        if self.value_source == "symbol":
            if self.source_symbol is None:
                raise ValueError("symbol value requires source_symbol.")
        elif self.source_symbol is not None:
            raise ValueError("source_symbol is only valid for symbol values.")
        _validate_optional_span(self.source_span)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SemanticArgumentHIR:
        """Build a semantic argument from a dictionary."""
        return cls(
            node_id=str(data["node_id"]),
            syntax_node_id=str(data["syntax_node_id"]),
            name=str(data["name"]),
            dtype=data["dtype"],
            unit=None if data.get("unit") is None else str(data["unit"]),
            binding_state=data["binding_state"],
            value=data.get("value"),
            value_source=data["value_source"],
            source_symbol=data.get("source_symbol"),
            source_span=_span_from_data(data.get("source_span")),
            schema_version=str(
                data.get("schema_version", SYNTAX_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class SemanticBlockHIR(IRMixin):
    """A resolved block declaration shared by all frontend forms."""

    node_id: str
    syntax_node_id: str
    name: str
    block_kind: SemanticBlockKind
    parameters: tuple[SemanticParameterHIR, ...] = ()
    logical_resources: tuple[SemanticLogicalResourceHIR, ...] = ()
    required_capabilities: tuple[str, ...] = ()
    source_span: SourceSpan | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = SYNTAX_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _validate_semantic_node(self.node_id, self.syntax_node_id)
        _require_identifier(self.name, field_name="name")
        if self.block_kind not in {"digital", "analog", "measurement"}:
            raise ValueError("invalid block_kind.")
        _validate_optional_span(self.source_span)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SemanticBlockHIR:
        """Build a semantic block from a dictionary."""
        return cls(
            node_id=str(data["node_id"]),
            syntax_node_id=str(data["syntax_node_id"]),
            name=str(data["name"]),
            block_kind=data["block_kind"],
            parameters=tuple(
                SemanticParameterHIR.from_dict(item)
                for item in data.get("parameters", ())
            ),
            logical_resources=tuple(
                SemanticLogicalResourceHIR.from_dict(item)
                for item in data.get("logical_resources", ())
            ),
            required_capabilities=tuple(
                str(item) for item in data.get("required_capabilities", ())
            ),
            source_span=_span_from_data(data.get("source_span")),
            metadata=dict(data.get("metadata", {})),
            schema_version=str(
                data.get("schema_version", SYNTAX_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class SemanticInvocationHIR(IRMixin):
    """A resolved ordered block invocation."""

    node_id: str
    syntax_node_id: str
    block_node_id: str
    block_name: str
    block_kind: SemanticBlockKind
    arguments: tuple[SemanticArgumentHIR, ...] = ()
    mapping: dict[str, str] = field(default_factory=dict)
    source_span: SourceSpan | None = None
    schema_version: str = SYNTAX_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _validate_semantic_node(self.node_id, self.syntax_node_id)
        _require_identifier(self.block_node_id, field_name="block_node_id")
        _require_identifier(self.block_name, field_name="block_name")
        if self.block_kind not in {"digital", "analog", "measurement"}:
            raise ValueError("invalid block_kind.")
        _validate_optional_span(self.source_span)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SemanticInvocationHIR:
        """Build a semantic invocation from a dictionary."""
        return cls(
            node_id=str(data["node_id"]),
            syntax_node_id=str(data["syntax_node_id"]),
            block_node_id=str(data["block_node_id"]),
            block_name=str(data["block_name"]),
            block_kind=data["block_kind"],
            arguments=tuple(
                SemanticArgumentHIR.from_dict(item)
                for item in data.get("arguments", ())
            ),
            mapping={
                str(key): str(value)
                for key, value in data.get("mapping", {}).items()
            },
            source_span=_span_from_data(data.get("source_span")),
            schema_version=str(
                data.get("schema_version", SYNTAX_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class SemanticProgramHIR(IRMixin):
    """A fully analyzed frontend program ready for orchestration lowering."""

    node_id: str
    syntax_node_id: str
    program_id: str
    syntax_hash: str
    blocks: tuple[SemanticBlockHIR, ...] = ()
    invocations: tuple[SemanticInvocationHIR, ...] = ()
    source_map: SourceMap = field(default_factory=SourceMap)
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = SYNTAX_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _validate_semantic_node(self.node_id, self.syntax_node_id)
        _require_identifier(self.program_id, field_name="program_id")
        if len(self.syntax_hash) != 64 or any(
            character not in "0123456789abcdef" for character in self.syntax_hash
        ):
            raise ValueError("syntax_hash must be a lowercase SHA-256 hex digest.")
        if not isinstance(self.source_map, SourceMap):
            raise TypeError("source_map must be SourceMap.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SemanticProgramHIR:
        """Build a semantic program from a dictionary."""
        return cls(
            node_id=str(data["node_id"]),
            syntax_node_id=str(data["syntax_node_id"]),
            program_id=str(data["program_id"]),
            syntax_hash=str(data["syntax_hash"]),
            blocks=tuple(
                SemanticBlockHIR.from_dict(item)
                for item in data.get("blocks", ())
            ),
            invocations=tuple(
                SemanticInvocationHIR.from_dict(item)
                for item in data.get("invocations", ())
            ),
            source_map=SourceMap.from_dict(data.get("source_map", {})),
            metadata=dict(data.get("metadata", {})),
            schema_version=str(
                data.get("schema_version", SYNTAX_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> SemanticProgramHIR:
        """Build a semantic program from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("SemanticProgramHIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class SemanticAnalysisResult(IRMixin):
    """Semantic HIR or blocking frontend diagnostics."""

    hir: SemanticProgramHIR | None
    diagnostics: tuple[FrontendDiagnosticIR, ...] = ()
    schema_version: str = SYNTAX_SCHEMA_VERSION

    @property
    def has_errors(self) -> bool:
        """Return whether semantic analysis emitted any error."""
        return any(item.severity == "error" for item in self.diagnostics)

    def __post_init__(self) -> None:
        if self.has_errors and self.hir is not None:
            raise ValueError("analysis with errors must not expose a HIR.")
        if not self.has_errors and self.hir is None:
            raise ValueError("analysis without errors must expose a HIR.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SemanticAnalysisResult:
        """Build an analysis result from a dictionary."""
        hir_data = data.get("hir")
        return cls(
            hir=None
            if hir_data is None
            else SemanticProgramHIR.from_dict(hir_data),
            diagnostics=tuple(
                FrontendDiagnosticIR.from_dict(item)
                for item in data.get("diagnostics", ())
            ),
            schema_version=str(
                data.get("schema_version", SYNTAX_SCHEMA_VERSION)
            ),
        )


def _validate_semantic_node(node_id: str, syntax_node_id: str) -> None:
    _require_identifier(node_id, field_name="node_id")
    _require_identifier(syntax_node_id, field_name="syntax_node_id")


def _validate_typed_value(
    value: object,
    *,
    dtype: SemanticDType,
    field_name: str,
) -> None:
    valid = (
        (dtype == "bool" and isinstance(value, bool))
        or (dtype == "int" and isinstance(value, int) and not isinstance(value, bool))
        or (
            dtype == "float"
            and isinstance(value, (int, float))
            and not isinstance(value, bool)
        )
    )
    if not valid:
        raise ValueError(f"{field_name} does not match dtype '{dtype}'.")


def _span_from_data(data: Any) -> SourceSpan | None:
    if data is None:
        return None
    if not isinstance(data, dict):
        raise TypeError("source_span must contain an object.")
    return SourceSpan.from_dict(data)
