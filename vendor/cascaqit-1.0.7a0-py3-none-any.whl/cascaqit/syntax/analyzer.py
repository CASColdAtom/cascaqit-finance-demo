"""Deterministic semantic analysis for the hybrid frontend Syntax AST."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any

from cascaqit.syntax.ast import (
    ArgumentSyntax,
    BlockInvocationSyntax,
    BlockSyntax,
    ParameterSyntax,
    ProgramSyntaxAST,
)
from cascaqit.syntax.diagnostics import FrontendDiagnosticIR
from cascaqit.syntax.hir import (
    SemanticAnalysisResult,
    SemanticArgumentHIR,
    SemanticBlockHIR,
    SemanticInvocationHIR,
    SemanticLogicalResourceHIR,
    SemanticParameterHIR,
    SemanticProgramHIR,
    SymbolBinding,
)
from cascaqit.syntax.source import SourceMap, SourceMapEntry, SourceSpan

__all__ = ["analyze"]


def analyze(
    syntax: ProgramSyntaxAST,
    *,
    symbols: Mapping[str, SymbolBinding] | None = None,
    available_capabilities: Sequence[str] = (),
) -> SemanticAnalysisResult:
    """Lower a syntax tree to HIR or return blocking semantic diagnostics."""
    if not isinstance(syntax, ProgramSyntaxAST):
        raise TypeError("syntax must be ProgramSyntaxAST.")
    symbol_table = _normalize_symbols(symbols)
    capabilities = _normalize_capabilities(available_capabilities)
    diagnostics: list[FrontendDiagnosticIR] = []
    block_by_name = _collect_block_symbols(syntax.blocks, diagnostics)
    semantic_blocks = tuple(
        _lower_block(block, capabilities, diagnostics) for block in syntax.blocks
    )
    semantic_block_by_name = {
        block.name: block for block in semantic_blocks if block.name in block_by_name
    }
    semantic_invocations: list[SemanticInvocationHIR] = []
    for index, invocation in enumerate(syntax.invocations):
        lowered = _lower_invocation(
            invocation,
            index=index,
            block_syntax=block_by_name.get(invocation.block_name),
            block_hir=semantic_block_by_name.get(invocation.block_name),
            symbols=symbol_table,
            diagnostics=diagnostics,
        )
        if lowered is not None:
            semantic_invocations.append(lowered)
    ordered_diagnostics = tuple(diagnostics)
    if any(item.severity == "error" for item in ordered_diagnostics):
        return SemanticAnalysisResult(hir=None, diagnostics=ordered_diagnostics)
    hir = SemanticProgramHIR(
        node_id=f"hir.{syntax.node_id}",
        syntax_node_id=syntax.node_id,
        program_id=syntax.program_id,
        syntax_hash=syntax.stable_hash(),
        blocks=semantic_blocks,
        invocations=tuple(semantic_invocations),
        source_map=_complete_source_map(syntax),
        metadata={
            "frontend": "python_builder",
            "analysis": "syntax_to_semantic_hir",
        },
    )
    return SemanticAnalysisResult(hir=hir, diagnostics=ordered_diagnostics)


def _normalize_symbols(
    symbols: Mapping[str, SymbolBinding] | None,
) -> dict[str, SymbolBinding]:
    if symbols is None:
        return {}
    normalized: dict[str, SymbolBinding] = {}
    for name, binding in symbols.items():
        if not isinstance(binding, SymbolBinding):
            raise TypeError("symbols values must be SymbolBinding.")
        if name != binding.name:
            raise ValueError(
                f"symbol key '{name}' does not match binding name "
                f"'{binding.name}'."
            )
        normalized[name] = binding
    return normalized


def _normalize_capabilities(values: Sequence[str]) -> set[str]:
    normalized: set[str] = set()
    for value in values:
        if not isinstance(value, str) or not value.strip():
            raise ValueError("available capabilities must be non-empty strings.")
        normalized.add(value)
    return normalized


def _collect_block_symbols(
    blocks: tuple[BlockSyntax, ...],
    diagnostics: list[FrontendDiagnosticIR],
) -> dict[str, BlockSyntax]:
    block_by_name: dict[str, BlockSyntax] = {}
    for index, block in enumerate(blocks):
        if block.name in block_by_name:
            diagnostics.append(
                _diagnostic(
                    block.node_id,
                    code="SEMANTIC_BLOCK_DUPLICATE",
                    message=f"Block symbol '{block.name}' is declared more than once.",
                    object_path=f"program.blocks[{index}].name",
                    source_span=block.source_span,
                    suggestion="Rename or remove the duplicate block declaration.",
                    metadata={"block_name": block.name},
                )
            )
            continue
        block_by_name[block.name] = block
    return block_by_name


def _lower_block(
    block: BlockSyntax,
    capabilities: set[str],
    diagnostics: list[FrontendDiagnosticIR],
) -> SemanticBlockHIR:
    for resource_index, resource in enumerate(block.logical_resources):
        if not _resource_kind_matches(block.block_kind, resource.resource_kind):
            diagnostics.append(
                _diagnostic(
                    resource.node_id,
                    code="SEMANTIC_LOGICAL_RESOURCE_KIND_INVALID",
                    message=(
                        f"Resource '{resource.logical_id}' of kind "
                        f"'{resource.resource_kind}' is invalid for "
                        f"a {block.block_kind} block."
                    ),
                    object_path=(
                        f"block.{block.name}.logical_resources[{resource_index}]"
                    ),
                    source_span=resource.source_span,
                    suggestion="Use a logical resource kind supported by the block.",
                    metadata={
                        "block_kind": block.block_kind,
                        "resource_kind": resource.resource_kind,
                    },
                )
            )
    for capability_index, capability in enumerate(block.required_capabilities):
        if capability not in capabilities:
            diagnostics.append(
                _diagnostic(
                    block.node_id,
                    code="SEMANTIC_CAPABILITY_UNSUPPORTED",
                    message=f"Required capability '{capability}' is unavailable.",
                    object_path=(
                        f"block.{block.name}.required_capabilities"
                        f"[{capability_index}]"
                    ),
                    source_span=block.source_span,
                    suggestion="Select a supported capability or change the block.",
                    metadata={"capability": capability},
                )
            )
    return SemanticBlockHIR(
        node_id=f"hir.{block.node_id}",
        syntax_node_id=block.node_id,
        name=block.name,
        block_kind=block.block_kind,
        parameters=tuple(
            SemanticParameterHIR(
                node_id=f"hir.{parameter.node_id}",
                syntax_node_id=parameter.node_id,
                name=parameter.name,
                dtype=parameter.dtype,
                unit=parameter.unit,
                required=parameter.required,
                default=parameter.default,
                source_span=parameter.source_span,
            )
            for parameter in block.parameters
        ),
        logical_resources=tuple(
            SemanticLogicalResourceHIR(
                node_id=f"hir.{resource.node_id}",
                syntax_node_id=resource.node_id,
                logical_id=resource.logical_id,
                resource_kind=resource.resource_kind,
                source_span=resource.source_span,
            )
            for resource in block.logical_resources
        ),
        required_capabilities=block.required_capabilities,
        source_span=block.source_span,
        metadata=dict(block.metadata),
    )


def _lower_invocation(
    invocation: BlockInvocationSyntax,
    *,
    index: int,
    block_syntax: BlockSyntax | None,
    block_hir: SemanticBlockHIR | None,
    symbols: Mapping[str, SymbolBinding],
    diagnostics: list[FrontendDiagnosticIR],
) -> SemanticInvocationHIR | None:
    if block_syntax is None or block_hir is None:
        diagnostics.append(
            _diagnostic(
                invocation.node_id,
                code="SEMANTIC_BLOCK_UNKNOWN",
                message=f"Block '{invocation.block_name}' is not declared.",
                object_path=f"program.invocations[{index}].block_name",
                source_span=invocation.source_span,
                suggestion="Declare the block before invoking it.",
                metadata={"block_name": invocation.block_name},
            )
        )
        return None
    declared_parameters = {
        parameter.name: parameter for parameter in block_syntax.parameters
    }
    arguments = {argument.name: argument for argument in invocation.arguments}
    for argument_index, argument in enumerate(invocation.arguments):
        if argument.name not in declared_parameters:
            diagnostics.append(
                _diagnostic(
                    argument.node_id,
                    code="SEMANTIC_ARGUMENT_UNKNOWN",
                    message=(
                        f"Argument '{argument.name}' is not declared by "
                        f"block '{block_syntax.name}'."
                    ),
                    object_path=(
                        f"program.invocations[{index}].arguments"
                        f"[{argument_index}]"
                    ),
                    source_span=argument.source_span or invocation.source_span,
                    suggestion="Remove the argument or declare a matching parameter.",
                    metadata={
                        "argument_name": argument.name,
                        "block_name": block_syntax.name,
                    },
                )
            )
    semantic_arguments: list[SemanticArgumentHIR] = []
    for parameter_index, parameter in enumerate(block_syntax.parameters):
        lowered = _resolve_argument(
            parameter,
            arguments.get(parameter.name),
            invocation=invocation,
            invocation_index=index,
            parameter_index=parameter_index,
            symbols=symbols,
            diagnostics=diagnostics,
        )
        if lowered is not None:
            semantic_arguments.append(lowered)
    _validate_mapping(
        block_syntax,
        invocation,
        invocation_index=index,
        diagnostics=diagnostics,
    )
    return SemanticInvocationHIR(
        node_id=f"hir.{invocation.node_id}",
        syntax_node_id=invocation.node_id,
        block_node_id=block_hir.node_id,
        block_name=block_hir.name,
        block_kind=block_hir.block_kind,
        arguments=tuple(semantic_arguments),
        mapping=dict(invocation.mapping),
        source_span=invocation.source_span,
    )


def _resolve_argument(
    parameter: ParameterSyntax,
    argument: ArgumentSyntax | None,
    *,
    invocation: BlockInvocationSyntax,
    invocation_index: int,
    parameter_index: int,
    symbols: Mapping[str, SymbolBinding],
    diagnostics: list[FrontendDiagnosticIR],
) -> SemanticArgumentHIR | None:
    if argument is None:
        if parameter.default is not None:
            return SemanticArgumentHIR(
                node_id=f"hir.{invocation.node_id}.argument.{parameter.name}",
                syntax_node_id=parameter.node_id,
                name=parameter.name,
                dtype=parameter.dtype,
                unit=parameter.unit,
                binding_state="defaulted",
                value=parameter.default,
                value_source="default",
                source_span=invocation.source_span or parameter.source_span,
            )
        if parameter.required:
            diagnostics.append(
                _diagnostic(
                    invocation.node_id,
                    code="SEMANTIC_PARAMETER_UNBOUND",
                    message=(
                        f"Required parameter '{parameter.name}' is not bound "
                        f"for block '{invocation.block_name}'."
                    ),
                    object_path=(
                        f"program.invocations[{invocation_index}]"
                        f".parameters[{parameter_index}]"
                    ),
                    source_span=invocation.source_span or parameter.source_span,
                    suggestion=f"Bind parameter '{parameter.name}'.",
                    metadata={"parameter": parameter.name},
                )
            )
            return None
        return SemanticArgumentHIR(
            node_id=f"hir.{invocation.node_id}.argument.{parameter.name}",
            syntax_node_id=parameter.node_id,
            name=parameter.name,
            dtype=parameter.dtype,
            unit=parameter.unit,
            binding_state="unbound",
            value=None,
            value_source="unbound",
            source_span=invocation.source_span or parameter.source_span,
        )
    if argument.value_kind == "literal":
        value = argument.value
        if isinstance(value, str):
            raise AssertionError("literal syntax value must be scalar.")
        compatible = _check_type_and_unit(
            parameter,
            actual_dtype=_infer_dtype(value),
            actual_unit=argument.unit,
            source_node_id=argument.node_id,
            source_span=argument.source_span or invocation.source_span,
            object_path=(
                f"program.invocations[{invocation_index}]"
                f".arguments.{argument.name}"
            ),
            diagnostics=diagnostics,
        )
        if not compatible:
            return None
        return SemanticArgumentHIR(
            node_id=f"hir.{argument.node_id}",
            syntax_node_id=argument.node_id,
            name=parameter.name,
            dtype=parameter.dtype,
            unit=parameter.unit,
            binding_state="bound",
            value=_normalize_value(value, parameter.dtype),
            value_source="literal",
            source_span=argument.source_span or invocation.source_span,
        )
    symbol_name = str(argument.value)
    binding = symbols.get(symbol_name)
    if binding is None:
        diagnostics.append(
            _diagnostic(
                argument.node_id,
                code="SEMANTIC_SYMBOL_UNBOUND",
                message=f"Symbol '{symbol_name}' is not bound.",
                object_path=(
                    f"program.invocations[{invocation_index}]"
                    f".arguments.{argument.name}"
                ),
                source_span=argument.source_span or invocation.source_span,
                suggestion="Provide a typed SymbolBinding before analysis.",
                metadata={"symbol": symbol_name},
            )
        )
        return None
    compatible = _check_type_and_unit(
        parameter,
        actual_dtype=binding.dtype,
        actual_unit=binding.unit,
        source_node_id=argument.node_id,
        source_span=argument.source_span or binding.source_span,
        object_path=(
            f"program.invocations[{invocation_index}]"
            f".arguments.{argument.name}"
        ),
        diagnostics=diagnostics,
    )
    if not compatible:
        return None
    return SemanticArgumentHIR(
        node_id=f"hir.{argument.node_id}",
        syntax_node_id=argument.node_id,
        name=parameter.name,
        dtype=parameter.dtype,
        unit=parameter.unit,
        binding_state="bound",
        value=_normalize_value(binding.value, parameter.dtype),
        value_source="symbol",
        source_symbol=binding.name,
        source_span=argument.source_span or binding.source_span,
    )


def _check_type_and_unit(
    parameter: ParameterSyntax,
    *,
    actual_dtype: str,
    actual_unit: str | None,
    source_node_id: str,
    source_span: SourceSpan | None,
    object_path: str,
    diagnostics: list[FrontendDiagnosticIR],
) -> bool:
    type_matches = _dtype_compatible(parameter.dtype, actual_dtype)
    unit_matches = parameter.unit == actual_unit
    if not type_matches:
        diagnostics.append(
            _diagnostic(
                source_node_id,
                code="SEMANTIC_PARAMETER_TYPE_MISMATCH",
                message=(
                    f"Parameter '{parameter.name}' expects {parameter.dtype}, "
                    f"but received {actual_dtype}."
                ),
                object_path=object_path,
                source_span=source_span,
                suggestion="Bind a value with the declared parameter type.",
                metadata={
                    "expected_dtype": parameter.dtype,
                    "actual_dtype": actual_dtype,
                },
            )
        )
    if not unit_matches:
        diagnostics.append(
            _diagnostic(
                source_node_id,
                code="SEMANTIC_PARAMETER_UNIT_MISMATCH",
                message=(
                    f"Parameter '{parameter.name}' expects unit "
                    f"{parameter.unit!r}, but received {actual_unit!r}."
                ),
                object_path=object_path,
                source_span=source_span,
                suggestion=(
                    "Bind a value with the declared unit; no implicit "
                    "conversion is performed."
                ),
                metadata={
                    "expected_unit": parameter.unit,
                    "actual_unit": actual_unit,
                },
            )
        )
    return type_matches and unit_matches


def _validate_mapping(
    block: BlockSyntax,
    invocation: BlockInvocationSyntax,
    *,
    invocation_index: int,
    diagnostics: list[FrontendDiagnosticIR],
) -> None:
    declared_ids = {resource.logical_id for resource in block.logical_resources}
    mapped_ids = set(invocation.mapping)
    for missing in sorted(declared_ids - mapped_ids):
        diagnostics.append(
            _diagnostic(
                invocation.node_id,
                code="SEMANTIC_LOGICAL_MAPPING_MISSING",
                message=f"Logical resource '{missing}' has no invocation mapping.",
                object_path=f"program.invocations[{invocation_index}].mapping",
                source_span=invocation.source_span,
                suggestion=f"Map local resource '{missing}' to a logical id.",
                metadata={"logical_id": missing},
            )
        )
    for unknown in sorted(mapped_ids - declared_ids):
        diagnostics.append(
            _diagnostic(
                invocation.node_id,
                code="SEMANTIC_LOGICAL_MAPPING_UNKNOWN",
                message=(
                    f"Mapping key '{unknown}' is not declared by "
                    f"block '{block.name}'."
                ),
                object_path=f"program.invocations[{invocation_index}].mapping",
                source_span=invocation.source_span,
                suggestion="Remove the mapping or declare the local resource.",
                metadata={"logical_id": unknown},
            )
        )


def _complete_source_map(syntax: ProgramSyntaxAST) -> SourceMap:
    existing = {entry.node_id: entry for entry in syntax.source_map.entries}
    entries: list[SourceMapEntry] = []
    for node_id, span in _syntax_nodes(syntax):
        entry = existing.get(node_id)
        if entry is not None:
            entries.append(entry)
            continue
        resolved_span = span or SourceSpan.unknown(node_id)
        entries.append(
            SourceMapEntry(
                node_id=node_id,
                span=resolved_span,
                origin="python" if resolved_span.is_known else "generated",
            )
        )
    return SourceMap(entries=tuple(entries))


def _syntax_nodes(
    syntax: ProgramSyntaxAST,
) -> tuple[tuple[str, SourceSpan | None], ...]:
    nodes: list[tuple[str, SourceSpan | None]] = [(syntax.node_id, None)]
    for block in syntax.blocks:
        nodes.append((block.node_id, block.source_span))
        nodes.extend(
            (parameter.node_id, parameter.source_span)
            for parameter in block.parameters
        )
        nodes.extend(
            (resource.node_id, resource.source_span)
            for resource in block.logical_resources
        )
    for invocation in syntax.invocations:
        nodes.append((invocation.node_id, invocation.source_span))
        nodes.extend(
            (argument.node_id, argument.source_span)
            for argument in invocation.arguments
        )
    return tuple(nodes)


def _resource_kind_matches(block_kind: str, resource_kind: str) -> bool:
    if block_kind == "digital":
        return resource_kind in {"qubit", "classical_bit"}
    if block_kind == "analog":
        return resource_kind == "atom"
    return resource_kind in {"qubit", "atom", "classical_bit"}


def _infer_dtype(value: object) -> str:
    if isinstance(value, bool):
        return "bool"
    if isinstance(value, int):
        return "int"
    return "float"


def _dtype_compatible(expected: str, actual: str) -> bool:
    return expected == actual or (expected == "float" and actual == "int")


def _normalize_value(value: Any, dtype: str) -> bool | int | float:
    if dtype == "float" and not isinstance(value, bool):
        return float(value)
    if dtype == "int" and isinstance(value, int) and not isinstance(value, bool):
        return value
    if dtype == "bool" and isinstance(value, bool):
        return value
    if isinstance(value, (bool, int, float)):
        return value
    raise TypeError("semantic values must be bool, int, or float.")


def _diagnostic(
    node_id: str,
    *,
    code: str,
    message: str,
    object_path: str,
    source_span: SourceSpan | None,
    suggestion: str,
    metadata: dict[str, Any],
) -> FrontendDiagnosticIR:
    return FrontendDiagnosticIR(
        diagnostic_id=f"{node_id}.{code.lower()}",
        stage="semantic",
        severity="error",
        code=code,
        message=message,
        object_path=object_path,
        source_span=source_span,
        suggestion=suggestion,
        metadata=metadata,
    )
