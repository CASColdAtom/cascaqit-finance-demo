"""Materialize captured decorator declarations into existing Native builders."""

from __future__ import annotations

import hashlib
import math
from collections.abc import Callable, Mapping, Sequence
from typing import TYPE_CHECKING, NoReturn, Union

from cascaqit.analog import (
    AHSProgram,
    AtomRegister,
    Waveform,
)
from cascaqit.digital import Circuit
from cascaqit.parameters.canonical import Expression, Parameter
from cascaqit.syntax.body import (
    BodyLoweringError,
    BodyOperationSyntax,
    BodyValueSyntax,
)
from cascaqit.syntax.diagnostics import FrontendDiagnosticIR
from cascaqit.syntax.source import SourceSpan

if TYPE_CHECKING:
    from cascaqit.syntax.decorators import BlockDefinition

__all__ = ["lower_block_definition"]

DigitalScalarExpression = Union[int, float, Parameter, Expression]
AnalogScalarExpression = Union[int, float, Parameter, Expression]

_DIGITAL_ONE_QUBIT = frozenset({"h", "x"})
_DIGITAL_ROTATIONS = frozenset({"rx", "ry", "rz"})
_DIGITAL_TWO_QUBIT = frozenset({"cx", "cz"})
_DIGITAL_OPERATIONS = (
    _DIGITAL_ONE_QUBIT
    | _DIGITAL_ROTATIONS
    | _DIGITAL_TWO_QUBIT
    | {"measure"}
)


def lower_block_definition(
    definition: BlockDefinition,
    *,
    args: tuple[object, ...],
    kwargs: Mapping[str, object],
    register: AtomRegister | None,
) -> Circuit | AHSProgram:
    """Materialize one captured declaration without executing its function."""
    body = definition.body_declaration
    if body is None:
        if definition.body_diagnostics:
            raise BodyLoweringError(definition.body_diagnostics)
        _raise_lowering_error(
            code="BODY_CAPTURE_NOT_REQUESTED",
            message="Body lowering was not enabled for this block.",
            object_path=f"{definition.declaration.node_id}.body",
            span=definition.declaration.source_span,
            suggestion="Set lower_body=True or use the Builder API.",
        )
    assert body is not None
    bindings = _bind_arguments(definition, args=args, kwargs=kwargs)
    if body.block_kind == "digital":
        if register is not None:
            _raise_lowering_error(
                code="DIGITAL_BODY_REGISTER_UNEXPECTED",
                message="Digital body lowering does not accept an AtomRegister.",
                object_path=f"{body.node_id}.register",
                span=body.source_span,
                suggestion="Remove register from the Digital lower() call.",
            )
        return _lower_digital(definition, bindings=bindings)
    if body.block_kind == "analog":
        return _lower_analog(definition, bindings=bindings, register=register)
    _raise_lowering_error(
        code="BODY_BLOCK_KIND_UNSUPPORTED",
        message=f"Block kind '{body.block_kind}' cannot be materialized.",
        object_path=body.node_id,
        span=body.source_span,
        suggestion="Use a Digital or Analog declaration block.",
    )


def _bind_arguments(
    definition: BlockDefinition,
    *,
    args: tuple[object, ...],
    kwargs: Mapping[str, object],
) -> dict[str, object] | None:
    if not args and not kwargs:
        return None
    try:
        bound = definition.signature.bind(*args, **dict(kwargs))
    except TypeError as exc:
        _raise_lowering_error(
            code="BODY_LOWER_ARGUMENTS_INVALID",
            message=f"Body lowering arguments are invalid: {exc}",
            object_path=f"{definition.declaration.node_id}.parameters",
            span=definition.declaration.source_span,
            suggestion="Pass every required block parameter exactly once.",
        )
    bound.apply_defaults()
    return dict(bound.arguments)


def _lower_digital(
    definition: BlockDefinition,
    *,
    bindings: dict[str, object] | None,
) -> Circuit:
    body = definition.body_declaration
    assert body is not None
    qubits = tuple(
        resource.logical_id
        for resource in definition.declaration.logical_resources
        if resource.resource_kind == "qubit"
    )
    circuit = Circuit(
        qubits,
        program_id=f"program.decorator.{definition.declaration.name}",
        metadata={
            "declaration_source": "decorator_body",
            "body_declaration_hash": body.stable_hash(),
            "function_body_executed": False,
        },
    )
    parameter_values: dict[str, Parameter] = {}
    specs = definition.parameter_specs
    for parameter in definition.declaration.parameters:
        if parameter.dtype != "float" or parameter.unit not in {None, "rad"}:
            _raise_lowering_error(
                code="DIGITAL_BODY_PARAMETER_TYPE_UNSUPPORTED",
                message=(
                    f"Digital parameter '{parameter.name}' must be float with "
                    "unit None or 'rad'."
                ),
                object_path=f"{body.node_id}.parameters.{parameter.name}",
                span=parameter.source_span,
                suggestion="Declare a float/rad parameter for Digital lowering.",
            )
        spec = specs.get(parameter.name)
        default = _optional_float(
            parameter.default,
            object_path=f"{body.node_id}.parameters.{parameter.name}.default",
            span=parameter.source_span,
        )
        parameter_values[parameter.name] = circuit.parameter(
            parameter.name,
            default=default,
            lower_bound=None if spec is None else spec.lower_bound,
            upper_bound=None if spec is None else spec.upper_bound,
        )
    if not body.operations:
        _raise_lowering_error(
            code="DIGITAL_BODY_EMPTY",
            message="Digital declaration body must contain at least one operation.",
            object_path=body.node_id,
            span=body.source_span,
            suggestion="Declare an allowlisted Digital gate or measurement.",
        )
    for operation in body.operations:
        _apply_digital_operation(
            circuit,
            operation,
            parameters=parameter_values,
        )
    if bindings is None:
        return circuit
    return circuit.bind(bindings)  # type: ignore[arg-type]


def _apply_digital_operation(
    circuit: Circuit,
    operation: BodyOperationSyntax,
    *,
    parameters: Mapping[str, Parameter],
) -> None:
    if operation.namespace != "digital":
        _raise_operation_error(
            operation,
            code="DIGITAL_BODY_NAMESPACE_MISMATCH",
            message="Digital blocks may only contain digital.* declarations.",
            suggestion="Replace the operation with an allowlisted digital.* call.",
        )
    if operation.name not in _DIGITAL_OPERATIONS:
        _raise_operation_error(
            operation,
            code="DIGITAL_BODY_OPERATION_UNSUPPORTED",
            message=f"Digital operation '{operation.name}' is not supported.",
            suggestion=(
                "Use h, x, rx, ry, rz, cx, cz, or terminal measure."
            ),
        )
    if operation.name in _DIGITAL_ONE_QUBIT:
        _require_shape(operation, argument_count=1, keyword_names=())
        qubit = _qubit(operation.arguments[0], operation=operation)
        if operation.name == "h":
            circuit.h(qubit)
        else:
            circuit.x(qubit)
        return
    if operation.name in _DIGITAL_ROTATIONS:
        _require_shape(operation, argument_count=2, keyword_names=())
        theta = _digital_expression(
            operation.arguments[0],
            parameters=parameters,
            operation=operation,
        )
        qubit = _qubit(operation.arguments[1], operation=operation)
        if operation.name == "rx":
            circuit.rx(theta, qubit)
        elif operation.name == "ry":
            circuit.ry(theta, qubit)
        else:
            circuit.rz(theta, qubit)
        return
    if operation.name in _DIGITAL_TWO_QUBIT:
        _require_shape(operation, argument_count=2, keyword_names=())
        control = _qubit(operation.arguments[0], operation=operation)
        target = _qubit(operation.arguments[1], operation=operation)
        if operation.name == "cx":
            circuit.cx(control, target)
        else:
            circuit.cz(control, target)
        return
    _apply_digital_measurement(circuit, operation)


def _lower_analog(
    definition: BlockDefinition,
    *,
    bindings: dict[str, object] | None,
    register: AtomRegister | None,
) -> AHSProgram:
    body = definition.body_declaration
    assert body is not None
    if register is None:
        _raise_lowering_error(
            code="ANALOG_BODY_REGISTER_REQUIRED",
            message="Analog body lowering requires an AtomRegister.",
            object_path=f"{body.node_id}.register",
            span=body.source_span,
            suggestion="Pass register=AtomRegister.line(...) to lower().",
        )
    if not isinstance(register, AtomRegister):
        _raise_lowering_error(
            code="ANALOG_BODY_REGISTER_INVALID",
            message="Analog body register must be AtomRegister.",
            object_path=f"{body.node_id}.register",
            span=body.source_span,
            suggestion="Pass a cascaqit.analog.AtomRegister value.",
        )
    expected_atoms = sum(
        resource.resource_kind == "atom"
        for resource in definition.declaration.logical_resources
    )
    active_atom_count = len(register.to_ir().active_sites)
    if active_atom_count != expected_atoms:
        _raise_lowering_error(
            code="ANALOG_BODY_REGISTER_SIZE_MISMATCH",
            message=(
                f"Analog block declares {expected_atoms} atoms but register has "
                f"{active_atom_count} active atoms."
            ),
            object_path=f"{body.node_id}.register",
            span=body.source_span,
            suggestion="Use one active target atom per declared logical atom.",
        )
    program = AHSProgram(
        register,
        program_id=f"program.decorator.{definition.declaration.name}",
    )
    parameter_values: dict[str, Parameter] = {}
    specs = definition.parameter_specs
    for parameter in definition.declaration.parameters:
        unit = "rad/us" if parameter.unit is None else parameter.unit
        if parameter.dtype != "float" or unit not in {"rad/us", "rad"}:
            _raise_lowering_error(
                code="ANALOG_BODY_PARAMETER_TYPE_UNSUPPORTED",
                message=(
                    f"Analog parameter '{parameter.name}' must be float with "
                    "unit 'rad/us' or 'rad'."
                ),
                object_path=f"{body.node_id}.parameters.{parameter.name}",
                span=parameter.source_span,
                suggestion="Declare a float parameter with a supported Analog unit.",
            )
        spec = specs.get(parameter.name)
        parameter_values[parameter.name] = program.parameter(
            parameter.name,
            unit=unit,
            default=_optional_float(
                parameter.default,
                object_path=f"{body.node_id}.parameters.{parameter.name}.default",
                span=parameter.source_span,
                code_prefix="ANALOG_BODY",
            ),
            lower_bound=None if spec is None else spec.lower_bound,
            upper_bound=None if spec is None else spec.upper_bound,
        )
    _apply_analog_operations(program, body.operations, parameters=parameter_values)
    if bindings is None:
        return program
    return program.bind(bindings)  # type: ignore[arg-type]


def _apply_analog_operations(
    program: AHSProgram,
    operations: tuple[BodyOperationSyntax, ...],
    *,
    parameters: Mapping[str, Parameter],
) -> None:
    drive_seen = False
    for operation in operations:
        if operation.namespace != "analog":
            _raise_operation_error(
                operation,
                code="ANALOG_BODY_NAMESPACE_MISMATCH",
                message="Analog blocks may only contain analog.* declarations.",
                suggestion="Use analog.drive for the block control declaration.",
            )
        if operation.name == "drive":
            if drive_seen:
                _raise_operation_error(
                    operation,
                    code="ANALOG_BODY_DRIVE_DUPLICATE",
                    message="Analog body may declare exactly one global drive.",
                    suggestion="Combine the waveform declarations into one drive.",
                )
            _apply_analog_drive(program, operation, parameters=parameters)
            drive_seen = True
            continue
        _raise_operation_error(
            operation,
            code="ANALOG_BODY_OPERATION_UNSUPPORTED",
            message=f"Analog operation '{operation.name}' is not supported.",
            suggestion=(
                "Use one global drive; declare terminal measurement on the "
                "owning Hybrid program."
            ),
        )
    body_span = operations[0].source_span if operations else None
    if not drive_seen:
        _raise_lowering_error(
            code="ANALOG_BODY_DRIVE_MISSING",
            message="Analog body must declare one global drive.",
            object_path="analog.body.drive",
            span=body_span,
            suggestion="Add analog.drive with rabi, detuning, and phase.",
        )


def _apply_analog_drive(
    program: AHSProgram,
    operation: BodyOperationSyntax,
    *,
    parameters: Mapping[str, Parameter],
) -> None:
    _require_exact_keywords(
        operation,
        required=("detuning", "phase", "rabi"),
        code="ANALOG_BODY_DRIVE_SIGNATURE_INVALID",
    )
    keyword_map = {item.name: item.value for item in operation.keywords}
    rabi = _analog_waveform(
        keyword_map["rabi"],
        parameters=parameters,
        operation=operation,
        role="rabi",
        default_unit="rad/us",
    )
    detuning = _analog_waveform(
        keyword_map["detuning"],
        parameters=parameters,
        operation=operation,
        role="detuning",
        default_unit="rad/us",
    )
    phase_value = keyword_map["phase"]
    if phase_value.value_kind == "call":
        phase: int | float | Parameter | Expression | Waveform
        phase = _analog_waveform(
            phase_value,
            parameters=parameters,
            operation=operation,
            role="phase",
            default_unit="rad",
        )
    else:
        phase = _analog_expression(
            phase_value,
            parameters=parameters,
            operation=operation,
        )
    try:
        program.drive(rabi=rabi, detuning=detuning, phase=phase)
    except BodyLoweringError:
        raise
    except (TypeError, ValueError) as exc:
        _raise_operation_error(
            operation,
            code="ANALOG_BODY_DRIVE_INVALID",
            message=f"Analog drive declaration is invalid: {exc}",
            suggestion="Check waveform/phase units and parameter ownership.",
        )


def _analog_waveform(
    value: BodyValueSyntax,
    *,
    parameters: Mapping[str, Parameter],
    operation: BodyOperationSyntax,
    role: str,
    default_unit: str,
) -> Waveform:
    if (
        value.value_kind != "call"
        or value.namespace != "analog"
        or value.call_name
        not in {
            "constant",
            "linear",
            "piecewise_constant",
            "piecewise_linear",
            "interpolated",
        }
    ):
        _raise_value_error(
            value,
            operation=operation,
            code="ANALOG_BODY_WAVEFORM_REQUIRED",
            message=f"Analog drive '{role}' must be an analog waveform declaration.",
            suggestion="Use analog.constant, linear, piecewise_*, or interpolated.",
        )
    keyword_map = {item.name: item.value for item in value.keywords}
    waveform_id = _optional_string_literal(
        keyword_map.pop("waveform_id", None),
        default=f"{operation.node_id}.{role}",
        operation=operation,
        code="ANALOG_BODY_WAVEFORM_ID_INVALID",
    )
    value_unit = _optional_string_literal(
        keyword_map.pop("value_unit", None),
        default=default_unit,
        operation=operation,
        code="ANALOG_BODY_WAVEFORM_UNIT_INVALID",
    )
    if value.call_name == "constant":
        if len(value.items) != 1 or set(keyword_map) != {"duration"}:
            _raise_waveform_signature(value, operation=operation)
        return _build_analog_waveform(
            lambda: Waveform.constant(
                _analog_expression(
                    value.items[0], parameters=parameters, operation=operation
                ),
                duration=_finite_literal(
                    keyword_map["duration"],
                    operation=operation,
                    label="duration",
                ),
                waveform_id=waveform_id,
                value_unit=value_unit,
            ),
            value=value,
            operation=operation,
        )
    if value.call_name == "linear":
        if len(value.items) != 2 or set(keyword_map) != {"duration"}:
            _raise_waveform_signature(value, operation=operation)
        return _build_analog_waveform(
            lambda: Waveform.linear(
                _analog_expression(
                    value.items[0], parameters=parameters, operation=operation
                ),
                _analog_expression(
                    value.items[1], parameters=parameters, operation=operation
                ),
                duration=_finite_literal(
                    keyword_map["duration"],
                    operation=operation,
                    label="duration",
                ),
                waveform_id=waveform_id,
                value_unit=value_unit,
            ),
            value=value,
            operation=operation,
        )
    times_value, values_value = _piecewise_arguments(
        value,
        keyword_map=keyword_map,
        operation=operation,
    )
    times = _finite_literal_sequence(
        times_value, operation=operation, label="times"
    )
    values = tuple(
        _analog_expression(item, parameters=parameters, operation=operation)
        for item in _sequence_items(
            values_value, operation=operation, label="values"
        )
    )
    if value.call_name == "piecewise_constant":
        constructor = Waveform.piecewise_constant
    elif value.call_name == "piecewise_linear":
        constructor = Waveform.piecewise_linear
    else:
        constructor = Waveform.interpolated
    return _build_analog_waveform(
        lambda: constructor(
            times=times,
            values=values,
            waveform_id=waveform_id,
            value_unit=value_unit,
        ),
        value=value,
        operation=operation,
    )


def _build_analog_waveform(
    factory: Callable[[], Waveform],
    *,
    value: BodyValueSyntax,
    operation: BodyOperationSyntax,
) -> Waveform:
    try:
        return factory()
    except BodyLoweringError:
        raise
    except (TypeError, ValueError) as exc:
        _raise_value_error(
            value,
            operation=operation,
            code="ANALOG_BODY_WAVEFORM_INVALID",
            message=f"Analog waveform declaration is invalid: {exc}",
            suggestion="Check waveform values, units, duration, times, and ids.",
        )


def _piecewise_arguments(
    value: BodyValueSyntax,
    *,
    keyword_map: dict[str, BodyValueSyntax],
    operation: BodyOperationSyntax,
) -> tuple[BodyValueSyntax, BodyValueSyntax]:
    if len(value.items) == 2 and not keyword_map:
        return value.items[0], value.items[1]
    if not value.items and set(keyword_map) == {"times", "values"}:
        return keyword_map["times"], keyword_map["values"]
    _raise_waveform_signature(value, operation=operation)


def _analog_expression(
    value: BodyValueSyntax,
    *,
    parameters: Mapping[str, Parameter],
    operation: BodyOperationSyntax,
) -> AnalogScalarExpression:
    if value.value_kind == "literal":
        scalar = value.value
        if isinstance(scalar, bool) or not isinstance(scalar, (int, float)):
            _raise_value_error(
                value,
                operation=operation,
                code="ANALOG_BODY_SCALAR_INVALID",
                message="Analog control values must be finite real literals.",
                suggestion="Use an int, float, or declared float parameter.",
            )
        if not math.isfinite(float(scalar)):
            _raise_value_error(
                value,
                operation=operation,
                code="ANALOG_BODY_SCALAR_NON_FINITE",
                message="Analog control values must be finite.",
                suggestion="Use a finite int or float literal.",
            )
        return scalar
    if value.value_kind == "name":
        assert isinstance(value.value, str)
        parameter = parameters.get(value.value)
        if parameter is None:
            _raise_value_error(
                value,
                operation=operation,
                code="ANALOG_BODY_NAME_UNRESOLVED",
                message=f"Name '{value.value}' is not a declared block parameter.",
                suggestion="Use a function parameter or finite numeric literal.",
            )
        return parameter
    if value.value_kind == "unary":
        operand = _analog_expression(
            value.items[0], parameters=parameters, operation=operation
        )
        return +operand if value.operator == "+" else -operand
    if value.value_kind == "binary":
        left = _analog_expression(
            value.items[0], parameters=parameters, operation=operation
        )
        right = _analog_expression(
            value.items[1], parameters=parameters, operation=operation
        )
        try:
            if value.operator == "+":
                return left + right
            if value.operator == "-":
                return left - right
            if value.operator == "*":
                return left * right
            return left / right
        except (ArithmeticError, TypeError, ValueError) as exc:
            _raise_value_error(
                value,
                operation=operation,
                code="ANALOG_BODY_EXPRESSION_INVALID",
                message=f"Analog expression violates unit rules: {exc}",
                suggestion="Use same-unit +/- or dimensioned-value/scalar * and /.",
            )
    _raise_value_error(
        value,
        operation=operation,
        code="ANALOG_BODY_EXPRESSION_UNSUPPORTED",
        message=f"Analog expression kind '{value.value_kind}' is not supported.",
        suggestion="Use a scalar parameter, literal, or safe arithmetic expression.",
    )


def _require_exact_keywords(
    operation: BodyOperationSyntax,
    *,
    required: tuple[str, ...],
    code: str,
) -> None:
    actual = tuple(item.name for item in operation.keywords)
    if operation.arguments or set(actual) != set(required):
        _raise_operation_error(
            operation,
            code=code,
            message=f"Analog operation '{operation.name}' has invalid arguments.",
            suggestion="Pass each required keyword exactly once.",
        )


def _raise_waveform_signature(
    value: BodyValueSyntax,
    *,
    operation: BodyOperationSyntax,
) -> NoReturn:
    _raise_value_error(
        value,
        operation=operation,
        code="ANALOG_BODY_WAVEFORM_SIGNATURE_INVALID",
        message=f"Analog waveform '{value.call_name}' has invalid arguments.",
        suggestion="Use the documented waveform arguments and keywords.",
    )


def _optional_string_literal(
    value: BodyValueSyntax | None,
    *,
    default: str,
    operation: BodyOperationSyntax,
    code: str,
) -> str:
    if value is None:
        return default
    if value.value_kind != "literal" or not isinstance(value.value, str):
        _raise_value_error(
            value,
            operation=operation,
            code=code,
            message="Analog declaration metadata must be a string literal.",
            suggestion="Use a non-empty string literal.",
        )
    if not value.value:
        _raise_value_error(
            value,
            operation=operation,
            code=code,
            message="Analog declaration metadata must not be empty.",
            suggestion="Use a non-empty string literal.",
        )
    return value.value


def _finite_literal(
    value: BodyValueSyntax,
    *,
    operation: BodyOperationSyntax,
    label: str,
) -> float:
    if (
        value.value_kind != "literal"
        or isinstance(value.value, bool)
        or not isinstance(value.value, (int, float))
        or not math.isfinite(float(value.value))
    ):
        _raise_value_error(
            value,
            operation=operation,
            code="ANALOG_BODY_TIMING_LITERAL_REQUIRED",
            message=f"Analog waveform {label} must use finite numeric literals.",
            suggestion="Keep duration and times fully numeric in a11.",
        )
    return float(value.value)


def _sequence_items(
    value: BodyValueSyntax,
    *,
    operation: BodyOperationSyntax,
    label: str,
) -> tuple[BodyValueSyntax, ...]:
    if value.value_kind != "sequence":
        _raise_value_error(
            value,
            operation=operation,
            code="ANALOG_BODY_SEQUENCE_REQUIRED",
            message=f"Analog waveform {label} must be a list or tuple.",
            suggestion="Pass a static list or tuple declaration.",
        )
    return value.items


def _finite_literal_sequence(
    value: BodyValueSyntax,
    *,
    operation: BodyOperationSyntax,
    label: str,
) -> tuple[float, ...]:
    return tuple(
        _finite_literal(item, operation=operation, label=label)
        for item in _sequence_items(value, operation=operation, label=label)
    )


def _apply_digital_measurement(
    circuit: Circuit,
    operation: BodyOperationSyntax,
) -> None:
    _require_shape(operation, argument_count=1, keyword_names=("key",))
    target_value = operation.arguments[0]
    if target_value.value_kind == "sequence":
        targets: str | Sequence[str] = tuple(
            _qubit(item, operation=operation) for item in target_value.items
        )
    else:
        targets = _qubit(target_value, operation=operation)
    keyword_map = {item.name: item.value for item in operation.keywords}
    key_value = keyword_map.get("key")
    if key_value is None or (
        key_value.value_kind == "literal" and key_value.value is None
    ):
        circuit.measure(targets)
        return
    if key_value.value_kind != "literal" or not isinstance(key_value.value, str):
        _raise_operation_error(
            operation,
            code="DIGITAL_BODY_MEASUREMENT_KEY_INVALID",
            message="Digital measurement key must be a string literal or None.",
            suggestion="Pass key='m' or omit key.",
        )
    circuit.measure(targets, key=key_value.value)


def _digital_expression(
    value: BodyValueSyntax,
    *,
    parameters: Mapping[str, Parameter],
    operation: BodyOperationSyntax,
) -> DigitalScalarExpression:
    if value.value_kind == "literal":
        scalar = value.value
        if isinstance(scalar, bool) or not isinstance(scalar, (int, float)):
            _raise_value_error(
                value,
                operation=operation,
                code="DIGITAL_BODY_SCALAR_INVALID",
                message="Digital gate scalars must be finite real literals.",
                suggestion="Use an int, float, or declared float parameter.",
            )
        if not math.isfinite(float(scalar)):
            _raise_value_error(
                value,
                operation=operation,
                code="DIGITAL_BODY_SCALAR_NON_FINITE",
                message="Digital gate scalars must be finite.",
                suggestion="Use a finite int or float literal.",
            )
        return scalar
    if value.value_kind == "name":
        assert isinstance(value.value, str)
        parameter = parameters.get(value.value)
        if parameter is None:
            _raise_value_error(
                value,
                operation=operation,
                code="DIGITAL_BODY_NAME_UNRESOLVED",
                message=f"Name '{value.value}' is not a declared block parameter.",
                suggestion="Use a function parameter or finite numeric literal.",
            )
        assert parameter is not None
        return parameter
    if value.value_kind == "unary":
        operand = _digital_expression(
            value.items[0], parameters=parameters, operation=operation
        )
        return +operand if value.operator == "+" else -operand
    if value.value_kind == "binary":
        left = _digital_expression(
            value.items[0], parameters=parameters, operation=operation
        )
        right = _digital_expression(
            value.items[1], parameters=parameters, operation=operation
        )
        if value.operator == "+":
            return left + right
        if value.operator == "-":
            return left - right
        if value.operator == "*":
            return left * right
        return left / right
    _raise_value_error(
        value,
        operation=operation,
        code="DIGITAL_BODY_EXPRESSION_UNSUPPORTED",
        message=f"Digital expression kind '{value.value_kind}' is not supported.",
        suggestion="Use a scalar parameter, literal, or safe arithmetic expression.",
    )


def _qubit(value: BodyValueSyntax, *, operation: BodyOperationSyntax) -> str:
    if value.value_kind == "literal" and isinstance(value.value, str):
        return value.value
    _raise_value_error(
        value,
        operation=operation,
        code="DIGITAL_BODY_QUBIT_INVALID",
        message="Digital qubits must be string literal logical ids.",
        suggestion="Use a declared id such as 'q0'.",
    )


def _require_shape(
    operation: BodyOperationSyntax,
    *,
    argument_count: int,
    keyword_names: tuple[str, ...],
) -> None:
    actual_keywords = tuple(item.name for item in operation.keywords)
    unknown_keywords = tuple(
        name for name in actual_keywords if name not in keyword_names
    )
    if len(operation.arguments) != argument_count or unknown_keywords:
        _raise_operation_error(
            operation,
            code="DIGITAL_BODY_OPERATION_SIGNATURE_INVALID",
            message=f"Digital operation '{operation.name}' has invalid arguments.",
            suggestion="Use the documented positional arguments and keywords.",
        )


def _optional_float(
    value: object,
    *,
    object_path: str,
    span: SourceSpan | None,
    code_prefix: str = "DIGITAL_BODY",
) -> float | None:
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        _raise_lowering_error(
            code=f"{code_prefix}_PARAMETER_DEFAULT_INVALID",
            message="Block parameter default must be a finite real number.",
            object_path=object_path,
            span=span,
            suggestion="Use a finite float default.",
        )
    normalized = float(value)
    if not math.isfinite(normalized):
        _raise_lowering_error(
            code=f"{code_prefix}_PARAMETER_DEFAULT_INVALID",
            message="Block parameter default must be finite.",
            object_path=object_path,
            span=span,
            suggestion="Use a finite float default.",
        )
    return normalized


def _raise_operation_error(
    operation: BodyOperationSyntax,
    *,
    code: str,
    message: str,
    suggestion: str,
) -> NoReturn:
    _raise_lowering_error(
        code=code,
        message=message,
        object_path=operation.node_id,
        span=operation.source_span,
        suggestion=suggestion,
    )


def _raise_value_error(
    value: BodyValueSyntax,
    *,
    operation: BodyOperationSyntax,
    code: str,
    message: str,
    suggestion: str,
) -> NoReturn:
    _raise_lowering_error(
        code=code,
        message=message,
        object_path=operation.node_id,
        span=value.source_span or operation.source_span,
        suggestion=suggestion,
    )


def _raise_lowering_error(
    *,
    code: str,
    message: str,
    object_path: str,
    span: SourceSpan | None,
    suggestion: str,
) -> NoReturn:
    digest = hashlib.sha256(
        f"{code}:{object_path}".encode()
    ).hexdigest()[:12]
    raise BodyLoweringError(
        (
            FrontendDiagnosticIR(
                diagnostic_id=f"frontend.lowering.{code.lower()}.{digest}",
                stage="semantic",
                severity="error",
                code=code,
                message=message,
                object_path=object_path,
                source_span=span,
                suggestion=suggestion,
            ),
        )
    )
