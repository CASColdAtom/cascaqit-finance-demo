"""Static, source-aware declarations captured from decorated function bodies."""

from __future__ import annotations

import ast
import hashlib
import inspect
import json
import textwrap
from dataclasses import dataclass
from typing import Any, Literal, Union

from cascaqit.native_ir.base import IRMixin, stable_json
from cascaqit.syntax.diagnostics import FrontendDiagnosticIR
from cascaqit.syntax.source import (
    SYNTAX_SCHEMA_VERSION,
    SourceSpan,
    canonical_source_path,
)

__all__ = [
    "BlockBodySyntax",
    "BodyCaptureResult",
    "BodyKeywordSyntax",
    "BodyLoweringError",
    "BodyOperationSyntax",
    "BodyValueSyntax",
    "capture_block_body",
]

BodyValueKind = Literal[
    "literal",
    "name",
    "sequence",
    "unary",
    "binary",
    "call",
]
BodySequenceKind = Literal["list", "tuple"]
BodyScalar = Union[str, bool, int, float, None]


def _require_text(value: str, *, field_name: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field_name} must be a non-empty string.")


class BodyLoweringError(ValueError):
    """Raised when a captured declaration cannot materialize safely."""

    def __init__(self, diagnostics: tuple[FrontendDiagnosticIR, ...]) -> None:
        if not diagnostics:
            raise ValueError("BodyLoweringError requires at least one diagnostic.")
        self.diagnostics = diagnostics
        super().__init__(diagnostics[0].message)


@dataclass(frozen=True)
class BodyKeywordSyntax(IRMixin):
    """One explicit keyword argument in a body declaration call."""

    name: str
    value: BodyValueSyntax
    schema_version: str = SYNTAX_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_text(self.name, field_name="keyword name")
        if not isinstance(self.value, BodyValueSyntax):
            raise TypeError("keyword value must be BodyValueSyntax.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> BodyKeywordSyntax:
        """Build a keyword declaration from a dictionary."""
        return cls(
            name=str(data["name"]),
            value=BodyValueSyntax.from_dict(data["value"]),
            schema_version=str(data.get("schema_version", SYNTAX_SCHEMA_VERSION)),
        )


@dataclass(frozen=True)
class BodyValueSyntax(IRMixin):
    """One safe structural value captured without evaluating Python."""

    value_kind: BodyValueKind
    value: BodyScalar = None
    operator: str | None = None
    sequence_kind: BodySequenceKind | None = None
    namespace: str | None = None
    call_name: str | None = None
    items: tuple[BodyValueSyntax, ...] = ()
    keywords: tuple[BodyKeywordSyntax, ...] = ()
    source_span: SourceSpan | None = None
    schema_version: str = SYNTAX_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.value_kind not in {
            "literal",
            "name",
            "sequence",
            "unary",
            "binary",
            "call",
        }:
            raise ValueError("invalid body value kind.")
        if any(not isinstance(item, BodyValueSyntax) for item in self.items):
            raise TypeError("items must contain BodyValueSyntax values.")
        if any(
            not isinstance(item, BodyKeywordSyntax) for item in self.keywords
        ):
            raise TypeError("keywords must contain BodyKeywordSyntax values.")
        if self.source_span is not None and not isinstance(
            self.source_span, SourceSpan
        ):
            raise TypeError("source_span must be SourceSpan or None.")
        self._validate_shape()

    def _validate_shape(self) -> None:
        if self.value_kind == "literal":
            if self.operator or self.sequence_kind or self.namespace or self.call_name:
                raise ValueError("literal body values contain only value.")
            if self.items or self.keywords:
                raise ValueError("literal body values cannot contain children.")
            return
        if self.value_kind == "name":
            if not isinstance(self.value, str) or not self.value.strip():
                raise ValueError("name body values require a name.")
            if any((self.operator, self.sequence_kind, self.namespace, self.call_name)):
                raise ValueError("name body values contain only value.")
            if self.items or self.keywords:
                raise ValueError("name body values cannot contain children.")
            return
        if self.value is not None:
            raise ValueError("composite body values cannot contain scalar value.")
        if self.value_kind == "sequence":
            if self.sequence_kind not in {"list", "tuple"}:
                raise ValueError("sequence values require list or tuple kind.")
            if self.operator or self.namespace or self.call_name or self.keywords:
                raise ValueError("sequence body value shape is invalid.")
            return
        if self.value_kind == "unary":
            if self.operator not in {"+", "-"} or len(self.items) != 1:
                raise ValueError("unary values require one item and +/- operator.")
            if self.sequence_kind or self.namespace or self.call_name or self.keywords:
                raise ValueError("unary body value shape is invalid.")
            return
        if self.value_kind == "binary":
            if self.operator not in {"+", "-", "*", "/"} or len(self.items) != 2:
                raise ValueError("binary values require two items and +, -, *, or /.")
            if self.sequence_kind or self.namespace or self.call_name or self.keywords:
                raise ValueError("binary body value shape is invalid.")
            return
        if self.namespace not in {"digital", "analog"}:
            raise ValueError("call namespace must be digital or analog.")
        if self.call_name is None:
            raise ValueError("call values require call_name.")
        _require_text(self.call_name, field_name="call_name")
        if self.operator or self.sequence_kind:
            raise ValueError("call body value shape is invalid.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> BodyValueSyntax:
        """Build a body value from a dictionary."""
        span_data = data.get("source_span")
        return cls(
            value_kind=data["value_kind"],
            value=data.get("value"),
            operator=data.get("operator"),
            sequence_kind=data.get("sequence_kind"),
            namespace=data.get("namespace"),
            call_name=data.get("call_name"),
            items=tuple(cls.from_dict(item) for item in data.get("items", ())),
            keywords=tuple(
                BodyKeywordSyntax.from_dict(item)
                for item in data.get("keywords", ())
            ),
            source_span=(
                None if span_data is None else SourceSpan.from_dict(span_data)
            ),
            schema_version=str(data.get("schema_version", SYNTAX_SCHEMA_VERSION)),
        )


@dataclass(frozen=True)
class BodyOperationSyntax(IRMixin):
    """One ordered top-level declaration operation."""

    node_id: str
    namespace: str
    name: str
    arguments: tuple[BodyValueSyntax, ...] = ()
    keywords: tuple[BodyKeywordSyntax, ...] = ()
    source_span: SourceSpan | None = None
    schema_version: str = SYNTAX_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_text(self.node_id, field_name="node_id")
        if self.namespace not in {"digital", "analog"}:
            raise ValueError("operation namespace must be digital or analog.")
        _require_text(self.name, field_name="operation name")
        if any(
            not isinstance(item, BodyValueSyntax) for item in self.arguments
        ):
            raise TypeError("arguments must contain BodyValueSyntax values.")
        if any(
            not isinstance(item, BodyKeywordSyntax) for item in self.keywords
        ):
            raise TypeError("keywords must contain BodyKeywordSyntax values.")
        names = [item.name for item in self.keywords]
        if len(set(names)) != len(names):
            raise ValueError("operation keyword names must be unique.")
        if self.source_span is not None and not isinstance(
            self.source_span, SourceSpan
        ):
            raise TypeError("source_span must be SourceSpan or None.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> BodyOperationSyntax:
        """Build an operation declaration from a dictionary."""
        span_data = data.get("source_span")
        return cls(
            node_id=str(data["node_id"]),
            namespace=str(data["namespace"]),
            name=str(data["name"]),
            arguments=tuple(
                BodyValueSyntax.from_dict(item)
                for item in data.get("arguments", ())
            ),
            keywords=tuple(
                BodyKeywordSyntax.from_dict(item)
                for item in data.get("keywords", ())
            ),
            source_span=(
                None if span_data is None else SourceSpan.from_dict(span_data)
            ),
            schema_version=str(data.get("schema_version", SYNTAX_SCHEMA_VERSION)),
        )


@dataclass(frozen=True)
class BlockBodySyntax(IRMixin):
    """Immutable declaration body captured from one decorated function."""

    node_id: str
    block_node_id: str
    block_kind: str
    operations: tuple[BodyOperationSyntax, ...] = ()
    source_span: SourceSpan | None = None
    schema_version: str = SYNTAX_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_text(self.node_id, field_name="node_id")
        _require_text(self.block_node_id, field_name="block_node_id")
        if self.block_kind not in {"digital", "analog", "measurement"}:
            raise ValueError("invalid block_kind.")
        if any(
            not isinstance(item, BodyOperationSyntax)
            for item in self.operations
        ):
            raise TypeError("operations must contain BodyOperationSyntax values.")
        node_ids = [item.node_id for item in self.operations]
        if len(set(node_ids)) != len(node_ids):
            raise ValueError("body operation node ids must be unique.")
        if self.source_span is not None and not isinstance(
            self.source_span, SourceSpan
        ):
            raise TypeError("source_span must be SourceSpan or None.")

    def stable_hash(self) -> str:
        """Hash declaration semantics without environment-specific file paths."""
        payload = {
            "node_id": self.node_id,
            "block_node_id": self.block_node_id,
            "block_kind": self.block_kind,
            "operations": [_hashable_operation(item) for item in self.operations],
            "schema_version": self.schema_version,
        }
        return hashlib.sha256(stable_json(payload).encode("utf-8")).hexdigest()

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> BlockBodySyntax:
        """Build a body declaration from a dictionary."""
        span_data = data.get("source_span")
        return cls(
            node_id=str(data["node_id"]),
            block_node_id=str(data["block_node_id"]),
            block_kind=str(data["block_kind"]),
            operations=tuple(
                BodyOperationSyntax.from_dict(item)
                for item in data.get("operations", ())
            ),
            source_span=(
                None if span_data is None else SourceSpan.from_dict(span_data)
            ),
            schema_version=str(data.get("schema_version", SYNTAX_SCHEMA_VERSION)),
        )

    @classmethod
    def from_json(cls, text: str) -> BlockBodySyntax:
        """Build a body declaration from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("BlockBodySyntax JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class BodyCaptureResult(IRMixin):
    """A complete declaration or blocking source diagnostics."""

    body: BlockBodySyntax | None
    diagnostics: tuple[FrontendDiagnosticIR, ...] = ()
    schema_version: str = SYNTAX_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.body is not None and not isinstance(self.body, BlockBodySyntax):
            raise TypeError("body must be BlockBodySyntax or None.")
        if any(
            not isinstance(item, FrontendDiagnosticIR)
            for item in self.diagnostics
        ):
            raise TypeError("diagnostics must contain FrontendDiagnosticIR values.")
        if self.has_errors and self.body is not None:
            raise ValueError("body must be None when capture has errors.")

    @property
    def has_errors(self) -> bool:
        """Return whether capture emitted a blocking diagnostic."""
        return any(item.severity == "error" for item in self.diagnostics)


def capture_block_body(
    function: Any,
    *,
    block_node_id: str,
    block_kind: str,
) -> BodyCaptureResult:
    """Capture one decorated function body without executing Python code."""
    if block_kind == "measurement":
        return _capture_error(
            code="BODY_BLOCK_KIND_UNSUPPORTED",
            message="Measurement block body lowering is not supported.",
            object_path=f"{block_node_id}.body",
            span=None,
            suggestion=(
                "Keep the measurement block body empty and configure terminal "
                "measurement on its Hybrid owner."
            ),
        )
    source_id = f"python.{function.__module__}.{function.__qualname__}"
    try:
        source_lines, start_line = inspect.getsourcelines(function)
        path = inspect.getsourcefile(function)
    except (OSError, TypeError):
        source_lines, start_line, path = [], 0, None
    if path is None or not source_lines:
        return _capture_error(
            code="BODY_SOURCE_UNAVAILABLE",
            message="Decorated function source is unavailable for static lowering.",
            object_path=f"{block_node_id}.body",
            span=SourceSpan.unknown(source_id),
            suggestion="Define the block in a Python module or use the Builder API.",
        )
    path = canonical_source_path(path)
    raw_source = "".join(source_lines)
    indent = _common_space_indent(source_lines)
    try:
        tree = ast.parse(textwrap.dedent(raw_source), filename=path)
    except SyntaxError as exc:
        return _capture_error(
            code="BODY_SOURCE_PARSE_FAILED",
            message=f"Decorated function source could not be parsed: {exc.msg}.",
            object_path=f"{block_node_id}.body",
            span=SourceSpan.unknown(source_id),
            suggestion="Use valid module source or the Builder API.",
        )
    matches = [
        node
        for node in tree.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        and node.name == function.__name__
    ]
    if len(matches) != 1:
        return _capture_error(
            code="BODY_SOURCE_TARGET_AMBIGUOUS",
            message="Decorated source did not contain one matching function.",
            object_path=f"{block_node_id}.body",
            span=SourceSpan.unknown(source_id),
            suggestion="Define one named block per decorated source region.",
        )
    target = matches[0]
    body_span = _node_span(target, path, source_id, start_line, indent)
    if isinstance(target, ast.AsyncFunctionDef):
        return _capture_error(
            code="BODY_ASYNC_UNSUPPORTED",
            message="Async decorated functions cannot use body lowering.",
            object_path=f"{block_node_id}.body",
            span=body_span,
            suggestion="Use a synchronous declaration-only function.",
        )
    diagnostics: list[FrontendDiagnosticIR] = []
    operations: list[BodyOperationSyntax] = []
    for statement in target.body:
        if isinstance(statement, ast.Pass):
            continue
        if not isinstance(statement, ast.Expr) or not isinstance(
            statement.value, ast.Call
        ):
            diagnostics.append(
                _diagnostic(
                    code="BODY_STATEMENT_UNSUPPORTED",
                    message=(
                        f"Statement '{type(statement).__name__}' is not supported "
                        "in declaration bodies."
                    ),
                    object_path=f"{block_node_id}.body",
                    span=_node_span(
                        statement, path, source_id, start_line, indent
                    ),
                    suggestion="Use only allowlisted digital.* or analog.* calls.",
                )
            )
            continue
        operation = _parse_operation(
            statement.value,
            block_node_id=block_node_id,
            operation_index=len(operations),
            path=path,
            source_id=source_id,
            start_line=start_line,
            indent=indent,
            diagnostics=diagnostics,
        )
        if operation is not None:
            operations.append(operation)
    if diagnostics:
        return BodyCaptureResult(body=None, diagnostics=tuple(diagnostics))
    return BodyCaptureResult(
        body=BlockBodySyntax(
            node_id=f"{block_node_id}.body",
            block_node_id=block_node_id,
            block_kind=block_kind,
            operations=tuple(operations),
            source_span=body_span,
        )
    )


def _parse_operation(
    call: ast.Call,
    *,
    block_node_id: str,
    operation_index: int,
    path: str,
    source_id: str,
    start_line: int,
    indent: int,
    diagnostics: list[FrontendDiagnosticIR],
) -> BodyOperationSyntax | None:
    callee = _call_target(call.func)
    span = _node_span(call, path, source_id, start_line, indent)
    if callee is None:
        diagnostics.append(
            _diagnostic(
                code="BODY_CALL_TARGET_UNSUPPORTED",
                message="Declaration calls must use digital.* or analog.*.",
                object_path=f"{block_node_id}.body",
                span=span,
                suggestion="Call an operation through the canonical namespace.",
            )
        )
        return None
    namespace, name = callee
    arguments = [
        _parse_value(
            value,
            path=path,
            source_id=source_id,
            start_line=start_line,
            indent=indent,
            object_path=f"{block_node_id}.body.{operation_index}.arguments",
            diagnostics=diagnostics,
        )
        for value in call.args
    ]
    keyword_values: list[BodyKeywordSyntax] = []
    for keyword in call.keywords:
        if keyword.arg is None:
            diagnostics.append(
                _diagnostic(
                    code="BODY_KEYWORD_UNPACK_UNSUPPORTED",
                    message="Keyword unpacking is not supported in declaration calls.",
                    object_path=f"{block_node_id}.body.{operation_index}.keywords",
                    span=_node_span(
                        keyword.value, path, source_id, start_line, indent
                    ),
                    suggestion="Pass each keyword explicitly.",
                )
            )
            continue
        parsed = _parse_value(
            keyword.value,
            path=path,
            source_id=source_id,
            start_line=start_line,
            indent=indent,
            object_path=(
                f"{block_node_id}.body.{operation_index}.keywords.{keyword.arg}"
            ),
            diagnostics=diagnostics,
        )
        if parsed is not None:
            keyword_values.append(BodyKeywordSyntax(keyword.arg, parsed))
    if any(value is None for value in arguments):
        return None
    return BodyOperationSyntax(
        node_id=f"{block_node_id}.body.operation.{operation_index}.{name}",
        namespace=namespace,
        name=name,
        arguments=tuple(value for value in arguments if value is not None),
        keywords=tuple(sorted(keyword_values, key=lambda item: item.name)),
        source_span=span,
    )


def _parse_value(
    node: ast.expr,
    *,
    path: str,
    source_id: str,
    start_line: int,
    indent: int,
    object_path: str,
    diagnostics: list[FrontendDiagnosticIR],
) -> BodyValueSyntax | None:
    span = _node_span(node, path, source_id, start_line, indent)
    if isinstance(node, ast.Constant) and (
        node.value is None
        or isinstance(node.value, (str, bool, int, float))
    ):
        return BodyValueSyntax(
            value_kind="literal", value=node.value, source_span=span
        )
    if isinstance(node, ast.Name):
        return BodyValueSyntax(
            value_kind="name", value=node.id, source_span=span
        )
    if isinstance(node, (ast.List, ast.Tuple)):
        items = [
            _parse_value(
                item,
                path=path,
                source_id=source_id,
                start_line=start_line,
                indent=indent,
                object_path=object_path,
                diagnostics=diagnostics,
            )
            for item in node.elts
        ]
        if any(item is None for item in items):
            return None
        return BodyValueSyntax(
            value_kind="sequence",
            sequence_kind="list" if isinstance(node, ast.List) else "tuple",
            items=tuple(item for item in items if item is not None),
            source_span=span,
        )
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
        operand = _parse_value(
            node.operand,
            path=path,
            source_id=source_id,
            start_line=start_line,
            indent=indent,
            object_path=object_path,
            diagnostics=diagnostics,
        )
        if operand is None:
            return None
        return BodyValueSyntax(
            value_kind="unary",
            operator="+" if isinstance(node.op, ast.UAdd) else "-",
            items=(operand,),
            source_span=span,
        )
    binary_operators: dict[type[ast.operator], str] = {
        ast.Add: "+",
        ast.Sub: "-",
        ast.Mult: "*",
        ast.Div: "/",
    }
    if isinstance(node, ast.BinOp) and type(node.op) in binary_operators:
        values = [
            _parse_value(
                item,
                path=path,
                source_id=source_id,
                start_line=start_line,
                indent=indent,
                object_path=object_path,
                diagnostics=diagnostics,
            )
            for item in (node.left, node.right)
        ]
        if any(item is None for item in values):
            return None
        return BodyValueSyntax(
            value_kind="binary",
            operator=binary_operators[type(node.op)],
            items=tuple(item for item in values if item is not None),
            source_span=span,
        )
    if isinstance(node, ast.Call):
        callee = _call_target(node.func)
        if callee is not None:
            namespace, call_name = callee
            arguments = [
                _parse_value(
                    item,
                    path=path,
                    source_id=source_id,
                    start_line=start_line,
                    indent=indent,
                    object_path=object_path,
                    diagnostics=diagnostics,
                )
                for item in node.args
            ]
            keywords: list[BodyKeywordSyntax] = []
            for keyword in node.keywords:
                if keyword.arg is None:
                    diagnostics.append(
                        _diagnostic(
                            code="BODY_KEYWORD_UNPACK_UNSUPPORTED",
                            message="Keyword unpacking is not supported.",
                            object_path=object_path,
                            span=span,
                            suggestion="Pass each keyword explicitly.",
                        )
                    )
                    continue
                parsed = _parse_value(
                    keyword.value,
                    path=path,
                    source_id=source_id,
                    start_line=start_line,
                    indent=indent,
                    object_path=f"{object_path}.{keyword.arg}",
                    diagnostics=diagnostics,
                )
                if parsed is not None:
                    keywords.append(BodyKeywordSyntax(keyword.arg, parsed))
            if not any(item is None for item in arguments):
                return BodyValueSyntax(
                    value_kind="call",
                    namespace=namespace,
                    call_name=call_name,
                    items=tuple(item for item in arguments if item is not None),
                    keywords=tuple(sorted(keywords, key=lambda item: item.name)),
                    source_span=span,
                )
    diagnostics.append(
        _diagnostic(
            code="BODY_EXPRESSION_UNSUPPORTED",
            message=f"Expression '{type(node).__name__}' is not supported.",
            object_path=object_path,
            span=span,
            suggestion="Use parameters, finite literals, safe arithmetic, or lists.",
        )
    )
    return None


def _call_target(node: ast.expr) -> tuple[str, str] | None:
    if not isinstance(node, ast.Attribute) or not isinstance(node.value, ast.Name):
        return None
    if node.value.id not in {"digital", "analog"} or not node.attr.strip():
        return None
    return node.value.id, node.attr


def _node_span(
    node: ast.AST,
    path: str,
    source_id: str,
    start_line: int,
    indent: int,
) -> SourceSpan:
    line = int(getattr(node, "lineno", 1))
    column = int(getattr(node, "col_offset", 0)) + indent
    end_line = int(getattr(node, "end_lineno", line))
    end_column = int(getattr(node, "end_col_offset", column)) + indent
    return SourceSpan(
        source_id=source_id,
        path=path,
        start_line=start_line + line - 1,
        start_column=column,
        end_line=start_line + end_line - 1,
        end_column=end_column,
    )


def _common_space_indent(lines: list[str]) -> int:
    non_empty = [line for line in lines if line.strip()]
    if not non_empty:
        return 0
    return min(len(line) - len(line.lstrip(" ")) for line in non_empty)


def _capture_error(
    *,
    code: str,
    message: str,
    object_path: str,
    span: SourceSpan | None,
    suggestion: str,
) -> BodyCaptureResult:
    return BodyCaptureResult(
        body=None,
        diagnostics=(
            _diagnostic(
                code=code,
                message=message,
                object_path=object_path,
                span=span,
                suggestion=suggestion,
            ),
        ),
    )


def _diagnostic(
    *,
    code: str,
    message: str,
    object_path: str,
    span: SourceSpan | None,
    suggestion: str,
) -> FrontendDiagnosticIR:
    digest = hashlib.sha256(object_path.encode("utf-8")).hexdigest()[:12]
    return FrontendDiagnosticIR(
        diagnostic_id=f"frontend.body.{code.lower()}.{digest}",
        stage="syntax",
        severity="error",
        code=code,
        message=message,
        object_path=object_path,
        source_span=span,
        suggestion=suggestion,
    )


def _hashable_operation(operation: BodyOperationSyntax) -> dict[str, Any]:
    return {
        "node_id": operation.node_id,
        "namespace": operation.namespace,
        "name": operation.name,
        "arguments": [_hashable_value(item) for item in operation.arguments],
        "keywords": [
            {"name": item.name, "value": _hashable_value(item.value)}
            for item in operation.keywords
        ],
    }


def _hashable_value(value: BodyValueSyntax) -> dict[str, Any]:
    return {
        "value_kind": value.value_kind,
        "value": value.value,
        "operator": value.operator,
        "sequence_kind": value.sequence_kind,
        "namespace": value.namespace,
        "call_name": value.call_name,
        "items": [_hashable_value(item) for item in value.items],
        "keywords": [
            {"name": item.name, "value": _hashable_value(item.value)}
            for item in value.keywords
        ],
    }
