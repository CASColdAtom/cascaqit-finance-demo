"""Immutable syntax tree models for the Python hybrid frontend."""

from __future__ import annotations

import json
import math
from dataclasses import dataclass, field
from typing import Any, Literal, Union

from cascaqit.native_ir.base import IRMixin
from cascaqit.syntax.source import SYNTAX_SCHEMA_VERSION, SourceMap, SourceSpan

__all__ = [
    "ArgumentSyntax",
    "BlockInvocationSyntax",
    "BlockSyntax",
    "LogicalResourceSyntax",
    "ParameterSyntax",
    "ProgramSyntaxAST",
]

BlockKind = Literal["digital", "analog", "measurement"]
ParameterDType = Literal["float", "int", "bool"]
ResourceKind = Literal["qubit", "atom", "classical_bit"]
ArgumentValueKind = Literal["literal", "symbol"]
ScalarValue = Union[bool, int, float]


def _require_identifier(value: str, *, field_name: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field_name} must be a non-empty string.")


def _validate_scalar(value: object, *, field_name: str) -> None:
    if isinstance(value, bool):
        return
    if isinstance(value, int):
        return
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError(f"{field_name} must be finite.")
        return
    raise TypeError(f"{field_name} must be bool, int, or float.")


@dataclass(frozen=True)
class ParameterSyntax(IRMixin):
    """A parameter declaration before symbol resolution."""

    node_id: str
    name: str
    dtype: ParameterDType
    unit: str | None = None
    required: bool = True
    default: ScalarValue | None = None
    source_span: SourceSpan | None = None
    schema_version: str = SYNTAX_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_identifier(self.node_id, field_name="node_id")
        _require_identifier(self.name, field_name="name")
        if self.dtype not in {"float", "int", "bool"}:
            raise ValueError("dtype must be float, int, or bool.")
        if self.unit is not None and not str(self.unit).strip():
            raise ValueError("unit must be None or a non-empty string.")
        if self.default is not None:
            _validate_parameter_value(
                self.default,
                dtype=self.dtype,
                field_name="parameter default",
            )
            if self.required:
                raise ValueError(
                    "a parameter with a default must not be marked required."
                )
        _validate_optional_span(self.source_span)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ParameterSyntax:
        """Build a parameter declaration from a dictionary."""
        return cls(
            node_id=str(data["node_id"]),
            name=str(data["name"]),
            dtype=data["dtype"],
            unit=None if data.get("unit") is None else str(data["unit"]),
            required=bool(data.get("required", True)),
            default=data.get("default"),
            source_span=_span_from_data(data.get("source_span")),
            schema_version=str(
                data.get("schema_version", SYNTAX_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class LogicalResourceSyntax(IRMixin):
    """A logical qubit, atom, or classical bit declaration."""

    node_id: str
    logical_id: str
    resource_kind: ResourceKind
    source_span: SourceSpan | None = None
    schema_version: str = SYNTAX_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_identifier(self.node_id, field_name="node_id")
        _require_identifier(self.logical_id, field_name="logical_id")
        if self.resource_kind not in {"qubit", "atom", "classical_bit"}:
            raise ValueError(
                "resource_kind must be qubit, atom, or classical_bit."
            )
        _validate_optional_span(self.source_span)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> LogicalResourceSyntax:
        """Build a logical resource from a dictionary."""
        return cls(
            node_id=str(data["node_id"]),
            logical_id=str(data["logical_id"]),
            resource_kind=data["resource_kind"],
            source_span=_span_from_data(data.get("source_span")),
            schema_version=str(
                data.get("schema_version", SYNTAX_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class ArgumentSyntax(IRMixin):
    """A named invocation argument expressed as a literal or symbol."""

    node_id: str
    name: str
    value_kind: ArgumentValueKind
    value: ScalarValue | str
    unit: str | None = None
    source_span: SourceSpan | None = None
    schema_version: str = SYNTAX_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_identifier(self.node_id, field_name="node_id")
        _require_identifier(self.name, field_name="name")
        if self.value_kind not in {"literal", "symbol"}:
            raise ValueError("value_kind must be literal or symbol.")
        if self.value_kind == "literal":
            _validate_scalar(self.value, field_name="literal argument")
        else:
            if not isinstance(self.value, str) or not self.value.strip():
                raise ValueError("symbol argument must name a non-empty symbol.")
            if self.unit is not None:
                raise ValueError("symbol arguments must not declare a literal unit.")
        if self.unit is not None and not str(self.unit).strip():
            raise ValueError("unit must be None or a non-empty string.")
        _validate_optional_span(self.source_span)

    @classmethod
    def literal(
        cls,
        name: str,
        value: ScalarValue,
        *,
        unit: str | None = None,
        node_id: str | None = None,
        source_span: SourceSpan | None = None,
    ) -> ArgumentSyntax:
        """Create a literal invocation argument."""
        return cls(
            node_id=node_id or f"argument.{name}",
            name=name,
            value_kind="literal",
            value=value,
            unit=unit,
            source_span=source_span,
        )

    @classmethod
    def symbol(
        cls,
        name: str,
        symbol: str,
        *,
        node_id: str | None = None,
        source_span: SourceSpan | None = None,
    ) -> ArgumentSyntax:
        """Create an argument that references a program symbol."""
        return cls(
            node_id=node_id or f"argument.{name}",
            name=name,
            value_kind="symbol",
            value=symbol,
            source_span=source_span,
        )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ArgumentSyntax:
        """Build an invocation argument from a dictionary."""
        return cls(
            node_id=str(data["node_id"]),
            name=str(data["name"]),
            value_kind=data["value_kind"],
            value=data["value"],
            unit=None if data.get("unit") is None else str(data["unit"]),
            source_span=_span_from_data(data.get("source_span")),
            schema_version=str(
                data.get("schema_version", SYNTAX_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class BlockSyntax(IRMixin):
    """A Digital, Analog, or Measurement block declaration."""

    node_id: str
    name: str
    block_kind: BlockKind
    parameters: tuple[ParameterSyntax, ...] = ()
    logical_resources: tuple[LogicalResourceSyntax, ...] = ()
    required_capabilities: tuple[str, ...] = ()
    source_span: SourceSpan | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = SYNTAX_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_identifier(self.node_id, field_name="node_id")
        _require_identifier(self.name, field_name="name")
        if self.block_kind not in {"digital", "analog", "measurement"}:
            raise ValueError(
                "block_kind must be digital, analog, or measurement."
            )
        _validate_unique_items(
            self.parameters,
            value_name="name",
            label="parameter",
            item_type=ParameterSyntax,
        )
        _validate_unique_items(
            self.logical_resources,
            value_name="logical_id",
            label="logical resource",
            item_type=LogicalResourceSyntax,
        )
        _validate_identifiers(
            self.required_capabilities,
            label="required capability",
        )
        _validate_optional_span(self.source_span)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> BlockSyntax:
        """Build a block declaration from a dictionary."""
        return cls(
            node_id=str(data["node_id"]),
            name=str(data["name"]),
            block_kind=data["block_kind"],
            parameters=tuple(
                ParameterSyntax.from_dict(item)
                for item in data.get("parameters", ())
            ),
            logical_resources=tuple(
                LogicalResourceSyntax.from_dict(item)
                for item in data.get("logical_resources", ())
            ),
            required_capabilities=tuple(
                str(item) for item in data.get("required_capabilities", ())
            ),
            source_span=_span_from_data(data.get("source_span")),
            metadata=dict(data.get("metadata", {})),
            schema_version=str(
                data.get("schema_version", SYNTAX_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> BlockSyntax:
        """Build a block declaration from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("BlockSyntax JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class BlockInvocationSyntax(IRMixin):
    """One ordered invocation of a declared block."""

    node_id: str
    block_name: str
    arguments: tuple[ArgumentSyntax, ...] = ()
    mapping: dict[str, str] = field(default_factory=dict)
    source_span: SourceSpan | None = None
    schema_version: str = SYNTAX_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_identifier(self.node_id, field_name="node_id")
        _require_identifier(self.block_name, field_name="block_name")
        _validate_unique_items(
            self.arguments,
            value_name="name",
            label="argument",
            item_type=ArgumentSyntax,
        )
        mapped_targets: set[str] = set()
        for local_id, logical_id in self.mapping.items():
            _require_identifier(local_id, field_name="mapping local id")
            _require_identifier(logical_id, field_name="mapping logical id")
            if logical_id in mapped_targets:
                raise ValueError(
                    f"mapping contains duplicate target '{logical_id}'."
                )
            mapped_targets.add(logical_id)
        _validate_optional_span(self.source_span)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> BlockInvocationSyntax:
        """Build a block invocation from a dictionary."""
        return cls(
            node_id=str(data["node_id"]),
            block_name=str(data["block_name"]),
            arguments=tuple(
                ArgumentSyntax.from_dict(item)
                for item in data.get("arguments", ())
            ),
            mapping={
                str(key): str(value)
                for key, value in data.get("mapping", {}).items()
            },
            source_span=_span_from_data(data.get("source_span")),
            schema_version=str(
                data.get("schema_version", SYNTAX_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class ProgramSyntaxAST(IRMixin):
    """A complete ordered Python frontend syntax tree."""

    node_id: str
    program_id: str
    blocks: tuple[BlockSyntax, ...] = ()
    invocations: tuple[BlockInvocationSyntax, ...] = ()
    source_map: SourceMap = field(default_factory=SourceMap)
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = SYNTAX_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_identifier(self.node_id, field_name="node_id")
        _require_identifier(self.program_id, field_name="program_id")
        for block in self.blocks:
            if not isinstance(block, BlockSyntax):
                raise TypeError("blocks must contain BlockSyntax values.")
        for invocation in self.invocations:
            if not isinstance(invocation, BlockInvocationSyntax):
                raise TypeError(
                    "invocations must contain BlockInvocationSyntax values."
                )
        if not isinstance(self.source_map, SourceMap):
            raise TypeError("source_map must be SourceMap.")
        node_ids = self._all_node_ids()
        duplicate = _first_duplicate(node_ids)
        if duplicate is not None:
            raise ValueError(f"syntax tree contains duplicate node_id '{duplicate}'.")
        known_node_ids = set(node_ids)
        for entry in self.source_map.entries:
            if entry.node_id not in known_node_ids:
                raise ValueError(
                    "source map references unknown node_id "
                    f"'{entry.node_id}'."
                )

    def _all_node_ids(self) -> tuple[str, ...]:
        node_ids = [self.node_id]
        for block in self.blocks:
            node_ids.append(block.node_id)
            node_ids.extend(parameter.node_id for parameter in block.parameters)
            node_ids.extend(
                resource.node_id for resource in block.logical_resources
            )
        for invocation in self.invocations:
            node_ids.append(invocation.node_id)
            node_ids.extend(argument.node_id for argument in invocation.arguments)
        return tuple(node_ids)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ProgramSyntaxAST:
        """Build a syntax tree from a JSON-compatible dictionary."""
        return cls(
            node_id=str(data["node_id"]),
            program_id=str(data["program_id"]),
            blocks=tuple(
                BlockSyntax.from_dict(item) for item in data.get("blocks", ())
            ),
            invocations=tuple(
                BlockInvocationSyntax.from_dict(item)
                for item in data.get("invocations", ())
            ),
            source_map=SourceMap.from_dict(data.get("source_map", {})),
            metadata=dict(data.get("metadata", {})),
            schema_version=str(
                data.get("schema_version", SYNTAX_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> ProgramSyntaxAST:
        """Build a syntax tree from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("ProgramSyntaxAST JSON must contain an object.")
        return cls.from_dict(data)


def _validate_parameter_value(
    value: object,
    *,
    dtype: ParameterDType,
    field_name: str,
) -> None:
    _validate_scalar(value, field_name=field_name)
    valid = (
        (dtype == "bool" and isinstance(value, bool))
        or (dtype == "int" and isinstance(value, int) and not isinstance(value, bool))
        or (
            dtype == "float"
            and isinstance(value, (int, float))
            and not isinstance(value, bool)
        )
    )
    if not valid:
        raise ValueError(f"{field_name} does not match dtype '{dtype}'.")


def _validate_optional_span(span: SourceSpan | None) -> None:
    if span is not None and not isinstance(span, SourceSpan):
        raise TypeError("source_span must be SourceSpan or None.")


def _validate_unique_items(
    items: tuple[Any, ...],
    *,
    value_name: str,
    label: str,
    item_type: type[Any],
) -> None:
    values: set[str] = set()
    for item in items:
        if not isinstance(item, item_type):
            raise TypeError(f"{label} entries must be {item_type.__name__}.")
        value = str(getattr(item, value_name))
        if value in values:
            raise ValueError(f"block contains duplicate {label} '{value}'.")
        values.add(value)


def _validate_identifiers(values: tuple[str, ...], *, label: str) -> None:
    seen: set[str] = set()
    for value in values:
        _require_identifier(value, field_name=label)
        if value in seen:
            raise ValueError(f"duplicate {label} '{value}'.")
        seen.add(value)


def _first_duplicate(values: tuple[str, ...]) -> str | None:
    seen: set[str] = set()
    for value in values:
        if value in seen:
            return value
        seen.add(value)
    return None


def _span_from_data(data: Any) -> SourceSpan | None:
    if data is None:
        return None
    if not isinstance(data, dict):
        raise TypeError("source_span must contain an object.")
    return SourceSpan.from_dict(data)
