"""Structured diagnostics for syntax and semantic frontend stages."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Literal

from cascaqit.native_ir.base import IRMixin
from cascaqit.syntax.source import SYNTAX_SCHEMA_VERSION, SourceSpan

__all__ = ["FrontendDiagnosticIR"]

FrontendDiagnosticStage = Literal["syntax", "semantic"]
FrontendDiagnosticSeverity = Literal["info", "warning", "error"]


@dataclass(frozen=True)
class FrontendDiagnosticIR(IRMixin):
    """A source-aware diagnostic emitted before orchestration or execution."""

    diagnostic_id: str
    stage: FrontendDiagnosticStage
    severity: FrontendDiagnosticSeverity
    code: str
    message: str
    object_path: str | None = None
    source_span: SourceSpan | None = None
    suggestion: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = SYNTAX_SCHEMA_VERSION

    def __post_init__(self) -> None:
        for field_name in ("diagnostic_id", "code", "message"):
            value = getattr(self, field_name)
            if not isinstance(value, str) or not value.strip():
                raise ValueError(f"{field_name} must be a non-empty string.")
        if self.stage not in {"syntax", "semantic"}:
            raise ValueError("stage must be syntax or semantic.")
        if self.severity not in {"info", "warning", "error"}:
            raise ValueError("severity must be info, warning, or error.")
        if self.source_span is not None and not isinstance(
            self.source_span, SourceSpan
        ):
            raise TypeError("source_span must be SourceSpan or None.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> FrontendDiagnosticIR:
        """Build a frontend diagnostic from a dictionary."""
        span_data = data.get("source_span")
        return cls(
            diagnostic_id=str(data["diagnostic_id"]),
            stage=data["stage"],
            severity=data["severity"],
            code=str(data["code"]),
            message=str(data["message"]),
            object_path=data.get("object_path"),
            source_span=None
            if span_data is None
            else SourceSpan.from_dict(span_data),
            suggestion=data.get("suggestion"),
            metadata=dict(data.get("metadata", {})),
            schema_version=str(
                data.get("schema_version", SYNTAX_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> FrontendDiagnosticIR:
        """Build a frontend diagnostic from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("FrontendDiagnosticIR JSON must contain an object.")
        return cls.from_dict(data)
