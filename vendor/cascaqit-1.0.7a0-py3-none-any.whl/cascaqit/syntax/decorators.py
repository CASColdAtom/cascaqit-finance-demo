"""Builder-first Python block decorators for the hybrid syntax frontend."""

from __future__ import annotations

import hashlib
import inspect
import math
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, replace
from typing import TYPE_CHECKING, Any, Literal, Union

from cascaqit.native_ir.base import stable_json
from cascaqit.syntax.ast import (
    ArgumentSyntax,
    BlockInvocationSyntax,
    BlockSyntax,
    LogicalResourceSyntax,
    ParameterSyntax,
)
from cascaqit.syntax.body import BlockBodySyntax, capture_block_body
from cascaqit.syntax.diagnostics import FrontendDiagnosticIR
from cascaqit.syntax.source import SourceSpan, canonical_source_path

if TYPE_CHECKING:
    from cascaqit.analog import AHSProgram, AtomRegister
    from cascaqit.digital import Circuit

__all__ = [
    "BlockDefinition",
    "ParameterSpec",
    "SymbolRef",
    "analog",
    "analog_block",
    "digital",
    "digital_block",
    "measurement_block",
]

DecoratorDType = Literal["float", "int", "bool"]
DecoratorResourceKind = Literal["qubit", "atom", "classical_bit"]
ResourceInput = Union[int, Sequence[str]]


@dataclass(frozen=True)
class ParameterSpec:
    """Optional dtype and unit metadata for one function parameter."""

    dtype: DecoratorDType | None = None
    unit: str | None = None
    lower_bound: float | None = None
    upper_bound: float | None = None

    def __post_init__(self) -> None:
        if self.dtype is not None and self.dtype not in {"float", "int", "bool"}:
            raise ValueError("dtype must be float, int, bool, or None.")
        if self.unit is not None and not self.unit.strip():
            raise ValueError("unit must be None or a non-empty string.")
        for field_name in ("lower_bound", "upper_bound"):
            value = getattr(self, field_name)
            if value is None:
                continue
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise TypeError(f"{field_name} must be a real number or None.")
            normalized = float(value)
            if not math.isfinite(normalized):
                raise ValueError(f"{field_name} must be finite.")
            object.__setattr__(self, field_name, normalized)
        if (
            self.lower_bound is not None
            and self.upper_bound is not None
            and self.lower_bound > self.upper_bound
        ):
            raise ValueError("lower_bound must not exceed upper_bound.")


@dataclass(frozen=True)
class SymbolRef:
    """Reference a typed symbol supplied to semantic analysis."""

    name: str

    def __post_init__(self) -> None:
        if not isinstance(self.name, str) or not self.name.strip():
            raise ValueError("symbol name must be a non-empty string.")


class BlockDefinition:
    """A decorated function declaration that creates syntax invocations."""

    def __init__(
        self,
        function: Callable[..., Any],
        declaration: BlockSyntax,
        signature: inspect.Signature,
        *,
        body_declaration: BlockBodySyntax | None = None,
        body_diagnostics: tuple[FrontendDiagnosticIR, ...] = (),
        parameter_specs: Mapping[str, ParameterSpec] | None = None,
    ) -> None:
        self._function = function
        self._declaration = declaration
        self._signature = signature
        self._body_declaration = body_declaration
        self._body_diagnostics = body_diagnostics
        self._parameter_specs = (
            {} if parameter_specs is None else dict(parameter_specs)
        )

    @property
    def declaration(self) -> BlockSyntax:
        """Return the immutable block declaration syntax."""
        return self._declaration

    @property
    def body_declaration(self) -> BlockBodySyntax | None:
        """Return the captured body declaration when opt-in capture succeeded."""
        return self._body_declaration

    @property
    def body_diagnostics(self) -> tuple[FrontendDiagnosticIR, ...]:
        """Return diagnostics emitted by opt-in body capture."""
        return self._body_diagnostics

    @property
    def parameter_specs(self) -> dict[str, ParameterSpec]:
        """Return a copy of lowering-specific parameter metadata."""
        return dict(self._parameter_specs)

    @property
    def signature(self) -> inspect.Signature:
        """Return the original callable signature without exposing the callable."""
        return self._signature

    def lower(
        self,
        *args: object,
        register: AtomRegister | None = None,
        **kwargs: object,
    ) -> Circuit | AHSProgram:
        """Materialize an opt-in declaration as an existing Native program."""
        from cascaqit.syntax.lowering import lower_block_definition

        return lower_block_definition(
            self,
            args=args,
            kwargs=kwargs,
            register=register,
        )

    @property
    def __name__(self) -> str:
        """Expose the original function name for familiar introspection."""
        return self._function.__name__

    def __call__(
        self,
        *args: object,
        mapping: Mapping[str, str] | None = None,
        **kwargs: object,
    ) -> BlockInvocationSyntax:
        """Create an invocation syntax node without executing the function."""
        bound = self._signature.bind_partial(*args, **kwargs)
        parameters = {
            parameter.name: parameter
            for parameter in self._declaration.parameters
        }
        arguments: list[ArgumentSyntax] = []
        for name in self._signature.parameters:
            if name not in bound.arguments:
                continue
            declaration = parameters[name]
            value = bound.arguments[name]
            argument_node_id = f"argument.{self._declaration.name}.pending.{name}"
            if isinstance(value, SymbolRef):
                arguments.append(
                    ArgumentSyntax.symbol(
                        name,
                        value.name,
                        node_id=argument_node_id,
                        source_span=declaration.source_span,
                    )
                )
            else:
                if not isinstance(value, (bool, int, float)):
                    raise TypeError(
                        f"argument '{name}' must be bool, int, float, or SymbolRef."
                    )
                arguments.append(
                    ArgumentSyntax.literal(
                        name,
                        value,
                        unit=declaration.unit,
                        node_id=argument_node_id,
                        source_span=declaration.source_span,
                    )
                )
        normalized_mapping = (
            {}
            if mapping is None
            else {str(key): str(value) for key, value in mapping.items()}
        )
        digest = hashlib.sha256(
            stable_json(
                {
                    "block_name": self._declaration.name,
                    "arguments": arguments,
                    "mapping": normalized_mapping,
                }
            ).encode("utf-8")
        ).hexdigest()[:12]
        return BlockInvocationSyntax(
            node_id=f"invocation.{self._declaration.name}.{digest}",
            block_name=self._declaration.name,
            arguments=tuple(arguments),
            mapping=normalized_mapping,
            source_span=self._declaration.source_span,
        )


def digital_block(
    *,
    qubits: ResourceInput,
    parameters: Mapping[str, ParameterSpec] | None = None,
    capabilities: Sequence[str] = (),
    name: str | None = None,
    lower_body: bool = False,
) -> Callable[[Callable[..., Any]], BlockDefinition]:
    """Declare a Digital block from a Python function signature."""
    resources = _logical_resources(qubits, resource_kind="qubit")
    return _block_decorator(
        block_kind="digital",
        resources=resources,
        parameters=parameters,
        capabilities=capabilities,
        name=name,
        lower_body=lower_body,
    )


def analog_block(
    *,
    atoms: ResourceInput,
    parameters: Mapping[str, ParameterSpec] | None = None,
    capabilities: Sequence[str] = (),
    name: str | None = None,
    lower_body: bool = False,
) -> Callable[[Callable[..., Any]], BlockDefinition]:
    """Declare an Analog block from a Python function signature."""
    resources = _logical_resources(atoms, resource_kind="atom")
    return _block_decorator(
        block_kind="analog",
        resources=resources,
        parameters=parameters,
        capabilities=capabilities,
        name=name,
        lower_body=lower_body,
    )


def measurement_block(
    *,
    logical_ids: ResourceInput,
    resource_kind: DecoratorResourceKind = "qubit",
    parameters: Mapping[str, ParameterSpec] | None = None,
    capabilities: Sequence[str] = (),
    name: str | None = None,
    lower_body: bool = False,
) -> Callable[[Callable[..., Any]], BlockDefinition]:
    """Declare a terminal Measurement block from a function signature."""
    resources = _logical_resources(logical_ids, resource_kind=resource_kind)
    return _block_decorator(
        block_kind="measurement",
        resources=resources,
        parameters=parameters,
        capabilities=capabilities,
        name=name,
        lower_body=lower_body,
    )


def _block_decorator(
    *,
    block_kind: Literal["digital", "analog", "measurement"],
    resources: tuple[tuple[str, DecoratorResourceKind], ...],
    parameters: Mapping[str, ParameterSpec] | None,
    capabilities: Sequence[str],
    name: str | None,
    lower_body: bool,
) -> Callable[[Callable[..., Any]], BlockDefinition]:
    if not isinstance(lower_body, bool):
        raise TypeError("lower_body must be bool.")
    parameter_specs = {} if parameters is None else dict(parameters)

    def decorate(function: Callable[..., Any]) -> BlockDefinition:
        if not callable(function):
            raise TypeError("block decorator requires a callable.")
        signature = inspect.signature(function)
        if "mapping" in signature.parameters:
            raise ValueError("'mapping' is reserved by block invocation syntax.")
        if lower_body and "register" in signature.parameters:
            raise ValueError("'register' is reserved by body materialization.")
        unknown_specs = set(parameter_specs) - set(signature.parameters)
        if unknown_specs:
            unknown = sorted(unknown_specs)[0]
            raise ValueError(
                f"ParameterSpec references unknown function parameter '{unknown}'."
            )
        block_name = function.__name__ if name is None else name
        if not isinstance(block_name, str) or not block_name.strip():
            raise ValueError("block name must be a non-empty string.")
        span = _function_source_span(function)
        parameter_nodes = tuple(
            _parameter_syntax(
                block_name,
                parameter,
                parameter_specs.get(parameter.name),
                span,
            )
            for parameter in signature.parameters.values()
        )
        resource_nodes = tuple(
            LogicalResourceSyntax(
                node_id=f"resource.{block_name}.{logical_id}",
                logical_id=logical_id,
                resource_kind=resource_kind,
                source_span=span,
            )
            for logical_id, resource_kind in resources
        )
        declaration = BlockSyntax(
            node_id=f"block.{block_name}",
            name=block_name,
            block_kind=block_kind,
            parameters=parameter_nodes,
            logical_resources=resource_nodes,
            required_capabilities=tuple(capabilities),
            source_span=span,
            metadata={
                "python_module": function.__module__,
                "python_qualname": function.__qualname__,
                "function_body_executed": False,
                "body_capture_requested": lower_body,
                "body_capture_status": "not_requested",
            },
        )
        body_declaration = None
        body_diagnostics: tuple[FrontendDiagnosticIR, ...] = ()
        if lower_body:
            capture = capture_block_body(
                function,
                block_node_id=declaration.node_id,
                block_kind=block_kind,
            )
            body_declaration = capture.body
            body_diagnostics = capture.diagnostics
            metadata = dict(declaration.metadata)
            metadata["body_capture_status"] = (
                "captured" if body_declaration is not None else "blocked"
            )
            if body_declaration is not None:
                metadata["body_declaration_hash"] = body_declaration.stable_hash()
            declaration = replace(declaration, metadata=metadata)
        return BlockDefinition(
            function,
            declaration,
            signature,
            body_declaration=body_declaration,
            body_diagnostics=body_diagnostics,
            parameter_specs=parameter_specs,
        )

    return decorate


class _DeclarationNamespace:
    """Marker namespace valid only inside statically captured declarations."""

    def __init__(self, name: str) -> None:
        self._name = name

    def __getattr__(self, operation: str) -> Callable[..., None]:
        if not operation or operation.startswith("_"):
            raise AttributeError(operation)

        def declaration_only(*args: object, **kwargs: object) -> None:
            del args, kwargs
            raise RuntimeError(
                f"{self._name}.{operation} is declaration-only and cannot execute."
            )

        return declaration_only


digital = _DeclarationNamespace("digital")
analog = _DeclarationNamespace("analog")


def _parameter_syntax(
    block_name: str,
    parameter: inspect.Parameter,
    spec: ParameterSpec | None,
    span: SourceSpan,
) -> ParameterSyntax:
    if parameter.kind in {
        inspect.Parameter.VAR_POSITIONAL,
        inspect.Parameter.VAR_KEYWORD,
    }:
        raise ValueError("variadic block parameters are not supported.")
    annotation_dtype = _annotation_dtype(parameter.annotation)
    spec_dtype = None if spec is None else spec.dtype
    if (
        annotation_dtype is not None
        and spec_dtype is not None
        and annotation_dtype != spec_dtype
    ):
        raise ValueError(
            f"ParameterSpec dtype '{spec_dtype}' disagrees with annotation "
            f"'{annotation_dtype}' for parameter '{parameter.name}'."
        )
    dtype = spec_dtype or annotation_dtype
    if dtype is None:
        raise ValueError(
            f"parameter '{parameter.name}' requires a supported dtype annotation "
            "or ParameterSpec dtype."
        )
    default: object | None = None
    required = parameter.default is inspect.Parameter.empty
    if not required:
        default = parameter.default
    return ParameterSyntax(
        node_id=f"parameter.{block_name}.{parameter.name}",
        name=parameter.name,
        dtype=dtype,
        unit=None if spec is None else spec.unit,
        required=required,
        default=default,  # type: ignore[arg-type]
        source_span=span,
    )


def _annotation_dtype(annotation: object) -> DecoratorDType | None:
    if annotation is inspect.Parameter.empty:
        return None
    if annotation is float or annotation == "float":
        return "float"
    if annotation is int or annotation == "int":
        return "int"
    if annotation is bool or annotation == "bool":
        return "bool"
    raise ValueError(
        "parameter dtype annotation must be float, int, or bool."
    )


def _logical_resources(
    value: ResourceInput,
    *,
    resource_kind: DecoratorResourceKind,
) -> tuple[tuple[str, DecoratorResourceKind], ...]:
    if isinstance(value, int):
        if value <= 0:
            raise ValueError("logical resource count must be positive.")
        logical_ids = tuple(f"q{index}" for index in range(value))
    else:
        if isinstance(value, (str, bytes)):
            raise TypeError("logical resources must be a count or a sequence of ids.")
        logical_ids = tuple(str(item) for item in value)
        if not logical_ids:
            raise ValueError("logical resources must not be empty.")
    if len(set(logical_ids)) != len(logical_ids):
        raise ValueError("logical resource ids must be unique.")
    if any(not item.strip() for item in logical_ids):
        raise ValueError("logical resource ids must be non-empty strings.")
    return tuple((item, resource_kind) for item in logical_ids)


def _function_source_span(function: Callable[..., Any]) -> SourceSpan:
    source_id = f"python.{function.__module__}.{function.__qualname__}"
    try:
        path = inspect.getsourcefile(function)
        lines, start_line = inspect.getsourcelines(function)
    except (OSError, TypeError):
        return SourceSpan.unknown(source_id)
    if path is None or not lines:
        return SourceSpan.unknown(source_id)
    end_line = start_line + len(lines) - 1
    end_column = len(lines[-1].rstrip("\r\n"))
    return SourceSpan(
        source_id=source_id,
        path=canonical_source_path(path),
        start_line=start_line,
        start_column=0,
        end_line=end_line,
        end_column=end_column,
    )
