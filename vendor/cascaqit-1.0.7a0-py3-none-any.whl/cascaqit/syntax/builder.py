"""Program-level assembly helpers for decorated block syntax."""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import replace
from typing import Union

from cascaqit.syntax.ast import (
    BlockInvocationSyntax,
    BlockSyntax,
    ProgramSyntaxAST,
)
from cascaqit.syntax.decorators import BlockDefinition
from cascaqit.syntax.source import SourceMap, SourceMapEntry, SourceSpan

__all__ = ["program_syntax"]

BlockInput = Union[BlockDefinition, BlockSyntax]


def program_syntax(
    program_id: str,
    *,
    blocks: Sequence[BlockInput],
    invocations: Sequence[BlockInvocationSyntax],
) -> ProgramSyntaxAST:
    """Assemble decorated declarations and invocations into a stable AST."""
    if not isinstance(program_id, str) or not program_id.strip():
        raise ValueError("program_id must be a non-empty string.")
    declarations = tuple(_declaration(item) for item in blocks)
    block_names: set[str] = set()
    for declaration in declarations:
        if declaration.name in block_names:
            raise ValueError(f"duplicate block name '{declaration.name}'.")
        block_names.add(declaration.name)
    normalized_invocations: list[BlockInvocationSyntax] = []
    for index, invocation in enumerate(invocations):
        if not isinstance(invocation, BlockInvocationSyntax):
            raise TypeError("invocations must contain BlockInvocationSyntax values.")
        if invocation.block_name not in block_names:
            raise ValueError(
                f"invoked block '{invocation.block_name}' is not included in blocks."
            )
        invocation_node_id = (
            f"invocation.{program_id}.{index}.{invocation.block_name}"
        )
        arguments = tuple(
            replace(
                argument,
                node_id=f"argument.{program_id}.{index}.{argument.name}",
            )
            for argument in invocation.arguments
        )
        normalized_invocations.append(
            replace(
                invocation,
                node_id=invocation_node_id,
                arguments=arguments,
            )
        )
    program_node_id = f"program.{program_id}"
    source_map = _source_map(
        program_node_id,
        declarations,
        tuple(normalized_invocations),
    )
    return ProgramSyntaxAST(
        node_id=program_node_id,
        program_id=program_id,
        blocks=declarations,
        invocations=tuple(normalized_invocations),
        source_map=source_map,
        metadata={"builder": "program_syntax"},
    )


def _declaration(value: BlockInput) -> BlockSyntax:
    if isinstance(value, BlockDefinition):
        return value.declaration
    if isinstance(value, BlockSyntax):
        return value
    raise TypeError("blocks must contain BlockDefinition or BlockSyntax values.")


def _source_map(
    program_node_id: str,
    blocks: tuple[BlockSyntax, ...],
    invocations: tuple[BlockInvocationSyntax, ...],
) -> SourceMap:
    entries = [
        SourceMapEntry(
            node_id=program_node_id,
            span=SourceSpan.unknown(program_node_id),
            origin="generated",
        )
    ]
    for block in blocks:
        entries.append(_entry(block.node_id, block.source_span))
        entries.extend(
            _entry(parameter.node_id, parameter.source_span)
            for parameter in block.parameters
        )
        entries.extend(
            _entry(resource.node_id, resource.source_span)
            for resource in block.logical_resources
        )
    for invocation in invocations:
        entries.append(_entry(invocation.node_id, invocation.source_span))
        entries.extend(
            _entry(argument.node_id, argument.source_span)
            for argument in invocation.arguments
        )
    return SourceMap(entries=tuple(entries))


def _entry(node_id: str, span: SourceSpan | None) -> SourceMapEntry:
    resolved = span or SourceSpan.unknown(node_id)
    return SourceMapEntry(
        node_id=node_id,
        span=resolved,
        origin="python" if resolved.is_known else "generated",
    )
