"""Source locations and deterministic frontend source maps."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

from cascaqit.native_ir.base import IRMixin

__all__ = [
    "SYNTAX_SCHEMA_VERSION",
    "SourceMap",
    "SourceMapEntry",
    "SourceSpan",
]

SYNTAX_SCHEMA_VERSION = "cascaqit.syntax.v1"
SourceOrigin = Literal["python", "generated", "unknown"]


def canonical_source_path(path: str) -> str:
    """Return a useful source path without embedding a checkout directory.

    Source locations are serialized into AST, HIR, and Hybrid provenance. An
    absolute path would make their stable hashes depend on where the same
    project was checked out. Prefer a path relative to the nearest project
    marker; for standalone files, fall back to the working directory or name.
    """
    candidate = Path(path)
    if not candidate.is_absolute():
        return candidate.as_posix()

    resolved = candidate.resolve()
    for parent in resolved.parents:
        if (parent / "pyproject.toml").is_file() or (parent / ".git").exists():
            return resolved.relative_to(parent).as_posix()

    try:
        return resolved.relative_to(Path.cwd().resolve()).as_posix()
    except ValueError:
        return resolved.name


def _require_identifier(value: str, *, field_name: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field_name} must be a non-empty string.")


@dataclass(frozen=True)
class SourceSpan(IRMixin):
    """A precise source range or an explicit unknown-source marker."""

    source_id: str
    path: str | None = None
    start_line: int | None = None
    start_column: int | None = None
    end_line: int | None = None
    end_column: int | None = None
    schema_version: str = SYNTAX_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_identifier(self.source_id, field_name="source_id")
        coordinates = (
            self.start_line,
            self.start_column,
            self.end_line,
            self.end_column,
        )
        if all(value is None for value in coordinates):
            if self.path is not None:
                raise ValueError(
                    "path must be None when source coordinates are unknown."
                )
            return
        if self.path is None or not str(self.path).strip():
            raise ValueError("path is required for a known source span.")
        if any(value is None for value in coordinates):
            raise ValueError("source coordinates must be provided together.")
        start_line = self.start_line
        start_column = self.start_column
        end_line = self.end_line
        end_column = self.end_column
        if (
            start_line is None
            or start_column is None
            or end_line is None
            or end_column is None
        ):
            raise AssertionError("source coordinate validation is incomplete.")
        if start_line < 1 or end_line < 1:
            raise ValueError("source lines must be positive integers.")
        if start_column < 0 or end_column < 0:
            raise ValueError("source columns must be non-negative integers.")
        if (end_line, end_column) < (start_line, start_column):
            raise ValueError("source end must not precede source start.")

    @property
    def is_known(self) -> bool:
        """Return whether this span has a concrete file location."""
        return self.path is not None

    @classmethod
    def unknown(cls, source_id: str) -> SourceSpan:
        """Create an explicit marker for unavailable source information."""
        return cls(source_id=source_id)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SourceSpan:
        """Build a source span from a JSON-compatible dictionary."""
        return cls(
            source_id=str(data["source_id"]),
            path=None if data.get("path") is None else str(data["path"]),
            start_line=_optional_int(data.get("start_line")),
            start_column=_optional_int(data.get("start_column")),
            end_line=_optional_int(data.get("end_line")),
            end_column=_optional_int(data.get("end_column")),
            schema_version=str(
                data.get("schema_version", SYNTAX_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> SourceSpan:
        """Build a source span from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("SourceSpan JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class SourceMapEntry(IRMixin):
    """Map one frontend node identifier to its source span."""

    node_id: str
    span: SourceSpan
    origin: SourceOrigin = "unknown"
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = SYNTAX_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_identifier(self.node_id, field_name="node_id")
        if not isinstance(self.span, SourceSpan):
            raise TypeError("span must be SourceSpan.")
        if self.origin not in {"python", "generated", "unknown"}:
            raise ValueError("origin must be python, generated, or unknown.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SourceMapEntry:
        """Build a source-map entry from a dictionary."""
        return cls(
            node_id=str(data["node_id"]),
            span=SourceSpan.from_dict(data["span"]),
            origin=data.get("origin", "unknown"),
            metadata=dict(data.get("metadata", {})),
            schema_version=str(
                data.get("schema_version", SYNTAX_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class SourceMap(IRMixin):
    """An immutable source map with unique node identifiers."""

    entries: tuple[SourceMapEntry, ...] = ()
    schema_version: str = SYNTAX_SCHEMA_VERSION

    def __post_init__(self) -> None:
        node_ids: set[str] = set()
        for entry in self.entries:
            if not isinstance(entry, SourceMapEntry):
                raise TypeError("entries must contain SourceMapEntry values.")
            if entry.node_id in node_ids:
                raise ValueError(
                    f"source map contains duplicate node_id '{entry.node_id}'."
                )
            node_ids.add(entry.node_id)

    def span_for(self, node_id: str) -> SourceSpan | None:
        """Return the span for a node, or None when the node is absent."""
        for entry in self.entries:
            if entry.node_id == node_id:
                return entry.span
        return None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SourceMap:
        """Build a source map from a JSON-compatible dictionary."""
        return cls(
            entries=tuple(
                SourceMapEntry.from_dict(item)
                for item in data.get("entries", ())
            ),
            schema_version=str(
                data.get("schema_version", SYNTAX_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> SourceMap:
        """Build a source map from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("SourceMap JSON must contain an object.")
        return cls.from_dict(data)


def _optional_int(value: Any) -> int | None:
    return None if value is None else int(value)
