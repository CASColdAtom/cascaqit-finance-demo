"""Public entry points for common CASCAQit workflows.

Advanced compiler, IR, simulator, backend, and report contracts are available
from their owning subpackages.  Keeping this module explicit prevents internal
contracts from becoming accidental root APIs.
"""

from __future__ import annotations

# Domain import order is intentional.  Analog initializes the shared native
# models before higher-level algorithm and backend packages join the root.
# ruff: noqa: I001

from cascaqit.analog import AHSProgram, AtomRegister, SiteMask, SitePattern, Waveform
from cascaqit.algorithms import (
    QAOA,
    VQE,
    HamiltonianTerm,
    OptimizerConfig,
    PauliHamiltonian,
    VariationalResult,
)
from cascaqit.backends import RetryPolicy
from cascaqit.digital import Circuit
from cascaqit.exceptions import (
    BackendExecutionError,
    CapabilityError,
    CASCAQitError,
    ProgramValidationError,
)
from cascaqit.hybrid import HybridProgram
from cascaqit.observables import (
    Observable,
    ObservableSet,
    PauliI,
    PauliProduct,
    PauliX,
    PauliY,
    PauliZ,
    PauliZZ,
)
from cascaqit.parameters import Parameter, ParameterManager, ParameterScan
from cascaqit.problems import GraphProblemIR, IsingModelIR, QUBOProblemIR
from cascaqit.results import ResultIR, build_result_view
from cascaqit.simulators import (
    LocalAhsSimulator,
    LocalBackend,
    LocalDigitalSimulator,
    NoiseChannel,
    NoiseModel,
    SimulationOptions,
)
from cascaqit.targets import MockNeutralAtomTarget
from cascaqit.visualization import build_counts_histogram, visualize

__all__ = [
    "AHSProgram",
    "AtomRegister",
    "BackendExecutionError",
    "CapabilityError",
    "CASCAQitError",
    "Circuit",
    "GraphProblemIR",
    "HamiltonianTerm",
    "HybridProgram",
    "IsingModelIR",
    "LocalAhsSimulator",
    "LocalBackend",
    "LocalDigitalSimulator",
    "MockNeutralAtomTarget",
    "NoiseChannel",
    "NoiseModel",
    "Observable",
    "ObservableSet",
    "OptimizerConfig",
    "Parameter",
    "ParameterManager",
    "ParameterScan",
    "PauliHamiltonian",
    "PauliI",
    "PauliProduct",
    "PauliX",
    "PauliY",
    "PauliZ",
    "PauliZZ",
    "ProgramValidationError",
    "QAOA",
    "QUBOProblemIR",
    "ResultIR",
    "RetryPolicy",
    "SimulationOptions",
    "SiteMask",
    "SitePattern",
    "VariationalResult",
    "VQE",
    "Waveform",
    "build_counts_histogram",
    "build_result_view",
    "visualize",
]

__version__ = "1.0.7a0"
