"""Offline lifecycle log and audit metadata contracts."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Literal, cast

from cascaqit.native_ir.base import IRMixin
from cascaqit.native_ir.models import SCHEMA_VERSION

__all__ = [
    "LifecycleLogStage",
    "LogEventIR",
    "build_lifecycle_log_event",
    "build_trace_correlation_metadata",
    "redact_audit_metadata",
]

LifecycleLogStage = Literal[
    "created",
    "validated",
    "discretized",
    "compiled",
    "queued",
    "running",
    "completed",
    "failed",
    "cancelled",
    "result_fetched",
]
LogSeverity = Literal["debug", "info", "warning", "error"]

_LIFECYCLE_STAGES: tuple[LifecycleLogStage, ...] = (
    "created",
    "validated",
    "discretized",
    "compiled",
    "queued",
    "running",
    "completed",
    "failed",
    "cancelled",
    "result_fetched",
)
_LOG_SEVERITIES: tuple[LogSeverity, ...] = (
    "debug",
    "info",
    "warning",
    "error",
)
_SECRET_KEY_MARKERS = (
    "access_key",
    "api_key",
    "apikey",
    "authorization",
    "credential",
    "email",
    "endpoint",
    "password",
    "phone",
    "private",
    "private_key",
    "secret",
    "token",
    "user",
)


@dataclass(frozen=True)
class LogEventIR(IRMixin):
    """Metadata-only lifecycle log event with audit-safe redaction."""

    event_id: str
    stage: LifecycleLogStage
    event_time: str
    status: str
    severity: LogSeverity = "info"
    trace_id: str | None = None
    cloud_trace_id: str | None = None
    span_id: str | None = None
    source_id: str | None = None
    source_kind: str | None = None
    message: str | None = None
    external_log_written: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Validate lifecycle fields and redact metadata."""
        if self.stage not in _LIFECYCLE_STAGES:
            raise ValueError(f"Unsupported lifecycle log stage: {self.stage}")
        if self.severity not in _LOG_SEVERITIES:
            raise ValueError(f"Unsupported log severity: {self.severity}")
        if self.external_log_written:
            raise ValueError("LogEventIR must not write external logs by default.")
        object.__setattr__(self, "metadata", redact_audit_metadata(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> LogEventIR:
        """Build a log event from a dictionary."""
        return cls(
            event_id=str(data["event_id"]),
            stage=cast(LifecycleLogStage, data["stage"]),
            event_time=str(data["event_time"]),
            status=str(data["status"]),
            severity=cast(LogSeverity, data.get("severity", "info")),
            trace_id=data.get("trace_id"),
            cloud_trace_id=data.get("cloud_trace_id"),
            span_id=data.get("span_id"),
            source_id=data.get("source_id"),
            source_kind=data.get("source_kind"),
            message=data.get("message"),
            external_log_written=bool(data.get("external_log_written", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> LogEventIR:
        """Build a log event from JSON text."""
        return cls.from_dict(_json_object(text, "LogEventIR"))


def build_trace_correlation_metadata(
    *,
    trace_id: str | None = None,
    cloud_trace_id: str | None = None,
    span_id: str | None = None,
) -> dict[str, Any]:
    """Build trace correlation placeholder metadata."""
    return {
        "trace_id": trace_id,
        "cloud_trace_id": cloud_trace_id,
        "span_id": span_id,
        "correlation_status": (
            "linked" if trace_id and cloud_trace_id else "placeholder"
        ),
        "external_trace_written": False,
        "metadata_only": True,
    }


def build_lifecycle_log_event(
    *,
    stage: LifecycleLogStage,
    source_id: str,
    source_kind: str,
    status: str = "ok",
    event_time: str = "offline",
    severity: LogSeverity = "info",
    trace_id: str | None = None,
    cloud_trace_id: str | None = None,
    span_id: str | None = None,
    message: str | None = None,
    metadata: dict[str, Any] | None = None,
    event_id: str | None = None,
) -> LogEventIR:
    """Build an audit-safe lifecycle log event without external logging."""
    correlation = build_trace_correlation_metadata(
        trace_id=trace_id,
        cloud_trace_id=cloud_trace_id,
        span_id=span_id,
    )
    payload_metadata = {
        "trace_correlation": correlation,
        "metadata_only": True,
        "external_log_written": False,
        **({} if metadata is None else metadata),
    }
    return LogEventIR(
        event_id=event_id or f"log.{stage}.{source_id}",
        stage=stage,
        event_time=event_time,
        status=status,
        severity=severity,
        trace_id=trace_id,
        cloud_trace_id=cloud_trace_id,
        span_id=span_id,
        source_id=source_id,
        source_kind=source_kind,
        message=message,
        external_log_written=False,
        metadata=payload_metadata,
    )


def redact_audit_metadata(data: dict[str, Any]) -> dict[str, Any]:
    """Return audit metadata with secret and privacy-like fields redacted."""
    return _redact_mapping(data)


def _json_object(text: str, model_name: str) -> dict[str, Any]:
    data = json.loads(text)
    if not isinstance(data, dict):
        raise TypeError(f"{model_name} JSON must contain an object.")
    return data


def _redact_mapping(data: dict[str, Any]) -> dict[str, Any]:
    redacted: dict[str, Any] = {}
    for key, value in data.items():
        lowered = str(key).lower()
        if any(token in lowered for token in _SECRET_KEY_MARKERS):
            redacted[str(key)] = "<redacted>"
        else:
            redacted[str(key)] = _redact_value(value)
    return redacted


def _redact_value(value: Any) -> Any:
    if isinstance(value, dict):
        return _redact_mapping(value)
    if isinstance(value, list):
        return [_redact_value(item) for item in value]
    if isinstance(value, tuple):
        return tuple(_redact_value(item) for item in value)
    return value
