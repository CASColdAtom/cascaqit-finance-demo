"""Resource estimation contracts for conservative offline metadata."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Literal

from cascaqit.control import ControlSystemIR
from cascaqit.native_ir.base import IRMixin
from cascaqit.native_ir.models import SCHEMA_VERSION, ProgramIR, WaveformIR
from cascaqit.native_ir.reference_compiled import ReferenceCompiledProgramIR

__all__ = [
    "ResourceEstimateIR",
    "estimate_compiled_resources",
    "estimate_program_resources",
]

ResourceEstimateSource = Literal[
    "ProgramIR",
    "ReferenceCompiledProgramIR",
]


@dataclass(frozen=True)
class ResourceEstimateIR(IRMixin):
    """Conservative resource estimate metadata, not a hardware guarantee."""

    estimate_id: str
    source_kind: ResourceEstimateSource
    source_id: str
    source_hash: str
    atom_count: int
    duration: float
    duration_unit: str
    waveform_count: int
    measurement_count: int
    channel_usage: dict[str, Any]
    shots: int | None = None
    estimated_hilbert_dimension: int | None = None
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ResourceEstimateIR:
        """Build a resource estimate from a dictionary."""
        return cls(
            estimate_id=str(data["estimate_id"]),
            source_kind=data["source_kind"],
            source_id=str(data["source_id"]),
            source_hash=str(data["source_hash"]),
            atom_count=int(data["atom_count"]),
            duration=float(data["duration"]),
            duration_unit=str(data["duration_unit"]),
            waveform_count=int(data["waveform_count"]),
            measurement_count=int(data["measurement_count"]),
            channel_usage=dict(data["channel_usage"]),
            shots=None if data.get("shots") is None else int(data["shots"]),
            estimated_hilbert_dimension=(
                None
                if data.get("estimated_hilbert_dimension") is None
                else int(data["estimated_hilbert_dimension"])
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> ResourceEstimateIR:
        """Build a resource estimate from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("ResourceEstimateIR JSON must contain an object.")
        return cls.from_dict(data)


def estimate_program_resources(
    program: ProgramIR,
    *,
    shots: int | None = None,
    control_system: ControlSystemIR | None = None,
) -> ResourceEstimateIR:
    """Estimate resources directly from ProgramIR."""
    if not isinstance(program, ProgramIR):
        raise TypeError("estimate_program_resources accepts ProgramIR.")
    register = program.register
    atom_count = len(register.active_sites)
    duration = _program_duration(program)
    return ResourceEstimateIR(
        estimate_id=f"resource.program.{program.program_id}",
        source_kind="ProgramIR",
        source_id=program.program_id,
        source_hash=program.stable_hash(),
        atom_count=atom_count,
        duration=duration,
        duration_unit=program.unit_conventions.time,
        waveform_count=_program_waveform_count(program),
        measurement_count=len(program.measurements),
        channel_usage=_program_channel_usage(
            program,
            control_system=control_system,
        ),
        shots=shots,
        estimated_hilbert_dimension=2**atom_count,
        metadata=_estimate_metadata(
            source="ProgramIR",
            control_system=control_system,
            extra={
                "program_type": program.program_type,
                "lifecycle_state": program.lifecycle_state,
                "register_snapshot": register.snapshot_evidence(),
            },
        ),
    )


def estimate_compiled_resources(
    compiled_program: ReferenceCompiledProgramIR,
    *,
    shots: int | None = None,
    control_system: ControlSystemIR | None = None,
) -> ResourceEstimateIR:
    """Estimate resources from ReferenceCompiledProgramIR metadata and schedules."""
    if not isinstance(compiled_program, ReferenceCompiledProgramIR):
        raise TypeError(
            "estimate_compiled_resources accepts ReferenceCompiledProgramIR."
        )
    existing = compiled_program.resource_estimate
    atom_count = int(existing.get("atom_count", 0))
    duration = float(
        existing.get(
            "duration",
            compiled_program.compiled_schedule.get("duration", 0.0),
        )
    )
    waveform_count = int(
        existing.get(
            "waveform_count",
            _compiled_waveform_count(compiled_program),
        )
    )
    measurement_count = int(
        existing.get(
            "measurement_count",
            len(compiled_program.measurement_schedule.get("measurements", ())),
        )
    )
    return ResourceEstimateIR(
        estimate_id=f"resource.compiled.{compiled_program.compiled_program_id}",
        source_kind="ReferenceCompiledProgramIR",
        source_id=compiled_program.compiled_program_id,
        source_hash=compiled_program.stable_hash(),
        atom_count=atom_count,
        duration=duration,
        duration_unit=str(compiled_program.compiled_schedule.get("time_unit", "us")),
        waveform_count=waveform_count,
        measurement_count=measurement_count,
        channel_usage=_compiled_channel_usage(
            compiled_program,
            control_system=control_system,
        ),
        shots=shots,
        estimated_hilbert_dimension=existing.get("estimated_hilbert_dimension"),
        metadata=_estimate_metadata(
            source="ReferenceCompiledProgramIR",
            control_system=control_system,
            extra={
                "target_id": compiled_program.target_id,
                "compiler_version": compiled_program.compiler_version,
                "compile_cache_key": compiled_program.compile_cache_key,
            },
        ),
    )


def _estimate_metadata(
    *,
    source: str,
    control_system: ControlSystemIR | None,
    extra: dict[str, Any],
) -> dict[str, Any]:
    metadata = {
        "estimate_mode": "conservative_metadata",
        "source": source,
        "hardware_guarantee": False,
        "requires_real_calibration": False,
        "expected_error_budget": {
            "status": "placeholder",
            "physical_accuracy": "not_claimed",
            "components": [],
        },
    }
    if control_system is not None:
        metadata["control_system"] = control_system.channel_summary()
    metadata.update(extra)
    return metadata


def _program_duration(program: ProgramIR) -> float:
    durations = [
        program.hamiltonian.rabi.duration,
        program.hamiltonian.detuning.duration,
    ]
    phase = program.hamiltonian.phase
    if isinstance(phase, WaveformIR):
        durations.append(phase.duration)
    durations.extend(
        term.waveform.duration for term in program.hamiltonian.local_detuning_terms
    )
    for term in program.hamiltonian.local_rabi_terms:
        durations.append(term.rabi.duration)
        if isinstance(term.phase, WaveformIR):
            durations.append(term.phase.duration)
    return max(durations)


def _program_waveform_count(program: ProgramIR) -> int:
    count = 2
    if isinstance(program.hamiltonian.phase, WaveformIR):
        count += 1
    count += len(program.hamiltonian.local_detuning_terms)
    for term in program.hamiltonian.local_rabi_terms:
        count += 1
        if isinstance(term.phase, WaveformIR):
            count += 1
    return count


def _program_channel_usage(
    program: ProgramIR,
    *,
    control_system: ControlSystemIR | None,
) -> dict[str, Any]:
    usage = {
        "channels": [
            {
                "channel_id": "global",
                "channel_type": "rydberg_global",
                "fields": ["rabi", "detuning", "phase"],
                "operation_count": 1,
                "duration": _program_duration(program),
                "time_unit": program.unit_conventions.time,
            }
        ],
        "control_system_channel_count": 0,
    }
    channels = usage["channels"]
    assert isinstance(channels, list)
    for index, detuning_term in enumerate(program.hamiltonian.local_detuning_terms):
        channels.append(
            {
                "channel_id": f"local_detuning_{index}",
                "channel_type": "rydberg_detuning",
                "fields": ["detuning", "site_addressing"],
                "operation_count": 1,
                "duration": detuning_term.waveform.duration,
                "time_unit": detuning_term.waveform.time_unit,
                "addressing_hash": detuning_term.addressing.stable_hash(),
                "addressing_frame_count": detuning_term.addressing.frame_count,
            }
        )
    for index, rabi_term in enumerate(program.hamiltonian.local_rabi_terms):
        channels.append(
            {
                "channel_id": f"local_rabi_{index}",
                "channel_type": "rydberg_rabi",
                "fields": ["rabi", "phase", "site_addressing"],
                "operation_count": 1,
                "duration": rabi_term.rabi.duration,
                "time_unit": rabi_term.rabi.time_unit,
                "addressing_hash": rabi_term.addressing.stable_hash(),
                "addressing_frame_count": rabi_term.addressing.frame_count,
            }
        )
    if control_system is not None:
        usage["control_system_channel_count"] = len(control_system.channels)
        usage["control_system_channels"] = control_system.channel_summary()["channels"]
    return usage


def _compiled_channel_usage(
    compiled_program: ReferenceCompiledProgramIR,
    *,
    control_system: ControlSystemIR | None,
) -> dict[str, Any]:
    channels = compiled_program.channel_schedule.get("channels", {})
    usage = {
        "channels": [
            {"channel_id": channel_id, **dict(payload)}
            for channel_id, payload in sorted(channels.items())
        ],
        "control_system_channel_count": 0,
    }
    if control_system is not None:
        usage["control_system_channel_count"] = len(control_system.channels)
        usage["control_system_channels"] = control_system.channel_summary()["channels"]
    return usage


def _compiled_waveform_count(compiled_program: ReferenceCompiledProgramIR) -> int:
    count = 0
    for operation in compiled_program.native_operation_set:
        fields = operation.get("fields", {})
        if isinstance(fields, dict):
            count += len(fields)
    return count
