"""Public offline readiness, audit, and resource-estimation contracts."""

from __future__ import annotations

from importlib import import_module
from typing import Any

_EXPORTS = {
    "BackendHealthIR": "cascaqit.readiness.core",
    "BackendHealthProviderProtocol": "cascaqit.readiness.core",
    "CloudReadinessManifestIR": "cascaqit.readiness.core",
    "CredentialProfileIR": "cascaqit.readiness.core",
    "CredentialRefIR": "cascaqit.readiness.core",
    "CredentialRequirementIR": "cascaqit.readiness.core",
    "CredentialResolutionPolicyIR": "cascaqit.readiness.core",
    "CredentialResolutionResultIR": "cascaqit.readiness.core",
    "CredentialResolverProtocol": "cascaqit.readiness.core",
    "FakeBackendHealthProvider": "cascaqit.readiness.core",
    "HardwareSmokeManifestIR": "cascaqit.readiness.core",
    "LifecycleLogStage": "cascaqit.readiness.audit",
    "LiveSmokePreflightIR": "cascaqit.readiness.core",
    "LiveSmokeProfileIR": "cascaqit.readiness.core",
    "LogEventIR": "cascaqit.readiness.audit",
    "ReadinessCheckResultIR": "cascaqit.readiness.core",
    "ReferenceOnlyCredentialResolver": "cascaqit.readiness.core",
    "ResourceEstimateIR": "cascaqit.readiness.resources",
    "build_cloud_readiness_manifest": "cascaqit.readiness.core",
    "build_hardware_smoke_manifest": "cascaqit.readiness.core",
    "build_lifecycle_log_event": "cascaqit.readiness.audit",
    "build_live_smoke_preflight": "cascaqit.readiness.core",
    "build_trace_correlation_metadata": "cascaqit.readiness.audit",
    "check_backend_readiness": "cascaqit.readiness.core",
    "diagnose_backend_readiness": "cascaqit.readiness.core",
    "estimate_compiled_resources": "cascaqit.readiness.resources",
    "estimate_program_resources": "cascaqit.readiness.resources",
    "redact_audit_metadata": "cascaqit.readiness.audit",
    "resolve_credential_reference": "cascaqit.readiness.core",
    "validate_credential_profile": "cascaqit.readiness.core",
}

__all__ = sorted(_EXPORTS)


def __getattr__(name: str) -> Any:
    module_name = _EXPORTS.get(name)
    if module_name is None:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
    value = getattr(import_module(module_name), name)
    globals()[name] = value
    return value


def __dir__() -> list[str]:
    return sorted(set(globals()) | set(__all__))
