"""Offline readiness manifests for future hardware and cloud integration."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Literal, Protocol, cast

from cascaqit.diagnostics import DiagnosticsIR, with_diagnostic_taxonomy
from cascaqit.native_ir.base import IRMixin
from cascaqit.native_ir.models import SCHEMA_VERSION
from cascaqit.submission import HardwareSubmissionIR

__all__ = [
    "BackendHealthIR",
    "BackendHealthProviderProtocol",
    "CloudReadinessManifestIR",
    "CredentialProfileIR",
    "CredentialResolutionPolicyIR",
    "CredentialResolutionResultIR",
    "CredentialResolverProtocol",
    "CredentialRefIR",
    "CredentialRequirementIR",
    "FakeBackendHealthProvider",
    "HardwareSmokeManifestIR",
    "LiveSmokePreflightIR",
    "LiveSmokeProfileIR",
    "ReadinessCheckResultIR",
    "build_cloud_readiness_manifest",
    "build_hardware_smoke_manifest",
    "build_live_smoke_preflight",
    "check_backend_readiness",
    "diagnose_backend_readiness",
    "resolve_credential_reference",
    "validate_credential_profile",
]

CredentialReferenceKind = Literal[
    "none",
    "env_var",
    "profile",
    "keychain",
    "secret_manager",
    "external",
]
CredentialProfileStatus = Literal["configured", "missing", "disabled", "unknown"]
ReadinessMode = Literal["offline_manifest", "dry_run", "live_opt_in"]
BackendHealthStatus = Literal["unknown", "available", "degraded", "unavailable"]
BackendKind = Literal["hardware", "cloud"]
LiveSmokePreflightStatus = Literal["skipped", "blocked", "ready"]
ReadinessManifest = "HardwareSmokeManifestIR | CloudReadinessManifestIR"

_BACKEND_HEALTH_STATUSES: tuple[BackendHealthStatus, ...] = (
    "unknown",
    "available",
    "degraded",
    "unavailable",
)

_SECRET_KEY_MARKERS = (
    "access_key",
    "api_key",
    "apikey",
    "authorization",
    "credential",
    "password",
    "private_key",
    "secret",
    "token",
)


@dataclass(frozen=True)
class CredentialResolutionPolicyIR(IRMixin):
    """Metadata-only credential reference resolution policy."""

    resolution_policy_id: str
    provider: str
    allowed_reference_kinds: tuple[CredentialReferenceKind, ...]
    required_scopes: tuple[str, ...] = ()
    allow_raw_secret_loading: bool = False
    allow_network_access: bool = False
    allow_permission_probe: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.allow_raw_secret_loading:
            raise ValueError(
                "CredentialResolutionPolicyIR cannot allow raw secret loading."
            )
        object.__setattr__(
            self,
            "allowed_reference_kinds",
            tuple(self.allowed_reference_kinds),
        )
        object.__setattr__(
            self,
            "required_scopes",
            tuple(str(scope) for scope in self.required_scopes),
        )
        object.__setattr__(self, "metadata", _redact_mapping(self.metadata))

    @classmethod
    def from_requirement(
        cls,
        requirement: CredentialRequirementIR,
        *,
        resolution_policy_id: str | None = None,
        allow_network_access: bool = False,
        allow_permission_probe: bool = False,
        metadata: dict[str, Any] | None = None,
    ) -> CredentialResolutionPolicyIR:
        """Build a resolution policy from a credential requirement."""
        if not isinstance(requirement, CredentialRequirementIR):
            raise TypeError("from_requirement accepts CredentialRequirementIR.")
        return cls(
            resolution_policy_id=(
                resolution_policy_id
                or f"credential_resolution_policy.{requirement.requirement_id}"
            ),
            provider=requirement.provider,
            allowed_reference_kinds=requirement.allowed_reference_kinds,
            required_scopes=requirement.required_scopes,
            allow_network_access=allow_network_access,
            allow_permission_probe=allow_permission_probe,
            metadata={
                "source": "CredentialRequirementIR",
                "operation": requirement.operation,
                **({} if metadata is None else metadata),
            },
        )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CredentialResolutionPolicyIR:
        """Build a credential resolution policy from a dictionary."""
        return cls(
            resolution_policy_id=str(data["resolution_policy_id"]),
            provider=str(data["provider"]),
            allowed_reference_kinds=tuple(
                cast(CredentialReferenceKind, kind)
                for kind in data.get("allowed_reference_kinds", ())
            ),
            required_scopes=tuple(
                str(scope) for scope in data.get("required_scopes", ())
            ),
            allow_raw_secret_loading=bool(
                data.get("allow_raw_secret_loading", False)
            ),
            allow_network_access=bool(data.get("allow_network_access", False)),
            allow_permission_probe=bool(data.get("allow_permission_probe", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> CredentialResolutionPolicyIR:
        """Build a credential resolution policy from JSON text."""
        return cls.from_dict(_json_object(text, "CredentialResolutionPolicyIR"))


@dataclass(frozen=True)
class CredentialResolutionResultIR(IRMixin):
    """Result of resolving credential reference metadata without secret access."""

    resolution_result_id: str
    provider: str
    credential_ref: CredentialRefIR | None
    reference_kind: CredentialReferenceKind
    resolved_reference: str | None
    resolution_status: Literal["resolved_reference", "missing", "blocked"]
    diagnostics: tuple[DiagnosticsIR, ...]
    raw_secret_loaded: bool = False
    network_accessed: bool = False
    permission_probe_performed: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.raw_secret_loaded:
            raise ValueError("CredentialResolutionResultIR cannot load raw secrets.")
        if self.network_accessed:
            raise ValueError("CredentialResolutionResultIR cannot access network.")
        object.__setattr__(
            self,
            "diagnostics",
            tuple(_diagnostic_from_any(item) for item in self.diagnostics),
        )
        object.__setattr__(self, "metadata", _redact_mapping(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CredentialResolutionResultIR:
        """Build a credential resolution result from a dictionary."""
        return cls(
            resolution_result_id=str(data["resolution_result_id"]),
            provider=str(data["provider"]),
            credential_ref=_credential_from_optional(data.get("credential_ref")),
            reference_kind=cast(CredentialReferenceKind, data["reference_kind"]),
            resolved_reference=data.get("resolved_reference"),
            resolution_status=cast(
                Literal["resolved_reference", "missing", "blocked"],
                data["resolution_status"],
            ),
            diagnostics=tuple(
                _diagnostic_from_any(item) for item in data.get("diagnostics", ())
            ),
            raw_secret_loaded=bool(data.get("raw_secret_loaded", False)),
            network_accessed=bool(data.get("network_accessed", False)),
            permission_probe_performed=bool(
                data.get("permission_probe_performed", False)
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> CredentialResolutionResultIR:
        """Build a credential resolution result from JSON text."""
        return cls.from_dict(_json_object(text, "CredentialResolutionResultIR"))


class CredentialResolverProtocol(Protocol):
    """Credential resolver SPI that must keep public results reference-only."""

    def resolve(
        self,
        credential_ref: CredentialRefIR | None,
        policy: CredentialResolutionPolicyIR,
    ) -> CredentialResolutionResultIR:
        """Resolve credential metadata without exposing raw secret values."""


class ReferenceOnlyCredentialResolver:
    """Default resolver that never reads env, keychain, or secret-manager values."""

    def resolve(
        self,
        credential_ref: CredentialRefIR | None,
        policy: CredentialResolutionPolicyIR,
    ) -> CredentialResolutionResultIR:
        """Return reference-only credential resolution metadata."""
        return resolve_credential_reference(credential_ref, policy)


@dataclass(frozen=True)
class CredentialRefIR(IRMixin):
    """Credential reference metadata without raw secret material."""

    credential_ref_id: str
    provider: str
    reference_kind: CredentialReferenceKind
    reference: str | None = None
    required_scopes: tuple[str, ...] = ()
    raw_secret_loaded: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize scope metadata and reject raw secret payloads."""
        if self.raw_secret_loaded:
            raise ValueError("CredentialRefIR cannot contain raw secrets.")
        if self.reference_kind == "none" and self.reference is not None:
            raise ValueError("reference must be None when reference_kind='none'.")
        if self.reference_kind != "none" and not self.reference:
            raise ValueError("reference is required for credential references.")
        object.__setattr__(
            self,
            "required_scopes",
            tuple(str(scope) for scope in self.required_scopes),
        )
        object.__setattr__(self, "metadata", _redact_mapping(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CredentialRefIR:
        """Build a credential reference from a dictionary."""
        return cls(
            credential_ref_id=str(data["credential_ref_id"]),
            provider=str(data["provider"]),
            reference_kind=cast(
                CredentialReferenceKind,
                data["reference_kind"],
            ),
            reference=data.get("reference"),
            required_scopes=tuple(
                str(scope) for scope in data.get("required_scopes", ())
            ),
            raw_secret_loaded=bool(data.get("raw_secret_loaded", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> CredentialRefIR:
        """Build a credential reference from JSON text."""
        return cls.from_dict(_json_object(text, "CredentialRefIR"))


@dataclass(frozen=True)
class CredentialRequirementIR(IRMixin):
    """Credential requirements for an opt-in provider operation."""

    requirement_id: str
    provider: str
    required_scopes: tuple[str, ...]
    allowed_reference_kinds: tuple[CredentialReferenceKind, ...] = ()
    operation: str | None = None
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize tuple fields and redact metadata."""
        object.__setattr__(
            self,
            "required_scopes",
            tuple(str(scope) for scope in self.required_scopes),
        )
        object.__setattr__(
            self,
            "allowed_reference_kinds",
            tuple(self.allowed_reference_kinds),
        )
        object.__setattr__(self, "metadata", _redact_mapping(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CredentialRequirementIR:
        """Build a credential requirement from a dictionary."""
        return cls(
            requirement_id=str(data["requirement_id"]),
            provider=str(data["provider"]),
            required_scopes=tuple(
                str(scope) for scope in data.get("required_scopes", ())
            ),
            allowed_reference_kinds=tuple(
                cast(CredentialReferenceKind, kind)
                for kind in data.get("allowed_reference_kinds", ())
            ),
            operation=data.get("operation"),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> CredentialRequirementIR:
        """Build a credential requirement from JSON text."""
        return cls.from_dict(_json_object(text, "CredentialRequirementIR"))


@dataclass(frozen=True)
class CredentialProfileIR(IRMixin):
    """Credential profile metadata that references, but never loads, secrets."""

    credential_profile_id: str
    provider: str
    credential_ref: CredentialRefIR
    status: CredentialProfileStatus = "unknown"
    project_ref: str | None = None
    workspace_ref: str | None = None
    raw_secret_loaded: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Reject raw secret state and redact profile metadata."""
        if self.raw_secret_loaded:
            raise ValueError("CredentialProfileIR cannot contain raw secrets.")
        if self.provider != self.credential_ref.provider:
            raise ValueError("CredentialProfileIR provider must match credential_ref.")
        object.__setattr__(self, "metadata", _redact_mapping(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CredentialProfileIR:
        """Build a credential profile from a dictionary."""
        credential_ref = _credential_from_optional(data["credential_ref"])
        if credential_ref is None:
            raise TypeError("CredentialProfileIR credential_ref cannot be null.")
        return cls(
            credential_profile_id=str(data["credential_profile_id"]),
            provider=str(data["provider"]),
            credential_ref=credential_ref,
            status=cast(
                CredentialProfileStatus,
                data.get("status", "unknown"),
            ),
            project_ref=data.get("project_ref"),
            workspace_ref=data.get("workspace_ref"),
            raw_secret_loaded=bool(data.get("raw_secret_loaded", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> CredentialProfileIR:
        """Build a credential profile from JSON text."""
        return cls.from_dict(_json_object(text, "CredentialProfileIR"))


def validate_credential_profile(
    profile: CredentialProfileIR | None,
    requirement: CredentialRequirementIR,
) -> tuple[DiagnosticsIR, ...]:
    """Validate credential profile metadata without loading secret material."""
    if profile is not None and not isinstance(profile, CredentialProfileIR):
        raise TypeError("profile must be CredentialProfileIR or None.")
    if not isinstance(requirement, CredentialRequirementIR):
        raise TypeError("requirement must be CredentialRequirementIR.")
    diagnostics = [
        _diagnostic(
            diagnostic_id=f"diagnostic.{requirement.requirement_id}.offline",
            severity="info",
            code="CREDENTIAL_PROFILE_OFFLINE",
            message=(
                "Credential profile validation uses references only and does "
                "not load raw secrets."
            ),
            metadata={
                "requirement_id": requirement.requirement_id,
                "provider": requirement.provider,
                "operation": requirement.operation,
            },
        )
    ]
    if profile is None:
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"diagnostic.{requirement.requirement_id}.missing",
                severity="error",
                code="CREDENTIAL_PROFILE_MISSING",
                message="Required credential profile is missing.",
                object_path="credential_profile",
                suggestion="Attach a CredentialProfileIR for this provider.",
            )
        )
        return tuple(diagnostics)
    diagnostics.extend(_credential_profile_diagnostics(profile, requirement))
    diagnostics.extend(_authentication_permission_placeholder_diagnostics(requirement))
    return tuple(diagnostics)


def resolve_credential_reference(
    credential_ref: CredentialRefIR | None,
    policy: CredentialResolutionPolicyIR,
) -> CredentialResolutionResultIR:
    """Resolve credential reference metadata without loading secret values."""
    if credential_ref is not None and not isinstance(credential_ref, CredentialRefIR):
        raise TypeError("credential_ref must be CredentialRefIR or None.")
    if not isinstance(policy, CredentialResolutionPolicyIR):
        raise TypeError("policy must be CredentialResolutionPolicyIR.")
    diagnostics = [
        _diagnostic(
            diagnostic_id=f"diagnostic.{policy.resolution_policy_id}.offline",
            severity="info",
            code="CREDENTIAL_RESOLUTION_OFFLINE",
            message=(
                "Credential resolution validates references only and does not "
                "read environment values, keychains, secret managers, or tokens."
            ),
            metadata={
                "resolution_policy_id": policy.resolution_policy_id,
                "provider": policy.provider,
                "network_accessed": False,
                "raw_secret_loaded": False,
            },
        )
    ]
    if credential_ref is None:
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"diagnostic.{policy.resolution_policy_id}.missing",
                severity="error",
                code="CREDENTIAL_RESOLUTION_REFERENCE_MISSING",
                message="Credential reference is missing.",
                object_path="credential_ref",
            )
        )
        return CredentialResolutionResultIR(
            resolution_result_id=f"credential_resolution_result.{policy.provider}.missing",
            provider=policy.provider,
            credential_ref=None,
            reference_kind="none",
            resolved_reference=None,
            resolution_status="missing",
            diagnostics=tuple(diagnostics),
            metadata={
                "resolution_policy_id": policy.resolution_policy_id,
                "reference_only": True,
            },
        )
    diagnostics.extend(_credential_reference_policy_diagnostics(credential_ref, policy))
    blocked = any(diagnostic.severity == "error" for diagnostic in diagnostics)
    return CredentialResolutionResultIR(
        resolution_result_id=(
            f"credential_resolution_result.{credential_ref.credential_ref_id}"
        ),
        provider=policy.provider,
        credential_ref=credential_ref,
        reference_kind=credential_ref.reference_kind,
        resolved_reference=credential_ref.reference,
        resolution_status="blocked" if blocked else "resolved_reference",
        diagnostics=tuple(diagnostics),
        raw_secret_loaded=False,
        network_accessed=False,
        permission_probe_performed=False,
        metadata={
            "resolution_policy_id": policy.resolution_policy_id,
            "reference_only": True,
            "raw_value_returned": False,
            "authentication_checked": False,
            "permission_checked": False,
        },
    )


def _credential_profile_diagnostics(
    profile: CredentialProfileIR,
    requirement: CredentialRequirementIR,
) -> list[DiagnosticsIR]:
    diagnostics: list[DiagnosticsIR] = []
    if profile.provider != requirement.provider:
        diagnostics.append(
            _diagnostic(
                diagnostic_id=(
                    f"diagnostic.{profile.credential_profile_id}.provider"
                ),
                severity="error",
                code="CREDENTIAL_PROVIDER_MISMATCH",
                message="Credential profile provider does not match requirement.",
                object_path="provider",
                metadata={
                    "profile_provider": profile.provider,
                    "required_provider": requirement.provider,
                },
            )
        )
    if profile.status != "configured":
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"diagnostic.{profile.credential_profile_id}.status",
                severity="warning",
                code="CREDENTIAL_PROFILE_NOT_CONFIGURED",
                message="Credential profile is not marked configured.",
                object_path="status",
                suggestion="Configure the provider profile before live checks.",
                metadata={"status": profile.status},
            )
        )
    if profile.credential_ref.raw_secret_loaded or profile.raw_secret_loaded:
        diagnostics.append(
            _diagnostic(
                diagnostic_id=(
                    f"diagnostic.{profile.credential_profile_id}.raw_secret"
                ),
                severity="error",
                code="CREDENTIAL_RAW_SECRET_LOADED",
                message="Credential profile must not contain raw secret material.",
                object_path="raw_secret_loaded",
            )
        )
    allowed = requirement.allowed_reference_kinds
    if allowed and profile.credential_ref.reference_kind not in allowed:
        diagnostics.append(
            _diagnostic(
                diagnostic_id=(
                    f"diagnostic.{profile.credential_profile_id}.reference_kind"
                ),
                severity="error",
                code="CREDENTIAL_REFERENCE_KIND_UNSUPPORTED",
                message="Credential reference kind is not allowed.",
                object_path="credential_ref.reference_kind",
                metadata={
                    "reference_kind": profile.credential_ref.reference_kind,
                    "allowed_reference_kinds": list(allowed),
                },
            )
        )
    missing_scopes = sorted(
        set(requirement.required_scopes) - set(profile.credential_ref.required_scopes)
    )
    if missing_scopes:
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"diagnostic.{profile.credential_profile_id}.scopes",
                severity="error",
                code="CREDENTIAL_SCOPE_MISSING",
                message="Credential profile is missing required scopes.",
                object_path="credential_ref.required_scopes",
                suggestion="Add the missing scopes to the credential profile.",
                metadata={"missing_scopes": missing_scopes},
            )
        )
    return diagnostics


def _credential_reference_policy_diagnostics(
    credential_ref: CredentialRefIR,
    policy: CredentialResolutionPolicyIR,
) -> list[DiagnosticsIR]:
    diagnostics: list[DiagnosticsIR] = []
    if credential_ref.provider != policy.provider:
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"diagnostic.{credential_ref.credential_ref_id}.provider",
                severity="error",
                code="CREDENTIAL_RESOLUTION_PROVIDER_MISMATCH",
                message="Credential reference provider does not match policy.",
                object_path="provider",
                metadata={
                    "reference_provider": credential_ref.provider,
                    "policy_provider": policy.provider,
                },
            )
        )
    if (
        policy.allowed_reference_kinds
        and credential_ref.reference_kind not in policy.allowed_reference_kinds
    ):
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"diagnostic.{credential_ref.credential_ref_id}.kind",
                severity="error",
                code="CREDENTIAL_RESOLUTION_REFERENCE_KIND_UNSUPPORTED",
                message="Credential reference kind is not allowed by policy.",
                object_path="reference_kind",
                metadata={
                    "reference_kind": credential_ref.reference_kind,
                    "allowed_reference_kinds": list(policy.allowed_reference_kinds),
                },
            )
        )
    missing_scopes = sorted(
        set(policy.required_scopes) - set(credential_ref.required_scopes)
    )
    if missing_scopes:
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"diagnostic.{credential_ref.credential_ref_id}.scopes",
                severity="error",
                code="CREDENTIAL_RESOLUTION_SCOPE_MISSING",
                message="Credential reference is missing required scopes.",
                object_path="required_scopes",
                metadata={"missing_scopes": missing_scopes},
            )
        )
    diagnostics.extend(_credential_reference_shape_diagnostics(credential_ref))
    return diagnostics


def _credential_reference_shape_diagnostics(
    credential_ref: CredentialRefIR,
) -> list[DiagnosticsIR]:
    diagnostics: list[DiagnosticsIR] = []
    if credential_ref.reference_kind == "env_var":
        if "=" in str(credential_ref.reference):
            diagnostics.append(
                _diagnostic(
                    diagnostic_id=(
                        f"diagnostic.{credential_ref.credential_ref_id}.env_var"
                    ),
                    severity="error",
                    code="CREDENTIAL_REFERENCE_ENV_VAR_VALUE_FORBIDDEN",
                    message=(
                        "env_var credential references must name a variable and "
                        "must not contain a value."
                    ),
                    object_path="reference",
                )
            )
    elif credential_ref.reference_kind == "profile":
        if "/" not in str(credential_ref.reference):
            diagnostics.append(
                _diagnostic(
                    diagnostic_id=(
                        f"diagnostic.{credential_ref.credential_ref_id}.profile"
                    ),
                    severity="warning",
                    code="CREDENTIAL_REFERENCE_PROFILE_FORMAT_WEAK",
                    message="profile references should include provider/profile id.",
                    object_path="reference",
                )
            )
    elif credential_ref.reference_kind == "keychain":
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"diagnostic.{credential_ref.credential_ref_id}.keychain",
                severity="info",
                code="CREDENTIAL_REFERENCE_KEYCHAIN_NOT_READ",
                message="keychain reference recorded; keychain value was not read.",
                object_path="reference_kind",
            )
        )
    elif credential_ref.reference_kind == "secret_manager":
        diagnostics.append(
            _diagnostic(
                diagnostic_id=(
                    f"diagnostic.{credential_ref.credential_ref_id}."
                    "secret_manager"
                ),
                severity="info",
                code="CREDENTIAL_REFERENCE_SECRET_MANAGER_NOT_READ",
                message=(
                    "secret_manager reference recorded; remote secret value was "
                    "not read."
                ),
                object_path="reference_kind",
            )
        )
    elif credential_ref.reference_kind == "external":
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"diagnostic.{credential_ref.credential_ref_id}.external",
                severity="info",
                code="CREDENTIAL_REFERENCE_EXTERNAL_NOT_INVOKED",
                message="external credential provider was not invoked.",
                object_path="reference_kind",
            )
        )
    return diagnostics


def _authentication_permission_placeholder_diagnostics(
    requirement: CredentialRequirementIR,
) -> list[DiagnosticsIR]:
    return [
        _diagnostic(
            diagnostic_id=f"diagnostic.{requirement.requirement_id}.authentication",
            severity="info",
            code="AUTHENTICATION_CHECK_NOT_PERFORMED",
            message=(
                "Authentication check is a live opt-in placeholder and was not "
                "performed."
            ),
            object_path="credential_profile",
            metadata={
                "provider": requirement.provider,
                "operation": requirement.operation,
                "network_accessed": False,
            },
        ),
        _diagnostic(
            diagnostic_id=f"diagnostic.{requirement.requirement_id}.permission",
            severity="info",
            code="PERMISSION_CHECK_NOT_PERFORMED",
            message=(
                "Permission check is a live opt-in placeholder and was not "
                "performed."
            ),
            object_path="credential_profile",
            metadata={
                "provider": requirement.provider,
                "required_scopes": list(requirement.required_scopes),
                "network_accessed": False,
            },
        ),
    ]


@dataclass(frozen=True)
class BackendHealthIR(IRMixin):
    """Offline backend health snapshot for readiness aggregation."""

    health_id: str
    backend_id: str
    backend_kind: BackendKind
    status: BackendHealthStatus
    checked_at: str
    source: str
    network_accessed: bool = False
    credential_profile_id: str | None = None
    target_id: str | None = None
    target_snapshot_hash: str | None = None
    calibration_snapshot_hash: str | None = None
    package_schema: str | None = None
    expected_failure_modes: tuple[str, ...] = ()
    observed_failure_modes: tuple[str, ...] = ()
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize health metadata and enforce offline-only snapshots."""
        if self.network_accessed:
            raise ValueError("BackendHealthIR cannot record network access.")
        if self.status not in _BACKEND_HEALTH_STATUSES:
            raise ValueError(f"Unsupported backend health status: {self.status}")
        object.__setattr__(
            self,
            "expected_failure_modes",
            tuple(str(item) for item in self.expected_failure_modes),
        )
        object.__setattr__(
            self,
            "observed_failure_modes",
            tuple(str(item) for item in self.observed_failure_modes),
        )
        object.__setattr__(self, "metadata", _redact_mapping(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> BackendHealthIR:
        """Build a backend health snapshot from a dictionary."""
        return cls(
            health_id=str(data["health_id"]),
            backend_id=str(data["backend_id"]),
            backend_kind=cast(BackendKind, data["backend_kind"]),
            status=cast(BackendHealthStatus, data["status"]),
            checked_at=str(data["checked_at"]),
            source=str(data["source"]),
            network_accessed=bool(data.get("network_accessed", False)),
            credential_profile_id=data.get("credential_profile_id"),
            target_id=data.get("target_id"),
            target_snapshot_hash=data.get("target_snapshot_hash"),
            calibration_snapshot_hash=data.get("calibration_snapshot_hash"),
            package_schema=data.get("package_schema"),
            expected_failure_modes=tuple(
                str(item) for item in data.get("expected_failure_modes", ())
            ),
            observed_failure_modes=tuple(
                str(item) for item in data.get("observed_failure_modes", ())
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> BackendHealthIR:
        """Build a backend health snapshot from JSON text."""
        return cls.from_dict(_json_object(text, "BackendHealthIR"))


@dataclass(frozen=True)
class ReadinessCheckResultIR(IRMixin):
    """Aggregated offline readiness check result."""

    check_result_id: str
    manifest_id: str
    backend_id: str
    status: BackendHealthStatus
    backend_health: BackendHealthIR
    diagnostics: tuple[DiagnosticsIR, ...]
    credential_profile_id: str | None = None
    target_id: str | None = None
    target_snapshot_hash: str | None = None
    calibration_snapshot_hash: str | None = None
    package_schema: str | None = None
    expected_failure_mode_coverage: dict[str, Any] = field(default_factory=dict)
    network_accessed: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize nested diagnostics and enforce offline-only results."""
        if self.network_accessed:
            raise ValueError("ReadinessCheckResultIR cannot record network access.")
        if self.status not in _BACKEND_HEALTH_STATUSES:
            raise ValueError(f"Unsupported readiness result status: {self.status}")
        object.__setattr__(
            self,
            "diagnostics",
            tuple(_diagnostic_from_any(item) for item in self.diagnostics),
        )
        object.__setattr__(
            self,
            "expected_failure_mode_coverage",
            _redact_mapping(self.expected_failure_mode_coverage),
        )
        object.__setattr__(self, "metadata", _redact_mapping(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ReadinessCheckResultIR:
        """Build a readiness check result from a dictionary."""
        return cls(
            check_result_id=str(data["check_result_id"]),
            manifest_id=str(data["manifest_id"]),
            backend_id=str(data["backend_id"]),
            status=cast(BackendHealthStatus, data["status"]),
            backend_health=_backend_health_from_any(data["backend_health"]),
            diagnostics=tuple(
                _diagnostic_from_any(item) for item in data.get("diagnostics", ())
            ),
            credential_profile_id=data.get("credential_profile_id"),
            target_id=data.get("target_id"),
            target_snapshot_hash=data.get("target_snapshot_hash"),
            calibration_snapshot_hash=data.get("calibration_snapshot_hash"),
            package_schema=data.get("package_schema"),
            expected_failure_mode_coverage=dict(
                data.get("expected_failure_mode_coverage", {})
            ),
            network_accessed=bool(data.get("network_accessed", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> ReadinessCheckResultIR:
        """Build a readiness check result from JSON text."""
        return cls.from_dict(_json_object(text, "ReadinessCheckResultIR"))


class BackendHealthProviderProtocol(Protocol):
    """Protocol for offline or explicit opt-in backend health providers."""

    def check_health(
        self,
        manifest: HardwareSmokeManifestIR | CloudReadinessManifestIR,
        *,
        credential_profile: CredentialProfileIR | None = None,
    ) -> BackendHealthIR:
        """Return a backend health snapshot for a readiness manifest."""


@dataclass(frozen=True)
class FakeBackendHealthProvider:
    """Deterministic offline health provider used by default tests."""

    default_status: BackendHealthStatus = "unknown"
    checked_at: str = "offline"
    source: str = "fake_offline"
    status_by_backend_id: dict[str, BackendHealthStatus] = field(
        default_factory=dict
    )

    def __post_init__(self) -> None:
        """Validate configured fake statuses."""
        statuses = {
            str(backend_id): status
            for backend_id, status in self.status_by_backend_id.items()
        }
        if self.default_status not in _BACKEND_HEALTH_STATUSES:
            raise ValueError(
                f"Unsupported backend health status: {self.default_status}"
            )
        unsupported = [
            status
            for status in statuses.values()
            if status not in _BACKEND_HEALTH_STATUSES
        ]
        if unsupported:
            raise ValueError(f"Unsupported backend health status: {unsupported[0]}")
        object.__setattr__(self, "status_by_backend_id", statuses)

    def check_health(
        self,
        manifest: HardwareSmokeManifestIR | CloudReadinessManifestIR,
        *,
        credential_profile: CredentialProfileIR | None = None,
    ) -> BackendHealthIR:
        """Return a deterministic offline health snapshot."""
        if not isinstance(
            manifest,
            (HardwareSmokeManifestIR, CloudReadinessManifestIR),
        ):
            raise TypeError("check_health accepts a readiness manifest.")
        if credential_profile is not None and not isinstance(
            credential_profile,
            CredentialProfileIR,
        ):
            raise TypeError("credential_profile must be CredentialProfileIR or None.")
        status = self.status_by_backend_id.get(manifest.backend_id, self.default_status)
        return BackendHealthIR(
            health_id=f"health.{manifest.manifest_id}",
            backend_id=manifest.backend_id,
            backend_kind=_backend_kind(manifest),
            status=status,
            checked_at=self.checked_at,
            source=self.source,
            network_accessed=False,
            credential_profile_id=(
                None
                if credential_profile is None
                else credential_profile.credential_profile_id
            ),
            target_id=manifest.target_id,
            target_snapshot_hash=manifest.target_snapshot_hash,
            calibration_snapshot_hash=manifest.calibration_snapshot_hash,
            package_schema=manifest.package_schema,
            expected_failure_modes=manifest.expected_failure_modes,
            observed_failure_modes=_observed_failure_modes(manifest, status),
            metadata={
                "provider": "FakeBackendHealthProvider",
                "offline": True,
                "live_submission": False,
            },
        )


@dataclass(frozen=True)
class LiveSmokeProfileIR(IRMixin):
    """Explicit opt-in profile for future live smoke preflight checks."""

    live_smoke_profile_id: str
    provider: str
    backend_id: str
    backend_kind: BackendKind
    target_id: str | None = None
    calibration_profile_id: str | None = None
    endpoint_profile_id: str | None = None
    credential_ref: CredentialRefIR | None = None
    required_scopes: tuple[str, ...] = ()
    opt_in_marker: str | None = None
    reason: str | None = None
    enabled: bool = False
    network_access_required: bool = True
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize tuple metadata and redact profile fields."""
        if self.backend_kind not in ("hardware", "cloud"):
            raise ValueError(
                f"Unsupported live smoke backend kind: {self.backend_kind}"
            )
        object.__setattr__(
            self,
            "required_scopes",
            tuple(str(scope) for scope in self.required_scopes),
        )
        object.__setattr__(self, "metadata", _redact_mapping(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> LiveSmokeProfileIR:
        """Build a live smoke profile from a JSON-compatible dictionary."""
        return cls(
            live_smoke_profile_id=str(data["live_smoke_profile_id"]),
            provider=str(data["provider"]),
            backend_id=str(data["backend_id"]),
            backend_kind=cast(BackendKind, data["backend_kind"]),
            target_id=data.get("target_id"),
            calibration_profile_id=data.get("calibration_profile_id"),
            endpoint_profile_id=data.get("endpoint_profile_id"),
            credential_ref=_credential_from_optional(data.get("credential_ref")),
            required_scopes=tuple(
                str(scope) for scope in data.get("required_scopes", ())
            ),
            opt_in_marker=data.get("opt_in_marker"),
            reason=data.get("reason"),
            enabled=bool(data.get("enabled", False)),
            network_access_required=bool(data.get("network_access_required", True)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> LiveSmokeProfileIR:
        """Build a live smoke profile from JSON text."""
        return cls.from_dict(_json_object(text, "LiveSmokeProfileIR"))


@dataclass(frozen=True)
class LiveSmokePreflightIR(IRMixin):
    """Deterministic live smoke preflight result without endpoint access."""

    preflight_id: str
    live_smoke_profile: LiveSmokeProfileIR
    status: LiveSmokePreflightStatus
    diagnostics: tuple[DiagnosticsIR, ...]
    endpoint_profile_id: str | None = None
    credential_ref_id: str | None = None
    opt_in_marker: str | None = None
    skipped_by_default: bool = True
    network_accessed: bool = False
    raw_secret_loaded: bool = False
    live_smoke_executed: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize nested IRs and enforce preflight-only boundaries."""
        if not isinstance(self.live_smoke_profile, LiveSmokeProfileIR):
            raise TypeError("live_smoke_profile must be LiveSmokeProfileIR.")
        if self.status not in ("skipped", "blocked", "ready"):
            raise ValueError(f"Unsupported live smoke preflight status: {self.status}")
        if self.network_accessed:
            raise ValueError("LiveSmokePreflightIR cannot record network access.")
        if self.raw_secret_loaded:
            raise ValueError("LiveSmokePreflightIR cannot record raw secret loading.")
        if self.live_smoke_executed:
            raise ValueError("LiveSmokePreflightIR cannot execute live smoke.")
        object.__setattr__(
            self,
            "diagnostics",
            tuple(_diagnostic_from_any(item) for item in self.diagnostics),
        )
        object.__setattr__(self, "metadata", _redact_mapping(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> LiveSmokePreflightIR:
        """Build a live smoke preflight result from a dictionary."""
        profile = data["live_smoke_profile"]
        if isinstance(profile, LiveSmokeProfileIR):
            live_smoke_profile = profile
        elif isinstance(profile, dict):
            live_smoke_profile = LiveSmokeProfileIR.from_dict(profile)
        else:
            raise TypeError("live_smoke_profile must be LiveSmokeProfileIR or object.")
        return cls(
            preflight_id=str(data["preflight_id"]),
            live_smoke_profile=live_smoke_profile,
            status=cast(LiveSmokePreflightStatus, data["status"]),
            diagnostics=tuple(
                _diagnostic_from_any(item) for item in data.get("diagnostics", ())
            ),
            endpoint_profile_id=data.get("endpoint_profile_id"),
            credential_ref_id=data.get("credential_ref_id"),
            opt_in_marker=data.get("opt_in_marker"),
            skipped_by_default=bool(data.get("skipped_by_default", True)),
            network_accessed=bool(data.get("network_accessed", False)),
            raw_secret_loaded=bool(data.get("raw_secret_loaded", False)),
            live_smoke_executed=bool(data.get("live_smoke_executed", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> LiveSmokePreflightIR:
        """Build a live smoke preflight result from JSON text."""
        return cls.from_dict(_json_object(text, "LiveSmokePreflightIR"))


def build_live_smoke_preflight(
    profile: LiveSmokeProfileIR,
    *,
    endpoint_profile: Any | None = None,
    credential_profile: CredentialProfileIR | None = None,
    preflight_id: str | None = None,
) -> LiveSmokePreflightIR:
    """Build live smoke preflight diagnostics without performing live checks."""
    if not isinstance(profile, LiveSmokeProfileIR):
        raise TypeError("profile must be LiveSmokeProfileIR.")
    if credential_profile is not None and not isinstance(
        credential_profile,
        CredentialProfileIR,
    ):
        raise TypeError("credential_profile must be CredentialProfileIR or None.")
    diagnostics = [_live_smoke_offline_diagnostic(profile)]
    diagnostics.extend(_live_smoke_profile_diagnostics(profile))
    diagnostics.extend(_live_smoke_endpoint_diagnostics(profile, endpoint_profile))
    diagnostics.extend(_live_smoke_credential_diagnostics(profile, credential_profile))
    status = _live_smoke_status(profile, diagnostics)
    endpoint_profile_id = _endpoint_profile_id(endpoint_profile)
    credential_ref_id = (
        None
        if profile.credential_ref is None
        else profile.credential_ref.credential_ref_id
    )
    return LiveSmokePreflightIR(
        preflight_id=preflight_id or f"live_smoke_preflight.{profile.backend_id}",
        live_smoke_profile=profile,
        status=status,
        diagnostics=tuple(diagnostics),
        endpoint_profile_id=endpoint_profile_id,
        credential_ref_id=credential_ref_id,
        opt_in_marker=profile.opt_in_marker,
        skipped_by_default=True,
        network_accessed=False,
        raw_secret_loaded=False,
        live_smoke_executed=False,
        metadata={
            "provider": profile.provider,
            "backend_id": profile.backend_id,
            "backend_kind": profile.backend_kind,
            "enabled": profile.enabled,
            "endpoint_profile_supplied": endpoint_profile is not None,
            "credential_profile_supplied": credential_profile is not None,
            "preflight_only": True,
            "live_submission": False,
        },
    )


@dataclass(frozen=True)
class HardwareSmokeManifestIR(IRMixin):
    """Opt-in hardware smoke readiness manifest.

    The manifest records what would be checked before live hardware access. It
    does not authorize network access or hardware submission by itself.
    """

    manifest_id: str
    backend_id: str
    target_id: str
    target_snapshot_hash: str
    calibration_snapshot_hash: str
    execution_package_id: str
    execution_package_checksum: str
    package_schema: str
    credential_ref: CredentialRefIR | None = None
    readiness_mode: ReadinessMode = "offline_manifest"
    opt_in_marker: str = "optional_hardware"
    expected_failure_modes: tuple[str, ...] = ()
    required_permissions: tuple[str, ...] = ()
    network_access_required: bool = False
    submission_disabled_by_default: bool = True
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize tuple fields and redact metadata."""
        object.__setattr__(
            self,
            "expected_failure_modes",
            tuple(str(item) for item in self.expected_failure_modes),
        )
        object.__setattr__(
            self,
            "required_permissions",
            tuple(str(item) for item in self.required_permissions),
        )
        object.__setattr__(self, "metadata", _redact_mapping(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> HardwareSmokeManifestIR:
        """Build a hardware smoke manifest from a dictionary."""
        return cls(
            manifest_id=str(data["manifest_id"]),
            backend_id=str(data["backend_id"]),
            target_id=str(data["target_id"]),
            target_snapshot_hash=str(data["target_snapshot_hash"]),
            calibration_snapshot_hash=str(data["calibration_snapshot_hash"]),
            execution_package_id=str(data["execution_package_id"]),
            execution_package_checksum=str(data["execution_package_checksum"]),
            package_schema=str(data["package_schema"]),
            credential_ref=_credential_from_optional(data.get("credential_ref")),
            readiness_mode=cast(
                ReadinessMode,
                data.get("readiness_mode", "offline_manifest"),
            ),
            opt_in_marker=str(data.get("opt_in_marker", "optional_hardware")),
            expected_failure_modes=tuple(
                str(item) for item in data.get("expected_failure_modes", ())
            ),
            required_permissions=tuple(
                str(item) for item in data.get("required_permissions", ())
            ),
            network_access_required=bool(
                data.get("network_access_required", False)
            ),
            submission_disabled_by_default=bool(
                data.get("submission_disabled_by_default", True)
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> HardwareSmokeManifestIR:
        """Build a hardware smoke manifest from JSON text."""
        return cls.from_dict(_json_object(text, "HardwareSmokeManifestIR"))


@dataclass(frozen=True)
class CloudReadinessManifestIR(IRMixin):
    """Opt-in cloud readiness manifest without live network access."""

    manifest_id: str
    cloud_provider: str
    backend_id: str
    target_id: str
    package_schema: str
    api_contracts: tuple[str, ...]
    target_snapshot_hash: str | None = None
    calibration_snapshot_hash: str | None = None
    credential_ref: CredentialRefIR | None = None
    project_ref: str | None = None
    workspace_ref: str | None = None
    readiness_mode: ReadinessMode = "offline_manifest"
    opt_in_marker: str = "optional_cloud"
    expected_failure_modes: tuple[str, ...] = ()
    required_permissions: tuple[str, ...] = ()
    network_access_required: bool = False
    submission_disabled_by_default: bool = True
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize tuple fields and redact metadata."""
        object.__setattr__(
            self,
            "api_contracts",
            tuple(str(item) for item in self.api_contracts),
        )
        object.__setattr__(
            self,
            "expected_failure_modes",
            tuple(str(item) for item in self.expected_failure_modes),
        )
        object.__setattr__(
            self,
            "required_permissions",
            tuple(str(item) for item in self.required_permissions),
        )
        object.__setattr__(self, "metadata", _redact_mapping(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CloudReadinessManifestIR:
        """Build a cloud readiness manifest from a dictionary."""
        return cls(
            manifest_id=str(data["manifest_id"]),
            cloud_provider=str(data["cloud_provider"]),
            backend_id=str(data["backend_id"]),
            target_id=str(data["target_id"]),
            package_schema=str(data["package_schema"]),
            api_contracts=tuple(
                str(item) for item in data.get("api_contracts", ())
            ),
            target_snapshot_hash=data.get("target_snapshot_hash"),
            calibration_snapshot_hash=data.get("calibration_snapshot_hash"),
            credential_ref=_credential_from_optional(data.get("credential_ref")),
            project_ref=data.get("project_ref"),
            workspace_ref=data.get("workspace_ref"),
            readiness_mode=cast(
                ReadinessMode,
                data.get("readiness_mode", "offline_manifest"),
            ),
            opt_in_marker=str(data.get("opt_in_marker", "optional_cloud")),
            expected_failure_modes=tuple(
                str(item) for item in data.get("expected_failure_modes", ())
            ),
            required_permissions=tuple(
                str(item) for item in data.get("required_permissions", ())
            ),
            network_access_required=bool(
                data.get("network_access_required", False)
            ),
            submission_disabled_by_default=bool(
                data.get("submission_disabled_by_default", True)
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> CloudReadinessManifestIR:
        """Build a cloud readiness manifest from JSON text."""
        return cls.from_dict(_json_object(text, "CloudReadinessManifestIR"))


def build_hardware_smoke_manifest(
    submission: HardwareSubmissionIR,
    *,
    backend_id: str,
    credential_ref: CredentialRefIR | None = None,
    manifest_id: str | None = None,
    expected_failure_modes: tuple[str, ...] = (
        "authentication_missing",
        "permission_denied",
        "backend_unavailable",
        "calibration_stale",
        "quota_exceeded",
    ),
) -> HardwareSmokeManifestIR:
    """Build an offline hardware smoke manifest from a public submission."""
    if not isinstance(submission, HardwareSubmissionIR):
        raise TypeError(
            "build_hardware_smoke_manifest accepts HardwareSubmissionIR."
        )
    return HardwareSmokeManifestIR(
        manifest_id=manifest_id or f"readiness.hardware.{submission.submission_id}",
        backend_id=backend_id,
        target_id=submission.requested_target_id,
        target_snapshot_hash=submission.requested_target_snapshot_hash,
        calibration_snapshot_hash="private-service-owned",
        execution_package_id=submission.submission_id,
        execution_package_checksum=submission.checksum,
        package_schema="schemas/hardware_submission.schema.json",
        credential_ref=credential_ref,
        expected_failure_modes=expected_failure_modes,
        required_permissions=("submit:submission", "read:job", "read:result"),
        metadata={
            "source": "HardwareSubmissionIR",
            "submission_id": submission.submission_id,
            "program_type": submission.program_kind,
            "shots": submission.shots,
            "live_submission": False,
            "private_preflight_required": True,
        },
    )


def build_cloud_readiness_manifest(
    submission: HardwareSubmissionIR,
    *,
    backend_id: str,
    cloud_provider: str,
    credential_ref: CredentialRefIR | None = None,
    manifest_id: str | None = None,
    project_ref: str | None = None,
    workspace_ref: str | None = None,
    expected_failure_modes: tuple[str, ...] = (
        "authentication_missing",
        "permission_denied",
        "rate_limited",
        "quota_exceeded",
        "cloud_backend_unavailable",
        "artifact_retention_unconfigured",
    ),
) -> CloudReadinessManifestIR:
    """Build an offline cloud readiness manifest from a public submission."""
    if not isinstance(submission, HardwareSubmissionIR):
        raise TypeError(
            "build_cloud_readiness_manifest accepts HardwareSubmissionIR."
        )
    return CloudReadinessManifestIR(
        manifest_id=manifest_id or f"readiness.cloud.{submission.submission_id}",
        cloud_provider=cloud_provider,
        backend_id=backend_id,
        target_id=submission.requested_target_id,
        target_snapshot_hash=submission.requested_target_snapshot_hash,
        calibration_snapshot_hash=None,
        package_schema="schemas/hardware_submission.schema.json",
        api_contracts=(
            "CloudSubmitPackageRequestIR",
            "CloudSubmitPackageResponseIR",
            "CloudJobRecordResponseIR",
            "CloudResultRecordResponseIR",
        ),
        credential_ref=credential_ref,
        project_ref=project_ref,
        workspace_ref=workspace_ref,
        expected_failure_modes=expected_failure_modes,
        required_permissions=(
            "cloud:submit_submission",
            "cloud:read_job",
            "cloud:read_result",
            "cloud:list_artifacts",
        ),
        metadata={
            "source": "HardwareSubmissionIR",
            "submission_id": submission.submission_id,
            "submission_checksum": submission.checksum,
            "program_type": submission.program_kind,
            "shots": submission.shots,
            "live_submission": False,
            "private_preflight_required": True,
        },
    )


def diagnose_backend_readiness(
    manifest: HardwareSmokeManifestIR | CloudReadinessManifestIR,
    *,
    submission: HardwareSubmissionIR | None = None,
) -> tuple[DiagnosticsIR, ...]:
    """Return offline diagnostics for a hardware or cloud readiness manifest."""
    if not isinstance(manifest, (HardwareSmokeManifestIR, CloudReadinessManifestIR)):
        raise TypeError("diagnose_backend_readiness accepts a readiness manifest.")
    diagnostics = [
        _diagnostic(
            diagnostic_id=f"diagnostic.{manifest.manifest_id}.offline",
            severity="info",
            code="READINESS_MANIFEST_OFFLINE",
            message=(
                "Readiness manifest is metadata-only and does not access "
                "network, hardware, or raw credentials."
            ),
            metadata={
                "manifest_id": manifest.manifest_id,
                "backend_id": manifest.backend_id,
                "readiness_mode": manifest.readiness_mode,
            },
        )
    ]
    diagnostics.extend(_common_manifest_diagnostics(manifest))
    if submission is not None:
        diagnostics.extend(_submission_diagnostics(manifest, submission))
    return tuple(diagnostics)


def check_backend_readiness(
    manifest: HardwareSmokeManifestIR | CloudReadinessManifestIR,
    *,
    submission: HardwareSubmissionIR | None = None,
    credential_profile: CredentialProfileIR | None = None,
    health_provider: BackendHealthProviderProtocol | None = None,
) -> ReadinessCheckResultIR:
    """Aggregate offline manifest diagnostics and backend health metadata."""
    if not isinstance(manifest, (HardwareSmokeManifestIR, CloudReadinessManifestIR)):
        raise TypeError("check_backend_readiness accepts a readiness manifest.")
    if submission is not None and not isinstance(submission, HardwareSubmissionIR):
        raise TypeError("submission must be HardwareSubmissionIR.")
    if credential_profile is not None and not isinstance(
        credential_profile,
        CredentialProfileIR,
    ):
        raise TypeError("credential_profile must be CredentialProfileIR or None.")
    provider = health_provider or FakeBackendHealthProvider()
    health = provider.check_health(
        manifest,
        credential_profile=credential_profile,
    )
    diagnostics = list(
        diagnose_backend_readiness(manifest, submission=submission)
    )
    diagnostics.extend(_health_diagnostics(manifest, health))
    if credential_profile is not None:
        diagnostics.extend(
            validate_credential_profile(
                credential_profile,
                _credential_requirement_from_manifest(
                    manifest,
                    credential_profile=credential_profile,
                ),
            )
        )
    return ReadinessCheckResultIR(
        check_result_id=f"readiness_check.{manifest.manifest_id}",
        manifest_id=manifest.manifest_id,
        backend_id=manifest.backend_id,
        status=_readiness_status(health.status, diagnostics),
        backend_health=health,
        diagnostics=tuple(diagnostics),
        credential_profile_id=(
            None
            if credential_profile is None
            else credential_profile.credential_profile_id
        ),
        target_id=manifest.target_id,
        target_snapshot_hash=manifest.target_snapshot_hash,
        calibration_snapshot_hash=manifest.calibration_snapshot_hash,
        package_schema=manifest.package_schema,
        expected_failure_mode_coverage=_expected_failure_mode_coverage(
            manifest.expected_failure_modes,
            health.observed_failure_modes,
        ),
        network_accessed=health.network_accessed,
        metadata={
            "readiness_mode": manifest.readiness_mode,
            "backend_kind": _backend_kind(manifest),
            "health_source": health.source,
            "live_submission": False,
            "hardware_readiness": manifest.metadata.get(
                "hardware_readiness",
                {},
            ),
        },
    )


def _common_manifest_diagnostics(
    manifest: HardwareSmokeManifestIR | CloudReadinessManifestIR,
) -> list[DiagnosticsIR]:
    diagnostics: list[DiagnosticsIR] = []
    if not manifest.submission_disabled_by_default:
        diagnostics.append(
            _diagnostic(
                diagnostic_id=(
                    f"diagnostic.{manifest.manifest_id}."
                    "submission_enabled"
                ),
                severity="error",
                code="READINESS_SUBMISSION_ENABLED",
                message="Readiness manifests must disable submission by default.",
                suggestion="Set submission_disabled_by_default=True.",
            )
        )
    if manifest.network_access_required and manifest.readiness_mode != "live_opt_in":
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"diagnostic.{manifest.manifest_id}.network_mode",
                severity="error",
                code="READINESS_NETWORK_REQUIRES_LIVE_OPT_IN",
                message=(
                    "Network access is only valid for explicit live opt-in "
                    "manifests."
                ),
                suggestion="Use readiness_mode='live_opt_in' for live smoke tests.",
            )
        )
    if not manifest.expected_failure_modes:
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"diagnostic.{manifest.manifest_id}.failure_modes",
                severity="warning",
                code="READINESS_EXPECTED_FAILURE_MODES_MISSING",
                message="Readiness manifest should document expected failure modes.",
                suggestion=(
                    "Add authentication, permission, quota, and availability modes."
                ),
            )
        )
    if manifest.credential_ref is None:
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"diagnostic.{manifest.manifest_id}.credential",
                severity="warning",
                code="READINESS_CREDENTIAL_REF_MISSING",
                message="No credential reference is attached to this manifest.",
                suggestion="Attach CredentialRefIR when preparing opt-in live checks.",
            )
        )
    elif manifest.credential_ref.raw_secret_loaded:
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"diagnostic.{manifest.manifest_id}.raw_secret",
                severity="error",
                code="READINESS_RAW_SECRET_LOADED",
                message="CredentialRefIR must not contain raw secret material.",
            )
        )
    return diagnostics


def _health_diagnostics(
    manifest: HardwareSmokeManifestIR | CloudReadinessManifestIR,
    health: BackendHealthIR,
) -> list[DiagnosticsIR]:
    diagnostics: list[DiagnosticsIR] = []
    if not isinstance(health, BackendHealthIR):
        raise TypeError("health provider must return BackendHealthIR.")
    if health.network_accessed:
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"diagnostic.{manifest.manifest_id}.health_network",
                severity="error",
                code="READINESS_HEALTH_NETWORK_ACCESSED",
                message="Default readiness health checks must not access network.",
                object_path="backend_health.network_accessed",
            )
        )
    if health.backend_id != manifest.backend_id:
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"diagnostic.{manifest.manifest_id}.health_backend",
                severity="error",
                code="READINESS_HEALTH_BACKEND_MISMATCH",
                message="Backend health snapshot does not match manifest backend.",
                object_path="backend_health.backend_id",
                metadata={
                    "manifest_backend_id": manifest.backend_id,
                    "health_backend_id": health.backend_id,
                },
            )
        )
    if health.target_id not in (None, manifest.target_id):
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"diagnostic.{manifest.manifest_id}.health_target",
                severity="error",
                code="READINESS_HEALTH_TARGET_MISMATCH",
                message="Backend health target does not match manifest target.",
                object_path="backend_health.target_id",
            )
        )
    if health.status == "unknown":
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"diagnostic.{manifest.manifest_id}.health_unknown",
                severity="info",
                code="READINESS_HEALTH_UNKNOWN",
                message="Backend health is unknown in offline fake provider mode.",
                object_path="backend_health.status",
            )
        )
    elif health.status == "degraded":
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"diagnostic.{manifest.manifest_id}.health_degraded",
                severity="warning",
                code="READINESS_HEALTH_DEGRADED",
                message="Backend health snapshot reports degraded status.",
                object_path="backend_health.status",
            )
        )
    elif health.status == "unavailable":
        diagnostics.append(
            _diagnostic(
                diagnostic_id=(
                    f"diagnostic.{manifest.manifest_id}.health_unavailable"
                ),
                severity="error",
                code="READINESS_HEALTH_UNAVAILABLE",
                message="Backend health snapshot reports unavailable status.",
                object_path="backend_health.status",
            )
        )
    return diagnostics


def _credential_requirement_from_manifest(
    manifest: HardwareSmokeManifestIR | CloudReadinessManifestIR,
    *,
    credential_profile: CredentialProfileIR,
) -> CredentialRequirementIR:
    return CredentialRequirementIR(
        requirement_id=f"credential_requirement.{manifest.manifest_id}",
        provider=_credential_requirement_provider(manifest),
        operation="readiness_check",
        required_scopes=manifest.required_permissions,
        allowed_reference_kinds=("env_var", "profile", "keychain", "secret_manager"),
    )


def _credential_requirement_provider(
    manifest: HardwareSmokeManifestIR | CloudReadinessManifestIR,
) -> str:
    if manifest.credential_ref is not None:
        return manifest.credential_ref.provider
    if isinstance(manifest, CloudReadinessManifestIR):
        return manifest.cloud_provider
    return manifest.backend_id


def _submission_diagnostics(
    manifest: HardwareSmokeManifestIR | CloudReadinessManifestIR,
    submission: HardwareSubmissionIR,
) -> list[DiagnosticsIR]:
    """Validate only facts available on the public submission boundary."""
    checks = {
        "target_id": (manifest.target_id, submission.requested_target_id),
        "target_snapshot_hash": (
            manifest.target_snapshot_hash,
            submission.requested_target_snapshot_hash,
        ),
    }
    if isinstance(manifest, HardwareSmokeManifestIR):
        checks.update(
            {
                "submission_id": (
                    manifest.execution_package_id,
                    submission.submission_id,
                ),
                "submission_checksum": (
                    manifest.execution_package_checksum,
                    submission.checksum,
                ),
            }
        )
    diagnostics: list[DiagnosticsIR] = []
    for field_name, (manifest_value, submission_value) in checks.items():
        if manifest_value == submission_value:
            continue
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"diagnostic.{manifest.manifest_id}.{field_name}",
                severity="error",
                code="READINESS_SUBMISSION_MISMATCH",
                message=(
                    f"Readiness manifest {field_name} does not match submission."
                ),
                object_path=field_name,
                suggestion=(
                    "Regenerate the readiness manifest from the current submission."
                ),
                metadata={
                    "manifest_value": manifest_value,
                    "submission_value": submission_value,
                },
            )
        )
    return diagnostics


def _backend_kind(
    manifest: HardwareSmokeManifestIR | CloudReadinessManifestIR,
) -> BackendKind:
    if isinstance(manifest, HardwareSmokeManifestIR):
        return "hardware"
    return "cloud"


def _observed_failure_modes(
    manifest: HardwareSmokeManifestIR | CloudReadinessManifestIR,
    status: BackendHealthStatus,
) -> tuple[str, ...]:
    if status in ("unknown", "available"):
        return ()
    if status == "degraded":
        if isinstance(manifest, CloudReadinessManifestIR):
            return ("rate_limited",)
        return ("calibration_stale",)
    if isinstance(manifest, CloudReadinessManifestIR):
        return ("cloud_backend_unavailable",)
    return ("backend_unavailable",)


def _expected_failure_mode_coverage(
    expected_failure_modes: tuple[str, ...],
    observed_failure_modes: tuple[str, ...],
) -> dict[str, Any]:
    expected = tuple(str(item) for item in expected_failure_modes)
    observed = tuple(str(item) for item in observed_failure_modes)
    covered = tuple(item for item in observed if item in expected)
    missing = tuple(item for item in expected if item not in observed)
    return {
        "expected": list(expected),
        "observed": list(observed),
        "covered": list(covered),
        "missing": list(missing),
        "coverage_ratio": 1.0 if not expected else len(covered) / len(expected),
    }


def _readiness_status(
    health_status: BackendHealthStatus,
    diagnostics: list[DiagnosticsIR],
) -> BackendHealthStatus:
    if any(diagnostic.severity == "error" for diagnostic in diagnostics):
        return "unavailable"
    if health_status == "available" and any(
        diagnostic.severity == "warning" for diagnostic in diagnostics
    ):
        return "degraded"
    return health_status


def _live_smoke_offline_diagnostic(profile: LiveSmokeProfileIR) -> DiagnosticsIR:
    return _diagnostic(
        diagnostic_id=f"diagnostic.{profile.live_smoke_profile_id}.preflight",
        severity="info",
        code="LIVE_SMOKE_PREFLIGHT_ONLY",
        message=(
            "Live smoke preflight is deterministic and does not access network, "
            "hardware, cloud services, or raw credentials."
        ),
        metadata={
            "live_smoke_profile_id": profile.live_smoke_profile_id,
            "backend_id": profile.backend_id,
            "enabled": profile.enabled,
            "network_accessed": False,
            "raw_secret_loaded": False,
            "live_smoke_executed": False,
        },
    )


def _live_smoke_profile_diagnostics(
    profile: LiveSmokeProfileIR,
) -> list[DiagnosticsIR]:
    diagnostics: list[DiagnosticsIR] = []
    if not profile.enabled:
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"diagnostic.{profile.live_smoke_profile_id}.disabled",
                severity="warning",
                code="LIVE_SMOKE_PROFILE_DISABLED",
                message="Live smoke profile is disabled and will be skipped.",
                object_path="enabled",
                suggestion="Set enabled=True only for explicit optional live smoke.",
            )
        )
    if not profile.opt_in_marker:
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"diagnostic.{profile.live_smoke_profile_id}.marker",
                severity="error",
                code="LIVE_SMOKE_OPT_IN_MARKER_MISSING",
                message="Live smoke requires an explicit opt-in marker.",
                object_path="opt_in_marker",
            )
        )
    if profile.opt_in_marker not in (None, "optional_hardware", "optional_cloud"):
        diagnostics.append(
            _diagnostic(
                diagnostic_id=(
                    f"diagnostic.{profile.live_smoke_profile_id}.marker_kind"
                ),
                severity="error",
                code="LIVE_SMOKE_OPT_IN_MARKER_UNSUPPORTED",
                message=(
                    "Live smoke opt-in marker must be optional_hardware "
                    "or optional_cloud."
                ),
                object_path="opt_in_marker",
                metadata={"opt_in_marker": profile.opt_in_marker},
            )
        )
    if profile.backend_kind == "hardware" and profile.opt_in_marker == "optional_cloud":
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"diagnostic.{profile.live_smoke_profile_id}.marker_cloud",
                severity="error",
                code="LIVE_SMOKE_MARKER_BACKEND_KIND_MISMATCH",
                message="Hardware live smoke profiles must use optional_hardware.",
                object_path="opt_in_marker",
            )
        )
    if profile.backend_kind == "cloud" and profile.opt_in_marker == "optional_hardware":
        diagnostics.append(
            _diagnostic(
                diagnostic_id=(
                    f"diagnostic.{profile.live_smoke_profile_id}.marker_hardware"
                ),
                severity="error",
                code="LIVE_SMOKE_MARKER_BACKEND_KIND_MISMATCH",
                message="Cloud live smoke profiles must use optional_cloud.",
                object_path="opt_in_marker",
            )
        )
    if not profile.endpoint_profile_id:
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"diagnostic.{profile.live_smoke_profile_id}.endpoint",
                severity="error",
                code="LIVE_SMOKE_ENDPOINT_PROFILE_MISSING",
                message="Live smoke requires an endpoint profile reference.",
                object_path="endpoint_profile_id",
            )
        )
    if profile.credential_ref is None:
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"diagnostic.{profile.live_smoke_profile_id}.credential",
                severity="error",
                code="LIVE_SMOKE_CREDENTIAL_REF_MISSING",
                message="Live smoke requires a credential reference.",
                object_path="credential_ref",
            )
        )
    elif profile.credential_ref.raw_secret_loaded:
        diagnostics.append(
            _diagnostic(
                diagnostic_id=(
                    f"diagnostic.{profile.live_smoke_profile_id}.raw_secret"
                ),
                severity="error",
                code="LIVE_SMOKE_RAW_SECRET_LOADED",
                message=(
                    "Live smoke credential references must not contain raw "
                    "secrets."
                ),
                object_path="credential_ref.raw_secret_loaded",
            )
        )
    if not profile.required_scopes:
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"diagnostic.{profile.live_smoke_profile_id}.scopes",
                severity="error",
                code="LIVE_SMOKE_REQUIRED_SCOPES_MISSING",
                message="Live smoke requires explicit provider scopes.",
                object_path="required_scopes",
            )
        )
    return diagnostics


def _live_smoke_endpoint_diagnostics(
    profile: LiveSmokeProfileIR,
    endpoint_profile: Any | None,
) -> list[DiagnosticsIR]:
    diagnostics: list[DiagnosticsIR] = []
    if endpoint_profile is None:
        diagnostics.append(
            _diagnostic(
                diagnostic_id=(
                    f"diagnostic.{profile.live_smoke_profile_id}."
                    "endpoint_profile_missing"
                ),
                severity="error",
                code="LIVE_SMOKE_ENDPOINT_PROFILE_NOT_SUPPLIED",
                message="Live smoke preflight requires the endpoint profile object.",
                object_path="endpoint_profile",
            )
        )
        return diagnostics
    endpoint_profile_id = _endpoint_profile_id(endpoint_profile)
    if profile.endpoint_profile_id not in (None, endpoint_profile_id):
        diagnostics.append(
            _diagnostic(
                diagnostic_id=(
                    f"diagnostic.{profile.live_smoke_profile_id}."
                    "endpoint_profile_mismatch"
                ),
                severity="error",
                code="LIVE_SMOKE_ENDPOINT_PROFILE_MISMATCH",
                message="Live smoke profile does not match supplied endpoint profile.",
                object_path="endpoint_profile_id",
                metadata={
                    "profile_endpoint_profile_id": profile.endpoint_profile_id,
                    "endpoint_profile_id": endpoint_profile_id,
                },
            )
        )
    if _endpoint_attr(endpoint_profile, "execution_mode") != "live_opt_in":
        diagnostics.append(
            _diagnostic(
                diagnostic_id=(
                    f"diagnostic.{profile.live_smoke_profile_id}."
                    "endpoint_mode"
                ),
                severity="error",
                code="LIVE_SMOKE_ENDPOINT_NOT_LIVE_OPT_IN",
                message="Live smoke requires endpoint execution_mode='live_opt_in'.",
                object_path="endpoint_profile.execution_mode",
                metadata={
                    "execution_mode": _endpoint_attr(
                        endpoint_profile,
                        "execution_mode",
                    )
                },
            )
        )
    if _endpoint_attr(endpoint_profile, "network_access_required") is not True:
        diagnostics.append(
            _diagnostic(
                diagnostic_id=(
                    f"diagnostic.{profile.live_smoke_profile_id}."
                    "endpoint_network"
                ),
                severity="error",
                code="LIVE_SMOKE_ENDPOINT_NETWORK_DISABLED",
                message="Live smoke endpoint profile must require network access.",
                object_path="endpoint_profile.network_access_required",
            )
        )
    if not _endpoint_attr(endpoint_profile, "endpoint_allowlist"):
        diagnostics.append(
            _diagnostic(
                diagnostic_id=(
                    f"diagnostic.{profile.live_smoke_profile_id}."
                    "endpoint_allowlist"
                ),
                severity="error",
                code="LIVE_SMOKE_ENDPOINT_ALLOWLIST_MISSING",
                message="Live smoke requires an endpoint allowlist.",
                object_path="endpoint_profile.endpoint_allowlist",
            )
        )
    if not _endpoint_attr(endpoint_profile, "credential_ref"):
        diagnostics.append(
            _diagnostic(
                diagnostic_id=(
                    f"diagnostic.{profile.live_smoke_profile_id}."
                    "endpoint_credential"
                ),
                severity="error",
                code="LIVE_SMOKE_ENDPOINT_CREDENTIAL_REF_MISSING",
                message="Endpoint profile must carry a credential reference.",
                object_path="endpoint_profile.credential_ref",
            )
        )
    return diagnostics


def _live_smoke_credential_diagnostics(
    profile: LiveSmokeProfileIR,
    credential_profile: CredentialProfileIR | None,
) -> list[DiagnosticsIR]:
    diagnostics: list[DiagnosticsIR] = []
    if credential_profile is None:
        diagnostics.append(
            _diagnostic(
                diagnostic_id=(
                    f"diagnostic.{profile.live_smoke_profile_id}."
                    "credential_profile_missing"
                ),
                severity="error",
                code="LIVE_SMOKE_CREDENTIAL_PROFILE_NOT_SUPPLIED",
                message="Live smoke preflight requires a credential profile object.",
                object_path="credential_profile",
            )
        )
        return diagnostics
    if credential_profile.status != "configured":
        diagnostics.append(
            _diagnostic(
                diagnostic_id=(
                    f"diagnostic.{profile.live_smoke_profile_id}."
                    "credential_status"
                ),
                severity="error",
                code="LIVE_SMOKE_CREDENTIAL_PROFILE_NOT_CONFIGURED",
                message="Live smoke credential profile must be configured.",
                object_path="credential_profile.status",
            )
        )
    if profile.credential_ref is not None and (
        credential_profile.credential_ref.credential_ref_id
        != profile.credential_ref.credential_ref_id
    ):
        diagnostics.append(
            _diagnostic(
                diagnostic_id=(
                    f"diagnostic.{profile.live_smoke_profile_id}."
                    "credential_mismatch"
                ),
                severity="error",
                code="LIVE_SMOKE_CREDENTIAL_REF_MISMATCH",
                message="Credential profile does not match live smoke credential ref.",
                object_path="credential_profile.credential_ref",
            )
        )
    missing_scopes = sorted(
        set(profile.required_scopes)
        - set(credential_profile.credential_ref.required_scopes)
    )
    if missing_scopes:
        diagnostics.append(
            _diagnostic(
                diagnostic_id=(
                    f"diagnostic.{profile.live_smoke_profile_id}."
                    "credential_scopes"
                ),
                severity="error",
                code="LIVE_SMOKE_CREDENTIAL_SCOPE_MISSING",
                message="Credential profile is missing live smoke scopes.",
                object_path="credential_profile.credential_ref.required_scopes",
                metadata={"missing_scopes": missing_scopes},
            )
        )
    return diagnostics


def _live_smoke_status(
    profile: LiveSmokeProfileIR,
    diagnostics: list[DiagnosticsIR],
) -> LiveSmokePreflightStatus:
    if not profile.enabled:
        return "skipped"
    if any(diagnostic.severity == "error" for diagnostic in diagnostics):
        return "blocked"
    return "ready"


def _endpoint_profile_id(endpoint_profile: Any | None) -> str | None:
    if endpoint_profile is None:
        return None
    profile_id = getattr(endpoint_profile, "endpoint_profile_id", None)
    if profile_id is not None:
        return str(profile_id)
    cloud_profile_id = getattr(endpoint_profile, "cloud_endpoint_profile_id", None)
    if cloud_profile_id is not None:
        return str(cloud_profile_id)
    return None


def _endpoint_attr(endpoint_profile: Any, name: str) -> Any:
    if hasattr(endpoint_profile, name):
        return getattr(endpoint_profile, name)
    if isinstance(endpoint_profile, dict):
        return endpoint_profile.get(name)
    return None


def _backend_health_from_any(value: Any) -> BackendHealthIR:
    if isinstance(value, BackendHealthIR):
        return value
    if isinstance(value, dict):
        return BackendHealthIR.from_dict(value)
    raise TypeError("backend_health must be BackendHealthIR or object.")


def _diagnostic_from_any(value: Any) -> DiagnosticsIR:
    if isinstance(value, DiagnosticsIR):
        return value
    if isinstance(value, dict):
        return DiagnosticsIR.from_dict(value)
    raise TypeError("diagnostics must contain DiagnosticsIR objects.")


def _diagnostic(
    *,
    diagnostic_id: str,
    severity: Literal["info", "warning", "error"],
    code: str,
    message: str,
    object_path: str | None = None,
    suggestion: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> DiagnosticsIR:
    return with_diagnostic_taxonomy(
        DiagnosticsIR(
            diagnostic_id=diagnostic_id,
            stage="validation",
            severity=severity,
            code=code,
            message=message,
            object_path=object_path,
            suggestion=suggestion,
            metadata={} if metadata is None else metadata,
        ),
        reason_category="backend",
        action="resolve_backend_readiness",
    )


def _credential_from_optional(value: Any) -> CredentialRefIR | None:
    if value is None:
        return None
    if isinstance(value, CredentialRefIR):
        return value
    if isinstance(value, dict):
        return CredentialRefIR.from_dict(value)
    raise TypeError("credential_ref must be CredentialRefIR, object, or null.")


def _json_object(text: str, model_name: str) -> dict[str, Any]:
    data = json.loads(text)
    if not isinstance(data, dict):
        raise TypeError(f"{model_name} JSON must contain an object.")
    return data


def _redact_mapping(data: dict[str, Any]) -> dict[str, Any]:
    redacted: dict[str, Any] = {}
    for key, value in data.items():
        lowered = str(key).lower()
        if any(token in lowered for token in _SECRET_KEY_MARKERS):
            redacted[str(key)] = "<redacted>"
        else:
            redacted[str(key)] = _redact_value(value)
    return redacted


def _redact_value(value: Any) -> Any:
    if isinstance(value, dict):
        return _redact_mapping(value)
    if isinstance(value, list):
        return [_redact_value(item) for item in value]
    if isinstance(value, tuple):
        return tuple(_redact_value(item) for item in value)
    return value
