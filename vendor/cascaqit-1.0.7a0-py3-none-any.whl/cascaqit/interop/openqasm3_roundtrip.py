"""Restricted OpenQASM 3 import/export round-trip proof helpers."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Literal

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.digital import DigitalProgramIR
from cascaqit.interop.openqasm3_export import (
    OpenQASM3ExportResultIR,
    render_openqasm3_subset,
)
from cascaqit.interop.openqasm3_subset import (
    OpenQASM3SubsetImportResultIR,
    parse_openqasm3_subset,
)
from cascaqit.native_ir.base import IRMixin, canonicalize
from cascaqit.native_ir.models import SCHEMA_VERSION
from cascaqit.simulators.equivalence import (
    DigitalSemanticEquivalenceReportIR,
    compare_digital_program_semantics,
)

if TYPE_CHECKING:
    from cascaqit.native_ir.models import ProgramIR

__all__ = [
    "OpenQASM3RoundTripReportIR",
    "OpenQASM3RoundTripSemanticSummaryIR",
    "OpenQASM3SourceMapReviewIR",
    "OpenQASM3SourceMapReviewEntryIR",
    "build_openqasm3_source_map_review",
    "prove_openqasm3_round_trip",
]

RoundTripStatus = Literal["passed", "blocked", "failed"]
SourceMapReviewStatus = Literal["aligned", "blocked", "drifted"]
SourceMapMappingKind = Literal["direct", "lowered", "blocked"]


@dataclass(frozen=True)
class OpenQASM3RoundTripSemanticSummaryIR(IRMixin):
    """Comparable semantic summary for a digital OpenQASM round trip."""

    program_id: str
    program_hash: str
    qubits: tuple[str, ...]
    gates: tuple[dict[str, Any], ...]
    measurements: tuple[dict[str, Any], ...]
    bit_order: dict[str, Any]
    measurement_mapping: dict[str, Any]
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = SCHEMA_VERSION

    def __post_init__(self) -> None:
        """Normalize summary payload for deterministic comparison."""
        object.__setattr__(self, "qubits", tuple(str(qubit) for qubit in self.qubits))
        object.__setattr__(
            self,
            "gates",
            tuple(canonicalize(dict(gate)) for gate in self.gates),
        )
        object.__setattr__(
            self,
            "measurements",
            tuple(canonicalize(dict(measurement)) for measurement in self.measurements),
        )
        object.__setattr__(self, "bit_order", canonicalize(self.bit_order))
        object.__setattr__(
            self,
            "measurement_mapping",
            canonicalize(self.measurement_mapping),
        )
        object.__setattr__(self, "metadata", canonicalize(self.metadata))

    @classmethod
    def from_dict(
        cls,
        data: dict[str, Any],
    ) -> OpenQASM3RoundTripSemanticSummaryIR:
        """Build a semantic summary from a JSON-compatible dictionary."""
        return cls(
            program_id=str(data["program_id"]),
            program_hash=str(data["program_hash"]),
            qubits=tuple(str(qubit) for qubit in data.get("qubits", ())),
            gates=tuple(dict(gate) for gate in data.get("gates", ())),
            measurements=tuple(
                dict(measurement) for measurement in data.get("measurements", ())
            ),
            bit_order=dict(data.get("bit_order", {})),
            measurement_mapping=dict(data.get("measurement_mapping", {})),
            metadata=dict(data.get("metadata", {})),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
        )


@dataclass(frozen=True)
class OpenQASM3RoundTripReportIR(IRMixin):
    """Report proving restricted OpenQASM 3 export/import semantic stability."""

    report_id: str
    status: RoundTripStatus
    source_program_id: str
    source_program_hash: str | None
    exported_source_digest: str | None
    imported_source_digest: str | None
    payload_available: bool
    original_summary: OpenQASM3RoundTripSemanticSummaryIR | None
    imported_summary: OpenQASM3RoundTripSemanticSummaryIR | None
    matched_fields: tuple[str, ...]
    drift_fields: tuple[str, ...]
    diagnostics: tuple[DiagnosticsIR, ...]
    unsupported_features: tuple[str, ...] = ()
    export_result: dict[str, Any] = field(default_factory=dict)
    import_result: dict[str, Any] = field(default_factory=dict)
    external_sdk_imported: bool = False
    cascaqit_compat_required: bool = False
    execution_package_created: bool = False
    backend_called: bool = False
    cloud_called: bool = False
    network_accessed: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize report payload and enforce offline proof boundaries."""
        if self.external_sdk_imported:
            raise ValueError("OpenQASM round-trip must not import external SDKs.")
        if self.cascaqit_compat_required:
            raise ValueError("OpenQASM round-trip must not require compat.")
        if self.execution_package_created:
            raise ValueError("OpenQASM round-trip must not create packages.")
        if self.backend_called or self.cloud_called:
            raise ValueError("OpenQASM round-trip must not call backends or cloud.")
        if self.network_accessed:
            raise ValueError("OpenQASM round-trip cannot access networks.")
        object.__setattr__(
            self,
            "original_summary",
            _summary_or_none(self.original_summary),
        )
        object.__setattr__(
            self,
            "imported_summary",
            _summary_or_none(self.imported_summary),
        )
        object.__setattr__(
            self,
            "matched_fields",
            tuple(str(field) for field in self.matched_fields),
        )
        object.__setattr__(
            self,
            "drift_fields",
            tuple(str(field) for field in self.drift_fields),
        )
        object.__setattr__(
            self,
            "diagnostics",
            tuple(
                item
                if isinstance(item, DiagnosticsIR)
                else DiagnosticsIR.from_dict(item)
                for item in self.diagnostics
            ),
        )
        object.__setattr__(
            self,
            "unsupported_features",
            tuple(str(feature) for feature in self.unsupported_features),
        )
        object.__setattr__(self, "export_result", canonicalize(self.export_result))
        object.__setattr__(self, "import_result", canonicalize(self.import_result))
        object.__setattr__(self, "metadata", canonicalize(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> OpenQASM3RoundTripReportIR:
        """Build a round-trip report from a JSON-compatible dictionary."""
        return cls(
            report_id=str(data["report_id"]),
            status=data["status"],
            source_program_id=str(data["source_program_id"]),
            source_program_hash=data.get("source_program_hash"),
            exported_source_digest=data.get("exported_source_digest"),
            imported_source_digest=data.get("imported_source_digest"),
            payload_available=bool(data["payload_available"]),
            original_summary=_summary_from_data(data.get("original_summary")),
            imported_summary=_summary_from_data(data.get("imported_summary")),
            matched_fields=tuple(str(item) for item in data.get("matched_fields", ())),
            drift_fields=tuple(str(item) for item in data.get("drift_fields", ())),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(item)
                for item in data.get("diagnostics", ())
            ),
            unsupported_features=tuple(
                str(item) for item in data.get("unsupported_features", ())
            ),
            export_result=dict(data.get("export_result", {})),
            import_result=dict(data.get("import_result", {})),
            external_sdk_imported=bool(data.get("external_sdk_imported", False)),
            cascaqit_compat_required=bool(data.get("cascaqit_compat_required", False)),
            execution_package_created=bool(
                data.get("execution_package_created", False)
            ),
            backend_called=bool(data.get("backend_called", False)),
            cloud_called=bool(data.get("cloud_called", False)),
            network_accessed=bool(data.get("network_accessed", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )


@dataclass(frozen=True)
class OpenQASM3SourceMapReviewEntryIR(IRMixin):
    """One source-map relationship for an OpenQASM round-trip review."""

    entry_id: str
    mapping_kind: SourceMapMappingKind
    source_ref: str
    imported_refs: tuple[str, ...]
    source_gate: str | None
    imported_gates: tuple[str, ...]
    lowering_strategy: str | None = None
    drift_categories: tuple[str, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = SCHEMA_VERSION

    def __post_init__(self) -> None:
        """Normalize source-map review entry payload."""
        object.__setattr__(
            self,
            "imported_refs",
            tuple(str(item) for item in self.imported_refs),
        )
        object.__setattr__(
            self,
            "imported_gates",
            tuple(str(item) for item in self.imported_gates),
        )
        object.__setattr__(
            self,
            "drift_categories",
            tuple(str(item) for item in self.drift_categories),
        )
        object.__setattr__(self, "metadata", canonicalize(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> OpenQASM3SourceMapReviewEntryIR:
        """Build a source-map review entry from a JSON-compatible dictionary."""
        return cls(
            entry_id=str(data["entry_id"]),
            mapping_kind=data["mapping_kind"],
            source_ref=str(data["source_ref"]),
            imported_refs=tuple(str(item) for item in data.get("imported_refs", ())),
            source_gate=(
                None if data.get("source_gate") is None else str(data["source_gate"])
            ),
            imported_gates=tuple(str(item) for item in data.get("imported_gates", ())),
            lowering_strategy=data.get("lowering_strategy"),
            drift_categories=tuple(
                str(item) for item in data.get("drift_categories", ())
            ),
            metadata=dict(data.get("metadata", {})),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
        )


@dataclass(frozen=True)
class OpenQASM3SourceMapReviewIR(IRMixin):
    """Source-map review for restricted OpenQASM round-trip relationships."""

    review_id: str
    status: SourceMapReviewStatus
    round_trip_report_id: str
    source_program_id: str
    entries: tuple[OpenQASM3SourceMapReviewEntryIR, ...]
    drift_categories: tuple[str, ...]
    diagnostics: tuple[DiagnosticsIR, ...]
    source_map_policy: str
    mapping_counts: dict[str, int]
    external_sdk_imported: bool = False
    cascaqit_compat_required: bool = False
    execution_package_created: bool = False
    backend_called: bool = False
    cloud_called: bool = False
    network_accessed: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize review payload and enforce offline boundaries."""
        if self.external_sdk_imported:
            raise ValueError("OpenQASM source-map review must not import SDKs.")
        if self.cascaqit_compat_required:
            raise ValueError("OpenQASM source-map review must not require compat.")
        if self.execution_package_created:
            raise ValueError("OpenQASM source-map review must not create packages.")
        if self.backend_called or self.cloud_called:
            raise ValueError("OpenQASM source-map review must not call backends.")
        if self.network_accessed:
            raise ValueError("OpenQASM source-map review cannot access networks.")
        object.__setattr__(
            self,
            "entries",
            tuple(
                entry
                if isinstance(entry, OpenQASM3SourceMapReviewEntryIR)
                else OpenQASM3SourceMapReviewEntryIR.from_dict(entry)
                for entry in self.entries
            ),
        )
        object.__setattr__(
            self,
            "drift_categories",
            tuple(str(item) for item in self.drift_categories),
        )
        object.__setattr__(
            self,
            "diagnostics",
            tuple(
                diagnostic
                if isinstance(diagnostic, DiagnosticsIR)
                else DiagnosticsIR.from_dict(diagnostic)
                for diagnostic in self.diagnostics
            ),
        )
        object.__setattr__(self, "mapping_counts", canonicalize(self.mapping_counts))
        object.__setattr__(self, "metadata", canonicalize(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> OpenQASM3SourceMapReviewIR:
        """Build a source-map review from a JSON-compatible dictionary."""
        return cls(
            review_id=str(data["review_id"]),
            status=data["status"],
            round_trip_report_id=str(data["round_trip_report_id"]),
            source_program_id=str(data["source_program_id"]),
            entries=tuple(
                OpenQASM3SourceMapReviewEntryIR.from_dict(item)
                for item in data.get("entries", ())
            ),
            drift_categories=tuple(
                str(item) for item in data.get("drift_categories", ())
            ),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(item)
                for item in data.get("diagnostics", ())
            ),
            source_map_policy=str(data["source_map_policy"]),
            mapping_counts=dict(data.get("mapping_counts", {})),
            external_sdk_imported=bool(data.get("external_sdk_imported", False)),
            cascaqit_compat_required=bool(data.get("cascaqit_compat_required", False)),
            execution_package_created=bool(
                data.get("execution_package_created", False)
            ),
            backend_called=bool(data.get("backend_called", False)),
            cloud_called=bool(data.get("cloud_called", False)),
            network_accessed=bool(data.get("network_accessed", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )


def prove_openqasm3_round_trip(
    program: ProgramIR | DigitalProgramIR,
    *,
    report_id: str | None = None,
    imported_program_id: str | None = None,
) -> OpenQASM3RoundTripReportIR:
    """Export a digital program to OpenQASM 3 and import it back for proof."""
    program_id = getattr(program, "program_id", "program.unknown")
    source_program_hash = (
        program.stable_hash() if isinstance(program, IRMixin) else None
    )
    export_result = render_openqasm3_subset(
        program,
        export_id=f"openqasm3_roundtrip.export.{program_id}",
    )
    resolved_report_id = report_id or f"openqasm3_roundtrip.{program_id}"
    if not export_result.payload_available or export_result.source is None:
        return _round_trip_report(
            report_id=resolved_report_id,
            status="blocked",
            source_program_id=program_id,
            source_program_hash=source_program_hash,
            export_result=export_result,
            import_result=None,
            original_summary=None,
            imported_summary=None,
            matched_fields=(),
            drift_fields=("export",),
            diagnostics=export_result.diagnostics,
            unsupported_features=export_result.unsupported_features,
        )

    import_result = parse_openqasm3_subset(
        export_result.source,
        program_id=imported_program_id or f"{program_id}.openqasm3_roundtrip",
        source_id=export_result.export_id,
    )
    if not isinstance(program, DigitalProgramIR) or import_result.program is None:
        unsupported = tuple(
            f"openqasm3:{diagnostic.code}"
            for diagnostic in import_result.diagnostics
            if diagnostic.severity == "error"
        )
        return _round_trip_report(
            report_id=resolved_report_id,
            status="blocked",
            source_program_id=program_id,
            source_program_hash=source_program_hash,
            export_result=export_result,
            import_result=import_result,
            original_summary=None,
            imported_summary=None,
            matched_fields=(),
            drift_fields=("import",),
            diagnostics=(*export_result.diagnostics, *import_result.diagnostics),
            unsupported_features=unsupported,
        )

    semantic_equivalence_report = compare_digital_program_semantics(
        program,
        import_result.program,
        report_id=f"{resolved_report_id}.semantic_equivalence",
        metadata={
            "source_format": "cascaqit.native_digital",
            "target_format": "openqasm3",
            "round_trip_report_id": resolved_report_id,
            "export_id": export_result.export_id,
            "imported_program_id": import_result.program.program_id,
            "lowering_report": export_result.metadata.get("lowering_report", {}),
        },
    )
    original_summary = _semantic_summary(
        program,
        program_hash=program.stable_hash(),
        bit_order=export_result.bit_order,
        measurement_mapping=export_result.measurement_mapping,
        source="original",
        export_result=export_result,
    )
    imported_summary = _semantic_summary(
        import_result.program,
        program_hash=import_result.program.stable_hash(),
        bit_order=import_result.bit_order,
        measurement_mapping=import_result.measurement_mapping,
        source="imported",
    )
    matched_fields, drift_fields = _compare_summaries(
        original_summary,
        imported_summary,
    )
    diagnostics: tuple[DiagnosticsIR, ...] = (
        (*export_result.diagnostics, *import_result.diagnostics)
        if not drift_fields
        else (
            *export_result.diagnostics,
            *import_result.diagnostics,
            _round_trip_drift_diagnostic(drift_fields),
        )
    )
    return _round_trip_report(
        report_id=resolved_report_id,
        status="passed" if not drift_fields else "failed",
        source_program_id=program.program_id,
        source_program_hash=program.stable_hash(),
        export_result=export_result,
        import_result=import_result,
        original_summary=original_summary,
        imported_summary=imported_summary,
        matched_fields=matched_fields,
        drift_fields=drift_fields,
        diagnostics=diagnostics,
        unsupported_features=(),
        semantic_equivalence_report=semantic_equivalence_report,
    )


def build_openqasm3_source_map_review(
    program: ProgramIR | DigitalProgramIR,
    *,
    review_id: str | None = None,
    round_trip_report: OpenQASM3RoundTripReportIR | None = None,
) -> OpenQASM3SourceMapReviewIR:
    """Review source-map relationships for restricted OpenQASM round-trip."""
    report = round_trip_report or prove_openqasm3_round_trip(program)
    resolved_review_id = (
        review_id or f"openqasm3_source_map_review.{report.source_program_id}"
    )
    if report.status == "blocked":
        entries: tuple[OpenQASM3SourceMapReviewEntryIR, ...] = (
            OpenQASM3SourceMapReviewEntryIR(
                entry_id=f"{resolved_review_id}.blocked",
                mapping_kind="blocked",
                source_ref="program",
                imported_refs=(),
                source_gate=None,
                imported_gates=(),
                drift_categories=("mapping_cardinality",),
                metadata={"unsupported_features": list(report.unsupported_features)},
            ),
        )
        diagnostics = (
            _source_map_review_diagnostic(
                code="OPENQASM_SOURCE_MAP_REVIEW_BLOCKED",
                severity="warning",
                message="OpenQASM source-map review was blocked before import.",
                categories=("mapping_cardinality",),
            ),
        )
        return _source_map_review(
            review_id=resolved_review_id,
            status="blocked",
            report=report,
            entries=entries,
            diagnostics=diagnostics,
        )

    if report.original_summary is None or report.imported_summary is None:
        entries = ()
    else:
        entries = _source_map_entries(
            review_id=resolved_review_id,
            report=report,
        )
    drift_categories = _source_map_drift_categories(report, entries)
    diagnostics = (
        (
            _source_map_review_diagnostic(
                code="OPENQASM_SOURCE_MAP_REVIEW_DRIFT",
                severity="error",
                message="OpenQASM source-map relationships contain drift.",
                categories=drift_categories,
            ),
        )
        if drift_categories
        else (
            _source_map_review_diagnostic(
                code="OPENQASM_SOURCE_MAP_REVIEW_ALIGNED",
                severity="info",
                message="OpenQASM source-map relationships are aligned.",
                categories=(),
            ),
        )
    )
    return _source_map_review(
        review_id=resolved_review_id,
        status="drifted" if drift_categories else "aligned",
        report=report,
        entries=entries,
        diagnostics=diagnostics,
    )


def _summary_or_none(
    value: OpenQASM3RoundTripSemanticSummaryIR | dict[str, Any] | None,
) -> OpenQASM3RoundTripSemanticSummaryIR | None:
    if value is None:
        return None
    if isinstance(value, OpenQASM3RoundTripSemanticSummaryIR):
        return value
    return OpenQASM3RoundTripSemanticSummaryIR.from_dict(value)


def _summary_from_data(
    data: dict[str, Any] | None,
) -> OpenQASM3RoundTripSemanticSummaryIR | None:
    if data is None:
        return None
    return OpenQASM3RoundTripSemanticSummaryIR.from_dict(data)


def _semantic_summary(
    program: DigitalProgramIR,
    *,
    program_hash: str,
    bit_order: dict[str, Any],
    measurement_mapping: dict[str, Any],
    source: str,
    export_result: OpenQASM3ExportResultIR | None = None,
) -> OpenQASM3RoundTripSemanticSummaryIR:
    gates = (
        tuple(_gate_summary(gate) for gate in program.circuit.gates)
        if export_result is None
        else _export_comparable_gates(program, export_result)
    )
    return OpenQASM3RoundTripSemanticSummaryIR(
        program_id=program.program_id,
        program_hash=program_hash,
        qubits=program.circuit.qubits,
        gates=gates,
        measurements=_flatten_measurements(program),
        bit_order=_comparable_bit_order(bit_order, measurement_mapping),
        measurement_mapping=_comparable_measurement_mapping(measurement_mapping),
        metadata={
            "source": source,
            "program_type": program.program_type,
            "gate_count": len(program.circuit.gates),
            "comparable_gate_count": len(gates),
            "measurement_count": len(program.circuit.measurements),
            "lowered_gate_count": _lowered_gate_count(export_result),
        },
    )


def _gate_summary(gate: Any) -> dict[str, Any]:
    return {
        "name": gate.name,
        "targets": list(gate.targets),
        "parameters": {
            name: _parameter_value(value)
            for name, value in sorted(gate.parameters.items())
        },
    }


def _export_comparable_gates(
    program: DigitalProgramIR,
    export_result: OpenQASM3ExportResultIR,
) -> tuple[dict[str, Any], ...]:
    gates: list[dict[str, Any]] = []
    for index, gate in enumerate(program.circuit.gates):
        statement = _gate_statement_for_index(export_result, index)
        if statement is None or not statement.metadata.get("lowered"):
            gates.append(_gate_summary(gate))
            continue
        for generated in statement.metadata.get("generated_gates", ()):
            gates.append(
                {
                    "name": str(generated["name"]),
                    "targets": [str(target) for target in generated["targets"]],
                    "parameters": {},
                }
            )
    return tuple(gates)


def _gate_statement_for_index(
    export_result: OpenQASM3ExportResultIR,
    index: int,
) -> Any | None:
    native_ref = f"program.circuit.gates[{index}]"
    for statement in export_result.statements:
        if statement.kind == "gate" and statement.native_ref == native_ref:
            return statement
    return None


def _lowered_gate_count(export_result: OpenQASM3ExportResultIR | None) -> int:
    if export_result is None:
        return 0
    return int(export_result.metadata.get("lowered_gate_count", 0))


def _flatten_measurements(program: DigitalProgramIR) -> tuple[dict[str, Any], ...]:
    entries: list[dict[str, Any]] = []
    bit_cursor = 0
    for measurement in program.circuit.measurements:
        for target in measurement.targets:
            entries.append(
                {
                    "target": target,
                    "key": measurement.key
                    if len(measurement.targets) == 1
                    else f"{measurement.key}[{bit_cursor}]",
                    "basis": measurement.basis,
                    "classical_index": bit_cursor,
                }
            )
            bit_cursor += 1
    return tuple(entries)


def _comparable_bit_order(
    bit_order: dict[str, Any],
    measurement_mapping: dict[str, Any],
) -> dict[str, Any]:
    qubit_order = bit_order.get("qubit_order", ())
    classical_bit_count = (
        bit_order.get("classical_bit_count")
        if "classical_bit_count" in bit_order
        else bit_order.get("bit_count")
    )
    if classical_bit_count is None:
        classical_bit_count = measurement_mapping.get("bit_count")
    if classical_bit_count is None and "entries" in measurement_mapping:
        classical_bit_count = len(measurement_mapping["entries"])
    return {
        "qubit_order": list(qubit_order),
        "classical_bit_count": classical_bit_count,
    }


def _comparable_measurement_mapping(
    mapping: dict[str, Any],
) -> dict[str, Any]:
    if "entries" in mapping:
        entries = [
            {
                "target": entry.get("target"),
                "target_index": entry.get("target_index"),
                "classical_index": entry.get("classical_index"),
            }
            for entry in mapping["entries"]
        ]
    else:
        entries = [
            {
                "target": measurement["targets"][0],
                "target_index": _target_index(measurement["targets"][0]),
                "classical_index": _classical_index(
                    measurement.get("classical_bit")
                ),
            }
            for measurement in mapping.get("measurements", ())
        ]
    return {
        "bit_count": mapping.get("bit_count", len(entries)),
        "entries": entries,
    }


def _target_index(target: str) -> int | None:
    digits = "".join(char for char in target if char.isdigit())
    return None if not digits else int(digits)


def _classical_index(value: Any) -> int | None:
    if isinstance(value, int):
        return value
    if value is None:
        return None
    digits = "".join(char for char in str(value) if char.isdigit())
    return None if not digits else int(digits)


def _parameter_value(value: float) -> str:
    return format(float(value), ".17g")


def _source_map_entries(
    *,
    review_id: str,
    report: OpenQASM3RoundTripReportIR,
) -> tuple[OpenQASM3SourceMapReviewEntryIR, ...]:
    original = report.original_summary
    imported = report.imported_summary
    if original is None or imported is None:
        return ()
    lowering_entries = report.export_result.get("lowering_report", {}).get(
        "entries",
        (),
    )
    entries: list[OpenQASM3SourceMapReviewEntryIR] = []
    original_cursor = 0
    imported_cursor = 0
    lowering_by_source = {
        str(entry["native_ref"]): entry for entry in lowering_entries
    }
    for source_index, source_gate in enumerate(_source_program_gates(report)):
        source_ref = f"program.circuit.gates[{source_index}]"
        lowering_entry = lowering_by_source.get(source_ref)
        if lowering_entry is None:
            imported_refs: tuple[str, ...] = (
                f"imported.circuit.gates[{imported_cursor}]",
            )
            imported_slice = imported.gates[imported_cursor : imported_cursor + 1]
            comparable_slice = original.gates[original_cursor : original_cursor + 1]
            imported_cursor += 1
            original_cursor += 1
            mapping_kind: SourceMapMappingKind = "direct"
            lowering_strategy = None
        else:
            generated_count = int(lowering_entry["generated_statement_count"])
            imported_refs = tuple(
                f"imported.circuit.gates[{index}]"
                for index in range(imported_cursor, imported_cursor + generated_count)
            )
            imported_slice = imported.gates[
                imported_cursor : imported_cursor + generated_count
            ]
            comparable_slice = original.gates[
                original_cursor : original_cursor + generated_count
            ]
            imported_cursor += generated_count
            original_cursor += generated_count
            mapping_kind = "lowered"
            lowering_strategy = str(lowering_entry["lowering_strategy"])
        entries.append(
            OpenQASM3SourceMapReviewEntryIR(
                entry_id=f"{review_id}.gate.{source_index}",
                mapping_kind=mapping_kind,
                source_ref=source_ref,
                imported_refs=imported_refs,
                source_gate=str(source_gate["name"]),
                imported_gates=tuple(str(gate["name"]) for gate in imported_slice),
                lowering_strategy=lowering_strategy,
                drift_categories=_entry_drift_categories(
                    expected=comparable_slice,
                    actual=imported_slice,
                ),
                metadata={
                    "expected_gate_count": len(comparable_slice),
                    "imported_gate_count": len(imported_slice),
                    "mapping_cardinality": f"1:{len(imported_refs)}",
                },
            )
        )
    return tuple(entries)


def _source_program_gates(
    report: OpenQASM3RoundTripReportIR,
) -> tuple[dict[str, Any], ...]:
    original = report.original_summary
    if original is None:
        return ()
    lowering_entries = report.export_result.get("lowering_report", {}).get(
        "entries",
        (),
    )
    lowered_refs = {str(entry["native_ref"]) for entry in lowering_entries}
    gates: list[dict[str, Any]] = []
    comparable_cursor = 0
    for source_index in range(_source_gate_count(report)):
        source_ref = f"program.circuit.gates[{source_index}]"
        if source_ref in lowered_refs:
            lowering_entry = next(
                entry
                for entry in lowering_entries
                if str(entry["native_ref"]) == source_ref
            )
            gates.append(
                {
                    "name": lowering_entry["source_gate"],
                    "targets": [],
                    "parameters": {},
                }
            )
            comparable_cursor += int(lowering_entry["generated_statement_count"])
        else:
            gates.append(dict(original.gates[comparable_cursor]))
            comparable_cursor += 1
    return tuple(gates)


def _source_gate_count(report: OpenQASM3RoundTripReportIR) -> int:
    original = report.original_summary
    if original is None:
        return 0
    lowered = report.export_result.get("lowering_report", {}).get("entries", ())
    generated_extra = sum(
        int(entry["generated_statement_count"]) - 1 for entry in lowered
    )
    return int(original.metadata["comparable_gate_count"]) - generated_extra


def _entry_drift_categories(
    *,
    expected: tuple[dict[str, Any], ...],
    actual: tuple[dict[str, Any], ...],
) -> tuple[str, ...]:
    categories: list[str] = []
    if len(expected) != len(actual):
        categories.append("mapping_cardinality")
    for expected_gate, actual_gate in zip(expected, actual):
        if expected_gate.get("name") != actual_gate.get("name"):
            categories.append("gate_name")
        if expected_gate.get("targets") != actual_gate.get("targets"):
            categories.append("target_order")
        if expected_gate.get("parameters") != actual_gate.get("parameters"):
            categories.append("parameter_value")
    return tuple(dict.fromkeys(categories))


def _source_map_drift_categories(
    report: OpenQASM3RoundTripReportIR,
    entries: tuple[OpenQASM3SourceMapReviewEntryIR, ...],
) -> tuple[str, ...]:
    categories: list[str] = []
    for entry in entries:
        categories.extend(entry.drift_categories)
    for drift_field in report.drift_fields:
        if drift_field == "gates":
            categories.append("gate_name")
        elif drift_field in {"measurement_mapping", "measurements"}:
            categories.append("measurement_mapping")
        elif drift_field == "bit_order":
            categories.append("target_order")
        elif drift_field == "export":
            categories.append("mapping_cardinality")
        else:
            categories.append(str(drift_field))
    return tuple(sorted(set(categories)))


def _source_map_review(
    *,
    review_id: str,
    status: SourceMapReviewStatus,
    report: OpenQASM3RoundTripReportIR,
    entries: tuple[OpenQASM3SourceMapReviewEntryIR, ...],
    diagnostics: tuple[DiagnosticsIR, ...],
) -> OpenQASM3SourceMapReviewIR:
    return OpenQASM3SourceMapReviewIR(
        review_id=review_id,
        status=status,
        round_trip_report_id=report.report_id,
        source_program_id=report.source_program_id,
        entries=entries,
        drift_categories=_source_map_drift_categories(report, entries),
        diagnostics=diagnostics,
        source_map_policy="direct_or_lowered_gate_relationships",
        mapping_counts=_mapping_counts(entries),
        metadata={
            "phase": "219",
            "restricted_subset": True,
            "round_trip_status": report.status,
            "semantic_drift_fields": list(report.drift_fields),
            "direct_mapping_count": sum(
                1 for entry in entries if entry.mapping_kind == "direct"
            ),
            "lowered_mapping_count": sum(
                1 for entry in entries if entry.mapping_kind == "lowered"
            ),
            "blocked_mapping_count": sum(
                1 for entry in entries if entry.mapping_kind == "blocked"
            ),
            "external_sdk_imported": False,
            "cascaqit_compat_required": False,
            "execution_package_created": False,
            "backend_called": False,
            "cloud_called": False,
            "network_accessed": False,
        },
    )


def _mapping_counts(
    entries: tuple[OpenQASM3SourceMapReviewEntryIR, ...],
) -> dict[str, int]:
    counts = {"blocked": 0, "direct": 0, "lowered": 0}
    for entry in entries:
        counts[entry.mapping_kind] = counts.get(entry.mapping_kind, 0) + 1
    return counts


def _source_map_review_diagnostic(
    *,
    code: str,
    severity: Literal["info", "warning", "error"],
    message: str,
    categories: tuple[str, ...],
) -> DiagnosticsIR:
    return DiagnosticsIR(
        diagnostic_id=f"openqasm3.source_map_review.{code.lower()}",
        stage="serialization",
        severity=severity,
        code=code,
        message=message,
        object_path="openqasm3.source_map_review",
        suggestion="Inspect source-map review entries and drift categories.",
        metadata={
            "source_format": "cascaqit.native_digital",
            "target_format": "openqasm3",
            "reason_category": "source_map_review",
            "drift_categories": list(categories),
            "phase": "219",
        },
    )


def _compare_summaries(
    original: OpenQASM3RoundTripSemanticSummaryIR,
    imported: OpenQASM3RoundTripSemanticSummaryIR,
) -> tuple[tuple[str, ...], tuple[str, ...]]:
    fields = (
        "qubits",
        "gates",
        "measurements",
        "bit_order",
        "measurement_mapping",
    )
    matched: list[str] = []
    drift: list[str] = []
    for summary_field in fields:
        if getattr(original, summary_field) == getattr(imported, summary_field):
            matched.append(summary_field)
        else:
            drift.append(summary_field)
    return tuple(matched), tuple(drift)


def _round_trip_report(
    *,
    report_id: str,
    status: RoundTripStatus,
    source_program_id: str,
    source_program_hash: str | None,
    export_result: OpenQASM3ExportResultIR,
    import_result: OpenQASM3SubsetImportResultIR | None,
    original_summary: OpenQASM3RoundTripSemanticSummaryIR | None,
    imported_summary: OpenQASM3RoundTripSemanticSummaryIR | None,
    matched_fields: tuple[str, ...],
    drift_fields: tuple[str, ...],
    diagnostics: tuple[DiagnosticsIR, ...],
    unsupported_features: tuple[str, ...],
    semantic_equivalence_report: DigitalSemanticEquivalenceReportIR | None = None,
) -> OpenQASM3RoundTripReportIR:
    semantic_equivalence_metadata = (
        {}
        if semantic_equivalence_report is None
        else {"semantic_equivalence_report": semantic_equivalence_report.to_dict()}
    )
    return OpenQASM3RoundTripReportIR(
        report_id=report_id,
        status=status,
        source_program_id=source_program_id,
        source_program_hash=source_program_hash,
        exported_source_digest=export_result.payload_digest,
        imported_source_digest=(
            None if import_result is None else import_result.source_digest
        ),
        payload_available=export_result.payload_available,
        original_summary=original_summary,
        imported_summary=imported_summary,
        matched_fields=matched_fields,
        drift_fields=drift_fields,
        diagnostics=diagnostics,
        unsupported_features=unsupported_features,
        export_result={
            "export_id": export_result.export_id,
            "payload_available": export_result.payload_available,
            "payload_digest": export_result.payload_digest,
            "lowering_report": export_result.metadata.get("lowering_report", {}),
            "diagnostic_codes": [
                diagnostic.code for diagnostic in export_result.diagnostics
            ],
        },
        import_result={}
        if import_result is None
        else {
            "source_format": import_result.source_format,
            "source_digest": import_result.source_digest,
            "program_available": import_result.program is not None,
            "diagnostic_codes": [
                diagnostic.code for diagnostic in import_result.diagnostics
            ],
        },
        metadata={
            "phase": "210",
            "restricted_subset": True,
            "full_openqasm3_supported": False,
            "source_text_byte_for_byte_required": False,
            "semantic_equivalence_required": True,
            "exporter": "cascaqit.interop.openqasm3_export",
            "importer": "cascaqit.interop.openqasm3_subset",
            "external_sdk_imported": False,
            "cascaqit_compat_required": False,
            "execution_package_created": False,
            "backend_called": False,
            "cloud_called": False,
            "network_accessed": False,
            **semantic_equivalence_metadata,
        },
    )


def _round_trip_drift_diagnostic(drift_fields: tuple[str, ...]) -> DiagnosticsIR:
    return DiagnosticsIR(
        diagnostic_id="openqasm3.roundtrip.semantic_drift",
        stage="serialization",
        severity="error",
        code="OPENQASM_ROUNDTRIP_SEMANTIC_DRIFT",
        message="OpenQASM 3 round-trip semantic summaries did not match.",
        object_path="roundtrip.semantic_summary",
        suggestion="Inspect drift_fields and extend the restricted subset if needed.",
        metadata={
            "source_format": "cascaqit.native_digital",
            "target_format": "openqasm3",
            "reason_category": "roundtrip_drift",
            "drift_fields": list(drift_fields),
            "phase": "210",
        },
    )
