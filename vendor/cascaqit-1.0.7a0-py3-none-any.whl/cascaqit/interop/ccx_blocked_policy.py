"""CCX blocked-policy evidence reports for restricted OpenQASM interop."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Literal

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.interop.ccx_policy import (
    CCX_BLOCKED_DIAGNOSTIC_CODE,
    CCX_BLOCKED_GATE,
    CCX_BLOCKED_MESSAGE,
    CCX_BLOCKED_REASON,
)
from cascaqit.interop.contracts import (
    AdapterCapabilityManifestIR,
    ExternalFormatMappingCoverageIR,
)
from cascaqit.interop.openqasm3_export import OpenQASM3ExportResultIR
from cascaqit.interop.openqasm3_subset import OpenQASM3SubsetImportResultIR
from cascaqit.native_ir.base import IRMixin, canonicalize
from cascaqit.native_ir.models import SCHEMA_VERSION

__all__ = [
    "CCXBlockedPolicyReportIR",
    "CCXDecisionPreflightReportIR",
    "build_ccx_blocked_policy_report",
    "build_ccx_decision_preflight_report",
]

CCXBlockedPolicyStatus = Literal["aligned", "drifted", "blocked"]
CCXDecisionPreflightStatus = Literal["remain_blocked", "policy_drift"]

_CCX_PREFLIGHT_REQUIRED_EVIDENCE = (
    "toffoli_lowering_policy",
    "source_map_cardinality_policy",
    "statevector_equivalence_suite",
    "probability_equivalence_suite",
    "phase_sensitive_drift_suite",
    "import_export_roundtrip_suite",
    "adapter_manifest_transition_policy",
    "docs_and_migration_notes",
)


@dataclass(frozen=True)
class CCXBlockedPolicyReportIR(IRMixin):
    """Report proving CCX remains blocked without Toffoli lowering."""

    report_id: str
    status: CCXBlockedPolicyStatus
    blocked_gate: str
    blocked_reason: str
    evidence: dict[str, Any]
    drift_fields: tuple[str, ...]
    diagnostics: tuple[DiagnosticsIR, ...]
    metadata_only: bool = True
    backend_called: bool = False
    cloud_called: bool = False
    network_accessed: bool = False
    cascaqit_compat_required: bool = False
    execution_package_created: bool = False
    toffoli_lowering_supported: bool = False
    source_map_policy_defined: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize payload and enforce CCX blocked-policy boundaries."""
        if not self.metadata_only:
            raise ValueError("CCX blocked policy reports must be metadata-only.")
        if self.backend_called or self.cloud_called:
            raise ValueError("CCX blocked policy must not call backend or cloud.")
        if self.network_accessed:
            raise ValueError("CCX blocked policy must not access networks.")
        if self.cascaqit_compat_required:
            raise ValueError("CCX blocked policy must not require compat.")
        if self.execution_package_created:
            raise ValueError("CCX blocked policy must not create packages.")
        if self.toffoli_lowering_supported:
            raise ValueError("CCX blocked policy must not enable Toffoli lowering.")
        if self.source_map_policy_defined:
            raise ValueError(
                "CCX blocked policy must not define Toffoli source-map policy."
            )
        object.__setattr__(self, "evidence", canonicalize(self.evidence))
        object.__setattr__(
            self,
            "drift_fields",
            tuple(str(item) for item in self.drift_fields),
        )
        object.__setattr__(
            self,
            "diagnostics",
            tuple(
                diagnostic
                if isinstance(diagnostic, DiagnosticsIR)
                else DiagnosticsIR.from_dict(diagnostic)
                for diagnostic in self.diagnostics
            ),
        )
        object.__setattr__(self, "metadata", canonicalize(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CCXBlockedPolicyReportIR:
        """Build a CCX blocked-policy report from a dictionary."""
        return cls(
            report_id=str(data["report_id"]),
            status=data["status"],
            blocked_gate=str(data.get("blocked_gate", CCX_BLOCKED_GATE)),
            blocked_reason=str(data.get("blocked_reason", CCX_BLOCKED_REASON)),
            evidence=dict(data.get("evidence", {})),
            drift_fields=tuple(str(item) for item in data.get("drift_fields", ())),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(item)
                for item in data.get("diagnostics", ())
            ),
            metadata_only=bool(data.get("metadata_only", True)),
            backend_called=bool(data.get("backend_called", False)),
            cloud_called=bool(data.get("cloud_called", False)),
            network_accessed=bool(data.get("network_accessed", False)),
            cascaqit_compat_required=bool(
                data.get("cascaqit_compat_required", False)
            ),
            execution_package_created=bool(
                data.get("execution_package_created", False)
            ),
            toffoli_lowering_supported=bool(
                data.get("toffoli_lowering_supported", False)
            ),
            source_map_policy_defined=bool(
                data.get("source_map_policy_defined", False)
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> CCXBlockedPolicyReportIR:
        """Build a CCX blocked-policy report from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("CCXBlockedPolicyReportIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class CCXDecisionPreflightReportIR(IRMixin):
    """Decision preflight report for future CCX support."""

    report_id: str
    status: CCXDecisionPreflightStatus
    decision: str
    blocked_gate: str
    blocked_reason: str
    blocked_policy_status: CCXBlockedPolicyStatus
    missing_evidence: tuple[str, ...]
    enabling_checklist: tuple[dict[str, Any], ...]
    source_map_requirements: dict[str, Any]
    numerical_evidence_requirements: dict[str, Any]
    negative_guards: dict[str, Any]
    diagnostics: tuple[DiagnosticsIR, ...]
    metadata_only: bool = True
    offline_deterministic: bool = True
    backend_called: bool = False
    cloud_called: bool = False
    network_accessed: bool = False
    cascaqit_compat_required: bool = False
    execution_package_created: bool = False
    toffoli_lowering_supported: bool = False
    source_map_policy_defined: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize preflight payload and keep CCX support blocked."""
        if self.status not in ("remain_blocked", "policy_drift"):
            raise ValueError("CCXDecisionPreflightReportIR has unsupported status.")
        if self.decision != "remain_blocked":
            raise ValueError("CCX decision preflight must keep CCX blocked.")
        if not self.metadata_only:
            raise ValueError("CCX decision preflight reports must be metadata-only.")
        if not self.offline_deterministic:
            raise ValueError("CCX decision preflight must be deterministic.")
        if self.backend_called or self.cloud_called:
            raise ValueError("CCX decision preflight must not call backend or cloud.")
        if self.network_accessed:
            raise ValueError("CCX decision preflight must not access networks.")
        if self.cascaqit_compat_required:
            raise ValueError("CCX decision preflight must not require compat.")
        if self.execution_package_created:
            raise ValueError("CCX decision preflight must not create packages.")
        if self.toffoli_lowering_supported:
            raise ValueError(
                "CCX decision preflight must not enable Toffoli lowering."
            )
        if self.source_map_policy_defined:
            raise ValueError(
                "CCX decision preflight must not define source-map policy."
            )
        object.__setattr__(
            self,
            "missing_evidence",
            tuple(str(item) for item in self.missing_evidence),
        )
        object.__setattr__(
            self,
            "enabling_checklist",
            tuple(canonicalize(dict(item)) for item in self.enabling_checklist),
        )
        object.__setattr__(
            self,
            "source_map_requirements",
            canonicalize(self.source_map_requirements),
        )
        object.__setattr__(
            self,
            "numerical_evidence_requirements",
            canonicalize(self.numerical_evidence_requirements),
        )
        object.__setattr__(
            self,
            "negative_guards",
            canonicalize(self.negative_guards),
        )
        object.__setattr__(
            self,
            "diagnostics",
            tuple(
                diagnostic
                if isinstance(diagnostic, DiagnosticsIR)
                else DiagnosticsIR.from_dict(diagnostic)
                for diagnostic in self.diagnostics
            ),
        )
        object.__setattr__(self, "metadata", canonicalize(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CCXDecisionPreflightReportIR:
        """Build a CCX decision preflight report from a dictionary."""
        if not isinstance(data, dict):
            raise TypeError(
                "CCXDecisionPreflightReportIR dictionary must be an object."
            )
        return cls(
            report_id=str(data["report_id"]),
            status=data["status"],
            decision=str(data["decision"]),
            blocked_gate=str(data.get("blocked_gate", CCX_BLOCKED_GATE)),
            blocked_reason=str(data.get("blocked_reason", CCX_BLOCKED_REASON)),
            blocked_policy_status=data.get("blocked_policy_status", "blocked"),
            missing_evidence=tuple(
                str(item) for item in data.get("missing_evidence", ())
            ),
            enabling_checklist=tuple(
                dict(item) for item in data.get("enabling_checklist", ())
            ),
            source_map_requirements=dict(data.get("source_map_requirements", {})),
            numerical_evidence_requirements=dict(
                data.get("numerical_evidence_requirements", {})
            ),
            negative_guards=dict(data.get("negative_guards", {})),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(item)
                for item in data.get("diagnostics", ())
            ),
            metadata_only=bool(data.get("metadata_only", True)),
            offline_deterministic=bool(data.get("offline_deterministic", True)),
            backend_called=bool(data.get("backend_called", False)),
            cloud_called=bool(data.get("cloud_called", False)),
            network_accessed=bool(data.get("network_accessed", False)),
            cascaqit_compat_required=bool(
                data.get("cascaqit_compat_required", False)
            ),
            execution_package_created=bool(
                data.get("execution_package_created", False)
            ),
            toffoli_lowering_supported=bool(
                data.get("toffoli_lowering_supported", False)
            ),
            source_map_policy_defined=bool(
                data.get("source_map_policy_defined", False)
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> CCXDecisionPreflightReportIR:
        """Build a CCX decision preflight report from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError(
                "CCXDecisionPreflightReportIR JSON must contain an object."
            )
        return cls.from_dict(data)


def build_ccx_blocked_policy_report(
    *,
    report_id: str = "ccx_blocked_policy.openqasm3.restricted",
    export_result: OpenQASM3ExportResultIR | None = None,
    import_result: OpenQASM3SubsetImportResultIR | None = None,
    mapping_coverage: ExternalFormatMappingCoverageIR | None = None,
    capability_manifest: AdapterCapabilityManifestIR | None = None,
    docs_blocked_reason: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> CCXBlockedPolicyReportIR:
    """Build metadata-only CCX blocked-policy evidence."""
    evidence = {
        "expected": {
            "blocked_gate": CCX_BLOCKED_GATE,
            "blocked_reason": CCX_BLOCKED_REASON,
            "diagnostic_code": CCX_BLOCKED_DIAGNOSTIC_CODE,
            "message": CCX_BLOCKED_MESSAGE,
            "toffoli_lowering_supported": False,
            "source_map_policy_defined": False,
        }
    }
    if export_result is not None:
        evidence["export"] = _export_evidence(export_result)
    if import_result is not None:
        evidence["import"] = _import_evidence(import_result)
    if mapping_coverage is not None:
        evidence["mapping_coverage"] = _mapping_coverage_evidence(mapping_coverage)
    if capability_manifest is not None:
        evidence["capability_manifest"] = _manifest_evidence(capability_manifest)
    if docs_blocked_reason is not None:
        evidence["docs"] = {"blocked_reason": docs_blocked_reason}
    drift_fields = _drift_fields(evidence)
    diagnostics = (
        (
            _diagnostic(
                code="CCX_BLOCKED_POLICY_DRIFT",
                severity="error",
                message="CCX blocked-policy evidence is inconsistent.",
                drift_fields=drift_fields,
            ),
        )
        if drift_fields
        else (
            _diagnostic(
                code="CCX_BLOCKED_POLICY_ALIGNED",
                severity="info",
                message="CCX blocked-policy evidence is aligned.",
                drift_fields=(),
            ),
        )
    )
    status: CCXBlockedPolicyStatus
    if len(evidence) == 1:
        status = "blocked"
        diagnostics = (
            _diagnostic(
                code="CCX_BLOCKED_POLICY_EVIDENCE_MISSING",
                severity="error",
                message=(
                    "CCX blocked-policy report requires at least one evidence path."
                ),
                drift_fields=("evidence",),
            ),
        )
        drift_fields = ("evidence",)
    else:
        status = "drifted" if drift_fields else "aligned"
    return CCXBlockedPolicyReportIR(
        report_id=report_id,
        status=status,
        blocked_gate=CCX_BLOCKED_GATE,
        blocked_reason=CCX_BLOCKED_REASON,
        evidence=evidence,
        drift_fields=drift_fields,
        diagnostics=diagnostics,
        metadata={
            **({} if metadata is None else dict(metadata)),
            "phase": "227",
            "restricted_subset": True,
            "full_openqasm3_supported": False,
            "policy_scope": "ccx_blocked_until_toffoli_lowering_policy",
        },
    )


def build_ccx_decision_preflight_report(
    *,
    report_id: str = "ccx_decision_preflight.openqasm3.restricted",
    blocked_policy_report: CCXBlockedPolicyReportIR | None = None,
    metadata: dict[str, Any] | None = None,
) -> CCXDecisionPreflightReportIR:
    """Build a conservative CCX decision preflight report.

    The report lists the evidence needed before CCX can move from blocked
    policy to explicit lowering support. It does not enable lowering.
    """
    policy_status: CCXBlockedPolicyStatus = (
        "blocked" if blocked_policy_report is None else blocked_policy_report.status
    )
    status: CCXDecisionPreflightStatus = (
        "remain_blocked" if policy_status in ("aligned", "blocked") else "policy_drift"
    )
    diagnostics = (
        _preflight_diagnostic(
            code="CCX_DECISION_PREFLIGHT_REMAIN_BLOCKED",
            severity="info",
            message=(
                "CCX remains blocked until Toffoli lowering evidence is complete."
            ),
            policy_status=policy_status,
        ),
    )
    if status == "policy_drift":
        diagnostics = (
            _preflight_diagnostic(
                code="CCX_DECISION_PREFLIGHT_POLICY_DRIFT",
                severity="error",
                message=(
                    "CCX decision preflight detected drift in blocked-policy evidence."
                ),
                policy_status=policy_status,
            ),
        )
    return CCXDecisionPreflightReportIR(
        report_id=report_id,
        status=status,
        decision="remain_blocked",
        blocked_gate=CCX_BLOCKED_GATE,
        blocked_reason=CCX_BLOCKED_REASON,
        blocked_policy_status=policy_status,
        missing_evidence=_CCX_PREFLIGHT_REQUIRED_EVIDENCE,
        enabling_checklist=_ccx_enabling_checklist(),
        source_map_requirements=_ccx_source_map_requirements(),
        numerical_evidence_requirements=_ccx_numerical_evidence_requirements(),
        negative_guards=_ccx_negative_guards(blocked_policy_report),
        diagnostics=diagnostics,
        metadata={
            **({} if metadata is None else dict(metadata)),
            "phase": "235",
            "restricted_subset": True,
            "full_openqasm3_supported": False,
            "policy_scope": "ccx_decision_preflight",
            "default_action": "keep_blocked",
        },
    )


def _export_evidence(result: OpenQASM3ExportResultIR) -> dict[str, Any]:
    diagnostic = _first_ccx_diagnostic(result.diagnostics)
    return {
        "payload_available": result.payload_available,
        "payload_digest": result.payload_digest,
        "partial_payload_emitted": result.source is not None,
        "unsupported_features": list(result.unsupported_features),
        "diagnostic_code": None if diagnostic is None else diagnostic.code,
        "blocked_reason": _diagnostic_reason(diagnostic),
        "toffoli_lowering_supported": _diagnostic_metadata_bool(
            diagnostic,
            "toffoli_lowering_supported",
        ),
        "source_map_policy_defined": _diagnostic_metadata_bool(
            diagnostic,
            "source_map_policy_defined",
        ),
    }


def _import_evidence(result: OpenQASM3SubsetImportResultIR) -> dict[str, Any]:
    diagnostic = _first_ccx_diagnostic(result.diagnostics)
    return {
        "program_available": result.program is not None,
        "diagnostic_code": None if diagnostic is None else diagnostic.code,
        "blocked_reason": _diagnostic_reason(diagnostic),
        "toffoli_lowering_supported": _diagnostic_metadata_bool(
            diagnostic,
            "toffoli_lowering_supported",
        ),
        "source_map_policy_defined": _diagnostic_metadata_bool(
            diagnostic,
            "source_map_policy_defined",
        ),
    }


def _mapping_coverage_evidence(
    coverage: ExternalFormatMappingCoverageIR,
) -> dict[str, Any]:
    return {
        "blocked_gates": list(coverage.metadata.get("blocked_gates", ())),
        "blocked_reason": dict(coverage.metadata.get("blocked_reasons", {})).get(
            CCX_BLOCKED_GATE
        ),
        "status": coverage.status,
        "unsupported_features": list(coverage.unsupported_features),
    }


def _manifest_evidence(manifest: AdapterCapabilityManifestIR) -> dict[str, Any]:
    return {
        "blocked_gates": list(manifest.metadata.get("blocked_gates", ())),
        "blocked_reason": dict(manifest.metadata.get("blocked_reasons", {})).get(
            CCX_BLOCKED_GATE
        ),
        "status": manifest.status,
        "unsupported_features": list(manifest.unsupported_features),
    }


def _drift_fields(evidence: dict[str, Any]) -> tuple[str, ...]:
    drift: list[str] = []
    export = evidence.get("export")
    if export is not None:
        if export["payload_available"] or export["partial_payload_emitted"]:
            drift.append("export.payload")
        if export["diagnostic_code"] != CCX_BLOCKED_DIAGNOSTIC_CODE:
            drift.append("export.diagnostic_code")
        if export["blocked_reason"] != CCX_BLOCKED_REASON:
            drift.append("export.blocked_reason")
        if export["toffoli_lowering_supported"]:
            drift.append("export.toffoli_lowering")
        if export["source_map_policy_defined"]:
            drift.append("export.source_map_policy")
    imported = evidence.get("import")
    if imported is not None:
        if imported["program_available"]:
            drift.append("import.program")
        if imported["diagnostic_code"] != CCX_BLOCKED_DIAGNOSTIC_CODE:
            drift.append("import.diagnostic_code")
        if imported["blocked_reason"] != CCX_BLOCKED_REASON:
            drift.append("import.blocked_reason")
        if imported["toffoli_lowering_supported"]:
            drift.append("import.toffoli_lowering")
        if imported["source_map_policy_defined"]:
            drift.append("import.source_map_policy")
    for evidence_field in ("mapping_coverage", "capability_manifest", "docs"):
        item = evidence.get(evidence_field)
        if item is not None and item.get("blocked_reason") != CCX_BLOCKED_REASON:
            drift.append(f"{evidence_field}.blocked_reason")
    return tuple(drift)


def _first_ccx_diagnostic(
    diagnostics: tuple[DiagnosticsIR, ...],
) -> DiagnosticsIR | None:
    for diagnostic in diagnostics:
        if diagnostic.metadata.get("gate") == CCX_BLOCKED_GATE:
            return diagnostic
    return None


def _diagnostic_reason(diagnostic: DiagnosticsIR | None) -> str | None:
    if diagnostic is None:
        return None
    reason = diagnostic.metadata.get("blocked_reason")
    return None if reason is None else str(reason)


def _diagnostic_metadata_bool(
    diagnostic: DiagnosticsIR | None,
    key: str,
) -> bool:
    return bool(False if diagnostic is None else diagnostic.metadata.get(key, False))


def _diagnostic(
    *,
    code: str,
    severity: Literal["info", "error"],
    message: str,
    drift_fields: tuple[str, ...],
) -> DiagnosticsIR:
    return DiagnosticsIR(
        diagnostic_id=f"ccx_blocked_policy.{code.lower()}",
        stage="serialization",
        severity=severity,
        code=code,
        message=message,
        object_path="ccx_blocked_policy",
        suggestion="Keep CCX blocked until Toffoli lowering policy is designed.",
        metadata={
            "phase": "227",
            "gate": CCX_BLOCKED_GATE,
            "blocked_reason": CCX_BLOCKED_REASON,
            "drift_fields": list(drift_fields),
        },
    )


def _ccx_enabling_checklist() -> tuple[dict[str, Any], ...]:
    return (
        {
            "item": "toffoli_lowering_policy",
            "status": "missing",
            "required": True,
            "description": (
                "Define a deterministic CCX-to-supported-gates lowering sequence "
                "or keep native CCX unsupported."
            ),
        },
        {
            "item": "source_map_cardinality_policy",
            "status": "missing",
            "required": True,
            "description": (
                "Define how one source CCX maps to multiple lowered operations and "
                "how diagnostics point back to the source gate."
            ),
        },
        {
            "item": "statevector_equivalence_suite",
            "status": "missing",
            "required": True,
            "description": (
                "Prove native CCX semantics and lowered sequence statevector "
                "equivalence for all computational basis inputs."
            ),
        },
        {
            "item": "phase_sensitive_drift_suite",
            "status": "missing",
            "required": True,
            "description": (
                "Include phase-sensitive fixtures so probability-only checks cannot "
                "hide phase drift."
            ),
        },
        {
            "item": "adapter_manifest_transition_policy",
            "status": "missing",
            "required": True,
            "description": (
                "Define the manifest migration from blocked CCX to explicitly "
                "lowered CCX without silent support changes."
            ),
        },
    )


def _ccx_source_map_requirements() -> dict[str, Any]:
    return {
        "cardinality": "one_source_gate_to_many_lowered_operations",
        "required_fields": [
            "source_gate_id",
            "source_gate_name",
            "source_targets",
            "lowering_strategy",
            "lowered_operation_ids",
            "lowered_operation_count",
            "program_path",
        ],
        "diagnostic_policy": "diagnostics_must_reference_source_ccx_gate",
        "partial_payload_policy": "no_partial_payload_until_policy_defined",
    }


def _ccx_numerical_evidence_requirements() -> dict[str, Any]:
    return {
        "required_methods": [
            "statevector_equivalence",
            "probability_equivalence",
            "phase_sensitive_probe",
            "roundtrip_semantic_equivalence",
        ],
        "basis_inputs": [
            "000",
            "001",
            "010",
            "011",
            "100",
            "101",
            "110",
            "111",
        ],
        "tolerance": 1e-12,
        "global_phase_policy": "must_be_explicit",
        "qubit_order_policy": "must_match_reported_qubit_order",
        "metadata_only": True,
    }


def _ccx_negative_guards(
    blocked_policy_report: CCXBlockedPolicyReportIR | None,
) -> dict[str, Any]:
    return {
        "openqasm_import_must_block": True,
        "openqasm_export_must_block": True,
        "toffoli_lowering_supported": False,
        "source_map_policy_defined": False,
        "execution_package_created": False,
        "blocked_policy_report_status": (
            None if blocked_policy_report is None else blocked_policy_report.status
        ),
        "blocked_policy_report_id": (
            None if blocked_policy_report is None else blocked_policy_report.report_id
        ),
    }


def _preflight_diagnostic(
    *,
    code: str,
    severity: Literal["info", "error"],
    message: str,
    policy_status: CCXBlockedPolicyStatus,
) -> DiagnosticsIR:
    return DiagnosticsIR(
        diagnostic_id=f"ccx_decision_preflight.{code.lower()}",
        stage="serialization",
        severity=severity,
        code=code,
        message=message,
        object_path="ccx_decision_preflight",
        suggestion="Keep CCX blocked until all enabling evidence is present.",
        metadata={
            "phase": "235",
            "gate": CCX_BLOCKED_GATE,
            "decision": "remain_blocked",
            "blocked_reason": CCX_BLOCKED_REASON,
            "blocked_policy_status": policy_status,
            "missing_evidence": list(_CCX_PREFLIGHT_REQUIRED_EVIDENCE),
        },
    )
