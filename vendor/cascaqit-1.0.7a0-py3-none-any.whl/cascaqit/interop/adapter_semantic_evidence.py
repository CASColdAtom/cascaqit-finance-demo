"""Adapter-facing semantic evidence packages for restricted interop."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Literal

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.interop.ccx_blocked_policy import CCXBlockedPolicyReportIR
from cascaqit.interop.contracts import AdapterCapabilityManifestIR
from cascaqit.native_ir.base import IRMixin, canonicalize
from cascaqit.native_ir.models import SCHEMA_VERSION
from cascaqit.simulators.equivalence import DigitalSemanticEquivalenceReportIR

__all__ = [
    "AdapterSemanticEvidenceIntakeReportIR",
    "AdapterSemanticEvidencePackageIR",
    "build_adapter_semantic_evidence_package",
    "review_adapter_semantic_evidence_intake",
    "validate_adapter_semantic_evidence_replay_payload",
]

AdapterSemanticEvidenceStatus = Literal["ready", "drifted", "blocked"]
AdapterSemanticEvidenceIntakeStatus = Literal["ready", "drifted", "blocked"]


@dataclass(frozen=True)
class AdapterSemanticEvidencePackageIR(IRMixin):
    """Metadata-only package summarizing adapter semantic evidence."""

    package_id: str
    status: AdapterSemanticEvidenceStatus
    source_format: str
    target_format: str
    manifest_id: str
    semantic_evidence: dict[str, Any]
    evidence_summary: dict[str, Any]
    drift_fields: tuple[str, ...]
    diagnostics: tuple[DiagnosticsIR, ...]
    metadata_only: bool = True
    offline_deterministic: bool = True
    backend_called: bool = False
    cloud_called: bool = False
    network_accessed: bool = False
    external_sdk_imported: bool = False
    cascaqit_compat_required: bool = False
    execution_package_created: bool = False
    parser_invoked: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize evidence and enforce offline adapter boundaries."""
        if self.status not in ("ready", "drifted", "blocked"):
            raise ValueError(
                "AdapterSemanticEvidencePackageIR has unsupported status."
            )
        if not self.metadata_only:
            raise ValueError("Adapter semantic evidence must be metadata-only.")
        if not self.offline_deterministic:
            raise ValueError("Adapter semantic evidence must be deterministic.")
        if self.backend_called or self.cloud_called:
            raise ValueError("Adapter semantic evidence must not call backends/cloud.")
        if self.network_accessed:
            raise ValueError("Adapter semantic evidence must not access networks.")
        if self.external_sdk_imported:
            raise ValueError("Adapter semantic evidence must not import external SDKs.")
        if self.cascaqit_compat_required:
            raise ValueError("Adapter semantic evidence must not require compat.")
        if self.execution_package_created:
            raise ValueError("Adapter semantic evidence must not create packages.")
        if self.parser_invoked:
            raise ValueError("Adapter semantic evidence must not invoke parsers.")
        object.__setattr__(
            self,
            "semantic_evidence",
            canonicalize(self.semantic_evidence),
        )
        object.__setattr__(
            self,
            "evidence_summary",
            canonicalize(self.evidence_summary),
        )
        object.__setattr__(
            self,
            "drift_fields",
            tuple(str(item) for item in self.drift_fields),
        )
        object.__setattr__(
            self,
            "diagnostics",
            tuple(
                item
                if isinstance(item, DiagnosticsIR)
                else DiagnosticsIR.from_dict(item)
                for item in self.diagnostics
            ),
        )
        object.__setattr__(self, "metadata", canonicalize(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> AdapterSemanticEvidencePackageIR:
        """Build an adapter semantic evidence package from a dictionary."""
        if not isinstance(data, dict):
            raise TypeError(
                "AdapterSemanticEvidencePackageIR dictionary must be an object."
            )
        return cls(
            package_id=str(data["package_id"]),
            status=data["status"],
            source_format=str(data["source_format"]),
            target_format=str(data["target_format"]),
            manifest_id=str(data["manifest_id"]),
            semantic_evidence=dict(data.get("semantic_evidence", {})),
            evidence_summary=dict(data.get("evidence_summary", {})),
            drift_fields=tuple(str(item) for item in data.get("drift_fields", ())),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(item)
                for item in data.get("diagnostics", ())
            ),
            metadata_only=bool(data.get("metadata_only", True)),
            offline_deterministic=bool(data.get("offline_deterministic", True)),
            backend_called=bool(data.get("backend_called", False)),
            cloud_called=bool(data.get("cloud_called", False)),
            network_accessed=bool(data.get("network_accessed", False)),
            external_sdk_imported=bool(data.get("external_sdk_imported", False)),
            cascaqit_compat_required=bool(
                data.get("cascaqit_compat_required", False)
            ),
            execution_package_created=bool(
                data.get("execution_package_created", False)
            ),
            parser_invoked=bool(data.get("parser_invoked", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> AdapterSemanticEvidencePackageIR:
        """Build an adapter semantic evidence package from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError(
                "AdapterSemanticEvidencePackageIR JSON must contain an object."
            )
        return cls.from_dict(data)


@dataclass(frozen=True)
class AdapterSemanticEvidenceIntakeReportIR(IRMixin):
    """Metadata-only report for reviewing submitted semantic evidence."""

    report_id: str
    status: AdapterSemanticEvidenceIntakeStatus
    package_id: str
    manifest_id: str
    source_format: str
    target_format: str
    required_evidence_paths: tuple[str, ...]
    observed_evidence_paths: tuple[str, ...]
    missing_evidence_paths: tuple[str, ...]
    drift_fields: tuple[str, ...]
    side_effect_flags: dict[str, bool]
    diagnostics: tuple[DiagnosticsIR, ...]
    metadata_only: bool = True
    replay_only: bool = True
    offline_deterministic: bool = True
    backend_called: bool = False
    cloud_called: bool = False
    network_accessed: bool = False
    external_sdk_imported: bool = False
    cascaqit_compat_required: bool = False
    execution_package_created: bool = False
    parser_invoked: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize intake evidence and enforce no-side-effect boundaries."""
        if self.status not in ("ready", "drifted", "blocked"):
            raise ValueError(
                "AdapterSemanticEvidenceIntakeReportIR has unsupported status."
            )
        if not self.metadata_only:
            raise ValueError("Adapter semantic evidence intake must be metadata-only.")
        if not self.replay_only:
            raise ValueError("Adapter semantic evidence intake must be replay-only.")
        if not self.offline_deterministic:
            raise ValueError(
                "Adapter semantic evidence intake must be deterministic."
            )
        if self.backend_called or self.cloud_called:
            raise ValueError(
                "Adapter semantic evidence intake must not call backends/cloud."
            )
        if self.network_accessed:
            raise ValueError(
                "Adapter semantic evidence intake must not access networks."
            )
        if self.external_sdk_imported:
            raise ValueError(
                "Adapter semantic evidence intake must not import external SDKs."
            )
        if self.cascaqit_compat_required:
            raise ValueError(
                "Adapter semantic evidence intake must not require compat."
            )
        if self.execution_package_created:
            raise ValueError(
                "Adapter semantic evidence intake must not create packages."
            )
        if self.parser_invoked:
            raise ValueError(
                "Adapter semantic evidence intake must not invoke parsers."
            )
        object.__setattr__(
            self,
            "required_evidence_paths",
            tuple(str(item) for item in self.required_evidence_paths),
        )
        object.__setattr__(
            self,
            "observed_evidence_paths",
            tuple(str(item) for item in self.observed_evidence_paths),
        )
        object.__setattr__(
            self,
            "missing_evidence_paths",
            tuple(str(item) for item in self.missing_evidence_paths),
        )
        object.__setattr__(
            self,
            "drift_fields",
            tuple(str(item) for item in self.drift_fields),
        )
        object.__setattr__(
            self,
            "side_effect_flags",
            canonicalize(self.side_effect_flags),
        )
        object.__setattr__(
            self,
            "diagnostics",
            tuple(
                item
                if isinstance(item, DiagnosticsIR)
                else DiagnosticsIR.from_dict(item)
                for item in self.diagnostics
            ),
        )
        object.__setattr__(self, "metadata", canonicalize(self.metadata))

    @classmethod
    def from_dict(
        cls,
        data: dict[str, Any],
    ) -> AdapterSemanticEvidenceIntakeReportIR:
        """Build an adapter semantic evidence intake report from a dictionary."""
        if not isinstance(data, dict):
            raise TypeError(
                "AdapterSemanticEvidenceIntakeReportIR dictionary must be an object."
            )
        return cls(
            report_id=str(data["report_id"]),
            status=data["status"],
            package_id=str(data["package_id"]),
            manifest_id=str(data["manifest_id"]),
            source_format=str(data["source_format"]),
            target_format=str(data["target_format"]),
            required_evidence_paths=tuple(
                str(item) for item in data.get("required_evidence_paths", ())
            ),
            observed_evidence_paths=tuple(
                str(item) for item in data.get("observed_evidence_paths", ())
            ),
            missing_evidence_paths=tuple(
                str(item) for item in data.get("missing_evidence_paths", ())
            ),
            drift_fields=tuple(str(item) for item in data.get("drift_fields", ())),
            side_effect_flags=dict(data.get("side_effect_flags", {})),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(item)
                for item in data.get("diagnostics", ())
            ),
            metadata_only=bool(data.get("metadata_only", True)),
            replay_only=bool(data.get("replay_only", True)),
            offline_deterministic=bool(data.get("offline_deterministic", True)),
            backend_called=bool(data.get("backend_called", False)),
            cloud_called=bool(data.get("cloud_called", False)),
            network_accessed=bool(data.get("network_accessed", False)),
            external_sdk_imported=bool(data.get("external_sdk_imported", False)),
            cascaqit_compat_required=bool(
                data.get("cascaqit_compat_required", False)
            ),
            execution_package_created=bool(
                data.get("execution_package_created", False)
            ),
            parser_invoked=bool(data.get("parser_invoked", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> AdapterSemanticEvidenceIntakeReportIR:
        """Build an adapter semantic evidence intake report from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError(
                "AdapterSemanticEvidenceIntakeReportIR JSON must contain an object."
            )
        return cls.from_dict(data)


def build_adapter_semantic_evidence_package(
    *,
    manifest: AdapterCapabilityManifestIR,
    direct_equivalence: DigitalSemanticEquivalenceReportIR | None = None,
    lowered_equivalence: DigitalSemanticEquivalenceReportIR | None = None,
    blocked_policy: CCXBlockedPolicyReportIR | None = None,
    package_id: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> AdapterSemanticEvidencePackageIR:
    """Build metadata-only semantic evidence for adapter review."""
    evidence: dict[str, Any] = {
        "manifest": _manifest_evidence(manifest),
    }
    if direct_equivalence is not None:
        evidence["direct_equivalence"] = _equivalence_evidence(
            direct_equivalence,
            evidence_kind="direct_gate_equivalence",
        )
    if lowered_equivalence is not None:
        evidence["lowered_equivalence"] = _equivalence_evidence(
            lowered_equivalence,
            evidence_kind="lowered_gate_equivalence",
        )
    if blocked_policy is not None:
        evidence["blocked_policy"] = _blocked_policy_evidence(blocked_policy)

    drift_fields = _drift_fields(evidence)
    status: AdapterSemanticEvidenceStatus
    if len(evidence) == 1:
        status = "blocked"
        drift_fields = ("semantic_evidence",)
    else:
        status = "drifted" if drift_fields else "ready"
    diagnostics = (
        _diagnostic(
            code="ADAPTER_SEMANTIC_EVIDENCE_READY",
            severity="info",
            message="Adapter semantic evidence is aligned.",
            drift_fields=(),
        ),
    )
    if status == "drifted":
        diagnostics = (
            _diagnostic(
                code="ADAPTER_SEMANTIC_EVIDENCE_DRIFT",
                severity="error",
                message="Adapter semantic evidence contains drift.",
                drift_fields=drift_fields,
            ),
        )
    elif status == "blocked":
        diagnostics = (
            _diagnostic(
                code="ADAPTER_SEMANTIC_EVIDENCE_MISSING",
                severity="error",
                message="Adapter semantic evidence package requires evidence paths.",
                drift_fields=drift_fields,
            ),
        )

    return AdapterSemanticEvidencePackageIR(
        package_id=package_id
        or f"adapter_semantic_evidence.{manifest.source_format}.to."
        f"{manifest.target_format}",
        status=status,
        source_format=manifest.source_format,
        target_format=manifest.target_format,
        manifest_id=manifest.manifest_id,
        semantic_evidence=evidence,
        evidence_summary=_evidence_summary(evidence),
        drift_fields=drift_fields,
        diagnostics=diagnostics,
        metadata={
            **({} if metadata is None else dict(metadata)),
            "phase": "228",
            "contract": "adapter_semantic_evidence_package",
            "semantic_evidence_level": "simulator_backed_probability_equivalence",
            "metadata_only": True,
            "offline_deterministic": True,
            "full_openqasm3_supported": False,
        },
    )


def review_adapter_semantic_evidence_intake(
    *,
    package: AdapterSemanticEvidencePackageIR,
    expected_manifest: AdapterCapabilityManifestIR | None = None,
    required_evidence_paths: tuple[str, ...] = (
        "direct_equivalence",
        "lowered_equivalence",
        "blocked_policy",
    ),
    report_id: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> AdapterSemanticEvidenceIntakeReportIR:
    """Review a submitted semantic evidence package without side effects."""
    observed = tuple(
        str(item)
        for item in package.evidence_summary.get("semantic_evidence_paths", ())
    )
    required = tuple(str(item) for item in required_evidence_paths)
    missing = tuple(item for item in required if item not in observed)
    side_effect_flags = _intake_side_effect_flags(package, expected_manifest)
    drift_fields = _intake_drift_fields(
        package=package,
        expected_manifest=expected_manifest,
        missing_evidence_paths=missing,
        side_effect_flags=side_effect_flags,
    )
    status: AdapterSemanticEvidenceIntakeStatus
    if package.status == "blocked" or missing or any(side_effect_flags.values()):
        status = "blocked"
    elif package.status == "drifted" or drift_fields:
        status = "drifted"
    else:
        status = "ready"

    return AdapterSemanticEvidenceIntakeReportIR(
        report_id=report_id or f"adapter_semantic_evidence_intake.{package.package_id}",
        status=status,
        package_id=package.package_id,
        manifest_id=package.manifest_id,
        source_format=package.source_format,
        target_format=package.target_format,
        required_evidence_paths=required,
        observed_evidence_paths=observed,
        missing_evidence_paths=missing,
        drift_fields=drift_fields,
        side_effect_flags=side_effect_flags,
        diagnostics=(
            _intake_diagnostic(
                status=status,
                drift_fields=drift_fields,
                missing_evidence_paths=missing,
                side_effect_flags=side_effect_flags,
            ),
        ),
        metadata={
            "phase": "231",
            "contract": "adapter_semantic_evidence_intake",
            "metadata_only": True,
            "replay_only": True,
            "offline_deterministic": True,
            "package_status": package.status,
            **({} if metadata is None else dict(metadata)),
        },
    )


def validate_adapter_semantic_evidence_replay_payload(
    payload: str | dict[str, Any],
    *,
    expected_manifest: AdapterCapabilityManifestIR | None = None,
    required_evidence_paths: tuple[str, ...] = (
        "direct_equivalence",
        "lowered_equivalence",
        "blocked_policy",
    ),
    report_id: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> AdapterSemanticEvidenceIntakeReportIR:
    """Validate a submitted evidence payload without parser or backend calls."""
    data = _coerce_replay_payload(payload)
    side_effect_flags = _payload_side_effect_flags(data)
    if any(side_effect_flags.values()):
        return _blocked_replay_payload_report(
            data=data,
            required_evidence_paths=required_evidence_paths,
            side_effect_flags=side_effect_flags,
            report_id=report_id,
            metadata=metadata,
        )
    package = AdapterSemanticEvidencePackageIR.from_dict(data)
    return review_adapter_semantic_evidence_intake(
        package=package,
        expected_manifest=expected_manifest,
        required_evidence_paths=required_evidence_paths,
        report_id=report_id,
        metadata={
            **({} if metadata is None else dict(metadata)),
            "phase": "232",
            "contract": "adapter_semantic_evidence_replay_validation",
            "payload_validation": "replay_only",
        },
    )


def _manifest_evidence(manifest: AdapterCapabilityManifestIR) -> dict[str, Any]:
    return {
        "manifest_id": manifest.manifest_id,
        "status": manifest.status,
        "mapping_coverage_id": manifest.mapping_coverage_id,
        "source_format": manifest.source_format,
        "target_format": manifest.target_format,
        "direct_gates": list(manifest.metadata.get("direct_gates", ())),
        "lowered_gates": dict(manifest.metadata.get("lowered_gates", {})),
        "blocked_gates": list(manifest.metadata.get("blocked_gates", ())),
        "blocked_reasons": dict(manifest.metadata.get("blocked_reasons", {})),
        "semantic_evidence_required": bool(
            manifest.metadata.get("semantic_evidence_required", False)
        ),
        "semantic_evidence_level": manifest.metadata.get("semantic_evidence_level"),
        "metadata_only": manifest.metadata_only,
        "parser_implemented": manifest.parser_implemented,
        "external_object_constructed": manifest.external_object_constructed,
        "execution_package_created": manifest.execution_package_created,
        "backend_called": manifest.backend_called,
        "network_accessed": manifest.network_accessed,
        "cascaqit_compat_required": manifest.cascaqit_compat_required,
    }


def _equivalence_evidence(
    report: DigitalSemanticEquivalenceReportIR,
    *,
    evidence_kind: str,
) -> dict[str, Any]:
    return {
        "evidence_kind": evidence_kind,
        "report_id": report.report_id,
        "status": report.status,
        "basis": report.basis,
        "qubit_order": list(report.qubit_order),
        "tolerance": report.tolerance,
        "max_probability_delta": report.max_probability_delta,
        "drift_bitstrings": list(report.drift_bitstrings),
        "matched_bitstrings": list(report.matched_bitstrings),
        "diagnostic_codes": [diagnostic.code for diagnostic in report.diagnostics],
        "metadata_only": report.metadata_only,
        "offline_deterministic": report.offline_deterministic,
        "simulator_name": report.simulator_name,
        "backend_called": report.backend_called,
        "cloud_called": report.cloud_called,
        "network_accessed": report.network_accessed,
        "external_sdk_imported": report.external_sdk_imported,
        "cascaqit_compat_required": report.cascaqit_compat_required,
        "execution_package_created": report.execution_package_created,
        "comparison_kind": report.metadata.get("comparison_kind"),
        "probability_source": report.metadata.get("probability_source"),
        "state_bytes_required": report.metadata.get("state_bytes_required"),
    }


def _blocked_policy_evidence(report: CCXBlockedPolicyReportIR) -> dict[str, Any]:
    return {
        "report_id": report.report_id,
        "status": report.status,
        "blocked_gate": report.blocked_gate,
        "blocked_reason": report.blocked_reason,
        "drift_fields": list(report.drift_fields),
        "diagnostic_codes": [diagnostic.code for diagnostic in report.diagnostics],
        "metadata_only": report.metadata_only,
        "backend_called": report.backend_called,
        "cloud_called": report.cloud_called,
        "network_accessed": report.network_accessed,
        "cascaqit_compat_required": report.cascaqit_compat_required,
        "execution_package_created": report.execution_package_created,
        "toffoli_lowering_supported": report.toffoli_lowering_supported,
        "source_map_policy_defined": report.source_map_policy_defined,
    }


def _drift_fields(evidence: dict[str, Any]) -> tuple[str, ...]:
    drift: list[str] = []
    manifest = evidence["manifest"]
    if manifest["status"] != "ready":
        drift.append("manifest.status")
    if not manifest["semantic_evidence_required"]:
        drift.append("manifest.semantic_evidence_required")
    if manifest["semantic_evidence_level"] != (
        "simulator_backed_probability_equivalence"
    ):
        drift.append("manifest.semantic_evidence_level")
    for boundary in _MANIFEST_BOUNDARY_FIELDS:
        if manifest[boundary]:
            drift.append(f"manifest.{boundary}")

    for name in ("direct_equivalence", "lowered_equivalence"):
        item = evidence.get(name)
        if item is None:
            continue
        if item["status"] != "equivalent":
            drift.append(f"{name}.status")
        if item["max_probability_delta"] is None:
            drift.append(f"{name}.max_probability_delta")
        if item["drift_bitstrings"]:
            drift.append(f"{name}.drift_bitstrings")
        for boundary in _BOUNDARY_FIELDS:
            if item[boundary]:
                drift.append(f"{name}.{boundary}")

    blocked = evidence.get("blocked_policy")
    if blocked is not None:
        if blocked["status"] != "aligned":
            drift.append("blocked_policy.status")
        if blocked["drift_fields"]:
            drift.append("blocked_policy.drift_fields")
        if blocked["toffoli_lowering_supported"]:
            drift.append("blocked_policy.toffoli_lowering_supported")
        if blocked["source_map_policy_defined"]:
            drift.append("blocked_policy.source_map_policy_defined")
        for boundary in (
            "backend_called",
            "cloud_called",
            "network_accessed",
            "cascaqit_compat_required",
            "execution_package_created",
        ):
            if blocked[boundary]:
                drift.append(f"blocked_policy.{boundary}")
    return tuple(drift)


def _evidence_summary(evidence: dict[str, Any]) -> dict[str, Any]:
    direct = evidence.get("direct_equivalence")
    lowered = evidence.get("lowered_equivalence")
    blocked = evidence.get("blocked_policy")
    return {
        "manifest_status": evidence["manifest"]["status"],
        "direct_equivalence_status": None if direct is None else direct["status"],
        "lowered_equivalence_status": None if lowered is None else lowered["status"],
        "blocked_policy_status": None if blocked is None else blocked["status"],
        "semantic_evidence_paths": sorted(
            key for key in evidence if key != "manifest"
        ),
        "max_probability_delta": _max_probability_delta(direct, lowered),
        "blocked_gates": evidence["manifest"]["blocked_gates"],
        "blocked_reasons": evidence["manifest"]["blocked_reasons"],
    }


def _max_probability_delta(
    *items: dict[str, Any] | None,
) -> float | None:
    deltas = [
        float(item["max_probability_delta"])
        for item in items
        if item is not None and item["max_probability_delta"] is not None
    ]
    return max(deltas) if deltas else None


def _diagnostic(
    *,
    code: str,
    severity: Literal["info", "error"],
    message: str,
    drift_fields: tuple[str, ...],
) -> DiagnosticsIR:
    return DiagnosticsIR(
        diagnostic_id=f"adapter_semantic_evidence.{code.lower()}",
        stage="serialization",
        severity=severity,
        code=code,
        message=message,
        object_path="adapter_semantic_evidence",
        suggestion=(
            "Review manifest policy, simulator equivalence reports, and blocked "
            "gate policy evidence."
        ),
        metadata={
            "phase": "228",
            "drift_fields": list(drift_fields),
            "metadata_only": True,
            "offline_deterministic": True,
        },
    )


def _intake_side_effect_flags(
    package: AdapterSemanticEvidencePackageIR,
    manifest: AdapterCapabilityManifestIR | None,
) -> dict[str, bool]:
    flags = {
        "package.backend_called": package.backend_called,
        "package.cloud_called": package.cloud_called,
        "package.network_accessed": package.network_accessed,
        "package.external_sdk_imported": package.external_sdk_imported,
        "package.cascaqit_compat_required": package.cascaqit_compat_required,
        "package.execution_package_created": package.execution_package_created,
        "package.parser_invoked": package.parser_invoked,
    }
    if manifest is not None:
        flags.update(
            {
                "manifest.parser_implemented": manifest.parser_implemented,
                "manifest.external_object_constructed": (
                    manifest.external_object_constructed
                ),
                "manifest.execution_package_created": (
                    manifest.execution_package_created
                ),
                "manifest.backend_called": manifest.backend_called,
                "manifest.network_accessed": manifest.network_accessed,
                "manifest.cascaqit_compat_required": (
                    manifest.cascaqit_compat_required
                ),
            }
        )
    return flags


def _intake_drift_fields(
    *,
    package: AdapterSemanticEvidencePackageIR,
    expected_manifest: AdapterCapabilityManifestIR | None,
    missing_evidence_paths: tuple[str, ...],
    side_effect_flags: dict[str, bool],
) -> tuple[str, ...]:
    drift: list[str] = []
    if package.status != "ready":
        drift.append("package.status")
    if missing_evidence_paths:
        drift.append("missing_evidence_paths")
    drift.extend(
        f"side_effect_flags.{key}"
        for key, value in side_effect_flags.items()
        if value
    )
    if expected_manifest is not None:
        if package.manifest_id != expected_manifest.manifest_id:
            drift.append("manifest_id")
        if package.source_format != expected_manifest.source_format:
            drift.append("source_format")
        if package.target_format != expected_manifest.target_format:
            drift.append("target_format")
        package_manifest = package.semantic_evidence.get("manifest", {})
        if package_manifest.get("mapping_coverage_id") != (
            expected_manifest.mapping_coverage_id
        ):
            drift.append("manifest.mapping_coverage_id")
        if package_manifest.get("status") != expected_manifest.status:
            drift.append("manifest.status")
        if package_manifest.get("semantic_evidence_required") is not True:
            drift.append("manifest.semantic_evidence_required")
    drift.extend(f"package.{field}" for field in package.drift_fields)
    return tuple(dict.fromkeys(drift))


def _intake_diagnostic(
    *,
    status: AdapterSemanticEvidenceIntakeStatus,
    drift_fields: tuple[str, ...],
    missing_evidence_paths: tuple[str, ...],
    side_effect_flags: dict[str, bool],
) -> DiagnosticsIR:
    code = {
        "ready": "ADAPTER_SEMANTIC_EVIDENCE_INTAKE_READY",
        "drifted": "ADAPTER_SEMANTIC_EVIDENCE_INTAKE_DRIFT",
        "blocked": "ADAPTER_SEMANTIC_EVIDENCE_INTAKE_BLOCKED",
    }[status]
    return DiagnosticsIR(
        diagnostic_id=f"adapter_semantic_evidence_intake.{code.lower()}",
        stage="serialization",
        severity="info" if status == "ready" else "error",
        code=code,
        message=(
            "Adapter semantic evidence intake is ready."
            if status == "ready"
            else "Adapter semantic evidence intake found drift or blocked evidence."
        ),
        object_path="adapter_semantic_evidence_intake",
        suggestion=(
            "Submit metadata-only semantic evidence with direct, lowered, and "
            "blocked policy paths and no parser/backend/cloud side effects."
        ),
        metadata={
            "phase": "231",
            "drift_fields": list(drift_fields),
            "missing_evidence_paths": list(missing_evidence_paths),
            "side_effect_flags": side_effect_flags,
            "metadata_only": True,
            "replay_only": True,
        },
    )


def _coerce_replay_payload(payload: str | dict[str, Any]) -> dict[str, Any]:
    if isinstance(payload, str):
        data = json.loads(payload)
    elif isinstance(payload, dict):
        data = dict(payload)
    else:
        raise TypeError("Adapter semantic evidence replay payload must be JSON/dict.")
    if not isinstance(data, dict):
        raise TypeError("Adapter semantic evidence replay payload must be an object.")
    return data


def _payload_side_effect_flags(data: dict[str, Any]) -> dict[str, bool]:
    flags = {
        f"package.{field}": bool(data.get(field, False))
        for field in _PACKAGE_SIDE_EFFECT_FIELDS
    }
    semantic_evidence = data.get("semantic_evidence", {})
    if isinstance(semantic_evidence, dict):
        manifest = semantic_evidence.get("manifest", {})
        if isinstance(manifest, dict):
            flags.update(
                {
                    f"manifest.{field}": bool(manifest.get(field, False))
                    for field in _MANIFEST_PAYLOAD_SIDE_EFFECT_FIELDS
                }
            )
        for path in ("direct_equivalence", "lowered_equivalence"):
            evidence = semantic_evidence.get(path, {})
            if isinstance(evidence, dict):
                flags.update(
                    {
                        f"{path}.{field}": bool(evidence.get(field, False))
                        for field in _EQUIVALENCE_PAYLOAD_SIDE_EFFECT_FIELDS
                    }
                )
        blocked = semantic_evidence.get("blocked_policy", {})
        if isinstance(blocked, dict):
            flags.update(
                {
                    f"blocked_policy.{field}": bool(blocked.get(field, False))
                    for field in _BLOCKED_POLICY_PAYLOAD_SIDE_EFFECT_FIELDS
                }
            )
    return flags


def _blocked_replay_payload_report(
    *,
    data: dict[str, Any],
    required_evidence_paths: tuple[str, ...],
    side_effect_flags: dict[str, bool],
    report_id: str | None,
    metadata: dict[str, Any] | None,
) -> AdapterSemanticEvidenceIntakeReportIR:
    active_flags = tuple(
        f"side_effect_flags.{key}"
        for key, value in side_effect_flags.items()
        if value
    )
    package_id = str(data.get("package_id", "unknown"))
    manifest_id = str(data.get("manifest_id", "unknown"))
    source_format = str(data.get("source_format", "unknown"))
    target_format = str(data.get("target_format", "unknown"))
    observed = _payload_evidence_paths(data)
    missing = tuple(path for path in required_evidence_paths if path not in observed)
    drift_fields = tuple(
        dict.fromkeys(
            (
                "replay_payload.side_effects",
                *active_flags,
                *(("missing_evidence_paths",) if missing else ()),
            )
        )
    )
    return AdapterSemanticEvidenceIntakeReportIR(
        report_id=report_id
        or f"adapter_semantic_evidence_replay_validation.{package_id}",
        status="blocked",
        package_id=package_id,
        manifest_id=manifest_id,
        source_format=source_format,
        target_format=target_format,
        required_evidence_paths=tuple(str(item) for item in required_evidence_paths),
        observed_evidence_paths=observed,
        missing_evidence_paths=missing,
        drift_fields=drift_fields,
        side_effect_flags=side_effect_flags,
        diagnostics=(
            _replay_payload_diagnostic(
                drift_fields=drift_fields,
                missing_evidence_paths=missing,
                side_effect_flags=side_effect_flags,
            ),
        ),
        metadata={
            **({} if metadata is None else dict(metadata)),
            "phase": "232",
            "contract": "adapter_semantic_evidence_replay_validation",
            "payload_validation": "blocked_before_ir_construction",
        },
    )


def _payload_evidence_paths(data: dict[str, Any]) -> tuple[str, ...]:
    summary = data.get("evidence_summary", {})
    if isinstance(summary, dict):
        paths = summary.get("semantic_evidence_paths", ())
        if isinstance(paths, (list, tuple)):
            return tuple(str(item) for item in paths)
    evidence = data.get("semantic_evidence", {})
    if isinstance(evidence, dict):
        return tuple(sorted(str(key) for key in evidence if key != "manifest"))
    return ()


def _replay_payload_diagnostic(
    *,
    drift_fields: tuple[str, ...],
    missing_evidence_paths: tuple[str, ...],
    side_effect_flags: dict[str, bool],
) -> DiagnosticsIR:
    return DiagnosticsIR(
        diagnostic_id=(
            "adapter_semantic_evidence_replay."
            "adapter_semantic_evidence_replay_side_effects"
        ),
        stage="serialization",
        severity="error",
        code="ADAPTER_SEMANTIC_EVIDENCE_REPLAY_SIDE_EFFECTS",
        message=(
            "Adapter semantic evidence replay payload declares forbidden side "
            "effects."
        ),
        object_path="adapter_semantic_evidence_replay_payload",
        suggestion=(
            "Submit an offline metadata-only evidence payload with parser, "
            "external SDK, compat, backend, cloud, network, credential, and "
            "execution-package flags set to false."
        ),
        metadata={
            "phase": "232",
            "drift_fields": list(drift_fields),
            "missing_evidence_paths": list(missing_evidence_paths),
            "side_effect_flags": side_effect_flags,
            "metadata_only": True,
            "replay_only": True,
        },
    )


_MANIFEST_BOUNDARY_FIELDS = (
    "parser_implemented",
    "external_object_constructed",
    "execution_package_created",
    "backend_called",
    "network_accessed",
    "cascaqit_compat_required",
)

_BOUNDARY_FIELDS = (
    "backend_called",
    "cloud_called",
    "network_accessed",
    "external_sdk_imported",
    "cascaqit_compat_required",
    "execution_package_created",
)

_PACKAGE_SIDE_EFFECT_FIELDS = (
    "backend_called",
    "cloud_called",
    "network_accessed",
    "credential_accessed",
    "external_sdk_imported",
    "external_object_constructed",
    "cascaqit_compat_required",
    "execution_package_created",
    "parser_invoked",
)

_MANIFEST_PAYLOAD_SIDE_EFFECT_FIELDS = (
    "parser_implemented",
    "external_object_constructed",
    "execution_package_created",
    "backend_called",
    "cloud_called",
    "network_accessed",
    "credential_accessed",
    "cascaqit_compat_required",
)

_EQUIVALENCE_PAYLOAD_SIDE_EFFECT_FIELDS = (
    "backend_called",
    "cloud_called",
    "network_accessed",
    "credential_accessed",
    "external_sdk_imported",
    "cascaqit_compat_required",
    "execution_package_created",
    "parser_invoked",
)

_BLOCKED_POLICY_PAYLOAD_SIDE_EFFECT_FIELDS = (
    "backend_called",
    "cloud_called",
    "network_accessed",
    "credential_accessed",
    "external_sdk_imported",
    "external_object_constructed",
    "cascaqit_compat_required",
    "execution_package_created",
    "parser_invoked",
)
