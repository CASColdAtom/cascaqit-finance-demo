"""Shared policy constants for blocked CCX OpenQASM interop."""

from __future__ import annotations

CCX_BLOCKED_GATE = "ccx"
CCX_BLOCKED_REASON = "toffoli_lowering_policy_missing"
CCX_BLOCKED_STATUS = "blocked"
CCX_BLOCKED_DIAGNOSTIC_CODE = "OPENQASM_CCX_BLOCKED"
CCX_BLOCKED_MESSAGE = (
    "CCX is blocked until stable Toffoli lowering and source-map policy exist."
)
CCX_BLOCKED_SUGGESTION = (
    "Keep CCX as native DigitalProgramIR or wait for an explicit Toffoli "
    "lowering policy."
)
CCX_BLOCKED_METADATA = {
    "gate": CCX_BLOCKED_GATE,
    "blocked": True,
    "blocked_gate": CCX_BLOCKED_GATE,
    "blocked_status": CCX_BLOCKED_STATUS,
    "blocked_reason": CCX_BLOCKED_REASON,
    "reason_category": "unsupported_gate",
    "toffoli_lowering_supported": False,
    "partial_payload_emitted": False,
    "source_map_policy_defined": False,
}
