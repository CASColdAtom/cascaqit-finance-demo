"""Bit-order and measurement-mapping invariant checks for digital interop."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Literal

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.digital import DigitalMeasurementProjectionIR, DigitalProgramIR
from cascaqit.interop.openqasm3_export import OpenQASM3ExportResultIR
from cascaqit.interop.openqasm3_roundtrip import OpenQASM3RoundTripReportIR
from cascaqit.interop.openqasm3_subset import OpenQASM3SubsetImportResultIR
from cascaqit.native_ir.base import IRMixin, canonicalize
from cascaqit.native_ir.models import SCHEMA_VERSION

__all__ = [
    "BitOrderInvariantReportIR",
    "check_digital_bit_order_invariants",
]

BitOrderInvariantStatus = Literal["consistent", "drifted", "blocked"]


@dataclass(frozen=True)
class BitOrderInvariantReportIR(IRMixin):
    """Report for digital bit-order and measurement-mapping invariants."""

    report_id: str
    status: BitOrderInvariantStatus
    program_id: str
    qubit_order: tuple[str, ...]
    bitstring_index: str
    measurement_entries: tuple[dict[str, Any], ...]
    checked_paths: tuple[str, ...]
    matched_invariants: tuple[str, ...]
    drift_invariants: tuple[str, ...]
    diagnostics: tuple[DiagnosticsIR, ...]
    metadata_only: bool = True
    backend_called: bool = False
    cloud_called: bool = False
    network_accessed: bool = False
    cascaqit_compat_required: bool = False
    execution_package_created: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize report payload and enforce offline boundaries."""
        if not self.metadata_only:
            raise ValueError("Bit-order invariant reports must remain metadata-only.")
        if self.backend_called or self.cloud_called:
            raise ValueError("Bit-order invariant checks must not call backends.")
        if self.network_accessed:
            raise ValueError("Bit-order invariant checks must not access networks.")
        if self.cascaqit_compat_required:
            raise ValueError("Bit-order invariant checks must not require compat.")
        if self.execution_package_created:
            raise ValueError("Bit-order invariant checks must not create packages.")
        object.__setattr__(
            self,
            "qubit_order",
            tuple(str(qubit) for qubit in self.qubit_order),
        )
        object.__setattr__(
            self,
            "measurement_entries",
            tuple(canonicalize(dict(entry)) for entry in self.measurement_entries),
        )
        object.__setattr__(
            self,
            "checked_paths",
            tuple(str(path) for path in self.checked_paths),
        )
        object.__setattr__(
            self,
            "matched_invariants",
            tuple(str(item) for item in self.matched_invariants),
        )
        object.__setattr__(
            self,
            "drift_invariants",
            tuple(str(item) for item in self.drift_invariants),
        )
        object.__setattr__(
            self,
            "diagnostics",
            tuple(
                diagnostic
                if isinstance(diagnostic, DiagnosticsIR)
                else DiagnosticsIR.from_dict(diagnostic)
                for diagnostic in self.diagnostics
            ),
        )
        object.__setattr__(self, "metadata", canonicalize(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> BitOrderInvariantReportIR:
        """Build a bit-order invariant report from a dictionary."""
        return cls(
            report_id=str(data["report_id"]),
            status=data["status"],
            program_id=str(data["program_id"]),
            qubit_order=tuple(str(item) for item in data.get("qubit_order", ())),
            bitstring_index=str(data["bitstring_index"]),
            measurement_entries=tuple(
                dict(item) for item in data.get("measurement_entries", ())
            ),
            checked_paths=tuple(str(item) for item in data.get("checked_paths", ())),
            matched_invariants=tuple(
                str(item) for item in data.get("matched_invariants", ())
            ),
            drift_invariants=tuple(
                str(item) for item in data.get("drift_invariants", ())
            ),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(item)
                for item in data.get("diagnostics", ())
            ),
            metadata_only=bool(data.get("metadata_only", True)),
            backend_called=bool(data.get("backend_called", False)),
            cloud_called=bool(data.get("cloud_called", False)),
            network_accessed=bool(data.get("network_accessed", False)),
            cascaqit_compat_required=bool(
                data.get("cascaqit_compat_required", False)
            ),
            execution_package_created=bool(
                data.get("execution_package_created", False)
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> BitOrderInvariantReportIR:
        """Build a bit-order invariant report from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("BitOrderInvariantReportIR JSON must contain an object.")
        return cls.from_dict(data)


def check_digital_bit_order_invariants(
    program: DigitalProgramIR,
    *,
    report_id: str | None = None,
    export_result: OpenQASM3ExportResultIR | None = None,
    import_result: OpenQASM3SubsetImportResultIR | None = None,
    round_trip_report: OpenQASM3RoundTripReportIR | None = None,
    projection: DigitalMeasurementProjectionIR | None = None,
    metadata: dict[str, Any] | None = None,
) -> BitOrderInvariantReportIR:
    """Check digital bit-order invariants across interop evidence."""
    if not isinstance(program, DigitalProgramIR):
        raise TypeError("check_digital_bit_order_invariants requires DigitalProgramIR.")
    contexts = _collect_contexts(
        program,
        export_result=export_result,
        import_result=import_result,
        round_trip_report=round_trip_report,
        projection=projection,
    )
    diagnostics: list[DiagnosticsIR] = []
    drift_invariants: list[str] = []
    matched_invariants: list[str] = []
    reference = contexts["native"]
    for name, context in contexts.items():
        if name == "native":
            continue
        _compare_context(
            name,
            reference,
            context,
            diagnostics=diagnostics,
            drift_invariants=drift_invariants,
            matched_invariants=matched_invariants,
        )
    if diagnostics:
        status: BitOrderInvariantStatus = "drifted"
    elif len(contexts) == 1:
        status = "blocked"
        diagnostics.append(
            _diagnostic(
                code="DIGITAL_BIT_ORDER_INVARIANT_EVIDENCE_MISSING",
                severity="error",
                message=(
                    "Bit-order invariant checks require at least one evidence path."
                ),
                invariant="evidence",
                path="digital_bit_order_invariants",
            )
        )
        drift_invariants.append("evidence")
    else:
        status = "consistent"
        matched_invariants = sorted(set(matched_invariants))
        diagnostics.append(
            _diagnostic(
                code="DIGITAL_BIT_ORDER_INVARIANTS_CONSISTENT",
                severity="info",
                message="Digital bit-order and measurement mapping are consistent.",
                invariant="all",
                path="digital_bit_order_invariants",
            )
        )
    return BitOrderInvariantReportIR(
        report_id=report_id or f"digital_bit_order_invariants.{program.program_id}",
        status=status,
        program_id=program.program_id,
        qubit_order=tuple(reference["qubit_order"]),
        bitstring_index=str(reference["bitstring_index"]),
        measurement_entries=tuple(reference["measurement_entries"]),
        checked_paths=tuple(contexts),
        matched_invariants=tuple(sorted(set(matched_invariants))),
        drift_invariants=tuple(sorted(set(drift_invariants))),
        diagnostics=tuple(diagnostics),
        metadata={
            **({} if metadata is None else dict(metadata)),
            "phase": "226",
            "invariant_scope": (
                "native_import_export_lowered_projection_bit_order"
            ),
            "context_count": len(contexts),
            "contexts": {name: context for name, context in contexts.items()},
            "projection_checked": projection is not None,
            "round_trip_checked": round_trip_report is not None,
            "export_checked": export_result is not None,
            "import_checked": import_result is not None,
        },
    )


def _collect_contexts(
    program: DigitalProgramIR,
    *,
    export_result: OpenQASM3ExportResultIR | None,
    import_result: OpenQASM3SubsetImportResultIR | None,
    round_trip_report: OpenQASM3RoundTripReportIR | None,
    projection: DigitalMeasurementProjectionIR | None,
) -> dict[str, dict[str, Any]]:
    contexts = {"native": _native_context(program)}
    if export_result is not None:
        contexts["export"] = _export_context(export_result)
    if import_result is not None:
        if import_result.program is None:
            contexts["import"] = _empty_context()
        else:
            contexts["import"] = _import_context(import_result)
    if round_trip_report is not None:
        contexts["round_trip"] = _round_trip_context(round_trip_report)
    if projection is not None:
        contexts["projection"] = _projection_context(projection)
    return contexts


def _compare_context(
    name: str,
    reference: dict[str, Any],
    context: dict[str, Any],
    *,
    diagnostics: list[DiagnosticsIR],
    drift_invariants: list[str],
    matched_invariants: list[str],
) -> None:
    checks = (
        ("qubit_order", "DIGITAL_BIT_ORDER_QUBIT_ORDER_DRIFT"),
        ("bitstring_index", "DIGITAL_BIT_ORDER_BITSTRING_INDEX_DRIFT"),
        ("measurement_entries", "DIGITAL_BIT_ORDER_MEASUREMENT_MAPPING_DRIFT"),
    )
    for invariant, code in checks:
        if context.get(invariant) == reference.get(invariant):
            matched_invariants.append(f"{name}.{invariant}")
            continue
        drift_invariants.append(f"{name}.{invariant}")
        diagnostics.append(
            _diagnostic(
                code=code,
                severity="error",
                message=f"{name} {invariant} differs from native program.",
                invariant=invariant,
                path=name,
                metadata={
                    "expected": reference.get(invariant),
                    "actual": context.get(invariant),
                },
            )
        )


def _native_context(program: DigitalProgramIR) -> dict[str, Any]:
    return {
        "qubit_order": list(program.circuit.qubits),
        "bitstring_index": "left_to_right_matches_qubit_order",
        "measurement_entries": _native_measurement_entries(program),
    }


def _export_context(export_result: OpenQASM3ExportResultIR) -> dict[str, Any]:
    return {
        "qubit_order": list(export_result.bit_order.get("qubit_order", ())),
        "bitstring_index": export_result.bit_order.get(
            "bitstring_index",
            "left_to_right_matches_qubit_order",
        ),
        "measurement_entries": _entries_from_export_mapping(
            export_result.measurement_mapping
        ),
    }


def _import_context(import_result: OpenQASM3SubsetImportResultIR) -> dict[str, Any]:
    return {
        "qubit_order": list(import_result.bit_order.get("qubit_order", ())),
        "bitstring_index": import_result.bit_order.get(
            "bitstring_index",
            "left_to_right_matches_qubit_order",
        ),
        "measurement_entries": _entries_from_import_mapping(
            import_result.measurement_mapping
        ),
    }


def _round_trip_context(report: OpenQASM3RoundTripReportIR) -> dict[str, Any]:
    summary = report.imported_summary or report.original_summary
    if summary is None:
        return _empty_context()
    return {
        "qubit_order": list(summary.bit_order.get("qubit_order", ())),
        "bitstring_index": summary.bit_order.get(
            "bitstring_index",
            "left_to_right_matches_qubit_order",
        ),
        "measurement_entries": _entries_from_summary_mapping(
            summary.measurement_mapping
        ),
    }


def _projection_context(projection: DigitalMeasurementProjectionIR) -> dict[str, Any]:
    return {
        "qubit_order": _projection_qubit_order(projection),
        "bitstring_index": _projection_bitstring_index(projection),
        "measurement_entries": _entries_from_projection(projection),
    }


def _empty_context() -> dict[str, Any]:
    return {
        "qubit_order": [],
        "bitstring_index": "missing",
        "measurement_entries": [],
    }


def _native_measurement_entries(program: DigitalProgramIR) -> list[dict[str, Any]]:
    qubit_index = {qubit: index for index, qubit in enumerate(program.circuit.qubits)}
    entries: list[dict[str, Any]] = []
    classical_index = 0
    for measurement in program.circuit.measurements:
        for target in measurement.targets:
            entries.append(
                {
                    "target": target,
                    "target_index": qubit_index[target],
                    "classical_index": classical_index,
                }
            )
            classical_index += 1
    return entries


def _entries_from_export_mapping(mapping: dict[str, Any]) -> list[dict[str, Any]]:
    return [
        {
            "target": entry.get("target"),
            "target_index": entry.get("target_index"),
            "classical_index": entry.get("classical_index"),
        }
        for entry in mapping.get("entries", ())
    ]


def _entries_from_import_mapping(mapping: dict[str, Any]) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    for measurement in mapping.get("measurements", ()):
        target = _first(measurement.get("targets", ()))
        entries.append(
            {
                "target": target,
                "target_index": _target_index(target),
                "classical_index": _classical_index(
                    measurement.get("classical_bit")
                ),
            }
        )
    return entries


def _entries_from_summary_mapping(mapping: dict[str, Any]) -> list[dict[str, Any]]:
    return [
        {
            "target": entry.get("target"),
            "target_index": entry.get("target_index"),
            "classical_index": entry.get("classical_index"),
        }
        for entry in mapping.get("entries", ())
    ]


def _entries_from_projection(
    projection: DigitalMeasurementProjectionIR,
) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    classical_index = 0
    for register in projection.registers:
        for target, target_index in zip(register.targets, register.target_bit_indices):
            entries.append(
                {
                    "target": target,
                    "target_index": target_index,
                    "classical_index": classical_index,
                }
            )
            classical_index += 1
    return entries


def _projection_qubit_order(
    projection: DigitalMeasurementProjectionIR,
) -> list[str]:
    entries = [
        (index, target)
        for register in projection.registers
        for target, index in zip(register.targets, register.target_bit_indices)
    ]
    max_index = max((index for index, _ in entries), default=-1)
    by_index = {index: target for index, target in entries}
    return [
        str(by_index.get(index, f"<uncovered:{index}>"))
        for index in range(max_index + 1)
    ]


def _projection_bitstring_index(
    projection: DigitalMeasurementProjectionIR,
) -> str:
    values = {register.bitstring_index for register in projection.registers}
    if len(values) == 1:
        return values.pop()
    if not values:
        return "left_to_right_matches_qubit_order"
    return "mixed"


def _first(values: Any) -> Any:
    if isinstance(values, (list, tuple)) and values:
        return values[0]
    return None


def _target_index(target: Any) -> int | None:
    text = str(target)
    suffix = ""
    for char in reversed(text):
        if char.isdigit():
            suffix = f"{char}{suffix}"
        else:
            break
    return None if not suffix else int(suffix)


def _classical_index(classical_bit: Any) -> int | None:
    text = str(classical_bit)
    if "[" not in text or not text.endswith("]"):
        return None
    return int(text.rsplit("[", 1)[1].rstrip("]"))


def _diagnostic(
    *,
    code: str,
    severity: Literal["info", "error"],
    message: str,
    invariant: str,
    path: str,
    metadata: dict[str, Any] | None = None,
) -> DiagnosticsIR:
    diagnostic_metadata = {
        "phase": "226",
        "invariant": invariant,
        "path": path,
        "reason_category": "bit_order_invariant",
    }
    if metadata:
        diagnostic_metadata.update(metadata)
    return DiagnosticsIR(
        diagnostic_id=f"digital_bit_order_invariants.{code.lower()}",
        stage="serialization",
        severity=severity,
        code=code,
        message=message,
        object_path=f"digital_bit_order_invariants.{path}",
        suggestion="Preserve qubit order, bitstring index, and measurement mapping.",
        metadata=diagnostic_metadata,
    )
