"""Program Import / Export contracts.

External formats return structured diagnostics without importing runtime
dependencies. Future adapters must first produce CASCAQit Native IR and then
pass through validation, compilation, packaging, runtime, and backend checks.
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass, field
from typing import Any, Literal

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.diagnostics.taxonomy import diagnostic_taxonomy_summary
from cascaqit.digital import DigitalProgramIR
from cascaqit.interop.ccx_policy import (
    CCX_BLOCKED_GATE,
    CCX_BLOCKED_REASON,
)
from cascaqit.interop.openqasm3_export import (
    OpenQASM3ExportResultIR,
    render_openqasm3_subset,
)
from cascaqit.interop.openqasm3_roundtrip import (
    build_openqasm3_source_map_review,
    prove_openqasm3_round_trip,
)
from cascaqit.interop.openqasm3_subset import (
    OpenQASM3SubsetImportResultIR,
    parse_openqasm3_subset,
)
from cascaqit.native_ir.base import IRMixin, canonicalize
from cascaqit.native_ir.models import SCHEMA_VERSION, ProgramIR

__all__ = [
    "AdapterCapabilityManifestFeatureIR",
    "AdapterCapabilityManifestIR",
    "AdapterConformanceFixtureIR",
    "AdapterConformanceHarnessReportIR",
    "AdapterExportRoundTripEvidencePackageIR",
    "AdapterReplayFixturePackageIR",
    "ExternalFormatFeatureCoverageIR",
    "ExternalFormatMappingCoverageIR",
    "ProgramImportSourceMapEntryIR",
    "ProgramImportSourceMapSummaryIR",
    "ProgramInteropReadinessIR",
    "ProgramImportMappingIssueIR",
    "ProgramExportRequest",
    "ProgramExportResult",
    "ProgramImportRequest",
    "ProgramImportResult",
    "ProgramSourceMetadataIR",
    "build_adapter_capability_manifest",
    "build_adapter_conformance_fixture",
    "build_adapter_conformance_harness_report",
    "build_openqasm3_export_roundtrip_evidence_package",
    "build_adapter_replay_fixture_package",
    "build_external_format_mapping_coverage",
    "build_openqasm3_restricted_subset_mapping_coverage",
    "build_program_import_source_map_summary",
    "build_program_export_readiness",
    "build_program_import_readiness",
    "export_program",
    "import_program",
]

ProgramFormat = Literal[
    "cascaqit.native_json",
    "cascaqit_compat.atom_program",
    "openqasm3",
    "braket_ahs",
    "pulser_json",
    "bloqade_analog",
]
UnsupportedPolicy = Literal["diagnose", "raise"]
LossyPolicy = Literal["warn", "error"]
MappingSupportLevel = Literal["supported", "lossy", "unsupported"]
MappingReasonCategory = Literal[
    "native_equivalent",
    "requires_adapter",
    "dynamic_control",
    "measurement_semantics",
    "timing_semantics",
    "unit_ambiguity",
    "geometry_mismatch",
    "analog_feature_gap",
    "compat_boundary",
    "external_runtime_object",
]
MappingAction = Literal[
    "map_to_native",
    "preserve_metadata",
    "warn_and_review",
    "block_import",
    "adapter_required",
]
AdapterFixtureImportStatus = Literal[
    "aligned",
    "lossy",
    "blocked",
    "adapter_required",
]
AdapterFixtureResultStatus = Literal["ready", "lossy", "unsupported"]
AdapterConformanceHarnessStatus = Literal["passed", "failed"]
AdapterCapabilityManifestStatus = Literal[
    "ready",
    "adapter_required",
    "blocked",
]
AdapterReplayFixtureStatus = Literal["ready", "blocked"]

SUPPORTED_NATIVE_FORMAT: ProgramFormat = "cascaqit.native_json"


@dataclass(frozen=True)
class AdapterCapabilityManifestFeatureIR(IRMixin):
    """Versioned adapter capability manifest entry for one source feature."""

    feature_id: str
    feature: str
    support_level: MappingSupportLevel
    reason_category: MappingReasonCategory
    action: MappingAction
    source_path: str
    native_path: str | None = None
    diagnostic_code: str | None = None
    message: str | None = None
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(
        cls,
        data: dict[str, Any],
    ) -> AdapterCapabilityManifestFeatureIR:
        """Build a manifest feature entry from a JSON-compatible dictionary."""
        if not isinstance(data, dict):
            raise TypeError(
                "AdapterCapabilityManifestFeatureIR dictionary must be an object."
            )
        return cls(
            feature_id=str(data["feature_id"]),
            feature=str(data["feature"]),
            support_level=data["support_level"],
            reason_category=data["reason_category"],
            action=data["action"],
            source_path=str(data["source_path"]),
            native_path=data.get("native_path"),
            diagnostic_code=data.get("diagnostic_code"),
            message=data.get("message"),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )


@dataclass(frozen=True)
class AdapterCapabilityManifestIR(IRMixin):
    """Versioned metadata-only adapter capability manifest."""

    manifest_id: str
    manifest_version: str
    adapter_name: str
    adapter_version: str
    source_format: ProgramFormat
    target_format: ProgramFormat
    status: AdapterCapabilityManifestStatus
    mapping_coverage_id: str
    features: tuple[AdapterCapabilityManifestFeatureIR, ...]
    supported_features: tuple[str, ...]
    lossy_features: tuple[str, ...]
    unsupported_features: tuple[str, ...]
    bit_order_policy: dict[str, Any]
    measurement_mapping_policy: dict[str, Any]
    source_metadata_policy: dict[str, Any]
    target_projection_policy: dict[str, Any]
    diagnostics: tuple[DiagnosticsIR, ...] = ()
    metadata_only: bool = True
    parser_implemented: bool = False
    external_object_constructed: bool = False
    execution_package_created: bool = False
    backend_called: bool = False
    network_accessed: bool = False
    target_hardware_facts_embedded: bool = False
    cascaqit_compat_required: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize payload and enforce manifest-only boundaries."""
        if self.status not in ("ready", "adapter_required", "blocked"):
            raise ValueError("AdapterCapabilityManifestIR has unsupported status.")
        if not self.metadata_only:
            raise ValueError("AdapterCapabilityManifestIR must be metadata-only.")
        if self.parser_implemented:
            raise ValueError(
                "AdapterCapabilityManifestIR must not claim parser implementation."
            )
        if self.external_object_constructed:
            raise ValueError(
                "AdapterCapabilityManifestIR must not construct external objects."
            )
        if self.execution_package_created:
            raise ValueError(
                "AdapterCapabilityManifestIR must not create execution packages."
            )
        if self.backend_called:
            raise ValueError("AdapterCapabilityManifestIR must not call backends.")
        if self.network_accessed:
            raise ValueError("AdapterCapabilityManifestIR cannot access networks.")
        if self.target_hardware_facts_embedded:
            raise ValueError(
                "AdapterCapabilityManifestIR must not embed target hardware facts."
            )
        if self.cascaqit_compat_required:
            raise ValueError(
                "AdapterCapabilityManifestIR must not require cascaqit-compat."
            )
        object.__setattr__(
            self,
            "features",
            tuple(
                feature
                if isinstance(feature, AdapterCapabilityManifestFeatureIR)
                else AdapterCapabilityManifestFeatureIR.from_dict(feature)
                for feature in self.features
            ),
        )
        object.__setattr__(
            self,
            "supported_features",
            tuple(str(item) for item in self.supported_features),
        )
        object.__setattr__(
            self,
            "lossy_features",
            tuple(str(item) for item in self.lossy_features),
        )
        object.__setattr__(
            self,
            "unsupported_features",
            tuple(str(item) for item in self.unsupported_features),
        )
        object.__setattr__(
            self,
            "bit_order_policy",
            canonicalize(self.bit_order_policy),
        )
        object.__setattr__(
            self,
            "measurement_mapping_policy",
            canonicalize(self.measurement_mapping_policy),
        )
        object.__setattr__(
            self,
            "source_metadata_policy",
            canonicalize(self.source_metadata_policy),
        )
        object.__setattr__(
            self,
            "target_projection_policy",
            canonicalize(self.target_projection_policy),
        )
        object.__setattr__(
            self,
            "diagnostics",
            tuple(
                item
                if isinstance(item, DiagnosticsIR)
                else DiagnosticsIR.from_dict(item)
                for item in self.diagnostics
            ),
        )
        object.__setattr__(self, "metadata", canonicalize(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> AdapterCapabilityManifestIR:
        """Build an adapter capability manifest from a JSON-compatible object."""
        if not isinstance(data, dict):
            raise TypeError("AdapterCapabilityManifestIR dictionary must be an object.")
        return cls(
            manifest_id=str(data["manifest_id"]),
            manifest_version=str(data["manifest_version"]),
            adapter_name=str(data["adapter_name"]),
            adapter_version=str(data["adapter_version"]),
            source_format=data["source_format"],
            target_format=data["target_format"],
            status=data["status"],
            mapping_coverage_id=str(data["mapping_coverage_id"]),
            features=tuple(
                AdapterCapabilityManifestFeatureIR.from_dict(item)
                for item in data.get("features", ())
            ),
            supported_features=tuple(
                str(item) for item in data.get("supported_features", ())
            ),
            lossy_features=tuple(str(item) for item in data.get("lossy_features", ())),
            unsupported_features=tuple(
                str(item) for item in data.get("unsupported_features", ())
            ),
            bit_order_policy=dict(data["bit_order_policy"]),
            measurement_mapping_policy=dict(data["measurement_mapping_policy"]),
            source_metadata_policy=dict(data["source_metadata_policy"]),
            target_projection_policy=dict(data["target_projection_policy"]),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(item) for item in data.get("diagnostics", ())
            ),
            metadata_only=bool(data.get("metadata_only", True)),
            parser_implemented=bool(data.get("parser_implemented", False)),
            external_object_constructed=bool(
                data.get("external_object_constructed", False)
            ),
            execution_package_created=bool(
                data.get("execution_package_created", False)
            ),
            backend_called=bool(data.get("backend_called", False)),
            network_accessed=bool(data.get("network_accessed", False)),
            target_hardware_facts_embedded=bool(
                data.get("target_hardware_facts_embedded", False)
            ),
            cascaqit_compat_required=bool(data.get("cascaqit_compat_required", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> AdapterCapabilityManifestIR:
        """Build an adapter capability manifest from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("AdapterCapabilityManifestIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class AdapterReplayFixturePackageIR(IRMixin):
    """Replay-only external fixture package for adapter conformance review."""

    package_id: str
    status: AdapterReplayFixtureStatus
    source_format: ProgramFormat
    target_format: ProgramFormat
    source_payload: str | dict[str, Any]
    source_metadata: dict[str, Any]
    mapping_coverage: dict[str, Any]
    capability_manifest: dict[str, Any]
    expected_fixture: dict[str, Any]
    harness_report: dict[str, Any]
    expected_import_status: AdapterFixtureImportStatus
    expected_result_adapter_status: AdapterFixtureResultStatus
    diagnostics: tuple[DiagnosticsIR, ...] = ()
    metadata_only: bool = True
    replay_only: bool = True
    parser_invoked: bool = False
    external_sdk_imported: bool = False
    external_object_constructed: bool = False
    execution_package_created: bool = False
    backend_called: bool = False
    network_accessed: bool = False
    credential_accessed: bool = False
    cascaqit_compat_required: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize payload and enforce replay-only boundaries."""
        if self.status not in ("ready", "blocked"):
            raise ValueError("AdapterReplayFixturePackageIR has unsupported status.")
        if not self.metadata_only:
            raise ValueError("AdapterReplayFixturePackageIR must be metadata-only.")
        if not self.replay_only:
            raise ValueError("AdapterReplayFixturePackageIR must be replay-only.")
        if self.parser_invoked:
            raise ValueError("AdapterReplayFixturePackageIR must not invoke parsers.")
        if self.external_sdk_imported:
            raise ValueError(
                "AdapterReplayFixturePackageIR must not import external SDKs."
            )
        if self.external_object_constructed:
            raise ValueError(
                "AdapterReplayFixturePackageIR must not construct external objects."
            )
        if self.execution_package_created:
            raise ValueError(
                "AdapterReplayFixturePackageIR must not create execution packages."
            )
        if self.backend_called:
            raise ValueError("AdapterReplayFixturePackageIR must not call backends.")
        if self.network_accessed:
            raise ValueError("AdapterReplayFixturePackageIR cannot access networks.")
        if self.credential_accessed:
            raise ValueError(
                "AdapterReplayFixturePackageIR must not access credentials."
            )
        if self.cascaqit_compat_required:
            raise ValueError(
                "AdapterReplayFixturePackageIR must not require cascaqit-compat."
            )
        object.__setattr__(self, "source_payload", canonicalize(self.source_payload))
        object.__setattr__(self, "source_metadata", canonicalize(self.source_metadata))
        object.__setattr__(
            self,
            "mapping_coverage",
            canonicalize(self.mapping_coverage),
        )
        object.__setattr__(
            self,
            "capability_manifest",
            canonicalize(self.capability_manifest),
        )
        object.__setattr__(
            self,
            "expected_fixture",
            canonicalize(self.expected_fixture),
        )
        object.__setattr__(self, "harness_report", canonicalize(self.harness_report))
        object.__setattr__(
            self,
            "diagnostics",
            tuple(
                item
                if isinstance(item, DiagnosticsIR)
                else DiagnosticsIR.from_dict(item)
                for item in self.diagnostics
            ),
        )
        object.__setattr__(self, "metadata", canonicalize(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> AdapterReplayFixturePackageIR:
        """Build a replay fixture package from a JSON-compatible dictionary."""
        if not isinstance(data, dict):
            raise TypeError(
                "AdapterReplayFixturePackageIR dictionary must be an object."
            )
        return cls(
            package_id=str(data["package_id"]),
            status=data["status"],
            source_format=data["source_format"],
            target_format=data["target_format"],
            source_payload=data["source_payload"],
            source_metadata=dict(data["source_metadata"]),
            mapping_coverage=dict(data["mapping_coverage"]),
            capability_manifest=dict(data["capability_manifest"]),
            expected_fixture=dict(data["expected_fixture"]),
            harness_report=dict(data["harness_report"]),
            expected_import_status=data["expected_import_status"],
            expected_result_adapter_status=data["expected_result_adapter_status"],
            diagnostics=tuple(
                DiagnosticsIR.from_dict(item) for item in data.get("diagnostics", ())
            ),
            metadata_only=bool(data.get("metadata_only", True)),
            replay_only=bool(data.get("replay_only", True)),
            parser_invoked=bool(data.get("parser_invoked", False)),
            external_sdk_imported=bool(data.get("external_sdk_imported", False)),
            external_object_constructed=bool(
                data.get("external_object_constructed", False)
            ),
            execution_package_created=bool(
                data.get("execution_package_created", False)
            ),
            backend_called=bool(data.get("backend_called", False)),
            network_accessed=bool(data.get("network_accessed", False)),
            credential_accessed=bool(data.get("credential_accessed", False)),
            cascaqit_compat_required=bool(data.get("cascaqit_compat_required", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> AdapterReplayFixturePackageIR:
        """Build a replay fixture package from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError(
                "AdapterReplayFixturePackageIR JSON must contain an object."
            )
        return cls.from_dict(data)


@dataclass(frozen=True)
class ExternalFormatFeatureCoverageIR(IRMixin):
    """Feature-level import/export mapping coverage for an external format."""

    feature_id: str
    feature: str
    support_level: MappingSupportLevel
    reason_category: MappingReasonCategory
    action: MappingAction
    source_path: str
    native_path: str | None = None
    diagnostic_code: str | None = None
    message: str | None = None
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ExternalFormatFeatureCoverageIR:
        """Build feature coverage from a JSON-compatible dictionary."""
        return cls(
            feature_id=str(data["feature_id"]),
            feature=str(data["feature"]),
            support_level=data["support_level"],
            reason_category=data["reason_category"],
            action=data["action"],
            source_path=str(data["source_path"]),
            native_path=data.get("native_path"),
            diagnostic_code=data.get("diagnostic_code"),
            message=data.get("message"),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    def diagnostic(self, *, source_format: ProgramFormat) -> DiagnosticsIR | None:
        """Return this mapping coverage as a diagnostic when review is needed."""
        if self.support_level == "supported":
            return None
        severity: Literal["info", "warning", "error"] = (
            "warning" if self.support_level == "lossy" else "error"
        )
        code = self.diagnostic_code or (
            "PROGRAM_IMPORT_LOSSY_MAPPING"
            if self.support_level == "lossy"
            else "PROGRAM_IMPORT_UNSUPPORTED_FEATURE"
        )
        return _diagnostic(
            diagnostic_id=f"interop.mapping_coverage.{self.feature_id}",
            code=code,
            message=self.message or f"Feature {self.feature!r} requires review.",
            object_path=self.native_path or self.source_path,
            suggestion=_mapping_suggestion(self),
            severity=severity,
            metadata={
                "source_format": source_format,
                "feature_id": self.feature_id,
                "feature": self.feature,
                "support_level": self.support_level,
                "reason_category": self.reason_category,
                "action": self.action,
                "source_path": self.source_path,
                "native_path": self.native_path,
                **self.metadata,
            },
        )


@dataclass(frozen=True)
class ExternalFormatMappingCoverageIR(IRMixin):
    """Mapping coverage contract for an external program format boundary."""

    source_format: ProgramFormat
    target_format: ProgramFormat
    coverage_id: str
    status: Literal["ready", "lossy", "blocked", "adapter_required"]
    features: tuple[ExternalFormatFeatureCoverageIR, ...]
    supported_features: tuple[str, ...]
    lossy_features: tuple[str, ...]
    unsupported_features: tuple[str, ...]
    diagnostics: tuple[DiagnosticsIR, ...]
    native_ir_required: bool = True
    adapter_required: bool = True
    backend_bypass_allowed: bool = False
    execution_package_created: bool = False
    external_object_constructed: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ExternalFormatMappingCoverageIR:
        """Build external mapping coverage from a JSON-compatible dictionary."""
        return cls(
            source_format=data["source_format"],
            target_format=data["target_format"],
            coverage_id=str(data["coverage_id"]),
            status=data["status"],
            features=tuple(
                ExternalFormatFeatureCoverageIR.from_dict(item)
                for item in data.get("features", ())
            ),
            supported_features=tuple(
                str(item) for item in data.get("supported_features", ())
            ),
            lossy_features=tuple(str(item) for item in data.get("lossy_features", ())),
            unsupported_features=tuple(
                str(item) for item in data.get("unsupported_features", ())
            ),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(item) for item in data.get("diagnostics", ())
            ),
            native_ir_required=bool(data.get("native_ir_required", True)),
            adapter_required=bool(data.get("adapter_required", True)),
            backend_bypass_allowed=bool(data.get("backend_bypass_allowed", False)),
            execution_package_created=bool(
                data.get("execution_package_created", False)
            ),
            external_object_constructed=bool(
                data.get("external_object_constructed", False)
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )


@dataclass(frozen=True)
class ProgramInteropReadinessIR(IRMixin):
    """Readiness summary for Program Import / Export adapter boundaries."""

    operation: Literal["import", "export"]
    source_format: ProgramFormat | None = None
    target_format: ProgramFormat | None = None
    status: Literal["ready", "adapter_required", "blocked"] = "ready"
    native_ir_required: bool = True
    adapter_required: bool = False
    backend_bypass_allowed: bool = False
    validation_required: bool = True
    compiler_required: bool = True
    execution_package_required: bool = True
    lossy_policy: LossyPolicy = "warn"
    unsupported_policy: UnsupportedPolicy = "diagnose"
    declared_lossy_mappings: tuple[str, ...] = ()
    declared_unsupported_features: tuple[str, ...] = ()
    payload_available: bool = False
    program_available: bool = False
    external_object_constructed: bool = False
    cascaqit_compat_required: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ProgramInteropReadinessIR:
        """Build interop readiness from a JSON-compatible dictionary."""
        return cls(
            operation=data["operation"],
            source_format=data.get("source_format"),
            target_format=data.get("target_format"),
            status=data.get("status", "ready"),
            native_ir_required=bool(data.get("native_ir_required", True)),
            adapter_required=bool(data.get("adapter_required", False)),
            backend_bypass_allowed=bool(data.get("backend_bypass_allowed", False)),
            validation_required=bool(data.get("validation_required", True)),
            compiler_required=bool(data.get("compiler_required", True)),
            execution_package_required=bool(
                data.get("execution_package_required", True)
            ),
            lossy_policy=data.get("lossy_policy", "warn"),
            unsupported_policy=data.get("unsupported_policy", "diagnose"),
            declared_lossy_mappings=tuple(
                str(item) for item in data.get("declared_lossy_mappings", ())
            ),
            declared_unsupported_features=tuple(
                str(item) for item in data.get("declared_unsupported_features", ())
            ),
            payload_available=bool(data.get("payload_available", False)),
            program_available=bool(data.get("program_available", False)),
            external_object_constructed=bool(
                data.get("external_object_constructed", False)
            ),
            cascaqit_compat_required=bool(data.get("cascaqit_compat_required", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )


@dataclass(frozen=True)
class ProgramSourceMetadataIR(IRMixin):
    """Stable source metadata preserved at the Program Import boundary."""

    source_format: ProgramFormat
    source_digest: str
    source_id: str | None = None
    source_version: str | None = None
    frontend_name: str | None = None
    frontend_version: str | None = None
    adapter_name: str = "cascaqit.interop"
    adapter_version: str = "phase_113"
    preserve_metadata: bool = True
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ProgramSourceMetadataIR:
        """Build source metadata from a JSON-compatible dictionary."""
        return cls(
            source_format=data["source_format"],
            source_digest=str(data["source_digest"]),
            source_id=data.get("source_id"),
            source_version=data.get("source_version"),
            frontend_name=data.get("frontend_name"),
            frontend_version=data.get("frontend_version"),
            adapter_name=str(data.get("adapter_name", "cascaqit.interop")),
            adapter_version=str(data.get("adapter_version", "phase_113")),
            preserve_metadata=bool(data.get("preserve_metadata", True)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )


@dataclass(frozen=True)
class ProgramImportMappingIssueIR(IRMixin):
    """Lossy or unsupported mapping issue declared by an import adapter."""

    issue_id: str
    issue_type: Literal["lossy", "unsupported"]
    feature: str
    reason: str
    source_path: str | None = None
    native_path: str | None = None
    severity: Literal["warning", "error"] = "warning"
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ProgramImportMappingIssueIR:
        """Build a mapping issue from a JSON-compatible dictionary."""
        return cls(
            issue_id=str(data["issue_id"]),
            issue_type=data["issue_type"],
            feature=str(data["feature"]),
            reason=str(data["reason"]),
            source_path=data.get("source_path"),
            native_path=data.get("native_path"),
            severity=data.get("severity", "warning"),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    def diagnostic(self, *, source_format: ProgramFormat) -> DiagnosticsIR:
        """Return this mapping issue as a structured diagnostic."""
        if self.issue_type == "unsupported":
            code = "PROGRAM_IMPORT_UNSUPPORTED_FEATURE"
            diagnostic_id = f"interop.import_unsupported.{self.issue_id}"
            diagnostic_severity: Literal["info", "warning", "error"] = "error"
            suggestion = (
                "Do not submit this imported program. Add an adapter mapping "
                "or remove the unsupported source feature."
            )
        else:
            code = "PROGRAM_IMPORT_LOSSY_MAPPING"
            diagnostic_id = f"interop.import_lossy.{self.issue_id}"
            diagnostic_severity = self.severity
            suggestion = (
                "Review the lossy mapping before validation, compilation, or "
                "simulation."
            )
        return _diagnostic(
            diagnostic_id=diagnostic_id,
            code=code,
            message=self.reason,
            object_path=self.native_path or self.source_path or "import.mapping",
            suggestion=suggestion,
            severity=diagnostic_severity,
            metadata={
                "feature": self.feature,
                "issue_id": self.issue_id,
                "issue_type": self.issue_type,
                "source_format": source_format,
                "source_path": self.source_path,
                "native_path": self.native_path,
                **self.metadata,
            },
        )


@dataclass(frozen=True)
class ProgramImportSourceMapEntryIR(IRMixin):
    """Source/native path alignment entry for Program Import review."""

    entry_id: str
    source_format: ProgramFormat
    source_path: str
    native_path: str | None
    feature: str
    support_level: MappingSupportLevel
    reason_category: str
    action: str
    diagnostic_ids: tuple[str, ...] = ()
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ProgramImportSourceMapEntryIR:
        """Build an import source-map entry from a dictionary."""
        return cls(
            entry_id=str(data["entry_id"]),
            source_format=data["source_format"],
            source_path=str(data["source_path"]),
            native_path=data.get("native_path"),
            feature=str(data["feature"]),
            support_level=data["support_level"],
            reason_category=str(data["reason_category"]),
            action=str(data["action"]),
            diagnostic_ids=tuple(str(item) for item in data.get("diagnostic_ids", ())),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )


@dataclass(frozen=True)
class ProgramImportSourceMapSummaryIR(IRMixin):
    """Metadata-only summary aligning import paths, diagnostics, and taxonomy."""

    summary_id: str
    source_format: ProgramFormat
    target_format: ProgramFormat
    source_digest: str
    status: Literal["aligned", "lossy", "blocked", "adapter_required"]
    entries: tuple[ProgramImportSourceMapEntryIR, ...]
    diagnostics: tuple[DiagnosticsIR, ...]
    taxonomy_summary: dict[str, Any]
    source_metadata: dict[str, Any]
    mapping_coverage_id: str | None = None
    native_ir_required: bool = True
    compiler_invoked: bool = False
    runtime_invoked: bool = False
    program_mutated: bool = False
    backend_bypass_allowed: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ProgramImportSourceMapSummaryIR:
        """Build an import source-map summary from a dictionary."""
        return cls(
            summary_id=str(data["summary_id"]),
            source_format=data["source_format"],
            target_format=data["target_format"],
            source_digest=str(data["source_digest"]),
            status=data["status"],
            entries=tuple(
                ProgramImportSourceMapEntryIR.from_dict(item)
                for item in data.get("entries", ())
            ),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(item) for item in data.get("diagnostics", ())
            ),
            taxonomy_summary=dict(data["taxonomy_summary"]),
            source_metadata=dict(data.get("source_metadata", {})),
            mapping_coverage_id=data.get("mapping_coverage_id"),
            native_ir_required=bool(data.get("native_ir_required", True)),
            compiler_invoked=bool(data.get("compiler_invoked", False)),
            runtime_invoked=bool(data.get("runtime_invoked", False)),
            program_mutated=bool(data.get("program_mutated", False)),
            backend_bypass_allowed=bool(data.get("backend_bypass_allowed", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )


@dataclass(frozen=True)
class AdapterConformanceFixtureIR(IRMixin):
    """Metadata-only fixture contract for future interop adapters."""

    fixture_id: str
    source_format: ProgramFormat
    source_digest: str
    source_metadata: dict[str, Any]
    declared_mapping_coverage: dict[str, Any]
    target_projection_id: str | None
    expected_import_status: AdapterFixtureImportStatus
    expected_result_adapter_status: AdapterFixtureResultStatus
    import_source_map_summary_id: str | None = None
    diagnostics: tuple[DiagnosticsIR, ...] = ()
    metadata_only: bool = True
    parser_invoked: bool = False
    external_object_constructed: bool = False
    execution_package_created: bool = False
    backend_called: bool = False
    network_accessed: bool = False
    cascaqit_compat_required: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize JSON payloads and enforce fixture-only boundaries."""
        if self.expected_import_status not in (
            "aligned",
            "lossy",
            "blocked",
            "adapter_required",
        ):
            raise ValueError(
                "AdapterConformanceFixtureIR has unsupported import status."
            )
        if self.expected_result_adapter_status not in (
            "ready",
            "lossy",
            "unsupported",
        ):
            raise ValueError(
                "AdapterConformanceFixtureIR has unsupported result adapter status."
            )
        if not self.metadata_only:
            raise ValueError("AdapterConformanceFixtureIR must be metadata-only.")
        if self.parser_invoked:
            raise ValueError("AdapterConformanceFixtureIR must not invoke parsers.")
        if self.external_object_constructed:
            raise ValueError(
                "AdapterConformanceFixtureIR must not construct external objects."
            )
        if self.execution_package_created:
            raise ValueError(
                "AdapterConformanceFixtureIR must not create execution packages."
            )
        if self.backend_called:
            raise ValueError("AdapterConformanceFixtureIR must not call backends.")
        if self.network_accessed:
            raise ValueError("AdapterConformanceFixtureIR cannot access networks.")
        if self.cascaqit_compat_required:
            raise ValueError(
                "AdapterConformanceFixtureIR must not require cascaqit-compat."
            )

        source_metadata = canonicalize(self.source_metadata)
        declared_mapping_coverage = canonicalize(self.declared_mapping_coverage)
        if not isinstance(source_metadata, dict):
            raise TypeError("source_metadata must serialize to an object.")
        if not isinstance(declared_mapping_coverage, dict):
            raise TypeError("declared_mapping_coverage must serialize to an object.")
        if source_metadata.get("source_format") != self.source_format:
            raise ValueError("source_metadata source_format must match fixture.")
        if source_metadata.get("source_digest") != self.source_digest:
            raise ValueError("source_metadata source_digest must match fixture.")
        if declared_mapping_coverage.get("source_format") != self.source_format:
            raise ValueError(
                "declared_mapping_coverage source_format must match fixture."
            )

        object.__setattr__(self, "source_metadata", source_metadata)
        object.__setattr__(
            self,
            "declared_mapping_coverage",
            declared_mapping_coverage,
        )
        object.__setattr__(
            self,
            "diagnostics",
            tuple(
                item
                if isinstance(item, DiagnosticsIR)
                else DiagnosticsIR.from_dict(item)
                for item in self.diagnostics
            ),
        )
        object.__setattr__(self, "metadata", canonicalize(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> AdapterConformanceFixtureIR:
        """Build an adapter conformance fixture from a JSON-compatible object."""
        if not isinstance(data, dict):
            raise TypeError("AdapterConformanceFixtureIR dictionary must be an object.")
        return cls(
            fixture_id=str(data["fixture_id"]),
            source_format=data["source_format"],
            source_digest=str(data["source_digest"]),
            source_metadata=dict(data["source_metadata"]),
            declared_mapping_coverage=dict(data["declared_mapping_coverage"]),
            target_projection_id=data.get("target_projection_id"),
            expected_import_status=data["expected_import_status"],
            expected_result_adapter_status=data["expected_result_adapter_status"],
            import_source_map_summary_id=data.get("import_source_map_summary_id"),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(item) for item in data.get("diagnostics", ())
            ),
            metadata_only=bool(data.get("metadata_only", True)),
            parser_invoked=bool(data.get("parser_invoked", False)),
            external_object_constructed=bool(
                data.get("external_object_constructed", False)
            ),
            execution_package_created=bool(
                data.get("execution_package_created", False)
            ),
            backend_called=bool(data.get("backend_called", False)),
            network_accessed=bool(data.get("network_accessed", False)),
            cascaqit_compat_required=bool(data.get("cascaqit_compat_required", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> AdapterConformanceFixtureIR:
        """Build an adapter conformance fixture from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("AdapterConformanceFixtureIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class AdapterConformanceHarnessReportIR(IRMixin):
    """Metadata-only adapter fixture conformance harness report."""

    report_id: str
    status: AdapterConformanceHarnessStatus
    submitted_fixture_id: str
    expected_fixture_id: str
    source_format: ProgramFormat
    source_digest: str
    expected_source_digest: str
    compared_fields: tuple[str, ...]
    matched_fields: tuple[str, ...]
    drift_fields: tuple[str, ...]
    side_effect_violations: tuple[str, ...]
    mapping_coverage_summary: dict[str, Any]
    diagnostics_taxonomy_summary: dict[str, Any]
    diagnostics: tuple[DiagnosticsIR, ...] = ()
    metadata_only: bool = True
    parser_invoked: bool = False
    external_object_constructed: bool = False
    execution_package_created: bool = False
    backend_called: bool = False
    network_accessed: bool = False
    cascaqit_compat_required: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize report payload and enforce harness-only boundaries."""
        if self.status not in ("passed", "failed"):
            raise ValueError(
                "AdapterConformanceHarnessReportIR has unsupported status."
            )
        if not self.metadata_only:
            raise ValueError("AdapterConformanceHarnessReportIR must be metadata-only.")
        if self.parser_invoked:
            raise ValueError(
                "AdapterConformanceHarnessReportIR must not invoke parsers."
            )
        if self.external_object_constructed:
            raise ValueError(
                "AdapterConformanceHarnessReportIR must not construct external objects."
            )
        if self.execution_package_created:
            raise ValueError(
                "AdapterConformanceHarnessReportIR must not create execution packages."
            )
        if self.backend_called:
            raise ValueError(
                "AdapterConformanceHarnessReportIR must not call backends."
            )
        if self.network_accessed:
            raise ValueError(
                "AdapterConformanceHarnessReportIR cannot access networks."
            )
        if self.cascaqit_compat_required:
            raise ValueError(
                "AdapterConformanceHarnessReportIR must not require cascaqit-compat."
            )

        object.__setattr__(
            self,
            "compared_fields",
            tuple(str(item) for item in self.compared_fields),
        )
        object.__setattr__(
            self,
            "matched_fields",
            tuple(str(item) for item in self.matched_fields),
        )
        object.__setattr__(
            self,
            "drift_fields",
            tuple(str(item) for item in self.drift_fields),
        )
        object.__setattr__(
            self,
            "side_effect_violations",
            tuple(str(item) for item in self.side_effect_violations),
        )
        object.__setattr__(
            self,
            "mapping_coverage_summary",
            canonicalize(self.mapping_coverage_summary),
        )
        object.__setattr__(
            self,
            "diagnostics_taxonomy_summary",
            canonicalize(self.diagnostics_taxonomy_summary),
        )
        object.__setattr__(
            self,
            "diagnostics",
            tuple(
                item
                if isinstance(item, DiagnosticsIR)
                else DiagnosticsIR.from_dict(item)
                for item in self.diagnostics
            ),
        )
        object.__setattr__(self, "metadata", canonicalize(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> AdapterConformanceHarnessReportIR:
        """Build a harness report from a JSON-compatible object."""
        if not isinstance(data, dict):
            raise TypeError(
                "AdapterConformanceHarnessReportIR dictionary must be an object."
            )
        return cls(
            report_id=str(data["report_id"]),
            status=data["status"],
            submitted_fixture_id=str(data["submitted_fixture_id"]),
            expected_fixture_id=str(data["expected_fixture_id"]),
            source_format=data["source_format"],
            source_digest=str(data["source_digest"]),
            expected_source_digest=str(data["expected_source_digest"]),
            compared_fields=tuple(
                str(item) for item in data.get("compared_fields", ())
            ),
            matched_fields=tuple(str(item) for item in data.get("matched_fields", ())),
            drift_fields=tuple(str(item) for item in data.get("drift_fields", ())),
            side_effect_violations=tuple(
                str(item) for item in data.get("side_effect_violations", ())
            ),
            mapping_coverage_summary=dict(data["mapping_coverage_summary"]),
            diagnostics_taxonomy_summary=dict(data["diagnostics_taxonomy_summary"]),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(item) for item in data.get("diagnostics", ())
            ),
            metadata_only=bool(data.get("metadata_only", True)),
            parser_invoked=bool(data.get("parser_invoked", False)),
            external_object_constructed=bool(
                data.get("external_object_constructed", False)
            ),
            execution_package_created=bool(
                data.get("execution_package_created", False)
            ),
            backend_called=bool(data.get("backend_called", False)),
            network_accessed=bool(data.get("network_accessed", False)),
            cascaqit_compat_required=bool(data.get("cascaqit_compat_required", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> AdapterConformanceHarnessReportIR:
        """Build a harness report from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError(
                "AdapterConformanceHarnessReportIR JSON must contain an object."
            )
        return cls.from_dict(data)


@dataclass(frozen=True)
class AdapterExportRoundTripEvidencePackageIR(IRMixin):
    """Export and round-trip evidence package for adapter conformance review."""

    package_id: str
    status: AdapterReplayFixtureStatus
    source_format: ProgramFormat
    target_format: ProgramFormat
    source_program_id: str
    source_program_hash: str
    export_result: dict[str, Any]
    round_trip_report: dict[str, Any]
    payload_digest: str | None
    matched_fields: tuple[str, ...]
    drift_fields: tuple[str, ...]
    diagnostics: tuple[DiagnosticsIR, ...] = ()
    metadata_only: bool = True
    replay_only: bool = True
    parser_invoked: bool = True
    external_sdk_imported: bool = False
    external_object_constructed: bool = False
    execution_package_created: bool = False
    backend_called: bool = False
    cloud_called: bool = False
    network_accessed: bool = False
    credential_accessed: bool = False
    cascaqit_compat_required: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize evidence payload and enforce native SDK boundaries."""
        if self.status not in ("ready", "blocked"):
            raise ValueError(
                "AdapterExportRoundTripEvidencePackageIR has unsupported status."
            )
        if not self.metadata_only:
            raise ValueError(
                "AdapterExportRoundTripEvidencePackageIR must be metadata-only."
            )
        if not self.replay_only:
            raise ValueError(
                "AdapterExportRoundTripEvidencePackageIR must be replay-only."
            )
        if not self.parser_invoked:
            raise ValueError(
                "AdapterExportRoundTripEvidencePackageIR must record parser proof."
            )
        if self.external_sdk_imported:
            raise ValueError(
                "AdapterExportRoundTripEvidencePackageIR must not import external SDKs."
            )
        if self.external_object_constructed:
            raise ValueError(
                "AdapterExportRoundTripEvidencePackageIR must not construct "
                "external objects."
            )
        if self.execution_package_created:
            raise ValueError(
                "AdapterExportRoundTripEvidencePackageIR must not create "
                "execution packages."
            )
        if self.backend_called or self.cloud_called:
            raise ValueError(
                "AdapterExportRoundTripEvidencePackageIR must not call "
                "backends or cloud."
            )
        if self.network_accessed:
            raise ValueError(
                "AdapterExportRoundTripEvidencePackageIR cannot access networks."
            )
        if self.credential_accessed:
            raise ValueError(
                "AdapterExportRoundTripEvidencePackageIR must not access credentials."
            )
        if self.cascaqit_compat_required:
            raise ValueError(
                "AdapterExportRoundTripEvidencePackageIR must not require "
                "cascaqit-compat."
            )
        object.__setattr__(self, "export_result", canonicalize(self.export_result))
        object.__setattr__(
            self,
            "round_trip_report",
            canonicalize(self.round_trip_report),
        )
        object.__setattr__(
            self,
            "matched_fields",
            tuple(str(field) for field in self.matched_fields),
        )
        object.__setattr__(
            self,
            "drift_fields",
            tuple(str(field) for field in self.drift_fields),
        )
        object.__setattr__(
            self,
            "diagnostics",
            tuple(
                item
                if isinstance(item, DiagnosticsIR)
                else DiagnosticsIR.from_dict(item)
                for item in self.diagnostics
            ),
        )
        object.__setattr__(self, "metadata", canonicalize(self.metadata))

    @classmethod
    def from_dict(
        cls,
        data: dict[str, Any],
    ) -> AdapterExportRoundTripEvidencePackageIR:
        """Build export/round-trip evidence from a JSON-compatible object."""
        if not isinstance(data, dict):
            raise TypeError(
                "AdapterExportRoundTripEvidencePackageIR dictionary must be an object."
            )
        return cls(
            package_id=str(data["package_id"]),
            status=data["status"],
            source_format=data["source_format"],
            target_format=data["target_format"],
            source_program_id=str(data["source_program_id"]),
            source_program_hash=str(data["source_program_hash"]),
            export_result=dict(data["export_result"]),
            round_trip_report=dict(data["round_trip_report"]),
            payload_digest=data.get("payload_digest"),
            matched_fields=tuple(str(item) for item in data.get("matched_fields", ())),
            drift_fields=tuple(str(item) for item in data.get("drift_fields", ())),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(item) for item in data.get("diagnostics", ())
            ),
            metadata_only=bool(data.get("metadata_only", True)),
            replay_only=bool(data.get("replay_only", True)),
            parser_invoked=bool(data.get("parser_invoked", True)),
            external_sdk_imported=bool(data.get("external_sdk_imported", False)),
            external_object_constructed=bool(
                data.get("external_object_constructed", False)
            ),
            execution_package_created=bool(
                data.get("execution_package_created", False)
            ),
            backend_called=bool(data.get("backend_called", False)),
            cloud_called=bool(data.get("cloud_called", False)),
            network_accessed=bool(data.get("network_accessed", False)),
            credential_accessed=bool(data.get("credential_accessed", False)),
            cascaqit_compat_required=bool(data.get("cascaqit_compat_required", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> AdapterExportRoundTripEvidencePackageIR:
        """Build export/round-trip evidence from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError(
                "AdapterExportRoundTripEvidencePackageIR JSON must contain an object."
            )
        return cls.from_dict(data)


@dataclass(frozen=True)
class ProgramImportRequest(IRMixin):
    """Request to import an external or native program into ProgramIR."""

    source_format: ProgramFormat
    source: str | dict[str, Any]
    source_id: str | None = None
    source_version: str | None = None
    preserve_metadata: bool = True
    on_unsupported: UnsupportedPolicy = "diagnose"
    on_lossy: LossyPolicy = "warn"
    frontend_name: str | None = None
    frontend_version: str | None = None
    declared_lossy_mappings: tuple[ProgramImportMappingIssueIR, ...] = ()
    declared_unsupported_features: tuple[ProgramImportMappingIssueIR, ...] = ()
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ProgramImportResult(IRMixin):
    """Result of a Program Import operation."""

    source_format: ProgramFormat
    program: ProgramIR | DigitalProgramIR | None
    diagnostics: tuple[DiagnosticsIR, ...]
    source_digest: str
    source_metadata_ir: ProgramSourceMetadataIR | None = None
    source_metadata: dict[str, Any] = field(default_factory=dict)
    mapping_issues: tuple[ProgramImportMappingIssueIR, ...] = ()
    lossy_mappings: tuple[str, ...] = ()
    unsupported_features: tuple[str, ...] = ()
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ProgramExportRequest(IRMixin):
    """Request to export ProgramIR to a target format."""

    program: ProgramIR | DigitalProgramIR
    target_format: ProgramFormat
    preserve_metadata: bool = True
    on_unsupported: UnsupportedPolicy = "diagnose"
    on_lossy: LossyPolicy = "warn"
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ProgramExportResult(IRMixin):
    """Result of a Program Export operation."""

    target_format: ProgramFormat
    payload: str | dict[str, Any] | None
    diagnostics: tuple[DiagnosticsIR, ...]
    source_program_hash: str
    lossy_mappings: tuple[str, ...] = ()
    unsupported_features: tuple[str, ...] = ()
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)


def build_external_format_mapping_coverage(
    *,
    source_format: ProgramFormat,
    target_format: ProgramFormat = SUPPORTED_NATIVE_FORMAT,
    declared_features: tuple[ExternalFormatFeatureCoverageIR, ...] = (),
    coverage_id: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> ExternalFormatMappingCoverageIR:
    """Return mapping coverage for an external format without parsing it."""
    features = (
        declared_features
        if declared_features
        else _default_mapping_coverage_features(source_format)
    )
    supported = tuple(
        feature.feature for feature in features if feature.support_level == "supported"
    )
    lossy = tuple(
        feature.feature for feature in features if feature.support_level == "lossy"
    )
    unsupported = tuple(
        feature.feature
        for feature in features
        if feature.support_level == "unsupported"
    )
    diagnostics = tuple(
        diagnostic
        for diagnostic in (
            feature.diagnostic(source_format=source_format) for feature in features
        )
        if diagnostic is not None
    )
    adapter_required = source_format != SUPPORTED_NATIVE_FORMAT
    return ExternalFormatMappingCoverageIR(
        source_format=source_format,
        target_format=target_format,
        coverage_id=coverage_id
        or f"mapping_coverage.{source_format}.to.{target_format}",
        status=_mapping_coverage_status(
            adapter_required=adapter_required,
            lossy_features=lossy,
            unsupported_features=unsupported,
        ),
        features=features,
        supported_features=supported,
        lossy_features=lossy,
        unsupported_features=unsupported,
        diagnostics=diagnostics,
        native_ir_required=True,
        adapter_required=adapter_required,
        backend_bypass_allowed=False,
        execution_package_created=False,
        external_object_constructed=False,
        metadata={
            "contract": "external_format_mapping_coverage",
            "source_format": source_format,
            "target_format": target_format,
            "full_parser_implemented": source_format == SUPPORTED_NATIVE_FORMAT,
            "source_metadata_required": True,
            "bit_order_must_be_explicit": True,
            "measurement_mapping_must_be_explicit": True,
            "units_must_be_explicit": True,
            "execution_package_created": False,
            **({} if metadata is None else metadata),
        },
    )


def build_openqasm3_restricted_subset_mapping_coverage(
    *,
    target_format: ProgramFormat = SUPPORTED_NATIVE_FORMAT,
    coverage_id: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> ExternalFormatMappingCoverageIR:
    """Return positive coverage for CASCAQit's restricted OpenQASM 3 subset."""
    features = (
        _feature(
            source_format="openqasm3",
            feature_id="openqasm_static_gate_subset",
            feature="static_gate_subset",
            support_level="supported",
            reason_category="native_equivalent",
            action="map_to_native",
            source_path="program.statements[*]",
            native_path="DigitalProgramIR.circuit.operations",
            message=(
                "Restricted OpenQASM 3 static gate statements map to "
                "DigitalProgramIR circuit operations."
            ),
            metadata={
                "direct_gates": [
                    "i",
                    "x",
                    "y",
                    "z",
                    "h",
                    "s",
                    "sdg",
                    "t",
                    "tdg",
                    "rx",
                    "ry",
                    "rz",
                    "p",
                    "u",
                    "cx",
                    "cy",
                    "cz",
                ],
                "lowered_gates": {"swap": "swap_to_three_cx"},
                "blocked_gates": [CCX_BLOCKED_GATE],
                "blocked_reasons": {
                    CCX_BLOCKED_GATE: CCX_BLOCKED_REASON,
                },
            },
        ),
        _feature(
            source_format="openqasm3",
            feature_id="openqasm_u_cy_direct_gates",
            feature="u_cy_direct_gates",
            support_level="supported",
            reason_category="native_equivalent",
            action="map_to_native",
            source_path="program.statements[u|cy]",
            native_path="DigitalProgramIR.circuit.operations",
            message=(
                "Restricted OpenQASM 3 supports direct U and CY gate import/export."
            ),
        ),
        _feature(
            source_format="openqasm3",
            feature_id="openqasm_swap_lowering",
            feature="swap_lowering",
            support_level="supported",
            reason_category="native_equivalent",
            action="preserve_metadata",
            source_path="DigitalProgramIR.circuit.operations[swap]",
            native_path="OpenQASM3.cx_group[3]",
            message=(
                "Native SWAP export is lowered to three CX statements with "
                "source-map provenance."
            ),
            metadata={
                "lowering_strategy": "swap_to_three_cx",
                "semantic_equivalence_required": True,
            },
        ),
        _feature(
            source_format="openqasm3",
            feature_id="openqasm_terminal_measurement",
            feature="terminal_measurement",
            support_level="supported",
            reason_category="measurement_semantics",
            action="map_to_native",
            source_path="program.measurements[terminal]",
            native_path="DigitalProgramIR.circuit.measurements",
            message=(
                "Terminal OpenQASM 3 measurements preserve explicit classical "
                "bit mapping in DigitalProgramIR."
            ),
        ),
        _feature(
            source_format="openqasm3",
            feature_id="openqasm_explicit_bit_order",
            feature="explicit_bit_order",
            support_level="supported",
            reason_category="native_equivalent",
            action="preserve_metadata",
            source_path="qubit[n] q; bit[n] c;",
            native_path="DigitalProgramIR.metadata.source.bit_order",
            message=(
                "Restricted OpenQASM 3 register order is preserved as explicit "
                "bit-order metadata."
            ),
        ),
    )
    coverage = build_external_format_mapping_coverage(
        source_format="openqasm3",
        target_format=target_format,
        declared_features=features,
        coverage_id=coverage_id
        or f"mapping_coverage.openqasm3.restricted_subset.to.{target_format}",
        metadata={
            "restricted_subset": True,
            "full_format_supported": False,
            "subset_importer": "cascaqit.interop.openqasm3_subset",
            "supported_subset_status": "ready",
            "advanced_openqasm_features_status": "blocked",
            "direct_gates": [
                "i",
                "x",
                "y",
                "z",
                "h",
                "s",
                "sdg",
                "t",
                "tdg",
                "rx",
                "ry",
                "rz",
                "p",
                "u",
                "cx",
                "cy",
                "cz",
            ],
            "lowered_gates": {"swap": "swap_to_three_cx"},
            "blocked_gates": [CCX_BLOCKED_GATE],
            "blocked_reasons": {
                CCX_BLOCKED_GATE: CCX_BLOCKED_REASON,
            },
            "dynamic_circuit_supported": False,
            "mid_circuit_measurement_supported": False,
            "defcal_timing_supported": False,
            **({} if metadata is None else metadata),
        },
    )
    return ExternalFormatMappingCoverageIR.from_dict(
        {
            **coverage.to_dict(),
            "status": "ready",
            "adapter_required": False,
        },
    )


def build_adapter_capability_manifest(
    *,
    source_format: ProgramFormat,
    target_format: ProgramFormat = SUPPORTED_NATIVE_FORMAT,
    adapter_name: str | None = None,
    adapter_version: str = "0.0.metadata",
    manifest_version: str = "v0.25",
    mapping_coverage: ExternalFormatMappingCoverageIR | None = None,
    manifest_id: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> AdapterCapabilityManifestIR:
    """Build a versioned adapter capability manifest without parser execution."""
    coverage = mapping_coverage or build_external_format_mapping_coverage(
        source_format=source_format,
        target_format=target_format,
    )
    if coverage.source_format != source_format:
        raise ValueError("mapping_coverage source_format must match manifest.")
    if coverage.target_format != target_format:
        raise ValueError("mapping_coverage target_format must match manifest.")
    features = tuple(
        AdapterCapabilityManifestFeatureIR(
            feature_id=feature.feature_id,
            feature=feature.feature,
            support_level=feature.support_level,
            reason_category=feature.reason_category,
            action=feature.action,
            source_path=feature.source_path,
            native_path=feature.native_path,
            diagnostic_code=feature.diagnostic_code,
            message=feature.message,
            metadata={
                **feature.metadata,
                "mapping_coverage_id": coverage.coverage_id,
            },
        )
        for feature in coverage.features
    )
    adapter = adapter_name or f"{source_format}.metadata_adapter"
    return AdapterCapabilityManifestIR(
        manifest_id=manifest_id
        or (
            f"adapter_capability_manifest.{source_format}.to."
            f"{target_format}.{manifest_version}"
        ),
        manifest_version=manifest_version,
        adapter_name=adapter,
        adapter_version=adapter_version,
        source_format=source_format,
        target_format=target_format,
        status=_adapter_capability_manifest_status(coverage),
        mapping_coverage_id=coverage.coverage_id,
        features=features,
        supported_features=coverage.supported_features,
        lossy_features=coverage.lossy_features,
        unsupported_features=coverage.unsupported_features,
        bit_order_policy=_adapter_bit_order_policy(source_format),
        measurement_mapping_policy=_adapter_measurement_mapping_policy(source_format),
        source_metadata_policy=_adapter_source_metadata_policy(source_format),
        target_projection_policy=_adapter_target_projection_policy(
            source_format,
            target_projection_required=not bool(
                coverage.metadata.get("restricted_subset")
            )
            and source_format != SUPPORTED_NATIVE_FORMAT,
        ),
        diagnostics=coverage.diagnostics,
        metadata_only=True,
        parser_implemented=False,
        external_object_constructed=False,
        execution_package_created=False,
        backend_called=False,
        network_accessed=False,
        target_hardware_facts_embedded=False,
        cascaqit_compat_required=False,
        metadata={
            "contract": "adapter_capability_manifest",
            "builder": "build_adapter_capability_manifest",
            "metadata_only": True,
            "manifest_version": manifest_version,
            "adapter_name": adapter,
            "adapter_version": adapter_version,
            "source_format": source_format,
            "target_format": target_format,
            "mapping_coverage_id": coverage.coverage_id,
            "direct_gates": coverage.metadata.get("direct_gates", ()),
            "lowered_gates": coverage.metadata.get("lowered_gates", {}),
            "blocked_gates": coverage.metadata.get("blocked_gates", ()),
            "blocked_reasons": coverage.metadata.get("blocked_reasons", {}),
            "semantic_evidence_required": bool(
                coverage.metadata.get("restricted_subset")
            )
            and source_format == "openqasm3",
            "semantic_evidence_level": (
                "simulator_backed_probability_equivalence"
                if bool(coverage.metadata.get("restricted_subset"))
                and source_format == "openqasm3"
                else "mapping_coverage_only"
            ),
            "semantic_evidence_paths": (
                ["direct_equivalence", "lowered_equivalence", "blocked_policy"]
                if bool(coverage.metadata.get("restricted_subset"))
                and source_format == "openqasm3"
                else []
            ),
            "parser_implemented": False,
            "external_object_constructed": False,
            "execution_package_created": False,
            "backend_called": False,
            "network_accessed": False,
            "target_hardware_facts_embedded": False,
            "target_projection_required": not bool(
                coverage.metadata.get("restricted_subset")
            )
            and source_format != SUPPORTED_NATIVE_FORMAT,
            "cascaqit_compat_required": False,
            **({} if metadata is None else metadata),
        },
    )


def build_program_import_source_map_summary(
    request: ProgramImportRequest,
    *,
    import_result: ProgramImportResult | None = None,
    mapping_coverage: ExternalFormatMappingCoverageIR | None = None,
    summary_id: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> ProgramImportSourceMapSummaryIR:
    """Summarize Program Import source/native path alignment metadata."""
    source_digest = (
        import_result.source_digest
        if import_result is not None
        else _source_digest(request.source)
    )
    source_metadata_ir = (
        import_result.source_metadata_ir
        if import_result is not None and import_result.source_metadata_ir is not None
        else _source_metadata_ir(request, source_digest)
    )
    coverage = mapping_coverage or build_external_format_mapping_coverage(
        source_format=request.source_format,
        target_format=SUPPORTED_NATIVE_FORMAT,
    )
    diagnostics = _source_map_summary_diagnostics(
        request=request,
        import_result=import_result,
        mapping_coverage=coverage,
    )
    entries = _source_map_summary_entries(
        request=request,
        mapping_coverage=coverage,
        diagnostics=diagnostics,
    )
    return ProgramImportSourceMapSummaryIR(
        summary_id=summary_id
        or f"import_source_map.{request.source_format}.{source_digest[:12]}",
        source_format=request.source_format,
        target_format=SUPPORTED_NATIVE_FORMAT,
        source_digest=source_digest,
        status=_source_map_summary_status(
            request=request,
            mapping_coverage=coverage,
            import_result=import_result,
        ),
        entries=entries,
        diagnostics=diagnostics,
        taxonomy_summary=diagnostic_taxonomy_summary(diagnostics),
        source_metadata=source_metadata_ir.to_dict(),
        mapping_coverage_id=coverage.coverage_id,
        native_ir_required=True,
        compiler_invoked=False,
        runtime_invoked=False,
        program_mutated=False,
        backend_bypass_allowed=False,
        metadata={
            "contract": "program_import_source_map_summary",
            "metadata_only": True,
            "source_format": request.source_format,
            "target_format": SUPPORTED_NATIVE_FORMAT,
            "source_digest": source_digest,
            "compiler_invoked": False,
            "runtime_invoked": False,
            "program_mutated": False,
            "diagnostics_json_compatible": True,
            **({} if metadata is None else metadata),
        },
    )


def build_adapter_conformance_fixture(
    request: ProgramImportRequest,
    *,
    mapping_coverage: ExternalFormatMappingCoverageIR | None = None,
    import_result: ProgramImportResult | None = None,
    import_source_map: ProgramImportSourceMapSummaryIR | None = None,
    target_projection_id: str | None = None,
    expected_result_adapter_status: AdapterFixtureResultStatus | None = None,
    fixture_id: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> AdapterConformanceFixtureIR:
    """Build a metadata-only conformance fixture for future adapters."""
    source_digest = _source_digest(request.source)
    source_metadata_ir = _source_metadata_ir(request, source_digest)
    coverage = mapping_coverage or build_external_format_mapping_coverage(
        source_format=request.source_format,
        target_format=SUPPORTED_NATIVE_FORMAT,
    )
    source_map = import_source_map or build_program_import_source_map_summary(
        request,
        import_result=import_result,
        mapping_coverage=coverage,
    )
    readiness = build_program_import_readiness(request)
    diagnostics = _adapter_conformance_fixture_diagnostics(
        mapping_coverage=coverage,
        import_source_map=source_map,
    )
    expected_import_status = _adapter_fixture_import_status(
        request=request,
        mapping_coverage=coverage,
        import_source_map=source_map,
    )
    result_status = expected_result_adapter_status or _adapter_fixture_result_status(
        expected_import_status=expected_import_status,
        mapping_coverage=coverage,
    )
    return AdapterConformanceFixtureIR(
        fixture_id=fixture_id
        or f"adapter_conformance.{request.source_format}.{source_digest[:12]}",
        source_format=request.source_format,
        source_digest=source_digest,
        source_metadata=source_metadata_ir.to_dict(),
        declared_mapping_coverage=coverage.to_dict(),
        target_projection_id=target_projection_id,
        expected_import_status=expected_import_status,
        expected_result_adapter_status=result_status,
        import_source_map_summary_id=source_map.summary_id,
        diagnostics=diagnostics,
        metadata_only=True,
        parser_invoked=False,
        external_object_constructed=False,
        execution_package_created=False,
        backend_called=False,
        network_accessed=False,
        cascaqit_compat_required=False,
        metadata={
            "contract": "adapter_conformance_fixture",
            "builder": "build_adapter_conformance_fixture",
            "metadata_only": True,
            "source_format": request.source_format,
            "target_format": SUPPORTED_NATIVE_FORMAT,
            "source_digest": source_digest,
            "readiness": readiness.to_dict(),
            "import_result_program_available": (
                import_result is not None and import_result.program is not None
            ),
            "restricted_subset": bool(coverage.metadata.get("restricted_subset")),
            "mapping_coverage_id": coverage.coverage_id,
            "import_source_map_summary_id": source_map.summary_id,
            "external_adapter_implemented": False,
            "full_parser_implemented": request.source_format == SUPPORTED_NATIVE_FORMAT,
            "parser_invoked": False,
            "external_object_constructed": False,
            "execution_package_created": False,
            "backend_called": False,
            "network_accessed": False,
            "cascaqit_compat_required": False,
            "fixture_payload_json_compatible": True,
            **({} if metadata is None else metadata),
        },
    )


def build_adapter_conformance_harness_report(
    submitted_fixture: AdapterConformanceFixtureIR | dict[str, Any],
    expected_fixture: AdapterConformanceFixtureIR | dict[str, Any],
    *,
    report_id: str | None = None,
    compared_fields: tuple[str, ...] | None = None,
    metadata: dict[str, Any] | None = None,
) -> AdapterConformanceHarnessReportIR:
    """Compare adapter fixtures without running external parsers or backends."""
    submitted_payload = _fixture_payload(submitted_fixture)
    expected_payload = _fixture_payload(expected_fixture)
    fields = compared_fields or _default_harness_compared_fields()
    matched = tuple(
        field
        for field in fields
        if _field_value(submitted_payload, field)
        == _field_value(expected_payload, field)
    )
    drift = tuple(field for field in fields if field not in set(matched))
    side_effect_violations = _fixture_side_effect_violations(submitted_payload)
    diagnostics = _adapter_conformance_harness_diagnostics(
        submitted_payload=submitted_payload,
        expected_payload=expected_payload,
        drift_fields=drift,
        side_effect_violations=side_effect_violations,
    )
    status: AdapterConformanceHarnessStatus = (
        "failed" if drift or side_effect_violations else "passed"
    )
    submitted_id = str(submitted_payload["fixture_id"])
    expected_id = str(expected_payload["fixture_id"])
    source_format = submitted_payload["source_format"]
    source_digest = str(submitted_payload["source_digest"])
    expected_source_digest = str(expected_payload["source_digest"])
    return AdapterConformanceHarnessReportIR(
        report_id=report_id
        or f"adapter_conformance_harness.{submitted_id}.vs.{expected_id}",
        status=status,
        submitted_fixture_id=submitted_id,
        expected_fixture_id=expected_id,
        source_format=source_format,
        source_digest=source_digest,
        expected_source_digest=expected_source_digest,
        compared_fields=fields,
        matched_fields=matched,
        drift_fields=drift,
        side_effect_violations=side_effect_violations,
        mapping_coverage_summary=_mapping_coverage_comparison_summary(
            submitted_payload=submitted_payload,
            expected_payload=expected_payload,
        ),
        diagnostics_taxonomy_summary=diagnostic_taxonomy_summary(diagnostics),
        diagnostics=diagnostics,
        metadata_only=True,
        parser_invoked=False,
        external_object_constructed=False,
        execution_package_created=False,
        backend_called=False,
        network_accessed=False,
        cascaqit_compat_required=False,
        metadata={
            "contract": "adapter_conformance_harness_report",
            "builder": "build_adapter_conformance_harness_report",
            "metadata_only": True,
            "source_format": source_format,
            "source_digest": source_digest,
            "expected_source_digest": expected_source_digest,
            "submitted_fixture_id": submitted_id,
            "expected_fixture_id": expected_id,
            "external_parser_invoked": False,
            "external_object_constructed": False,
            "execution_package_created": False,
            "backend_called": False,
            "network_accessed": False,
            "cascaqit_compat_required": False,
            **({} if metadata is None else metadata),
        },
    )


def build_openqasm3_export_roundtrip_evidence_package(
    program: DigitalProgramIR,
    *,
    package_id: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> AdapterExportRoundTripEvidencePackageIR:
    """Build positive OpenQASM export and round-trip conformance evidence."""
    export_result = export_program(
        ProgramExportRequest(program=program, target_format="openqasm3")
    )
    round_trip_report = prove_openqasm3_round_trip(
        program,
        report_id=f"roundtrip.evidence.openqasm3.{program.program_id}",
        imported_program_id=f"{program.program_id}.openqasm3.evidence_imported",
    )
    source_map_review = build_openqasm3_source_map_review(
        program,
        review_id=f"source_map_review.evidence.openqasm3.{program.program_id}",
        round_trip_report=round_trip_report,
    )
    diagnostics = (
        *export_result.diagnostics,
        *round_trip_report.diagnostics,
        *source_map_review.diagnostics,
    )
    status: AdapterReplayFixtureStatus = (
        "ready"
        if export_result.payload is not None and round_trip_report.status == "passed"
        else "blocked"
    )
    return AdapterExportRoundTripEvidencePackageIR(
        package_id=package_id
        or f"adapter_export_roundtrip_evidence.openqasm3.{program.stable_hash()[:12]}",
        status=status,
        source_format=SUPPORTED_NATIVE_FORMAT,
        target_format="openqasm3",
        source_program_id=program.program_id,
        source_program_hash=program.stable_hash(),
        export_result={
            "target_format": export_result.target_format,
            "payload_digest": export_result.metadata.get("payload_digest"),
            "payload_available": export_result.payload is not None,
            "source_program_hash": export_result.source_program_hash,
            "unsupported_features": list(export_result.unsupported_features),
            "diagnostic_codes": [
                diagnostic.code for diagnostic in export_result.diagnostics
            ],
            "export_contract": export_result.metadata.get("export_contract", {}),
            "bit_order": export_result.metadata.get("bit_order", {}),
            "measurement_mapping": export_result.metadata.get(
                "measurement_mapping",
                {},
            ),
        },
        round_trip_report={
            "report_id": round_trip_report.report_id,
            "status": round_trip_report.status,
            "exported_source_digest": round_trip_report.exported_source_digest,
            "imported_source_digest": round_trip_report.imported_source_digest,
            "payload_available": round_trip_report.payload_available,
            "matched_fields": list(round_trip_report.matched_fields),
            "drift_fields": list(round_trip_report.drift_fields),
            "unsupported_features": list(round_trip_report.unsupported_features),
            "diagnostic_codes": [
                diagnostic.code for diagnostic in round_trip_report.diagnostics
            ],
        },
        payload_digest=export_result.metadata.get("payload_digest"),
        matched_fields=round_trip_report.matched_fields,
        drift_fields=round_trip_report.drift_fields,
        diagnostics=diagnostics,
        metadata_only=True,
        replay_only=True,
        parser_invoked=True,
        external_sdk_imported=False,
        external_object_constructed=False,
        execution_package_created=False,
        backend_called=False,
        cloud_called=False,
        network_accessed=False,
        credential_accessed=False,
        cascaqit_compat_required=False,
        metadata={
            "contract": "openqasm3_export_roundtrip_evidence_package",
            "builder": "build_openqasm3_export_roundtrip_evidence_package",
            "metadata_only": True,
            "replay_only": True,
            "source_format": SUPPORTED_NATIVE_FORMAT,
            "target_format": "openqasm3",
            "positive_export_conformance": export_result.payload is not None,
            "round_trip_status": round_trip_report.status,
            "source_map_review": {
                "review_id": source_map_review.review_id,
                "status": source_map_review.status,
                "source_map_policy": source_map_review.source_map_policy,
                "mapping_counts": source_map_review.mapping_counts,
                "drift_categories": list(source_map_review.drift_categories),
                "diagnostic_codes": [
                    diagnostic.code for diagnostic in source_map_review.diagnostics
                ],
            },
            "semantic_equivalence_required": True,
            "source_text_byte_for_byte_required": False,
            "external_adapter_implemented": False,
            "cascaqit_compat_required": False,
            "compat_may_submit_evidence": True,
            "compat_must_not_create_execution_package": True,
            "native_sdk_boundary": (
                "Adapters submit Native IR and evidence only; execution packages "
                "are created by native compile/package flows."
            ),
            **({} if metadata is None else metadata),
        },
    )


def build_adapter_replay_fixture_package(
    request: ProgramImportRequest,
    *,
    mapping_coverage: ExternalFormatMappingCoverageIR | None = None,
    capability_manifest: AdapterCapabilityManifestIR | None = None,
    expected_fixture: AdapterConformanceFixtureIR | None = None,
    package_id: str | None = None,
    target_projection_id: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> AdapterReplayFixturePackageIR:
    """Build a replay-only package for adapter conformance review."""
    coverage = mapping_coverage or build_external_format_mapping_coverage(
        source_format=request.source_format,
        target_format=SUPPORTED_NATIVE_FORMAT,
    )
    manifest = capability_manifest or build_adapter_capability_manifest(
        source_format=request.source_format,
        target_format=SUPPORTED_NATIVE_FORMAT,
        mapping_coverage=coverage,
    )
    if manifest.source_format != request.source_format:
        raise ValueError("capability_manifest source_format must match request.")
    if manifest.target_format != SUPPORTED_NATIVE_FORMAT:
        raise ValueError("capability_manifest target_format must be native JSON.")
    if manifest.mapping_coverage_id != coverage.coverage_id:
        raise ValueError("capability_manifest mapping coverage must match package.")
    fixture = expected_fixture or build_adapter_conformance_fixture(
        request,
        mapping_coverage=coverage,
        target_projection_id=target_projection_id,
    )
    if fixture.source_format != request.source_format:
        raise ValueError("expected_fixture source_format must match request.")
    if fixture.source_digest != _source_digest(request.source):
        raise ValueError("expected_fixture source digest must match request.")
    if fixture.declared_mapping_coverage.get("coverage_id") != coverage.coverage_id:
        raise ValueError("expected_fixture mapping coverage must match package.")
    harness = build_adapter_conformance_harness_report(fixture, fixture)
    source_metadata = _source_metadata_ir(
        request,
        _source_digest(request.source),
    )
    diagnostics = tuple(
        diagnostic
        for diagnostic in (
            *coverage.diagnostics,
            *manifest.diagnostics,
            *fixture.diagnostics,
        )
    )
    return AdapterReplayFixturePackageIR(
        package_id=package_id
        or (
            f"adapter_replay_fixture.{request.source_format}."
            f"{source_metadata.source_digest[:12]}"
        ),
        status="blocked" if fixture.expected_import_status == "blocked" else "ready",
        source_format=request.source_format,
        target_format=SUPPORTED_NATIVE_FORMAT,
        source_payload=request.source,
        source_metadata=source_metadata.to_dict(),
        mapping_coverage=coverage.to_dict(),
        capability_manifest=manifest.to_dict(),
        expected_fixture=fixture.to_dict(),
        harness_report=harness.to_dict(),
        expected_import_status=fixture.expected_import_status,
        expected_result_adapter_status=fixture.expected_result_adapter_status,
        diagnostics=diagnostics,
        metadata_only=True,
        replay_only=True,
        parser_invoked=False,
        external_sdk_imported=False,
        external_object_constructed=False,
        execution_package_created=False,
        backend_called=False,
        network_accessed=False,
        credential_accessed=False,
        cascaqit_compat_required=False,
        metadata={
            "contract": "adapter_replay_fixture_package",
            "builder": "build_adapter_replay_fixture_package",
            "metadata_only": True,
            "replay_only": True,
            "source_format": request.source_format,
            "target_format": SUPPORTED_NATIVE_FORMAT,
            "source_digest": source_metadata.source_digest,
            "mapping_coverage_id": coverage.coverage_id,
            "capability_manifest_id": manifest.manifest_id,
            "expected_fixture_id": fixture.fixture_id,
            "harness_report_id": harness.report_id,
            "parser_invoked": False,
            "external_sdk_imported": False,
            "external_object_constructed": False,
            "execution_package_created": False,
            "backend_called": False,
            "network_accessed": False,
            "credential_accessed": False,
            "cascaqit_compat_required": False,
            **({} if metadata is None else metadata),
        },
    )


def build_program_import_readiness(
    request: ProgramImportRequest,
) -> ProgramInteropReadinessIR:
    """Return metadata-only readiness for a Program Import request."""
    lossy_mappings = _declared_lossy_mappings(request)
    unsupported_features = _declared_unsupported_features(request)
    if unsupported_features or (lossy_mappings and request.on_lossy == "error"):
        status: Literal["ready", "adapter_required", "blocked"] = "blocked"
    elif request.source_format != SUPPORTED_NATIVE_FORMAT:
        status = "adapter_required"
    else:
        status = "ready"
    return ProgramInteropReadinessIR(
        operation="import",
        source_format=request.source_format,
        target_format=SUPPORTED_NATIVE_FORMAT,
        status=status,
        adapter_required=request.source_format != SUPPORTED_NATIVE_FORMAT,
        lossy_policy=request.on_lossy,
        unsupported_policy=request.on_unsupported,
        declared_lossy_mappings=lossy_mappings,
        declared_unsupported_features=unsupported_features,
        program_available=status == "ready",
        metadata={
            "contract": "program_interop_readiness",
            "readiness_kind": "program_import",
            "source_format": request.source_format,
            "target_format": SUPPORTED_NATIVE_FORMAT,
            "native_import_path": ("cascaqit.interop.import_program -> ProgramIR"),
            "external_adapter_required": (
                request.source_format != SUPPORTED_NATIVE_FORMAT
            ),
            "backend_bypass_reason": (
                "External and native program imports must enter Native IR "
                "before validation, compilation, packaging, runtime, or backend "
                "execution."
            ),
        },
    )


def build_program_export_readiness(
    request: ProgramExportRequest,
) -> ProgramInteropReadinessIR:
    """Return metadata-only readiness for a Program Export request."""
    is_native_json = request.target_format == SUPPORTED_NATIVE_FORMAT
    is_restricted_openqasm3 = request.target_format == "openqasm3" and isinstance(
        request.program, DigitalProgramIR
    )
    adapter_required = not (is_native_json or is_restricted_openqasm3)
    payload_available = is_native_json or is_restricted_openqasm3
    status: Literal["ready", "adapter_required", "blocked"] = (
        "ready" if payload_available else "adapter_required"
    )
    return ProgramInteropReadinessIR(
        operation="export",
        source_format=SUPPORTED_NATIVE_FORMAT,
        target_format=request.target_format,
        status=status,
        adapter_required=adapter_required,
        lossy_policy=request.on_lossy,
        unsupported_policy=request.on_unsupported,
        payload_available=payload_available,
        program_available=True,
        metadata={
            "contract": "program_interop_readiness",
            "readiness_kind": "program_export",
            "source_format": SUPPORTED_NATIVE_FORMAT,
            "target_format": request.target_format,
            "source_program_id": request.program.program_id,
            "source_program_hash": request.program.stable_hash(),
            "external_adapter_required": adapter_required,
            "restricted_openqasm3_export_ready": is_restricted_openqasm3,
            "native_program_kind": type(request.program).__name__,
            "backend_bypass_reason": (
                "Exported external payloads are serialization artifacts, not "
                "hardware execution packages."
            ),
        },
    )


def import_program(request: ProgramImportRequest) -> ProgramImportResult:
    """Import a program according to the CASCAQit interop contract."""
    source_digest = _source_digest(request.source)
    source_metadata_ir = _source_metadata_ir(request, source_digest)
    readiness = build_program_import_readiness(request)
    declared_diagnostics = _declared_mapping_diagnostics(request)
    unsupported_features = _declared_unsupported_features(request)
    lossy_mappings = _declared_lossy_mappings(request)

    if unsupported_features and request.on_unsupported == "raise":
        raise ValueError("Program import declared unsupported source features.")
    if lossy_mappings and request.on_lossy == "error":
        return _blocked_import_result(
            request=request,
            source_digest=source_digest,
            source_metadata_ir=source_metadata_ir,
            diagnostics=declared_diagnostics,
            reason="Declared lossy source mappings are configured as errors.",
        )
    if unsupported_features:
        return _blocked_import_result(
            request=request,
            source_digest=source_digest,
            source_metadata_ir=source_metadata_ir,
            diagnostics=declared_diagnostics,
            reason="Declared unsupported source features block native import.",
        )

    if request.source_format == "openqasm3":
        return _openqasm3_subset_import_result(
            request,
            source_digest,
            source_metadata_ir,
            readiness,
            declared_diagnostics=declared_diagnostics,
        )

    if request.source_format != SUPPORTED_NATIVE_FORMAT:
        return _unsupported_import_result(request, source_digest, source_metadata_ir)

    try:
        program = _program_from_source(request.source)
    except (KeyError, TypeError, ValueError, json.JSONDecodeError) as error:
        diagnostic = _diagnostic(
            diagnostic_id="interop.import_invalid_source",
            code="PROGRAM_IMPORT_INVALID_SOURCE",
            message=f"Program import failed: {error}",
            object_path="source",
            suggestion="Provide valid CASCAQit native ProgramIR JSON.",
        )
        return ProgramImportResult(
            source_format=request.source_format,
            program=None,
            diagnostics=(diagnostic,),
            source_digest=source_digest,
            source_metadata_ir=source_metadata_ir,
            source_metadata=source_metadata_ir.to_dict(),
            metadata=_import_result_metadata(
                request,
                source_metadata_ir,
                readiness=readiness,
            ),
        )

    metadata = dict(program.metadata)
    if request.preserve_metadata:
        metadata["source"] = source_metadata_ir.to_dict()
        metadata["import_contract"] = _native_import_contract_metadata(
            request,
            source_metadata_ir,
        )
        metadata["interop_readiness"] = readiness.to_dict()
        program = ProgramIR.from_dict({**program.to_dict(), "metadata": metadata})
    return ProgramImportResult(
        source_format=request.source_format,
        program=program,
        diagnostics=declared_diagnostics,
        source_digest=source_digest,
        source_metadata_ir=source_metadata_ir,
        source_metadata=source_metadata_ir.to_dict(),
        mapping_issues=request.declared_lossy_mappings,
        lossy_mappings=lossy_mappings,
        metadata=_import_result_metadata(
            request,
            source_metadata_ir,
            readiness=readiness,
        ),
    )


def export_program(request: ProgramExportRequest) -> ProgramExportResult:
    """Export a ProgramIR according to the restricted format contract."""
    readiness = build_program_export_readiness(request)
    if request.target_format == "openqasm3":
        return _openqasm3_export_result(request, readiness)
    if request.target_format != SUPPORTED_NATIVE_FORMAT:
        return _unsupported_export_result(request, readiness)
    if not isinstance(request.program, ProgramIR):
        return _invalid_native_export_result(request, readiness)

    payload = request.program.to_json()
    return ProgramExportResult(
        target_format=request.target_format,
        payload=payload,
        diagnostics=(),
        source_program_hash=request.program.stable_hash(),
        metadata={
            "bit_ordering": request.program.bit_ordering,
            "source_program_id": request.program.program_id,
            "interop_readiness": readiness.to_dict(),
        },
    )


def _invalid_native_export_result(
    request: ProgramExportRequest,
    readiness: ProgramInteropReadinessIR,
) -> ProgramExportResult:
    diagnostic = _diagnostic(
        diagnostic_id="interop.export_native_program_invalid",
        code="PROGRAM_EXPORT_INVALID_PROGRAM",
        message="Native JSON export requires ProgramIR.",
        object_path="program",
        suggestion=(
            "Use ProgramIR for cascaqit.native_json export, or choose a "
            "format supported by the supplied program kind."
        ),
        metadata={
            "target_format": request.target_format,
            "program_kind": type(request.program).__name__,
        },
    )
    if request.on_unsupported == "raise":
        raise ValueError(diagnostic.message)
    metadata = {
        "interop_readiness": {
            **readiness.to_dict(),
            "status": "blocked",
            "payload_available": False,
        },
        "blocked": True,
        "payload_available": False,
        "execution_package_created": False,
        "backend_called": False,
        "network_accessed": False,
    }
    return ProgramExportResult(
        target_format=request.target_format,
        payload=None,
        diagnostics=(diagnostic,),
        source_program_hash=request.program.stable_hash(),
        unsupported_features=("export:program_kind",),
        metadata=metadata,
    )


def _program_from_source(source: str | dict[str, Any]) -> ProgramIR:
    if isinstance(source, str):
        return ProgramIR.from_json(source)
    return ProgramIR.from_dict(source)


def _unsupported_import_result(
    request: ProgramImportRequest,
    source_digest: str,
    source_metadata_ir: ProgramSourceMetadataIR,
) -> ProgramImportResult:
    readiness = build_program_import_readiness(request)
    feature = f"import:{request.source_format}"
    diagnostic = _unsupported_diagnostic(
        operation="import",
        source_format=request.source_format,
    )
    if request.on_unsupported == "raise":
        raise ValueError(diagnostic.message)
    return ProgramImportResult(
        source_format=request.source_format,
        program=None,
        diagnostics=(diagnostic,),
        source_digest=source_digest,
        source_metadata_ir=source_metadata_ir,
        source_metadata=source_metadata_ir.to_dict(),
        unsupported_features=(feature,),
        metadata=_import_result_metadata(
            request,
            source_metadata_ir,
            readiness=readiness,
            external_adapter_required=True,
        ),
    )


def _openqasm3_subset_import_result(
    request: ProgramImportRequest,
    source_digest: str,
    source_metadata_ir: ProgramSourceMetadataIR,
    readiness: ProgramInteropReadinessIR,
    *,
    declared_diagnostics: tuple[DiagnosticsIR, ...],
) -> ProgramImportResult:
    if not isinstance(request.source, str):
        diagnostic = _diagnostic(
            diagnostic_id="interop.openqasm3_source_invalid",
            code="OPENQASM_SOURCE_INVALID",
            message="OpenQASM 3 import requires source text.",
            object_path="source",
            suggestion="Pass OpenQASM 3 source as a string.",
            metadata={
                "source_format": request.source_format,
                "restricted_subset": True,
            },
        )
        if request.on_unsupported == "raise":
            raise ValueError(diagnostic.message)
        return ProgramImportResult(
            source_format=request.source_format,
            program=None,
            diagnostics=(*declared_diagnostics, diagnostic),
            source_digest=source_digest,
            source_metadata_ir=source_metadata_ir,
            source_metadata=source_metadata_ir.to_dict(),
            unsupported_features=("openqasm3:source_text_required",),
            metadata=_openqasm3_import_metadata(
                request,
                source_metadata_ir,
                readiness,
                program_available=False,
                subset_summary={"error": "source_text_required"},
            ),
        )

    subset = parse_openqasm3_subset(
        request.source,
        program_id=_openqasm3_program_id(request),
        source_id=request.source_id,
    )
    diagnostics = (*declared_diagnostics, *subset.diagnostics)
    if subset.program is None and request.on_unsupported == "raise":
        message = (
            subset.diagnostics[0].message
            if subset.diagnostics
            else "OpenQASM 3 source is outside the supported subset."
        )
        raise ValueError(message)

    program = subset.program
    if program is not None and request.preserve_metadata:
        metadata = dict(program.metadata)
        metadata["source"] = source_metadata_ir.to_dict()
        metadata["import_contract"] = _openqasm3_import_contract_metadata(
            request,
            source_metadata_ir,
            subset,
        )
        metadata["interop_readiness"] = readiness.to_dict()
        program = DigitalProgramIR.from_dict(
            {**program.to_dict(), "metadata": metadata}
        )

    unsupported_features = (
        ()
        if program is not None
        else tuple(
            f"openqasm3:{diagnostic.code}"
            for diagnostic in subset.diagnostics
            if diagnostic.severity == "error"
        )
    )
    return ProgramImportResult(
        source_format=request.source_format,
        program=program,
        diagnostics=diagnostics,
        source_digest=source_digest,
        source_metadata_ir=source_metadata_ir,
        source_metadata=source_metadata_ir.to_dict(),
        mapping_issues=request.declared_lossy_mappings,
        lossy_mappings=_declared_lossy_mappings(request),
        unsupported_features=unsupported_features,
        metadata=_openqasm3_import_metadata(
            request,
            source_metadata_ir,
            readiness,
            program_available=program is not None,
            subset_summary=_openqasm3_subset_summary(subset),
        ),
    )


def _blocked_import_result(
    *,
    request: ProgramImportRequest,
    source_digest: str,
    source_metadata_ir: ProgramSourceMetadataIR,
    diagnostics: tuple[DiagnosticsIR, ...],
    reason: str,
) -> ProgramImportResult:
    readiness = build_program_import_readiness(request)
    blocking = _diagnostic(
        diagnostic_id="interop.import_mapping_blocked",
        code="PROGRAM_IMPORT_MAPPING_BLOCKED",
        message=reason,
        object_path="import.mapping",
        suggestion=(
            "Resolve unsupported or loss-sensitive mapping issues before "
            "returning a Native IR program."
        ),
        metadata={
            "source_format": request.source_format,
            "lossy_mappings": _declared_lossy_mappings(request),
            "unsupported_features": _declared_unsupported_features(request),
        },
    )
    return ProgramImportResult(
        source_format=request.source_format,
        program=None,
        diagnostics=(*diagnostics, blocking),
        source_digest=source_digest,
        source_metadata_ir=source_metadata_ir,
        source_metadata=source_metadata_ir.to_dict(),
        mapping_issues=(
            *request.declared_lossy_mappings,
            *request.declared_unsupported_features,
        ),
        lossy_mappings=_declared_lossy_mappings(request),
        unsupported_features=_declared_unsupported_features(request),
        metadata=_import_result_metadata(
            request,
            source_metadata_ir,
            readiness=readiness,
            blocked=True,
        ),
    )


def _unsupported_export_result(
    request: ProgramExportRequest,
    readiness: ProgramInteropReadinessIR,
) -> ProgramExportResult:
    feature = f"export:{request.target_format}"
    diagnostic = _unsupported_diagnostic(
        operation="export",
        source_format=request.target_format,
    )
    if request.on_unsupported == "raise":
        raise ValueError(diagnostic.message)
    return ProgramExportResult(
        target_format=request.target_format,
        payload=None,
        diagnostics=(diagnostic,),
        source_program_hash=request.program.stable_hash(),
        unsupported_features=(feature,),
        metadata={"interop_readiness": readiness.to_dict()},
    )


def _openqasm3_export_result(
    request: ProgramExportRequest,
    readiness: ProgramInteropReadinessIR,
) -> ProgramExportResult:
    export_result = render_openqasm3_subset(
        request.program,
        export_id=f"program_export.openqasm3.{request.program.program_id}",
    )
    if not export_result.payload_available and request.on_unsupported == "raise":
        message = (
            export_result.diagnostics[0].message
            if export_result.diagnostics
            else "Program is outside the restricted OpenQASM 3 export subset."
        )
        raise ValueError(message)
    metadata = _openqasm3_export_metadata(request, readiness, export_result)
    return ProgramExportResult(
        target_format=request.target_format,
        payload=export_result.source,
        diagnostics=export_result.diagnostics,
        source_program_hash=request.program.stable_hash(),
        lossy_mappings=(),
        unsupported_features=tuple(
            f"openqasm3:{feature}" for feature in export_result.unsupported_features
        ),
        metadata=metadata,
    )


def _unsupported_diagnostic(*, operation: str, source_format: str) -> DiagnosticsIR:
    return _diagnostic(
        diagnostic_id=f"interop.{operation}_format_unsupported",
        code="PROGRAM_FORMAT_UNSUPPORTED",
        message=f"{operation} for format {source_format!r} is not implemented.",
        object_path=f"{operation}.format",
        suggestion=(
            "Use 'cascaqit.native_json', or implement an adapter that first "
            "emits CASCAQit Native IR with source metadata and mapping "
            "diagnostics."
        ),
        metadata={
            "format": source_format,
            "operation": operation,
            "adapter_required": True,
            "native_ir_required": True,
            "backend_bypass_allowed": False,
        },
    )


def _source_map_summary_diagnostics(
    *,
    request: ProgramImportRequest,
    import_result: ProgramImportResult | None,
    mapping_coverage: ExternalFormatMappingCoverageIR,
) -> tuple[DiagnosticsIR, ...]:
    result_diagnostics = () if import_result is None else import_result.diagnostics
    declared_diagnostics = _declared_mapping_diagnostics(request)
    diagnostics = (
        *mapping_coverage.diagnostics,
        *declared_diagnostics,
        *result_diagnostics,
    )
    deduplicated: dict[str, DiagnosticsIR] = {}
    for diagnostic in diagnostics:
        deduplicated[diagnostic.diagnostic_id] = _with_interop_taxonomy(diagnostic)
    return tuple(deduplicated[key] for key in sorted(deduplicated))


def _source_map_summary_entries(
    *,
    request: ProgramImportRequest,
    mapping_coverage: ExternalFormatMappingCoverageIR,
    diagnostics: tuple[DiagnosticsIR, ...],
) -> tuple[ProgramImportSourceMapEntryIR, ...]:
    entries = [
        _entry_from_coverage_feature(
            feature,
            request=request,
            diagnostics=diagnostics,
        )
        for feature in mapping_coverage.features
    ]
    entries.extend(
        _entry_from_mapping_issue(
            issue,
            request=request,
            diagnostics=diagnostics,
        )
        for issue in (
            *request.declared_lossy_mappings,
            *request.declared_unsupported_features,
        )
    )
    return tuple(entries)


def _entry_from_coverage_feature(
    feature: ExternalFormatFeatureCoverageIR,
    *,
    request: ProgramImportRequest,
    diagnostics: tuple[DiagnosticsIR, ...],
) -> ProgramImportSourceMapEntryIR:
    return ProgramImportSourceMapEntryIR(
        entry_id=f"coverage.{feature.feature_id}",
        source_format=request.source_format,
        source_path=feature.source_path,
        native_path=feature.native_path,
        feature=feature.feature,
        support_level=feature.support_level,
        reason_category=feature.reason_category,
        action=feature.action,
        diagnostic_ids=_diagnostic_ids_for_feature(
            diagnostics,
            feature=feature.feature,
            source_path=feature.source_path,
            native_path=feature.native_path,
        ),
        metadata={
            "entry_source": "mapping_coverage",
            "feature_id": feature.feature_id,
        },
    )


def _entry_from_mapping_issue(
    issue: ProgramImportMappingIssueIR,
    *,
    request: ProgramImportRequest,
    diagnostics: tuple[DiagnosticsIR, ...],
) -> ProgramImportSourceMapEntryIR:
    support_level: MappingSupportLevel = (
        "unsupported" if issue.issue_type == "unsupported" else "lossy"
    )
    action = "block_import" if support_level == "unsupported" else "warn_and_review"
    return ProgramImportSourceMapEntryIR(
        entry_id=f"declared.{issue.issue_id}",
        source_format=request.source_format,
        source_path=issue.source_path or "import.mapping",
        native_path=issue.native_path,
        feature=issue.feature,
        support_level=support_level,
        reason_category=str(
            issue.metadata.get(
                "reason_category",
                "measurement_semantics"
                if support_level == "unsupported"
                else "requires_adapter",
            )
        ),
        action=action,
        diagnostic_ids=_diagnostic_ids_for_feature(
            diagnostics,
            feature=issue.feature,
            source_path=issue.source_path,
            native_path=issue.native_path,
        ),
        metadata={
            "entry_source": "declared_mapping_issue",
            "issue_id": issue.issue_id,
            "issue_type": issue.issue_type,
        },
    )


def _diagnostic_ids_for_feature(
    diagnostics: tuple[DiagnosticsIR, ...],
    *,
    feature: str,
    source_path: str | None,
    native_path: str | None,
) -> tuple[str, ...]:
    ids = []
    for diagnostic in diagnostics:
        metadata = diagnostic.metadata
        if (
            metadata.get("feature") == feature
            or metadata.get("source_path") == source_path
            or metadata.get("native_path") == native_path
        ):
            ids.append(diagnostic.diagnostic_id)
    return tuple(sorted(set(ids)))


def _source_map_summary_status(
    *,
    request: ProgramImportRequest,
    mapping_coverage: ExternalFormatMappingCoverageIR,
    import_result: ProgramImportResult | None,
) -> Literal["aligned", "lossy", "blocked", "adapter_required"]:
    if import_result is not None and (
        import_result.unsupported_features or import_result.program is None
    ):
        return "blocked" if import_result.unsupported_features else "adapter_required"
    if mapping_coverage.unsupported_features or _declared_unsupported_features(request):
        return "blocked"
    if request.source_format == SUPPORTED_NATIVE_FORMAT and (
        mapping_coverage.lossy_features or _declared_lossy_mappings(request)
    ):
        return "lossy"
    if (
        import_result is not None
        and import_result.program is not None
        and mapping_coverage.status == "ready"
    ):
        return "aligned"
    if request.source_format != SUPPORTED_NATIVE_FORMAT:
        return "adapter_required"
    if mapping_coverage.lossy_features or _declared_lossy_mappings(request):
        return "lossy"
    return "aligned"


def _adapter_conformance_fixture_diagnostics(
    *,
    mapping_coverage: ExternalFormatMappingCoverageIR,
    import_source_map: ProgramImportSourceMapSummaryIR,
) -> tuple[DiagnosticsIR, ...]:
    deduplicated: dict[str, DiagnosticsIR] = {}
    omit_info_diagnostics = (
        import_source_map.status == "aligned" and mapping_coverage.status == "ready"
    )
    for diagnostic in (
        *mapping_coverage.diagnostics,
        *import_source_map.diagnostics,
    ):
        if omit_info_diagnostics and diagnostic.severity == "info":
            continue
        deduplicated[diagnostic.diagnostic_id] = _with_interop_taxonomy(diagnostic)
    return tuple(deduplicated[key] for key in sorted(deduplicated))


def _adapter_fixture_import_status(
    *,
    request: ProgramImportRequest,
    mapping_coverage: ExternalFormatMappingCoverageIR,
    import_source_map: ProgramImportSourceMapSummaryIR,
) -> AdapterFixtureImportStatus:
    if import_source_map.status in ("aligned", "lossy", "blocked"):
        return import_source_map.status
    if mapping_coverage.unsupported_features or _declared_unsupported_features(request):
        return "blocked"
    if mapping_coverage.lossy_features or _declared_lossy_mappings(request):
        return "lossy"
    return "adapter_required"


def _adapter_fixture_result_status(
    *,
    expected_import_status: AdapterFixtureImportStatus,
    mapping_coverage: ExternalFormatMappingCoverageIR,
) -> AdapterFixtureResultStatus:
    if expected_import_status == "aligned":
        return "ready"
    if expected_import_status == "lossy" or (
        mapping_coverage.lossy_features and not mapping_coverage.unsupported_features
    ):
        return "lossy"
    return "unsupported"


def _with_interop_taxonomy(diagnostic: DiagnosticsIR) -> DiagnosticsIR:
    metadata = dict(diagnostic.metadata)
    reason_category = str(
        metadata.get("reason_category")
        or metadata.get("issue_type")
        or _reason_category_from_code(diagnostic.code)
    )
    action = str(metadata.get("action") or _action_from_code(diagnostic.code))
    metadata.update(
        {
            "reason_category": reason_category,
            "taxonomy_stage": "interop",
            "action": action,
            "actionable": bool(diagnostic.suggestion or action),
        }
    )
    return DiagnosticsIR(
        diagnostic_id=diagnostic.diagnostic_id,
        stage=diagnostic.stage,
        severity=diagnostic.severity,
        code=diagnostic.code,
        message=diagnostic.message,
        schema_version=diagnostic.schema_version,
        object_path=diagnostic.object_path,
        suggestion=diagnostic.suggestion,
        metadata=metadata,
    )


def _reason_category_from_code(code: str) -> str:
    if "LOSSY" in code:
        return "requires_adapter"
    if "UNSUPPORTED" in code:
        return "unsupported_feature"
    if "INVALID_SOURCE" in code:
        return "invalid_source"
    if "FORMAT_UNSUPPORTED" in code:
        return "requires_adapter"
    return "interop"


def _action_from_code(code: str) -> str:
    if "LOSSY" in code:
        return "warn_and_review"
    if "UNSUPPORTED" in code or "INVALID_SOURCE" in code:
        return "block_import"
    if "FORMAT_UNSUPPORTED" in code:
        return "adapter_required"
    return "review"


def _default_mapping_coverage_features(
    source_format: ProgramFormat,
) -> tuple[ExternalFormatFeatureCoverageIR, ...]:
    if source_format == SUPPORTED_NATIVE_FORMAT:
        return (
            _feature(
                source_format=source_format,
                feature_id="native_program_ir",
                feature="cascaqit_native_program_ir",
                support_level="supported",
                reason_category="native_equivalent",
                action="map_to_native",
                source_path="source",
                native_path="ProgramIR",
                message="CASCAQit native JSON maps directly to ProgramIR.",
            ),
        )
    if source_format == "openqasm3":
        return (
            _feature(
                source_format=source_format,
                feature_id="openqasm_static_gate_subset",
                feature="static_gate_subset",
                support_level="lossy",
                reason_category="requires_adapter",
                action="warn_and_review",
                source_path="program.statements[*]",
                native_path="DigitalProgramIR.circuit.operations",
                message=(
                    "OpenQASM static gate statements require an adapter before "
                    "entering CASCAQit DigitalProgramIR."
                ),
            ),
            _feature(
                source_format=source_format,
                feature_id="openqasm_dynamic_circuit",
                feature="dynamic_circuit",
                support_level="unsupported",
                reason_category="dynamic_control",
                action="block_import",
                source_path="program.control_flow",
                native_path=None,
                message="Dynamic OpenQASM control flow has no native execution path.",
            ),
            _feature(
                source_format=source_format,
                feature_id="openqasm_mid_circuit_measurement",
                feature="mid_circuit_measurement",
                support_level="unsupported",
                reason_category="measurement_semantics",
                action="block_import",
                source_path="program.measurements[mid_circuit]",
                native_path="ProgramIR.measurements",
                message=(
                    "CASCAQit native analog ProgramIR supports terminal "
                    "measurement boundaries only."
                ),
            ),
            _feature(
                source_format=source_format,
                feature_id="openqasm_defcal_timing",
                feature="defcal_timing",
                support_level="unsupported",
                reason_category="timing_semantics",
                action="block_import",
                source_path="program.defcal",
                native_path="TargetProjectionIR.timing",
                message="OpenQASM defcal timing requires explicit adapter lowering.",
            ),
        )
    if source_format == "braket_ahs":
        return (
            _feature(
                source_format=source_format,
                feature_id="braket_ahs_global_drive",
                feature="global_drive",
                support_level="lossy",
                reason_category="requires_adapter",
                action="warn_and_review",
                source_path="braket_ahs.hamiltonian.drivingFields",
                native_path="ProgramIR.hamiltonian.terms",
                message=(
                    "Braket AHS global drive can be reviewed for CASCAQit "
                    "analog lowering but requires an adapter."
                ),
            ),
            _feature(
                source_format=source_format,
                feature_id="braket_ahs_local_detuning_pattern",
                feature="local_detuning_pattern",
                support_level="unsupported",
                reason_category="analog_feature_gap",
                action="block_import",
                source_path="braket_ahs.hamiltonian.localDetuning",
                native_path="HamiltonianIR.local_detuning_terms",
                message="Local detuning patterns are not yet supported natively.",
            ),
            _feature(
                source_format=source_format,
                feature_id="braket_ahs_geometry_mismatch",
                feature="analog_geometry_mismatch",
                support_level="unsupported",
                reason_category="geometry_mismatch",
                action="block_import",
                source_path="braket_ahs.register.sites",
                native_path="AtomRegisterIR.sites",
                message=(
                    "Analog geometry must be validated against CASCAQit target "
                    "projection constraints before import."
                ),
            ),
        )
    if source_format == "pulser_json":
        return (
            _feature(
                source_format=source_format,
                feature_id="pulser_sequence_channels",
                feature="sequence_channels",
                support_level="lossy",
                reason_category="requires_adapter",
                action="warn_and_review",
                source_path="pulser.sequence.channels",
                native_path="TargetProjectionIR.control_channels",
                message="Pulser channel declarations require explicit adapter mapping.",
            ),
            _feature(
                source_format=source_format,
                feature_id="pulser_pulse_unit_ambiguity",
                feature="pulse_unit_ambiguity",
                support_level="unsupported",
                reason_category="unit_ambiguity",
                action="block_import",
                source_path="pulser.sequence.pulses[*]",
                native_path="ProgramIR.unit_conventions",
                message="Pulser pulse units must be made explicit before import.",
            ),
            _feature(
                source_format=source_format,
                feature_id="pulser_local_detuning_pattern",
                feature="local_detuning_pattern",
                support_level="unsupported",
                reason_category="analog_feature_gap",
                action="block_import",
                source_path="pulser.sequence.detuning_maps",
                native_path="HamiltonianIR.local_detuning_terms",
                message="Pulser local detuning maps are not yet lowered natively.",
            ),
        )
    if source_format == "bloqade_analog":
        return (
            _feature(
                source_format=source_format,
                feature_id="bloqade_global_waveforms",
                feature="global_waveforms",
                support_level="lossy",
                reason_category="requires_adapter",
                action="warn_and_review",
                source_path="bloqade.program.waveforms",
                native_path="HamiltonianIR.terms",
                message="Bloqade analog waveforms require explicit adapter mapping.",
            ),
            _feature(
                source_format=source_format,
                feature_id="bloqade_analog_geometry_mismatch",
                feature="analog_geometry_mismatch",
                support_level="unsupported",
                reason_category="geometry_mismatch",
                action="block_import",
                source_path="bloqade.program.geometry",
                native_path="AtomRegisterIR.sites",
                message="Bloqade geometry must be checked against target projection.",
            ),
            _feature(
                source_format=source_format,
                feature_id="bloqade_local_detuning_pattern",
                feature="local_detuning_pattern",
                support_level="unsupported",
                reason_category="analog_feature_gap",
                action="block_import",
                source_path="bloqade.program.local_detuning",
                native_path="HamiltonianIR.local_detuning_terms",
                message="Bloqade local detuning remains unsupported by native import.",
            ),
        )
    return (
        _feature(
            source_format=source_format,
            feature_id="compat_atom_program_boundary",
            feature="compat_atom_program",
            support_level="lossy",
            reason_category="compat_boundary",
            action="adapter_required",
            source_path="AtomProgram",
            native_path="ProgramIR",
            message=(
                "cascaqit-compat AtomProgram must be imported through an "
                "explicit adapter; native SDK does not depend on compat."
            ),
        ),
        _feature(
            source_format=source_format,
            feature_id="compat_external_runtime_object",
            feature="external_runtime_object",
            support_level="unsupported",
            reason_category="external_runtime_object",
            action="block_import",
            source_path="AtomProgram.backend_payload",
            native_path=None,
            message=(
                "External runtime/backend payloads cannot bypass CASCAQit "
                "Native IR, compiler, runtime, or hardware submission."
            ),
        ),
    )


def _feature(
    *,
    source_format: ProgramFormat,
    feature_id: str,
    feature: str,
    support_level: MappingSupportLevel,
    reason_category: MappingReasonCategory,
    action: MappingAction,
    source_path: str,
    native_path: str | None,
    message: str,
    metadata: dict[str, Any] | None = None,
) -> ExternalFormatFeatureCoverageIR:
    diagnostic_code = None
    if support_level == "lossy":
        diagnostic_code = "PROGRAM_IMPORT_LOSSY_MAPPING"
    elif support_level == "unsupported":
        diagnostic_code = "PROGRAM_IMPORT_UNSUPPORTED_FEATURE"
    return ExternalFormatFeatureCoverageIR(
        feature_id=feature_id,
        feature=feature,
        support_level=support_level,
        reason_category=reason_category,
        action=action,
        source_path=source_path,
        native_path=native_path,
        diagnostic_code=diagnostic_code,
        message=message,
        metadata={
            "source_format": source_format,
            **({} if metadata is None else metadata),
        },
    )


def _mapping_coverage_status(
    *,
    adapter_required: bool,
    lossy_features: tuple[str, ...],
    unsupported_features: tuple[str, ...],
) -> Literal["ready", "lossy", "blocked", "adapter_required"]:
    if unsupported_features:
        return "blocked"
    if lossy_features:
        return "adapter_required" if adapter_required else "lossy"
    return "adapter_required" if adapter_required else "ready"


def _mapping_suggestion(feature: ExternalFormatFeatureCoverageIR) -> str:
    if feature.action == "block_import":
        return (
            "Block import until an adapter maps this feature without silent "
            "loss of units, bit order, measurement mapping, or source metadata."
        )
    if feature.action == "warn_and_review":
        return (
            "Review the adapter mapping and preserve source/native paths before "
            "validation, compilation, simulation, or execution."
        )
    if feature.action == "adapter_required":
        return "Use an explicit adapter before entering CASCAQit Native IR."
    return "Preserve mapping metadata for audit."


def _adapter_capability_manifest_status(
    coverage: ExternalFormatMappingCoverageIR,
) -> AdapterCapabilityManifestStatus:
    if coverage.unsupported_features:
        return "blocked"
    if coverage.adapter_required or coverage.lossy_features:
        return "adapter_required"
    return "ready"


def _adapter_bit_order_policy(source_format: ProgramFormat) -> dict[str, Any]:
    return {
        "policy": "explicit_required",
        "source_format": source_format,
        "native_bit_order_authoritative": True,
        "adapter_must_preserve_frontend_bit_order": True,
        "silent_reordering_allowed": False,
        "result_view_field": "ResultViewIR.bit_order",
    }


def _adapter_measurement_mapping_policy(
    source_format: ProgramFormat,
) -> dict[str, Any]:
    return {
        "policy": "explicit_required",
        "source_format": source_format,
        "native_measurement_mapping_authoritative": True,
        "adapter_must_preserve_external_register_names": True,
        "silent_measurement_merge_allowed": False,
        "result_view_field": "ResultViewIR.measurement_mapping",
    }


def _adapter_source_metadata_policy(source_format: ProgramFormat) -> dict[str, Any]:
    return {
        "policy": "preserve_required",
        "source_format": source_format,
        "required_fields": [
            "source_format",
            "source_digest",
            "source_id",
            "source_version",
            "frontend_name",
            "frontend_version",
            "preserve_metadata",
        ],
        "source_digest_algorithm": "sha256",
        "lossy_or_unsupported_fields_must_be_recorded": True,
    }


def _adapter_target_projection_policy(
    source_format: ProgramFormat,
    *,
    target_projection_required: bool | None = None,
) -> dict[str, Any]:
    required = (
        source_format != SUPPORTED_NATIVE_FORMAT
        if target_projection_required is None
        else target_projection_required
    )
    return {
        "policy": "reference_only",
        "source_format": source_format,
        "target_projection_required": required,
        "target_projection_authority": "TargetProjectionIR",
        "target_snapshot_hash_required": True,
        "calibration_refs_required": True,
        "adapter_hardware_facts_allowed": False,
        "embedded_target_hardware_facts_allowed": False,
    }


def _diagnostic(
    *,
    diagnostic_id: str,
    code: str,
    message: str,
    object_path: str,
    suggestion: str,
    severity: Literal["info", "warning", "error"] = "error",
    metadata: dict[str, Any] | None = None,
) -> DiagnosticsIR:
    return DiagnosticsIR(
        diagnostic_id=diagnostic_id,
        stage="serialization",
        severity=severity,
        code=code,
        message=message,
        object_path=object_path,
        suggestion=suggestion,
        metadata={} if metadata is None else metadata,
    )


def _fixture_payload(
    fixture: AdapterConformanceFixtureIR | dict[str, Any],
) -> dict[str, Any]:
    if isinstance(fixture, AdapterConformanceFixtureIR):
        return fixture.to_dict()
    if not isinstance(fixture, dict):
        raise TypeError(
            "adapter conformance harness fixtures must be fixture IR objects "
            "or dictionaries."
        )
    payload = canonicalize(fixture)
    if not isinstance(payload, dict):
        raise TypeError("adapter conformance fixture payload must be an object.")
    return payload


def _default_harness_compared_fields() -> tuple[str, ...]:
    return (
        "source_format",
        "source_digest",
        "source_metadata.source_format",
        "source_metadata.source_digest",
        "declared_mapping_coverage.status",
        "declared_mapping_coverage.lossy_features",
        "declared_mapping_coverage.unsupported_features",
        "target_projection_id",
        "expected_import_status",
        "expected_result_adapter_status",
        "import_source_map_summary_id",
    )


def _field_value(payload: dict[str, Any], field_path: str) -> Any:
    value: Any = payload
    for part in field_path.split("."):
        if not isinstance(value, dict) or part not in value:
            return None
        value = value[part]
    return value


def _fixture_side_effect_violations(payload: dict[str, Any]) -> tuple[str, ...]:
    violations = []
    expected = {
        "metadata_only": True,
        "parser_invoked": False,
        "external_object_constructed": False,
        "execution_package_created": False,
        "backend_called": False,
        "network_accessed": False,
        "cascaqit_compat_required": False,
    }
    for field_name, expected_value in expected.items():
        if payload.get(field_name) != expected_value:
            violations.append(field_name)
    return tuple(violations)


def _adapter_conformance_harness_diagnostics(
    *,
    submitted_payload: dict[str, Any],
    expected_payload: dict[str, Any],
    drift_fields: tuple[str, ...],
    side_effect_violations: tuple[str, ...],
) -> tuple[DiagnosticsIR, ...]:
    diagnostics: list[DiagnosticsIR] = []
    for field_name in drift_fields:
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"interop.adapter_harness.drift.{field_name}",
                code="ADAPTER_CONFORMANCE_FIXTURE_DRIFT",
                message=f"Submitted adapter fixture field {field_name!r} drifted.",
                object_path=field_name,
                suggestion=(
                    "Review submitted fixture metadata against the expected "
                    "golden policy before adapter execution."
                ),
                severity="error",
                metadata={
                    "taxonomy_stage": "interop",
                    "reason_category": "fixture_drift",
                    "action": "block_conformance",
                    "field": field_name,
                    "submitted_fixture_id": submitted_payload.get("fixture_id"),
                    "expected_fixture_id": expected_payload.get("fixture_id"),
                    "submitted_value": _field_value(submitted_payload, field_name),
                    "expected_value": _field_value(expected_payload, field_name),
                },
            )
        )
    for field_name in side_effect_violations:
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"interop.adapter_harness.side_effect.{field_name}",
                code="ADAPTER_CONFORMANCE_SIDE_EFFECT_VIOLATION",
                message=(
                    f"Submitted adapter fixture claims forbidden side effect "
                    f"{field_name!r}."
                ),
                object_path=field_name,
                suggestion=(
                    "Adapter conformance submissions must remain metadata-only "
                    "and cannot invoke parsers, construct external objects, "
                    "create packages, call backends, access networks, or "
                    "require cascaqit-compat."
                ),
                severity="error",
                metadata={
                    "taxonomy_stage": "interop",
                    "reason_category": "side_effect_violation",
                    "action": "block_conformance",
                    "field": field_name,
                    "submitted_fixture_id": submitted_payload.get("fixture_id"),
                    "submitted_value": submitted_payload.get(field_name),
                    "expected_value": field_name == "metadata_only",
                },
            )
        )
    return tuple(diagnostics)


def _mapping_coverage_comparison_summary(
    *,
    submitted_payload: dict[str, Any],
    expected_payload: dict[str, Any],
) -> dict[str, Any]:
    submitted = submitted_payload["declared_mapping_coverage"]
    expected = expected_payload["declared_mapping_coverage"]
    return {
        "submitted_coverage_id": submitted.get("coverage_id"),
        "expected_coverage_id": expected.get("coverage_id"),
        "submitted_status": submitted.get("status"),
        "expected_status": expected.get("status"),
        "submitted_lossy_features": submitted.get("lossy_features", []),
        "expected_lossy_features": expected.get("lossy_features", []),
        "submitted_unsupported_features": submitted.get(
            "unsupported_features",
            [],
        ),
        "expected_unsupported_features": expected.get(
            "unsupported_features",
            [],
        ),
        "lossy_features_match": submitted.get("lossy_features", [])
        == expected.get("lossy_features", []),
        "unsupported_features_match": submitted.get("unsupported_features", [])
        == expected.get("unsupported_features", []),
        "execution_package_created": submitted.get(
            "execution_package_created",
            False,
        ),
        "external_object_constructed": submitted.get(
            "external_object_constructed",
            False,
        ),
    }


def _source_metadata_ir(
    request: ProgramImportRequest,
    source_digest: str,
) -> ProgramSourceMetadataIR:
    return ProgramSourceMetadataIR(
        source_format=request.source_format,
        source_digest=source_digest,
        source_id=request.source_id,
        source_version=request.source_version,
        frontend_name=request.frontend_name,
        frontend_version=request.frontend_version,
        preserve_metadata=request.preserve_metadata,
        metadata={
            "request_metadata": dict(request.metadata),
            "source_digest_algorithm": "sha256",
        },
    )


def _declared_mapping_diagnostics(
    request: ProgramImportRequest,
) -> tuple[DiagnosticsIR, ...]:
    issues = (
        *request.declared_lossy_mappings,
        *request.declared_unsupported_features,
    )
    return tuple(
        issue.diagnostic(source_format=request.source_format) for issue in issues
    )


def _declared_lossy_mappings(request: ProgramImportRequest) -> tuple[str, ...]:
    return tuple(issue.feature for issue in request.declared_lossy_mappings)


def _declared_unsupported_features(request: ProgramImportRequest) -> tuple[str, ...]:
    return tuple(issue.feature for issue in request.declared_unsupported_features)


def _native_import_contract_metadata(
    request: ProgramImportRequest,
    source_metadata_ir: ProgramSourceMetadataIR,
) -> dict[str, Any]:
    readiness = build_program_import_readiness(request)
    return {
        "imported_via": "cascaqit.interop.import_program",
        "source_format": request.source_format,
        "source_digest": source_metadata_ir.source_digest,
        "frontend_name": request.frontend_name,
        "frontend_version": request.frontend_version,
        "lossy_mappings": _declared_lossy_mappings(request),
        "unsupported_features": _declared_unsupported_features(request),
        "native_ir_required": True,
        "backend_bypass_allowed": False,
        "interop_readiness": readiness.to_dict(),
    }


def _openqasm3_import_contract_metadata(
    request: ProgramImportRequest,
    source_metadata_ir: ProgramSourceMetadataIR,
    subset: OpenQASM3SubsetImportResultIR,
) -> dict[str, Any]:
    readiness = build_program_import_readiness(request)
    return {
        "imported_via": "cascaqit.interop.import_program",
        "source_format": request.source_format,
        "source_digest": source_metadata_ir.source_digest,
        "frontend_name": request.frontend_name,
        "frontend_version": request.frontend_version,
        "restricted_subset": True,
        "full_format_supported": False,
        "subset_importer": "cascaqit.interop.openqasm3_subset",
        "supported_subset": list(subset.supported_subset),
        "native_ir_required": True,
        "native_program_kind": "DigitalProgramIR",
        "backend_bypass_allowed": False,
        "execution_package_created": False,
        "backend_called": False,
        "network_accessed": False,
        "external_sdk_imported": False,
        "cascaqit_compat_required": False,
        "interop_readiness": readiness.to_dict(),
    }


def _import_result_metadata(
    request: ProgramImportRequest,
    source_metadata_ir: ProgramSourceMetadataIR,
    *,
    readiness: ProgramInteropReadinessIR,
    external_adapter_required: bool = False,
    blocked: bool = False,
) -> dict[str, Any]:
    return {
        "contract": "program_import_foundation",
        "source_format": request.source_format,
        "source_digest": source_metadata_ir.source_digest,
        "frontend_name": request.frontend_name,
        "frontend_version": request.frontend_version,
        "external_adapter_required": external_adapter_required,
        "blocked": blocked,
        "native_ir_required": True,
        "validation_required": True,
        "compiler_required": True,
        "execution_package_required": True,
        "backend_bypass_allowed": False,
        "lossy_mapping_policy": request.on_lossy,
        "unsupported_policy": request.on_unsupported,
        "interop_readiness": readiness.to_dict(),
    }


def _openqasm3_import_metadata(
    request: ProgramImportRequest,
    source_metadata_ir: ProgramSourceMetadataIR,
    readiness: ProgramInteropReadinessIR,
    *,
    program_available: bool,
    subset_summary: dict[str, Any],
) -> dict[str, Any]:
    metadata = _import_result_metadata(
        request,
        source_metadata_ir,
        readiness=readiness,
        external_adapter_required=False,
        blocked=not program_available,
    )
    metadata.update(
        {
            "restricted_subset": True,
            "full_format_supported": False,
            "internal_subset_importer": "cascaqit.interop.openqasm3_subset",
            "program_available": program_available,
            "native_program_kind": "DigitalProgramIR" if program_available else None,
            "execution_package_created": False,
            "backend_called": False,
            "network_accessed": False,
            "external_sdk_imported": False,
            "cascaqit_compat_required": False,
            "openqasm3_subset": subset_summary,
        }
    )
    return metadata


def _openqasm3_export_metadata(
    request: ProgramExportRequest,
    readiness: ProgramInteropReadinessIR,
    export_result: OpenQASM3ExportResultIR,
) -> dict[str, Any]:
    payload_available = export_result.payload_available
    interop_readiness = readiness.to_dict()
    if not payload_available:
        interop_readiness["status"] = "blocked"
        interop_readiness["payload_available"] = False
        interop_readiness["adapter_required"] = False
        interop_readiness["metadata"]["blocked_by_restricted_subset"] = True
        interop_readiness["metadata"]["unsupported_features"] = list(
            export_result.unsupported_features
        )
    return {
        "contract": "program_export_openqasm3_restricted_subset",
        "exported_via": "cascaqit.interop.export_program",
        "target_format": request.target_format,
        "source_program_id": request.program.program_id,
        "source_program_hash": request.program.stable_hash(),
        "payload_digest": export_result.payload_digest,
        "payload_digest_algorithm": "sha256" if payload_available else None,
        "payload_available": payload_available,
        "restricted_subset": True,
        "full_format_supported": False,
        "internal_subset_exporter": "cascaqit.interop.openqasm3_export",
        "native_program_kind": type(request.program).__name__,
        "export_contract": {
            "source_format": SUPPORTED_NATIVE_FORMAT,
            "target_format": request.target_format,
            "restricted_subset": True,
            "supported_gates": list(export_result.boundary.policy.supported_gates),
            "unsupported_scope": list(export_result.unsupported_features),
            "statement_count": len(export_result.statements),
            "lowered_gate_count": export_result.metadata.get("lowered_gate_count", 0),
        },
        "bit_order": export_result.bit_order,
        "measurement_mapping": export_result.measurement_mapping,
        "lowering_report": export_result.metadata.get("lowering_report", {}),
        "openqasm3_export": {
            "export_id": export_result.export_id,
            "boundary_id": export_result.boundary.boundary_id,
            "payload_digest": export_result.payload_digest,
            "payload_available": payload_available,
            "diagnostic_codes": [
                diagnostic.code for diagnostic in export_result.diagnostics
            ],
            "statement_refs": [
                {
                    "statement_id": statement.statement_id,
                    "kind": statement.kind,
                    "native_ref": statement.native_ref,
                    "source_text": statement.source_text,
                    "metadata": statement.metadata,
                }
                for statement in export_result.statements
            ],
        },
        "interop_readiness": interop_readiness,
        "validation_required": True,
        "compiler_required": False,
        "execution_package_required": False,
        "execution_package_created": False,
        "backend_called": False,
        "cloud_called": False,
        "network_accessed": False,
        "external_sdk_imported": False,
        "cascaqit_compat_required": False,
        "blocked": not payload_available,
    }


def _openqasm3_subset_summary(subset: OpenQASM3SubsetImportResultIR) -> dict[str, Any]:
    return {
        "source_format": subset.source_format,
        "statement_count": subset.metadata["statement_count"],
        "parsed_statement_count": subset.metadata["parsed_statement_count"],
        "gate_count": subset.metadata["gate_count"],
        "measurement_count": subset.metadata["measurement_count"],
        "qubit_count": subset.metadata["qubit_count"],
        "program_available": subset.program is not None,
        "diagnostic_codes": [diagnostic.code for diagnostic in subset.diagnostics],
        "supported_subset": list(subset.supported_subset),
    }


def _openqasm3_program_id(request: ProgramImportRequest) -> str:
    if request.source_id:
        normalized = re.sub(r"[^A-Za-z0-9_.-]+", "_", request.source_id)
        return f"program.openqasm3.{normalized}"
    return "program.openqasm3.imported"


def _source_digest(source: str | dict[str, Any]) -> str:
    payload = source if isinstance(source, str) else json.dumps(source, sort_keys=True)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()
