"""Restricted OpenQASM 3 export boundary and deterministic renderer."""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Literal

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.digital import DigitalProgramIR
from cascaqit.interop.ccx_policy import (
    CCX_BLOCKED_DIAGNOSTIC_CODE,
    CCX_BLOCKED_GATE,
    CCX_BLOCKED_MESSAGE,
    CCX_BLOCKED_METADATA,
    CCX_BLOCKED_SUGGESTION,
)
from cascaqit.native_ir.base import IRMixin, canonicalize
from cascaqit.native_ir.models import SCHEMA_VERSION

if TYPE_CHECKING:
    from cascaqit.native_ir.models import ProgramIR

__all__ = [
    "OpenQASM3ExportBoundaryIR",
    "OpenQASM3ExportPolicyIR",
    "OpenQASM3ExportResultIR",
    "OpenQASM3ExportStatementIR",
    "build_openqasm3_export_boundary",
    "default_openqasm3_export_policy",
    "render_openqasm3_subset",
]

StatementKind = Literal[
    "version",
    "include",
    "qubit_declaration",
    "bit_declaration",
    "gate",
    "measurement",
]

_SINGLE_QUBIT_GATES = frozenset({"i", "x", "y", "z", "h", "s", "sdg", "t", "tdg"})
_ROTATION_GATES = frozenset({"rx", "ry", "rz", "p"})
_U_GATES = frozenset({"u"})
_TWO_QUBIT_GATES = frozenset({"cx", "cy", "cz"})
_LOWERED_GATES = frozenset({"swap"})
_SUPPORTED_GATES = (
    _SINGLE_QUBIT_GATES
    | _ROTATION_GATES
    | _U_GATES
    | _TWO_QUBIT_GATES
    | _LOWERED_GATES
)
_U_PARAMETER_NAMES = ("theta", "phi", "lambda")


@dataclass(frozen=True)
class OpenQASM3ExportPolicyIR(IRMixin):
    """Policy for the restricted OpenQASM 3 export subset."""

    policy_id: str = "openqasm3_export_policy.restricted.v0_27"
    source_format: str = "cascaqit.native_digital"
    target_format: str = "openqasm3"
    qubit_register_name: str = "q"
    bit_register_name: str = "c"
    include_std_gates: bool = True
    supported_gates: tuple[str, ...] = tuple(sorted(_SUPPORTED_GATES))
    single_qubit_gates: tuple[str, ...] = tuple(sorted(_SINGLE_QUBIT_GATES))
    rotation_gates: tuple[str, ...] = tuple(sorted(_ROTATION_GATES))
    u_gates: tuple[str, ...] = tuple(sorted(_U_GATES))
    two_qubit_gates: tuple[str, ...] = tuple(sorted(_TWO_QUBIT_GATES))
    lowered_gates: tuple[str, ...] = tuple(sorted(_LOWERED_GATES))
    measurement_policy: str = "terminal_computational_basis_only"
    bit_order_policy: str = "qubit_order_maps_to_q_index"
    measurement_mapping_policy: str = "measurement_key_maps_to_c_index"
    payload_rendering_status: str = "planned"
    external_sdk_imported: bool = False
    cascaqit_compat_required: bool = False
    execution_package_created: bool = False
    backend_called: bool = False
    cloud_called: bool = False
    network_accessed: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize policy payload and enforce side-effect boundaries."""
        if self.external_sdk_imported:
            raise ValueError("OpenQASM 3 export must not import external SDKs.")
        if self.cascaqit_compat_required:
            raise ValueError("OpenQASM 3 export must not require compat.")
        if self.execution_package_created:
            raise ValueError("OpenQASM 3 export must not create packages.")
        if self.backend_called or self.cloud_called:
            raise ValueError("OpenQASM 3 export must not call backends or cloud.")
        if self.network_accessed:
            raise ValueError("OpenQASM 3 export cannot access networks.")
        object.__setattr__(
            self,
            "supported_gates",
            tuple(sorted(str(gate) for gate in self.supported_gates)),
        )
        object.__setattr__(
            self,
            "single_qubit_gates",
            tuple(sorted(str(gate) for gate in self.single_qubit_gates)),
        )
        object.__setattr__(
            self,
            "rotation_gates",
            tuple(sorted(str(gate) for gate in self.rotation_gates)),
        )
        object.__setattr__(
            self,
            "u_gates",
            tuple(sorted(str(gate) for gate in self.u_gates)),
        )
        object.__setattr__(
            self,
            "two_qubit_gates",
            tuple(sorted(str(gate) for gate in self.two_qubit_gates)),
        )
        object.__setattr__(
            self,
            "lowered_gates",
            tuple(sorted(str(gate) for gate in self.lowered_gates)),
        )
        object.__setattr__(self, "metadata", canonicalize(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> OpenQASM3ExportPolicyIR:
        """Build an export policy from a JSON-compatible dictionary."""
        return cls(
            policy_id=str(
                data.get("policy_id", "openqasm3_export_policy.restricted.v0_27")
            ),
            source_format=str(data.get("source_format", "cascaqit.native_digital")),
            target_format=str(data.get("target_format", "openqasm3")),
            qubit_register_name=str(data.get("qubit_register_name", "q")),
            bit_register_name=str(data.get("bit_register_name", "c")),
            include_std_gates=bool(data.get("include_std_gates", True)),
            supported_gates=tuple(str(item) for item in data["supported_gates"]),
            single_qubit_gates=tuple(
                str(item) for item in data.get("single_qubit_gates", ())
            ),
            rotation_gates=tuple(
                str(item) for item in data.get("rotation_gates", ())
            ),
            u_gates=tuple(str(item) for item in data.get("u_gates", ())),
            two_qubit_gates=tuple(
                str(item) for item in data.get("two_qubit_gates", ())
            ),
            lowered_gates=tuple(str(item) for item in data.get("lowered_gates", ())),
            measurement_policy=str(
                data.get("measurement_policy", "terminal_computational_basis_only")
            ),
            bit_order_policy=str(
                data.get("bit_order_policy", "qubit_order_maps_to_q_index")
            ),
            measurement_mapping_policy=str(
                data.get(
                    "measurement_mapping_policy",
                    "measurement_key_maps_to_c_index",
                )
            ),
            payload_rendering_status=str(
                data.get("payload_rendering_status", "planned")
            ),
            external_sdk_imported=bool(data.get("external_sdk_imported", False)),
            cascaqit_compat_required=bool(data.get("cascaqit_compat_required", False)),
            execution_package_created=bool(
                data.get("execution_package_created", False)
            ),
            backend_called=bool(data.get("backend_called", False)),
            cloud_called=bool(data.get("cloud_called", False)),
            network_accessed=bool(data.get("network_accessed", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )


@dataclass(frozen=True)
class OpenQASM3ExportStatementIR(IRMixin):
    """Planned OpenQASM statement mapped from a native digital object."""

    statement_id: str
    kind: StatementKind
    native_ref: str
    source_text: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = SCHEMA_VERSION

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> OpenQASM3ExportStatementIR:
        """Build an export statement from a JSON-compatible dictionary."""
        return cls(
            statement_id=str(data["statement_id"]),
            kind=data["kind"],
            native_ref=str(data["native_ref"]),
            source_text=data.get("source_text"),
            metadata=dict(data.get("metadata", {})),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
        )


@dataclass(frozen=True)
class OpenQASM3ExportBoundaryIR(IRMixin):
    """Boundary review result for restricted OpenQASM 3 export."""

    boundary_id: str
    program_id: str
    source_program_hash: str | None
    policy: OpenQASM3ExportPolicyIR
    statements: tuple[OpenQASM3ExportStatementIR, ...]
    diagnostics: tuple[DiagnosticsIR, ...]
    export_ready: bool
    payload_available: bool = False
    payload_rendering_status: str = "planned"
    bit_order: dict[str, Any] = field(default_factory=dict)
    measurement_mapping: dict[str, Any] = field(default_factory=dict)
    unsupported_features: tuple[str, ...] = ()
    external_sdk_imported: bool = False
    cascaqit_compat_required: bool = False
    execution_package_created: bool = False
    backend_called: bool = False
    cloud_called: bool = False
    network_accessed: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize the metadata-only export boundary."""
        if self.payload_available:
            raise ValueError("OpenQASM export boundary review has no payload.")
        if self.external_sdk_imported:
            raise ValueError("OpenQASM 3 export must not import external SDKs.")
        if self.cascaqit_compat_required:
            raise ValueError("OpenQASM 3 export must not require compat.")
        if self.execution_package_created:
            raise ValueError("OpenQASM 3 export must not create packages.")
        if self.backend_called or self.cloud_called:
            raise ValueError("OpenQASM 3 export must not call backends or cloud.")
        if self.network_accessed:
            raise ValueError("OpenQASM 3 export cannot access networks.")
        object.__setattr__(
            self,
            "policy",
            self.policy
            if isinstance(self.policy, OpenQASM3ExportPolicyIR)
            else OpenQASM3ExportPolicyIR.from_dict(self.policy),
        )
        object.__setattr__(
            self,
            "statements",
            tuple(
                item
                if isinstance(item, OpenQASM3ExportStatementIR)
                else OpenQASM3ExportStatementIR.from_dict(item)
                for item in self.statements
            ),
        )
        object.__setattr__(
            self,
            "diagnostics",
            tuple(
                item
                if isinstance(item, DiagnosticsIR)
                else DiagnosticsIR.from_dict(item)
                for item in self.diagnostics
            ),
        )
        object.__setattr__(self, "bit_order", canonicalize(self.bit_order))
        object.__setattr__(
            self,
            "measurement_mapping",
            canonicalize(self.measurement_mapping),
        )
        object.__setattr__(
            self,
            "unsupported_features",
            tuple(str(item) for item in self.unsupported_features),
        )
        object.__setattr__(self, "metadata", canonicalize(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> OpenQASM3ExportBoundaryIR:
        """Build an export boundary from a JSON-compatible dictionary."""
        return cls(
            boundary_id=str(data["boundary_id"]),
            program_id=str(data["program_id"]),
            source_program_hash=data.get("source_program_hash"),
            policy=OpenQASM3ExportPolicyIR.from_dict(data["policy"]),
            statements=tuple(
                OpenQASM3ExportStatementIR.from_dict(item)
                for item in data.get("statements", ())
            ),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(item)
                for item in data.get("diagnostics", ())
            ),
            export_ready=bool(data["export_ready"]),
            payload_available=bool(data.get("payload_available", False)),
            payload_rendering_status=str(
                data.get("payload_rendering_status", "planned")
            ),
            bit_order=dict(data.get("bit_order", {})),
            measurement_mapping=dict(data.get("measurement_mapping", {})),
            unsupported_features=tuple(
                str(item) for item in data.get("unsupported_features", ())
            ),
            external_sdk_imported=bool(data.get("external_sdk_imported", False)),
            cascaqit_compat_required=bool(data.get("cascaqit_compat_required", False)),
            execution_package_created=bool(
                data.get("execution_package_created", False)
            ),
            backend_called=bool(data.get("backend_called", False)),
            cloud_called=bool(data.get("cloud_called", False)),
            network_accessed=bool(data.get("network_accessed", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )


@dataclass(frozen=True)
class OpenQASM3ExportResultIR(IRMixin):
    """Result of rendering a restricted OpenQASM 3 source payload."""

    export_id: str
    program_id: str
    source_program_hash: str | None
    source: str | None
    payload_digest: str | None
    boundary: OpenQASM3ExportBoundaryIR
    statements: tuple[OpenQASM3ExportStatementIR, ...]
    diagnostics: tuple[DiagnosticsIR, ...]
    export_ready: bool
    payload_available: bool
    bit_order: dict[str, Any]
    measurement_mapping: dict[str, Any]
    unsupported_features: tuple[str, ...]
    external_sdk_imported: bool = False
    cascaqit_compat_required: bool = False
    execution_package_created: bool = False
    backend_called: bool = False
    cloud_called: bool = False
    network_accessed: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize result payload and enforce side-effect limits."""
        if self.payload_available and self.source is None:
            raise ValueError("OpenQASM 3 export payload requires source text.")
        if self.payload_available and self.payload_digest is None:
            raise ValueError("OpenQASM 3 export payload requires a digest.")
        if not self.payload_available and self.source is not None:
            raise ValueError("Unavailable OpenQASM 3 payload cannot include source.")
        if not self.payload_available and self.payload_digest is not None:
            raise ValueError("Unavailable OpenQASM 3 payload cannot include digest.")
        if self.external_sdk_imported:
            raise ValueError("OpenQASM 3 export must not import external SDKs.")
        if self.cascaqit_compat_required:
            raise ValueError("OpenQASM 3 export must not require compat.")
        if self.execution_package_created:
            raise ValueError("OpenQASM 3 export must not create packages.")
        if self.backend_called or self.cloud_called:
            raise ValueError("OpenQASM 3 export must not call backends or cloud.")
        if self.network_accessed:
            raise ValueError("OpenQASM 3 export cannot access networks.")
        object.__setattr__(
            self,
            "boundary",
            self.boundary
            if isinstance(self.boundary, OpenQASM3ExportBoundaryIR)
            else OpenQASM3ExportBoundaryIR.from_dict(self.boundary),
        )
        object.__setattr__(
            self,
            "statements",
            tuple(
                item
                if isinstance(item, OpenQASM3ExportStatementIR)
                else OpenQASM3ExportStatementIR.from_dict(item)
                for item in self.statements
            ),
        )
        object.__setattr__(
            self,
            "diagnostics",
            tuple(
                item
                if isinstance(item, DiagnosticsIR)
                else DiagnosticsIR.from_dict(item)
                for item in self.diagnostics
            ),
        )
        object.__setattr__(self, "bit_order", canonicalize(self.bit_order))
        object.__setattr__(
            self,
            "measurement_mapping",
            canonicalize(self.measurement_mapping),
        )
        object.__setattr__(
            self,
            "unsupported_features",
            tuple(str(item) for item in self.unsupported_features),
        )
        object.__setattr__(self, "metadata", canonicalize(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> OpenQASM3ExportResultIR:
        """Build an export result from a JSON-compatible dictionary."""
        return cls(
            export_id=str(data["export_id"]),
            program_id=str(data["program_id"]),
            source_program_hash=data.get("source_program_hash"),
            source=data.get("source"),
            payload_digest=data.get("payload_digest"),
            boundary=OpenQASM3ExportBoundaryIR.from_dict(data["boundary"]),
            statements=tuple(
                OpenQASM3ExportStatementIR.from_dict(item)
                for item in data.get("statements", ())
            ),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(item)
                for item in data.get("diagnostics", ())
            ),
            export_ready=bool(data["export_ready"]),
            payload_available=bool(data["payload_available"]),
            bit_order=dict(data.get("bit_order", {})),
            measurement_mapping=dict(data.get("measurement_mapping", {})),
            unsupported_features=tuple(
                str(item) for item in data.get("unsupported_features", ())
            ),
            external_sdk_imported=bool(data.get("external_sdk_imported", False)),
            cascaqit_compat_required=bool(data.get("cascaqit_compat_required", False)),
            execution_package_created=bool(
                data.get("execution_package_created", False)
            ),
            backend_called=bool(data.get("backend_called", False)),
            cloud_called=bool(data.get("cloud_called", False)),
            network_accessed=bool(data.get("network_accessed", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )


def default_openqasm3_export_policy() -> OpenQASM3ExportPolicyIR:
    """Return the restricted OpenQASM 3 export policy."""
    return OpenQASM3ExportPolicyIR(
        metadata={
            "phase": "217",
            "scope": "restricted_openqasm3_export_boundary",
            "full_openqasm3_supported": False,
            "payload_renderer_implemented": True,
            "u_cy_export_supported": True,
            "swap_lowering_supported": True,
        }
    )


def render_openqasm3_subset(
    program: ProgramIR | DigitalProgramIR,
    *,
    export_id: str | None = None,
    boundary_id: str | None = None,
    policy: OpenQASM3ExportPolicyIR | None = None,
) -> OpenQASM3ExportResultIR:
    """Render a supported DigitalProgramIR as deterministic OpenQASM 3 source."""
    boundary = build_openqasm3_export_boundary(
        program,
        boundary_id=boundary_id,
        policy=policy,
    )
    result_id = export_id or f"openqasm3_export.{boundary.program_id}"
    if not boundary.export_ready:
        return _render_result(
            export_id=result_id,
            boundary=boundary,
            source=None,
            payload_digest=None,
            statements=boundary.statements,
            diagnostics=boundary.diagnostics,
            bit_order=boundary.bit_order,
            measurement_mapping=boundary.measurement_mapping,
            metadata={
                "phase": "208",
                "renderer": "cascaqit.interop.openqasm3_export",
                "payload_rendered": False,
                "partial_payload_emitted": False,
                "blocked_by_boundary": True,
            },
        )
    if not isinstance(program, DigitalProgramIR):
        raise TypeError("OpenQASM 3 renderer requires DigitalProgramIR.")

    rendered_statements, measurement_mapping = _render_statements(program, boundary)
    lowering_report = _lowering_report(rendered_statements)
    source = "\n".join(
        statement.source_text or "" for statement in rendered_statements
    )
    source = f"{source}\n"
    payload_digest = hashlib.sha256(source.encode("utf-8")).hexdigest()
    diagnostics = (
        _diagnostic(
            code="OPENQASM_EXPORT_RENDERED",
            message="DigitalProgramIR was rendered as restricted OpenQASM 3 source.",
            severity="info",
            object_path="program",
            suggestion="Use Program Export for the public export workflow.",
            metadata={
                "reason_category": "rendered",
                "payload_digest": payload_digest,
                "statement_count": len(rendered_statements),
                "lowered_gate_count": lowering_report["lowered_gate_count"],
            },
        ),
    )
    return _render_result(
        export_id=result_id,
        boundary=boundary,
        source=source,
        payload_digest=payload_digest,
        statements=rendered_statements,
        diagnostics=diagnostics,
        bit_order=boundary.bit_order,
        measurement_mapping=measurement_mapping,
        metadata={
            "phase": "208",
            "renderer": "cascaqit.interop.openqasm3_export",
            "payload_rendered": True,
            "partial_payload_emitted": False,
            "line_count": len(rendered_statements),
            "statement_count": len(rendered_statements),
            "payload_digest": payload_digest,
            "lowering_report": lowering_report,
            "lowered_gate_count": lowering_report["lowered_gate_count"],
        },
    )


def build_openqasm3_export_boundary(
    program: ProgramIR | DigitalProgramIR,
    *,
    boundary_id: str | None = None,
    policy: OpenQASM3ExportPolicyIR | None = None,
) -> OpenQASM3ExportBoundaryIR:
    """Review whether a program is inside the restricted OpenQASM export subset."""
    export_policy = policy or default_openqasm3_export_policy()
    program_id = getattr(program, "program_id", "program.unknown")
    source_program_hash = (
        program.stable_hash() if isinstance(program, IRMixin) else None
    )
    boundary = boundary_id or f"openqasm3_export_boundary.{program_id}"

    if not isinstance(program, DigitalProgramIR):
        diagnostic = _diagnostic(
            code="OPENQASM_EXPORT_PROGRAM_TYPE_UNSUPPORTED",
            message="Restricted OpenQASM 3 export accepts DigitalProgramIR only.",
            object_path="program",
            suggestion=(
                "Convert or lower the program to DigitalProgramIR before export."
            ),
            metadata={
                "reason_category": "program_type",
                "program_type": getattr(
                    program,
                    "program_type",
                    type(program).__name__,
                ),
            },
        )
        return _boundary(
            boundary_id=boundary,
            program_id=program_id,
            source_program_hash=source_program_hash,
            policy=export_policy,
            statements=(),
            diagnostics=(diagnostic,),
            unsupported_features=("program_type",),
        )

    diagnostics: list[DiagnosticsIR] = []
    statements = list(_declaration_statements(program, export_policy))
    qubit_index = {qubit: index for index, qubit in enumerate(program.circuit.qubits)}

    for index, gate in enumerate(program.circuit.gates):
        statement_id = f"openqasm3.export.statement.gate.{index}"
        if gate.name not in export_policy.supported_gates:
            metadata = (
                {
                    **CCX_BLOCKED_METADATA,
                    "gate_id": gate.gate_id,
                }
                if gate.name == CCX_BLOCKED_GATE
                else {
                    "reason_category": "unsupported_gate",
                    "gate": gate.name,
                    "gate_id": gate.gate_id,
                }
            )
            diagnostics.append(
                _diagnostic(
                    code=(
                        CCX_BLOCKED_DIAGNOSTIC_CODE
                        if gate.name == CCX_BLOCKED_GATE
                        else "OPENQASM_EXPORT_GATE_UNSUPPORTED"
                    ),
                    message=(
                        CCX_BLOCKED_MESSAGE
                        if gate.name == CCX_BLOCKED_GATE
                        else (
                            f"Digital gate {gate.name!r} is outside the restricted "
                            "OpenQASM 3 export subset."
                        )
                    ),
                    object_path=f"program.circuit.gates[{index}]",
                    suggestion=(
                        CCX_BLOCKED_SUGGESTION
                        if gate.name == CCX_BLOCKED_GATE
                        else (
                            "Lower the gate to "
                            "i/x/y/z/h/s/sdg/t/tdg/rx/ry/rz/p/u/cx/cy/cz "
                            "or lowerable swap."
                        )
                    ),
                    metadata=metadata,
                )
            )
            continue
        missing_targets = tuple(
            target for target in gate.targets if target not in qubit_index
        )
        if missing_targets:
            diagnostics.append(
                _diagnostic(
                    code="OPENQASM_EXPORT_GATE_TARGET_UNKNOWN",
                    message=(
                        "Digital gate targets must reference declared circuit "
                        "qubits."
                    ),
                    object_path=f"program.circuit.gates[{index}].targets",
                    suggestion="Use targets from DigitalProgramIR.circuit.qubits.",
                    metadata={
                        "reason_category": "target_mapping",
                        "gate": gate.name,
                        "gate_id": gate.gate_id,
                        "missing_targets": list(missing_targets),
                    },
                )
            )
            continue
        expected_arity = _expected_gate_arity(gate.name, export_policy)
        if expected_arity is not None and len(gate.targets) != expected_arity:
            diagnostics.append(
                _diagnostic(
                    code="OPENQASM_EXPORT_GATE_ARITY_INVALID",
                    message=(
                        f"Digital gate {gate.name!r} requires {expected_arity} "
                        "target(s) for restricted OpenQASM 3 export."
                    ),
                    object_path=f"program.circuit.gates[{index}].targets",
                    suggestion="Use the canonical GateIR constructor for this gate.",
                    metadata={
                        "reason_category": "arity_mapping",
                        "gate": gate.name,
                        "gate_id": gate.gate_id,
                        "expected": expected_arity,
                        "actual": len(gate.targets),
                    },
                )
            )
            continue
        if gate.name in export_policy.rotation_gates and "theta" not in gate.parameters:
            diagnostics.append(
                _diagnostic(
                    code="OPENQASM_EXPORT_GATE_PARAMETER_MISSING",
                    message="Rotation gates require a numeric theta parameter.",
                    object_path=f"program.circuit.gates[{index}].parameters",
                    suggestion="Provide gate.parameters['theta'] before export.",
                    metadata={
                        "reason_category": "parameter_mapping",
                        "gate": gate.name,
                        "gate_id": gate.gate_id,
                    },
                )
            )
            continue
        if gate.name in export_policy.u_gates:
            missing_parameters = tuple(
                parameter
                for parameter in _U_PARAMETER_NAMES
                if parameter not in gate.parameters
            )
            if missing_parameters:
                diagnostics.append(
                    _diagnostic(
                        code="OPENQASM_EXPORT_GATE_PARAMETER_MISSING",
                        message=(
                            "U gates require numeric theta, phi, and lambda "
                            "parameters."
                        ),
                        object_path=f"program.circuit.gates[{index}].parameters",
                        suggestion=(
                            "Provide gate.parameters['theta'], "
                            "gate.parameters['phi'], and "
                            "gate.parameters['lambda'] before export."
                        ),
                        metadata={
                            "reason_category": "parameter_mapping",
                            "gate": gate.name,
                            "gate_id": gate.gate_id,
                            "missing_parameters": list(missing_parameters),
                        },
                    )
                )
                continue
        statements.append(
            OpenQASM3ExportStatementIR(
                statement_id=statement_id,
                kind="gate",
                native_ref=f"program.circuit.gates[{index}]",
                metadata={
                    "gate_id": gate.gate_id,
                    "gate": gate.name,
                    "target_indices": [qubit_index[target] for target in gate.targets],
                    "parameter_names": sorted(gate.parameters),
                    "lowering_strategy": (
                        "swap_to_three_cx"
                        if gate.name in export_policy.lowered_gates
                        else None
                    ),
                },
            )
        )

    for index, measurement in enumerate(program.circuit.measurements):
        statement_id = f"openqasm3.export.statement.measurement.{index}"
        if measurement.basis not in {"computational", "z"}:
            diagnostics.append(
                _diagnostic(
                    code="OPENQASM_EXPORT_MEASUREMENT_BASIS_UNSUPPORTED",
                    message=(
                        "Restricted OpenQASM 3 export supports terminal Z-basis "
                        "measurements only."
                    ),
                    object_path=f"program.circuit.measurements[{index}].basis",
                    suggestion="Use computational or z measurement basis.",
                    metadata={
                        "reason_category": "measurement_semantics",
                        "measurement_id": measurement.measurement_id,
                        "basis": measurement.basis,
                    },
                )
            )
            continue
        missing_targets = tuple(
            target for target in measurement.targets if target not in qubit_index
        )
        if missing_targets:
            diagnostics.append(
                _diagnostic(
                    code="OPENQASM_EXPORT_MEASUREMENT_TARGET_UNKNOWN",
                    message=(
                        "Measurement targets must reference declared circuit "
                        "qubits."
                    ),
                    object_path=f"program.circuit.measurements[{index}].targets",
                    suggestion="Use targets from DigitalProgramIR.circuit.qubits.",
                    metadata={
                        "reason_category": "measurement_mapping",
                        "measurement_id": measurement.measurement_id,
                        "missing_targets": list(missing_targets),
                    },
                )
            )
            continue
        statements.append(
            OpenQASM3ExportStatementIR(
                statement_id=statement_id,
                kind="measurement",
                native_ref=f"program.circuit.measurements[{index}]",
                metadata={
                    "measurement_id": measurement.measurement_id,
                    "key": measurement.key,
                    "target_indices": [
                        qubit_index[target] for target in measurement.targets
                    ],
                    "classical_indices": list(
                        range(index, index + len(measurement.targets))
                    ),
                },
            )
        )

    unsupported_features = tuple(
        sorted(
            {
                str(diagnostic.metadata.get("reason_category", diagnostic.code))
                for diagnostic in diagnostics
                if diagnostic.severity == "error"
            }
        )
    )
    return _boundary(
        boundary_id=boundary,
        program_id=program.program_id,
        source_program_hash=program.stable_hash(),
        policy=export_policy,
        statements=tuple(statements),
        diagnostics=tuple(diagnostics)
        if diagnostics
        else (
            _diagnostic(
                code="OPENQASM_EXPORT_BOUNDARY_READY",
                message=(
                    "DigitalProgramIR is inside the restricted OpenQASM 3 "
                    "export subset."
                ),
                severity="info",
                object_path="program",
                suggestion=(
                    "Render deterministic OpenQASM 3 source for the restricted "
                    "subset."
                ),
                metadata={"reason_category": "ready"},
            ),
        ),
        unsupported_features=unsupported_features,
        bit_order={
            "qubit_order": list(program.circuit.qubits),
            "bit_ordering": "q[0] is the first exported qubit",
            "register": export_policy.qubit_register_name,
        },
        measurement_mapping={
            "measurement_count": len(program.circuit.measurements),
            "measurement_keys": [
                measurement.key for measurement in program.circuit.measurements
            ],
            "register": export_policy.bit_register_name,
        },
    )


def _declaration_statements(
    program: DigitalProgramIR,
    policy: OpenQASM3ExportPolicyIR,
) -> tuple[OpenQASM3ExportStatementIR, ...]:
    statements = [
        OpenQASM3ExportStatementIR(
            statement_id="openqasm3.export.statement.version",
            kind="version",
            native_ref="program",
            metadata={"version": "3"},
        )
    ]
    if policy.include_std_gates:
        statements.append(
            OpenQASM3ExportStatementIR(
                statement_id="openqasm3.export.statement.include",
                kind="include",
                native_ref="program",
                metadata={"include": "stdgates.inc"},
            )
        )
    statements.extend(
        (
            OpenQASM3ExportStatementIR(
                statement_id="openqasm3.export.statement.qubits",
                kind="qubit_declaration",
                native_ref="program.circuit.qubits",
                metadata={
                    "register": policy.qubit_register_name,
                    "size": len(program.circuit.qubits),
                    "qubit_order": list(program.circuit.qubits),
                },
            ),
            OpenQASM3ExportStatementIR(
                statement_id="openqasm3.export.statement.bits",
                kind="bit_declaration",
                native_ref="program.circuit.measurements",
                metadata={
                    "register": policy.bit_register_name,
                    "size": sum(
                        len(measurement.targets)
                        for measurement in program.circuit.measurements
                    ),
                    "measurement_keys": [
                        measurement.key for measurement in program.circuit.measurements
                    ],
                },
            ),
        )
    )
    return tuple(statements)


def _render_statements(
    program: DigitalProgramIR,
    boundary: OpenQASM3ExportBoundaryIR,
) -> tuple[tuple[OpenQASM3ExportStatementIR, ...], dict[str, Any]]:
    policy = boundary.policy
    qubit_index = {qubit: index for index, qubit in enumerate(program.circuit.qubits)}
    rendered: list[OpenQASM3ExportStatementIR] = []
    bit_cursor = 0
    measurement_entries: list[dict[str, Any]] = []

    for statement in boundary.statements:
        if statement.kind == "version":
            rendered.append(_with_source(statement, "OPENQASM 3;"))
        elif statement.kind == "include":
            rendered.append(_with_source(statement, 'include "stdgates.inc";'))
        elif statement.kind == "qubit_declaration":
            size = len(program.circuit.qubits)
            rendered.append(
                _with_source(
                    statement,
                    f"qubit[{size}] {policy.qubit_register_name};",
                )
            )
        elif statement.kind == "bit_declaration":
            bit_count = sum(
                len(measurement.targets)
                for measurement in program.circuit.measurements
            )
            rendered.append(
                _with_source(
                    statement,
                    f"bit[{bit_count}] {policy.bit_register_name};",
                )
            )
        elif statement.kind == "gate":
            gate_index = _native_index(statement.native_ref)
            gate = program.circuit.gates[gate_index]
            source_text, metadata = _render_gate(gate, qubit_index, policy)
            rendered.append(_with_source(statement, source_text, metadata=metadata))
        elif statement.kind == "measurement":
            measurement_index = _native_index(statement.native_ref)
            measurement = program.circuit.measurements[measurement_index]
            source_lines: list[str] = []
            classical_indices: list[int] = []
            for target in measurement.targets:
                qubit = qubit_index[target]
                classical = bit_cursor
                bit_cursor += 1
                classical_indices.append(classical)
                source_lines.append(
                    "measure "
                    f"{policy.qubit_register_name}[{qubit}] -> "
                    f"{policy.bit_register_name}[{classical}];"
                )
                measurement_entries.append(
                    {
                        "measurement_id": measurement.measurement_id,
                        "key": measurement.key,
                        "target": target,
                        "target_index": qubit,
                        "classical_index": classical,
                    }
                )
            metadata = dict(statement.metadata)
            metadata["classical_indices"] = classical_indices
            rendered.append(
                OpenQASM3ExportStatementIR(
                    statement_id=statement.statement_id,
                    kind=statement.kind,
                    native_ref=statement.native_ref,
                    source_text="\n".join(source_lines),
                    metadata=metadata,
                    schema_version=statement.schema_version,
                )
            )
    measurement_mapping = {
        "measurement_count": len(program.circuit.measurements),
        "measurement_keys": [
            measurement.key for measurement in program.circuit.measurements
        ],
        "bit_count": bit_cursor,
        "register": policy.bit_register_name,
        "mapping_policy": "targets_are_assigned_consecutive_c_indices",
        "entries": measurement_entries,
    }
    return tuple(rendered), measurement_mapping


def _render_gate(
    gate: Any,
    qubit_index: dict[str, int],
    policy: OpenQASM3ExportPolicyIR,
) -> tuple[str, dict[str, Any]]:
    target_refs = ", ".join(
        f"{policy.qubit_register_name}[{qubit_index[target]}]"
        for target in gate.targets
    )
    if gate.name in policy.rotation_gates:
        theta = _format_parameter(gate.parameters["theta"])
        return f"{gate.name}({theta}) {target_refs};", {}
    if gate.name in policy.u_gates:
        theta = _format_parameter(gate.parameters["theta"])
        phi = _format_parameter(gate.parameters["phi"])
        lam = _format_parameter(gate.parameters["lambda"])
        return f"{gate.name}({theta}, {phi}, {lam}) {target_refs};", {}
    if gate.name == "swap":
        left, right = gate.targets
        left_ref = f"{policy.qubit_register_name}[{qubit_index[left]}]"
        right_ref = f"{policy.qubit_register_name}[{qubit_index[right]}]"
        generated = (
            f"cx {left_ref}, {right_ref};",
            f"cx {right_ref}, {left_ref};",
            f"cx {left_ref}, {right_ref};",
        )
        return (
            "\n".join(generated),
            {
                "lowered": True,
                "lowering_strategy": "swap_to_three_cx",
                "generated_statement_count": len(generated),
                "generated_gates": [
                    {"name": "cx", "targets": [left, right]},
                    {"name": "cx", "targets": [right, left]},
                    {"name": "cx", "targets": [left, right]},
                ],
                "equivalence_boundary": "unitary_equivalent_static_digital_gate",
            },
        )
    return f"{gate.name} {target_refs};", {}


def _lowering_report(
    statements: tuple[OpenQASM3ExportStatementIR, ...],
) -> dict[str, Any]:
    entries = [
        {
            "statement_id": statement.statement_id,
            "native_ref": statement.native_ref,
            "source_gate_id": statement.metadata.get("gate_id"),
            "source_gate": statement.metadata.get("gate"),
            "lowering_strategy": statement.metadata.get("lowering_strategy"),
            "generated_statement_count": statement.metadata.get(
                "generated_statement_count"
            ),
            "generated_gates": statement.metadata.get("generated_gates", ()),
            "equivalence_boundary": statement.metadata.get("equivalence_boundary"),
        }
        for statement in statements
        if statement.kind == "gate" and bool(statement.metadata.get("lowered"))
    ]
    return {
        "lowered_gate_count": len(entries),
        "entries": entries,
        "source_map_policy": "lowered_gate_maps_to_generated_statement_group",
        "bit_order_mutated": False,
        "measurement_mapping_mutated": False,
    }


def _format_parameter(value: float) -> str:
    return format(float(value), ".17g")


def _expected_gate_arity(
    gate_name: str,
    policy: OpenQASM3ExportPolicyIR,
) -> int | None:
    if (
        gate_name in policy.single_qubit_gates
        or gate_name in policy.rotation_gates
        or gate_name in policy.u_gates
    ):
        return 1
    if gate_name in policy.two_qubit_gates or gate_name in policy.lowered_gates:
        return 2
    return None


def _native_index(native_ref: str) -> int:
    return int(native_ref.rsplit("[", 1)[1].rstrip("]"))


def _with_source(
    statement: OpenQASM3ExportStatementIR,
    source_text: str,
    *,
    metadata: dict[str, Any] | None = None,
) -> OpenQASM3ExportStatementIR:
    statement_metadata = dict(statement.metadata)
    if metadata:
        statement_metadata.update(metadata)
    return OpenQASM3ExportStatementIR(
        statement_id=statement.statement_id,
        kind=statement.kind,
        native_ref=statement.native_ref,
        source_text=source_text,
        metadata=statement_metadata,
        schema_version=statement.schema_version,
    )


def _boundary(
    *,
    boundary_id: str,
    program_id: str,
    source_program_hash: str | None,
    policy: OpenQASM3ExportPolicyIR,
    statements: tuple[OpenQASM3ExportStatementIR, ...],
    diagnostics: tuple[DiagnosticsIR, ...],
    unsupported_features: tuple[str, ...],
    bit_order: dict[str, Any] | None = None,
    measurement_mapping: dict[str, Any] | None = None,
) -> OpenQASM3ExportBoundaryIR:
    has_errors = any(diagnostic.severity == "error" for diagnostic in diagnostics)
    return OpenQASM3ExportBoundaryIR(
        boundary_id=boundary_id,
        program_id=program_id,
        source_program_hash=source_program_hash,
        policy=policy,
        statements=statements,
        diagnostics=diagnostics,
        export_ready=not has_errors,
        payload_available=False,
        payload_rendering_status="planned",
        bit_order={} if bit_order is None else bit_order,
        measurement_mapping=(
            {} if measurement_mapping is None else measurement_mapping
        ),
        unsupported_features=unsupported_features,
        metadata={
            "phase": "217",
            "restricted_subset": True,
            "full_openqasm3_supported": False,
            "payload_renderer_implemented": True,
            "u_cy_export_supported": True,
            "swap_lowering_supported": True,
            "statement_count": len(statements),
        },
    )


def _render_result(
    *,
    export_id: str,
    boundary: OpenQASM3ExportBoundaryIR,
    source: str | None,
    payload_digest: str | None,
    statements: tuple[OpenQASM3ExportStatementIR, ...],
    diagnostics: tuple[DiagnosticsIR, ...],
    bit_order: dict[str, Any],
    measurement_mapping: dict[str, Any],
    metadata: dict[str, Any],
) -> OpenQASM3ExportResultIR:
    payload_available = source is not None
    return OpenQASM3ExportResultIR(
        export_id=export_id,
        program_id=boundary.program_id,
        source_program_hash=boundary.source_program_hash,
        source=source,
        payload_digest=payload_digest,
        boundary=boundary,
        statements=statements,
        diagnostics=diagnostics,
        export_ready=boundary.export_ready,
        payload_available=payload_available,
        bit_order=bit_order,
        measurement_mapping=measurement_mapping,
        unsupported_features=boundary.unsupported_features,
        metadata=metadata,
    )


def _diagnostic(
    *,
    code: str,
    message: str,
    object_path: str,
    suggestion: str,
    metadata: dict[str, Any],
    severity: Literal["info", "warning", "error"] = "error",
) -> DiagnosticsIR:
    diagnostic_metadata = {
        "source_format": "cascaqit.native_digital",
        "target_format": "openqasm3",
        "restricted_subset": True,
        "phase": "217",
        "taxonomy_stage": "interop",
        "actionable": True,
        "action": _openqasm3_export_action(code),
    }
    diagnostic_metadata.update(metadata)
    return DiagnosticsIR(
        diagnostic_id=f"openqasm3.export.{code.lower()}",
        stage="serialization",
        severity=severity,
        code=code,
        message=message,
        object_path=object_path,
        suggestion=suggestion,
        metadata=diagnostic_metadata,
    )


def _openqasm3_export_action(code: str) -> str:
    if "MEASUREMENT" in code:
        return "fix_openqasm_measurement_mapping"
    if "TARGET" in code:
        return "fix_openqasm_target_mapping"
    if "PARAMETER" in code:
        return "fix_openqasm_gate_parameters"
    if "GATE" in code:
        return "use_supported_openqasm_gate_subset"
    if "PROGRAM_TYPE" in code:
        return "use_supported_openqasm_program_type"
    return "inspect_openqasm_export_boundary"
