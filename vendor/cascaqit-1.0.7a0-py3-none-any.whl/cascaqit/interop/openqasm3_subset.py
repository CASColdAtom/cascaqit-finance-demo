"""Restricted OpenQASM 3 static-circuit subset importer.

The importer builds native DigitalProgramIR objects only. It does not call
backends, create execution packages, import external SDKs, or depend on
cascaqit-compat.
"""

from __future__ import annotations

import hashlib
import math
import re
from dataclasses import dataclass, field
from typing import Any, Literal

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.digital import DigitalMeasurementIR, DigitalProgramIR, GateIR
from cascaqit.digital.models import build_digital_program
from cascaqit.interop.ccx_policy import (
    CCX_BLOCKED_DIAGNOSTIC_CODE,
    CCX_BLOCKED_GATE,
    CCX_BLOCKED_MESSAGE,
    CCX_BLOCKED_METADATA,
    CCX_BLOCKED_SUGGESTION,
)
from cascaqit.native_ir.base import IRMixin, canonicalize
from cascaqit.native_ir.models import SCHEMA_VERSION

__all__ = [
    "OpenQASM3SubsetImportResultIR",
    "OpenQASM3SubsetParseError",
    "OpenQASM3SubsetStatementIR",
    "parse_openqasm3_subset",
]

StatementKind = Literal[
    "version",
    "include",
    "qubit_declaration",
    "bit_declaration",
    "gate",
    "measurement",
]

_HEADER_RE = re.compile(r"^OPENQASM\s+3(?:\.0)?$", re.IGNORECASE)
_INCLUDE_RE = re.compile(r'^include\s+"stdgates\.inc"$', re.IGNORECASE)
_REGISTER_RE = re.compile(r"^(qubit|bit)\[(\d+)\]\s+([A-Za-z_]\w*)$")
_MEASURE_RE = re.compile(
    r"^measure\s+([A-Za-z_]\w*)\[(\d+)\]\s*->\s*([A-Za-z_]\w*)\[(\d+)\]$",
    re.IGNORECASE,
)
_GATE_RE = re.compile(
    r"^([A-Za-z_]\w*)(?:\(([^()]*)\))?\s+(.+)$",
    re.IGNORECASE,
)
_QUBIT_REF_RE = re.compile(r"^([A-Za-z_]\w*)\[(\d+)\]$")
_ASSIGNMENT_RE = re.compile(r"^[A-Za-z_]\w*\[\d+\]\s*=.+$")
_LEGACY_REGISTER_RE = re.compile(r"^(qreg|creg)\b", re.IGNORECASE)
_SINGLE_QUBIT_GATES = frozenset({"i", "x", "y", "z", "h", "s", "sdg", "t", "tdg"})
_ROTATION_GATES = frozenset({"rx", "ry", "rz", "p"})
_U_GATES = frozenset({"u"})
_TWO_QUBIT_GATES = frozenset({"cx", "cy", "cz"})
_UNSUPPORTED_FEATURE_KEYWORDS: dict[str, tuple[str, str, str]] = {
    "if": (
        "OPENQASM_DYNAMIC_CONTROL_UNSUPPORTED",
        "dynamic_control",
        "Remove classical control or lower it in an external adapter.",
    ),
    "while": (
        "OPENQASM_DYNAMIC_CONTROL_UNSUPPORTED",
        "dynamic_control",
        "Remove runtime loops or lower them in an external adapter.",
    ),
    "for": (
        "OPENQASM_DYNAMIC_CONTROL_UNSUPPORTED",
        "dynamic_control",
        "Unroll loops before using this restricted importer.",
    ),
    "switch": (
        "OPENQASM_DYNAMIC_CONTROL_UNSUPPORTED",
        "dynamic_control",
        "Remove classical switch control or lower it in an external adapter.",
    ),
    "defcal": (
        "OPENQASM_DEFCAL_UNSUPPORTED",
        "timing_semantics",
        "Defcal and pulse calibration require a future timing-aware adapter.",
    ),
    "cal": (
        "OPENQASM_DEFCAL_UNSUPPORTED",
        "timing_semantics",
        "Calibration blocks require a future timing-aware adapter.",
    ),
    "delay": (
        "OPENQASM_TIMING_UNSUPPORTED",
        "timing_semantics",
        "Delay statements are outside this static gate subset.",
    ),
    "box": (
        "OPENQASM_TIMING_UNSUPPORTED",
        "timing_semantics",
        "Timing boxes are outside this static gate subset.",
    ),
    "barrier": (
        "OPENQASM_TIMING_UNSUPPORTED",
        "timing_semantics",
        "Barrier timing semantics are outside this static gate subset.",
    ),
    "reset": (
        "OPENQASM_RESET_UNSUPPORTED",
        "measurement_semantics",
        "Reset is not supported by this terminal-measurement subset.",
    ),
    "gate": (
        "OPENQASM_CUSTOM_GATE_UNSUPPORTED",
        "requires_adapter",
        "Inline or lower custom gates before importing.",
    ),
}


class OpenQASM3SubsetParseError(ValueError):
    """Raised when a restricted OpenQASM 3 source cannot be imported."""


class _OpenQASMParameterError(ValueError):
    """Internal structured parameter parse error."""

    def __init__(
        self,
        message: str,
        *,
        reason_category: str,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        self.reason_category = reason_category
        self.metadata = {} if metadata is None else dict(metadata)


@dataclass(frozen=True)
class OpenQASM3SubsetStatementIR(IRMixin):
    """Source statement parsed from the restricted OpenQASM 3 subset."""

    statement_id: str
    kind: StatementKind
    source_line: int
    source_text: str
    native_ref: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = SCHEMA_VERSION

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> OpenQASM3SubsetStatementIR:
        """Build a parsed statement from a JSON-compatible dictionary."""
        return cls(
            statement_id=str(data["statement_id"]),
            kind=data["kind"],
            source_line=int(data["source_line"]),
            source_text=str(data["source_text"]),
            native_ref=data.get("native_ref"),
            metadata=dict(data.get("metadata", {})),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
        )


@dataclass(frozen=True)
class OpenQASM3SubsetImportResultIR(IRMixin):
    """Result of parsing the restricted OpenQASM 3 subset."""

    source_format: str
    source_digest: str
    program: DigitalProgramIR | None
    diagnostics: tuple[DiagnosticsIR, ...]
    statements: tuple[OpenQASM3SubsetStatementIR, ...]
    bit_order: dict[str, Any]
    measurement_mapping: dict[str, Any]
    supported_subset: tuple[str, ...]
    external_sdk_imported: bool = False
    cascaqit_compat_required: bool = False
    execution_package_created: bool = False
    backend_called: bool = False
    network_accessed: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize result payload and enforce import boundaries."""
        if self.external_sdk_imported:
            raise ValueError("OpenQASM 3 subset import must not import external SDKs.")
        if self.cascaqit_compat_required:
            raise ValueError("OpenQASM 3 subset import must not require compat.")
        if self.execution_package_created:
            raise ValueError("OpenQASM 3 subset import must not create packages.")
        if self.backend_called:
            raise ValueError("OpenQASM 3 subset import must not call backends.")
        if self.network_accessed:
            raise ValueError("OpenQASM 3 subset import cannot access networks.")
        object.__setattr__(
            self,
            "diagnostics",
            tuple(
                item
                if isinstance(item, DiagnosticsIR)
                else DiagnosticsIR.from_dict(item)
                for item in self.diagnostics
            ),
        )
        object.__setattr__(
            self,
            "statements",
            tuple(
                item
                if isinstance(item, OpenQASM3SubsetStatementIR)
                else OpenQASM3SubsetStatementIR.from_dict(item)
                for item in self.statements
            ),
        )
        object.__setattr__(self, "bit_order", canonicalize(self.bit_order))
        object.__setattr__(
            self,
            "measurement_mapping",
            canonicalize(self.measurement_mapping),
        )
        object.__setattr__(
            self,
            "supported_subset",
            tuple(str(item) for item in self.supported_subset),
        )
        object.__setattr__(self, "metadata", canonicalize(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> OpenQASM3SubsetImportResultIR:
        """Build an import result from a JSON-compatible dictionary."""
        program_data = data.get("program")
        return cls(
            source_format=str(data.get("source_format", "openqasm3")),
            source_digest=str(data["source_digest"]),
            program=(
                None
                if program_data is None
                else DigitalProgramIR.from_dict(program_data)
            ),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(item)
                for item in data.get("diagnostics", ())
            ),
            statements=tuple(
                OpenQASM3SubsetStatementIR.from_dict(item)
                for item in data.get("statements", ())
            ),
            bit_order=dict(data.get("bit_order", {})),
            measurement_mapping=dict(data.get("measurement_mapping", {})),
            supported_subset=tuple(
                str(item) for item in data.get("supported_subset", ())
            ),
            external_sdk_imported=bool(data.get("external_sdk_imported", False)),
            cascaqit_compat_required=bool(data.get("cascaqit_compat_required", False)),
            execution_package_created=bool(
                data.get("execution_package_created", False)
            ),
            backend_called=bool(data.get("backend_called", False)),
            network_accessed=bool(data.get("network_accessed", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )


def parse_openqasm3_subset(
    source: str,
    *,
    program_id: str = "program.openqasm3_subset",
    source_id: str | None = None,
) -> OpenQASM3SubsetImportResultIR:
    """Parse a restricted OpenQASM 3 static circuit into DigitalProgramIR."""
    source_digest = hashlib.sha256(source.encode("utf-8")).hexdigest()
    statements = _split_statements(source)
    parsed_statements: list[OpenQASM3SubsetStatementIR] = []
    diagnostics: list[DiagnosticsIR] = []
    gates: list[GateIR] = []
    measurements: list[DigitalMeasurementIR] = []
    qubits: tuple[str, ...] = ()
    bit_count: int | None = None
    qubit_register: str | None = None
    bit_register: str | None = None
    seen_header = False
    measurement_seen = False

    for index, (line, text) in enumerate(statements):
        statement_id = f"openqasm3.statement.{index}"
        preclassified = _preclassify_statement(index=index, line=line, statement=text)
        if preclassified is not None:
            diagnostics.append(preclassified)
            continue
        if _HEADER_RE.fullmatch(text):
            seen_header = True
            parsed_statements.append(
                _statement(statement_id, "version", line, text)
            )
            continue
        if _INCLUDE_RE.fullmatch(text):
            parsed_statements.append(
                _statement(
                    statement_id,
                    "include",
                    line,
                    text,
                    metadata={"include": "stdgates.inc", "semantic_effect": "none"},
                )
            )
            continue
        register_match = _REGISTER_RE.fullmatch(text)
        if register_match is not None:
            kind, size_text, name = register_match.groups()
            size = int(size_text)
            if size <= 0:
                diagnostics.append(
                    _diagnostic(
                        code="OPENQASM_REGISTER_SIZE_INVALID",
                        message="OpenQASM registers must have positive size.",
                        line=line,
                        statement=text,
                        object_path=f"source.statements[{index}]",
                    )
                )
                continue
            if kind == "qubit":
                if qubit_register is not None:
                    diagnostics.append(
                        _diagnostic(
                            code="OPENQASM_MULTIPLE_QUBIT_REGISTERS_UNSUPPORTED",
                            message="Only one qubit register is supported.",
                            line=line,
                            statement=text,
                            object_path=f"source.statements[{index}]",
                        )
                    )
                    continue
                qubit_register = name
                qubits = tuple(f"{name}{qubit_index}" for qubit_index in range(size))
                parsed_statements.append(
                    _statement(
                        statement_id,
                        "qubit_declaration",
                        line,
                        text,
                        metadata={"register": name, "size": size},
                    )
                )
            else:
                if bit_register is not None:
                    diagnostics.append(
                        _diagnostic(
                            code="OPENQASM_MULTIPLE_BIT_REGISTERS_UNSUPPORTED",
                            message="Only one bit register is supported.",
                            line=line,
                            statement=text,
                            object_path=f"source.statements[{index}]",
                        )
                    )
                    continue
                bit_register = name
                bit_count = size
                parsed_statements.append(
                    _statement(
                        statement_id,
                        "bit_declaration",
                        line,
                        text,
                        metadata={"register": name, "size": size},
                    )
                )
            continue
        measure_match = _MEASURE_RE.fullmatch(text)
        if measure_match is not None:
            measurement = _parse_measurement(
                measure_match,
                index=index,
                line=line,
                statement=text,
                qubit_register=qubit_register,
                qubit_count=len(qubits),
                bit_register=bit_register,
                bit_count=bit_count,
            )
            if isinstance(measurement, DiagnosticsIR):
                diagnostics.append(measurement)
            else:
                measurement_seen = True
                measurements.append(measurement)
                parsed_statements.append(
                    _statement(
                        statement_id,
                        "measurement",
                        line,
                        text,
                        native_ref=f"circuit.measurements[{len(measurements) - 1}]",
                        metadata={"measurement_id": measurement.measurement_id},
                    )
                )
            continue
        gate = _parse_gate_statement(
            text,
            index=index,
            line=line,
            statement_id=statement_id,
            qubit_register=qubit_register,
            qubit_count=len(qubits),
            measurement_seen=measurement_seen,
        )
        if isinstance(gate, DiagnosticsIR):
            diagnostics.append(gate)
            continue
        gates.append(gate)
        parsed_statements.append(
            _statement(
                statement_id,
                "gate",
                line,
                text,
                native_ref=f"circuit.gates[{len(gates) - 1}]",
                metadata={"gate_id": gate.gate_id, "gate": gate.name},
            )
        )

    if not seen_header:
        diagnostics.insert(
            0,
            _diagnostic(
                code="OPENQASM_VERSION_MISSING",
                message="Restricted OpenQASM 3 input must start with OPENQASM 3.",
                line=1,
                statement="",
                object_path="source.header",
            ),
        )
    if not qubits:
        diagnostics.append(
            _diagnostic(
                code="OPENQASM_QUBIT_REGISTER_MISSING",
                message="Restricted OpenQASM 3 input requires one qubit register.",
                line=1,
                statement="",
                object_path="source.qubits",
            )
        )

    program: DigitalProgramIR | None = None
    if not diagnostics:
        bit_order = _bit_order(qubits, bit_register, bit_count)
        measurement_mapping = _measurement_mapping(measurements, bit_register)
        program = build_digital_program(
            program_id=program_id,
            qubits=qubits,
            gates=tuple(gates),
            measurements=tuple(measurements),
            metadata={
                "source": {
                    "source_format": "openqasm3",
                    "source_id": source_id,
                    "source_digest": source_digest,
                    "supported_subset": list(_supported_subset()),
                    "parser": "cascaqit.interop.openqasm3_subset",
                    "external_sdk_imported": False,
                    "cascaqit_compat_required": False,
                },
                "source_map": [statement.to_dict() for statement in parsed_statements],
                "bit_order": bit_order,
                "measurement_mapping": measurement_mapping,
            },
        )
        diagnostics.extend(program.validate_ir_only())
    else:
        bit_order = _bit_order(qubits, bit_register, bit_count)
        measurement_mapping = _measurement_mapping(measurements, bit_register)

    return OpenQASM3SubsetImportResultIR(
        source_format="openqasm3",
        source_digest=source_digest,
        program=program,
        diagnostics=tuple(diagnostics),
        statements=tuple(parsed_statements),
        bit_order=bit_order,
        measurement_mapping=measurement_mapping,
        supported_subset=_supported_subset(),
        metadata={
            "source_id": source_id,
            "statement_count": len(statements),
            "parsed_statement_count": len(parsed_statements),
            "gate_count": len(gates),
            "measurement_count": len(measurements),
            "qubit_count": len(qubits),
            "bit_count": bit_count,
            "program_available": program is not None,
            "phase": "216",
        },
    )


def _split_statements(source: str) -> tuple[tuple[int, str], ...]:
    statements: list[tuple[int, str]] = []
    pending = ""
    pending_line = 1
    for line_number, raw_line in enumerate(source.splitlines(), start=1):
        line = raw_line.split("//", 1)[0].strip()
        if not line:
            continue
        if not pending:
            pending_line = line_number
        pending = f"{pending} {line}".strip()
        while ";" in pending:
            statement, pending = pending.split(";", 1)
            statement = statement.strip()
            if statement:
                statements.append((pending_line, statement))
            pending = pending.strip()
            pending_line = line_number
    if pending.strip():
        statements.append((pending_line, pending.strip()))
    return tuple(statements)


def _preclassify_statement(
    *,
    index: int,
    line: int,
    statement: str,
) -> DiagnosticsIR | None:
    stripped = statement.strip()
    first_token = _first_token(stripped)
    unsupported = _UNSUPPORTED_FEATURE_KEYWORDS.get(first_token)
    if unsupported is not None:
        code, reason_category, suggestion = unsupported
        return _diagnostic(
            code=code,
            message=(
                f"OpenQASM statement '{first_token}' is outside the restricted "
                "OpenQASM 3 subset."
            ),
            line=line,
            statement=statement,
            object_path=f"source.statements[{index}]",
            suggestion=suggestion,
            metadata={"reason_category": reason_category, "keyword": first_token},
        )
    if first_token in {"}", "{"} or stripped.endswith("}"):
        return _diagnostic(
            code="OPENQASM_BLOCK_SYNTAX_UNSUPPORTED",
            message="OpenQASM block syntax is outside the restricted subset.",
            line=line,
            statement=statement,
            object_path=f"source.statements[{index}]",
            suggestion="Use only flat declarations, supported gates, and measure.",
            metadata={"reason_category": "dynamic_control"},
        )
    if _ASSIGNMENT_RE.fullmatch(stripped):
        return _diagnostic(
            code="OPENQASM_CLASSICAL_ASSIGNMENT_UNSUPPORTED",
            message="Classical assignment is outside the restricted subset.",
            line=line,
            statement=statement,
            object_path=f"source.statements[{index}]",
            suggestion="Use terminal measurement only; no classical mutation.",
            metadata={"reason_category": "dynamic_control"},
        )
    if _LEGACY_REGISTER_RE.match(stripped):
        return _diagnostic(
            code="OPENQASM_LEGACY_DECLARATION_UNSUPPORTED",
            message="OpenQASM 2 qreg/creg declarations are outside this subset.",
            line=line,
            statement=statement,
            object_path=f"source.statements[{index}]",
            suggestion="Use OpenQASM 3 declarations such as qubit[n] q and bit[n] c.",
            metadata={"reason_category": "syntax", "keyword": first_token},
        )
    return None


def _parse_gate_statement(
    text: str,
    *,
    index: int,
    line: int,
    statement_id: str,
    qubit_register: str | None,
    qubit_count: int,
    measurement_seen: bool,
) -> GateIR | DiagnosticsIR:
    match = _GATE_RE.fullmatch(text)
    if match is None:
        return _unsupported_or_malformed(index=index, line=line, statement=text)
    gate_name, parameter_text, target_text = match.groups()
    gate = gate_name.lower()
    if measurement_seen:
        return _diagnostic(
            code="OPENQASM_MID_CIRCUIT_MEASUREMENT_UNSUPPORTED",
            message=(
                "Gate statements after measurement imply mid-circuit measurement "
                "semantics, which are outside this subset."
            ),
            line=line,
            statement=text,
            object_path=f"source.statements[{index}]",
            suggestion="Move all measurements to the end of the OpenQASM source.",
            metadata={"reason_category": "measurement_semantics", "gate": gate_name},
        )
    targets = _parse_targets(
        target_text,
        index=index,
        line=line,
        statement=text,
        qubit_register=qubit_register,
        qubit_count=qubit_count,
    )
    if isinstance(targets, DiagnosticsIR):
        return targets
    gate_id = f"gate.openqasm3.{statement_id.rsplit('.', 1)[-1]}"
    metadata = _source_metadata(line, text)
    if gate in _SINGLE_QUBIT_GATES:
        if parameter_text is not None:
            return _parameter_shape_error(gate, index, line, text)
        if len(targets) != 1:
            return _arity_error(gate, 1, len(targets), index, line, text)
        return _single_qubit_gate(gate, targets[0], gate_id, metadata)
    if gate in _ROTATION_GATES:
        if parameter_text is None:
            return _parameter_shape_error(gate, index, line, text)
        if len(targets) != 1:
            return _arity_error(gate, 1, len(targets), index, line, text)
        try:
            theta = _parse_numeric_parameter(parameter_text)
        except _OpenQASMParameterError as error:
            return _diagnostic(
                code="OPENQASM_GATE_PARAMETER_INVALID",
                message=str(error),
                line=line,
                statement=text,
                object_path=f"source.statements[{index}].parameters",
                metadata={
                    "gate": gate,
                    "reason_category": error.reason_category,
                    "parameter_text": parameter_text,
                    **error.metadata,
                },
            )
        return _rotation_gate(gate, targets[0], theta, gate_id, metadata)
    if gate in _U_GATES:
        if parameter_text is None:
            return _parameter_shape_error(gate, index, line, text)
        if len(targets) != 1:
            return _arity_error(gate, 1, len(targets), index, line, text)
        try:
            theta, phi, lam = _parse_u_parameters(parameter_text)
        except _OpenQASMParameterError as error:
            return _diagnostic(
                code="OPENQASM_GATE_PARAMETER_INVALID",
                message=str(error),
                line=line,
                statement=text,
                object_path=f"source.statements[{index}].parameters",
                metadata={
                    "gate": gate,
                    "reason_category": error.reason_category,
                    "parameter_text": parameter_text,
                    **error.metadata,
                },
            )
        return GateIR.u(
            targets[0],
            theta,
            phi,
            lam,
            gate_id=gate_id,
            metadata=metadata,
        )
    if gate in _TWO_QUBIT_GATES:
        if parameter_text is not None:
            return _parameter_shape_error(gate, index, line, text)
        if len(targets) != 2:
            return _arity_error(gate, 2, len(targets), index, line, text)
        if gate == "cx":
            return GateIR.cx(targets[0], targets[1], gate_id=gate_id, metadata=metadata)
        if gate == "cy":
            return GateIR.cy(
                targets[0],
                targets[1],
                gate_id=gate_id,
                metadata=metadata,
            )
        return GateIR.cz(targets[0], targets[1], gate_id=gate_id, metadata=metadata)
    if gate == CCX_BLOCKED_GATE:
        return _diagnostic(
            code=CCX_BLOCKED_DIAGNOSTIC_CODE,
            message=CCX_BLOCKED_MESSAGE,
            line=line,
            statement=text,
            object_path=f"source.statements[{index}].gate",
            suggestion=CCX_BLOCKED_SUGGESTION,
            metadata=CCX_BLOCKED_METADATA,
        )
    return _diagnostic(
        code="OPENQASM_GATE_UNSUPPORTED",
        message=f"OpenQASM gate '{gate_name}' is not supported by this subset.",
        line=line,
        statement=text,
        object_path=f"source.statements[{index}].gate",
        metadata={"gate": gate_name, "reason_category": "requires_adapter"},
    )


def _parse_measurement(
    match: re.Match[str],
    *,
    index: int,
    line: int,
    statement: str,
    qubit_register: str | None,
    qubit_count: int,
    bit_register: str | None,
    bit_count: int | None,
) -> DigitalMeasurementIR | DiagnosticsIR:
    qreg, qindex_text, creg, cindex_text = match.groups()
    qindex = int(qindex_text)
    cindex = int(cindex_text)
    target = _resolve_qubit(
        qreg,
        qindex,
        qubit_register=qubit_register,
        qubit_count=qubit_count,
        index=index,
        line=line,
        statement=statement,
    )
    if isinstance(target, DiagnosticsIR):
        return target
    if bit_register is not None and creg != bit_register:
        return _diagnostic(
            code="OPENQASM_UNKNOWN_BIT_REGISTER",
            message="Measurement references an unknown bit register.",
            line=line,
            statement=statement,
            object_path=f"source.statements[{index}].bits",
            metadata={
                "reason_category": "register_mapping",
                "register_kind": "bit",
                "expected_register": bit_register,
                "actual_register": creg,
            },
        )
    if bit_count is not None and cindex >= bit_count:
        return _diagnostic(
            code="OPENQASM_BIT_INDEX_OUT_OF_RANGE",
            message="Measurement bit index is out of range.",
            line=line,
            statement=statement,
            object_path=f"source.statements[{index}].bits",
            metadata={
                "reason_category": "register_mapping",
                "register_kind": "bit",
                "index": cindex,
                "size": bit_count,
                "valid_index_range": [0, bit_count - 1],
            },
        )
    return DigitalMeasurementIR.measure(
        (target,),
        key=f"{creg}{cindex}",
        measurement_id=f"measurement.openqasm3.{index}",
        metadata={**_source_metadata(line, statement), "bit": f"{creg}[{cindex}]"},
    )


def _parse_targets(
    text: str,
    *,
    index: int,
    line: int,
    statement: str,
    qubit_register: str | None,
    qubit_count: int,
) -> tuple[str, ...] | DiagnosticsIR:
    targets: list[str] = []
    for raw_target in text.split(","):
        target_text = raw_target.strip()
        match = _QUBIT_REF_RE.fullmatch(target_text)
        if match is None:
            return _diagnostic(
                code="OPENQASM_QUBIT_REF_INVALID",
                message="OpenQASM gate targets must use q[i] references.",
                line=line,
                statement=statement,
                object_path=f"source.statements[{index}].targets",
                metadata={
                    "reason_category": "target_mapping",
                    "target": target_text,
                    "expected_shape": "register[index]",
                },
            )
        qreg, qindex_text = match.groups()
        target = _resolve_qubit(
            qreg,
            int(qindex_text),
            qubit_register=qubit_register,
            qubit_count=qubit_count,
            index=index,
            line=line,
            statement=statement,
        )
        if isinstance(target, DiagnosticsIR):
            return target
        targets.append(target)
    return tuple(targets)


def _resolve_qubit(
    qreg: str,
    qindex: int,
    *,
    qubit_register: str | None,
    qubit_count: int,
    index: int,
    line: int,
    statement: str,
) -> str | DiagnosticsIR:
    if qubit_register is None or qreg != qubit_register:
        return _diagnostic(
            code="OPENQASM_UNKNOWN_QUBIT_REGISTER",
            message="Statement references an unknown qubit register.",
            line=line,
            statement=statement,
            object_path=f"source.statements[{index}].qubits",
            metadata={
                "reason_category": "register_mapping",
                "register_kind": "qubit",
                "expected_register": qubit_register,
                "actual_register": qreg,
            },
        )
    if qindex >= qubit_count:
        return _diagnostic(
            code="OPENQASM_QUBIT_INDEX_OUT_OF_RANGE",
            message="Qubit index is out of range.",
            line=line,
            statement=statement,
            object_path=f"source.statements[{index}].qubits",
            metadata={
                "reason_category": "register_mapping",
                "register_kind": "qubit",
                "index": qindex,
                "size": qubit_count,
                "valid_index_range": [0, qubit_count - 1],
            },
        )
    return f"{qreg}{qindex}"


def _parse_numeric_parameter(text: str) -> float:
    value = text.strip()
    if "," in value:
        raise _OpenQASMParameterError(
            "Only one numeric gate parameter is supported.",
            reason_category="parameter_count",
            metadata={
                "expected_parameter_count": 1,
                "actual_parameter_count": len(tuple(text.split(","))),
            },
        )
    if value in {"pi", "+pi"}:
        return math.pi
    if value == "-pi":
        return -math.pi
    pi_fraction = re.fullmatch(r"([+-]?)pi\s*/\s*(\d+(?:\.\d+)?)", value)
    if pi_fraction is not None:
        sign, denominator = pi_fraction.groups()
        scale = -1.0 if sign == "-" else 1.0
        return scale * math.pi / float(denominator)
    try:
        return float(value)
    except ValueError as error:
        raise _OpenQASMParameterError(
            "Gate parameters must be numeric constants or pi fractions.",
            reason_category="parameter_value",
            metadata={"invalid_parameter": value},
        ) from error


def _parse_u_parameters(text: str) -> tuple[float, float, float]:
    parts = tuple(part.strip() for part in text.split(","))
    if len(parts) != 3:
        raise _OpenQASMParameterError(
            "OpenQASM u gate requires exactly three numeric parameters.",
            reason_category="parameter_count",
            metadata={
                "expected_parameter_count": 3,
                "actual_parameter_count": len(parts),
            },
        )
    theta = _parse_numeric_parameter(parts[0])
    phi = _parse_numeric_parameter(parts[1])
    lam = _parse_numeric_parameter(parts[2])
    return theta, phi, lam


def _single_qubit_gate(
    gate: str,
    qubit: str,
    gate_id: str,
    metadata: dict[str, Any],
) -> GateIR:
    if gate == "i":
        return GateIR.i(qubit, gate_id=gate_id, metadata=metadata)
    if gate == "x":
        return GateIR.x(qubit, gate_id=gate_id, metadata=metadata)
    if gate == "y":
        return GateIR.y(qubit, gate_id=gate_id, metadata=metadata)
    if gate == "z":
        return GateIR.z(qubit, gate_id=gate_id, metadata=metadata)
    if gate == "h":
        return GateIR.h(qubit, gate_id=gate_id, metadata=metadata)
    if gate == "s":
        return GateIR.s(qubit, gate_id=gate_id, metadata=metadata)
    if gate == "sdg":
        return GateIR.sdg(qubit, gate_id=gate_id, metadata=metadata)
    if gate == "t":
        return GateIR.t(qubit, gate_id=gate_id, metadata=metadata)
    return GateIR.tdg(qubit, gate_id=gate_id, metadata=metadata)


def _rotation_gate(
    gate: str,
    qubit: str,
    theta: float,
    gate_id: str,
    metadata: dict[str, Any],
) -> GateIR:
    if gate == "rx":
        return GateIR.rx(qubit, theta, gate_id=gate_id, metadata=metadata)
    if gate == "ry":
        return GateIR.ry(qubit, theta, gate_id=gate_id, metadata=metadata)
    if gate == "rz":
        return GateIR.rz(qubit, theta, gate_id=gate_id, metadata=metadata)
    return GateIR.p(qubit, theta, gate_id=gate_id, metadata=metadata)


def _arity_error(
    gate: str,
    expected: int,
    actual: int,
    index: int,
    line: int,
    statement: str,
) -> DiagnosticsIR:
    return _diagnostic(
        code="OPENQASM_GATE_ARITY_INVALID",
        message=f"OpenQASM gate '{gate}' expects {expected} targets, got {actual}.",
        line=line,
        statement=statement,
        object_path=f"source.statements[{index}].targets",
        metadata={
            "gate": gate,
            "reason_category": "arity",
            "expected": expected,
            "actual": actual,
            "expected_target_count": expected,
            "actual_target_count": actual,
        },
    )


def _parameter_shape_error(
    gate: str,
    index: int,
    line: int,
    statement: str,
) -> DiagnosticsIR:
    return _diagnostic(
        code="OPENQASM_GATE_PARAMETER_INVALID",
        message=f"OpenQASM gate '{gate}' has invalid parameter shape.",
        line=line,
        statement=statement,
        object_path=f"source.statements[{index}].parameters",
        metadata={"gate": gate, "reason_category": "parameter_shape"},
    )


def _unsupported_or_malformed(
    *,
    index: int,
    line: int,
    statement: str,
) -> DiagnosticsIR:
    first_token = _first_token(statement)
    return _diagnostic(
        code="OPENQASM_STATEMENT_INVALID",
        message="Statement is outside the restricted OpenQASM 3 subset.",
        line=line,
        statement=statement,
        object_path=f"source.statements[{index}]",
        suggestion="Use only declarations, supported gates, and terminal measure.",
        metadata={"reason_category": "syntax", "keyword": first_token},
    )


def _statement(
    statement_id: str,
    kind: StatementKind,
    line: int,
    text: str,
    *,
    native_ref: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> OpenQASM3SubsetStatementIR:
    return OpenQASM3SubsetStatementIR(
        statement_id=statement_id,
        kind=kind,
        source_line=line,
        source_text=text,
        native_ref=native_ref,
        metadata={} if metadata is None else dict(metadata),
    )


def _diagnostic(
    *,
    code: str,
    message: str,
    line: int,
    statement: str,
    object_path: str,
    suggestion: str = "Revise the source to the supported OpenQASM 3 subset.",
    metadata: dict[str, Any] | None = None,
) -> DiagnosticsIR:
    payload = {
        "source_format": "openqasm3",
        "source_line": line,
        "source_column": _source_column(statement),
        "source_statement": statement,
        "source_span": {
            "line": line,
            "column": _source_column(statement),
            "length": len(statement),
        },
        "reason_category": "syntax",
        "taxonomy_stage": "interop",
        "actionable": True,
        "action": "block_import",
        "supported_subset": list(_supported_subset()),
    }
    if metadata:
        payload.update(metadata)
    return DiagnosticsIR(
        diagnostic_id=f"openqasm3.{code.lower()}.{line}",
        stage="validation",
        severity="error",
        code=code,
        message=message,
        object_path=object_path,
        suggestion=suggestion,
        metadata=payload,
    )


def _first_token(statement: str) -> str:
    match = re.match(r"[A-Za-z_]\w*|[{}]", statement.strip())
    return "" if match is None else match.group(0).lower()


def _source_column(statement: str) -> int:
    return len(statement) - len(statement.lstrip()) + 1


def _source_metadata(line: int, statement: str) -> dict[str, Any]:
    return {
        "source_format": "openqasm3",
        "source_line": line,
        "source_statement": statement,
    }


def _bit_order(
    qubits: tuple[str, ...],
    bit_register: str | None,
    bit_count: int | None,
) -> dict[str, Any]:
    return {
        "convention": "openqasm_register_index_order",
        "qubit_order": list(qubits),
        "classical_register": bit_register,
        "classical_bit_count": bit_count,
        "bitstring_index": "left_to_right_matches_qubit_order",
    }


def _measurement_mapping(
    measurements: list[DigitalMeasurementIR],
    bit_register: str | None,
) -> dict[str, Any]:
    return {
        "basis": "computational",
        "readout_kind": "digital_computational",
        "classical_register": bit_register,
        "measurement_count": len(measurements),
        "measurements": [
            {
                "measurement_id": measurement.measurement_id,
                "targets": list(measurement.targets),
                "key": measurement.key,
                "source_line": measurement.metadata.get("source_line"),
                "source_statement": measurement.metadata.get("source_statement"),
                "classical_bit": measurement.metadata.get("bit"),
            }
            for measurement in measurements
        ],
    }


def _supported_subset() -> tuple[str, ...]:
    return (
        "OPENQASM 3",
        'include "stdgates.inc"',
        "qubit[n] q",
        "bit[n] c",
        "i/x/y/z/h/s/sdg/t/tdg",
        "rx/ry/rz/p numeric rotations",
        "u(theta, phi, lambda) numeric constants",
        "cx/cy/cz",
        "terminal measure q[i] -> c[j]",
    )
