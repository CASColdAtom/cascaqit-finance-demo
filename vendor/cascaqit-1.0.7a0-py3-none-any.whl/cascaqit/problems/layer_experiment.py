"""Automatic layer experiments for compiled variational Problems."""

from __future__ import annotations

import hashlib
import json
import math
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field, replace
from os import PathLike
from typing import TYPE_CHECKING, Any, Literal

from cascaqit.algorithms import OptimizerConfig
from cascaqit.algorithms.ansatz import transfer_vqe_parameters
from cascaqit.algorithms.optimizer import build_optimization_start_plans
from cascaqit.native_ir.base import IRMixin, stable_json
from cascaqit.problems.execution import ProblemExecutionResult

if TYPE_CHECKING:
    from cascaqit.visualization import ExperimentReport

__all__ = [
    "PROBLEM_LAYER_OBJECTIVE_TOLERANCE",
    "PROBLEM_LAYER_EXPERIMENT_SCHEMA_VERSION",
    "ProblemLayerExperimentResult",
    "ProblemLayerExperimentStepIR",
    "build_problem_layer_experiment_result",
]

PROBLEM_LAYER_EXPERIMENT_SCHEMA_VERSION = "cascaqit.problem.layer_experiment.v1"
PROBLEM_LAYER_OBJECTIVE_TOLERANCE = 1e-12
_DIGEST_LENGTH = 64


@dataclass(frozen=True)
class ProblemLayerExperimentStepIR(IRMixin):
    """One executed layer and its deterministic selection evidence."""

    layers: int
    execution: ProblemExecutionResult
    improvement_from_incumbent: float | None
    material_improvement: bool
    incumbent_layer: int
    no_improvement_count: int
    schema_version: str = PROBLEM_LAYER_EXPERIMENT_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_schema(self.schema_version)
        _positive_int(self.layers, "layers")
        if not isinstance(self.execution, ProblemExecutionResult):
            raise TypeError("execution must be ProblemExecutionResult.")
        if _execution_layers(self.execution) != self.layers:
            raise ValueError("execution layer count does not match step layers.")
        if self.improvement_from_incumbent is not None:
            improvement = _finite(
                self.improvement_from_incumbent,
                "improvement_from_incumbent",
            )
            object.__setattr__(self, "improvement_from_incumbent", improvement)
        if not isinstance(self.material_improvement, bool):
            raise TypeError("material_improvement must be boolean.")
        _positive_int(self.incumbent_layer, "incumbent_layer")
        if self.incumbent_layer > self.layers:
            raise ValueError("incumbent_layer cannot exceed the executed layer.")
        _non_negative_int(self.no_improvement_count, "no_improvement_count")

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ProblemLayerExperimentStepIR:
        """Restore one layer step from JSON-compatible data."""
        return cls(
            layers=int(data["layers"]),
            execution=ProblemExecutionResult.from_dict(
                _mapping(data["execution"], "execution")
            ),
            improvement_from_incumbent=(
                None
                if data.get("improvement_from_incumbent") is None
                else float(data["improvement_from_incumbent"])
            ),
            material_improvement=data["material_improvement"],
            incumbent_layer=int(data["incumbent_layer"]),
            no_improvement_count=int(data["no_improvement_count"]),
            schema_version=str(
                data.get(
                    "schema_version",
                    PROBLEM_LAYER_EXPERIMENT_SCHEMA_VERSION,
                )
            ),
        )


@dataclass(frozen=True)
class ProblemLayerExperimentResult(IRMixin):
    """Completed contiguous layer search with checked early-stop evidence."""

    experiment_id: str
    mode: Literal["digital", "hybrid"]
    algorithm: Literal["qaoa", "vqe"]
    problem_hash: str
    analysis_hash: str
    target_hash: str
    logical_order: tuple[str, ...]
    optimizer: OptimizerConfig
    max_layers: int
    min_improvement: float
    patience: int
    requested_shots: int
    seed: int
    steps: tuple[ProblemLayerExperimentStepIR, ...]
    selected_step_index: int
    stop_reason: Literal["max_layers_reached", "patience_exhausted"]
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = PROBLEM_LAYER_EXPERIMENT_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_schema(self.schema_version)
        _require_text(self.experiment_id, "experiment_id")
        if self.mode not in {"digital", "hybrid"}:
            raise ValueError("layer experiments support only digital or hybrid mode.")
        if self.algorithm not in {"qaoa", "vqe"}:
            raise ValueError("layer experiments support only qaoa or vqe.")
        if self.mode == "hybrid" and self.algorithm != "qaoa":
            raise ValueError("hybrid layer experiments require qaoa.")
        for value, name in (
            (self.problem_hash, "problem_hash"),
            (self.analysis_hash, "analysis_hash"),
            (self.target_hash, "target_hash"),
        ):
            _require_digest(value, name)
        object.__setattr__(self, "logical_order", tuple(self.logical_order))
        _require_unique_text(self.logical_order, "logical_order")
        if not isinstance(self.optimizer, OptimizerConfig):
            raise TypeError("optimizer must be OptimizerConfig.")
        if self.optimizer.bounds:
            raise ValueError(
                "layer experiment optimizer bounds must be resolved per layer."
            )
        if self.optimizer.initialization != "random":
            raise ValueError(
                "layer experiment optimizer initialization must be 'random'; "
                "later layers are managed as layerwise starts."
            )
        _positive_int(self.max_layers, "max_layers")
        threshold = _finite(self.min_improvement, "min_improvement")
        if threshold < 0.0:
            raise ValueError("min_improvement must be non-negative.")
        object.__setattr__(self, "min_improvement", threshold)
        _positive_int(self.patience, "patience")
        _non_negative_int(self.requested_shots, "requested_shots")
        _non_negative_int(self.seed, "seed")
        object.__setattr__(self, "steps", tuple(self.steps))
        if not self.steps:
            raise ValueError("steps must contain at least one executed layer.")
        if len(self.steps) > self.max_layers:
            raise ValueError("executed layer count cannot exceed max_layers.")
        if tuple(step.layers for step in self.steps) != tuple(
            range(1, len(self.steps) + 1)
        ):
            raise ValueError("steps must contain contiguous layers starting at one.")
        if (
            not isinstance(self.selected_step_index, int)
            or isinstance(self.selected_step_index, bool)
            or not 0 <= self.selected_step_index < len(self.steps)
        ):
            raise ValueError("selected_step_index is outside steps.")
        if self.stop_reason not in {"max_layers_reached", "patience_exhausted"}:
            raise ValueError(f"Unsupported stop_reason: {self.stop_reason!r}.")
        if not isinstance(self.metadata, dict):
            raise TypeError("metadata must be a dictionary.")
        object.__setattr__(self, "metadata", dict(self.metadata))
        expected_metadata = {
            "selection_rule": (
                "material_expected_objective_improvement_then_shallower_layer"
            ),
            "warm_start": "previous_selected_parameters",
            "global_optimality_claim": False,
            "backend_called_during_report": False,
        }
        if any(
            self.metadata.get(key) != value
            for key, value in expected_metadata.items()
        ):
            raise ValueError("layer experiment metadata does not match its contract.")
        self._validate_shared_execution_facts()
        expected_steps, expected_selected, expected_reason = _layer_step_evidence(
            tuple(step.execution for step in self.steps),
            max_layers=self.max_layers,
            min_improvement=self.min_improvement,
            patience=self.patience,
        )
        if self.steps != expected_steps:
            raise ValueError("layer step evidence does not match source executions.")
        if self.selected_step_index != expected_selected:
            raise ValueError(
                "selected_step_index does not match the material-improvement rule."
            )
        if self.stop_reason != expected_reason:
            raise ValueError("stop_reason does not match the executed layer history.")
        self._validate_layerwise_initialization()
        expected_id = _experiment_id(
            self.executions,
            optimizer=self.optimizer,
            max_layers=self.max_layers,
            min_improvement=self.min_improvement,
            patience=self.patience,
            requested_shots=self.requested_shots,
            seed=self.seed,
        )
        if self.experiment_id != expected_id:
            raise ValueError("experiment_id does not match the layer experiment facts.")

    @property
    def executions(self) -> tuple[ProblemExecutionResult, ...]:
        """Return every completed layer execution in ascending order."""
        return tuple(step.execution for step in self.steps)

    @property
    def selected_execution(self) -> ProblemExecutionResult:
        """Return the shallowest execution selected by the configured rule."""
        return self.steps[self.selected_step_index].execution

    @property
    def selected_layers(self) -> int:
        """Return the selected Ansatz layer count."""
        return self.steps[self.selected_step_index].layers

    @property
    def total_evaluation_count(self) -> int:
        """Return all real objective evaluations across executed layers."""
        return sum(len(execution.parameter_history) for execution in self.executions)

    def comparison_sources(self) -> dict[str, ProblemExecutionResult]:
        """Return stable labels accepted by the standard comparison report."""
        return {
            f"p={step.layers}": step.execution
            for step in self.steps
        }

    def report(
        self,
        output: str | PathLike[str] | None = None,
        *,
        language: Literal["en", "zh"] = "en",
        title: str | None = None,
    ) -> ExperimentReport:
        """Build and optionally save the standard layer experiment report."""
        from cascaqit.visualization import visualize

        report = visualize(self, profile="comparison", title=title)
        if output is not None:
            report.save(output, language=language)
        return report

    def _validate_shared_execution_facts(self) -> None:
        for step in self.steps:
            execution = step.execution
            mapping = execution.context.analysis.mapping_plan
            if execution.mode != self.mode or execution.algorithm != self.algorithm:
                raise ValueError(
                    "layer executions must share the experiment mode and algorithm."
                )
            if execution.problem_hash != self.problem_hash:
                raise ValueError("layer executions must share problem_hash.")
            if execution.analysis_hash != self.analysis_hash:
                raise ValueError("layer executions must share analysis_hash.")
            if execution.logical_order != self.logical_order:
                raise ValueError("layer executions must share logical_order.")
            if mapping.target_hash != self.target_hash:
                raise ValueError("layer executions must share target_hash.")
            if execution.optimization is None:
                raise ValueError("each layer must contain SciPy optimization evidence.")
            if execution.optimization.search_kind != "scipy":
                raise ValueError("layer experiments require SciPy optimization.")
            actual_optimizer = execution.optimization.optimizer
            if not isinstance(actual_optimizer, OptimizerConfig):
                raise ValueError("layer execution must retain optimizer config.")
            normalized_optimizer = replace(
                actual_optimizer,
                bounds=(),
                initialization="random",
            )
            if normalized_optimizer != self.optimizer:
                raise ValueError(
                    "layer execution optimizer does not match the requested config."
                )
            if execution.metadata.get("requested_shots") != self.requested_shots:
                raise ValueError(
                    "layer execution requested shots do not match the experiment."
                )

    def _validate_layerwise_initialization(self) -> None:
        for previous, current in zip(self.steps, self.steps[1:]):
            optimization = current.execution.optimization
            assert optimization is not None
            if not isinstance(optimization.optimizer, OptimizerConfig):
                raise ValueError("layer optimization must retain optimizer config.")
            if not optimization.starts:
                raise ValueError("layer optimization must retain optimizer starts.")
            first_start = optimization.starts[0]
            if first_start.initialization != "layerwise":
                raise ValueError(
                    "every layer after one must use a layerwise first start."
                )
            parameter_names = tuple(
                parameter.name
                for parameter in current.execution.context.parameter_schema.parameters
            )
            previous_parameters = dict(previous.execution.parameter_bind.values)
            if self.algorithm == "vqe":
                previous_ansatz = previous.execution.context.ansatz
                current_ansatz = current.execution.context.ansatz
                if previous_ansatz is None or current_ansatz is None:
                    raise ValueError(
                        "VQE layer executions must retain ansatz source facts."
                    )
                previous_parameters = transfer_vqe_parameters(
                    previous_ansatz,
                    current_ansatz,
                    previous_parameters,
                )
            plans = build_optimization_start_plans(
                algorithm_kind=self.algorithm,
                layers=current.layers,
                parameter_names=parameter_names,
                optimizer=optimization.optimizer,
                initial_parameters=previous_parameters,
                seed=self.seed if self.optimizer.seed is None else self.optimizer.seed,
            )
            if plans[0].initialization != "layerwise":
                raise RuntimeError("layerwise plan construction lost its strategy.")
            expected = dict(zip(parameter_names, plans[0].parameters))
            if not _parameter_maps_close(expected, first_start.initial_parameters):
                raise ValueError(
                    "layerwise initial parameters do not derive from the prior layer."
                )

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ProblemLayerExperimentResult:
        """Restore a completed layer experiment from JSON-compatible data."""
        return cls(
            experiment_id=str(data["experiment_id"]),
            mode=data["mode"],
            algorithm=data["algorithm"],
            problem_hash=str(data["problem_hash"]),
            analysis_hash=str(data["analysis_hash"]),
            target_hash=str(data["target_hash"]),
            logical_order=tuple(str(item) for item in data["logical_order"]),
            optimizer=OptimizerConfig.from_dict(
                _mapping(data["optimizer"], "optimizer")
            ),
            max_layers=int(data["max_layers"]),
            min_improvement=float(data["min_improvement"]),
            patience=int(data["patience"]),
            requested_shots=int(data["requested_shots"]),
            seed=int(data["seed"]),
            steps=tuple(
                ProblemLayerExperimentStepIR.from_dict(_mapping(item, "step"))
                for item in _sequence(data["steps"], "steps")
            ),
            selected_step_index=int(data["selected_step_index"]),
            stop_reason=data["stop_reason"],
            metadata=dict(_mapping(data.get("metadata", {}), "metadata")),
            schema_version=str(
                data.get(
                    "schema_version",
                    PROBLEM_LAYER_EXPERIMENT_SCHEMA_VERSION,
                )
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> ProblemLayerExperimentResult:
        """Restore a completed layer experiment from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("ProblemLayerExperimentResult JSON must contain an object.")
        return cls.from_dict(data)


def build_problem_layer_experiment_result(
    executions: Sequence[ProblemExecutionResult],
    *,
    optimizer: OptimizerConfig,
    max_layers: int,
    min_improvement: float,
    patience: int,
    requested_shots: int,
    seed: int,
) -> ProblemLayerExperimentResult:
    """Build one checked result from already completed contiguous executions."""
    if not isinstance(executions, Sequence) or isinstance(executions, (str, bytes)):
        raise TypeError("executions must be a sequence of ProblemExecutionResult.")
    normalized = tuple(executions)
    if not normalized or any(
        not isinstance(item, ProblemExecutionResult) for item in normalized
    ):
        raise ValueError("executions must contain ProblemExecutionResult values.")
    steps, selected_step_index, stop_reason = _layer_step_evidence(
        normalized,
        max_layers=max_layers,
        min_improvement=min_improvement,
        patience=patience,
    )
    baseline = normalized[0]
    target_hash = baseline.context.analysis.mapping_plan.target_hash
    return ProblemLayerExperimentResult(
        experiment_id=_experiment_id(
            normalized,
            optimizer=optimizer,
            max_layers=max_layers,
            min_improvement=min_improvement,
            patience=patience,
            requested_shots=requested_shots,
            seed=seed,
        ),
        mode=baseline.mode,  # type: ignore[arg-type]
        algorithm=baseline.algorithm,  # type: ignore[arg-type]
        problem_hash=baseline.problem_hash,
        analysis_hash=baseline.analysis_hash,
        target_hash=target_hash,
        logical_order=baseline.logical_order,
        optimizer=optimizer,
        max_layers=max_layers,
        min_improvement=min_improvement,
        patience=patience,
        requested_shots=requested_shots,
        seed=seed,
        steps=steps,
        selected_step_index=selected_step_index,
        stop_reason=stop_reason,
        metadata={
            "selection_rule": (
                "material_expected_objective_improvement_then_shallower_layer"
            ),
            "warm_start": "previous_selected_parameters",
            "global_optimality_claim": False,
            "backend_called_during_report": False,
        },
    )


def _layer_step_evidence(
    executions: tuple[ProblemExecutionResult, ...],
    *,
    max_layers: int,
    min_improvement: float,
    patience: int,
) -> tuple[
    tuple[ProblemLayerExperimentStepIR, ...],
    int,
    Literal["max_layers_reached", "patience_exhausted"],
]:
    _positive_int(max_layers, "max_layers")
    threshold = _finite(min_improvement, "min_improvement")
    if threshold < 0.0:
        raise ValueError("min_improvement must be non-negative.")
    _positive_int(patience, "patience")
    if not executions:
        raise ValueError("executions must not be empty.")
    if len(executions) > max_layers:
        raise ValueError("execution count cannot exceed max_layers.")
    steps: list[ProblemLayerExperimentStepIR] = []
    selected_index = 0
    no_improvement_count = 0
    for index, execution in enumerate(executions):
        layers = index + 1
        if _execution_layers(execution) != layers:
            raise ValueError("executions must use contiguous layers starting at one.")
        if index == 0:
            improvement = None
            material = True
        else:
            incumbent = executions[selected_index]
            improvement = incumbent.objective_value - execution.objective_value
            material = is_material_layer_improvement(improvement, threshold)
            if material:
                selected_index = index
                no_improvement_count = 0
            else:
                no_improvement_count += 1
        steps.append(
            ProblemLayerExperimentStepIR(
                layers=layers,
                execution=execution,
                improvement_from_incumbent=improvement,
                material_improvement=material,
                incumbent_layer=selected_index + 1,
                no_improvement_count=no_improvement_count,
            )
        )
        if no_improvement_count >= patience and index + 1 < len(executions):
            raise ValueError("executions continue after the configured early stop.")
    if no_improvement_count >= patience:
        reason: Literal["max_layers_reached", "patience_exhausted"] = (
            "patience_exhausted"
        )
    elif len(executions) == max_layers:
        reason = "max_layers_reached"
    else:
        raise ValueError("incomplete executions do not satisfy a stop condition.")
    return tuple(steps), selected_index, reason


def _execution_layers(execution: ProblemExecutionResult) -> int:
    if execution.algorithm == "qaa":
        raise ValueError("QAA does not define variational Ansatz layers.")
    gamma_count = sum(
        parameter.name.startswith("gamma_")
        for parameter in execution.context.parameter_schema.parameters
    )
    if execution.algorithm == "qaoa":
        if gamma_count <= 0:
            raise ValueError("QAOA execution does not expose canonical layers.")
        return gamma_count
    indices = []
    for parameter in execution.context.parameter_schema.parameters:
        parts = parameter.name.split("_")
        if len(parts) == 3 and parts[0] in {"ry", "rz"} and parts[1].isdigit():
            indices.append(int(parts[1]))
    if not indices:
        raise ValueError("VQE execution does not expose built-in layer parameters.")
    return max(indices) + 1


def is_material_layer_improvement(
    improvement: float,
    min_improvement: float,
) -> bool:
    """Return whether an objective decrease is larger than numeric noise."""
    return (
        improvement > PROBLEM_LAYER_OBJECTIVE_TOLERANCE
        and improvement >= min_improvement
    )


def _experiment_id(
    executions: tuple[ProblemExecutionResult, ...],
    *,
    optimizer: OptimizerConfig,
    max_layers: int,
    min_improvement: float,
    patience: int,
    requested_shots: int,
    seed: int,
) -> str:
    digest = hashlib.sha256(
        stable_json(
            {
                "execution_hashes": tuple(item.execution_hash for item in executions),
                "optimizer": optimizer,
                "max_layers": max_layers,
                "min_improvement": min_improvement,
                "patience": patience,
                "requested_shots": requested_shots,
                "seed": seed,
            }
        ).encode("utf-8")
    ).hexdigest()[:20]
    return f"problem.layer-experiment.{digest}"


def _parameter_maps_close(
    left: Mapping[str, float],
    right: Mapping[str, float],
) -> bool:
    return left.keys() == right.keys() and all(
        math.isclose(float(left[name]), float(right[name]), rel_tol=0.0, abs_tol=1e-12)
        for name in left
    )


def _mapping(value: object, name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{name} must be a mapping.")
    return value


def _sequence(value: object, name: str) -> Sequence[Any]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        raise TypeError(f"{name} must be a sequence.")
    return value


def _finite(value: object, name: str) -> float:
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        raise TypeError(f"{name} must be a real number.")
    normalized = float(value)
    if not math.isfinite(normalized):
        raise ValueError(f"{name} must be finite.")
    return normalized


def _positive_int(value: object, name: str) -> None:
    if not isinstance(value, int) or isinstance(value, bool) or value <= 0:
        raise ValueError(f"{name} must be a positive integer.")


def _non_negative_int(value: object, name: str) -> None:
    if not isinstance(value, int) or isinstance(value, bool) or value < 0:
        raise ValueError(f"{name} must be a non-negative integer.")


def _require_text(value: object, name: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{name} must be a non-empty string.")


def _require_digest(value: object, name: str) -> None:
    if (
        not isinstance(value, str)
        or len(value) != _DIGEST_LENGTH
        or any(character not in "0123456789abcdef" for character in value)
    ):
        raise ValueError(f"{name} must be a lowercase SHA-256 digest.")


def _require_unique_text(values: tuple[str, ...], name: str) -> None:
    if not values or any(not isinstance(item, str) or not item for item in values):
        raise ValueError(f"{name} must contain non-empty strings.")
    if len(values) != len(set(values)):
        raise ValueError(f"{name} values must be unique.")


def _require_schema(value: str) -> None:
    if value != PROBLEM_LAYER_EXPERIMENT_SCHEMA_VERSION:
        raise ValueError(f"Unsupported Problem layer experiment schema: {value!r}.")
