"""Problem-level IR contracts for combinatorial workflows."""

from __future__ import annotations

import json
import math
from dataclasses import dataclass, field
from typing import Any, Literal

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.native_ir.base import IRMixin, canonicalize
from cascaqit.native_ir.models import SCHEMA_VERSION
from cascaqit.problems.mis import MISInstance

__all__ = [
    "GraphProblemIR",
    "IsingModelIR",
    "MWISProblemIR",
    "ProblemCandidateIR",
    "ProblemResultDecodingIR",
    "ProblemResultProvenanceIR",
    "ProblemSweepExplanationIR",
    "QUBOProblemIR",
    "build_optimizer_problem_provenance_bridge",
    "explain_problem_sweep_result",
    "build_problem_result_provenance",
    "build_graph_layout_candidate",
    "build_ising_objective_candidate",
    "build_qubo_objective_candidate",
    "decode_graph_bitstring",
    "diagnose_mis_decode",
    "decode_mis_result",
]

ProblemType = Literal["graph", "mwis", "qubo", "ising"]
ProblemCandidateKind = Literal[
    "graph_layout",
    "qubo_objective_summary",
    "ising_objective_summary",
]


@dataclass(frozen=True)
class ProblemCandidateIR(IRMixin):
    """Inspectable problem candidate metadata without optimality claims."""

    candidate_id: str
    candidate_kind: ProblemCandidateKind
    problem_id: str
    problem_type: ProblemType
    source_problem_hash: str
    payload: dict[str, Any]
    diagnostics: tuple[DiagnosticsIR, ...] = ()
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ProblemCandidateIR:
        """Build a problem candidate from a dictionary."""
        return cls(
            candidate_id=str(data["candidate_id"]),
            candidate_kind=data["candidate_kind"],
            problem_id=str(data["problem_id"]),
            problem_type=data["problem_type"],
            source_problem_hash=str(data["source_problem_hash"]),
            payload=dict(data["payload"]),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(diagnostic)
                for diagnostic in data.get("diagnostics", ())
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> ProblemCandidateIR:
        """Build a problem candidate from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("ProblemCandidateIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class ProblemResultDecodingIR(IRMixin):
    """Metadata skeleton for decoding problem-level results."""

    decoding_id: str
    problem_id: str
    problem_type: ProblemType
    source_problem_hash: str
    variable_order: tuple[str, ...]
    bitstring_convention: str
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ProblemResultDecodingIR:
        """Build result decoding metadata from a dictionary."""
        return cls(
            decoding_id=str(data["decoding_id"]),
            problem_id=str(data["problem_id"]),
            problem_type=data["problem_type"],
            source_problem_hash=str(data["source_problem_hash"]),
            variable_order=tuple(str(item) for item in data["variable_order"]),
            bitstring_convention=str(data["bitstring_convention"]),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> ProblemResultDecodingIR:
        """Build result decoding metadata from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("ProblemResultDecodingIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class ProblemResultProvenanceIR(IRMixin):
    """Metadata contract linking problem decoding back to runtime evidence."""

    provenance_id: str
    problem_id: str
    problem_type: ProblemType
    source_problem_hash: str
    bitstring: str
    variable_order: tuple[str, ...]
    decoded_selected_nodes: tuple[str, ...]
    decoder_status: str
    optimality_claim: str = "not_claimed"
    parameter_bind_id: str | None = None
    parameter_bind_hash: str | None = None
    batch_id: str | None = None
    batch_item_index: int | None = None
    batch_item_status: str | None = None
    result_id: str | None = None
    execution_package_id: str | None = None
    hardware_execution: bool = False
    cloud_execution: bool = False
    metadata_only: bool = True
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ProblemResultProvenanceIR:
        """Build provenance metadata from a dictionary."""
        return cls(
            provenance_id=str(data["provenance_id"]),
            problem_id=str(data["problem_id"]),
            problem_type=data["problem_type"],
            source_problem_hash=str(data["source_problem_hash"]),
            bitstring=str(data["bitstring"]),
            variable_order=tuple(str(item) for item in data["variable_order"]),
            decoded_selected_nodes=tuple(
                str(item) for item in data.get("decoded_selected_nodes", ())
            ),
            decoder_status=str(data["decoder_status"]),
            optimality_claim=str(data.get("optimality_claim", "not_claimed")),
            parameter_bind_id=data.get("parameter_bind_id"),
            parameter_bind_hash=data.get("parameter_bind_hash"),
            batch_id=data.get("batch_id"),
            batch_item_index=None
            if data.get("batch_item_index") is None
            else int(data["batch_item_index"]),
            batch_item_status=data.get("batch_item_status"),
            result_id=data.get("result_id"),
            execution_package_id=data.get("execution_package_id"),
            hardware_execution=bool(data.get("hardware_execution", False)),
            cloud_execution=bool(data.get("cloud_execution", False)),
            metadata_only=bool(data.get("metadata_only", True)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> ProblemResultProvenanceIR:
        """Build provenance metadata from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("ProblemResultProvenanceIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class ProblemSweepExplanationIR(IRMixin):
    """User-facing metadata summary for one decoded problem/sweep result."""

    explanation_id: str
    problem_id: str
    problem_type: ProblemType
    sweep_id: str | None
    batch_id: str | None
    bitstring: str
    decoded: dict[str, Any]
    provenance: ProblemResultProvenanceIR
    sweep_summary: Any | None
    decoder_diagnostics: dict[str, Any]
    diagnostic_codes: tuple[str, ...]
    status: str = "explained"
    optimality_claim: str = "not_claimed"
    metadata_only: bool = True
    hardware_execution: bool = False
    cloud_execution: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ProblemSweepExplanationIR:
        """Build a problem/sweep explanation from a dictionary."""
        provenance = ProblemResultProvenanceIR.from_dict(data["provenance"])
        return cls(
            explanation_id=str(data["explanation_id"]),
            problem_id=str(data["problem_id"]),
            problem_type=data["problem_type"],
            sweep_id=data.get("sweep_id"),
            batch_id=data.get("batch_id"),
            bitstring=str(data["bitstring"]),
            decoded=dict(data["decoded"]),
            provenance=provenance,
            sweep_summary=data.get("sweep_summary"),
            decoder_diagnostics=dict(data["decoder_diagnostics"]),
            diagnostic_codes=tuple(
                str(code) for code in data.get("diagnostic_codes", ())
            ),
            status=str(data.get("status", "explained")),
            optimality_claim=str(data.get("optimality_claim", "not_claimed")),
            metadata_only=bool(data.get("metadata_only", True)),
            hardware_execution=bool(data.get("hardware_execution", False)),
            cloud_execution=bool(data.get("cloud_execution", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> ProblemSweepExplanationIR:
        """Build a problem/sweep explanation from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("ProblemSweepExplanationIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class GraphProblemIR(IRMixin):
    """Undirected graph problem contract."""

    problem_id: str
    nodes: tuple[str, ...]
    edges: tuple[tuple[str, str], ...]
    node_positions: tuple[tuple[str, tuple[float, float]], ...] = ()
    graph_type: Literal["undirected"] = "undirected"
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_edges(
        cls,
        *,
        problem_id: str,
        edges: list[tuple[str, str]] | tuple[tuple[str, str], ...],
        nodes: list[str] | tuple[str, ...] | None = None,
        positions: dict[str, tuple[float, float]] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> GraphProblemIR:
        """Build a deterministic graph problem from node and edge data."""
        edge_nodes = {str(node) for edge in edges for node in edge}
        all_nodes = edge_nodes if nodes is None else {str(node) for node in nodes}
        node_positions: tuple[tuple[str, tuple[float, float]], ...] = ()
        if positions is not None:
            node_positions = tuple(
                (str(node), (float(position[0]), float(position[1])))
                for node, position in sorted(positions.items())
            )
        return cls(
            problem_id=problem_id,
            nodes=tuple(sorted(all_nodes)),
            edges=_normalize_edges(edges),
            node_positions=node_positions,
            metadata={} if metadata is None else dict(metadata),
        )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> GraphProblemIR:
        """Build graph problem IR from a dictionary."""
        return cls(
            problem_id=str(data["problem_id"]),
            nodes=tuple(str(node) for node in data["nodes"]),
            edges=tuple(
                (str(edge[0]), str(edge[1])) for edge in data.get("edges", ())
            ),
            node_positions=tuple(
                (
                    str(item[0]),
                    (float(item[1][0]), float(item[1][1])),
                )
                for item in data.get("node_positions", ())
            ),
            graph_type=data.get("graph_type", "undirected"),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> GraphProblemIR:
        """Build graph problem IR from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("GraphProblemIR JSON must contain an object.")
        return cls.from_dict(data)

    def position_by_node(self) -> dict[str, tuple[float, float]]:
        """Return graph positions keyed by node id."""
        return dict(self.node_positions)

    def validate(self) -> tuple[DiagnosticsIR, ...]:
        """Return structural graph diagnostics."""
        diagnostics: list[DiagnosticsIR] = []
        node_set = set(self.nodes)
        if not self.nodes:
            diagnostics.append(
                _diagnostic(
                    problem_type="graph",
                    code="GRAPH_EMPTY",
                    message="GraphProblemIR requires at least one node.",
                    object_path="graph.nodes",
                )
            )
        if len(node_set) != len(self.nodes):
            diagnostics.append(
                _diagnostic(
                    problem_type="graph",
                    code="GRAPH_DUPLICATE_NODE",
                    message="GraphProblemIR node identifiers must be unique.",
                    object_path="graph.nodes",
                )
            )
        for left, right in self.edges:
            if left == right:
                diagnostics.append(
                    _diagnostic(
                        problem_type="graph",
                        code="GRAPH_SELF_LOOP",
                        message="GraphProblemIR does not support self-loop edges.",
                        object_path=f"graph.edges.{left}",
                    )
                )
            if left not in node_set or right not in node_set:
                diagnostics.append(
                    _diagnostic(
                        problem_type="graph",
                        code="GRAPH_EDGE_UNKNOWN_NODE",
                        message="Graph edge references an unknown node.",
                        object_path=f"graph.edges.{left}.{right}",
                    )
                )
        return tuple(diagnostics)

    def to_mis_instance(self, *, fallback_spacing: float = 5.0) -> MISInstance:
        """Convert this graph to an MIS instance with deterministic positions."""
        positions = self.position_by_node()
        if set(positions) != set(self.nodes):
            positions = {
                node: (float(index) * fallback_spacing, 0.0)
                for index, node in enumerate(self.nodes)
            }
            layout_metadata = {
                "layout_policy": "deterministic_line_fallback",
                "layout_optimality": "not_claimed",
                "fallback_spacing": fallback_spacing,
            }
        else:
            layout_metadata = {
                "layout_policy": "provided_positions",
                "layout_optimality": "not_claimed",
            }
        return MISInstance.from_positions(
            positions=positions,
            edges=self.edges,
            metadata={
                "source_problem_id": self.problem_id,
                "source_problem_type": "graph",
                "source_problem_hash": self.stable_hash(),
                **layout_metadata,
            },
        )

    def result_decoding_metadata(self) -> ProblemResultDecodingIR:
        """Return result decoding metadata for graph-node bitstrings."""
        return ProblemResultDecodingIR(
            decoding_id=f"decode.{self.problem_id}",
            problem_id=self.problem_id,
            problem_type="graph",
            source_problem_hash=self.stable_hash(),
            variable_order=self.nodes,
            bitstring_convention="1 means selected node in variable_order",
        )

    def layout_candidate(
        self,
        *,
        layout: Literal["line", "grid"] = "line",
        spacing: float = 5.0,
        columns: int | None = None,
    ) -> ProblemCandidateIR:
        """Return a deterministic graph layout candidate without optimality claims."""
        return build_graph_layout_candidate(
            self,
            layout=layout,
            spacing=spacing,
            columns=columns,
        )


@dataclass(frozen=True)
class MWISProblemIR(IRMixin):
    """带权无向图的最大带权独立集源模型。

    权重映射定义完整节点集合，因此没有边的孤立节点也不会丢失。该模型只保存
    业务输入；QUBO、罚项和 Hamiltonian 在后续 canonicalization 阶段生成。
    """

    problem_id: str
    nodes: tuple[str, ...]
    node_weights: tuple[tuple[str, float], ...]
    edges: tuple[tuple[str, str], ...]
    node_positions: tuple[tuple[str, tuple[float, float]], ...] = ()
    graph_type: Literal["undirected"] = "undirected"
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_edges(
        cls,
        *,
        problem_id: str,
        node_weights: dict[str, float],
        edges: list[tuple[str, str]] | tuple[tuple[str, str], ...],
        positions: dict[str, tuple[float, float]] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> MWISProblemIR:
        """从权重、边和可选二维位置构造确定性的 MWIS 源模型。"""
        weights = tuple(
            (str(node), _normalized_positive_weight(weight))
            for node, weight in sorted(
                node_weights.items(),
                key=lambda item: str(item[0]),
            )
        )
        normalized_positions: tuple[tuple[str, tuple[float, float]], ...] = ()
        if positions is not None:
            normalized_positions = tuple(
                (str(node), _normalized_position(position))
                for node, position in sorted(
                    positions.items(),
                    key=lambda item: str(item[0]),
                )
            )
        return cls(
            problem_id=problem_id,
            nodes=tuple(node for node, _ in weights),
            node_weights=weights,
            edges=_normalize_edges(edges),
            node_positions=normalized_positions,
            metadata={} if metadata is None else dict(metadata),
        )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> MWISProblemIR:
        """从 JSON 兼容字典恢复 MWIS 源模型。"""
        return cls(
            problem_id=str(data["problem_id"]),
            nodes=tuple(str(node) for node in data["nodes"]),
            # 保留数值的原始 JSON 类型，使 bool 或字符串篡改能被 validate() 发现。
            node_weights=tuple(
                (str(item[0]), item[1]) for item in data["node_weights"]
            ),
            edges=tuple(
                (str(edge[0]), str(edge[1])) for edge in data.get("edges", ())
            ),
            node_positions=tuple(
                (str(item[0]), (item[1][0], item[1][1]))
                for item in data.get("node_positions", ())
            ),
            graph_type=data.get("graph_type", "undirected"),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> MWISProblemIR:
        """从 JSON 对象恢复 MWIS 源模型。"""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("MWISProblemIR JSON must contain an object.")
        return cls.from_dict(data)

    def weight_by_node(self) -> dict[str, float]:
        """返回按节点 id 索引的权重。"""
        return dict(self.node_weights)

    def position_by_node(self) -> dict[str, tuple[float, float]]:
        """返回按节点 id 索引的二维位置。"""
        return dict(self.node_positions)

    def validate(self) -> tuple[DiagnosticsIR, ...]:
        """检查 MWIS 源事实，不在此阶段生成罚项或 QUBO。"""
        diagnostics: list[DiagnosticsIR] = []
        node_set = set(self.nodes)
        if not isinstance(self.problem_id, str) or not self.problem_id.strip():
            diagnostics.append(
                _mwis_diagnostic(
                    "MWIS_PROBLEM_ID_EMPTY",
                    "MWISProblemIR requires a non-empty problem_id.",
                    "mwis.problem_id",
                )
            )
        if not self.nodes:
            diagnostics.append(
                _mwis_diagnostic(
                    "MWIS_EMPTY",
                    "MWISProblemIR requires at least one node.",
                    "mwis.nodes",
                )
            )
        if len(node_set) != len(self.nodes):
            diagnostics.append(
                _mwis_diagnostic(
                    "MWIS_DUPLICATE_NODE",
                    "MWIS node identifiers must be unique.",
                    "mwis.nodes",
                )
            )
        if any(not isinstance(node, str) or not node for node in self.nodes):
            diagnostics.append(
                _mwis_diagnostic(
                    "MWIS_NODE_INVALID",
                    "MWIS node identifiers must be non-empty strings.",
                    "mwis.nodes",
                )
            )

        weight_nodes = tuple(node for node, _ in self.node_weights)
        if len(set(weight_nodes)) != len(weight_nodes):
            diagnostics.append(
                _mwis_diagnostic(
                    "MWIS_DUPLICATE_WEIGHT",
                    "MWIS node_weights must contain each node once.",
                    "mwis.node_weights",
                )
            )
        if set(weight_nodes) != node_set:
            diagnostics.append(
                _mwis_diagnostic(
                    "MWIS_WEIGHT_COVERAGE",
                    "MWIS node_weights must cover exactly the declared nodes.",
                    "mwis.node_weights",
                )
            )
        for node, weight in self.node_weights:
            if not _is_finite_real(weight) or float(weight) <= 0.0:
                diagnostics.append(
                    _mwis_diagnostic(
                        "MWIS_WEIGHT_INVALID",
                        "MWIS node weights must be finite positive numbers.",
                        f"mwis.node_weights.{node}",
                    )
                )

        normalized_edges: list[tuple[str, str]] = []
        for left, right in self.edges:
            normalized = tuple(sorted((left, right)))
            normalized_edges.append((normalized[0], normalized[1]))
            if left == right:
                diagnostics.append(
                    _mwis_diagnostic(
                        "MWIS_SELF_LOOP",
                        "MWIS does not support self-loop edges.",
                        f"mwis.edges.{left}",
                    )
                )
            if left not in node_set or right not in node_set:
                diagnostics.append(
                    _mwis_diagnostic(
                        "MWIS_EDGE_UNKNOWN_NODE",
                        "MWIS edge references an unknown node.",
                        f"mwis.edges.{left}.{right}",
                    )
                )
        if len(set(normalized_edges)) != len(normalized_edges):
            diagnostics.append(
                _mwis_diagnostic(
                    "MWIS_DUPLICATE_EDGE",
                    "MWIS edges must be unique after undirected normalization.",
                    "mwis.edges",
                )
            )

        position_nodes = tuple(node for node, _ in self.node_positions)
        if len(set(position_nodes)) != len(position_nodes):
            diagnostics.append(
                _mwis_diagnostic(
                    "MWIS_DUPLICATE_POSITION",
                    "MWIS node_positions must contain each node at most once.",
                    "mwis.node_positions",
                )
            )
        if self.node_positions and set(position_nodes) != node_set:
            diagnostics.append(
                _mwis_diagnostic(
                    "MWIS_POSITION_COVERAGE",
                    "MWIS positions must cover all nodes when provided.",
                    "mwis.node_positions",
                )
            )
        for node, position in self.node_positions:
            if not all(_is_finite_real(value) for value in position):
                diagnostics.append(
                    _mwis_diagnostic(
                        "MWIS_POSITION_INVALID",
                        "MWIS positions must contain finite real coordinates.",
                        f"mwis.node_positions.{node}",
                    )
                )
        if self.graph_type != "undirected":
            diagnostics.append(
                _mwis_diagnostic(
                    "MWIS_GRAPH_TYPE_UNSUPPORTED",
                    "MWISProblemIR supports only undirected graphs.",
                    "mwis.graph_type",
                )
            )
        return tuple(diagnostics)


@dataclass(frozen=True)
class QUBOProblemIR(IRMixin):
    """Quadratic binary objective with optional complete layout hints."""

    problem_id: str
    variables: tuple[str, ...]
    linear_terms: tuple[tuple[str, float], ...] = ()
    quadratic_terms: tuple[tuple[str, str, float], ...] = ()
    offset: float = 0.0
    variable_positions: tuple[tuple[str, tuple[float, float]], ...] = ()
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_terms(
        cls,
        *,
        problem_id: str,
        linear_terms: dict[str, float] | None = None,
        quadratic_terms: dict[tuple[str, str], float] | None = None,
        offset: float = 0.0,
        variables: list[str] | tuple[str, ...] | None = None,
        positions: dict[str, tuple[float, float]] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> QUBOProblemIR:
        """Build a deterministic QUBO problem from coefficient maps."""
        linear = {} if linear_terms is None else linear_terms
        quadratic = {} if quadratic_terms is None else quadratic_terms
        variable_set = {str(variable) for variable in linear}
        for left, right in quadratic:
            variable_set.add(str(left))
            variable_set.add(str(right))
        if variables is not None:
            variable_set.update(str(variable) for variable in variables)
        normalized_positions: tuple[tuple[str, tuple[float, float]], ...] = ()
        if positions is not None:
            normalized_positions = tuple(
                (str(variable), _normalized_position(position))
                for variable, position in sorted(
                    positions.items(),
                    key=lambda item: str(item[0]),
                )
            )
        return cls(
            problem_id=problem_id,
            variables=tuple(sorted(variable_set)),
            linear_terms=tuple(
                (str(variable), float(value))
                for variable, value in sorted(linear.items())
            ),
            quadratic_terms=_normalize_quadratic_terms(quadratic),
            offset=float(offset),
            variable_positions=normalized_positions,
            metadata={} if metadata is None else dict(metadata),
        )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> QUBOProblemIR:
        """Build QUBO problem IR from a dictionary."""
        return cls(
            problem_id=str(data["problem_id"]),
            variables=tuple(str(variable) for variable in data["variables"]),
            linear_terms=tuple(
                (str(term[0]), float(term[1]))
                for term in data.get("linear_terms", ())
            ),
            quadratic_terms=tuple(
                (str(term[0]), str(term[1]), float(term[2]))
                for term in data.get("quadratic_terms", ())
            ),
            offset=float(data.get("offset", 0.0)),
            variable_positions=tuple(
                (str(item[0]), (item[1][0], item[1][1]))
                for item in data.get("variable_positions", ())
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> QUBOProblemIR:
        """Build QUBO problem IR from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("QUBOProblemIR JSON must contain an object.")
        return cls.from_dict(data)

    def validate(self) -> tuple[DiagnosticsIR, ...]:
        """Return structural QUBO diagnostics."""
        diagnostics: list[DiagnosticsIR] = []
        variable_set = set(self.variables)
        if not self.variables:
            diagnostics.append(
                _diagnostic(
                    problem_type="qubo",
                    code="QUBO_EMPTY",
                    message="QUBOProblemIR requires at least one variable.",
                    object_path="qubo.variables",
                )
            )
        if len(variable_set) != len(self.variables):
            diagnostics.append(
                _diagnostic(
                    problem_type="qubo",
                    code="QUBO_DUPLICATE_VARIABLE",
                    message="QUBO variable identifiers must be unique.",
                    object_path="qubo.variables",
                )
            )
        for variable, _ in self.linear_terms:
            if variable not in variable_set:
                diagnostics.append(
                    _diagnostic(
                        problem_type="qubo",
                        code="QUBO_UNKNOWN_VARIABLE",
                        message="QUBO linear term references an unknown variable.",
                        object_path=f"qubo.linear_terms.{variable}",
                    )
                )
        for left, right, _ in self.quadratic_terms:
            if left == right:
                diagnostics.append(
                    _diagnostic(
                        problem_type="qubo",
                        code="QUBO_SELF_QUADRATIC_TERM",
                        message="QUBO quadratic terms must reference two variables.",
                        object_path=f"qubo.quadratic_terms.{left}",
                    )
                )
            if left not in variable_set or right not in variable_set:
                diagnostics.append(
                    _diagnostic(
                        problem_type="qubo",
                        code="QUBO_UNKNOWN_VARIABLE",
                        message="QUBO quadratic term references an unknown variable.",
                        object_path=f"qubo.quadratic_terms.{left}.{right}",
                    )
                )
        position_variables = tuple(
            variable for variable, _ in self.variable_positions
        )
        if len(set(position_variables)) != len(position_variables):
            diagnostics.append(
                _diagnostic(
                    problem_type="qubo",
                    code="QUBO_DUPLICATE_POSITION",
                    message=(
                        "QUBO variable_positions must contain each variable at "
                        "most once."
                    ),
                    object_path="qubo.variable_positions",
                )
            )
        if self.variable_positions and set(position_variables) != variable_set:
            diagnostics.append(
                _diagnostic(
                    problem_type="qubo",
                    code="QUBO_POSITION_COVERAGE",
                    message="QUBO positions must cover all variables when provided.",
                    object_path="qubo.variable_positions",
                )
            )
        for variable, position in self.variable_positions:
            if len(position) != 2 or not all(
                _is_finite_real(value) for value in position
            ):
                diagnostics.append(
                    _diagnostic(
                        problem_type="qubo",
                        code="QUBO_POSITION_INVALID",
                        message=(
                            "QUBO positions must contain two finite real "
                            "coordinates."
                        ),
                        object_path=f"qubo.variable_positions.{variable}",
                    )
                )
        return tuple(diagnostics)

    def position_by_variable(self) -> dict[str, tuple[float, float]]:
        """Return optional reference-layout positions keyed by variable id."""
        return dict(self.variable_positions)

    def to_ising_model(self) -> IsingModelIR:
        """Convert binary QUBO coefficients into an Ising objective summary."""
        field_values = {variable: 0.0 for variable in self.variables}
        coupling_values: dict[tuple[str, str], float] = {}
        constant = self.offset
        for variable, value in self.linear_terms:
            constant += value / 2.0
            field_values[variable] = field_values.get(variable, 0.0) + value / 2.0
        for left, right, value in self.quadratic_terms:
            constant += value / 4.0
            field_values[left] = field_values.get(left, 0.0) + value / 4.0
            field_values[right] = field_values.get(right, 0.0) + value / 4.0
            coupling_values[(left, right)] = (
                coupling_values.get((left, right), 0.0) + value / 4.0
            )
        return IsingModelIR(
            problem_id=f"ising.from.{self.problem_id}",
            spins=self.variables,
            fields=tuple(
                (spin, field_values[spin])
                for spin in self.variables
                if field_values.get(spin, 0.0) != 0.0
            ),
            couplings=tuple(
                (left, right, value)
                for (left, right), value in sorted(coupling_values.items())
                if value != 0.0
            ),
            offset=constant,
            metadata={
                "source_problem_id": self.problem_id,
                "source_problem_type": "qubo",
                "source_problem_hash": self.stable_hash(),
                "binary_to_spin_convention": "x = (1 + s) / 2",
            },
        )

    def result_decoding_metadata(self) -> ProblemResultDecodingIR:
        """Return result decoding metadata for QUBO bitstrings."""
        return ProblemResultDecodingIR(
            decoding_id=f"decode.{self.problem_id}",
            problem_id=self.problem_id,
            problem_type="qubo",
            source_problem_hash=self.stable_hash(),
            variable_order=self.variables,
            bitstring_convention="bit value maps to binary variable x in order",
        )

    def objective_candidate(self) -> ProblemCandidateIR:
        """Return a QUBO objective summary candidate."""
        return build_qubo_objective_candidate(self)


@dataclass(frozen=True)
class IsingModelIR(IRMixin):
    """Ising objective model contract."""

    problem_id: str
    spins: tuple[str, ...]
    fields: tuple[tuple[str, float], ...] = ()
    couplings: tuple[tuple[str, str, float], ...] = ()
    offset: float = 0.0
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_terms(
        cls,
        *,
        problem_id: str,
        fields: dict[str, float] | None = None,
        couplings: dict[tuple[str, str], float] | None = None,
        offset: float = 0.0,
        spins: list[str] | tuple[str, ...] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> IsingModelIR:
        """Build a deterministic Ising model from coefficient maps."""
        field_map = {} if fields is None else fields
        coupling_map = {} if couplings is None else couplings
        spin_set = {str(spin) for spin in field_map}
        for left, right in coupling_map:
            spin_set.add(str(left))
            spin_set.add(str(right))
        if spins is not None:
            spin_set.update(str(spin) for spin in spins)
        return cls(
            problem_id=problem_id,
            spins=tuple(sorted(spin_set)),
            fields=tuple(
                (str(spin), float(value))
                for spin, value in sorted(field_map.items())
            ),
            couplings=_normalize_quadratic_terms(coupling_map),
            offset=float(offset),
            metadata={} if metadata is None else dict(metadata),
        )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> IsingModelIR:
        """Build Ising model IR from a dictionary."""
        return cls(
            problem_id=str(data["problem_id"]),
            spins=tuple(str(spin) for spin in data["spins"]),
            fields=tuple(
                (str(term[0]), float(term[1])) for term in data.get("fields", ())
            ),
            couplings=tuple(
                (str(term[0]), str(term[1]), float(term[2]))
                for term in data.get("couplings", ())
            ),
            offset=float(data.get("offset", 0.0)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> IsingModelIR:
        """Build Ising model IR from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("IsingModelIR JSON must contain an object.")
        return cls.from_dict(data)

    def validate(self) -> tuple[DiagnosticsIR, ...]:
        """Return structural Ising diagnostics."""
        diagnostics: list[DiagnosticsIR] = []
        spin_set = set(self.spins)
        if not self.spins:
            diagnostics.append(
                _diagnostic(
                    problem_type="ising",
                    code="ISING_EMPTY",
                    message="IsingModelIR requires at least one spin.",
                    object_path="ising.spins",
                )
            )
        if len(spin_set) != len(self.spins):
            diagnostics.append(
                _diagnostic(
                    problem_type="ising",
                    code="ISING_DUPLICATE_SPIN",
                    message="Ising spin identifiers must be unique.",
                    object_path="ising.spins",
                )
            )
        for spin, _ in self.fields:
            if spin not in spin_set:
                diagnostics.append(
                    _diagnostic(
                        problem_type="ising",
                        code="ISING_UNKNOWN_SPIN",
                        message="Ising field references an unknown spin.",
                        object_path=f"ising.fields.{spin}",
                    )
                )
        for left, right, _ in self.couplings:
            if left == right:
                diagnostics.append(
                    _diagnostic(
                        problem_type="ising",
                        code="ISING_SELF_COUPLING",
                        message="Ising couplings must reference two spins.",
                        object_path=f"ising.couplings.{left}",
                    )
                )
            if left not in spin_set or right not in spin_set:
                diagnostics.append(
                    _diagnostic(
                        problem_type="ising",
                        code="ISING_UNKNOWN_SPIN",
                        message="Ising coupling references an unknown spin.",
                        object_path=f"ising.couplings.{left}.{right}",
                    )
                )
        return tuple(diagnostics)

    def to_ahs_candidate_metadata(self) -> dict[str, Any]:
        """Return candidate AHS metadata without layout or schedule claims."""
        return {
            "problem_type": "ising",
            "problem_id": self.problem_id,
            "source_problem_hash": self.metadata.get(
                "source_problem_hash",
                self.stable_hash(),
            ),
            "source_problem_id": self.metadata.get(
                "source_problem_id",
                self.problem_id,
            ),
            "spin_order": list(self.spins),
            "field_terms": [
                {"spin": spin, "coefficient": coefficient}
                for spin, coefficient in self.fields
            ],
            "coupling_terms": [
                {"left": left, "right": right, "coefficient": coefficient}
                for left, right, coefficient in self.couplings
            ],
            "offset": self.offset,
            "layout_status": "not_generated",
            "schedule_status": "not_generated",
            "optimizer_status": "not_requested",
            "limitations": [
                "No optimal atom layout is claimed.",
                "No pulse schedule is generated.",
                "This metadata candidate does not run or select a QAOA/VQE optimizer.",
            ],
        }

    def result_decoding_metadata(self) -> ProblemResultDecodingIR:
        """Return result decoding metadata for Ising spin bitstrings."""
        return ProblemResultDecodingIR(
            decoding_id=f"decode.{self.problem_id}",
            problem_id=self.problem_id,
            problem_type="ising",
            source_problem_hash=self.metadata.get(
                "source_problem_hash",
                self.stable_hash(),
            ),
            variable_order=self.spins,
            bitstring_convention="0 maps to spin -1, 1 maps to spin +1",
        )

    def objective_candidate(self) -> ProblemCandidateIR:
        """Return an Ising objective summary candidate."""
        return build_ising_objective_candidate(self)


def build_graph_layout_candidate(
    graph: GraphProblemIR,
    *,
    layout: Literal["line", "grid"] = "line",
    spacing: float = 5.0,
    columns: int | None = None,
) -> ProblemCandidateIR:
    """Build a deterministic graph layout candidate without optimization."""
    if not isinstance(graph, GraphProblemIR):
        raise TypeError("build_graph_layout_candidate accepts GraphProblemIR.")
    if layout not in {"line", "grid"}:
        raise ValueError("layout must be 'line' or 'grid'.")
    if spacing <= 0.0:
        raise ValueError("spacing must be positive.")
    positions = (
        _line_layout(graph.nodes, spacing=spacing)
        if layout == "line"
        else _grid_layout(graph.nodes, spacing=spacing, columns=columns)
    )
    return ProblemCandidateIR(
        candidate_id=f"candidate.{graph.problem_id}.{layout}_layout",
        candidate_kind="graph_layout",
        problem_id=graph.problem_id,
        problem_type="graph",
        source_problem_hash=graph.stable_hash(),
        payload={
            "layout": layout,
            "positions": [
                {"node": node, "x": position[0], "y": position[1]}
                for node, position in positions.items()
            ],
            "edges": [
                {"left": left, "right": right} for left, right in graph.edges
            ],
            "spacing": spacing,
            "columns": columns if layout == "grid" else None,
            "layout_optimality": "not_claimed",
            "schedule_status": "not_generated",
        },
        diagnostics=(
            _candidate_diagnostic(
                code="PROBLEM_OPTIMIZER_UNSUPPORTED",
                message="Graph layout candidate is deterministic and not optimized.",
                metadata={"layout": layout},
            ),
            _candidate_diagnostic(
                code="PROBLEM_SCHEDULER_UNSUPPORTED",
                message="Problem candidate does not generate a pulse schedule.",
                metadata={"layout": layout},
            ),
        ),
        metadata={
            "source_problem_id": graph.problem_id,
            "candidate_role": "experiment_readiness_metadata",
            "optimality_claim": "not_claimed",
        },
    )


def build_qubo_objective_candidate(qubo: QUBOProblemIR) -> ProblemCandidateIR:
    """Build a QUBO objective summary candidate without solving it."""
    if not isinstance(qubo, QUBOProblemIR):
        raise TypeError("build_qubo_objective_candidate accepts QUBOProblemIR.")
    return ProblemCandidateIR(
        candidate_id=f"candidate.{qubo.problem_id}.objective_summary",
        candidate_kind="qubo_objective_summary",
        problem_id=qubo.problem_id,
        problem_type="qubo",
        source_problem_hash=qubo.stable_hash(),
        payload={
            "variable_order": list(qubo.variables),
            "linear_term_count": len(qubo.linear_terms),
            "quadratic_term_count": len(qubo.quadratic_terms),
            "offset": qubo.offset,
            "linear_terms": [
                {"variable": variable, "coefficient": coefficient}
                for variable, coefficient in qubo.linear_terms
            ],
            "quadratic_terms": [
                {
                    "left": left,
                    "right": right,
                    "coefficient": coefficient,
                }
                for left, right, coefficient in qubo.quadratic_terms
            ],
            "optimizer_status": "not_generated",
            "schedule_status": "not_generated",
        },
        diagnostics=(
            _candidate_diagnostic(
                code="PROBLEM_OPTIMIZER_UNSUPPORTED",
                message="QUBO objective candidate is not an optimizer result.",
                metadata={"problem_type": "qubo"},
            ),
            _candidate_diagnostic(
                code="PROBLEM_SCHEDULER_UNSUPPORTED",
                message="QUBO objective candidate does not generate a schedule.",
                metadata={"problem_type": "qubo"},
            ),
        ),
        metadata={
            "source_problem_id": qubo.problem_id,
            "candidate_role": "objective_summary",
            "optimality_claim": "not_claimed",
        },
    )


def build_ising_objective_candidate(ising: IsingModelIR) -> ProblemCandidateIR:
    """Build an Ising objective summary candidate without solving it."""
    if not isinstance(ising, IsingModelIR):
        raise TypeError("build_ising_objective_candidate accepts IsingModelIR.")
    source_hash = str(ising.metadata.get("source_problem_hash", ising.stable_hash()))
    return ProblemCandidateIR(
        candidate_id=f"candidate.{ising.problem_id}.objective_summary",
        candidate_kind="ising_objective_summary",
        problem_id=ising.problem_id,
        problem_type="ising",
        source_problem_hash=source_hash,
        payload={
            "spin_order": list(ising.spins),
            "field_term_count": len(ising.fields),
            "coupling_term_count": len(ising.couplings),
            "offset": ising.offset,
            "fields": [
                {"spin": spin, "coefficient": coefficient}
                for spin, coefficient in ising.fields
            ],
            "couplings": [
                {
                    "left": left,
                    "right": right,
                    "coefficient": coefficient,
                }
                for left, right, coefficient in ising.couplings
            ],
            "layout_status": "not_generated",
            "optimizer_status": "not_generated",
            "schedule_status": "not_generated",
        },
        diagnostics=(
            _candidate_diagnostic(
                code="PROBLEM_OPTIMIZER_UNSUPPORTED",
                message="Ising objective candidate is not an optimizer result.",
                metadata={"problem_type": "ising"},
            ),
            _candidate_diagnostic(
                code="PROBLEM_SCHEDULER_UNSUPPORTED",
                message="Ising objective candidate does not generate a schedule.",
                metadata={"problem_type": "ising"},
            ),
        ),
        metadata={
            "source_problem_id": ising.metadata.get(
                "source_problem_id",
                ising.problem_id,
            ),
            "candidate_role": "objective_summary",
            "optimality_claim": "not_claimed",
        },
    )


def decode_graph_bitstring(
    graph: GraphProblemIR,
    bitstring: str,
) -> dict[str, Any]:
    """Decode a graph bitstring into selected nodes and edge violations."""
    if not isinstance(graph, GraphProblemIR):
        raise TypeError("decode_graph_bitstring accepts GraphProblemIR.")
    if len(bitstring) != len(graph.nodes):
        raise ValueError("bitstring length must match graph node count.")
    selected = tuple(
        node for node, bit in zip(graph.nodes, bitstring) if bit == "1"
    )
    selected_set = set(selected)
    violating_edges = tuple(
        edge
        for edge in graph.edges
        if edge[0] in selected_set and edge[1] in selected_set
    )
    return {
        "problem_id": graph.problem_id,
        "problem_type": "graph",
        "source_problem_hash": graph.stable_hash(),
        "bitstring": bitstring,
        "variable_order": graph.nodes,
        "selected_nodes": selected,
        "selection_size": len(selected),
        "is_independent": not violating_edges,
        "violating_edges": violating_edges,
        "decoding": graph.result_decoding_metadata().to_dict(),
    }


def decode_mis_result(
    graph_or_decoding: GraphProblemIR | ProblemResultDecodingIR,
    bitstring: str,
) -> dict[str, Any]:
    """Decode MIS/graph result bitstrings with provenance metadata."""
    if isinstance(graph_or_decoding, GraphProblemIR):
        return decode_graph_bitstring(graph_or_decoding, bitstring)
    if isinstance(graph_or_decoding, ProblemResultDecodingIR):
        if graph_or_decoding.problem_type != "graph":
            raise ValueError("decode_mis_result requires graph decoding metadata.")
        if len(bitstring) != len(graph_or_decoding.variable_order):
            raise ValueError("bitstring length must match variable order.")
        selected = tuple(
            node
            for node, bit in zip(graph_or_decoding.variable_order, bitstring)
            if bit == "1"
        )
        return {
            "problem_id": graph_or_decoding.problem_id,
            "problem_type": graph_or_decoding.problem_type,
            "source_problem_hash": graph_or_decoding.source_problem_hash,
            "bitstring": bitstring,
            "variable_order": graph_or_decoding.variable_order,
            "selected_nodes": selected,
            "selection_size": len(selected),
            "is_independent": None,
            "violating_edges": None,
            "decoding": graph_or_decoding.to_dict(),
            "validation_status": "requires_graph_edges",
        }
    raise TypeError("decode_mis_result accepts GraphProblemIR or decoding metadata.")


def diagnose_mis_decode(
    graph_or_decoding: GraphProblemIR | ProblemResultDecodingIR,
    bitstring: str,
) -> dict[str, Any]:
    """Return deterministic diagnostics for MIS/graph result decoding."""
    try:
        decoded = decode_mis_result(graph_or_decoding, bitstring)
    except (TypeError, ValueError) as exc:
        return _decode_diagnostic_payload(
            graph_or_decoding,
            bitstring,
            status="invalid",
            diagnostic_code=_decode_error_code(exc),
            message=str(exc),
        )
    status = (
        "metadata_only"
        if decoded.get("validation_status") == "requires_graph_edges"
        else "valid"
    )
    diagnostic_code = (
        "MIS_DECODE_REQUIRES_GRAPH_EDGES"
        if status == "metadata_only"
        else "MIS_DECODE_VALID"
    )
    return {
        "status": status,
        "diagnostic_code": diagnostic_code,
        "problem_id": decoded["problem_id"],
        "problem_type": decoded["problem_type"],
        "bitstring": decoded["bitstring"],
        "variable_order": decoded["variable_order"],
        "selected_nodes": decoded["selected_nodes"],
        "is_independent": decoded.get("is_independent"),
        "validation_status": decoded.get("validation_status", "validated"),
        "hardware_execution": False,
        "cloud_execution": False,
        "optimality_claim": "not_claimed",
    }


def build_problem_result_provenance(
    graph_or_decoding: GraphProblemIR | ProblemResultDecodingIR,
    decoded: dict[str, Any],
    *,
    batch_result: Any | None = None,
    batch_item_index: int | None = None,
    parameter_bind_id: str | None = None,
    parameter_bind_hash: str | None = None,
    result_id: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> ProblemResultProvenanceIR:
    """Build provenance metadata for a decoded graph/MIS result."""
    decoding = _decoding_from_source(graph_or_decoding)
    bitstring = str(decoded["bitstring"])
    if tuple(decoded.get("variable_order", ())) != decoding.variable_order:
        raise ValueError("decoded variable_order must match source decoding metadata.")

    item = _batch_result_item(batch_result, batch_item_index)
    batch_metadata = {} if batch_result is None else dict(batch_result.metadata)
    execution_boundary = dict(batch_metadata.get("execution_boundary", {}))
    selected_nodes = tuple(str(node) for node in decoded.get("selected_nodes", ()))
    decoder_status = str(
        decoded.get(
            "validation_status",
            "validated" if decoded.get("is_independent") is not None else "unknown",
        )
    )

    return ProblemResultProvenanceIR(
        provenance_id=f"provenance.{decoding.problem_id}.{bitstring}",
        problem_id=decoding.problem_id,
        problem_type=decoding.problem_type,
        source_problem_hash=decoding.source_problem_hash,
        bitstring=bitstring,
        variable_order=decoding.variable_order,
        decoded_selected_nodes=selected_nodes,
        decoder_status=decoder_status,
        parameter_bind_id=_first_not_none(
            parameter_bind_id,
            None if item is None else item.parameter_bind_id,
        ),
        parameter_bind_hash=_first_not_none(
            parameter_bind_hash,
            None if item is None else item.parameter_bind_hash,
        ),
        batch_id=None if batch_result is None else batch_result.batch_id,
        batch_item_index=None if item is None else item.item_index,
        batch_item_status=None if item is None else item.status,
        result_id=_first_not_none(result_id, None if item is None else item.result_id),
        execution_package_id=None if item is None else item.execution_package_id,
        hardware_execution=bool(execution_boundary.get("hardware_execution", False)),
        cloud_execution=bool(execution_boundary.get("cloud_execution", False)),
        metadata_only=bool(execution_boundary.get("metadata_only", True)),
        metadata={
            "source": "problem_result_provenance",
            "decoded_is_independent": decoded.get("is_independent"),
            "decoded_selection_size": decoded.get("selection_size"),
            "optimality_claimed": False,
            **({} if metadata is None else metadata),
        },
    )


def explain_problem_sweep_result(
    graph_or_decoding: GraphProblemIR | ProblemResultDecodingIR,
    bitstring: str,
    *,
    sweep_result: Any | None = None,
    batch_result: Any | None = None,
    batch_item_index: int | None = None,
    sweep_summary: Any | None = None,
    parameter_bind_id: str | None = None,
    parameter_bind_hash: str | None = None,
    result_id: str | None = None,
    explanation_id: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> ProblemSweepExplanationIR:
    """Compose decoded result, provenance, summary, and diagnostics metadata."""
    decoded = decode_mis_result(graph_or_decoding, bitstring)
    provenance = build_problem_result_provenance(
        graph_or_decoding,
        decoded,
        batch_result=batch_result,
        batch_item_index=batch_item_index,
        parameter_bind_id=parameter_bind_id,
        parameter_bind_hash=parameter_bind_hash,
        result_id=result_id,
    )
    diagnostics = diagnose_mis_decode(graph_or_decoding, bitstring)
    summary = sweep_summary
    if summary is None and sweep_result is not None:
        from cascaqit.sweep import build_sweep_result_summary

        summary = build_sweep_result_summary(
            sweep_result,
            batch_result=batch_result,
            provenances=(provenance,),
        )

    summary_dict = None if summary is None else summary.to_dict()
    diagnostic_codes = _explanation_diagnostic_codes(diagnostics, summary)
    status = _explanation_status(diagnostics, summary)
    return ProblemSweepExplanationIR(
        explanation_id=explanation_id
        or f"problem_sweep_explanation.{provenance.problem_id}.{bitstring}",
        problem_id=provenance.problem_id,
        problem_type=provenance.problem_type,
        sweep_id=None if summary is None else summary.sweep_id,
        batch_id=provenance.batch_id,
        bitstring=bitstring,
        decoded=_json_object(decoded),
        provenance=provenance,
        sweep_summary=summary_dict,
        decoder_diagnostics=_json_object(diagnostics),
        diagnostic_codes=diagnostic_codes,
        status=status,
        metadata_only=provenance.metadata_only
        and (True if summary is None else summary.metadata_only),
        hardware_execution=provenance.hardware_execution
        or (False if summary is None else summary.hardware_execution),
        cloud_execution=provenance.cloud_execution
        or (False if summary is None else summary.cloud_execution),
        metadata={
            "source": "problem_sweep_explanation",
            "optimizer_result": False,
            "optimality_claimed": False,
            "summary_present": summary is not None,
            **({} if metadata is None else metadata),
        },
    )


def build_optimizer_problem_provenance_bridge(
    graph_or_decoding: GraphProblemIR | ProblemResultDecodingIR,
    optimizer_result: Any,
    *,
    batch_result: Any | None = None,
    metadata: dict[str, Any] | None = None,
) -> ProblemResultProvenanceIR:
    """Build provenance for an optimizer's observed best decoded candidate."""
    if optimizer_result.best_trial_id is None:
        raise ValueError("optimizer_result requires best_trial_id.")
    best_trial = _optimizer_best_trial(optimizer_result)
    if best_trial.decoded_bitstring is None:
        raise ValueError("optimizer best trial requires decoded_bitstring.")
    decoded = decode_mis_result(graph_or_decoding, best_trial.decoded_bitstring)
    return build_problem_result_provenance(
        graph_or_decoding,
        decoded,
        batch_result=batch_result,
        batch_item_index=None if batch_result is None else best_trial.batch_item_index,
        parameter_bind_id=best_trial.parameter_bind_id,
        parameter_bind_hash=best_trial.parameter_bind_hash,
        result_id=best_trial.result_id,
        metadata={
            "source": "optimizer_problem_provenance_bridge",
            "optimizer_run_id": optimizer_result.optimizer_run_id,
            "optimizer_best_trial_id": best_trial.trial_id,
            "objective_name": optimizer_result.objective_name,
            "objective_value": best_trial.objective_value,
            "objective_source_ids": (),
            "constraint_violation_ids": tuple(
                violation.violation_id
                for trial in optimizer_result.trials
                for violation in getattr(trial, "constraint_violations", ())
            ),
            "round_ids": tuple(
                round_item.round_id
                for round_item in getattr(optimizer_result, "rounds", ())
            ),
            "result_linkback": {
                "result_id": best_trial.result_id,
                "best_trial_id": best_trial.trial_id,
                "parameter_bind_id": best_trial.parameter_bind_id,
                "parameter_bind_hash": best_trial.parameter_bind_hash,
            },
            "best_candidate_kind": "observed_best_candidate",
            "optimality_claim": "not_claimed",
            "convergence_claim": "not_claimed",
            "artifact_bytes_read": False,
            "object_store_accessed": False,
            "signed_url_issued": False,
            **({} if metadata is None else metadata),
        },
    )


def _decoding_from_source(
    graph_or_decoding: GraphProblemIR | ProblemResultDecodingIR,
) -> ProblemResultDecodingIR:
    if isinstance(graph_or_decoding, GraphProblemIR):
        return graph_or_decoding.result_decoding_metadata()
    if isinstance(graph_or_decoding, ProblemResultDecodingIR):
        if graph_or_decoding.problem_type != "graph":
            raise ValueError("problem result provenance requires graph decoding.")
        return graph_or_decoding
    raise TypeError(
        "build_problem_result_provenance accepts GraphProblemIR or decoding metadata."
    )


def _batch_result_item(batch_result: Any | None, index: int | None) -> Any | None:
    if batch_result is None:
        if index is not None:
            raise ValueError("batch_item_index requires batch_result.")
        return None
    if index is None:
        return None
    if index < 0 or index >= len(batch_result.items):
        raise ValueError("batch_item_index is outside batch_result items.")
    return batch_result.items[index]


def _first_not_none(first: str | None, second: str | None) -> str | None:
    return first if first is not None else second


def _optimizer_best_trial(optimizer_result: Any) -> Any:
    for trial in optimizer_result.trials:
        if trial.trial_id == optimizer_result.best_trial_id:
            return trial
    raise ValueError("optimizer best trial is missing from trials.")


def _decode_diagnostic_payload(
    graph_or_decoding: Any,
    bitstring: str,
    *,
    status: str,
    diagnostic_code: str,
    message: str,
) -> dict[str, Any]:
    problem_id = getattr(graph_or_decoding, "problem_id", None)
    problem_type = getattr(graph_or_decoding, "problem_type", None)
    variable_order = getattr(graph_or_decoding, "variable_order", None)
    if isinstance(graph_or_decoding, GraphProblemIR):
        problem_type = "graph"
        variable_order = graph_or_decoding.nodes
    return {
        "status": status,
        "diagnostic_code": diagnostic_code,
        "message": message,
        "problem_id": problem_id,
        "problem_type": problem_type,
        "bitstring": bitstring,
        "variable_order": variable_order,
        "hardware_execution": False,
        "cloud_execution": False,
        "optimality_claim": "not_claimed",
    }


def _decode_error_code(exc: Exception) -> str:
    message = str(exc)
    if "length" in message:
        return "MIS_DECODE_BITSTRING_LENGTH_MISMATCH"
    if "graph decoding" in message:
        return "MIS_DECODE_UNSUPPORTED_DECODING_METADATA"
    if "GraphProblemIR or decoding" in message:
        return "MIS_DECODE_UNSUPPORTED_INPUT"
    return "MIS_DECODE_INVALID_INPUT"


def _json_object(value: dict[str, Any]) -> dict[str, Any]:
    data = canonicalize(value)
    if not isinstance(data, dict):
        raise TypeError("Expected a JSON object.")
    return data


def _explanation_diagnostic_codes(
    diagnostics: dict[str, Any],
    summary: Any | None,
) -> tuple[str, ...]:
    codes: list[str] = [str(diagnostics["diagnostic_code"])]
    if summary is not None:
        codes.extend(str(code) for code in summary.diagnostic_codes)
    return tuple(dict.fromkeys(codes))


def _explanation_status(
    diagnostics: dict[str, Any],
    summary: Any | None,
) -> str:
    if diagnostics.get("status") == "invalid":
        return "invalid_decode"
    if summary is not None and summary.failed_count:
        return "partial_failed"
    if diagnostics.get("status") == "metadata_only":
        return "metadata_only"
    return "explained"


def _normalize_edges(
    edges: list[tuple[str, str]] | tuple[tuple[str, str], ...],
) -> tuple[tuple[str, str], ...]:
    normalized: set[tuple[str, str]] = set()
    for left, right in edges:
        ordered = tuple(sorted((str(left), str(right))))
        normalized.add((ordered[0], ordered[1]))
    return tuple(sorted(normalized))


def _normalized_positive_weight(value: object) -> float:
    if (
        not isinstance(value, (int, float))
        or isinstance(value, bool)
        or not math.isfinite(value)
    ):
        raise TypeError("MWIS node weights must be finite real numbers.")
    normalized = float(value)
    if normalized <= 0.0:
        raise ValueError("MWIS node weights must be positive.")
    return normalized


def _normalized_position(position: tuple[float, float]) -> tuple[float, float]:
    if len(position) != 2 or not all(_is_finite_real(value) for value in position):
        raise ValueError("Problem positions must contain two finite real coordinates.")
    return (float(position[0]), float(position[1]))


def _is_finite_real(value: object) -> bool:
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        return False
    return math.isfinite(value)


def _normalize_quadratic_terms(
    terms: dict[tuple[str, str], float],
) -> tuple[tuple[str, str, float], ...]:
    normalized: dict[tuple[str, str], float] = {}
    for (left, right), value in terms.items():
        ordered = tuple(sorted((str(left), str(right))))
        key = (ordered[0], ordered[1])
        normalized[key] = normalized.get(key, 0.0) + float(value)
    return tuple(
        (left, right, value)
        for (left, right), value in sorted(normalized.items())
    )


def _line_layout(
    nodes: tuple[str, ...],
    *,
    spacing: float,
) -> dict[str, tuple[float, float]]:
    return {
        node: (float(index) * spacing, 0.0)
        for index, node in enumerate(nodes)
    }


def _grid_layout(
    nodes: tuple[str, ...],
    *,
    spacing: float,
    columns: int | None,
) -> dict[str, tuple[float, float]]:
    if not nodes:
        return {}
    column_count = (
        _default_grid_columns(len(nodes)) if columns is None else columns
    )
    if column_count <= 0:
        raise ValueError("columns must be positive.")
    return {
        node: (
            float(index % column_count) * spacing,
            float(index // column_count) * spacing,
        )
        for index, node in enumerate(nodes)
    }


def _default_grid_columns(count: int) -> int:
    columns = 1
    while columns * columns < count:
        columns += 1
    return columns


def _diagnostic(
    *,
    problem_type: str,
    code: str,
    message: str,
    object_path: str,
) -> DiagnosticsIR:
    return DiagnosticsIR(
        diagnostic_id=f"problem.{problem_type}.{code.lower()}",
        stage="validation",
        severity="error",
        code=code,
        message=message,
        object_path=object_path,
    )


def _mwis_diagnostic(code: str, message: str, object_path: str) -> DiagnosticsIR:
    return _diagnostic(
        problem_type="mwis",
        code=code,
        message=message,
        object_path=object_path,
    )


def _candidate_diagnostic(
    *,
    code: str,
    message: str,
    metadata: dict[str, Any] | None = None,
) -> DiagnosticsIR:
    return DiagnosticsIR(
        diagnostic_id=f"problem.candidate.{code.lower()}",
        stage="validation",
        severity="warning",
        code=code,
        message=message,
        object_path="problem_candidate",
        suggestion=(
            "Treat this candidate as inspectable metadata until an optimizer "
            "or scheduler is implemented."
        ),
        metadata={} if metadata is None else dict(metadata),
    )
