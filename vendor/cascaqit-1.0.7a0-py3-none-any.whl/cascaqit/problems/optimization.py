"""Classical objective semantics for supported optimization problems."""

from __future__ import annotations

import math
from typing import Union

from cascaqit.problems.mis import MISInstance
from cascaqit.problems.models import (
    GraphProblemIR,
    IsingModelIR,
    MWISProblemIR,
    QUBOProblemIR,
)

__all__ = [
    "OptimizationProblem",
    "evaluate_ising_bitstring",
    "evaluate_mwis_bitstring",
    "evaluate_problem_bitstring",
    "evaluate_qubo_bitstring",
    "mis_to_qubo",
    "mwis_to_qubo",
    "mwis_penalty_threshold",
    "resolve_mwis_penalty",
]

OptimizationProblem = Union[
    GraphProblemIR,
    MISInstance,
    MWISProblemIR,
    QUBOProblemIR,
    IsingModelIR,
]

DEFAULT_MIS_PENALTY = 2.0
DEFAULT_EDGELESS_MWIS_PENALTY = 1.0


def mwis_penalty_threshold(problem: MWISProblemIR) -> float:
    """返回统一 MWIS 罚项在删点证明下必须严格超过的阈值。"""
    if not isinstance(problem, MWISProblemIR):
        raise TypeError("mwis_penalty_threshold requires MWISProblemIR.")
    _require_valid_problem(problem, "MWIS")
    weights = problem.weight_by_node()
    return max(
        (min(weights[left], weights[right]) for left, right in problem.edges),
        default=0.0,
    )


def resolve_mwis_penalty(
    problem: MWISProblemIR,
    *,
    penalty: float | None = None,
) -> float:
    """校验显式 MWIS 罚项，或从源权重生成确定性的默认值。"""
    threshold = mwis_penalty_threshold(problem)
    if penalty is None:
        normalized = (
            DEFAULT_EDGELESS_MWIS_PENALTY if not problem.edges else 2.0 * threshold
        )
        if not math.isfinite(normalized) or normalized <= threshold:
            raise ValueError(
                "Default MWIS penalty cannot be represented as a finite value "
                "strictly above the weighted vertex-removal threshold."
            )
    else:
        normalized = _finite(penalty, "MWIS penalty")
    if normalized <= 0.0:
        raise ValueError("MWIS penalty must be positive.")
    if normalized <= threshold:
        raise ValueError(
            "MWIS penalty must be strictly greater than "
            f"{threshold:g}, the weighted vertex-removal threshold."
        )
    return normalized


def mis_to_qubo(
    problem: MISInstance,
    *,
    penalty: float = DEFAULT_MIS_PENALTY,
    problem_id: str | None = None,
) -> QUBOProblemIR:
    """Build the standard penalized minimization QUBO for one MIS instance."""
    if not isinstance(problem, MISInstance):
        raise TypeError("mis_to_qubo requires MISInstance.")
    _require_valid_problem(problem, "MIS")
    normalized_penalty = _mis_penalty(penalty)
    source_id, source_hash, source_type = _source_problem_identity(problem)
    return QUBOProblemIR.from_terms(
        problem_id=problem_id or f"qubo.mis.{source_id}",
        variables=problem.node_order(),
        linear_terms={node: -1.0 for node in problem.node_order()},
        quadratic_terms={edge: normalized_penalty for edge in problem.edges},
        metadata={
            "source_problem_id": source_id,
            "source_problem_hash": source_hash,
            "source_problem_type": source_type,
            "problem_semantics": "maximum_independent_set",
            "objective_direction": "minimize",
            "mis_penalty": normalized_penalty,
            "mis_objective": "-sum(x_i) + penalty*sum_edges(x_i*x_j)",
        },
    )


def mwis_to_qubo(
    problem: MWISProblemIR,
    *,
    penalty: float | None = None,
    problem_id: str | None = None,
) -> QUBOProblemIR:
    """构造保留 MWIS 业务权重的带罚项 QUBO。"""
    if not isinstance(problem, MWISProblemIR):
        raise TypeError("mwis_to_qubo requires MWISProblemIR.")
    _require_valid_problem(problem, "MWIS")
    normalized_penalty = resolve_mwis_penalty(problem, penalty=penalty)
    return QUBOProblemIR.from_terms(
        problem_id=problem_id or f"qubo.mwis.{problem.problem_id}",
        variables=problem.nodes,
        linear_terms={node: -weight for node, weight in problem.node_weights},
        quadratic_terms={edge: normalized_penalty for edge in problem.edges},
        metadata={
            "source_problem_id": problem.problem_id,
            "source_problem_hash": problem.stable_hash(),
            "source_problem_type": "mwis",
            "problem_semantics": "maximum_weighted_independent_set",
            "objective_direction": "minimize",
            "mwis_penalty": normalized_penalty,
            "mwis_objective": "-sum(w_i*x_i) + penalty*sum_edges(x_i*x_j)",
        },
    )


def evaluate_qubo_bitstring(problem: QUBOProblemIR, bitstring: str) -> float:
    """Evaluate a QUBO with bits mapped to variables in declared order."""
    if not isinstance(problem, QUBOProblemIR):
        raise TypeError("evaluate_qubo_bitstring requires QUBOProblemIR.")
    _require_valid_problem(problem, "QUBO")
    bits = _bit_values(bitstring, problem.variables)
    energy = _finite(problem.offset, "QUBO offset")
    for variable, coefficient in problem.linear_terms:
        energy += _finite(coefficient, "QUBO coefficient") * bits[variable]
    for left, right, coefficient in problem.quadratic_terms:
        energy += _finite(coefficient, "QUBO coefficient") * bits[left] * bits[right]
    return float(energy)


def evaluate_mwis_bitstring(
    problem: MWISProblemIR,
    bitstring: str,
    *,
    penalty: float | None = None,
) -> float:
    """按节点声明顺序计算一个 MWIS 候选的完整带罚项目标。"""
    if not isinstance(problem, MWISProblemIR):
        raise TypeError("evaluate_mwis_bitstring requires MWISProblemIR.")
    _require_valid_problem(problem, "MWIS")
    bits = _bit_values(bitstring, problem.nodes)
    normalized_penalty = resolve_mwis_penalty(problem, penalty=penalty)
    business_objective = -sum(
        weight * bits[node] for node, weight in problem.node_weights
    )
    penalty_energy = normalized_penalty * sum(
        bits[left] * bits[right] for left, right in problem.edges
    )
    return float(business_objective + penalty_energy)


def evaluate_ising_bitstring(problem: IsingModelIR, bitstring: str) -> float:
    """Evaluate Ising energy with bit 0 -> spin -1 and bit 1 -> spin +1."""
    if not isinstance(problem, IsingModelIR):
        raise TypeError("evaluate_ising_bitstring requires IsingModelIR.")
    _require_valid_problem(problem, "Ising")
    bits = _bit_values(bitstring, problem.spins)
    spins = {name: 2 * bit - 1 for name, bit in bits.items()}
    energy = _finite(problem.offset, "Ising offset")
    for spin, coefficient in problem.fields:
        energy += _finite(coefficient, "Ising coefficient") * spins[spin]
    for left, right, coefficient in problem.couplings:
        energy += _finite(coefficient, "Ising coefficient") * spins[left] * spins[right]
    return float(energy)


def evaluate_problem_bitstring(
    problem: OptimizationProblem,
    bitstring: str,
    *,
    mis_penalty: float = DEFAULT_MIS_PENALTY,
    mwis_penalty: float | None = None,
) -> float:
    """Evaluate one supported problem under its declared bit order."""
    if isinstance(problem, QUBOProblemIR):
        return evaluate_qubo_bitstring(problem, bitstring)
    if isinstance(problem, IsingModelIR):
        return evaluate_ising_bitstring(problem, bitstring)
    if isinstance(problem, MWISProblemIR):
        return evaluate_mwis_bitstring(
            problem,
            bitstring,
            penalty=mwis_penalty,
        )
    instance = _mis_instance(problem)
    return evaluate_qubo_bitstring(
        mis_to_qubo(instance, penalty=mis_penalty),
        bitstring,
    )


def _mis_instance(problem: OptimizationProblem) -> MISInstance:
    if isinstance(problem, GraphProblemIR):
        _require_valid_problem(problem, "Graph")
        return problem.to_mis_instance()
    if isinstance(problem, MISInstance):
        _require_valid_problem(problem, "MIS")
        return problem
    raise TypeError(
        "supported problem types are GraphProblemIR, MISInstance, "
        "MWISProblemIR, QUBOProblemIR, and IsingModelIR."
    )


def _source_problem_identity(problem: MISInstance) -> tuple[str, str, str]:
    source_id = str(problem.metadata.get("source_problem_id", ""))
    if not source_id:
        source_id = f"mis.{problem.stable_hash()[:16]}"
    source_hash = str(
        problem.metadata.get("source_problem_hash", problem.stable_hash())
    )
    source_type = str(problem.metadata.get("source_problem_type", "mis"))
    return source_id, source_hash, source_type


def _require_valid_problem(
    problem: (
        GraphProblemIR
        | MISInstance
        | MWISProblemIR
        | QUBOProblemIR
        | IsingModelIR
    ),
    label: str,
) -> None:
    diagnostics = problem.validate()
    if diagnostics:
        codes = ", ".join(sorted({item.code for item in diagnostics}))
        raise ValueError(f"{label} problem validation failed: {codes}.")


def _bit_values(bitstring: str, order: tuple[str, ...]) -> dict[str, int]:
    if not isinstance(bitstring, str) or set(bitstring) - {"0", "1"}:
        raise ValueError("bitstring must contain only 0 and 1.")
    if len(bitstring) != len(order):
        raise ValueError("bitstring length must match the declared variable order.")
    return {name: int(bit) for name, bit in zip(order, bitstring)}


def _mis_penalty(value: object) -> float:
    penalty = _finite(value, "MIS penalty")
    if penalty <= 1.0:
        raise ValueError("MIS penalty must be greater than 1.")
    return penalty


def _finite(value: object, name: str) -> float:
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        raise TypeError(f"{name} must be a real number.")
    normalized = float(value)
    if not math.isfinite(normalized):
        raise ValueError(f"{name} must be finite.")
    return normalized
