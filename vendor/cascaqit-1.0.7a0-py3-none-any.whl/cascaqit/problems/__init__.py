"""Problem-level helpers for native CASCAQit workflows."""

from __future__ import annotations

from importlib import import_module
from typing import Any

from cascaqit.problems.canonical import (
    CANONICAL_PROBLEM_SCHEMA_VERSION,
    CanonicalConstraintIR,
    CanonicalConstraintTermIR,
    CanonicalLinearTermIR,
    CanonicalProblemIR,
    CanonicalQuadraticTermIR,
    ProblemDecoderIR,
    canonicalize_problem,
)
from cascaqit.problems.mis import MISInstance, MISProgramTemplate, build_mis_program
from cascaqit.problems.models import (
    GraphProblemIR,
    IsingModelIR,
    MWISProblemIR,
    ProblemCandidateIR,
    ProblemResultDecodingIR,
    ProblemResultProvenanceIR,
    ProblemSweepExplanationIR,
    QUBOProblemIR,
    build_graph_layout_candidate,
    build_ising_objective_candidate,
    build_optimizer_problem_provenance_bridge,
    build_problem_result_provenance,
    build_qubo_objective_candidate,
    decode_graph_bitstring,
    decode_mis_result,
    diagnose_mis_decode,
    explain_problem_sweep_result,
)
from cascaqit.problems.optimization import (
    OptimizationProblem,
    evaluate_ising_bitstring,
    evaluate_mwis_bitstring,
    evaluate_problem_bitstring,
    evaluate_qubo_bitstring,
    mis_to_qubo,
    mwis_penalty_threshold,
    mwis_to_qubo,
    resolve_mwis_penalty,
)

_EXPORT_MODULES: dict[str, str] = {
    "ProblemAnalysisResult": "cascaqit.problems.analysis",
    "ProblemAHSCompileResult": "cascaqit.problems.compiler",
    "ProblemCompileResult": "cascaqit.problems.compiler",
    "ProblemCompiler": "cascaqit.problems.compiler",
    "ProblemDigitalCompileResult": "cascaqit.problems.compiler",
    "ProblemExecutionResult": "cascaqit.problems.execution",
    "ProblemExecutionContextIR": "cascaqit.problems.execution_context",
    "ProblemHybridCompileResult": "cascaqit.problems.compiler",
    "ProblemLayerExperimentResult": "cascaqit.problems.layer_experiment",
    "ProblemLayerExperimentStepIR": "cascaqit.problems.layer_experiment",
    "ProblemLayerStatisticsIR": "cascaqit.problems.repeated_layer_experiment",
    "ProblemPairedImprovementIR": "cascaqit.problems.repeated_layer_experiment",
    "ProblemRepeatedLayerExperimentResult": (
        "cascaqit.problems.repeated_layer_experiment"
    ),
    "ProblemRepeatedLayerRunIR": "cascaqit.problems.repeated_layer_experiment",
    "ProblemRepeatedLayerStepIR": "cascaqit.problems.repeated_layer_experiment",
    "build_problem_repeated_layer_experiment_result": (
        "cascaqit.problems.repeated_layer_experiment"
    ),
    "derive_problem_layer_run_seed": (
        "cascaqit.problems.repeated_layer_experiment"
    ),
    "ProblemOptimizationIR": "cascaqit.problems.execution",
    "ProblemParameterEvaluationIR": "cascaqit.problems.execution",
    "ProblemConstraintPenaltyIR": "cascaqit.problems.penalties",
    "ProblemEnergyBreakdownIR": "cascaqit.problems.penalties",
    "ProblemPenaltyAnalysisIR": "cascaqit.problems.penalties",
    "ProblemPenaltyTermIR": "cascaqit.problems.penalties",
    "ProblemOptimizerGapItemIR": "cascaqit.problems.optimizer_gap",
    "ProblemOptimizerGapMatrixIR": "cascaqit.problems.optimizer_gap",
    "build_problem_optimizer_contract_gap_matrix": ("cascaqit.problems.optimizer_gap"),
    "analyze_problem": "cascaqit.problems.analysis",
    "analyze_problem_penalty": "cascaqit.problems.penalties",
    "evaluate_problem_energy_breakdown": "cascaqit.problems.penalties",
    "evaluate_problem_energy_breakdowns": "cascaqit.problems.penalties",
    "expected_problem_energy_breakdown": "cascaqit.problems.penalties",
}

__all__ = [
    "CANONICAL_PROBLEM_SCHEMA_VERSION",
    "CanonicalConstraintIR",
    "CanonicalConstraintTermIR",
    "CanonicalLinearTermIR",
    "CanonicalProblemIR",
    "CanonicalQuadraticTermIR",
    "GraphProblemIR",
    "IsingModelIR",
    "MISInstance",
    "MISProgramTemplate",
    "MWISProblemIR",
    "OptimizationProblem",
    "ProblemAnalysisResult",
    "ProblemAHSCompileResult",
    "ProblemCompileResult",
    "ProblemCompiler",
    "ProblemDigitalCompileResult",
    "ProblemExecutionResult",
    "ProblemExecutionContextIR",
    "ProblemHybridCompileResult",
    "ProblemLayerExperimentResult",
    "ProblemLayerExperimentStepIR",
    "ProblemLayerStatisticsIR",
    "ProblemPairedImprovementIR",
    "ProblemRepeatedLayerExperimentResult",
    "ProblemRepeatedLayerRunIR",
    "ProblemRepeatedLayerStepIR",
    "ProblemOptimizationIR",
    "ProblemParameterEvaluationIR",
    "ProblemConstraintPenaltyIR",
    "ProblemEnergyBreakdownIR",
    "ProblemPenaltyAnalysisIR",
    "ProblemPenaltyTermIR",
    "ProblemCandidateIR",
    "ProblemDecoderIR",
    "ProblemOptimizerGapItemIR",
    "ProblemOptimizerGapMatrixIR",
    "ProblemResultDecodingIR",
    "ProblemResultProvenanceIR",
    "ProblemSweepExplanationIR",
    "QUBOProblemIR",
    "build_problem_result_provenance",
    "build_problem_repeated_layer_experiment_result",
    "build_graph_layout_candidate",
    "build_ising_objective_candidate",
    "build_optimizer_problem_provenance_bridge",
    "build_mis_program",
    "build_problem_optimizer_contract_gap_matrix",
    "build_qubo_objective_candidate",
    "canonicalize_problem",
    "analyze_problem",
    "analyze_problem_penalty",
    "decode_graph_bitstring",
    "decode_mis_result",
    "derive_problem_layer_run_seed",
    "diagnose_mis_decode",
    "explain_problem_sweep_result",
    "evaluate_ising_bitstring",
    "evaluate_mwis_bitstring",
    "evaluate_problem_energy_breakdown",
    "evaluate_problem_energy_breakdowns",
    "evaluate_problem_bitstring",
    "evaluate_qubo_bitstring",
    "expected_problem_energy_breakdown",
    "mis_to_qubo",
    "mwis_penalty_threshold",
    "mwis_to_qubo",
    "resolve_mwis_penalty",
]


def __getattr__(name: str) -> Any:
    """Lazily resolve problem exports that depend on optional submodules."""
    try:
        module_name = _EXPORT_MODULES[name]
    except KeyError as exc:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}") from exc
    value = getattr(import_module(module_name), name)
    globals()[name] = value
    return value
