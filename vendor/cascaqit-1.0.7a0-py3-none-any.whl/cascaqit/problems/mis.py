"""Minimal maximum independent set problem template."""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from typing import Any

from cascaqit.analog import AHSProgram, AtomRegister, Waveform
from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.native_ir.base import IRMixin
from cascaqit.native_ir.models import SCHEMA_VERSION, ProgramIR, RegisterSiteIR

__all__ = ["MISInstance", "MISProgramTemplate", "build_mis_program"]


@dataclass(frozen=True)
class MISInstance(IRMixin):
    """Small graph instance for a native Rydberg MIS template."""

    node_positions: tuple[tuple[str, tuple[float, float]], ...]
    edges: tuple[tuple[str, str], ...]
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_positions(
        cls,
        *,
        positions: dict[str, tuple[float, float]],
        edges: list[tuple[str, str]] | tuple[tuple[str, str], ...],
        metadata: dict[str, Any] | None = None,
    ) -> MISInstance:
        """Create a deterministic MIS instance from node coordinates."""
        return cls(
            node_positions=tuple(
                (str(node), (float(position[0]), float(position[1])))
                for node, position in sorted(positions.items())
            ),
            edges=_normalize_edges(edges),
            metadata={} if metadata is None else metadata,
        )

    def node_order(self) -> tuple[str, ...]:
        """Return deterministic node order used for atom and bit ordering."""
        return tuple(node for node, _ in self.node_positions)

    def position_by_node(self) -> dict[str, tuple[float, float]]:
        """Return node coordinates keyed by node id."""
        return dict(self.node_positions)

    def validate(self) -> tuple[DiagnosticsIR, ...]:
        """Return structural diagnostics for this MIS instance."""
        diagnostics: list[DiagnosticsIR] = []
        nodes = set(self.node_order())
        if not nodes:
            diagnostics.append(
                _diagnostic(
                    code="MIS_EMPTY_GRAPH",
                    message="MIS instance must contain at least one node.",
                    object_path="mis.node_positions",
                )
            )
        for left, right in self.edges:
            if left == right:
                diagnostics.append(
                    _diagnostic(
                        code="MIS_SELF_LOOP",
                        message="MIS template does not support self-loop edges.",
                        object_path=f"mis.edges.{left}",
                    )
                )
            if left not in nodes or right not in nodes:
                diagnostics.append(
                    _diagnostic(
                        code="MIS_EDGE_UNKNOWN_NODE",
                        message="MIS edge references a node outside node_positions.",
                        object_path=f"mis.edges.{left}.{right}",
                    )
                )
        return tuple(diagnostics)


@dataclass(frozen=True)
class MISProgramTemplate:
    """Native AHS template and decoder for one MIS instance."""

    instance: MISInstance
    program: AHSProgram
    omega_parameter: str
    delta_parameter: str
    diagnostics: tuple[DiagnosticsIR, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_ir(self) -> ProgramIR:
        """Return the template as a CASCAQit Native ProgramIR."""
        program_ir = self.program.to_ir()
        return replace(
            program_ir,
            metadata={
                **program_ir.metadata,
                "problem_type": "mis",
                "source_problem_id": self.instance.metadata.get(
                    "source_problem_id",
                    "mis.instance",
                ),
                "source_problem_type": self.instance.metadata.get(
                    "source_problem_type",
                    "mis",
                ),
                "source_problem_hash": self.instance.metadata.get(
                    "source_problem_hash",
                    self.instance.stable_hash(),
                ),
                "node_order": list(self.instance.node_order()),
                "edges": [list(edge) for edge in self.instance.edges],
                "omega_parameter": self.omega_parameter,
                "delta_parameter": self.delta_parameter,
            },
        )

    def decode_bitstring(self, bitstring: str) -> dict[str, Any]:
        """Decode a measured bitstring into selected MIS nodes."""
        nodes = self.instance.node_order()
        selected = tuple(
            node
            for node, bit in zip(nodes, bitstring)
            if bit == "1"
        )
        selected_set = set(selected)
        violations = tuple(
            edge
            for edge in self.instance.edges
            if edge[0] in selected_set and edge[1] in selected_set
        )
        return {
            "selected_nodes": selected,
            "size": len(selected),
            "is_independent": not violations,
            "violating_edges": violations,
        }


def build_mis_program(
    instance: MISInstance,
    *,
    program_id: str = "program.mis",
    duration: float = 1.0,
    omega_parameter: str = "omega",
    delta_parameter: str = "delta",
) -> MISProgramTemplate:
    """Build a minimal parameterized native AHS template for MIS exploration."""
    diagnostics = instance.validate()
    register = AtomRegister(
        sites=tuple(
            RegisterSiteIR(
                site_id=f"q{index}",
                atom_id=node,
                position=position,
            )
            for index, (node, position) in enumerate(instance.node_positions)
        )
    )
    program = AHSProgram(register, program_id=program_id)
    program.parameter(
        omega_parameter,
        unit="rad/us",
        lower_bound=0.0,
    )
    program.parameter(
        delta_parameter,
        unit="rad/us",
    )
    program.drive(
        rabi=Waveform.parameter(
            omega_parameter,
            duration=duration,
            waveform_id="mis.rabi",
        ),
        detuning=Waveform.parameter(
            delta_parameter,
            duration=duration,
            waveform_id="mis.detuning",
        ),
        phase=0.0,
    )
    program.measure(measurement_id="mis.measure")
    return MISProgramTemplate(
        instance=instance,
        program=program,
        omega_parameter=omega_parameter,
        delta_parameter=delta_parameter,
        diagnostics=diagnostics,
        metadata={"template": "mis_minimal_ahs"},
    )


def _normalize_edges(
    edges: list[tuple[str, str]] | tuple[tuple[str, str], ...],
) -> tuple[tuple[str, str], ...]:
    normalized: set[tuple[str, str]] = set()
    for left, right in edges:
        edge = tuple(sorted((str(left), str(right))))
        normalized.add((edge[0], edge[1]))
    return tuple(sorted(normalized))


def _diagnostic(
    *,
    code: str,
    message: str,
    object_path: str,
) -> DiagnosticsIR:
    return DiagnosticsIR(
        diagnostic_id=f"problem.mis.{code.lower()}",
        stage="validation",
        severity="error",
        code=code,
        message=message,
        object_path=object_path,
    )
