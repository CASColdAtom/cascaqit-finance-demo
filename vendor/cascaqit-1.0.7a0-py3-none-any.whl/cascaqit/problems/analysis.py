"""Shared Problem analysis entrypoint used before mode-specific lowering."""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

from cascaqit.compiler.problem import LogicalHamiltonianIR, build_logical_hamiltonian
from cascaqit.compiler.problem_mapping import (
    ProblemMappingPlanIR,
    ProblemMappingPlanner,
)
from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.native_ir.base import IRMixin
from cascaqit.problems.canonical import (
    CanonicalProblemIR,
    ProblemDecoderIR,
    canonicalize_problem,
)
from cascaqit.problems.optimization import DEFAULT_MIS_PENALTY, OptimizationProblem
from cascaqit.problems.penalties import (
    ProblemPenaltyAnalysisIR,
    analyze_problem_penalty,
)
from cascaqit.targets import TargetSpec

__all__ = ["ProblemAnalysisResult", "analyze_problem"]


@dataclass(frozen=True)
class ProblemAnalysisResult(IRMixin):
    """One immutable analysis shared by Digital, Analog, and Hybrid Lowerers."""

    analysis_id: str
    canonical_problem: CanonicalProblemIR
    logical_hamiltonian: LogicalHamiltonianIR
    decoder: ProblemDecoderIR
    mapping_plan: ProblemMappingPlanIR
    penalty_analysis: ProblemPenaltyAnalysisIR | None
    diagnostics: tuple[DiagnosticsIR, ...]

    def __post_init__(self) -> None:
        if not isinstance(self.analysis_id, str) or not self.analysis_id.strip():
            raise ValueError("analysis_id must be a non-empty string.")
        if self.decoder != self.canonical_problem.decoder:
            raise ValueError("analysis decoder must come from canonical_problem.")
        if (
            self.logical_hamiltonian.source_problem_hash
            != self.canonical_problem.problem_hash
        ):
            raise ValueError("analysis logical Hamiltonian source hash does not match.")
        if self.mapping_plan.source_problem_hash != self.canonical_problem.problem_hash:
            raise ValueError("analysis mapping source hash does not match.")
        if (
            self.mapping_plan.logical_hamiltonian_hash
            != self.logical_hamiltonian.stable_hash()
        ):
            raise ValueError("analysis mapping does not reference logical Hamiltonian.")
        expected_penalty_analysis = analyze_problem_penalty(self.canonical_problem)
        if self.penalty_analysis != expected_penalty_analysis:
            raise ValueError(
                "analysis penalty model does not match the canonical Problem."
            )
        object.__setattr__(self, "diagnostics", tuple(self.diagnostics))

    @property
    def analysis_hash(self) -> str:
        """Return the deterministic hash referenced by compile results."""
        return self.stable_hash()

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ProblemAnalysisResult:
        """Restore one shared Problem analysis."""
        return cls(
            analysis_id=str(data["analysis_id"]),
            canonical_problem=CanonicalProblemIR.from_dict(data["canonical_problem"]),
            logical_hamiltonian=LogicalHamiltonianIR.from_dict(
                data["logical_hamiltonian"]
            ),
            decoder=ProblemDecoderIR.from_dict(data["decoder"]),
            mapping_plan=ProblemMappingPlanIR.from_dict(data["mapping_plan"]),
            penalty_analysis=(
                None
                if data.get("penalty_analysis") is None
                else ProblemPenaltyAnalysisIR.from_dict(data["penalty_analysis"])
            ),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(item) for item in data.get("diagnostics", ())
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> ProblemAnalysisResult:
        """Restore one shared Problem analysis from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("ProblemAnalysisResult JSON must contain an object.")
        return cls.from_dict(data)


def analyze_problem(
    problem: OptimizationProblem,
    *,
    target: TargetSpec,
    mis_penalty: float = DEFAULT_MIS_PENALTY,
    mwis_penalty: float | None = None,
    absolute_tolerance: float = 1e-8,
    relative_tolerance: float = 0.05,
) -> ProblemAnalysisResult:
    """Build the one canonical analysis reused by every compile mode."""
    if not isinstance(target, TargetSpec):
        raise TypeError("target must be TargetSpec.")
    canonical = canonicalize_problem(
        problem,
        mis_penalty=mis_penalty,
        mwis_penalty=mwis_penalty,
    )
    logical = build_logical_hamiltonian(
        problem,
        canonical=canonical,
        mis_penalty=mis_penalty,
        mwis_penalty=mwis_penalty,
    )
    mapping = ProblemMappingPlanner(
        absolute_tolerance=absolute_tolerance,
        relative_tolerance=relative_tolerance,
    ).plan(canonical, logical, target=target)
    penalty_analysis = analyze_problem_penalty(canonical)
    diagnostics = mapping.diagnostics
    if penalty_analysis is not None:
        diagnostics = (
            *diagnostics,
            DiagnosticsIR(
                diagnostic_id=(
                    f"problem.analysis.{canonical.problem_id}.penalty-sufficient"
                ),
                stage="validation",
                severity="info",
                code="PROBLEM_PENALTY_SUFFICIENT",
                message=(
                    "Problem penalty strength is strictly greater than the "
                    "applicable vertex-removal sufficiency threshold."
                ),
                object_path="problem.analysis.penalty_analysis",
                metadata={
                    "criterion": penalty_analysis.criterion,
                    "penalty_strength": penalty_analysis.penalty_strength,
                    "minimum_sufficient_strength": (
                        penalty_analysis.minimum_sufficient_strength
                    ),
                    "sufficiency_margin": penalty_analysis.sufficiency_margin,
                    "reason_category": "validation",
                    "taxonomy_stage": "validation",
                    "actionable": False,
                },
            ),
        )
    return ProblemAnalysisResult(
        analysis_id=f"analysis.{canonical.problem_id}.{target.target_id}",
        canonical_problem=canonical,
        logical_hamiltonian=logical,
        decoder=canonical.decoder,
        mapping_plan=mapping,
        penalty_analysis=penalty_analysis,
        diagnostics=diagnostics,
    )
