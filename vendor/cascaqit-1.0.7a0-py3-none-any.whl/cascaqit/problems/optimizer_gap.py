"""Problem optimizer contract gap matrix contracts."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Literal

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.native_ir.base import IRMixin, canonicalize
from cascaqit.native_ir.models import SCHEMA_VERSION

__all__ = [
    "ProblemOptimizerGapItemIR",
    "ProblemOptimizerGapMatrixIR",
    "ProblemOptimizerGapStatus",
    "build_problem_optimizer_contract_gap_matrix",
]

ProblemOptimizerGapStatus = Literal[
    "implemented",
    "metadata-only",
    "blocked",
    "not implemented",
]

_STATUSES: tuple[ProblemOptimizerGapStatus, ...] = (
    "implemented",
    "metadata-only",
    "blocked",
    "not implemented",
)


@dataclass(frozen=True)
class ProblemOptimizerGapItemIR(IRMixin):
    """Single row in the problem optimizer contract gap matrix."""

    capability_id: str
    capability_area: str
    status: ProblemOptimizerGapStatus
    current_evidence: str
    gap: str
    recommendation: str
    priority: int
    blocks_optimizer_claim: bool = False
    metadata_only: bool = True
    optimizer_result: bool = False
    optimality_claimed: bool = False
    approximation_ratio_claimed: bool = False
    convergence_claimed: bool = False
    external_optimizer_service: bool = False
    hardware_execution: bool = False
    cloud_execution: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Validate item invariants for no-optimizer-claim boundaries."""
        if self.status not in _STATUSES:
            raise ValueError(f"unsupported optimizer gap status: {self.status}")
        if self.priority < 1:
            raise ValueError("priority must be positive.")
        if not self.metadata_only:
            raise ValueError("Problem optimizer gap items must be metadata-only.")
        if self.optimizer_result:
            raise ValueError(
                "Problem optimizer gap items must not be optimizer results."
            )
        if self.optimality_claimed:
            raise ValueError("Problem optimizer gap items must not claim optimality.")
        if self.approximation_ratio_claimed:
            raise ValueError(
                "Problem optimizer gap items must not claim approximation ratio."
            )
        if self.convergence_claimed:
            raise ValueError("Problem optimizer gap items must not claim convergence.")
        if self.external_optimizer_service:
            raise ValueError(
                "Problem optimizer gap items must not use external optimizer service."
            )
        if self.hardware_execution:
            raise ValueError("Problem optimizer gap items must not claim hardware.")
        if self.cloud_execution:
            raise ValueError("Problem optimizer gap items must not claim cloud.")
        object.__setattr__(self, "metadata", canonicalize(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ProblemOptimizerGapItemIR:
        """Build an optimizer gap item from a dictionary."""
        return cls(
            capability_id=str(data["capability_id"]),
            capability_area=str(data["capability_area"]),
            status=data["status"],
            current_evidence=str(data["current_evidence"]),
            gap=str(data["gap"]),
            recommendation=str(data["recommendation"]),
            priority=int(data["priority"]),
            blocks_optimizer_claim=bool(data.get("blocks_optimizer_claim", False)),
            metadata_only=bool(data.get("metadata_only", True)),
            optimizer_result=bool(data.get("optimizer_result", False)),
            optimality_claimed=bool(data.get("optimality_claimed", False)),
            approximation_ratio_claimed=bool(
                data.get("approximation_ratio_claimed", False)
            ),
            convergence_claimed=bool(data.get("convergence_claimed", False)),
            external_optimizer_service=bool(
                data.get("external_optimizer_service", False)
            ),
            hardware_execution=bool(data.get("hardware_execution", False)),
            cloud_execution=bool(data.get("cloud_execution", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )


@dataclass(frozen=True)
class ProblemOptimizerGapMatrixIR(IRMixin):
    """Metadata-only matrix for problem/sweep optimizer contract gaps."""

    matrix_id: str
    scope: str
    items: tuple[ProblemOptimizerGapItemIR, ...]
    recommended_next_focus: tuple[str, ...]
    diagnostics: tuple[DiagnosticsIR, ...] = ()
    metadata_only: bool = True
    optimizer_result: bool = False
    optimality_claimed: bool = False
    approximation_ratio_claimed: bool = False
    convergence_claimed: bool = False
    external_optimizer_service: bool = False
    hardware_execution: bool = False
    cloud_execution: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize rows and enforce no optimizer/result claims."""
        if not self.metadata_only:
            raise ValueError("Problem optimizer gap matrix must be metadata-only.")
        if self.optimizer_result:
            raise ValueError("Problem optimizer gap matrix is not an optimizer result.")
        if self.optimality_claimed:
            raise ValueError("Problem optimizer gap matrix must not claim optimality.")
        if self.approximation_ratio_claimed:
            raise ValueError(
                "Problem optimizer gap matrix must not claim approximation ratio."
            )
        if self.convergence_claimed:
            raise ValueError("Problem optimizer gap matrix must not claim convergence.")
        if self.external_optimizer_service:
            raise ValueError(
                "Problem optimizer gap matrix must not use external optimizer service."
            )
        if self.hardware_execution:
            raise ValueError("Problem optimizer gap matrix must not claim hardware.")
        if self.cloud_execution:
            raise ValueError("Problem optimizer gap matrix must not claim cloud.")
        object.__setattr__(
            self,
            "items",
            tuple(
                item if isinstance(item, ProblemOptimizerGapItemIR)
                else ProblemOptimizerGapItemIR.from_dict(item)
                for item in self.items
            ),
        )
        object.__setattr__(
            self,
            "diagnostics",
            tuple(
                item if isinstance(item, DiagnosticsIR)
                else DiagnosticsIR.from_dict(item)
                for item in self.diagnostics
            ),
        )
        object.__setattr__(self, "metadata", canonicalize(self.metadata))

    @property
    def status_counts(self) -> dict[str, int]:
        """Return deterministic status counts."""
        return {
            status: sum(1 for item in self.items if item.status == status)
            for status in _STATUSES
        }

    @property
    def optimizer_claim_blockers(self) -> tuple[str, ...]:
        """Return capability ids that block optimizer claims."""
        return tuple(
            item.capability_id for item in self.items
            if item.blocks_optimizer_claim
        )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ProblemOptimizerGapMatrixIR:
        """Build an optimizer gap matrix from a dictionary."""
        return cls(
            matrix_id=str(data["matrix_id"]),
            scope=str(data["scope"]),
            items=tuple(
                ProblemOptimizerGapItemIR.from_dict(item)
                for item in data.get("items", ())
            ),
            recommended_next_focus=tuple(
                str(item) for item in data.get("recommended_next_focus", ())
            ),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(item)
                for item in data.get("diagnostics", ())
            ),
            metadata_only=bool(data.get("metadata_only", True)),
            optimizer_result=bool(data.get("optimizer_result", False)),
            optimality_claimed=bool(data.get("optimality_claimed", False)),
            approximation_ratio_claimed=bool(
                data.get("approximation_ratio_claimed", False)
            ),
            convergence_claimed=bool(data.get("convergence_claimed", False)),
            external_optimizer_service=bool(
                data.get("external_optimizer_service", False)
            ),
            hardware_execution=bool(data.get("hardware_execution", False)),
            cloud_execution=bool(data.get("cloud_execution", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> ProblemOptimizerGapMatrixIR:
        """Build an optimizer gap matrix from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("ProblemOptimizerGapMatrixIR JSON must contain an object.")
        return cls.from_dict(data)


def build_problem_optimizer_contract_gap_matrix(
    *,
    matrix_id: str = "problem_optimizer_gap.v0_65.contract",
) -> ProblemOptimizerGapMatrixIR:
    """Build the deterministic legacy optimizer contract gap matrix."""
    items = (
        _item(
            "problem_ir_and_candidates",
            "problem_modeling",
            "implemented",
            "Graph, QUBO, Ising, MIS, and objective candidates are modeled.",
            "Candidate generation is inspectable metadata, not optimization.",
            "Keep problem candidates separate from optimizer result objects.",
            1,
        ),
        _item(
            "parameter_sweep_grid",
            "sweep",
            "implemented",
            "ParameterGrid expands deterministic binds and BatchRuntime can run them.",
            "Grid search is user-provided enumeration, not an optimizer loop.",
            "Treat sweep summaries as execution evidence only.",
            1,
        ),
        _item(
            "mis_decoder",
            "decoder",
            "implemented",
            "decode_mis_result and diagnose_mis_decode validate bitstrings.",
            "Decoding reports feasibility, not optimality.",
            "Keep selected-node decode independent from optimizer metrics.",
            1,
        ),
        _item(
            "result_provenance",
            "provenance",
            "implemented",
            "ProblemResultProvenanceIR links decode output to batch/result evidence.",
            "Provenance does not define objective history or optimizer state.",
            "Preserve provenance as evidence, not optimization metadata.",
            2,
        ),
        _item(
            "problem_sweep_explanation",
            "explanation",
            "metadata-only",
            "ProblemSweepExplanationIR composes decode, provenance, and summary.",
            "Explanation is a derived view and not an optimizer result.",
            "Continue exposing explicit no-claim metadata.",
            2,
        ),
        _item(
            "optimizer_loop",
            "optimizer",
            "not implemented",
            "No optimizer loop, candidate proposal policy, or update rule exists.",
            "There is no iterative optimizer state machine.",
            "Design optimizer loop contracts before any optimization claim.",
            1,
            blocks=True,
        ),
        _item(
            "termination_and_convergence",
            "optimizer",
            "not implemented",
            "No termination reason, stopping criteria, or convergence trace exists.",
            "Convergence cannot be claimed without optimizer lifecycle state.",
            "Define termination and convergence semantics before execution.",
            1,
            blocks=True,
        ),
        _item(
            "objective_history",
            "optimizer",
            "not implemented",
            "Batch/sweep summaries count execution results but not objective history.",
            "No best-so-far, objective trace, or comparison policy is defined.",
            "Add objective history only with explicit optimizer result schema.",
            2,
            blocks=True,
        ),
        _item(
            "optimality_metrics",
            "claims",
            "blocked",
            "Existing contracts set optimality_claim to not_claimed.",
            "MIS optimality, approximation ratio, and convergence are not proven.",
            "Keep all optimizer claims blocked until mathematically defined.",
            1,
            blocks=True,
        ),
    )
    return ProblemOptimizerGapMatrixIR(
        matrix_id=matrix_id,
        scope="problem_sweep_optimizer_contract",
        items=items,
        recommended_next_focus=(
            "optimizer_result_schema",
            "objective_history_contract",
            "termination_reason_and_convergence_contract",
        ),
        diagnostics=(
            DiagnosticsIR(
                diagnostic_id="problem_optimizer_gap.metadata_only",
                stage="validation",
                severity="info",
                code="PROBLEM_OPTIMIZER_GAP_MATRIX_METADATA_ONLY",
                message=(
                    "Problem optimizer gap matrix is metadata-only and does not "
                    "execute optimizer loops."
                ),
                object_path="problem_optimizer_gap_matrix",
                metadata={"optimizer_result": False},
            ),
            DiagnosticsIR(
                diagnostic_id="problem_optimizer_gap.claims_blocked",
                stage="validation",
                severity="warning",
                code="PROBLEM_OPTIMIZER_CLAIMS_BLOCKED",
                message=(
                    "Optimality, approximation ratio, and convergence claims "
                    "remain blocked."
                ),
                object_path="problem_optimizer_gap_matrix.claims",
                metadata={
                    "optimality_claimed": False,
                    "approximation_ratio_claimed": False,
                    "convergence_claimed": False,
                },
            ),
        ),
        metadata={
            "status_vocabulary": _STATUSES,
            "mis_optimality": "not_claimed",
            "approximation_ratio": "not_claimed",
            "convergence": "not_claimed",
            "optimizer_loop": "not_implemented",
        },
    )


def _item(
    capability_id: str,
    capability_area: str,
    status: ProblemOptimizerGapStatus,
    current_evidence: str,
    gap: str,
    recommendation: str,
    priority: int,
    *,
    blocks: bool = False,
) -> ProblemOptimizerGapItemIR:
    return ProblemOptimizerGapItemIR(
        capability_id=capability_id,
        capability_area=capability_area,
        status=status,
        current_evidence=current_evidence,
        gap=gap,
        recommendation=recommendation,
        priority=priority,
        blocks_optimizer_claim=blocks,
        metadata={
            "optimizer_result": False,
            "optimality_claimed": False,
            "approximation_ratio_claimed": False,
            "convergence_claimed": False,
        },
    )
