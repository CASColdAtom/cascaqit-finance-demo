"""Typed penalty analysis and runtime energy decomposition for Problems."""

from __future__ import annotations

import math
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from typing import Any, Literal

from cascaqit.native_ir.base import IRMixin
from cascaqit.problems.canonical import CanonicalProblemIR

__all__ = [
    "PROBLEM_PENALTY_SCHEMA_VERSION",
    "ProblemConstraintPenaltyIR",
    "ProblemEnergyBreakdownIR",
    "ProblemPenaltyAnalysisIR",
    "ProblemPenaltyTermIR",
    "analyze_problem_penalty",
    "evaluate_problem_energy_breakdown",
    "evaluate_problem_energy_breakdowns",
    "expected_problem_energy_breakdown",
]

PROBLEM_PENALTY_SCHEMA_VERSION = "cascaqit.problem.penalty.v2"
_ENERGY_TOLERANCE = 1e-12
_ENERGY_RELATIVE_TOLERANCE = 1e-12
_PROBABILITY_TOLERANCE = 1e-9


@dataclass(frozen=True)
class ProblemPenaltyTermIR(IRMixin):
    """One explicit source constraint and its canonical penalty term."""

    constraint_id: str
    source_kind: Literal["independent_set_edge"]
    targets: tuple[str, ...]
    canonical_term_id: str
    coefficient: float
    schema_version: str = PROBLEM_PENALTY_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_penalty_schema(self.schema_version)
        _require_text(self.constraint_id, "constraint_id")
        if self.source_kind != "independent_set_edge":
            raise ValueError(
                f"Unsupported penalty source kind: {self.source_kind!r}."
            )
        object.__setattr__(self, "targets", tuple(self.targets))
        if len(self.targets) != 2 or len(set(self.targets)) != 2:
            raise ValueError("independent-set penalty terms require two targets.")
        if any(not isinstance(target, str) or not target for target in self.targets):
            raise ValueError("penalty targets must contain non-empty strings.")
        _require_text(self.canonical_term_id, "canonical_term_id")
        coefficient = _finite(self.coefficient, "coefficient")
        if coefficient <= 0.0:
            raise ValueError("penalty coefficients must be positive.")
        object.__setattr__(self, "coefficient", coefficient)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ProblemPenaltyTermIR:
        """Restore one penalty term from JSON-compatible data."""
        return cls(
            constraint_id=str(data["constraint_id"]),
            source_kind=data["source_kind"],
            targets=tuple(str(item) for item in data["targets"]),
            canonical_term_id=str(data["canonical_term_id"]),
            coefficient=data["coefficient"],
            schema_version=str(
                data.get("schema_version", PROBLEM_PENALTY_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class ProblemPenaltyAnalysisIR(IRMixin):
    """来源约束与规范罚项逐项对应的静态充分性证明。"""

    source_problem_hash: str
    criterion: Literal["mis_vertex_removal", "weighted_vertex_removal"]
    penalty_strength: float
    minimum_sufficient_strength: float
    strict_inequality: bool
    sufficiency_margin: float
    sufficient: bool
    business_objective_term_ids: tuple[str, ...]
    penalty_terms: tuple[ProblemPenaltyTermIR, ...]
    schema_version: str = PROBLEM_PENALTY_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_penalty_schema(self.schema_version)
        _require_digest(self.source_problem_hash, "source_problem_hash")
        if self.criterion not in {
            "mis_vertex_removal",
            "weighted_vertex_removal",
        }:
            raise ValueError(f"Unsupported penalty criterion: {self.criterion!r}.")
        strength = _finite(self.penalty_strength, "penalty_strength")
        minimum = _finite(
            self.minimum_sufficient_strength,
            "minimum_sufficient_strength",
        )
        margin = _finite(self.sufficiency_margin, "sufficiency_margin")
        if strength <= 0.0 or minimum < 0.0:
            raise ValueError("penalty strengths must use a positive finite domain.")
        if not isinstance(self.strict_inequality, bool):
            raise TypeError("strict_inequality must be a boolean.")
        if not self.strict_inequality:
            raise ValueError(
                "Problem penalty sufficiency requires a strict inequality."
            )
        if not math.isclose(
            margin,
            strength - minimum,
            rel_tol=_ENERGY_RELATIVE_TOLERANCE,
            abs_tol=_ENERGY_TOLERANCE,
        ):
            raise ValueError("sufficiency_margin must equal strength minus threshold.")
        if not isinstance(self.sufficient, bool):
            raise TypeError("sufficient must be a boolean.")
        if self.sufficient != (strength > minimum):
            raise ValueError("sufficient does not match the strict penalty threshold.")
        object.__setattr__(self, "penalty_strength", strength)
        object.__setattr__(self, "minimum_sufficient_strength", minimum)
        object.__setattr__(self, "sufficiency_margin", margin)
        object.__setattr__(
            self,
            "business_objective_term_ids",
            tuple(self.business_objective_term_ids),
        )
        _require_unique_text(
            self.business_objective_term_ids,
            "business_objective_term_ids",
            allow_empty=True,
        )
        object.__setattr__(self, "penalty_terms", tuple(self.penalty_terms))
        if any(
            not isinstance(item, ProblemPenaltyTermIR) for item in self.penalty_terms
        ):
            raise TypeError("penalty_terms must contain ProblemPenaltyTermIR values.")
        constraint_ids = tuple(item.constraint_id for item in self.penalty_terms)
        term_ids = tuple(item.canonical_term_id for item in self.penalty_terms)
        _require_unique_text(constraint_ids, "penalty constraint ids", allow_empty=True)
        _require_unique_text(term_ids, "penalty term ids", allow_empty=True)
        if any(
            not math.isclose(
                item.coefficient,
                strength,
                rel_tol=_ENERGY_RELATIVE_TOLERANCE,
                abs_tol=_ENERGY_TOLERANCE,
            )
            for item in self.penalty_terms
        ):
            raise ValueError("every Problem penalty term must use penalty_strength.")

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ProblemPenaltyAnalysisIR:
        """Restore one static penalty analysis from JSON-compatible data."""
        return cls(
            source_problem_hash=str(data["source_problem_hash"]),
            criterion=data["criterion"],
            penalty_strength=data["penalty_strength"],
            minimum_sufficient_strength=data["minimum_sufficient_strength"],
            strict_inequality=data["strict_inequality"],
            sufficiency_margin=data["sufficiency_margin"],
            sufficient=data["sufficient"],
            business_objective_term_ids=tuple(
                str(item) for item in data["business_objective_term_ids"]
            ),
            penalty_terms=tuple(
                ProblemPenaltyTermIR.from_dict(_mapping(item, "penalty_term"))
                for item in data["penalty_terms"]
            ),
            schema_version=str(
                data.get("schema_version", PROBLEM_PENALTY_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class ProblemConstraintPenaltyIR(IRMixin):
    """One constraint's activation and contribution for a candidate or distribution."""

    constraint_id: str
    canonical_term_id: str
    targets: tuple[str, ...]
    coefficient: float
    activation: float
    contribution: float
    schema_version: str = PROBLEM_PENALTY_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_penalty_schema(self.schema_version)
        _require_text(self.constraint_id, "constraint_id")
        _require_text(self.canonical_term_id, "canonical_term_id")
        object.__setattr__(self, "targets", tuple(self.targets))
        if len(self.targets) != 2 or len(set(self.targets)) != 2:
            raise ValueError("constraint penalty targets must contain two variables.")
        if any(not isinstance(target, str) or not target for target in self.targets):
            raise ValueError(
                "constraint penalty targets must contain non-empty strings."
            )
        coefficient = _finite(self.coefficient, "coefficient")
        activation = _finite(self.activation, "activation")
        contribution = _finite(self.contribution, "contribution")
        if coefficient <= 0.0:
            raise ValueError("constraint penalty coefficient must be positive.")
        if not 0.0 <= activation <= 1.0 + _PROBABILITY_TOLERANCE:
            raise ValueError("constraint activation must be within [0, 1].")
        if not math.isclose(
            contribution,
            coefficient * activation,
            rel_tol=_ENERGY_RELATIVE_TOLERANCE,
            abs_tol=_ENERGY_TOLERANCE,
        ):
            raise ValueError(
                "constraint contribution must equal coefficient * activation."
            )
        object.__setattr__(self, "coefficient", coefficient)
        object.__setattr__(self, "activation", min(activation, 1.0))
        object.__setattr__(self, "contribution", contribution)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ProblemConstraintPenaltyIR:
        """Restore one runtime constraint contribution."""
        return cls(
            constraint_id=str(data["constraint_id"]),
            canonical_term_id=str(data["canonical_term_id"]),
            targets=tuple(str(item) for item in data["targets"]),
            coefficient=data["coefficient"],
            activation=data["activation"],
            contribution=data["contribution"],
            schema_version=str(
                data.get("schema_version", PROBLEM_PENALTY_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class ProblemEnergyBreakdownIR(IRMixin):
    """Business objective and explicit penalty energy for one result scope."""

    scope: Literal["candidate", "expectation"]
    penalty_model_status: Literal["defined", "not_applicable"]
    business_objective: float
    penalty_energy: float
    total_objective: float
    constraint_penalties: tuple[ProblemConstraintPenaltyIR, ...]
    bitstring: str | None = None
    schema_version: str = PROBLEM_PENALTY_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_penalty_schema(self.schema_version)
        if self.scope not in {"candidate", "expectation"}:
            raise ValueError(f"Unsupported energy breakdown scope: {self.scope!r}.")
        if self.penalty_model_status not in {"defined", "not_applicable"}:
            raise ValueError(
                "penalty_model_status must be defined or not_applicable."
            )
        if self.scope == "candidate":
            if not self.bitstring or set(self.bitstring) - {"0", "1"}:
                raise ValueError("candidate energy breakdown requires a bitstring.")
        elif self.bitstring is not None:
            raise ValueError("expectation energy breakdown cannot contain a bitstring.")
        business = _finite(self.business_objective, "business_objective")
        penalty = _finite(self.penalty_energy, "penalty_energy")
        total = _finite(self.total_objective, "total_objective")
        if penalty < -_ENERGY_TOLERANCE:
            raise ValueError("penalty_energy must be non-negative.")
        object.__setattr__(
            self,
            "constraint_penalties",
            tuple(self.constraint_penalties),
        )
        if any(
            not isinstance(item, ProblemConstraintPenaltyIR)
            for item in self.constraint_penalties
        ):
            raise TypeError(
                "constraint_penalties must contain ProblemConstraintPenaltyIR values."
            )
        constraint_ids = tuple(
            item.constraint_id for item in self.constraint_penalties
        )
        _require_unique_text(
            constraint_ids,
            "constraint penalty ids",
            allow_empty=True,
        )
        if self.penalty_model_status == "not_applicable" and (
            self.constraint_penalties or abs(penalty) > _ENERGY_TOLERANCE
        ):
            raise ValueError(
                "not_applicable penalty models cannot contain penalty contributions."
            )
        if not math.isclose(
            penalty,
            sum(item.contribution for item in self.constraint_penalties),
            rel_tol=_ENERGY_RELATIVE_TOLERANCE,
            abs_tol=_ENERGY_TOLERANCE,
        ):
            raise ValueError("penalty_energy must equal constraint contributions.")
        if not math.isclose(
            total,
            business + penalty,
            rel_tol=_ENERGY_RELATIVE_TOLERANCE,
            abs_tol=_ENERGY_TOLERANCE,
        ):
            raise ValueError(
                "total_objective must equal business_objective plus penalty_energy."
            )
        object.__setattr__(self, "business_objective", business)
        object.__setattr__(self, "penalty_energy", max(0.0, penalty))
        object.__setattr__(self, "total_objective", total)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ProblemEnergyBreakdownIR:
        """Restore one energy breakdown from JSON-compatible data."""
        return cls(
            scope=data["scope"],
            penalty_model_status=data["penalty_model_status"],
            business_objective=data["business_objective"],
            penalty_energy=data["penalty_energy"],
            total_objective=data["total_objective"],
            constraint_penalties=tuple(
                ProblemConstraintPenaltyIR.from_dict(
                    _mapping(item, "constraint_penalty")
                )
                for item in data["constraint_penalties"]
            ),
            bitstring=(
                None if data.get("bitstring") is None else str(data["bitstring"])
            ),
            schema_version=str(
                data.get("schema_version", PROBLEM_PENALTY_SCHEMA_VERSION)
            ),
        )


def analyze_problem_penalty(
    canonical: CanonicalProblemIR,
) -> ProblemPenaltyAnalysisIR | None:
    """从规范约束构造 MIS/MWIS 罚项证明，不推断普通 QUBO。"""
    if not isinstance(canonical, CanonicalProblemIR):
        raise TypeError("canonical must be CanonicalProblemIR.")
    if canonical.decoder.decoder_kind not in {"mis", "mwis"}:
        # A generic QUBO coefficient may be a business interaction or a penalty.
        # Without source constraint semantics, CASCAQit must not guess which it is.
        return None
    strength = _decoder_penalty_strength(canonical)
    quadratic_by_id = {term.term_id: term for term in canonical.quadratic_terms}
    terms = []
    for constraint in canonical.constraints:
        if len(constraint.penalty_term_ids) != 1:
            raise ValueError(
                f"Constraint {constraint.constraint_id!r} must reference one "
                "canonical penalty term."
            )
        canonical_term = quadratic_by_id.get(constraint.penalty_term_ids[0])
        if canonical_term is None:
            raise ValueError(
                f"Constraint {constraint.constraint_id!r} has no canonical "
                "penalty term."
            )
        targets = tuple(term.variable for term in constraint.linear_terms)
        terms.append(
            ProblemPenaltyTermIR(
                constraint_id=constraint.constraint_id,
                source_kind=constraint.source_kind,
                targets=targets,
                canonical_term_id=canonical_term.term_id,
                coefficient=canonical_term.coefficient,
            )
        )
    if {item.canonical_term_id for item in terms} != {
        term.term_id for term in canonical.quadratic_terms
    }:
        raise ValueError(
            "Constrained Problem quadratic terms must map one-to-one to constraints."
        )
    criterion: Literal["mis_vertex_removal", "weighted_vertex_removal"]
    if canonical.decoder.decoder_kind == "mis":
        criterion = "mis_vertex_removal"
        minimum = 1.0
    else:
        criterion = "weighted_vertex_removal"
        weights = dict(canonical.decoder.node_weights)
        minimum = max(
            (
                min(weights[left], weights[right])
                for left, right in canonical.decoder.edges
            ),
            default=0.0,
        )
    return ProblemPenaltyAnalysisIR(
        source_problem_hash=canonical.problem_hash,
        criterion=criterion,
        penalty_strength=strength,
        minimum_sufficient_strength=minimum,
        strict_inequality=True,
        sufficiency_margin=strength - minimum,
        sufficient=strength > minimum,
        business_objective_term_ids=tuple(
            term.term_id for term in canonical.linear_terms
        ),
        penalty_terms=tuple(terms),
    )


def evaluate_problem_energy_breakdown(
    canonical: CanonicalProblemIR,
    bitstring: str,
    *,
    penalty_analysis: ProblemPenaltyAnalysisIR | None,
) -> ProblemEnergyBreakdownIR:
    """Evaluate one candidate and independently verify its canonical objective."""
    _validate_penalty_contract(canonical, penalty_analysis)
    return _evaluate_problem_energy_breakdown(
        canonical,
        bitstring,
        penalty_analysis=penalty_analysis,
    )


def evaluate_problem_energy_breakdowns(
    canonical: CanonicalProblemIR,
    bitstrings: Iterable[str],
    *,
    penalty_analysis: ProblemPenaltyAnalysisIR | None,
) -> tuple[ProblemEnergyBreakdownIR, ...]:
    """Evaluate a candidate set after validating its shared penalty model once."""
    _validate_penalty_contract(canonical, penalty_analysis)
    return tuple(
        _evaluate_problem_energy_breakdown(
            canonical,
            bitstring,
            penalty_analysis=penalty_analysis,
        )
        for bitstring in bitstrings
    )


def _evaluate_problem_energy_breakdown(
    canonical: CanonicalProblemIR,
    bitstring: str,
    *,
    penalty_analysis: ProblemPenaltyAnalysisIR | None,
) -> ProblemEnergyBreakdownIR:
    """Evaluate one candidate after the caller has validated shared semantics."""
    values = _bit_values(canonical, bitstring)
    if canonical.decoder.decoder_kind not in {"mis", "mwis"}:
        total = _canonical_objective(canonical, values)
        return ProblemEnergyBreakdownIR(
            scope="candidate",
            penalty_model_status="not_applicable",
            business_objective=total,
            penalty_energy=0.0,
            total_objective=total,
            constraint_penalties=(),
            bitstring=bitstring,
        )
    assert penalty_analysis is not None
    business = canonical.offset + sum(
        term.coefficient * values[term.variable]
        for term in canonical.linear_terms
    )
    contributions = tuple(
        ProblemConstraintPenaltyIR(
            constraint_id=term.constraint_id,
            canonical_term_id=term.canonical_term_id,
            targets=term.targets,
            coefficient=term.coefficient,
            activation=float(values[term.targets[0]] * values[term.targets[1]]),
            contribution=(
                term.coefficient
                * values[term.targets[0]]
                * values[term.targets[1]]
            ),
        )
        for term in penalty_analysis.penalty_terms
    )
    penalty = sum(item.contribution for item in contributions)
    total = business + penalty
    if not math.isclose(
        total,
        _canonical_objective(canonical, values),
        rel_tol=_ENERGY_RELATIVE_TOLERANCE,
        abs_tol=_ENERGY_TOLERANCE,
    ):
        raise ValueError(
            "Constrained Problem energy decomposition does not reconstruct "
            "the objective."
        )
    return ProblemEnergyBreakdownIR(
        scope="candidate",
        penalty_model_status="defined",
        business_objective=business,
        penalty_energy=penalty,
        total_objective=total,
        constraint_penalties=contributions,
        bitstring=bitstring,
    )


def expected_problem_energy_breakdown(
    canonical: CanonicalProblemIR,
    weights: Iterable[tuple[str, float]],
    *,
    penalty_analysis: ProblemPenaltyAnalysisIR | None,
) -> ProblemEnergyBreakdownIR:
    """Stream one normalized distribution into a checked expected decomposition."""
    _validate_penalty_contract(canonical, penalty_analysis)
    probability_mass = 0.0
    business = 0.0
    canonical_total = 0.0
    activations = (
        [0.0] * len(penalty_analysis.penalty_terms)
        if penalty_analysis is not None
        else []
    )
    for bitstring, probability in weights:
        normalized = _finite(probability, "probability")
        if normalized < 0.0:
            raise ValueError("probability must be non-negative.")
        probability_mass += normalized
        values = _bit_values(canonical, bitstring)
        total = _canonical_objective(canonical, values)
        canonical_total += normalized * total
        if penalty_analysis is None:
            business += normalized * total
            continue
        candidate_business = canonical.offset + sum(
            term.coefficient * values[term.variable]
            for term in canonical.linear_terms
        )
        business += normalized * candidate_business
        for index, term in enumerate(penalty_analysis.penalty_terms):
            activations[index] += normalized * float(
                values[term.targets[0]] * values[term.targets[1]]
            )
    if probability_mass <= 0.0 or not math.isclose(
        probability_mass,
        1.0,
        rel_tol=0.0,
        abs_tol=_PROBABILITY_TOLERANCE,
    ):
        raise ValueError("energy breakdown weights must sum to one.")
    if penalty_analysis is None:
        contributions: tuple[ProblemConstraintPenaltyIR, ...] = ()
        status: Literal["defined", "not_applicable"] = "not_applicable"
    else:
        status = "defined"
        contributions = tuple(
            ProblemConstraintPenaltyIR(
                constraint_id=term.constraint_id,
                canonical_term_id=term.canonical_term_id,
                targets=term.targets,
                coefficient=term.coefficient,
                activation=activations[index],
                contribution=term.coefficient * activations[index],
            )
            for index, term in enumerate(penalty_analysis.penalty_terms)
        )
    penalty = sum(item.contribution for item in contributions)
    if not math.isclose(
        business + penalty,
        canonical_total,
        rel_tol=_ENERGY_RELATIVE_TOLERANCE,
        abs_tol=_ENERGY_TOLERANCE,
    ):
        raise ValueError(
            "Expected energy decomposition does not reconstruct the objective."
        )
    return ProblemEnergyBreakdownIR(
        scope="expectation",
        penalty_model_status=status,
        business_objective=business,
        penalty_energy=penalty,
        total_objective=canonical_total,
        constraint_penalties=contributions,
    )


def _validate_penalty_contract(
    canonical: CanonicalProblemIR,
    penalty_analysis: ProblemPenaltyAnalysisIR | None,
) -> None:
    if not isinstance(canonical, CanonicalProblemIR):
        raise TypeError("canonical must be CanonicalProblemIR.")
    if canonical.decoder.decoder_kind in {"mis", "mwis"}:
        _validate_penalty_analysis(canonical, penalty_analysis)
    elif penalty_analysis is not None:
        raise ValueError("Only constrained Problems may provide penalty_analysis.")


def _validate_penalty_analysis(
    canonical: CanonicalProblemIR,
    penalty_analysis: ProblemPenaltyAnalysisIR | None,
) -> None:
    if not isinstance(penalty_analysis, ProblemPenaltyAnalysisIR):
        raise TypeError(
            "Constrained Problem energy decomposition requires "
            "ProblemPenaltyAnalysisIR."
        )
    if penalty_analysis.source_problem_hash != canonical.problem_hash:
        raise ValueError(
            "penalty analysis source hash does not match canonical Problem."
        )
    expected = analyze_problem_penalty(canonical)
    if penalty_analysis != expected:
        raise ValueError(
            "penalty analysis does not match canonical constraints and terms."
        )


def _bit_values(canonical: CanonicalProblemIR, bitstring: str) -> dict[str, int]:
    if len(bitstring) != len(canonical.logical_order) or set(bitstring) - {"0", "1"}:
        raise ValueError("bitstring must match the canonical logical order.")
    raw = (int(bit) for bit in bitstring)
    if canonical.variable_domain == "spin":
        return dict(zip(canonical.logical_order, (2 * bit - 1 for bit in raw)))
    return dict(zip(canonical.logical_order, raw))


def _decoder_penalty_strength(canonical: CanonicalProblemIR) -> float:
    decoder = canonical.decoder
    if decoder.decoder_kind == "mis":
        assert decoder.mis_penalty is not None
        return float(decoder.mis_penalty)
    if decoder.decoder_kind == "mwis":
        assert decoder.mwis_penalty is not None
        return float(decoder.mwis_penalty)
    raise ValueError("Decoder does not define a source penalty model.")


def _canonical_objective(
    canonical: CanonicalProblemIR,
    values: Mapping[str, int],
) -> float:
    return float(
        canonical.offset
        + sum(
            term.coefficient * values[term.variable]
            for term in canonical.linear_terms
        )
        + sum(
            term.coefficient * values[term.left] * values[term.right]
            for term in canonical.quadratic_terms
        )
    )


def _finite(value: object, name: str) -> float:
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        raise TypeError(f"{name} must be a real number.")
    normalized = float(value)
    if not math.isfinite(normalized):
        raise ValueError(f"{name} must be finite.")
    return normalized


def _require_penalty_schema(value: object) -> None:
    if value != PROBLEM_PENALTY_SCHEMA_VERSION:
        raise ValueError(f"Unsupported Problem penalty schema: {value!r}.")


def _require_text(value: object, name: str) -> None:
    if not isinstance(value, str) or not value.strip() or value != value.strip():
        raise ValueError(f"{name} must be a non-empty trimmed string.")


def _require_digest(value: object, name: str) -> None:
    if (
        not isinstance(value, str)
        or len(value) != 64
        or any(character not in "0123456789abcdef" for character in value)
    ):
        raise ValueError(f"{name} must be a lowercase SHA-256 digest.")


def _require_unique_text(
    values: tuple[str, ...],
    name: str,
    *,
    allow_empty: bool = False,
) -> None:
    if not values and not allow_empty:
        raise ValueError(f"{name} must not be empty.")
    if any(not isinstance(value, str) or not value for value in values):
        raise ValueError(f"{name} must contain non-empty strings.")
    if len(values) != len(set(values)):
        raise ValueError(f"{name} must be unique.")


def _mapping(value: object, name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{name} must be a mapping.")
    return value
