"""Unified execution and decoding for compiled optimization Problems."""

from __future__ import annotations

import hashlib
import math
import re
from collections import Counter
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass, field, replace
from os import PathLike
from typing import TYPE_CHECKING, Any, Literal, cast

from cascaqit.algorithms.execution import ParameterValues
from cascaqit.algorithms.gradient import (
    ObjectiveGradientIR,
    build_parameter_shift_plan,
)
from cascaqit.algorithms.models import (
    AlgorithmCandidateIR,
    AnsatzSpecIR,
    ClassicalBaselineIR,
    OptimizationStartIR,
    OptimizerConfig,
    OptimizerTerminationIR,
    PauliHamiltonian,
)
from cascaqit.algorithms.noisy_execution import (
    ObjectiveExecutionEvidenceIR,
    build_objective_execution_evidence,
    validate_noisy_variational_request,
)
from cascaqit.algorithms.optimizer import (
    aggregate_optimizer_termination,
    build_optimization_start_plans,
    run_scalar_optimization,
)
from cascaqit.algorithms.problem_projection import (
    bounded_exhaustive_baseline,
    decode_problem_candidate,
)
from cascaqit.analog import AHSProgram
from cascaqit.digital import Circuit
from cascaqit.exceptions import CapabilityError
from cascaqit.hybrid import HybridProgram
from cascaqit.native_ir.base import IRMixin, stable_json
from cascaqit.observables import ObservableBatchResultIR
from cascaqit.parameters import ParameterBindIR
from cascaqit.problems.analysis import ProblemAnalysisResult
from cascaqit.problems.canonical import CanonicalProblemIR
from cascaqit.problems.execution_context import (
    ProblemExecutionContextIR,
    ProblemNativeProgramIR,
)
from cascaqit.problems.mis import MISInstance
from cascaqit.problems.models import IsingModelIR, MWISProblemIR, QUBOProblemIR
from cascaqit.problems.penalties import (
    ProblemEnergyBreakdownIR,
    evaluate_problem_energy_breakdowns,
    expected_problem_energy_breakdown,
)
from cascaqit.results import ResultIR
from cascaqit.simulators import LocalBackend, NoiseModel, SimulationOptions

if TYPE_CHECKING:
    from cascaqit.problems.compiler import ProblemCompileResult
    from cascaqit.visualization import ExperimentReport

__all__ = [
    "PROBLEM_EXECUTION_SCHEMA_VERSION",
    "ProblemExecutionResult",
    "ProblemExecutionContextIR",
    "ProblemOptimizationIR",
    "ProblemParameterEvaluationIR",
    "build_problem_execution_context",
    "decode_problem_result",
    "evaluate_compiled_problem",
    "optimize_compiled_problem",
    "run_compiled_problem",
]

_ENERGY_ABSOLUTE_TOLERANCE = 1e-12
_ENERGY_RELATIVE_TOLERANCE = 1e-12

PROBLEM_EXECUTION_SCHEMA_VERSION = "cascaqit.problem.execution.v5"
_DIGEST_PATTERN = re.compile(r"[0-9a-f]{64}")
_MODES = frozenset({"digital", "analog", "hybrid"})
_MODE_ALGORITHMS = {
    "digital": frozenset({"qaoa", "vqe"}),
    "analog": frozenset({"qaa"}),
    "hybrid": frozenset({"qaoa"}),
}
_PROBABILITY_TOLERANCE = 1e-9


@dataclass(frozen=True)
class _ProblemEvaluationMetrics:
    """Metrics derived from one complete Problem result distribution."""

    best_observed_candidate: AlgorithmCandidateIR
    feasible_probability: float | None
    expected_constraint_violation_count: float | None
    best_observed_constraint_violation_count: int | None
    expected_selected_weight: float | None
    baseline_objective: float | None
    expected_objective_gap: float | None
    best_observed_objective_gap: float | None


@dataclass(frozen=True)
class ProblemParameterEvaluationIR(IRMixin):
    """Evidence that one concrete parameter point was executed."""

    evaluation_index: int
    parameter_bind: ParameterBindIR
    result_id: str
    result_hash: str
    source_program_hash: str
    program_hash: str
    objective_value: float
    shots: int
    seed: int | None
    best_observed_candidate: AlgorithmCandidateIR
    feasible_probability: float | None
    expected_constraint_violation_count: float | None
    best_observed_constraint_violation_count: int | None
    expected_selected_weight: float | None
    baseline_objective: float | None
    expected_objective_gap: float | None
    best_observed_objective_gap: float | None
    energy_breakdown: ProblemEnergyBreakdownIR
    execution_evidence: ObjectiveExecutionEvidenceIR | None = None
    backend_job_id: str | None = None
    schema_version: str = PROBLEM_EXECUTION_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_execution_schema(self.schema_version)
        if (
            not isinstance(self.evaluation_index, int)
            or isinstance(self.evaluation_index, bool)
            or self.evaluation_index < 0
        ):
            raise ValueError("evaluation_index must be a non-negative integer.")
        if not isinstance(self.parameter_bind, ParameterBindIR):
            raise TypeError("parameter_bind must be ParameterBindIR.")
        if not self.parameter_bind.verify_hash():
            raise ValueError("parameter_bind hash does not match its values.")
        _require_text(self.result_id, "result_id")
        _require_digest(self.result_hash, "result_hash")
        _require_digest(self.source_program_hash, "source_program_hash")
        _require_digest(self.program_hash, "program_hash")
        object.__setattr__(
            self,
            "objective_value",
            _finite(self.objective_value, "objective_value"),
        )
        _non_negative_int(self.shots, "shots")
        _optional_seed(self.seed)
        if not isinstance(self.best_observed_candidate, AlgorithmCandidateIR):
            raise TypeError("best_observed_candidate must be AlgorithmCandidateIR.")
        if self.feasible_probability is None:
            if any(
                value is not None
                for value in (
                    self.expected_constraint_violation_count,
                    self.best_observed_constraint_violation_count,
                )
            ):
                raise ValueError(
                    "constraint metrics must all be None when feasibility is undefined."
                )
            if self.best_observed_candidate.feasible is not None:
                raise ValueError(
                    "undefined feasible_probability requires candidate "
                    "feasibility None."
                )
        else:
            feasible_probability = _finite(
                self.feasible_probability,
                "feasible_probability",
            )
            if not 0.0 <= feasible_probability <= 1.0:
                raise ValueError("feasible_probability must be within [0, 1].")
            object.__setattr__(
                self,
                "feasible_probability",
                feasible_probability,
            )
            if self.expected_constraint_violation_count is None or (
                self.best_observed_constraint_violation_count is None
            ):
                raise ValueError(
                    "constraint metrics are required when feasibility is defined."
                )
            expected_violations = _finite(
                self.expected_constraint_violation_count,
                "expected_constraint_violation_count",
            )
            if expected_violations < 0.0:
                raise ValueError(
                    "expected_constraint_violation_count must be non-negative."
                )
            object.__setattr__(
                self,
                "expected_constraint_violation_count",
                expected_violations,
            )
            _non_negative_int(
                self.best_observed_constraint_violation_count,
                "best_observed_constraint_violation_count",
            )
            if self.best_observed_candidate.feasible is None:
                raise ValueError(
                    "defined feasible_probability requires candidate feasibility."
                )

        candidate_problem_type = self.best_observed_candidate.decoded.get(
            "problem_type"
        )
        if self.expected_selected_weight is None:
            if candidate_problem_type == "mwis":
                raise ValueError(
                    "MWIS parameter evaluations require expected_selected_weight."
                )
        else:
            selected_weight = _finite(
                self.expected_selected_weight,
                "expected_selected_weight",
            )
            if selected_weight < 0.0:
                raise ValueError("expected_selected_weight must be non-negative.")
            if candidate_problem_type != "mwis":
                raise ValueError(
                    "expected_selected_weight is defined only for MWIS results."
                )
            object.__setattr__(
                self,
                "expected_selected_weight",
                selected_weight,
            )

        baseline_metrics = (
            self.baseline_objective,
            self.expected_objective_gap,
            self.best_observed_objective_gap,
        )
        if all(value is None for value in baseline_metrics):
            pass
        elif any(value is None for value in baseline_metrics):
            raise ValueError("baseline metrics must all be present or all be None.")
        else:
            baseline = _finite(self.baseline_objective, "baseline_objective")
            expected_gap = _finite(
                self.expected_objective_gap,
                "expected_objective_gap",
            )
            best_gap = _finite(
                self.best_observed_objective_gap,
                "best_observed_objective_gap",
            )
            if not math.isclose(
                expected_gap,
                self.objective_value - baseline,
                rel_tol=_ENERGY_RELATIVE_TOLERANCE,
                abs_tol=_ENERGY_ABSOLUTE_TOLERANCE,
            ):
                raise ValueError(
                    "expected_objective_gap must equal objective minus baseline."
                )
            if not math.isclose(
                best_gap,
                self.best_observed_candidate.objective_value - baseline,
                rel_tol=_ENERGY_RELATIVE_TOLERANCE,
                abs_tol=_ENERGY_ABSOLUTE_TOLERANCE,
            ):
                raise ValueError(
                    "best_observed_objective_gap must equal candidate minus baseline."
                )
            object.__setattr__(self, "baseline_objective", baseline)
            object.__setattr__(self, "expected_objective_gap", expected_gap)
            object.__setattr__(self, "best_observed_objective_gap", best_gap)
        if not isinstance(self.energy_breakdown, ProblemEnergyBreakdownIR):
            raise TypeError("energy_breakdown must be ProblemEnergyBreakdownIR.")
        if self.energy_breakdown.scope != "expectation":
            raise ValueError("parameter evaluation requires an expectation breakdown.")
        if not math.isclose(
            self.energy_breakdown.total_objective,
            self.objective_value,
            rel_tol=_ENERGY_RELATIVE_TOLERANCE,
            abs_tol=_ENERGY_ABSOLUTE_TOLERANCE,
        ):
            raise ValueError(
                "energy breakdown total must match the parameter objective."
            )
        if self.backend_job_id is not None:
            _require_text(self.backend_job_id, "backend_job_id")
        if self.execution_evidence is not None:
            evidence = self.execution_evidence
            if not isinstance(evidence, ObjectiveExecutionEvidenceIR):
                raise TypeError(
                    "execution_evidence must be ObjectiveExecutionEvidenceIR or None."
                )
            if evidence.result_id != self.result_id:
                raise ValueError("execution evidence result_id does not match result.")
            if evidence.result_hash != self.result_hash:
                raise ValueError(
                    "execution evidence result_hash does not match result."
                )
            if evidence.metadata.get("program_hash") != self.program_hash:
                raise ValueError(
                    "execution evidence program_hash does not match result."
                )
            if evidence.backend_shots != self.shots:
                raise ValueError("execution evidence shots do not match result.")
            if evidence.effective_seed != self.seed:
                raise ValueError("execution evidence seed does not match result.")
            if self.backend_job_id != evidence.backend_job_id:
                raise ValueError(
                    "execution evidence Backend Job does not match result."
                )

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ProblemParameterEvaluationIR:
        """Restore one parameter evaluation from JSON-compatible data."""
        return cls(
            evaluation_index=int(data["evaluation_index"]),
            parameter_bind=ParameterBindIR.from_dict(
                _mapping(data["parameter_bind"], "parameter_bind")
            ),
            result_id=str(data["result_id"]),
            result_hash=str(data["result_hash"]),
            source_program_hash=str(data["source_program_hash"]),
            program_hash=str(data["program_hash"]),
            objective_value=float(data["objective_value"]),
            shots=int(data["shots"]),
            seed=None if data.get("seed") is None else int(data["seed"]),
            best_observed_candidate=AlgorithmCandidateIR.from_dict(
                _mapping(
                    data["best_observed_candidate"],
                    "best_observed_candidate",
                )
            ),
            feasible_probability=data["feasible_probability"],
            expected_constraint_violation_count=data[
                "expected_constraint_violation_count"
            ],
            best_observed_constraint_violation_count=data[
                "best_observed_constraint_violation_count"
            ],
            expected_selected_weight=data.get("expected_selected_weight"),
            baseline_objective=data["baseline_objective"],
            expected_objective_gap=data["expected_objective_gap"],
            best_observed_objective_gap=data["best_observed_objective_gap"],
            energy_breakdown=ProblemEnergyBreakdownIR.from_dict(
                _mapping(data["energy_breakdown"], "energy_breakdown")
            ),
            execution_evidence=(
                None
                if data.get("execution_evidence") is None
                else ObjectiveExecutionEvidenceIR.from_dict(
                    _mapping(data["execution_evidence"], "execution_evidence")
                )
            ),
            backend_job_id=(
                None
                if data.get("backend_job_id") is None
                else str(data["backend_job_id"])
            ),
            schema_version=str(
                data.get("schema_version", PROBLEM_EXECUTION_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> ProblemParameterEvaluationIR:
        """Restore one parameter evaluation from JSON text."""
        import json

        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("ProblemParameterEvaluationIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class ProblemOptimizationIR(IRMixin):
    """Typed search configuration and termination facts for one optimization."""

    optimization_id: str
    search_kind: Literal["parameter_sets", "scipy"]
    evaluation_count: int
    best_evaluation_index: int
    optimizer: OptimizerConfig | None = None
    initial_parameters: Mapping[str, float] | None = None
    final_parameters: Mapping[str, float] | None = None
    final_objective: float | None = None
    termination: OptimizerTerminationIR | None = None
    starts: tuple[OptimizationStartIR, ...] = ()
    selected_start_index: int | None = None
    gradients: tuple[ObjectiveGradientIR, ...] = ()
    schema_version: str = PROBLEM_EXECUTION_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_execution_schema(self.schema_version)
        _require_text(self.optimization_id, "optimization_id")
        if self.search_kind not in {"parameter_sets", "scipy"}:
            raise ValueError(f"Unsupported search_kind: {self.search_kind!r}.")
        if (
            not isinstance(self.evaluation_count, int)
            or isinstance(self.evaluation_count, bool)
            or self.evaluation_count <= 0
        ):
            raise ValueError("evaluation_count must be a positive integer.")
        if (
            not isinstance(self.best_evaluation_index, int)
            or isinstance(self.best_evaluation_index, bool)
            or not 0 <= self.best_evaluation_index < self.evaluation_count
        ):
            raise ValueError("best_evaluation_index is outside the evaluation count.")

        if self.search_kind == "parameter_sets":
            if any(
                value is not None
                for value in (
                    self.optimizer,
                    self.initial_parameters,
                    self.final_parameters,
                    self.final_objective,
                    self.termination,
                    self.selected_start_index,
                )
            ):
                raise ValueError(
                    "parameter_sets optimization cannot contain SciPy fields."
                )
            if self.starts:
                raise ValueError(
                    "parameter_sets optimization cannot contain optimizer starts."
                )
            if self.gradients:
                raise ValueError(
                    "parameter_sets optimization cannot contain gradient history."
                )
            return

        if not isinstance(self.optimizer, OptimizerConfig):
            raise TypeError("SciPy optimization requires OptimizerConfig.")
        if not isinstance(self.termination, OptimizerTerminationIR):
            raise TypeError("SciPy optimization requires termination evidence.")
        if self.termination.nfev != self.evaluation_count:
            raise ValueError("termination nfev must match evaluation_count.")
        if not isinstance(self.gradients, tuple):
            object.__setattr__(self, "gradients", tuple(self.gradients))
        if any(not isinstance(item, ObjectiveGradientIR) for item in self.gradients):
            raise TypeError("gradients must contain ObjectiveGradientIR values.")
        if tuple(item.gradient_index for item in self.gradients) != tuple(
            range(len(self.gradients))
        ):
            raise ValueError("gradient indices must be contiguous and zero-based.")
        if self.optimizer.gradient is None and self.gradients:
            raise ValueError("gradient history requires optimizer GradientConfig.")
        if self.optimizer.gradient is not None and not self.gradients:
            raise ValueError("gradient optimizer requires gradient history.")
        if self.termination.njev != len(self.gradients):
            raise ValueError("termination njev must match gradient history.")
        expected_backend_count = self.evaluation_count + sum(
            item.backend_execution_count for item in self.gradients
        )
        if self.termination.backend_execution_count != expected_backend_count:
            raise ValueError(
                "termination Backend cost must match objective and gradient evidence."
            )
        if self.gradients and len({item.plan_hash for item in self.gradients}) != 1:
            raise ValueError("all gradients must share one parameter-shift plan.")
        if not isinstance(self.starts, tuple):
            object.__setattr__(self, "starts", tuple(self.starts))
        if any(not isinstance(item, OptimizationStartIR) for item in self.starts):
            raise TypeError("starts must contain OptimizationStartIR values.")
        if self.starts:
            if len(self.starts) != self.optimizer.starts:
                raise ValueError("starts must match optimizer starts.")
            if tuple(item.start_index for item in self.starts) != tuple(
                range(len(self.starts))
            ):
                raise ValueError("start indices must be contiguous and zero-based.")
            expected_start = 0
            expected_gradient_start = 0
            for start in self.starts:
                if start.evaluation_start_index != expected_start:
                    raise ValueError("starts must cover contiguous evaluation slices.")
                expected_start += start.evaluation_count
                if start.gradient_start_index != expected_gradient_start:
                    raise ValueError("starts must cover contiguous gradient slices.")
                expected_gradient_start += start.gradient_count
            if expected_start != self.evaluation_count:
                raise ValueError("starts must cover every evaluation exactly once.")
            if expected_gradient_start != len(self.gradients):
                raise ValueError("starts must cover every gradient exactly once.")
            if sum(start.backend_execution_count or 0 for start in self.starts) != (
                self.termination.backend_execution_count
            ):
                raise ValueError("start Backend costs must match termination evidence.")
            if (
                not isinstance(self.selected_start_index, int)
                or isinstance(self.selected_start_index, bool)
                or not 0 <= self.selected_start_index < len(self.starts)
            ):
                raise ValueError("selected_start_index is outside starts.")
            if (
                self.starts[self.selected_start_index].best_evaluation_index
                != self.best_evaluation_index
            ):
                raise ValueError("selected start must own the best evaluation.")
        elif self.selected_start_index is not None:
            raise ValueError("selected_start_index requires starts.")
        initial = _finite_parameter_mapping(
            self.initial_parameters,
            "initial_parameters",
        )
        final = _finite_parameter_mapping(
            self.final_parameters,
            "final_parameters",
        )
        if not initial or initial.keys() != final.keys():
            raise ValueError(
                "initial_parameters and final_parameters must share non-empty keys."
            )
        object.__setattr__(self, "initial_parameters", initial)
        object.__setattr__(self, "final_parameters", final)
        if self.final_objective is None:
            raise ValueError("SciPy optimization requires final_objective.")
        object.__setattr__(
            self,
            "final_objective",
            _finite(self.final_objective, "final_objective"),
        )
        if self.starts:
            assert self.selected_start_index is not None
            selected_start = self.starts[self.selected_start_index]
            if initial != selected_start.initial_parameters:
                raise ValueError(
                    "initial_parameters must match the selected optimizer start."
                )
            if final != selected_start.final_parameters:
                raise ValueError(
                    "final_parameters must match the selected optimizer start."
                )
            if not math.isclose(
                self.final_objective,
                selected_start.final_objective,
                rel_tol=_ENERGY_RELATIVE_TOLERANCE,
                abs_tol=_ENERGY_ABSOLUTE_TOLERANCE,
            ):
                raise ValueError(
                    "final_objective must match the selected optimizer start."
                )

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ProblemOptimizationIR:
        """Restore one optimization summary from JSON-compatible data."""
        return cls(
            optimization_id=str(data["optimization_id"]),
            search_kind=data["search_kind"],
            evaluation_count=int(data["evaluation_count"]),
            best_evaluation_index=int(data["best_evaluation_index"]),
            optimizer=(
                None
                if data.get("optimizer") is None
                else OptimizerConfig.from_dict(_mapping(data["optimizer"], "optimizer"))
            ),
            initial_parameters=(
                None
                if data.get("initial_parameters") is None
                else _finite_parameter_mapping(
                    data["initial_parameters"], "initial_parameters"
                )
            ),
            final_parameters=(
                None
                if data.get("final_parameters") is None
                else _finite_parameter_mapping(
                    data["final_parameters"], "final_parameters"
                )
            ),
            final_objective=(
                None
                if data.get("final_objective") is None
                else float(data["final_objective"])
            ),
            termination=(
                None
                if data.get("termination") is None
                else OptimizerTerminationIR.from_dict(
                    _mapping(data["termination"], "termination")
                )
            ),
            starts=tuple(
                OptimizationStartIR.from_dict(_mapping(item, "optimization_start"))
                for item in data.get("starts", ())
            ),
            selected_start_index=data.get("selected_start_index"),
            gradients=tuple(
                ObjectiveGradientIR.from_dict(_mapping(item, "gradient"))
                for item in data.get("gradients", ())
            ),
            schema_version=str(
                data.get("schema_version", PROBLEM_EXECUTION_SCHEMA_VERSION)
            ),
        )


def _digital_evidence_context(
    evidence: ObjectiveExecutionEvidenceIR,
) -> tuple[object, object, str, object, object]:
    """Return the facts that must stay invariant across one optimization."""
    return (
        evidence.noise_model,
        evidence.requested_options,
        evidence.simulation_plan.method_selected,
        evidence.estimator_kind,
        evidence.source_kind,
    )


def _validate_problem_digital_evidence(
    history: tuple[ProblemParameterEvaluationIR, ...],
) -> None:
    """Keep every Backend-produced Digital objective in one execution context."""
    executed = tuple(
        item.execution_evidence
        for item in history
        if item.execution_evidence is not None
    )
    if not executed:
        return
    reference = _digital_evidence_context(executed[0])
    if any(_digital_evidence_context(item) != reference for item in executed[1:]):
        raise ValueError(
            "Digital parameter history mixes incompatible execution evidence."
        )


def _validate_problem_gradient_evidence(
    history: tuple[ProblemParameterEvaluationIR, ...],
    gradients: tuple[ObjectiveGradientIR, ...],
) -> None:
    """Require objective and parameter-shift Jobs to use one noise context."""
    if not gradients:
        return
    objective_evidence = history[0].execution_evidence
    if objective_evidence is None:
        raise ValueError("Problem gradients require Digital execution evidence.")
    expected = _digital_evidence_context(objective_evidence)
    for gradient in gradients:
        for pair in gradient.shift_pairs:
            for evaluation in (
                pair.positive_evaluation,
                pair.negative_evaluation,
            ):
                if _digital_evidence_context(evaluation.execution_evidence) != expected:
                    raise ValueError(
                        "Problem objective and gradient use incompatible execution "
                        "evidence."
                    )


@dataclass(frozen=True)
class ProblemExecutionResult(IRMixin):
    """One decoded execution with source, binding, and sampling evidence."""

    execution_id: str
    mode: Literal["digital", "analog", "hybrid"]
    algorithm: Literal["qaoa", "vqe", "qaa"]
    topology: str | None
    compile_hash: str
    analysis_hash: str
    problem_hash: str
    logical_order: tuple[str, ...]
    context: ProblemExecutionContextIR
    parameter_bind: ParameterBindIR
    parameter_bind_hash: str
    result: ResultIR
    candidates: tuple[AlgorithmCandidateIR, ...]
    most_probable_candidate: AlgorithmCandidateIR
    best_observed_candidate: AlgorithmCandidateIR
    objective_value: float
    feasibility: bool | None
    constraint_violations: tuple[str, ...]
    candidate_energy_breakdowns: tuple[ProblemEnergyBreakdownIR, ...]
    parameter_history: tuple[ProblemParameterEvaluationIR, ...]
    selected_evaluation_index: int
    optimization: ProblemOptimizationIR | None = None
    baseline: ClassicalBaselineIR | None = None
    optimality_claim: Literal["not_claimed"] = "not_claimed"
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = PROBLEM_EXECUTION_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_execution_schema(self.schema_version)
        _require_text(self.execution_id, "execution_id")
        if self.mode not in _MODES:
            raise ValueError(f"Unsupported Problem execution mode: {self.mode!r}.")
        if self.algorithm not in _MODE_ALGORITHMS[self.mode]:
            raise ValueError("mode and algorithm do not form a supported combination.")
        if self.mode == "hybrid" and self.topology != "dad":
            raise ValueError("Hybrid execution requires topology='dad'.")
        if self.mode != "hybrid" and self.topology is not None:
            raise ValueError("Only Hybrid execution may declare a topology.")
        for name in ("compile_hash", "analysis_hash", "problem_hash"):
            _require_digest(getattr(self, name), name)
        object.__setattr__(self, "logical_order", tuple(self.logical_order))
        _require_unique_text(self.logical_order, "logical_order")
        if not isinstance(self.context, ProblemExecutionContextIR):
            raise TypeError("context must be ProblemExecutionContextIR.")
        if self.context.mode != self.mode or self.context.algorithm != self.algorithm:
            raise ValueError("context mode and algorithm do not match execution.")
        if self.context.topology != self.topology:
            raise ValueError("context topology does not match execution.")
        if self.context.compile_hash != self.compile_hash:
            raise ValueError("context compile_hash does not match execution.")
        if self.context.analysis_hash != self.analysis_hash:
            raise ValueError("context analysis_hash does not match execution.")
        if self.context.problem_hash != self.problem_hash:
            raise ValueError("context problem_hash does not match execution.")
        if self.context.analysis.canonical_problem.logical_order != self.logical_order:
            raise ValueError("context logical order does not match execution.")
        if not isinstance(self.parameter_bind, ParameterBindIR):
            raise TypeError("parameter_bind must be ParameterBindIR.")
        _require_digest(self.parameter_bind_hash, "parameter_bind_hash")
        if self.parameter_bind_hash != self.parameter_bind.parameter_bind_hash:
            raise ValueError("parameter_bind_hash does not match parameter_bind.")
        if not isinstance(self.result, ResultIR):
            raise TypeError("result must be ResultIR.")
        canonical = self.context.analysis.canonical_problem
        _validate_result(self.result, logical_order=canonical.logical_order)
        object.__setattr__(self, "candidates", tuple(self.candidates))
        if not self.candidates or any(
            not isinstance(item, AlgorithmCandidateIR) for item in self.candidates
        ):
            raise ValueError(
                "candidates must contain decoded AlgorithmCandidateIR values."
            )
        bitstrings = tuple(item.bitstring for item in self.candidates)
        if len(bitstrings) != len(set(bitstrings)):
            raise ValueError("candidate bitstrings must be unique.")
        if self.candidates != tuple(sorted(self.candidates, key=_candidate_rank)):
            raise ValueError("candidates must use stable count/probability order.")
        expected_candidates = _decode_result_candidates(canonical, self.result)
        if self.candidates != expected_candidates:
            raise ValueError(
                "decoded candidates do not match the original Result evidence."
            )
        if self.most_probable_candidate != self.candidates[0]:
            raise ValueError("most_probable_candidate must be the first candidate.")
        expected_best = min(
            self.candidates,
            key=lambda item: (item.objective_value, item.bitstring),
        )
        if self.best_observed_candidate != expected_best:
            raise ValueError(
                "best_observed_candidate must minimize observed objective."
            )
        objective = _finite(self.objective_value, "objective_value")
        object.__setattr__(self, "objective_value", objective)
        if self.feasibility != self.best_observed_candidate.feasible:
            raise ValueError("feasibility must describe best_observed_candidate.")
        object.__setattr__(
            self,
            "constraint_violations",
            tuple(self.constraint_violations),
        )
        _require_unique_text(
            self.constraint_violations,
            "constraint_violations",
            allow_empty=True,
        )
        if (self.feasibility is False) != bool(self.constraint_violations):
            raise ValueError("constraint_violations must agree with infeasible status.")
        expected_violations = _constraint_violations(
            canonical,
            self.best_observed_candidate.bitstring,
        )
        if self.constraint_violations != expected_violations:
            raise ValueError(
                "constraint_violations do not match the canonical Problem."
            )
        object.__setattr__(
            self,
            "candidate_energy_breakdowns",
            tuple(self.candidate_energy_breakdowns),
        )
        if any(
            not isinstance(item, ProblemEnergyBreakdownIR)
            for item in self.candidate_energy_breakdowns
        ):
            raise TypeError(
                "candidate_energy_breakdowns must contain ProblemEnergyBreakdownIR."
            )
        if tuple(
            item.bitstring for item in self.candidate_energy_breakdowns
        ) != bitstrings:
            raise ValueError(
                "candidate energy breakdowns must align with decoded candidates."
            )
        expected_candidate_breakdowns = evaluate_problem_energy_breakdowns(
            self.context.analysis.canonical_problem,
            (candidate.bitstring for candidate in self.candidates),
            penalty_analysis=self.context.analysis.penalty_analysis,
        )
        if self.candidate_energy_breakdowns != expected_candidate_breakdowns:
            raise ValueError(
                "candidate energy breakdowns do not match the canonical Problem."
            )
        if any(
            not math.isclose(
                breakdown.total_objective,
                candidate.objective_value,
                rel_tol=_ENERGY_RELATIVE_TOLERANCE,
                abs_tol=_ENERGY_ABSOLUTE_TOLERANCE,
            )
            for candidate, breakdown in zip(
                self.candidates,
                self.candidate_energy_breakdowns,
            )
        ):
            raise ValueError(
                "candidate energy totals do not match decoded objectives."
            )
        object.__setattr__(self, "parameter_history", tuple(self.parameter_history))
        if not self.parameter_history or any(
            not isinstance(item, ProblemParameterEvaluationIR)
            for item in self.parameter_history
        ):
            raise ValueError("parameter_history must contain real evaluations.")
        if self.mode == "digital":
            if any(
                item.backend_job_id is not None and item.execution_evidence is None
                for item in self.parameter_history
            ):
                raise ValueError(
                    "executed Digital parameter history requires execution evidence."
                )
            _validate_problem_digital_evidence(self.parameter_history)
        elif any(
            item.execution_evidence is not None for item in self.parameter_history
        ):
            raise ValueError(
                "Analog and Hybrid parameter history cannot contain Digital "
                "execution evidence."
            )
        indices = tuple(item.evaluation_index for item in self.parameter_history)
        if indices != tuple(range(len(self.parameter_history))):
            raise ValueError(
                "parameter_history indices must be contiguous and zero-based."
            )
        if (
            not isinstance(self.selected_evaluation_index, int)
            or isinstance(self.selected_evaluation_index, bool)
            or not 0 <= self.selected_evaluation_index < len(self.parameter_history)
        ):
            raise ValueError("selected_evaluation_index is outside parameter_history.")
        selected = self.parameter_history[self.selected_evaluation_index]
        expected_selected = min(
            self.parameter_history,
            key=lambda item: (item.objective_value, item.evaluation_index),
        ).evaluation_index
        if self.selected_evaluation_index != expected_selected:
            raise ValueError(
                "selected_evaluation_index must minimize the parameter history."
            )
        if self.context.native_program_hash != self.result.program_hash and (
            selected.execution_evidence is None
            or selected.execution_evidence.noise_model is None
        ):
            raise ValueError("context Native Program does not match result.")
        if selected.parameter_bind != self.parameter_bind:
            raise ValueError(
                "selected history binding does not match the result binding."
            )
        if selected.result_hash != self.result.stable_hash():
            raise ValueError("selected history result hash does not match result.")
        if selected.result_id != self.result.result_id:
            raise ValueError("selected history result id does not match result.")
        if selected.program_hash != self.result.program_hash:
            raise ValueError("selected history program hash does not match result.")
        if selected.source_program_hash != self.context.native_program_hash:
            raise ValueError(
                "selected history source program does not match execution context."
            )
        if selected.shots != self.result.shots:
            raise ValueError("selected history shots do not match result.")
        if not math.isclose(
            selected.objective_value,
            self.objective_value,
            rel_tol=_ENERGY_RELATIVE_TOLERANCE,
            abs_tol=_ENERGY_ABSOLUTE_TOLERANCE,
        ):
            raise ValueError("selected history objective does not match result.")
        expected_selected_breakdown = expected_problem_energy_breakdown(
            self.context.analysis.canonical_problem,
            _result_weights(self.result),
            penalty_analysis=self.context.analysis.penalty_analysis,
        )
        if selected.energy_breakdown != expected_selected_breakdown:
            raise ValueError(
                "selected history energy breakdown does not match result distribution."
            )
        expected_penalty_status = (
            "defined"
            if self.context.analysis.penalty_analysis is not None
            else "not_applicable"
        )
        if any(
            item.energy_breakdown.penalty_model_status != expected_penalty_status
            for item in self.parameter_history
        ):
            raise ValueError(
                "parameter history penalty status does not match Problem analysis."
            )
        if self.baseline is not None and not isinstance(
            self.baseline, ClassicalBaselineIR
        ):
            raise TypeError("baseline must be ClassicalBaselineIR or None.")
        expected_baseline = _canonical_baseline(canonical)
        if self.baseline != expected_baseline:
            raise ValueError("baseline does not match the canonical Problem.")
        expected_metrics = _problem_evaluation_metrics(
            canonical=canonical,
            result=self.result,
            best_observed_candidate=self.best_observed_candidate,
            baseline=self.baseline,
            objective_value=self.objective_value,
        )
        actual_metrics = _ProblemEvaluationMetrics(
            best_observed_candidate=selected.best_observed_candidate,
            feasible_probability=selected.feasible_probability,
            expected_constraint_violation_count=(
                selected.expected_constraint_violation_count
            ),
            best_observed_constraint_violation_count=(
                selected.best_observed_constraint_violation_count
            ),
            expected_selected_weight=selected.expected_selected_weight,
            baseline_objective=selected.baseline_objective,
            expected_objective_gap=selected.expected_objective_gap,
            best_observed_objective_gap=selected.best_observed_objective_gap,
        )
        if actual_metrics != expected_metrics:
            raise ValueError(
                "selected parameter evaluation does not match result distribution."
            )
        if self.optimization is not None:
            if not isinstance(self.optimization, ProblemOptimizationIR):
                raise TypeError("optimization must be ProblemOptimizationIR or None.")
            if self.optimization.evaluation_count != len(self.parameter_history):
                raise ValueError(
                    "optimization evaluation_count must match parameter_history."
                )
            if (
                self.optimization.best_evaluation_index
                != self.selected_evaluation_index
            ):
                raise ValueError(
                    "optimization best index must match selected_evaluation_index."
                )
            expected_parameter_names = tuple(
                item.name for item in self.context.parameter_schema.parameters
            )
            expected_hamiltonian_hash = (
                self.context.analysis.logical_hamiltonian.pauli_hamiltonian_hash
            )
            for gradient in self.optimization.gradients:
                if gradient.plan.logical_order != self.logical_order:
                    raise ValueError(
                        "optimization gradient logical order does not match Problem."
                    )
                if gradient.plan.parameter_names != expected_parameter_names:
                    raise ValueError(
                        "optimization gradient parameters do not match Problem."
                    )
                if gradient.plan.hamiltonian_hash != expected_hamiltonian_hash:
                    raise ValueError(
                        "optimization gradient Hamiltonian does not match Problem."
                    )
            _validate_problem_gradient_evidence(
                self.parameter_history,
                self.optimization.gradients,
            )
            for start in self.optimization.starts:
                start_history = self.parameter_history[
                    start.evaluation_start_index :
                    start.evaluation_start_index + start.evaluation_count
                ]
                if any(item.seed != start.seed for item in start_history):
                    raise ValueError(
                        "optimizer start seed does not match parameter_history."
                    )
                if dict(start_history[0].parameter_bind.values) != dict(
                    start.initial_parameters
                ):
                    raise ValueError(
                        "optimizer start initial parameters do not match "
                        "parameter_history."
                    )
                local_best = min(
                    start_history,
                    key=lambda item: (item.objective_value, item.evaluation_index),
                )
                if start.best_evaluation_index != local_best.evaluation_index:
                    raise ValueError(
                        "optimizer start best index does not match parameter_history."
                    )
                if not math.isclose(
                    start.best_objective,
                    local_best.objective_value,
                    rel_tol=_ENERGY_RELATIVE_TOLERANCE,
                    abs_tol=_ENERGY_ABSOLUTE_TOLERANCE,
                ):
                    raise ValueError(
                        "optimizer start best objective does not match "
                        "parameter_history."
                    )
        if self.optimality_claim != "not_claimed":
            raise ValueError("ProblemExecutionResult cannot claim global optimality.")
        if not isinstance(self.metadata, dict):
            raise TypeError("metadata must be a dictionary.")
        object.__setattr__(self, "metadata", dict(self.metadata))

    @property
    def execution_hash(self) -> str:
        """Return a stable hash of all execution and decoding evidence."""
        return self.stable_hash()

    def report(
        self,
        output: str | PathLike[str] | None = None,
        *,
        language: Literal["en", "zh"] = "en",
        title: str | None = None,
    ) -> ExperimentReport:
        """Build and optionally save the standard Problem experiment report."""
        from cascaqit.visualization import visualize

        report = visualize(self, profile="problem", title=title)
        if output is not None:
            report.save(output, language=language)
        return report

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ProblemExecutionResult:
        """Restore a Problem execution result from JSON-compatible data."""
        return cls(
            execution_id=str(data["execution_id"]),
            mode=data["mode"],
            algorithm=data["algorithm"],
            topology=(None if data.get("topology") is None else str(data["topology"])),
            compile_hash=str(data["compile_hash"]),
            analysis_hash=str(data["analysis_hash"]),
            problem_hash=str(data["problem_hash"]),
            logical_order=tuple(str(item) for item in data["logical_order"]),
            context=ProblemExecutionContextIR.from_dict(
                dict(_mapping(data["context"], "context"))
            ),
            parameter_bind=ParameterBindIR.from_dict(
                _mapping(data["parameter_bind"], "parameter_bind")
            ),
            parameter_bind_hash=str(data["parameter_bind_hash"]),
            result=ResultIR.from_dict(dict(_mapping(data["result"], "result"))),
            candidates=tuple(
                AlgorithmCandidateIR.from_dict(_mapping(item, "candidate"))
                for item in _sequence(data["candidates"], "candidates")
            ),
            most_probable_candidate=AlgorithmCandidateIR.from_dict(
                _mapping(
                    data["most_probable_candidate"],
                    "most_probable_candidate",
                )
            ),
            best_observed_candidate=AlgorithmCandidateIR.from_dict(
                _mapping(data["best_observed_candidate"], "best_observed_candidate")
            ),
            objective_value=float(data["objective_value"]),
            feasibility=data.get("feasibility"),
            constraint_violations=tuple(
                str(item) for item in data.get("constraint_violations", ())
            ),
            candidate_energy_breakdowns=tuple(
                ProblemEnergyBreakdownIR.from_dict(
                    _mapping(item, "candidate_energy_breakdown")
                )
                for item in _sequence(
                    data["candidate_energy_breakdowns"],
                    "candidate_energy_breakdowns",
                )
            ),
            parameter_history=tuple(
                ProblemParameterEvaluationIR.from_dict(
                    _mapping(item, "parameter_history item")
                )
                for item in _sequence(data["parameter_history"], "parameter_history")
            ),
            selected_evaluation_index=int(data["selected_evaluation_index"]),
            optimization=(
                None
                if data.get("optimization") is None
                else ProblemOptimizationIR.from_dict(
                    _mapping(data["optimization"], "optimization")
                )
            ),
            baseline=(
                None
                if data.get("baseline") is None
                else ClassicalBaselineIR.from_dict(
                    _mapping(data["baseline"], "baseline")
                )
            ),
            optimality_claim=data.get("optimality_claim", "not_claimed"),
            metadata=dict(_mapping(data.get("metadata", {}), "metadata")),
            schema_version=str(
                data.get("schema_version", PROBLEM_EXECUTION_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> ProblemExecutionResult:
        """Restore a Problem execution result from JSON text."""
        import json

        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("ProblemExecutionResult JSON must contain an object.")
        return cls.from_dict(data)


def _reject_non_digital_noise(
    compiled: ProblemCompileResult,
    *,
    noise: NoiseModel | None,
    operation: str,
) -> None:
    """Reject noisy Analog/Hybrid Problem requests before binding or Job creation."""
    if noise is None or compiled.mode == "digital":
        return
    raise CapabilityError(
        "Problem noise is currently available only for Digital QAOA/VQE.",
        code="PROBLEM_NOISY_MODE_UNSUPPORTED",
        stage="optimization" if operation == "optimize" else "execution",
        object_path=f"problem.compile.{compiled.mode}.{operation}.noise",
        metadata={
            "mode": compiled.mode,
            "algorithm": compiled.algorithm,
            "operation": operation,
        },
    )


def _digital_hamiltonian(compiled: ProblemCompileResult) -> PauliHamiltonian:
    """Return the typed Digital Hamiltonian after checking the union member."""
    hamiltonian = getattr(compiled, "hamiltonian", None)
    if not isinstance(hamiltonian, PauliHamiltonian):
        raise RuntimeError("Digital compile result lost its Pauli Hamiltonian.")
    return hamiltonian


def _digital_observable_objective(
    hamiltonian: PauliHamiltonian,
    observable_batch: ObservableBatchResultIR,
) -> float:
    """Reconstruct the Hamiltonian energy from the same Result used by decoding."""
    if len(observable_batch.items) != len(hamiltonian.terms):
        raise ValueError("Digital Observable batch does not cover the Hamiltonian.")
    energy = hamiltonian.constant
    for term, observable in zip(hamiltonian.terms, observable_batch.items):
        if term.observable.name != observable.name:
            raise ValueError("Digital Observable order does not match the Hamiltonian.")
        energy += term.coefficient * observable.expectation
    return float(energy)


def run_compiled_problem(
    compiled: ProblemCompileResult,
    *,
    params: Mapping[str, float] | None = None,
    shots: int = 1024,
    seed: int | None = 0,
    backend: LocalBackend | None = None,
    noise: NoiseModel | None = None,
    options: SimulationOptions | None = None,
    job_id: str | None = None,
) -> ProblemExecutionResult:
    """Bind, execute, and decode one compiled Problem program."""
    _non_negative_int(shots, "shots")
    _optional_seed(seed)
    _reject_non_digital_noise(compiled, noise=noise, operation="run")
    if compiled.mode == "hybrid" and shots == 0:
        raise ValueError(
            "Hybrid run() requires positive shots; use evaluate() for exact "
            "probabilities."
        )
    if compiled.mode == "digital" and noise is not None and shots == 0:
        raise ValueError(
            "Noisy Digital run() requires positive shots; use evaluate() for an "
            "exact-density objective."
        )
    bound = _bound_compile_result(compiled, params=params)
    parameter_bind = bound.parameter_bind
    if parameter_bind is None:
        raise RuntimeError("Bound Problem execution lost its parameter binding.")
    execution_backend = _execution_backend(bound, backend=backend, seed=seed)
    execution_program = _execution_program(bound)
    digital_hamiltonian = (
        _digital_hamiltonian(bound) if bound.mode == "digital" else None
    )
    planned_noisy_execution = None
    if noise is not None:
        if not isinstance(execution_program, Circuit):
            raise RuntimeError("Noisy Digital execution lost its bound Circuit.")
        planned_noisy_execution = validate_noisy_variational_request(
            execution_program,
            noise=noise,
            options=options,
            backend=execution_backend,
            seed=seed,
        )
    context = build_problem_execution_context(
        bound,
        execution_program=execution_program,
    )
    bind_hash = parameter_bind.parameter_bind_hash
    resolved_job_id = (
        f"problem.{bound.mode}.{bound.compile_hash[:12]}.{bind_hash[:12]}.run"
        if job_id is None
        else job_id
    )
    job = execution_backend.run(
        execution_program,
        shots=shots,
        seed=seed,
        job_id=resolved_job_id,
        observables=(
            digital_hamiltonian.observable_set()
            if digital_hamiltonian is not None
            else None
        ),
        noise=noise,
        options=options,
    )
    result = job.result()
    status = job.status()
    execution_evidence = None
    if bound.mode == "digital":
        observable_batch = result.observable_batch
        if observable_batch is None:
            raise RuntimeError(
                "Digital Problem execution did not return Observable evidence."
            )
        execution_evidence = build_objective_execution_evidence(
            result=result,
            observable_batch=observable_batch,
            noise=noise,
            options=options,
            requested_seed=seed,
            backend_id=status.backend_id,
            backend_job_id=status.job_id,
        )
        if (
            planned_noisy_execution is not None
            and execution_evidence.simulation_plan.stable_hash()
            != planned_noisy_execution.stable_hash()
        ):
            raise RuntimeError(
                "Noisy Problem SimulationPlan changed between preflight and execution."
            )
    decoded = decode_problem_result(
        analysis=bound.analysis,
        mode=bound.mode,
        algorithm=bound.algorithm,
        topology=bound.topology,
        compile_hash=bound.compile_hash,
        context=context,
        parameter_bind=parameter_bind,
        result=result,
        source_program_hash=context.native_program_hash,
        execution_evidence=execution_evidence,
        seed=_result_seed(result, fallback=seed),
        backend_job_id=status.job_id,
        metadata={
            "backend_id": status.backend_id,
            "backend_job_id": status.job_id,
            "backend_execution_count": status.execution_count,
            "execution_program_hash": result.program_hash,
            "requested_seed": seed,
        },
    )
    if bound.mode == "digital":
        assert result.observable_batch is not None
        assert digital_hamiltonian is not None
        observable_objective = _digital_observable_objective(
            digital_hamiltonian,
            result.observable_batch,
        )
        if not math.isclose(
            observable_objective,
            decoded.objective_value,
            rel_tol=_ENERGY_RELATIVE_TOLERANCE,
            abs_tol=_ENERGY_ABSOLUTE_TOLERANCE,
        ):
            raise ValueError(
                "Digital Observable objective does not match Problem decoding."
            )
    return decoded


def build_problem_execution_context(
    compiled: ProblemCompileResult,
    *,
    execution_program: Circuit | AHSProgram | HybridProgram | None = None,
) -> ProblemExecutionContextIR:
    """Capture the selected compile facts and exact Native Program snapshot."""
    program = (
        _execution_program(compiled) if execution_program is None else execution_program
    )
    native_program: ProblemNativeProgramIR
    if compiled.mode == "digital":
        if not isinstance(program, Circuit):
            raise TypeError("Digital execution context requires a Circuit.")
        native_program = program.to_ir()
        native_program_hash = native_program.stable_hash()
    elif compiled.mode == "analog":
        if not isinstance(program, AHSProgram):
            raise TypeError("Analog execution context requires an AHSProgram.")
        native_program = program.to_ir()
        native_program_hash = native_program.stable_hash()
    else:
        if not isinstance(program, HybridProgram):
            raise TypeError("Hybrid execution context requires a HybridProgram.")
        native_program = program.to_ir()
        native_program_hash = program.stable_hash()

    identity_hash = hashlib.sha256(
        stable_json(
            {
                "compile_hash": compiled.compile_hash,
                "native_program_hash": native_program_hash,
                "parameter_bind": compiled.parameter_bind,
            }
        ).encode("utf-8")
    ).hexdigest()
    context_ansatz: AnsatzSpecIR | None = getattr(compiled, "ansatz", None)
    return ProblemExecutionContextIR(
        context_id=f"problem.context.{compiled.mode}.{identity_hash[:20]}",
        mode=compiled.mode,  # type: ignore[arg-type]
        algorithm=compiled.algorithm,  # type: ignore[arg-type]
        topology=compiled.topology,
        compile_hash=compiled.compile_hash,
        analysis=compiled.analysis,
        term_mapping=compiled.term_mapping,
        parameter_schema=compiled.parameter_schema,
        ansatz=context_ansatz,
        ansatz_spec_hash=(
            context_ansatz.spec_hash if context_ansatz is not None else None
        ),
        native_program=native_program,
        native_program_hash=native_program_hash,
        local_reference=compiled.local_reference,
        hardware_executable=compiled.hardware_executable,
        metadata={
            "native_program_kind": compiled.mode,
            "target_id": compiled.analysis.mapping_plan.target_id,
            "target_hash": compiled.analysis.mapping_plan.target_hash,
        },
    )


def evaluate_compiled_problem(
    compiled: ProblemCompileResult,
    *,
    params: Mapping[str, float] | None = None,
    seed: int | None = 0,
    backend: LocalBackend | None = None,
    noise: NoiseModel | None = None,
    options: SimulationOptions | None = None,
) -> ProblemExecutionResult:
    """Evaluate exact basis probabilities for one concrete parameter point."""
    # Hybrid execution currently requires a positive terminal measurement count.
    # One shot satisfies that runtime contract; the objective still uses the exact
    # probability vector returned by the ideal backend, never the one-shot count.
    shots = 1 if compiled.mode == "hybrid" or noise is not None else 0
    return run_compiled_problem(
        compiled,
        params=params,
        shots=shots,
        seed=seed,
        backend=backend,
        noise=noise,
        options=options,
    )


def optimize_compiled_problem(
    compiled: ProblemCompileResult,
    *,
    parameter_sets: Sequence[Mapping[str, float]] | None = None,
    optimizer: OptimizerConfig | None = None,
    initial_parameters: ParameterValues | None = None,
    shots: int = 0,
    seed: int | None = 0,
    backend: LocalBackend | None = None,
    noise: NoiseModel | None = None,
    options: SimulationOptions | None = None,
) -> ProblemExecutionResult:
    """Run exactly one discrete or SciPy optimization strategy."""
    _reject_non_digital_noise(compiled, noise=noise, operation="optimize")
    if (parameter_sets is None) == (optimizer is None):
        raise ValueError("Provide exactly one of parameter_sets or optimizer.")
    if parameter_sets is not None:
        if initial_parameters is not None:
            raise ValueError("initial_parameters are available only with optimizer.")
        return _optimize_parameter_sets(
            compiled,
            parameter_sets=parameter_sets,
            shots=shots,
            seed=seed,
            backend=backend,
            noise=noise,
            options=options,
        )
    if not isinstance(optimizer, OptimizerConfig):
        raise TypeError("optimizer must be OptimizerConfig.")
    return _optimize_continuous_problem(
        compiled,
        optimizer=optimizer,
        initial_parameters=initial_parameters,
        shots=shots,
        seed=seed,
        backend=backend,
        noise=noise,
        options=options,
    )


def _optimize_parameter_sets(
    compiled: ProblemCompileResult,
    *,
    parameter_sets: Sequence[Mapping[str, float]],
    shots: int,
    seed: int | None,
    backend: LocalBackend | None,
    noise: NoiseModel | None,
    options: SimulationOptions | None,
) -> ProblemExecutionResult:
    """Execute caller-supplied points without applying a classical optimizer."""
    if not isinstance(parameter_sets, Sequence) or isinstance(
        parameter_sets, (str, bytes)
    ):
        raise TypeError("parameter_sets must be a sequence of mappings.")
    if not parameter_sets:
        raise ValueError("parameter_sets must not be empty.")
    _non_negative_int(shots, "shots")
    _optional_seed(seed)
    effective_shots = (
        1
        if (compiled.mode == "hybrid" or noise is not None) and shots == 0
        else shots
    )
    execution_backend = _execution_backend(compiled, backend=backend, seed=seed)
    executions = tuple(
        run_compiled_problem(
            compiled,
            params=params,
            shots=effective_shots,
            seed=seed,
            backend=execution_backend,
            noise=noise,
            options=options,
            job_id=(
                f"problem.{compiled.mode}.{compiled.compile_hash[:12]}."
                f"parameter-set.{index:06d}"
            ),
        )
        for index, params in enumerate(parameter_sets)
    )
    return _finalize_problem_optimization(
        compiled,
        executions=executions,
        search_kind="parameter_sets",
        requested_shots=shots,
        effective_shots=effective_shots,
    )


def _optimize_continuous_problem(
    compiled: ProblemCompileResult,
    *,
    optimizer: OptimizerConfig,
    initial_parameters: ParameterValues | None,
    shots: int,
    seed: int | None,
    backend: LocalBackend | None,
    noise: NoiseModel | None,
    options: SimulationOptions | None,
) -> ProblemExecutionResult:
    """Minimize the decoded expected objective through the shared SciPy adapter."""
    _non_negative_int(shots, "shots")
    _optional_seed(seed)
    config = resolve_problem_optimizer_config(compiled, optimizer)
    if config.gradient is not None and compiled.mode != "digital":
        raise CapabilityError(
            "Problem gradient optimization is available only for Digital QAOA/VQE.",
            code="PROBLEM_GRADIENT_MODE_UNSUPPORTED",
            stage="optimization",
            object_path=f"problem.compile.{compiled.mode}.optimize.gradient",
            metadata={"mode": compiled.mode, "algorithm": compiled.algorithm},
        )
    parameter_names = tuple(
        parameter.name for parameter in compiled.parameter_schema.parameters
    )
    resolved_seed = _problem_optimizer_seed(config, backend=backend, seed=seed)
    algorithm_kind = cast(Literal["qaoa", "vqe", "qaa"], compiled.algorithm)
    plans = build_optimization_start_plans(
        algorithm_kind=algorithm_kind,
        layers=getattr(compiled, "layers", 1),
        parameter_names=parameter_names,
        optimizer=config,
        initial_parameters=initial_parameters,
        seed=resolved_seed,
        default_initial_parameters=_problem_default_initial_parameters(
            compiled,
            parameter_names=parameter_names,
        ),
    )
    effective_shots = (
        1
        if (compiled.mode == "hybrid" or noise is not None) and shots == 0
        else shots
    )
    execution_backend = _execution_backend(
        compiled,
        backend=backend,
        seed=resolved_seed,
    )
    run_hash = hashlib.sha256(
        stable_json(
            {
                "compile_hash": compiled.compile_hash,
                "optimizer": config,
                "starts": plans,
                "seed": resolved_seed,
                "shots": shots,
                "noise": noise,
                "options": options,
            }
        ).encode("utf-8")
    ).hexdigest()
    executions: list[ProblemExecutionResult] = []
    gradients: list[ObjectiveGradientIR] = []
    gradient_plan = None
    if config.gradient is not None:
        program = getattr(compiled, "program", None)
        hamiltonian = getattr(compiled, "hamiltonian", None)
        if not isinstance(program, Circuit) or not isinstance(
            hamiltonian,
            PauliHamiltonian,
        ):
            raise RuntimeError(
                "Digital compile result lost its Circuit or Pauli Hamiltonian."
            )
        gradient_plan = build_parameter_shift_plan(
            program,
            hamiltonian,
            config=config.gradient,
        )
    start_results: list[OptimizationStartIR] = []
    for plan in plans:
        evaluation_start_index = len(executions)
        gradient_start_index = len(gradients)

        def objective(
            values: tuple[float, ...],
            evaluation_index: int,
            *,
            _seed: int = plan.seed,
            _start_index: int = plan.start_index,
        ) -> float:
            execution = run_compiled_problem(
                compiled,
                params=dict(zip(parameter_names, values)),
                shots=effective_shots,
                seed=_seed,
                backend=execution_backend,
                noise=noise,
                options=options,
                job_id=(
                    f"problem.{compiled.mode}.{run_hash[:12]}."
                    f"start.{_start_index:03d}.scipy."
                    f"{evaluation_index:06d}"
                ),
            )
            executions.append(execution)
            return execution.objective_value

        def gradient(
            values: tuple[float, ...],
            gradient_index: int,
            *,
            _seed: int = plan.seed,
            _gradient_offset: int = gradient_start_index,
        ) -> tuple[float, ...]:
            assert config.gradient is not None
            assert gradient_plan is not None
            gradient_method = getattr(compiled, "gradient", None)
            if not callable(gradient_method):
                raise RuntimeError("Digital compile result lost its gradient method.")
            computed = gradient_method(
                params=dict(zip(parameter_names, values)),
                backend=execution_backend,
                gradient_index=_gradient_offset + gradient_index,
                algorithm_run_id=f"problem.{run_hash[:20]}",
                seed=_seed,
                config=config.gradient,
                noise=noise,
                options=options,
            )
            if computed.plan_hash != gradient_plan.plan_hash:
                raise RuntimeError("Problem gradient plan changed during optimization.")
            if (
                computed.backend_execution_count
                != gradient_plan.expected_backend_execution_count
            ):
                raise RuntimeError("Problem gradient Backend cost changed from plan.")
            gradients.append(computed)
            return tuple(computed.gradient[name] for name in parameter_names)

        outcome = run_scalar_optimization(
            parameter_names=parameter_names,
            objective=objective,
            optimizer=config,
            initial_parameters=plan.parameters,
            gradient=gradient if config.gradient is not None else None,
            gradient_backend_execution_count=(
                0
                if gradient_plan is None
                else gradient_plan.expected_backend_execution_count
            ),
        )
        observed = tuple(
            item.objective_value for item in executions[evaluation_start_index:]
        )
        if observed != outcome.objective_values:
            raise RuntimeError(
                "SciPy objective history does not match Problem execution evidence."
            )
        global_best_index = evaluation_start_index + outcome.best_evaluation_index
        if outcome.termination.njev != len(gradients) - gradient_start_index:
            raise RuntimeError(
                "SciPy njev does not match Problem gradient history."
            )
        start_results.append(
            OptimizationStartIR(
                start_index=plan.start_index,
                seed=plan.seed,
                initialization=plan.initialization,
                evaluation_start_index=evaluation_start_index,
                evaluation_count=outcome.termination.nfev,
                best_evaluation_index=global_best_index,
                initial_parameters=dict(
                    zip(parameter_names, outcome.initial_parameters)
                ),
                final_parameters=dict(zip(parameter_names, outcome.final_parameters)),
                final_objective=outcome.final_objective,
                best_objective=executions[global_best_index].objective_value,
                termination=outcome.termination,
                gradient_start_index=gradient_start_index,
                gradient_count=outcome.termination.njev,
                backend_execution_count=outcome.termination.backend_execution_count,
            )
        )

    best_index = min(
        range(len(executions)),
        key=lambda index: (executions[index].objective_value, index),
    )
    selected_start_index = next(
        item.start_index
        for item in start_results
        if item.best_evaluation_index == best_index
    )
    starts = tuple(start_results)
    selected_start = starts[selected_start_index]
    termination = aggregate_optimizer_termination(
        starts,
        selected_start_index=selected_start_index,
    )
    return _finalize_problem_optimization(
        compiled,
        executions=tuple(executions),
        search_kind="scipy",
        requested_shots=shots,
        effective_shots=effective_shots,
        expected_best_index=best_index,
        optimizer=config,
        initial_parameters=selected_start.initial_parameters,
        final_parameters=selected_start.final_parameters,
        final_objective=selected_start.final_objective,
        termination=termination,
        starts=starts,
        selected_start_index=selected_start_index,
        gradients=tuple(gradients),
    )


def _finalize_problem_optimization(
    compiled: ProblemCompileResult,
    *,
    executions: Sequence[ProblemExecutionResult],
    search_kind: Literal["parameter_sets", "scipy"],
    requested_shots: int,
    effective_shots: int,
    expected_best_index: int | None = None,
    optimizer: OptimizerConfig | None = None,
    initial_parameters: Mapping[str, float] | None = None,
    final_parameters: Mapping[str, float] | None = None,
    final_objective: float | None = None,
    termination: OptimizerTerminationIR | None = None,
    starts: tuple[OptimizationStartIR, ...] = (),
    selected_start_index: int | None = None,
    gradients: tuple[ObjectiveGradientIR, ...] = (),
) -> ProblemExecutionResult:
    """Select the best real execution and attach one typed optimization summary."""
    if not executions:
        raise ValueError("optimization executions must not be empty.")
    best_index = min(
        range(len(executions)),
        key=lambda index: (executions[index].objective_value, index),
    )
    if expected_best_index is not None and expected_best_index != best_index:
        raise RuntimeError("Optimizer best index does not match Problem executions.")
    best = executions[best_index]
    history = tuple(
        replace(execution.parameter_history[0], evaluation_index=index)
        for index, execution in enumerate(executions)
    )
    canonical = compiled.analysis.canonical_problem
    baseline = _canonical_baseline(canonical)
    summary_payload = {
        "compile_hash": compiled.compile_hash,
        "search_kind": search_kind,
        # Runtime result hashes can contain timing facts and are intentionally
        # retained in parameter_history rather than the semantic optimization id.
        # Fixed inputs and seeds therefore produce the same typed summary even
        # when two executions have different wall-clock evidence.
        "evaluations": tuple(
            {
                "evaluation_index": item.evaluation_index,
                "parameter_bind_hash": item.parameter_bind.parameter_bind_hash,
                "objective_value": item.objective_value,
                "best_observed_candidate": item.best_observed_candidate,
                "feasible_probability": item.feasible_probability,
                "expected_constraint_violation_count": (
                    item.expected_constraint_violation_count
                ),
                "best_observed_constraint_violation_count": (
                    item.best_observed_constraint_violation_count
                ),
                "baseline_objective": item.baseline_objective,
                "expected_objective_gap": item.expected_objective_gap,
                "best_observed_objective_gap": (item.best_observed_objective_gap),
                "energy_breakdown": item.energy_breakdown,
                "shots": item.shots,
                "seed": item.seed,
                "source_program_hash": item.source_program_hash,
                "execution_context": (
                    None
                    if item.execution_evidence is None
                    else {
                        "noise_model": item.execution_evidence.noise_model,
                        "requested_options": (
                            item.execution_evidence.requested_options
                        ),
                        "simulation_method": (
                            item.execution_evidence.simulation_plan.method_selected
                        ),
                        "estimator_kind": item.execution_evidence.estimator_kind,
                        "source_kind": item.execution_evidence.source_kind,
                    }
                ),
            }
            for item in history
        ),
        "best_evaluation_index": best_index,
        "optimizer": optimizer,
        "initial_parameters": initial_parameters,
        "final_parameters": final_parameters,
        "final_objective": final_objective,
        "termination": termination,
        "starts": starts,
        "selected_start_index": selected_start_index,
        "gradients": gradients,
    }
    summary_hash = hashlib.sha256(
        stable_json(summary_payload).encode("utf-8")
    ).hexdigest()
    optimization = ProblemOptimizationIR(
        optimization_id=f"problem.optimization.{summary_hash[:20]}",
        search_kind=search_kind,
        evaluation_count=len(history),
        best_evaluation_index=best_index,
        optimizer=optimizer,
        initial_parameters=initial_parameters,
        final_parameters=final_parameters,
        final_objective=final_objective,
        termination=termination,
        starts=starts,
        selected_start_index=selected_start_index,
        gradients=gradients,
    )
    optimization_hash = hashlib.sha256(
        stable_json(
            {
                "compile_hash": compiled.compile_hash,
                "history": history,
                "selected_evaluation_index": best_index,
                "optimization": optimization,
            }
        ).encode("utf-8")
    ).hexdigest()
    return replace(
        best,
        execution_id=f"problem.execution.optimize.{optimization_hash[:20]}",
        parameter_history=history,
        selected_evaluation_index=best_index,
        optimization=optimization,
        baseline=baseline,
        metadata={
            **best.metadata,
            "execution_role": (
                "parameter_set_optimization"
                if search_kind == "parameter_sets"
                else "continuous_optimization"
            ),
            "parameter_set_count": len(history),
            "optimizer_start_count": len(starts) if starts else None,
            "selected_start_index": selected_start_index,
            "selection_rule": "minimum_expected_objective_then_input_order",
            "canonical_problem_hash": canonical.problem_hash,
            "requested_shots": requested_shots,
            "effective_shots": effective_shots,
        },
    )


def resolve_problem_optimizer_config(
    compiled: ProblemCompileResult,
    optimizer: OptimizerConfig,
) -> OptimizerConfig:
    """Resolve complete finite bounds from explicit config or Parameter schema."""
    if not isinstance(optimizer, OptimizerConfig):
        raise TypeError("optimizer must be OptimizerConfig.")
    declarations = compiled.parameter_schema.parameters
    if optimizer.bounds:
        if len(optimizer.bounds) != len(declarations):
            raise ValueError("optimizer bounds must match Problem parameter count.")
        bounds = optimizer.bounds
    else:
        resolved: list[tuple[float, float]] = []
        for parameter in declarations:
            lower = parameter.lower_bound
            upper = parameter.upper_bound
            if parameter.name.startswith("gamma_"):
                lower = -math.pi if lower is None else lower
                upper = math.pi if upper is None else upper
            elif parameter.name.startswith("beta_"):
                lower = -math.pi / 2.0 if lower is None else lower
                upper = math.pi / 2.0 if upper is None else upper
            elif compiled.algorithm == "vqe":
                # 与 standalone VQE 保持同一默认角度域；显式 Parameter
                # 边界仍优先，用户提供的 optimizer bounds 也会在下方校验。
                lower = -math.pi if lower is None else lower
                upper = math.pi if upper is None else upper
            if lower is None or upper is None:
                raise ValueError(
                    "optimizer bounds are required when the Problem parameter "
                    f"schema does not fully bound '{parameter.name}'."
                )
            resolved.append((float(lower), float(upper)))
        bounds = tuple(resolved)

    for parameter, (lower, upper) in zip(declarations, bounds):
        if parameter.lower_bound is not None and lower < parameter.lower_bound:
            raise ValueError(
                f"optimizer lower bound for '{parameter.name}' is outside the "
                "Problem parameter schema."
            )
        if parameter.upper_bound is not None and upper > parameter.upper_bound:
            raise ValueError(
                f"optimizer upper bound for '{parameter.name}' is outside the "
                "Problem parameter schema."
            )
    return replace(optimizer, bounds=bounds)


def _problem_default_initial_parameters(
    compiled: ProblemCompileResult,
    *,
    parameter_names: tuple[str, ...],
) -> tuple[float, ...] | None:
    """Return a complete schema-default point when one is declared."""
    declarations = compiled.parameter_schema.by_name()
    if not all(declarations[name].default is not None for name in parameter_names):
        return None
    values = {
        name: float(declarations[name].default)  # type: ignore[arg-type]
        for name in parameter_names
    }
    parameter_bind = ParameterBindIR.create(
        parameter_bind_id=f"{compiled.analysis.analysis_id}.optimizer.initial",
        parameter_schema=compiled.parameter_schema,
        values=values,
        metadata={"binding_role": "continuous_optimizer_initial"},
    )
    return tuple(float(parameter_bind.values[name]) for name in parameter_names)


def _problem_optimizer_seed(
    optimizer: OptimizerConfig,
    *,
    backend: LocalBackend | None,
    seed: int | None,
) -> int:
    """Resolve one seed for initialization and every Backend evaluation."""
    if optimizer.seed is not None:
        return optimizer.seed
    if seed is not None:
        return seed
    if backend is not None and backend.seed is not None:
        return backend.seed
    return 0


def decode_problem_result(
    *,
    analysis: ProblemAnalysisResult,
    mode: str,
    algorithm: str,
    topology: str | None,
    compile_hash: str,
    context: ProblemExecutionContextIR,
    parameter_bind: ParameterBindIR,
    result: ResultIR,
    source_program_hash: str | None = None,
    execution_evidence: ObjectiveExecutionEvidenceIR | None = None,
    seed: int | None = None,
    backend_job_id: str | None = None,
    metadata: Mapping[str, Any] | None = None,
) -> ProblemExecutionResult:
    """Decode one ResultIR using shared canonical Problem facts."""
    if not isinstance(analysis, ProblemAnalysisResult):
        raise TypeError("analysis must be ProblemAnalysisResult.")
    if mode not in _MODES or algorithm not in _MODE_ALGORITHMS[mode]:
        raise ValueError("mode and algorithm do not form a supported combination.")
    _require_digest(compile_hash, "compile_hash")
    if not isinstance(context, ProblemExecutionContextIR):
        raise TypeError("context must be ProblemExecutionContextIR.")
    if context.analysis != analysis:
        raise ValueError("context analysis does not match decoder analysis.")
    if context.compile_hash != compile_hash:
        raise ValueError("context compile_hash does not match decoder input.")
    if not isinstance(parameter_bind, ParameterBindIR):
        raise TypeError("parameter_bind must be ParameterBindIR.")
    resolved_source_program_hash = (
        context.native_program_hash
        if source_program_hash is None
        else source_program_hash
    )
    _require_digest(resolved_source_program_hash, "source_program_hash")
    canonical = analysis.canonical_problem
    _validate_result(result, logical_order=canonical.logical_order)
    source_problem = _canonical_source_problem(canonical)
    ranked = _decode_result_candidates(canonical, result)
    best = min(ranked, key=lambda item: (item.objective_value, item.bitstring))
    objective = _expected_objective(source_problem, canonical, result)
    expected_breakdown = expected_problem_energy_breakdown(
        canonical,
        _result_weights(result),
        penalty_analysis=analysis.penalty_analysis,
    )
    if not math.isclose(
        expected_breakdown.total_objective,
        objective,
        rel_tol=_ENERGY_RELATIVE_TOLERANCE,
        abs_tol=_ENERGY_ABSOLUTE_TOLERANCE,
    ):
        raise ValueError(
            "Result objective does not match the canonical energy decomposition."
        )
    candidate_breakdowns = evaluate_problem_energy_breakdowns(
        canonical,
        (candidate.bitstring for candidate in ranked),
        penalty_analysis=analysis.penalty_analysis,
    )
    violations = _constraint_violations(canonical, best.bitstring)
    baseline = _canonical_baseline(canonical)
    metrics = _problem_evaluation_metrics(
        canonical=canonical,
        result=result,
        best_observed_candidate=best,
        baseline=baseline,
        objective_value=objective,
    )
    history = (
        ProblemParameterEvaluationIR(
            evaluation_index=0,
            parameter_bind=parameter_bind,
            result_id=result.result_id,
            result_hash=result.stable_hash(),
            source_program_hash=resolved_source_program_hash,
            program_hash=result.program_hash,
            objective_value=objective,
            shots=result.shots,
            seed=seed,
            best_observed_candidate=metrics.best_observed_candidate,
            feasible_probability=metrics.feasible_probability,
            expected_constraint_violation_count=(
                metrics.expected_constraint_violation_count
            ),
            best_observed_constraint_violation_count=(
                metrics.best_observed_constraint_violation_count
            ),
            expected_selected_weight=metrics.expected_selected_weight,
            baseline_objective=metrics.baseline_objective,
            expected_objective_gap=metrics.expected_objective_gap,
            best_observed_objective_gap=metrics.best_observed_objective_gap,
            energy_breakdown=expected_breakdown,
            execution_evidence=execution_evidence,
            backend_job_id=backend_job_id,
        ),
    )
    identity_hash = hashlib.sha256(
        stable_json(
            {
                "compile_hash": compile_hash,
                "parameter_bind_hash": parameter_bind.parameter_bind_hash,
                "result_hash": result.stable_hash(),
            }
        ).encode("utf-8")
    ).hexdigest()
    return ProblemExecutionResult(
        execution_id=f"problem.execution.{mode}.{identity_hash[:20]}",
        mode=mode,  # type: ignore[arg-type]
        algorithm=algorithm,  # type: ignore[arg-type]
        topology=topology,
        compile_hash=compile_hash,
        analysis_hash=analysis.analysis_hash,
        problem_hash=canonical.problem_hash,
        logical_order=canonical.logical_order,
        context=context,
        parameter_bind=parameter_bind,
        parameter_bind_hash=parameter_bind.parameter_bind_hash,
        result=result,
        candidates=ranked,
        most_probable_candidate=ranked[0],
        best_observed_candidate=best,
        objective_value=objective,
        feasibility=best.feasible,
        constraint_violations=violations,
        candidate_energy_breakdowns=candidate_breakdowns,
        parameter_history=history,
        selected_evaluation_index=0,
        baseline=baseline,
        metadata={
            "decoder_id": canonical.decoder.decoder_id,
            "decoder_kind": canonical.decoder.decoder_kind,
            "objective_direction": canonical.objective_direction,
            "objective_estimator": (
                "result_probabilities"
                if result.probabilities is not None
                else "sample_counts"
            ),
            **({} if metadata is None else dict(metadata)),
        },
    )


def _bound_compile_result(
    compiled: ProblemCompileResult,
    *,
    params: Mapping[str, float] | None,
) -> ProblemCompileResult:
    if params is None:
        if getattr(compiled, "parameter_bind", None) is None:
            raise ValueError("params are required for an unbound compile result.")
        return compiled
    if not isinstance(params, Mapping):
        raise TypeError("params must be a mapping or None.")
    current = getattr(compiled, "parameter_bind", None)
    if compiled.mode == "digital" and current is not None:
        if dict(current.values) == dict(params):
            return compiled
        raise ValueError("A bound Digital compile result cannot use different params.")
    return compiled.bind(params)


def _execution_backend(
    compiled: ProblemCompileResult,
    *,
    backend: LocalBackend | None,
    seed: int | None,
) -> LocalBackend:
    if backend is not None:
        if not isinstance(backend, LocalBackend):
            raise TypeError("backend must be LocalBackend or None.")
        return backend
    target = getattr(compiled, "target", None)
    return LocalBackend(seed=seed, target=target)


def _execution_program(
    compiled: ProblemCompileResult,
) -> Circuit | AHSProgram | HybridProgram:
    if compiled.mode != "digital":
        if not isinstance(compiled.program, (AHSProgram, HybridProgram)):
            raise TypeError("Analog or Hybrid compile result has an invalid program.")
        return compiled.program
    program = compiled.program
    parameter_bind = compiled.parameter_bind
    if not isinstance(program, Circuit):
        raise TypeError("Digital compile result must contain a Circuit.")
    if parameter_bind is None:
        raise ValueError("Digital execution requires a bound compile result.")
    # QAOA circuits remain reusable and measurement-free in the compile result.
    # Execution gets a fresh terminal-measurement wrapper with explicit lineage.
    measured = Circuit(
        program.qubits,
        program_id=(
            f"program.problem.{compiled.compile_hash[:12]}."
            f"{parameter_bind.parameter_bind_hash[:12]}"
        ),
        metadata={
            "execution_role": "problem_sampling",
            "source_program_id": program.program_id,
            "compile_hash": compiled.compile_hash,
            "parameter_bind_hash": parameter_bind.parameter_bind_hash,
        },
    ).compose(program)
    measured.measure_all(key="problem")
    return measured


def _validate_result(result: ResultIR, *, logical_order: tuple[str, ...]) -> None:
    if not isinstance(result, ResultIR):
        raise TypeError("result must be ResultIR.")
    _require_text(result.result_id, "result.result_id")
    _require_digest(result.program_hash, "result.program_hash")
    _non_negative_int(result.shots, "result.shots")
    declared_order = _declared_result_order(result)
    if declared_order != logical_order:
        raise ValueError("Result logical order does not match the compiled Problem.")
    if (
        result.occupation_encoding.ground != 0
        or result.occupation_encoding.rydberg != 1
    ):
        raise ValueError("Result occupation encoding does not match Problem bits.")
    for bitstring, count in result.counts.items():
        _validate_bitstring(bitstring, logical_order)
        if not isinstance(count, int) or isinstance(count, bool) or count <= 0:
            raise ValueError("Result counts must contain positive integers.")
    if sum(result.counts.values()) != result.shots:
        raise ValueError("Result counts must sum to shots.")
    if len(result.samples) != result.shots:
        raise ValueError("Result samples must contain one entry per shot.")
    for bitstring in result.samples:
        _validate_bitstring(bitstring, logical_order)
    if Counter(result.samples) != Counter(result.counts):
        raise ValueError("Result samples must reproduce the declared counts.")
    if result.probabilities is not None:
        probability_mass = 0.0
        for bitstring, probability in result.probabilities.items():
            _validate_bitstring(bitstring, logical_order)
            value = _finite(probability, "result probability")
            if value < 0.0 or value > 1.0 + _PROBABILITY_TOLERANCE:
                raise ValueError("Result probabilities must be within [0, 1].")
            probability_mass += value
        if not math.isclose(
            probability_mass,
            1.0,
            rel_tol=0.0,
            abs_tol=_PROBABILITY_TOLERANCE,
        ):
            raise ValueError("Result probabilities must sum to one.")
    if not result.counts and not result.probabilities:
        raise ValueError("Result must contain counts or probabilities for decoding.")


def _declared_result_order(result: ResultIR) -> tuple[str, ...]:
    metadata = result.metadata.get("bitstring_ordering")
    if isinstance(metadata, Mapping):
        for key in ("logical_order", "qubit_order"):
            value = metadata.get(key)
            if isinstance(value, (list, tuple)) and all(
                isinstance(item, str) for item in value
            ):
                return tuple(value)
    for key in ("logical_order", "qubits"):
        value = result.bit_ordering.get(key)
        if isinstance(value, str) and value:
            return tuple(value.split(","))
        if isinstance(value, (list, tuple)) and all(
            isinstance(item, str) for item in value
        ):
            return tuple(value)
    raise ValueError("Result does not declare a usable logical order.")


def _candidate_bitstrings(result: ResultIR) -> tuple[str, ...]:
    if result.counts:
        return tuple(sorted(result.counts))
    assert result.probabilities is not None
    observed = tuple(
        sorted(
            bitstring
            for bitstring, probability in result.probabilities.items()
            if probability > _PROBABILITY_TOLERANCE
        )
    )
    if not observed:
        raise ValueError("Result probabilities do not contain a non-zero candidate.")
    return observed


def _candidate_probability(result: ResultIR, bitstring: str) -> float:
    if result.probabilities is not None:
        return float(result.probabilities.get(bitstring, 0.0))
    return result.counts[bitstring] / result.shots


def _candidate_rank(candidate: AlgorithmCandidateIR) -> tuple[int, float, str]:
    return (
        0 if candidate.count is None else -candidate.count,
        -float(0.0 if candidate.probability is None else candidate.probability),
        candidate.bitstring,
    )


def _expected_objective(
    source_problem: QUBOProblemIR | IsingModelIR | MISInstance | MWISProblemIR,
    canonical: CanonicalProblemIR,
    result: ResultIR,
) -> float:
    if result.probabilities is not None:
        weights: Iterable[tuple[str, float]] = result.probabilities.items()
    else:
        weights = (
            (bitstring, count / result.shots)
            for bitstring, count in result.counts.items()
        )
    return float(
        sum(
            probability
            * decode_problem_candidate(
                source_problem,
                bitstring,
                mis_penalty=(
                    2.0
                    if canonical.decoder.mis_penalty is None
                    else canonical.decoder.mis_penalty
                ),
                mwis_penalty=canonical.decoder.mwis_penalty,
            ).objective_value
            for bitstring, probability in weights
        )
    )


def _result_weights(result: ResultIR) -> tuple[tuple[str, float], ...]:
    """Return the complete normalized distribution used by objective evidence."""
    if result.probabilities is not None:
        return tuple(
            (bitstring, float(probability))
            for bitstring, probability in result.probabilities.items()
        )
    return tuple(
        (bitstring, count / result.shots)
        for bitstring, count in result.counts.items()
    )


def _constraint_violations(
    canonical: CanonicalProblemIR,
    bitstring: str,
) -> tuple[str, ...]:
    values = dict(zip(canonical.logical_order, (int(bit) for bit in bitstring)))
    return tuple(
        constraint.constraint_id
        for constraint in canonical.constraints
        if (
            sum(
                term.coefficient * values[term.variable]
                for term in constraint.linear_terms
            )
            > constraint.rhs
        )
    )


def _problem_evaluation_metrics(
    *,
    canonical: CanonicalProblemIR,
    result: ResultIR,
    best_observed_candidate: AlgorithmCandidateIR,
    baseline: ClassicalBaselineIR | None,
    objective_value: float,
) -> _ProblemEvaluationMetrics:
    """Derive optimization metrics from the complete result distribution."""
    feasible_probability: float | None = None
    expected_violation_count: float | None = None
    best_violation_count: int | None = None
    expected_selected_weight: float | None = None
    if canonical.decoder.decoder_kind in {"mis", "mwis"}:
        if result.probabilities is not None:
            weights = tuple(result.probabilities.items())
        else:
            weights = tuple(
                (bitstring, count / result.shots)
                for bitstring, count in result.counts.items()
            )
        feasible_mass = 0.0
        violation_mass = 0.0
        for bitstring, probability in weights:
            violation_count = len(_constraint_violations(canonical, bitstring))
            if violation_count == 0:
                feasible_mass += probability
            violation_mass += probability * violation_count
        feasible_probability = min(max(float(feasible_mass), 0.0), 1.0)
        expected_violation_count = float(violation_mass)
        best_violation_count = len(
            _constraint_violations(canonical, best_observed_candidate.bitstring)
        )
        if canonical.decoder.decoder_kind == "mwis":
            node_weights = dict(canonical.decoder.node_weights)
            expected_selected_weight = float(
                sum(
                    probability
                    * sum(
                        node_weights[node] * int(bit)
                        for node, bit in zip(canonical.logical_order, bitstring)
                    )
                    for bitstring, probability in weights
                )
            )

    baseline_objective = (
        None
        if baseline is None or baseline.status != "available"
        else baseline.objective_value
    )
    if baseline_objective is None:
        expected_gap = None
        best_gap = None
    else:
        expected_gap = objective_value - baseline_objective
        best_gap = best_observed_candidate.objective_value - baseline_objective
    return _ProblemEvaluationMetrics(
        best_observed_candidate=best_observed_candidate,
        feasible_probability=feasible_probability,
        expected_constraint_violation_count=expected_violation_count,
        best_observed_constraint_violation_count=best_violation_count,
        expected_selected_weight=expected_selected_weight,
        baseline_objective=baseline_objective,
        expected_objective_gap=expected_gap,
        best_observed_objective_gap=best_gap,
    )


def _canonical_source_problem(
    canonical: CanonicalProblemIR,
) -> QUBOProblemIR | IsingModelIR | MISInstance | MWISProblemIR:
    metadata = {
        "source_problem_id": canonical.problem_id,
        "source_problem_hash": canonical.problem_hash,
        "source_problem_type": canonical.problem_type,
    }
    if canonical.decoder.decoder_kind == "mis":
        positions = dict(canonical.layout_hints)
        return MISInstance(
            node_positions=tuple(
                (
                    name,
                    positions.get(name, (float(index), 0.0)),
                )
                for index, name in enumerate(canonical.logical_order)
            ),
            edges=canonical.decoder.edges,
            metadata=metadata,
        )
    if canonical.decoder.decoder_kind == "mwis":
        return MWISProblemIR(
            problem_id=canonical.problem_id,
            nodes=canonical.logical_order,
            node_weights=canonical.decoder.node_weights,
            edges=canonical.decoder.edges,
            node_positions=canonical.layout_hints,
            metadata=metadata,
        )
    if canonical.decoder.decoder_kind == "qubo":
        return QUBOProblemIR(
            problem_id=canonical.problem_id,
            variables=canonical.logical_order,
            linear_terms=tuple(
                (term.variable, term.coefficient) for term in canonical.linear_terms
            ),
            quadratic_terms=tuple(
                (term.left, term.right, term.coefficient)
                for term in canonical.quadratic_terms
            ),
            offset=canonical.offset,
            metadata=metadata,
        )
    return IsingModelIR(
        problem_id=canonical.problem_id,
        spins=canonical.logical_order,
        fields=tuple(
            (term.variable, term.coefficient) for term in canonical.linear_terms
        ),
        couplings=tuple(
            (term.left, term.right, term.coefficient)
            for term in canonical.quadratic_terms
        ),
        offset=canonical.offset,
        metadata=metadata,
    )


def _canonical_baseline(canonical: CanonicalProblemIR) -> ClassicalBaselineIR:
    return bounded_exhaustive_baseline(
        _canonical_source_problem(canonical),
        mis_penalty=(
            2.0
            if canonical.decoder.mis_penalty is None
            else canonical.decoder.mis_penalty
        ),
        mwis_penalty=canonical.decoder.mwis_penalty,
    )


def _decode_result_candidates(
    canonical: CanonicalProblemIR,
    result: ResultIR,
) -> tuple[AlgorithmCandidateIR, ...]:
    """从原始 Result 分布重建候选，序列化候选不作为事实源。"""
    source_problem = _canonical_source_problem(canonical)
    candidates = tuple(
        decode_problem_candidate(
            source_problem,
            bitstring,
            count=(
                result.counts.get(bitstring) if bitstring in result.counts else None
            ),
            probability=_candidate_probability(result, bitstring),
            mis_penalty=(
                2.0
                if canonical.decoder.mis_penalty is None
                else canonical.decoder.mis_penalty
            ),
            mwis_penalty=canonical.decoder.mwis_penalty,
        )
        for bitstring in _candidate_bitstrings(result)
    )
    return tuple(sorted(candidates, key=_candidate_rank))


def _validate_bitstring(bitstring: object, logical_order: tuple[str, ...]) -> None:
    if (
        not isinstance(bitstring, str)
        or len(bitstring) != len(logical_order)
        or set(bitstring) - {"0", "1"}
    ):
        raise ValueError("Result bitstrings must match the Problem logical order.")


def _result_seed(result: ResultIR, *, fallback: int | None) -> int | None:
    value = result.metadata.get("seed", fallback)
    _optional_seed(value)
    return value


def _require_digest(value: object, name: str) -> None:
    if not isinstance(value, str) or _DIGEST_PATTERN.fullmatch(value) is None:
        raise ValueError(f"{name} must be a lowercase SHA-256 digest.")


def _require_execution_schema(value: object) -> None:
    if value != PROBLEM_EXECUTION_SCHEMA_VERSION:
        raise ValueError(
            "Unsupported Problem execution schema_version: "
            f"{value!r}; expected {PROBLEM_EXECUTION_SCHEMA_VERSION!r}."
        )


def _require_text(value: object, name: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{name} must be a non-empty string.")


def _require_unique_text(
    values: tuple[str, ...],
    name: str,
    *,
    allow_empty: bool = False,
) -> None:
    if not values and not allow_empty:
        raise ValueError(f"{name} must not be empty.")
    if any(not isinstance(value, str) or not value.strip() for value in values):
        raise ValueError(f"{name} must contain non-empty strings.")
    if len(values) != len(set(values)):
        raise ValueError(f"{name} must be unique.")


def _non_negative_int(value: object, name: str) -> None:
    if not isinstance(value, int) or isinstance(value, bool) or value < 0:
        raise ValueError(f"{name} must be a non-negative integer.")


def _optional_seed(value: object) -> None:
    if value is not None and (
        not isinstance(value, int) or isinstance(value, bool) or value < 0
    ):
        raise ValueError("seed must be a non-negative integer or None.")


def _finite(value: object, name: str) -> float:
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        raise TypeError(f"{name} must be a real number.")
    normalized = float(value)
    if not math.isfinite(normalized):
        raise ValueError(f"{name} must be finite.")
    return normalized


def _finite_parameter_mapping(value: object, name: str) -> dict[str, float]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{name} must be an object.")
    normalized: dict[str, float] = {}
    for raw_name, raw_value in value.items():
        parameter_name = str(raw_name)
        _require_text(parameter_name, f"{name} key")
        if parameter_name in normalized:
            raise ValueError(f"{name} contains duplicate parameter names.")
        normalized[parameter_name] = _finite(
            raw_value,
            f"{name}[{parameter_name}]",
        )
    return normalized


def _mapping(value: object, name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{name} must be an object.")
    return value


def _sequence(value: object, name: str) -> Sequence[Any]:
    if not isinstance(value, (list, tuple)):
        raise TypeError(f"{name} must be an array.")
    return value
