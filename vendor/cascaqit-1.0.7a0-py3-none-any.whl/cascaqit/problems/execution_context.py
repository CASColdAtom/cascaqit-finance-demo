"""Serializable compile and native-program context for Problem executions."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any, Literal, Union

from cascaqit.algorithms import AnsatzSpecIR
from cascaqit.compiler.problem_mapping import ProblemTermMappingIR
from cascaqit.digital import DigitalProgramIR
from cascaqit.hybrid import HybridProgramIR
from cascaqit.native_ir.base import IRMixin
from cascaqit.native_ir.models import ProgramIR
from cascaqit.parameters import ParameterSchemaIR
from cascaqit.problems.analysis import ProblemAnalysisResult

__all__ = [
    "PROBLEM_EXECUTION_CONTEXT_SCHEMA_VERSION",
    "ProblemExecutionContextIR",
    "ProblemNativeProgramIR",
]

PROBLEM_EXECUTION_CONTEXT_SCHEMA_VERSION = "cascaqit.problem.execution-context.v2"
ProblemNativeProgramIR = Union[DigitalProgramIR, ProgramIR, HybridProgramIR]

_DIGEST_PATTERN = re.compile(r"[0-9a-f]{64}")
_MODE_ALGORITHMS = {
    "digital": frozenset({"qaoa", "vqe"}),
    "analog": frozenset({"qaa"}),
    "hybrid": frozenset({"qaoa"}),
}


@dataclass(frozen=True)
class ProblemExecutionContextIR(IRMixin):
    """Facts needed to inspect a Problem execution after serialization."""

    context_id: str
    mode: Literal["digital", "analog", "hybrid"]
    algorithm: Literal["qaoa", "vqe", "qaa"]
    topology: str | None
    compile_hash: str
    analysis: ProblemAnalysisResult
    term_mapping: tuple[ProblemTermMappingIR, ...]
    parameter_schema: ParameterSchemaIR
    ansatz: AnsatzSpecIR | None
    ansatz_spec_hash: str | None
    native_program: ProblemNativeProgramIR
    native_program_hash: str
    local_reference: bool = True
    hardware_executable: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = PROBLEM_EXECUTION_CONTEXT_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_text(self.context_id, "context_id")
        if self.mode not in _MODE_ALGORITHMS:
            raise ValueError(f"Unsupported Problem context mode: {self.mode!r}.")
        if self.algorithm not in _MODE_ALGORITHMS[self.mode]:
            raise ValueError("mode and algorithm do not form a supported combination.")
        if self.mode == "hybrid" and self.topology != "dad":
            raise ValueError("Hybrid execution context requires topology='dad'.")
        if self.mode != "hybrid" and self.topology is not None:
            raise ValueError("Only Hybrid execution context may declare a topology.")
        _require_digest(self.compile_hash, "compile_hash")
        if not isinstance(self.analysis, ProblemAnalysisResult):
            raise TypeError("analysis must be ProblemAnalysisResult.")
        object.__setattr__(self, "term_mapping", tuple(self.term_mapping))
        if any(
            not isinstance(item, ProblemTermMappingIR) for item in self.term_mapping
        ):
            raise TypeError("term_mapping must contain ProblemTermMappingIR values.")
        if not isinstance(self.parameter_schema, ParameterSchemaIR):
            raise TypeError("parameter_schema must be ParameterSchemaIR.")
        if self.mode == "digital":
            if not isinstance(self.ansatz, AnsatzSpecIR):
                raise TypeError("Digital execution context requires AnsatzSpecIR.")
            parameter_names = tuple(
                item.name for item in self.parameter_schema.parameters
            )
            if self.ansatz.parameter_names != parameter_names:
                raise ValueError("context ansatz does not match parameter_schema.")
            if (
                self.ansatz.logical_order
                != self.analysis.canonical_problem.logical_order
            ):
                raise ValueError(
                    "context ansatz logical order does not match analysis."
                )
            _require_digest(self.ansatz_spec_hash, "ansatz_spec_hash")
            if self.ansatz_spec_hash != self.ansatz.spec_hash:
                raise ValueError("context ansatz_spec_hash does not match ansatz.")
        elif self.ansatz is not None or self.ansatz_spec_hash is not None:
            raise ValueError("Only Digital execution context may contain ansatz facts.")
        _require_digest(self.native_program_hash, "native_program_hash")
        _validate_native_program(
            self.native_program,
            mode=self.mode,
            expected_hash=self.native_program_hash,
        )
        if self.hardware_executable and self.local_reference:
            raise ValueError(
                "A local reference context cannot claim hardware execution."
            )
        if not isinstance(self.metadata, dict):
            raise TypeError("metadata must be a dictionary.")
        object.__setattr__(self, "metadata", dict(self.metadata))

        logical_terms = {
            item.term_id for item in self.analysis.logical_hamiltonian.terms
        }
        mapped_terms = {
            item.logical_term_id
            for item in self.term_mapping
            if item.logical_term_id in logical_terms
        }
        if mapped_terms != logical_terms:
            raise ValueError(
                "term_mapping must cover every logical Hamiltonian term."
            )

    @property
    def analysis_hash(self) -> str:
        """Return the shared analysis identity retained by this context."""
        return self.analysis.analysis_hash

    @property
    def problem_hash(self) -> str:
        """Return the canonical source Problem identity."""
        return self.analysis.canonical_problem.problem_hash

    @property
    def native_program_id(self) -> str:
        """Return the stable identifier of the captured Native Program."""
        return self.native_program.program_id

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ProblemExecutionContextIR:
        """Restore a complete Problem execution context."""
        mode = str(data["mode"])
        return cls(
            context_id=str(data["context_id"]),
            mode=mode,  # type: ignore[arg-type]
            algorithm=data["algorithm"],
            topology=(None if data.get("topology") is None else str(data["topology"])),
            compile_hash=str(data["compile_hash"]),
            analysis=ProblemAnalysisResult.from_dict(dict(data["analysis"])),
            term_mapping=tuple(
                ProblemTermMappingIR.from_dict(dict(item))
                for item in data.get("term_mapping", ())
            ),
            parameter_schema=ParameterSchemaIR.from_dict(data["parameter_schema"]),
            ansatz=(
                None
                if data.get("ansatz") is None
                else AnsatzSpecIR.from_dict(data["ansatz"])
            ),
            ansatz_spec_hash=(
                None
                if data.get("ansatz_spec_hash") is None
                else str(data["ansatz_spec_hash"])
            ),
            native_program=_native_program_from_dict(
                mode,
                dict(data["native_program"]),
            ),
            native_program_hash=str(data["native_program_hash"]),
            local_reference=bool(data.get("local_reference", True)),
            hardware_executable=bool(data.get("hardware_executable", False)),
            metadata=dict(data.get("metadata", {})),
            schema_version=str(
                data.get(
                    "schema_version",
                    PROBLEM_EXECUTION_CONTEXT_SCHEMA_VERSION,
                )
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> ProblemExecutionContextIR:
        """Restore a complete Problem execution context from JSON."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("ProblemExecutionContextIR JSON must contain an object.")
        return cls.from_dict(data)


def _native_program_from_dict(
    mode: str,
    data: dict[str, Any],
) -> ProblemNativeProgramIR:
    if mode == "digital":
        return DigitalProgramIR.from_dict(data)
    if mode == "analog":
        return ProgramIR.from_dict(data)
    if mode == "hybrid":
        return HybridProgramIR.from_dict(data)
    raise ValueError(f"Unsupported Problem context mode: {mode!r}.")


def _validate_native_program(
    program: ProblemNativeProgramIR,
    *,
    mode: str,
    expected_hash: str,
) -> None:
    expected_type = {
        "digital": DigitalProgramIR,
        "analog": ProgramIR,
        "hybrid": HybridProgramIR,
    }[mode]
    if not isinstance(program, expected_type):
        raise TypeError(f"{mode} context contains the wrong Native Program type.")
    if mode == "hybrid":
        # Hybrid runtime identity belongs to the orchestration builder. The IR
        # carries that hash because its own structural hash is a different fact.
        actual_hash = program.metadata.get("hybrid_program_hash")
    else:
        actual_hash = program.stable_hash()
    if actual_hash != expected_hash:
        raise ValueError("native_program_hash does not match native_program.")


def _require_text(value: object, name: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{name} must be a non-empty string.")


def _require_digest(value: object, name: str) -> None:
    if not isinstance(value, str) or _DIGEST_PATTERN.fullmatch(value) is None:
        raise ValueError(f"{name} must be a SHA-256 digest.")
