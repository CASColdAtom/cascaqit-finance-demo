"""Canonical optimization-problem contracts shared by every compiler mode."""

from __future__ import annotations

import json
import math
import re
from dataclasses import dataclass, field
from typing import Any, Literal

from cascaqit.native_ir.base import IRMixin
from cascaqit.problems.mis import MISInstance
from cascaqit.problems.models import (
    GraphProblemIR,
    IsingModelIR,
    MWISProblemIR,
    QUBOProblemIR,
)
from cascaqit.problems.optimization import (
    DEFAULT_MIS_PENALTY,
    OptimizationProblem,
    mis_to_qubo,
    resolve_mwis_penalty,
)

__all__ = [
    "CANONICAL_PROBLEM_SCHEMA_VERSION",
    "CanonicalConstraintIR",
    "CanonicalConstraintTermIR",
    "CanonicalLinearTermIR",
    "CanonicalProblemIR",
    "CanonicalQuadraticTermIR",
    "ProblemDecoderIR",
    "canonicalize_problem",
]

CANONICAL_PROBLEM_SCHEMA_VERSION = "cascaqit.problem.canonical.v2"
ProblemType = Literal["graph", "mis", "mwis", "qubo", "ising"]
VariableDomain = Literal["binary", "spin"]
DecoderKind = Literal["mis", "mwis", "qubo", "ising"]
ConstraintSourceKind = Literal["independent_set_edge"]
ConstraintRelation = Literal["less_than_or_equal"]
_DIGEST_PATTERN = re.compile(r"[0-9a-f]{64}")


@dataclass(frozen=True)
class CanonicalLinearTermIR(IRMixin):
    """One normalized source linear term before Pauli projection."""

    term_id: str
    variable: str
    coefficient: float
    source_term_ids: tuple[str, ...]
    schema_version: str = CANONICAL_PROBLEM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_canonical_schema(self.schema_version)
        _require_text(self.term_id, "term_id")
        _require_text(self.variable, "variable")
        object.__setattr__(
            self,
            "coefficient",
            _finite(self.coefficient, "coefficient"),
        )
        object.__setattr__(self, "source_term_ids", tuple(self.source_term_ids))
        _require_unique_text(self.source_term_ids, "source_term_ids")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CanonicalLinearTermIR:
        """Restore a canonical linear term from JSON-compatible data."""
        return cls(
            term_id=str(data["term_id"]),
            variable=str(data["variable"]),
            coefficient=data["coefficient"],
            source_term_ids=tuple(str(item) for item in data["source_term_ids"]),
            schema_version=str(
                data.get("schema_version", CANONICAL_PROBLEM_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class CanonicalQuadraticTermIR(IRMixin):
    """One normalized source quadratic term before Pauli projection."""

    term_id: str
    left: str
    right: str
    coefficient: float
    source_term_ids: tuple[str, ...]
    schema_version: str = CANONICAL_PROBLEM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_canonical_schema(self.schema_version)
        _require_text(self.term_id, "term_id")
        _require_text(self.left, "left")
        _require_text(self.right, "right")
        if self.left == self.right:
            raise ValueError("quadratic term targets must be different.")
        if self.left > self.right:
            raise ValueError("quadratic term targets must use canonical order.")
        object.__setattr__(
            self,
            "coefficient",
            _finite(self.coefficient, "coefficient"),
        )
        object.__setattr__(self, "source_term_ids", tuple(self.source_term_ids))
        _require_unique_text(self.source_term_ids, "source_term_ids")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CanonicalQuadraticTermIR:
        """Restore a canonical quadratic term from JSON-compatible data."""
        return cls(
            term_id=str(data["term_id"]),
            left=str(data["left"]),
            right=str(data["right"]),
            coefficient=data["coefficient"],
            source_term_ids=tuple(str(item) for item in data["source_term_ids"]),
            schema_version=str(
                data.get("schema_version", CANONICAL_PROBLEM_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class CanonicalConstraintTermIR(IRMixin):
    """规范约束线性表达式中的一个变量系数。"""

    variable: str
    coefficient: float
    schema_version: str = CANONICAL_PROBLEM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_canonical_schema(self.schema_version)
        _require_text(self.variable, "constraint variable")
        coefficient = _finite(self.coefficient, "constraint coefficient")
        if coefficient == 0.0:
            raise ValueError("constraint coefficients must be non-zero.")
        object.__setattr__(self, "coefficient", coefficient)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CanonicalConstraintTermIR:
        """从 JSON 兼容字典恢复一个约束线性项。"""
        return cls(
            variable=str(data["variable"]),
            coefficient=data["coefficient"],
            schema_version=str(
                data.get("schema_version", CANONICAL_PROBLEM_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class CanonicalConstraintIR(IRMixin):
    """带来源和罚项引用的规范二元线性约束。"""

    constraint_id: str
    source_kind: ConstraintSourceKind
    linear_terms: tuple[CanonicalConstraintTermIR, ...]
    relation: ConstraintRelation
    rhs: float
    penalty_term_ids: tuple[str, ...]
    schema_version: str = CANONICAL_PROBLEM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_canonical_schema(self.schema_version)
        _require_text(self.constraint_id, "constraint_id")
        if self.source_kind != "independent_set_edge":
            raise ValueError(
                f"Unsupported constraint source_kind: {self.source_kind!r}."
            )
        object.__setattr__(self, "linear_terms", tuple(self.linear_terms))
        if any(
            not isinstance(term, CanonicalConstraintTermIR)
            for term in self.linear_terms
        ):
            raise TypeError(
                "linear_terms must contain CanonicalConstraintTermIR values."
            )
        variables = tuple(term.variable for term in self.linear_terms)
        _require_unique_text(variables, "constraint variables")
        if variables != tuple(sorted(variables)):
            raise ValueError("constraint variables must use canonical order.")
        if self.relation != "less_than_or_equal":
            raise ValueError(f"Unsupported constraint relation: {self.relation!r}.")
        object.__setattr__(self, "rhs", _finite(self.rhs, "constraint rhs"))
        object.__setattr__(self, "penalty_term_ids", tuple(self.penalty_term_ids))
        _require_unique_text(self.penalty_term_ids, "penalty_term_ids")
        # 首个 consumer 只开放独立集边，不能把可扩展字段误当作任意约束支持。
        if len(self.linear_terms) != 2 or any(
            term.coefficient != 1.0 for term in self.linear_terms
        ):
            raise ValueError(
                "independent-set constraints require two unit linear terms."
            )
        if self.rhs != 1.0:
            raise ValueError("independent-set constraints require rhs equal to 1.")
        if len(self.penalty_term_ids) != 1:
            raise ValueError(
                "independent-set constraints require exactly one penalty term."
            )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CanonicalConstraintIR:
        """Restore a canonical constraint from JSON-compatible data."""
        return cls(
            constraint_id=str(data["constraint_id"]),
            source_kind=data["source_kind"],
            linear_terms=tuple(
                CanonicalConstraintTermIR.from_dict(item)
                for item in data["linear_terms"]
            ),
            relation=data["relation"],
            rhs=data["rhs"],
            penalty_term_ids=tuple(str(item) for item in data["penalty_term_ids"]),
            schema_version=str(
                data.get("schema_version", CANONICAL_PROBLEM_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class ProblemDecoderIR(IRMixin):
    """Stable decoding semantics shared by compile and execution results."""

    decoder_id: str
    decoder_kind: DecoderKind
    source_problem_id: str
    source_problem_hash: str
    logical_order: tuple[str, ...]
    bitstring_convention: str
    edges: tuple[tuple[str, str], ...] = ()
    mis_penalty: float | None = None
    node_weights: tuple[tuple[str, float], ...] = ()
    mwis_penalty: float | None = None
    schema_version: str = CANONICAL_PROBLEM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_canonical_schema(self.schema_version)
        _require_text(self.decoder_id, "decoder_id")
        if self.decoder_kind not in {"mis", "mwis", "qubo", "ising"}:
            raise ValueError(f"Unsupported decoder_kind: {self.decoder_kind!r}.")
        _require_text(self.source_problem_id, "source_problem_id")
        _require_digest(self.source_problem_hash, "source_problem_hash")
        object.__setattr__(self, "logical_order", tuple(self.logical_order))
        _require_unique_text(self.logical_order, "logical_order")
        _require_text(self.bitstring_convention, "bitstring_convention")
        object.__setattr__(
            self,
            "edges",
            tuple((str(left), str(right)) for left, right in self.edges),
        )
        logical = set(self.logical_order)
        if any(
            left not in logical or right not in logical
            for left, right in self.edges
        ):
            raise ValueError("decoder edges must reference logical_order.")
        normalized_edges = tuple(tuple(sorted(edge)) for edge in self.edges)
        if normalized_edges != self.edges or len(set(self.edges)) != len(self.edges):
            raise ValueError("decoder edges must be unique and canonically ordered.")
        object.__setattr__(self, "node_weights", tuple(self.node_weights))
        weight_nodes = tuple(node for node, _ in self.node_weights)
        if len(set(weight_nodes)) != len(weight_nodes):
            raise ValueError("decoder node_weights must contain unique nodes.")
        normalized_weights = tuple(
            (node, _finite(weight, f"node weight {node}"))
            for node, weight in self.node_weights
        )
        object.__setattr__(self, "node_weights", normalized_weights)
        if self.decoder_kind == "mis":
            if (
                self.mis_penalty is None
                or _finite(self.mis_penalty, "mis_penalty") <= 1
            ):
                raise ValueError("MIS decoder requires mis_penalty greater than 1.")
            if self.node_weights or self.mwis_penalty is not None:
                raise ValueError("MIS decoder cannot contain MWIS fields.")
        elif self.decoder_kind == "mwis":
            if self.mis_penalty is not None:
                raise ValueError("MWIS decoder cannot contain mis_penalty.")
            if set(weight_nodes) != logical or any(
                weight <= 0.0 for _, weight in normalized_weights
            ):
                raise ValueError(
                    "MWIS decoder node_weights must positively cover logical_order."
                )
            if self.mwis_penalty is None:
                raise ValueError("MWIS decoder requires mwis_penalty.")
            strength = _finite(self.mwis_penalty, "mwis_penalty")
            weights = dict(normalized_weights)
            threshold = max(
                (min(weights[left], weights[right]) for left, right in self.edges),
                default=0.0,
            )
            if strength <= threshold:
                raise ValueError(
                    "MWIS decoder mwis_penalty must be strictly greater than "
                    "the weighted vertex-removal threshold."
                )
            object.__setattr__(self, "mwis_penalty", strength)
        elif (
            self.edges
            or self.mis_penalty is not None
            or self.node_weights
            or self.mwis_penalty is not None
        ):
            raise ValueError("Only constrained decoders may contain graph fields.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ProblemDecoderIR:
        """Restore decoder semantics from JSON-compatible data."""
        return cls(
            decoder_id=str(data["decoder_id"]),
            decoder_kind=data["decoder_kind"],
            source_problem_id=str(data["source_problem_id"]),
            source_problem_hash=str(data["source_problem_hash"]),
            logical_order=tuple(str(item) for item in data["logical_order"]),
            bitstring_convention=str(data["bitstring_convention"]),
            edges=tuple(
                (str(item[0]), str(item[1])) for item in data.get("edges", ())
            ),
            mis_penalty=(
                None
                if data.get("mis_penalty") is None
                else data["mis_penalty"]
            ),
            node_weights=tuple(
                (str(item[0]), item[1]) for item in data.get("node_weights", ())
            ),
            mwis_penalty=data.get("mwis_penalty"),
            schema_version=str(
                data.get("schema_version", CANONICAL_PROBLEM_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class CanonicalProblemIR(IRMixin):
    """Normalized source problem consumed by all Problem Lowerers."""

    problem_id: str
    problem_type: ProblemType
    problem_hash: str
    logical_order: tuple[str, ...]
    variable_domain: VariableDomain
    objective_direction: Literal["minimize"]
    offset: float
    linear_terms: tuple[CanonicalLinearTermIR, ...]
    quadratic_terms: tuple[CanonicalQuadraticTermIR, ...]
    decoder: ProblemDecoderIR
    constraints: tuple[CanonicalConstraintIR, ...] = ()
    layout_hints: tuple[tuple[str, tuple[float, float]], ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = CANONICAL_PROBLEM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_canonical_schema(self.schema_version)
        _require_text(self.problem_id, "problem_id")
        if self.problem_type not in {"graph", "mis", "mwis", "qubo", "ising"}:
            raise ValueError(f"Unsupported problem_type: {self.problem_type!r}.")
        _require_digest(self.problem_hash, "problem_hash")
        object.__setattr__(self, "logical_order", tuple(self.logical_order))
        _require_unique_text(self.logical_order, "logical_order")
        if self.variable_domain not in {"binary", "spin"}:
            raise ValueError(f"Unsupported variable_domain: {self.variable_domain!r}.")
        expected_domain = "spin" if self.problem_type == "ising" else "binary"
        if self.variable_domain != expected_domain:
            raise ValueError("variable_domain does not match problem_type.")
        if self.objective_direction != "minimize":
            raise ValueError("Only minimization objectives are canonicalized.")
        object.__setattr__(self, "offset", _finite(self.offset, "offset"))
        object.__setattr__(self, "linear_terms", tuple(self.linear_terms))
        object.__setattr__(self, "quadratic_terms", tuple(self.quadratic_terms))
        object.__setattr__(self, "constraints", tuple(self.constraints))
        object.__setattr__(
            self,
            "layout_hints",
            tuple(
                (
                    node,
                    (
                        _finite(position[0], f"layout x for {node}"),
                        _finite(position[1], f"layout y for {node}"),
                    ),
                )
                for node, position in self.layout_hints
            ),
        )
        term_ids = tuple(term.term_id for term in self.linear_terms) + tuple(
            term.term_id for term in self.quadratic_terms
        )
        _require_unique_text(term_ids, "term ids", allow_empty=True)
        logical = set(self.logical_order)
        if any(term.variable not in logical for term in self.linear_terms):
            raise ValueError("linear terms contain variables outside logical_order.")
        if any(
            term.left not in logical or term.right not in logical
            for term in self.quadratic_terms
        ):
            raise ValueError("quadratic terms contain variables outside logical_order.")
        if any(
            term.variable not in logical
            for item in self.constraints
            for term in item.linear_terms
        ):
            raise ValueError("constraints contain variables outside logical_order.")
        _require_unique_text(
            tuple(item.constraint_id for item in self.constraints),
            "constraint ids",
            allow_empty=True,
        )
        _validate_constraint_penalty_links(self)
        layout_nodes = tuple(node for node, _ in self.layout_hints)
        _require_unique_text(layout_nodes, "layout_hints nodes", allow_empty=True)
        if any(node not in logical for node in layout_nodes):
            raise ValueError("layout_hints contain nodes outside logical_order.")
        if (
            self.decoder.source_problem_id != self.problem_id
            or self.decoder.source_problem_hash != self.problem_hash
            or self.decoder.logical_order != self.logical_order
        ):
            raise ValueError("decoder identity must match the canonical problem.")
        expected_decoder = {
            "graph": "mis",
            "mis": "mis",
            "mwis": "mwis",
            "qubo": "qubo",
            "ising": "ising",
        }[self.problem_type]
        if self.decoder.decoder_kind != expected_decoder:
            raise ValueError("decoder_kind does not match problem_type.")
        if self.problem_type == "mwis":
            _validate_mwis_canonical(self)
        if not isinstance(self.metadata, dict):
            raise TypeError("metadata must be a dictionary.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CanonicalProblemIR:
        """Restore a canonical problem from JSON-compatible data."""
        return cls(
            problem_id=str(data["problem_id"]),
            problem_type=data["problem_type"],
            problem_hash=str(data["problem_hash"]),
            logical_order=tuple(str(item) for item in data["logical_order"]),
            variable_domain=data["variable_domain"],
            objective_direction=data["objective_direction"],
            offset=data["offset"],
            linear_terms=tuple(
                CanonicalLinearTermIR.from_dict(item)
                for item in data.get("linear_terms", ())
            ),
            quadratic_terms=tuple(
                CanonicalQuadraticTermIR.from_dict(item)
                for item in data.get("quadratic_terms", ())
            ),
            decoder=ProblemDecoderIR.from_dict(data["decoder"]),
            constraints=tuple(
                CanonicalConstraintIR.from_dict(item)
                for item in data.get("constraints", ())
            ),
            layout_hints=tuple(
                (
                    str(item[0]),
                    (item[1][0], item[1][1]),
                )
                for item in data.get("layout_hints", ())
            ),
            metadata=dict(data.get("metadata", {})),
            schema_version=str(
                data.get("schema_version", CANONICAL_PROBLEM_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> CanonicalProblemIR:
        """Restore a canonical problem from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("CanonicalProblemIR JSON must contain an object.")
        return cls.from_dict(data)


def canonicalize_problem(
    problem: OptimizationProblem | MWISProblemIR,
    *,
    mis_penalty: float = DEFAULT_MIS_PENALTY,
    mwis_penalty: float | None = None,
) -> CanonicalProblemIR:
    """Normalize one supported optimization problem without choosing a mode."""
    if isinstance(problem, GraphProblemIR):
        _require_valid(problem, "Graph")
        instance = problem.to_mis_instance()
        return _canonical_mis(
            problem_id=problem.problem_id,
            problem_type="graph",
            problem_hash=problem.stable_hash(),
            instance=instance,
            mis_penalty=mis_penalty,
            layout_hints=problem.node_positions,
        )
    if isinstance(problem, MISInstance):
        _require_valid(problem, "MIS")
        problem_hash = str(
            problem.metadata.get("source_problem_hash", problem.stable_hash())
        )
        return _canonical_mis(
            problem_id=str(
                problem.metadata.get("source_problem_id", f"mis.{problem_hash[:16]}")
            ),
            problem_type="mis",
            problem_hash=problem_hash,
            instance=problem,
            mis_penalty=mis_penalty,
            layout_hints=problem.node_positions,
        )
    if isinstance(problem, MWISProblemIR):
        _require_valid(problem, "MWIS")
        return _canonical_mwis(
            problem,
            mwis_penalty=resolve_mwis_penalty(problem, penalty=mwis_penalty),
        )
    if isinstance(problem, QUBOProblemIR):
        _require_valid(problem, "QUBO")
        return _canonical_qubo(
            problem_id=problem.problem_id,
            problem_type="qubo",
            problem_hash=problem.stable_hash(),
            qubo=problem,
        )
    if isinstance(problem, IsingModelIR):
        _require_valid(problem, "Ising")
        problem_hash = problem.stable_hash()
        return CanonicalProblemIR(
            problem_id=problem.problem_id,
            problem_type="ising",
            problem_hash=problem_hash,
            logical_order=problem.spins,
            variable_domain="spin",
            objective_direction="minimize",
            offset=problem.offset,
            linear_terms=tuple(
                CanonicalLinearTermIR(
                    term_id=f"field.{spin}",
                    variable=spin,
                    coefficient=coefficient,
                    source_term_ids=(f"field.{spin}",),
                )
                for spin, coefficient in problem.fields
                if coefficient != 0.0
            ),
            quadratic_terms=tuple(
                CanonicalQuadraticTermIR(
                    term_id=f"coupling.{left}.{right}",
                    left=left,
                    right=right,
                    coefficient=coefficient,
                    source_term_ids=(f"coupling.{left}.{right}",),
                )
                for left, right, coefficient in problem.couplings
                if coefficient != 0.0
            ),
            decoder=ProblemDecoderIR(
                decoder_id=f"decoder.{problem.problem_id}",
                decoder_kind="ising",
                source_problem_id=problem.problem_id,
                source_problem_hash=problem_hash,
                logical_order=problem.spins,
                bitstring_convention="0 maps to spin -1; 1 maps to spin +1",
            ),
            metadata={"source_schema_version": problem.schema_version},
        )
    raise TypeError(
        "supported problem types are GraphProblemIR, MISInstance, "
        "MWISProblemIR, QUBOProblemIR, and IsingModelIR."
    )


def _canonical_mis(
    *,
    problem_id: str,
    problem_type: Literal["graph", "mis"],
    problem_hash: str,
    instance: MISInstance,
    mis_penalty: float,
    layout_hints: tuple[tuple[str, tuple[float, float]], ...],
) -> CanonicalProblemIR:
    qubo = mis_to_qubo(instance, penalty=mis_penalty)
    canonical = _canonical_qubo(
        problem_id=problem_id,
        # 这个对象只用于复用 QUBO 项规范化；约束语义在最终对象中一次性附加。
        problem_type="qubo",
        problem_hash=problem_hash,
        qubo=qubo,
    )
    return CanonicalProblemIR(
        problem_id=canonical.problem_id,
        problem_type=problem_type,
        problem_hash=canonical.problem_hash,
        logical_order=canonical.logical_order,
        variable_domain=canonical.variable_domain,
        objective_direction=canonical.objective_direction,
        offset=canonical.offset,
        linear_terms=canonical.linear_terms,
        quadratic_terms=canonical.quadratic_terms,
        decoder=ProblemDecoderIR(
            decoder_id=f"decoder.{problem_id}",
            decoder_kind="mis",
            source_problem_id=problem_id,
            source_problem_hash=problem_hash,
            logical_order=instance.node_order(),
            bitstring_convention="1 means selected node in logical_order",
            edges=instance.edges,
            mis_penalty=mis_penalty,
        ),
        constraints=tuple(
            CanonicalConstraintIR(
                constraint_id=f"constraint.edge.{left}.{right}",
                source_kind="independent_set_edge",
                linear_terms=(
                    CanonicalConstraintTermIR(variable=left, coefficient=1.0),
                    CanonicalConstraintTermIR(variable=right, coefficient=1.0),
                ),
                relation="less_than_or_equal",
                rhs=1.0,
                penalty_term_ids=(f"quadratic.{left}.{right}",),
            )
            for left, right in instance.edges
        ),
        layout_hints=layout_hints,
        metadata={
            **canonical.metadata,
            "normalized_problem_type": "qubo",
            "mis_penalty": float(mis_penalty),
        },
    )


def _canonical_mwis(
    problem: MWISProblemIR,
    *,
    mwis_penalty: float,
) -> CanonicalProblemIR:
    """直接从带权源事实生成可追溯的规范目标和边约束。"""
    problem_hash = problem.stable_hash()
    linear_terms = tuple(
        CanonicalLinearTermIR(
            term_id=f"objective.node.{node}",
            variable=node,
            coefficient=-weight,
            source_term_ids=(f"objective.node.{node}",),
        )
        for node, weight in problem.node_weights
    )
    quadratic_terms = tuple(
        CanonicalQuadraticTermIR(
            term_id=f"penalty.edge.{left}.{right}",
            left=left,
            right=right,
            coefficient=mwis_penalty,
            source_term_ids=(f"constraint.edge.{left}.{right}",),
        )
        for left, right in problem.edges
    )
    constraints = tuple(
        CanonicalConstraintIR(
            constraint_id=f"constraint.edge.{left}.{right}",
            source_kind="independent_set_edge",
            linear_terms=(
                CanonicalConstraintTermIR(variable=left, coefficient=1.0),
                CanonicalConstraintTermIR(variable=right, coefficient=1.0),
            ),
            relation="less_than_or_equal",
            rhs=1.0,
            penalty_term_ids=(f"penalty.edge.{left}.{right}",),
        )
        for left, right in problem.edges
    )
    return CanonicalProblemIR(
        problem_id=problem.problem_id,
        problem_type="mwis",
        problem_hash=problem_hash,
        logical_order=problem.nodes,
        variable_domain="binary",
        objective_direction="minimize",
        offset=0.0,
        linear_terms=linear_terms,
        quadratic_terms=quadratic_terms,
        decoder=ProblemDecoderIR(
            decoder_id=f"decoder.{problem.problem_id}",
            decoder_kind="mwis",
            source_problem_id=problem.problem_id,
            source_problem_hash=problem_hash,
            logical_order=problem.nodes,
            bitstring_convention="1 means selected node in logical_order",
            edges=problem.edges,
            node_weights=problem.node_weights,
            mwis_penalty=mwis_penalty,
        ),
        constraints=constraints,
        layout_hints=problem.node_positions,
        metadata={
            "source_schema_version": problem.schema_version,
            "normalized_problem_type": "qubo",
            "mwis_penalty": mwis_penalty,
        },
    )


def _canonical_qubo(
    *,
    problem_id: str,
    problem_type: Literal["graph", "mis", "qubo"],
    problem_hash: str,
    qubo: QUBOProblemIR,
) -> CanonicalProblemIR:
    linear_terms = tuple(
        CanonicalLinearTermIR(
            term_id=f"linear.{variable}",
            variable=variable,
            coefficient=coefficient,
            source_term_ids=(f"linear.{variable}",),
        )
        for variable, coefficient in qubo.linear_terms
        if coefficient != 0.0
    )
    quadratic_terms = tuple(
        CanonicalQuadraticTermIR(
            term_id=f"quadratic.{left}.{right}",
            left=left,
            right=right,
            coefficient=coefficient,
            source_term_ids=(f"quadratic.{left}.{right}",),
        )
        for left, right, coefficient in qubo.quadratic_terms
        if coefficient != 0.0
    )
    return CanonicalProblemIR(
        problem_id=problem_id,
        problem_type=problem_type,
        problem_hash=problem_hash,
        logical_order=qubo.variables,
        variable_domain="binary",
        objective_direction="minimize",
        offset=qubo.offset,
        linear_terms=linear_terms,
        quadratic_terms=quadratic_terms,
        layout_hints=qubo.variable_positions,
        decoder=ProblemDecoderIR(
            decoder_id=f"decoder.{problem_id}",
            decoder_kind="qubo",
            source_problem_id=problem_id,
            source_problem_hash=problem_hash,
            logical_order=qubo.variables,
            bitstring_convention="bit value maps to binary variable in logical_order",
        ),
        metadata={
            "source_schema_version": qubo.schema_version,
            "normalized_problem_id": qubo.problem_id,
            "normalized_problem_hash": qubo.stable_hash(),
        },
    )


def _require_valid(
    problem: (
        GraphProblemIR
        | MISInstance
        | MWISProblemIR
        | QUBOProblemIR
        | IsingModelIR
    ),
    label: str,
) -> None:
    diagnostics = problem.validate()
    if diagnostics:
        codes = ", ".join(sorted({item.code for item in diagnostics}))
        raise ValueError(f"{label} problem validation failed: {codes}.")


def _validate_constraint_penalty_links(canonical: CanonicalProblemIR) -> None:
    quadratic = {term.term_id: term for term in canonical.quadratic_terms}
    claimed: list[str] = []
    for constraint in canonical.constraints:
        variables = {term.variable for term in constraint.linear_terms}
        for term_id in constraint.penalty_term_ids:
            try:
                penalty_term = quadratic[term_id]
            except KeyError as exc:
                raise ValueError(
                    f"Constraint penalty term {term_id!r} does not exist."
                ) from exc
            if {penalty_term.left, penalty_term.right} != variables:
                raise ValueError(
                    "Constraint expression variables must match its penalty term."
                )
            claimed.append(term_id)
    if len(claimed) != len(set(claimed)):
        raise ValueError("A penalty term cannot be claimed by multiple constraints.")
    if canonical.problem_type in {"graph", "mis", "mwis"} and set(claimed) != set(
        quadratic
    ):
        raise ValueError(
            "Constrained problems require one-to-one constraint and penalty terms."
        )
    if canonical.problem_type in {"qubo", "ising"} and canonical.constraints:
        raise ValueError("QUBO and Ising cannot contain inferred source constraints.")


def _validate_mwis_canonical(canonical: CanonicalProblemIR) -> None:
    """从 decoder 的源语义重建 MWIS 目标，拒绝 JSON 补写或篡改。"""
    decoder = canonical.decoder
    assert decoder.mwis_penalty is not None
    weights = dict(decoder.node_weights)
    linear = {term.variable: term for term in canonical.linear_terms}
    if set(linear) != set(canonical.logical_order):
        raise ValueError("MWIS business objective must cover every logical variable.")
    for node in canonical.logical_order:
        linear_term = linear[node]
        expected_id = f"objective.node.{node}"
        if (
            linear_term.term_id != expected_id
            or linear_term.source_term_ids != (expected_id,)
            or linear_term.coefficient != -weights[node]
        ):
            raise ValueError("MWIS business objective does not match decoder weights.")

    quadratic = {
        (term.left, term.right): term for term in canonical.quadratic_terms
    }
    if set(quadratic) != set(decoder.edges):
        raise ValueError("MWIS penalty terms do not match decoder edges.")
    constraints = {item.constraint_id: item for item in canonical.constraints}
    if len(constraints) != len(decoder.edges):
        raise ValueError("MWIS constraints do not match decoder edges.")
    for left, right in decoder.edges:
        constraint_id = f"constraint.edge.{left}.{right}"
        penalty_id = f"penalty.edge.{left}.{right}"
        quadratic_term = quadratic[(left, right)]
        constraint = constraints.get(constraint_id)
        if (
            quadratic_term.term_id != penalty_id
            or quadratic_term.source_term_ids != (constraint_id,)
            or quadratic_term.coefficient != decoder.mwis_penalty
            or constraint is None
            or constraint.penalty_term_ids != (penalty_id,)
        ):
            raise ValueError("MWIS edge penalty does not match its source constraint.")


def _require_canonical_schema(value: object) -> None:
    if value != CANONICAL_PROBLEM_SCHEMA_VERSION:
        raise ValueError(f"Unsupported canonical schema: {value!r}.")


def _require_text(value: object, name: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{name} must be a non-empty string.")


def _require_digest(value: object, name: str) -> None:
    if not isinstance(value, str) or _DIGEST_PATTERN.fullmatch(value) is None:
        raise ValueError(f"{name} must be a SHA-256 hash.")


def _require_unique_text(
    values: tuple[str, ...],
    name: str,
    *,
    allow_empty: bool = False,
) -> None:
    if not values and not allow_empty:
        raise ValueError(f"{name} must not be empty.")
    if any(not isinstance(value, str) or not value.strip() for value in values):
        raise ValueError(f"{name} must contain non-empty strings.")
    if len(values) != len(set(values)):
        raise ValueError(f"{name} must be unique.")


def _finite(value: object, name: str) -> float:
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        raise TypeError(f"{name} must be a real number.")
    normalized = float(value)
    if not math.isfinite(normalized):
        raise ValueError(f"{name} must be finite.")
    return normalized
