"""Projection of unified parameter binds into hybrid programs and plans."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field, replace
from typing import Any, Literal

from cascaqit.hybrid import HybridProgram, LocalExecutionPlan
from cascaqit.hybrid.orchestration import HybridProgramBlock
from cascaqit.native_ir.base import IRMixin, stable_json
from cascaqit.parameters.canonical import CANONICAL_PARAMETER_SCHEMA_VERSION
from cascaqit.parameters.diagnostics import ParameterDiagnosticIR
from cascaqit.parameters.ir import ParameterBindIR, ParameterTargetIR
from cascaqit.parameters.manager import ParameterManager
from cascaqit.parameters.mapping import validate_parameter_targets
from cascaqit.syntax import SemanticArgumentHIR

__all__ = ["ParameterPlanProjection", "project_parameter_bindings"]

ProjectionDecision = Literal["reuse", "recompile", "blocked"]


@dataclass(frozen=True)
class ParameterPlanProjection(IRMixin):
    """A projected program and honest non-executable local plan decision."""

    projection_id: str
    schema_hash: str
    bind_set: ParameterBindIR
    decision: ProjectionDecision
    program: HybridProgram | None
    plan: LocalExecutionPlan | None
    diagnostics: tuple[ParameterDiagnosticIR, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = CANONICAL_PARAMETER_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if not self.projection_id.strip():
            raise ValueError("projection_id must be a non-empty string.")
        _require_hash(self.schema_hash, field_name="schema_hash")
        if not isinstance(self.bind_set, ParameterBindIR):
            raise TypeError("bind_set must be ParameterBindIR.")
        if self.program is not None and not isinstance(self.program, HybridProgram):
            raise TypeError("program must be HybridProgram or None.")
        if self.plan is not None and not isinstance(self.plan, LocalExecutionPlan):
            raise TypeError("plan must be LocalExecutionPlan or None.")
        if any(
            not isinstance(item, ParameterDiagnosticIR)
            for item in self.diagnostics
        ):
            raise TypeError("diagnostics must contain ParameterDiagnosticIR values.")
        if self.decision not in {"reuse", "recompile", "blocked"}:
            raise ValueError("invalid projection decision.")
        if self.decision == "blocked":
            if self.plan is not None or not self.has_errors:
                raise ValueError("blocked projection requires errors and no plan.")
        elif self.program is None or self.plan is None or self.has_errors:
            raise ValueError(
                "successful projection requires a program, plan, and no errors."
            )
        if self.plan is not None and self.plan.execution_ready:
            raise ValueError("parameter projection cannot produce an executable plan.")

    @property
    def has_errors(self) -> bool:
        """Return whether parameter projection was blocked."""
        return any(item.severity == "error" for item in self.diagnostics)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ParameterPlanProjection:
        """Build a parameter plan projection from a dictionary."""
        program_data = data.get("program")
        plan_data = data.get("plan")
        return cls(
            projection_id=str(data["projection_id"]),
            schema_hash=str(data["schema_hash"]),
            bind_set=ParameterBindIR.from_dict(data["bind_set"]),
            decision=data["decision"],
            program=(
                None
                if program_data is None
                else HybridProgram.from_dict(program_data)
            ),
            plan=(
                None
                if plan_data is None
                else LocalExecutionPlan.from_dict(plan_data)
            ),
            diagnostics=tuple(
                ParameterDiagnosticIR.from_dict(item)
                for item in data.get("diagnostics", ())
            ),
            metadata=dict(data.get("metadata", {})),
            schema_version=str(
                data.get("schema_version", CANONICAL_PARAMETER_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> ParameterPlanProjection:
        """Build a parameter plan projection from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("ParameterPlanProjection JSON must contain an object.")
        return cls.from_dict(data)


def project_parameter_bindings(
    manager: ParameterManager,
    program: HybridProgram,
    bind_set: ParameterBindIR,
    *,
    previous: ParameterPlanProjection | None = None,
) -> ParameterPlanProjection:
    """Project values without invoking a backend, numerical kernel, or payload."""
    if not isinstance(manager, ParameterManager):
        raise TypeError("manager must be ParameterManager.")
    if not isinstance(program, HybridProgram):
        raise TypeError("program must be HybridProgram.")
    if not isinstance(bind_set, ParameterBindIR):
        raise TypeError("bind_set must be ParameterBindIR.")
    if previous is not None and not isinstance(previous, ParameterPlanProjection):
        raise TypeError("previous must be ParameterPlanProjection or None.")

    schema_hash = manager.schema.stable_hash()
    projection_id = f"projection.{bind_set.parameter_bind_id}"
    base_program_hash = program.stable_hash()
    target_hash = _target_hash(manager.targets)
    diagnostics: list[ParameterDiagnosticIR] = []
    if bind_set.parameter_schema_hash != schema_hash:
        diagnostics.append(
            _diagnostic(
                projection_id,
                "PARAMETER_PROJECTION_SCHEMA_MISMATCH",
                "Bind set schema does not match the parameter manager schema.",
                "Bind values again with the current parameter manager.",
            )
        )
    diagnostics.extend(
        validate_parameter_targets(manager.schema, program, manager.targets)
    )
    for target in manager.targets:
        if target.parameter_name not in bind_set.values:
            diagnostics.append(
                _diagnostic(
                    target.target_id,
                    "PARAMETER_PROJECTION_VALUE_MISSING",
                    f"Bind set has no value for '{target.parameter_name}'.",
                    "Bind every parameter referenced by a target.",
                    target=target,
                )
            )
    if diagnostics:
        return ParameterPlanProjection(
            projection_id=projection_id,
            schema_hash=schema_hash,
            bind_set=bind_set,
            decision="blocked",
            program=None,
            plan=None,
            diagnostics=tuple(diagnostics),
            metadata=_boundary_metadata(base_program_hash, target_hash),
        )

    projected_program = _project_program(program, manager.targets, bind_set)
    can_reuse = _can_reuse(
        previous,
        schema_hash=schema_hash,
        base_program_hash=base_program_hash,
        target_hash=target_hash,
        compile_required=bind_set.compile_required,
    )
    if can_reuse:
        if previous is None or previous.plan is None:
            raise AssertionError("reusable projection requires a previous plan.")
        plan = _reuse_plan(
            previous.plan,
            projected_program,
            schema_hash=schema_hash,
            bind_set=bind_set,
        )
        decision: ProjectionDecision = "reuse"
        reason = "schema_and_base_program_unchanged"
        base_plan_hash: str | None = previous.plan.stable_hash()
        compiler_diagnostic_codes: list[str] = []
    else:
        compiled = projected_program.compile()
        if compiled.plan is None:
            compiler_errors = tuple(
                _compiler_diagnostic(item.code, item.message, item.object_path)
                for item in compiled.diagnostics
                if item.severity == "error"
            )
            return ParameterPlanProjection(
                projection_id=projection_id,
                schema_hash=schema_hash,
                bind_set=bind_set,
                decision="blocked",
                program=projected_program,
                plan=None,
                diagnostics=compiler_errors,
                metadata={
                    **_boundary_metadata(base_program_hash, target_hash),
                    "compiler_diagnostic_codes": [
                        item.code for item in compiled.diagnostics
                    ],
                },
            )
        decision = "recompile"
        reason = _recompile_reason(
            previous,
            schema_hash=schema_hash,
            base_program_hash=base_program_hash,
            target_hash=target_hash,
            compile_required=bind_set.compile_required,
        )
        base_plan_hash = None
        compiler_diagnostic_codes = [item.code for item in compiled.diagnostics]
        plan = replace(
            compiled.plan,
            metadata={
                **compiled.plan.metadata,
                **_plan_metadata(
                    decision=decision,
                    schema_hash=schema_hash,
                    bind_set=bind_set,
                    base_plan_hash=None,
                ),
            },
        )
    return ParameterPlanProjection(
        projection_id=projection_id,
        schema_hash=schema_hash,
        bind_set=bind_set,
        decision=decision,
        program=projected_program,
        plan=plan,
        metadata={
            **_boundary_metadata(base_program_hash, target_hash),
            "decision_reason": reason,
            "base_plan_hash": base_plan_hash,
            "compiler_diagnostic_codes": compiler_diagnostic_codes,
        },
    )


def _project_program(
    program: HybridProgram,
    targets: tuple[ParameterTargetIR, ...],
    bind_set: ParameterBindIR,
) -> HybridProgram:
    targets_by_argument = {
        (target.block_id, target.argument_name): target for target in targets
    }
    blocks: list[HybridProgramBlock] = []
    for block in program.blocks:
        arguments = tuple(
            _project_argument(
                argument,
                targets_by_argument.get((block.block_id, argument.name)),
                bind_set,
            )
            for argument in block.arguments
        )
        blocks.append(replace(block, arguments=arguments))
    return replace(
        program,
        blocks=tuple(blocks),
        metadata={
            **program.metadata,
            "parameter_schema_hash": bind_set.parameter_schema_hash,
            "parameter_bind_hash": bind_set.parameter_bind_hash,
            "parameter_bind_id": bind_set.parameter_bind_id,
        },
    )


def _project_argument(
    argument: SemanticArgumentHIR,
    target: ParameterTargetIR | None,
    bind_set: ParameterBindIR,
) -> SemanticArgumentHIR:
    if target is None:
        return argument
    return replace(
        argument,
        binding_state="bound",
        value=bind_set.values[target.parameter_name],
        value_source="symbol",
        source_symbol=target.parameter_name,
    )


def _can_reuse(
    previous: ParameterPlanProjection | None,
    *,
    schema_hash: str,
    base_program_hash: str,
    target_hash: str,
    compile_required: bool,
) -> bool:
    return bool(
        not compile_required
        and previous is not None
        and not previous.has_errors
        and previous.plan is not None
        and previous.schema_hash == schema_hash
        and previous.metadata.get("base_program_hash") == base_program_hash
        and previous.metadata.get("target_hash") == target_hash
    )


def _reuse_plan(
    previous_plan: LocalExecutionPlan,
    program: HybridProgram,
    *,
    schema_hash: str,
    bind_set: ParameterBindIR,
) -> LocalExecutionPlan:
    blocks = {block.block_id: block for block in program.blocks}
    steps = tuple(
        replace(step, argument_bindings=blocks[step.block_id].arguments)
        for step in previous_plan.steps
    )
    return replace(
        previous_plan,
        program_hash=program.stable_hash(),
        steps=steps,
        metadata={
            **previous_plan.metadata,
            **_plan_metadata(
                decision="reuse",
                schema_hash=schema_hash,
                bind_set=bind_set,
                base_plan_hash=previous_plan.stable_hash(),
            ),
        },
    )


def _plan_metadata(
    *,
    decision: ProjectionDecision,
    schema_hash: str,
    bind_set: ParameterBindIR,
    base_plan_hash: str | None,
) -> dict[str, Any]:
    return {
        "parameter_projection": True,
        "parameter_schema_hash": schema_hash,
        "parameter_bind_hash": bind_set.parameter_bind_hash,
        "parameter_bind_id": bind_set.parameter_bind_id,
        "parameter_plan_decision": decision,
        "base_plan_hash": base_plan_hash,
        "kernel_execution": False,
        "backend_called": False,
    }


def _boundary_metadata(
    base_program_hash: str,
    target_hash: str,
) -> dict[str, Any]:
    return {
        "base_program_hash": base_program_hash,
        "target_hash": target_hash,
        "execution_performed": False,
        "payload_bound": False,
        "backend_called": False,
        "kernel_called": False,
    }


def _recompile_reason(
    previous: ParameterPlanProjection | None,
    *,
    schema_hash: str,
    base_program_hash: str,
    target_hash: str,
    compile_required: bool,
) -> str:
    if compile_required:
        return "bind_compile_impact_requires_recompile"
    if previous is None or previous.plan is None or previous.has_errors:
        return "reusable_base_plan_missing"
    if previous.schema_hash != schema_hash:
        return "parameter_schema_changed"
    if previous.metadata.get("base_program_hash") != base_program_hash:
        return "base_program_changed"
    if previous.metadata.get("target_hash") != target_hash:
        return "parameter_targets_changed"
    return "reusable_base_plan_missing"


def _target_hash(targets: tuple[ParameterTargetIR, ...]) -> str:
    return hashlib.sha256(stable_json(targets).encode("utf-8")).hexdigest()


def _compiler_diagnostic(
    code: str,
    message: str,
    object_path: str | None,
) -> ParameterDiagnosticIR:
    return ParameterDiagnosticIR(
        diagnostic_id=f"parameter.projection.compiler.{code.lower()}",
        severity="error",
        code="PARAMETER_PROJECTION_COMPILE_FAILED",
        message=message,
        object_path=object_path,
        suggestion="Fix the projected HybridProgram before creating a plan.",
        metadata={"compiler_code": code},
    )


def _diagnostic(
    identity: str,
    code: str,
    message: str,
    suggestion: str,
    *,
    target: ParameterTargetIR | None = None,
) -> ParameterDiagnosticIR:
    return ParameterDiagnosticIR(
        diagnostic_id=f"parameter.projection.{identity}.{code.lower()}",
        severity="error",
        code=code,
        message=message,
        object_path=(
            "parameter_projection"
            if target is None
            else f"parameter_targets.{target.target_id}"
        ),
        source_span=None if target is None else target.source_span,
        suggestion=suggestion,
    )


def _require_hash(value: str, *, field_name: str) -> None:
    if len(value) != 64 or any(
        character not in "0123456789abcdef" for character in value
    ):
        raise ValueError(f"{field_name} must be a lowercase SHA-256 hex digest.")
