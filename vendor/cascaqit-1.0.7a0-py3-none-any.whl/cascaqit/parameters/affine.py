"""Restricted affine analysis for canonical parameter expressions."""

from __future__ import annotations

import json
import math
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from types import MappingProxyType
from typing import Union

from cascaqit.native_ir.base import IRMixin
from cascaqit.parameters.canonical import Expression, Parameter

__all__ = ["AffineForm", "affine_form"]

AffineOperand = Union[int, float, Parameter, Expression]


class _AffineFormError(ValueError):
    """Internal error carrying a stable reason for an unsupported expression."""

    def __init__(self, message: str, *, code: str) -> None:
        super().__init__(message)
        self.code = code


@dataclass(frozen=True)
class AffineForm(IRMixin):
    """One immutable ``offset + sum(coefficient * parameter)`` form."""

    offset: float
    coefficients: Mapping[str, float]

    def __post_init__(self) -> None:
        offset = _finite_float(self.offset, "affine offset")
        if not isinstance(self.coefficients, Mapping):
            raise TypeError("affine coefficients must be a mapping.")

        normalized: dict[str, float] = {}
        for raw_name, raw_coefficient in self.coefficients.items():
            name = str(raw_name)
            if not name:
                raise ValueError("affine coefficient names must not be empty.")
            coefficient = _finite_float(
                raw_coefficient,
                f"affine coefficient '{name}'",
            )
            # Exact zero terms carry no derivative and would make equivalent
            # expressions serialize differently, so remove them at the boundary.
            if coefficient != 0.0:
                normalized[name] = coefficient

        object.__setattr__(self, "offset", offset)
        object.__setattr__(
            self,
            "coefficients",
            MappingProxyType(dict(sorted(normalized.items()))),
        )

    def evaluate(self, values: Mapping[str, float]) -> float:
        """Evaluate this form using finite values for every coefficient name."""
        if not isinstance(values, Mapping):
            raise TypeError("affine values must be a mapping.")
        missing = tuple(name for name in self.coefficients if name not in values)
        if missing:
            raise ValueError("affine values are missing: " + ", ".join(missing))
        result = self.offset + sum(
            coefficient * _finite_float(values[name], f"affine value '{name}'")
            for name, coefficient in self.coefficients.items()
        )
        return _finite_float(result, "affine result")

    @classmethod
    def from_dict(cls, data: Mapping[str, object]) -> AffineForm:
        """Restore a form from JSON-compatible data."""
        raw_coefficients = data.get("coefficients", {})
        if not isinstance(raw_coefficients, Mapping):
            raise TypeError("affine coefficients must be an object.")
        return cls(
            offset=_finite_float(data["offset"], "affine offset"),
            coefficients={
                str(name): _finite_float(value, f"affine coefficient '{name}'")
                for name, value in raw_coefficients.items()
            },
        )

    @classmethod
    def from_json(cls, text: str) -> AffineForm:
        """Restore a form from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("AffineForm JSON must contain an object.")
        return cls.from_dict(data)


def affine_form(
    value: AffineOperand,
    *,
    parameter_order: Sequence[str] | None = None,
) -> AffineForm:
    """Reduce a proven affine expression or reject an unsupported operation.

    The accepted language is deliberately smaller than ``Expression``.  This
    function proves the local derivative used by parameter-shift planning; it
    must not silently approximate a nonlinear expression.
    """

    form = _analyze(value)
    if parameter_order is None:
        return form

    order = tuple(str(name) for name in parameter_order)
    if len(order) != len(set(order)):
        raise ValueError("parameter_order contains duplicate names.")
    missing = tuple(name for name in form.coefficients if name not in order)
    if missing:
        raise ValueError("parameter_order is missing: " + ", ".join(missing))
    return _ordered_form(form, order)


def _analyze(value: AffineOperand) -> AffineForm:
    if isinstance(value, bool):
        raise TypeError("affine input must be a numeric scalar and not bool.")
    if isinstance(value, (int, float)):
        return AffineForm(offset=_finite_float(value, "affine input"), coefficients={})
    if isinstance(value, Parameter):
        if value.dtype == "bool":
            raise TypeError("affine input must use numeric parameters.")
        return AffineForm(offset=0.0, coefficients={value.name: 1.0})
    if not isinstance(value, Expression):
        raise TypeError("affine input must be a number, Parameter, or Expression.")

    if value.node_type == "literal":
        assert value.value is not None
        return AffineForm(offset=float(value.value), coefficients={})
    if value.node_type == "parameter":
        assert value.parameter_name is not None
        return AffineForm(offset=0.0, coefficients={value.parameter_name: 1.0})

    left = _analyze(value.operands[0])
    if value.operator == "positive":
        return left
    if value.operator == "negative":
        return _scale(left, -1.0)

    right = _analyze(value.operands[1])
    if value.operator == "add":
        return _combine(left, right, right_scale=1.0)
    if value.operator == "subtract":
        return _combine(left, right, right_scale=-1.0)
    if value.operator == "multiply":
        if left.coefficients and right.coefficients:
            raise _AffineFormError(
                "affine expressions cannot multiply two parameter-dependent values.",
                code="PARAMETER_AFFINE_MULTIPLICATION_UNSUPPORTED",
            )
        return (
            _scale(right, left.offset)
            if not left.coefficients
            else _scale(left, right.offset)
        )
    if value.operator == "divide":
        if right.coefficients:
            raise _AffineFormError(
                "an affine expression divisor must be a finite literal.",
                code="PARAMETER_AFFINE_DIVISOR_UNSUPPORTED",
            )
        if right.offset == 0.0:
            raise ZeroDivisionError("an affine expression divisor must not be zero.")
        return _scale(left, 1.0 / right.offset)
    if value.operator == "power":
        if right.coefficients or right.offset != 1.0:
            raise _AffineFormError(
                "affine expressions support power one only.",
                code="PARAMETER_AFFINE_POWER_UNSUPPORTED",
            )
        return left
    raise _AffineFormError(
        "affine expression operator is unsupported.",
        code="PARAMETER_AFFINE_OPERATOR_UNSUPPORTED",
    )


def _combine(
    left: AffineForm,
    right: AffineForm,
    *,
    right_scale: float,
) -> AffineForm:
    coefficients = dict(left.coefficients)
    for name, coefficient in right.coefficients.items():
        coefficients[name] = coefficients.get(name, 0.0) + right_scale * coefficient
    return AffineForm(
        offset=left.offset + right_scale * right.offset,
        coefficients=coefficients,
    )


def _scale(form: AffineForm, scale: float) -> AffineForm:
    finite_scale = _finite_float(scale, "affine scale")
    return AffineForm(
        offset=form.offset * finite_scale,
        coefficients={
            name: coefficient * finite_scale
            for name, coefficient in form.coefficients.items()
        },
    )


def _ordered_form(form: AffineForm, order: Sequence[str]) -> AffineForm:
    ordered = {
        name: form.coefficients[name] for name in order if name in form.coefficients
    }
    normalized = AffineForm(offset=form.offset, coefficients=ordered)
    # AffineForm normalizes arbitrary direct construction lexically.  Reapply
    # the caller's declaration order for Circuit-level chain-rule planning.
    object.__setattr__(normalized, "coefficients", MappingProxyType(ordered))
    return normalized


def _finite_float(value: object, field_name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{field_name} must be numeric and not bool.")
    normalized = float(value)
    if not math.isfinite(normalized):
        raise ValueError(f"{field_name} must be finite.")
    return normalized
