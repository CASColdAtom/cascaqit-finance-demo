"""Immutable manager for canonical parameter declarations and bindings."""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field, replace
from typing import Any

from cascaqit.native_ir.base import IRMixin
from cascaqit.parameters.canonical import (
    CANONICAL_PARAMETER_SCHEMA_VERSION,
    Parameter,
    ParameterScalar,
)
from cascaqit.parameters.diagnostics import ParameterDiagnosticIR
from cascaqit.parameters.ir import (
    ParameterBindIR,
    ParameterSchemaIR,
    ParameterTargetIR,
)

__all__ = ["ParameterBindingResult", "ParameterManager"]


@dataclass(frozen=True)
class ParameterBindingResult(IRMixin):
    """A canonical bind or diagnostics that prevented its creation."""

    bind_set: ParameterBindIR | None
    diagnostics: tuple[ParameterDiagnosticIR, ...] = ()
    schema_version: str = CANONICAL_PARAMETER_SCHEMA_VERSION

    @property
    def has_errors(self) -> bool:
        return any(item.severity == "error" for item in self.diagnostics)

    def __post_init__(self) -> None:
        if self.has_errors and self.bind_set is not None:
            raise ValueError("binding with errors must not expose a bind set.")
        if not self.has_errors and self.bind_set is None:
            raise ValueError("binding without errors must expose a bind set.")

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ParameterBindingResult:
        bind_data = data.get("bind_set")
        return cls(
            bind_set=(
                None
                if bind_data is None
                else ParameterBindIR.from_dict(_mapping(bind_data, "bind_set"))
            ),
            diagnostics=tuple(
                ParameterDiagnosticIR.from_dict(item)
                for item in data.get("diagnostics", ())
            ),
            schema_version=str(
                data.get("schema_version", CANONICAL_PARAMETER_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class ParameterManager(IRMixin):
    """An immutable owner of one canonical schema, assignments, and targets."""

    schema: ParameterSchemaIR = field(default_factory=ParameterSchemaIR)
    assignments: dict[str, ParameterScalar] = field(default_factory=dict)
    assignment_units: dict[str, str | None] = field(default_factory=dict)
    targets: tuple[ParameterTargetIR, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = CANONICAL_PARAMETER_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if not isinstance(self.schema, ParameterSchemaIR):
            raise TypeError("schema must be ParameterSchemaIR.")
        if set(self.assignment_units) - set(self.assignments):
            raise ValueError("assignment_units cannot reference unassigned parameters.")
        for name, value in self.assignments.items():
            if not name.strip():
                raise ValueError("assignment names must be non-empty strings.")
            if not isinstance(value, (bool, int, float)):
                raise TypeError("assignment values must be bool, int, or float.")
        if any(not isinstance(target, ParameterTargetIR) for target in self.targets):
            raise TypeError("targets must contain ParameterTargetIR values.")
        ids = tuple(target.target_id for target in self.targets)
        if len(ids) != len(set(ids)):
            raise ValueError("parameter target ids must be unique.")

    def declare(self, parameter: Parameter) -> ParameterManager:
        """Return a manager with one additional canonical parameter."""
        if not isinstance(parameter, Parameter):
            raise TypeError("parameter must be Parameter.")
        if parameter.name in self.schema.by_name():
            raise ValueError(f"parameter '{parameter.name}' is already declared.")
        return replace(
            self,
            schema=replace(
                self.schema,
                parameters=(*self.schema.parameters, parameter.to_ir()),
            ),
        )

    def assign(
        self,
        name: str,
        value: ParameterScalar,
        *,
        unit: str | None = None,
    ) -> ParameterManager:
        if not isinstance(name, str) or not name.strip():
            raise ValueError("name must be a non-empty string.")
        if not isinstance(value, (bool, int, float)):
            raise TypeError("value must be bool, int, or float.")
        if unit is not None and not unit.strip():
            raise ValueError("unit must be None or a non-empty string.")
        return replace(
            self,
            assignments={**self.assignments, name: value},
            assignment_units={**self.assignment_units, name: unit},
        )

    def map_target(self, target: ParameterTargetIR) -> ParameterManager:
        if not isinstance(target, ParameterTargetIR):
            raise TypeError("target must be ParameterTargetIR.")
        if target.target_id in {item.target_id for item in self.targets}:
            raise ValueError(f"parameter target '{target.target_id}' already exists.")
        return replace(self, targets=(*self.targets, target))

    def bind(
        self,
        values: Mapping[str, ParameterScalar] | None = None,
        *,
        units: Mapping[str, str | None] | None = None,
        bind_id: str = "bind.default",
    ) -> ParameterBindingResult:
        provided = {**self.assignments, **({} if values is None else values)}
        provided_units = {
            **self.assignment_units,
            **({} if units is None else units),
        }
        diagnostics = _validate_inputs(self.schema, provided, provided_units)
        if diagnostics:
            return ParameterBindingResult(None, tuple(diagnostics))
        try:
            bind = ParameterBindIR.create(
                parameter_bind_id=bind_id,
                parameter_schema=self.schema,
                values=provided,
            )
        except (ArithmeticError, TypeError, ValueError) as exc:
            code = _expression_failure_code(self.schema, str(exc))
            return ParameterBindingResult(
                None,
                (
                    _diagnostic(
                        "expression",
                        code,
                        f"Parameter expression resolution failed: {exc}",
                        "Fix expression dependencies, values, or bounds.",
                    ),
                ),
            )
        return ParameterBindingResult(bind)

    def bind_many(
        self,
        value_sets: Sequence[Mapping[str, ParameterScalar]],
        *,
        units: Mapping[str, str | None] | None = None,
        bind_id_prefix: str = "bind",
    ) -> tuple[ParameterBindingResult, ...]:
        if not bind_id_prefix.strip():
            raise ValueError("bind_id_prefix must be a non-empty string.")
        return tuple(
            self.bind(values, units=units, bind_id=f"{bind_id_prefix}.{index}")
            for index, values in enumerate(value_sets)
        )

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ParameterManager:
        return cls(
            schema=ParameterSchemaIR.from_dict(
                _mapping(data.get("schema", {}), "schema")
            ),
            assignments={
                str(key): value
                for key, value in _mapping(
                    data.get("assignments", {}), "assignments"
                ).items()
            },
            assignment_units={
                str(key): (None if value is None else str(value))
                for key, value in _mapping(
                    data.get("assignment_units", {}), "assignment_units"
                ).items()
            },
            targets=tuple(
                ParameterTargetIR.from_dict(item)
                for item in data.get("targets", ())
            ),
            metadata=dict(_mapping(data.get("metadata", {}), "metadata")),
            schema_version=str(
                data.get("schema_version", CANONICAL_PARAMETER_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> ParameterManager:
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("ParameterManager JSON must contain an object.")
        return cls.from_dict(data)


def _validate_inputs(
    schema: ParameterSchemaIR,
    values: Mapping[str, ParameterScalar],
    units: Mapping[str, str | None],
) -> list[ParameterDiagnosticIR]:
    diagnostics: list[ParameterDiagnosticIR] = []
    declarations = schema.by_name()
    for name in sorted(set(values) - set(declarations)):
        diagnostics.append(
            _diagnostic(
                name,
                "PARAMETER_UNKNOWN",
                f"Parameter '{name}' is not declared.",
                "Remove the value or declare the parameter.",
            )
        )
    for name in sorted(set(units) - set(values)):
        diagnostics.append(
            _diagnostic(
                name,
                "PARAMETER_UNIT_WITHOUT_VALUE",
                f"Unit for parameter '{name}' has no value.",
                "Provide a value together with the unit.",
            )
        )
    for item in schema.parameters:
        parameter = Parameter.from_ir(item)
        name = parameter.name
        if parameter.expression is not None:
            continue
        if name not in values:
            if parameter.required:
                diagnostics.append(
                    _diagnostic(
                        name,
                        "PARAMETER_MISSING",
                        f"Required parameter '{name}' is missing.",
                        "Assign or bind the required parameter.",
                        parameter=parameter,
                    )
                )
            continue
        try:
            within_bounds = parameter.contains(values[name])
        except (TypeError, ValueError):
            diagnostics.append(
                _diagnostic(
                    name,
                    "PARAMETER_TYPE_MISMATCH",
                    f"Value for parameter '{name}' does not match {parameter.dtype}.",
                    "Bind a value with the declared dtype.",
                    parameter=parameter,
                )
            )
            continue
        if not within_bounds:
            diagnostics.append(
                _diagnostic(
                    name,
                    "PARAMETER_OUT_OF_RANGE",
                    f"Value for parameter '{name}' is outside its range.",
                    "Bind a value within the declared range.",
                    parameter=parameter,
                )
            )
        actual_unit = units.get(name)
        if actual_unit is not None and actual_unit != parameter.unit:
            diagnostics.append(
                _diagnostic(
                    name,
                    "PARAMETER_UNIT_MISMATCH",
                    f"Unit for parameter '{name}' does not match {parameter.unit!r}.",
                    "Use the declared unit; implicit conversion is not supported.",
                    parameter=parameter,
                    metadata={"actual_unit": actual_unit},
                )
            )
    return diagnostics


def _expression_failure_code(schema: ParameterSchemaIR, message: str) -> str:
    declared = set(schema.by_name())
    referenced = {
        name
        for item in schema.parameters
        if item.expression is not None
        for name in item.expression.dependencies
    }
    if referenced - declared:
        return "PARAMETER_EXPRESSION_UNKNOWN_SYMBOL"
    if "cyclic" in message:
        return "PARAMETER_EXPRESSION_CYCLE"
    return "PARAMETER_EXPRESSION_EVALUATION_FAILED"


def _diagnostic(
    name: str,
    code: str,
    message: str,
    suggestion: str,
    *,
    parameter: Parameter | None = None,
    metadata: dict[str, Any] | None = None,
) -> ParameterDiagnosticIR:
    return ParameterDiagnosticIR(
        diagnostic_id=f"parameter.{name}.{code.lower()}",
        severity="error",
        code=code,
        message=message,
        object_path=f"parameters.{name}",
        source_span=None if parameter is None else parameter.source_span,
        suggestion=suggestion,
        metadata={} if metadata is None else metadata,
    )


def _mapping(value: object, field_name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{field_name} must be an object.")
    return value
