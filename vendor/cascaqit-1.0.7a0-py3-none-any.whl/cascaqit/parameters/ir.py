"""Canonical parameter schema, binding, and target IR contracts."""

from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field, replace
from types import MappingProxyType
from typing import Any

from cascaqit.native_ir.base import IRMixin, stable_json
from cascaqit.parameters.canonical import (
    CANONICAL_PARAMETER_SCHEMA_VERSION,
    CompileImpact,
    Expression,
    Parameter,
    ParameterDType,
    ParameterScalar,
)
from cascaqit.syntax import SourceSpan

__all__ = [
    "ParameterBindIR",
    "ParameterIR",
    "ParameterSchemaIR",
    "ParameterTargetIR",
]


@dataclass(frozen=True)
class ParameterIR(IRMixin):
    """Canonical wire representation of one parameter."""

    name: str
    dtype: ParameterDType = "float"
    unit: str | None = None
    default: ParameterScalar | None = None
    lower_bound: int | float | None = None
    upper_bound: int | float | None = None
    expression: Expression | None = None
    compile_impact: CompileImpact = "bind_only"
    source_span: SourceSpan | None = None
    metadata: Mapping[str, Any] = field(default_factory=dict)
    schema_version: str = CANONICAL_PARAMETER_SCHEMA_VERSION

    def __post_init__(self) -> None:
        canonical = Parameter(
            name=self.name,
            dtype=self.dtype,
            unit=self.unit,
            default=self.default,
            lower_bound=self.lower_bound,
            upper_bound=self.upper_bound,
            expression=self.expression,
            compile_impact=self.compile_impact,
            source_span=self.source_span,
            metadata=self.metadata,
            schema_version=self.schema_version,
        )
        object.__setattr__(self, "metadata", canonical.metadata)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ParameterIR:
        """Build a parameter IR from JSON-compatible data."""
        parameter = Parameter.from_dict(data)
        return parameter.to_ir()

    @classmethod
    def from_json(cls, text: str) -> ParameterIR:
        """Build a parameter IR from JSON text."""
        return cls.from_dict(_json_object(text, "ParameterIR"))


@dataclass(frozen=True)
class ParameterSchemaIR(IRMixin):
    """A deterministic collection of unique canonical parameters."""

    parameters: tuple[ParameterIR, ...] = ()
    metadata: Mapping[str, Any] = field(default_factory=dict)
    schema_version: str = CANONICAL_PARAMETER_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if any(not isinstance(item, ParameterIR) for item in self.parameters):
            raise TypeError("parameters must contain ParameterIR values.")
        names = tuple(item.name for item in self.parameters)
        if len(names) != len(set(names)):
            raise ValueError("parameter schema contains duplicate names.")
        object.__setattr__(self, "metadata", _freeze_mapping(self.metadata))

    def by_name(self) -> dict[str, ParameterIR]:
        """Return parameter declarations keyed by name."""
        return {item.name: item for item in self.parameters}

    @classmethod
    def from_parameters(
        cls,
        parameters: Sequence[Parameter],
        *,
        metadata: Mapping[str, Any] | None = None,
    ) -> ParameterSchemaIR:
        """Project canonical value objects into a schema."""
        return cls(
            parameters=tuple(parameter.to_ir() for parameter in parameters),
            metadata={} if metadata is None else metadata,
        )

    @classmethod
    def merge(cls, parameters: Sequence[ParameterIR]) -> ParameterSchemaIR:
        """Merge identical declarations and reject same-name conflicts."""
        merged: dict[str, ParameterIR] = {}
        for parameter in parameters:
            if not isinstance(parameter, ParameterIR):
                raise TypeError("parameters must contain ParameterIR values.")
            existing = merged.get(parameter.name)
            if existing is not None and existing != parameter:
                raise ValueError(
                    f"parameter '{parameter.name}' has conflicting declarations."
                )
            merged[parameter.name] = parameter
        return cls(parameters=tuple(merged[name] for name in sorted(merged)))

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ParameterSchemaIR:
        """Build a schema from JSON-compatible data."""
        raw_parameters = data.get("parameters", ())
        if not isinstance(raw_parameters, (list, tuple)):
            raise TypeError("schema parameters must be an array.")
        return cls(
            parameters=tuple(
                ParameterIR.from_dict(_require_mapping(item, "parameter"))
                for item in raw_parameters
            ),
            metadata=dict(_require_mapping(data.get("metadata", {}), "metadata")),
            schema_version=str(
                data.get("schema_version", CANONICAL_PARAMETER_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> ParameterSchemaIR:
        """Build a schema from JSON text."""
        return cls.from_dict(_json_object(text, "ParameterSchemaIR"))


@dataclass(frozen=True)
class ParameterBindIR(IRMixin):
    """One validated set of concrete canonical parameter values."""

    parameter_bind_id: str
    parameter_schema_hash: str
    values: Mapping[str, ParameterScalar]
    parameter_bind_hash: str = ""
    compile_required: bool = False
    metadata: Mapping[str, Any] = field(default_factory=dict)
    schema_version: str = CANONICAL_PARAMETER_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_non_empty(self.parameter_bind_id, "parameter_bind_id")
        _require_digest(self.parameter_schema_hash, "parameter_schema_hash")
        object.__setattr__(self, "values", _freeze_mapping(self.values))
        object.__setattr__(self, "metadata", _freeze_mapping(self.metadata))
        if not self.parameter_bind_hash:
            object.__setattr__(
                self, "parameter_bind_hash", self.compute_bind_hash()
            )
        _require_digest(self.parameter_bind_hash, "parameter_bind_hash")

    @classmethod
    def create(
        cls,
        *,
        parameter_bind_id: str,
        parameter_schema: ParameterSchemaIR,
        values: Mapping[str, ParameterScalar],
        metadata: Mapping[str, Any] | None = None,
    ) -> ParameterBindIR:
        """Resolve defaults/expressions, validate, and compute semantic hashes."""
        if not isinstance(parameter_schema, ParameterSchemaIR):
            raise TypeError("parameter_schema must be ParameterSchemaIR.")
        declarations = parameter_schema.by_name()
        unknown = sorted(set(values) - set(declarations))
        if unknown:
            raise ValueError("unknown parameter values: " + ", ".join(unknown))
        derived = sorted(
            name
            for name in values
            if declarations[name].expression is not None
        )
        if derived:
            raise ValueError(
                "derived parameters cannot be bound directly: " + ", ".join(derived)
            )
        resolved = _resolve_values(parameter_schema, values)
        schema_hash = parameter_schema.stable_hash()
        compile_required = any(
            item.compile_impact == "recompile" and item.name in resolved
            for item in parameter_schema.parameters
        )
        bind = cls(
            parameter_bind_id=parameter_bind_id,
            parameter_schema_hash=schema_hash,
            values=resolved,
            parameter_bind_hash="0" * 64,
            compile_required=compile_required,
            metadata={} if metadata is None else metadata,
        )
        return replace(bind, parameter_bind_hash=bind.compute_bind_hash())

    def compute_bind_hash(self) -> str:
        """Return a stable semantic hash independent of bind_id and metadata."""
        return hashlib.sha256(
            stable_json(
                {
                    "schema_version": self.schema_version,
                    "parameter_schema_hash": self.parameter_schema_hash,
                    "values": self.values,
                }
            ).encode("utf-8")
        ).hexdigest()

    def verify_hash(self) -> bool:
        """Return whether the embedded semantic hash is current."""
        return self.parameter_bind_hash == self.compute_bind_hash()

    def validate_against(self, schema: ParameterSchemaIR) -> tuple[str, ...]:
        """Return stable validation issue codes for imported bind data."""
        issues: list[str] = []
        if self.parameter_schema_hash != schema.stable_hash():
            issues.append("PARAMETER_SCHEMA_HASH_MISMATCH")
        if not self.verify_hash():
            issues.append("PARAMETER_BIND_HASH_MISMATCH")
        try:
            expected = self.create(
                parameter_bind_id=self.parameter_bind_id,
                parameter_schema=schema,
                values={
                    name: value
                    for name, value in self.values.items()
                    if schema.by_name().get(name) is not None
                    and schema.by_name()[name].expression is None
                    and schema.by_name()[name].default != value
                },
                metadata=self.metadata,
            )
            if dict(expected.values) != dict(self.values):
                issues.append("PARAMETER_BIND_VALUES_INVALID")
        except (TypeError, ValueError):
            issues.append("PARAMETER_BIND_VALUES_INVALID")
        return tuple(issues)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ParameterBindIR:
        """Build a bind IR from JSON-compatible data without recomputing hashes."""
        values = _require_mapping(data.get("values", {}), "values")
        return cls(
            parameter_bind_id=str(data["parameter_bind_id"]),
            parameter_schema_hash=str(data["parameter_schema_hash"]),
            values={str(name): value for name, value in values.items()},
            parameter_bind_hash=str(data.get("parameter_bind_hash", "")),
            compile_required=bool(data.get("compile_required", False)),
            metadata=dict(_require_mapping(data.get("metadata", {}), "metadata")),
            schema_version=str(
                data.get("schema_version", CANONICAL_PARAMETER_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> ParameterBindIR:
        """Build a bind IR from JSON text."""
        return cls.from_dict(_json_object(text, "ParameterBindIR"))


@dataclass(frozen=True)
class ParameterTargetIR(IRMixin):
    """An explicit parameter-to-block argument mapping."""

    target_id: str
    parameter_name: str
    block_id: str
    argument_name: str
    dtype: ParameterDType = "float"
    unit: str | None = None
    source_span: SourceSpan | None = None
    metadata: Mapping[str, Any] = field(default_factory=dict)
    schema_version: str = CANONICAL_PARAMETER_SCHEMA_VERSION

    def __post_init__(self) -> None:
        for field_name in ("target_id", "parameter_name", "block_id", "argument_name"):
            _require_non_empty(getattr(self, field_name), field_name)
        if self.dtype not in {"float", "int", "bool"}:
            raise ValueError("dtype must be float, int, or bool.")
        if self.unit is not None and not self.unit.strip():
            raise ValueError("unit must be None or a non-empty string.")
        if self.source_span is not None and not isinstance(
            self.source_span, SourceSpan
        ):
            raise TypeError("source_span must be SourceSpan or None.")
        object.__setattr__(self, "metadata", _freeze_mapping(self.metadata))

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ParameterTargetIR:
        """Build a target IR from JSON-compatible data."""
        span = data.get("source_span")
        return cls(
            target_id=str(data["target_id"]),
            parameter_name=str(data["parameter_name"]),
            block_id=str(data["block_id"]),
            argument_name=str(data["argument_name"]),
            dtype=data.get("dtype", "float"),
            unit=None if data.get("unit") is None else str(data["unit"]),
            source_span=(
                None
                if span is None
                else SourceSpan.from_dict(dict(_require_mapping(span, "source_span")))
            ),
            metadata=dict(_require_mapping(data.get("metadata", {}), "metadata")),
            schema_version=str(
                data.get("schema_version", CANONICAL_PARAMETER_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> ParameterTargetIR:
        """Build a target IR from JSON text."""
        return cls.from_dict(_json_object(text, "ParameterTargetIR"))


def _resolve_values(
    schema: ParameterSchemaIR,
    provided: Mapping[str, ParameterScalar],
) -> dict[str, ParameterScalar]:
    resolved: dict[str, ParameterScalar] = {}
    pending: dict[str, Parameter] = {}
    for item in schema.parameters:
        parameter = Parameter.from_ir(item)
        if parameter.expression is not None:
            pending[parameter.name] = parameter
            continue
        if parameter.name in provided:
            resolved[parameter.name] = parameter.evaluate(provided)
        elif parameter.default is not None:
            resolved[parameter.name] = parameter.evaluate({})
        else:
            raise ValueError(f"required parameter '{parameter.name}' is missing.")
    while pending:
        ready = sorted(
            name
            for name, parameter in pending.items()
            if set(parameter.dependencies) <= set(resolved)
        )
        if not ready:
            raise ValueError(
                "parameter expressions contain unresolved or cyclic dependencies: "
                + ", ".join(sorted(pending))
            )
        for name in ready:
            resolved[name] = pending.pop(name).evaluate(resolved)
    return {name: resolved[name] for name in sorted(resolved)}


def _freeze_mapping(value: Mapping[str, Any]) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError("value must be a mapping.")
    return MappingProxyType({str(name): item for name, item in sorted(value.items())})


def _require_non_empty(value: object, field_name: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field_name} must be a non-empty string.")


def _require_digest(value: str, field_name: str) -> None:
    if len(value) != 64 or any(
        character not in "0123456789abcdef" for character in value
    ):
        raise ValueError(f"{field_name} must be a lowercase SHA-256 hex digest.")


def _require_mapping(value: object, field_name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{field_name} must be an object.")
    return value


def _json_object(text: str, type_name: str) -> Mapping[str, Any]:
    data = json.loads(text)
    if not isinstance(data, dict):
        raise TypeError(f"{type_name} JSON must contain an object.")
    return data
