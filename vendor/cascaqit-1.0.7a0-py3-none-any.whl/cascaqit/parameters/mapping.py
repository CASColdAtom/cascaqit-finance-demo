"""Validation for shared parameter mappings to HybridProgram arguments."""

from __future__ import annotations

from cascaqit.hybrid import HybridProgram, LocalExecutionPlan
from cascaqit.parameters.diagnostics import ParameterDiagnosticIR
from cascaqit.parameters.ir import ParameterSchemaIR, ParameterTargetIR

__all__ = ["validate_parameter_targets"]


def validate_parameter_targets(
    schema: ParameterSchemaIR,
    program: HybridProgram | LocalExecutionPlan,
    targets: tuple[ParameterTargetIR, ...],
) -> tuple[ParameterDiagnosticIR, ...]:
    """Validate explicit targets against a user program or compiled plan."""
    if not isinstance(schema, ParameterSchemaIR):
        raise TypeError("schema must be ParameterSchemaIR.")
    if isinstance(program, HybridProgram):
        blocks = {
            block.block_id: (block.block_kind, block.arguments)
            for block in program.blocks
        }
    elif isinstance(program, LocalExecutionPlan):
        blocks = {
            step.block_id: (step.kernel_kind, step.argument_bindings)
            for step in program.steps
        }
    else:
        raise TypeError("program must be HybridProgram or LocalExecutionPlan.")
    definitions = schema.by_name()
    diagnostics: list[ParameterDiagnosticIR] = []
    target_ids: set[str] = set()
    argument_targets: set[tuple[str, str]] = set()
    for target in targets:
        if not isinstance(target, ParameterTargetIR):
            raise TypeError("targets must contain ParameterTargetIR values.")
        if target.target_id in target_ids:
            diagnostics.append(
                _diagnostic(
                    target,
                    "PARAMETER_TARGET_DUPLICATE_ID",
                    "Duplicate target id.",
                )
            )
        target_ids.add(target.target_id)
        argument_key = (target.block_id, target.argument_name)
        if argument_key in argument_targets:
            diagnostics.append(
                _diagnostic(
                    target,
                    "PARAMETER_TARGET_DUPLICATE_ARGUMENT",
                    "A block argument cannot have multiple parameter targets.",
                )
            )
        argument_targets.add(argument_key)
        definition = definitions.get(target.parameter_name)
        if definition is None:
            diagnostics.append(
                _diagnostic(
                    target,
                    "PARAMETER_TARGET_UNKNOWN_PARAMETER",
                    f"Parameter '{target.parameter_name}' is not declared.",
                )
            )
            continue
        block_contract = blocks.get(target.block_id)
        if block_contract is None:
            diagnostics.append(
                _diagnostic(
                    target,
                    "PARAMETER_TARGET_UNKNOWN_BLOCK",
                    f"Block '{target.block_id}' does not exist.",
                )
            )
            continue
        block_kind, arguments = block_contract
        if block_kind not in {"digital", "analog"}:
            diagnostics.append(
                _diagnostic(
                    target,
                    "PARAMETER_TARGET_UNSUPPORTED_BLOCK_KIND",
                    "Only Digital and Analog block arguments can be mapped.",
                )
            )
        argument = next(
            (item for item in arguments if item.name == target.argument_name),
            None,
        )
        if argument is None:
            diagnostics.append(
                _diagnostic(
                    target,
                    "PARAMETER_TARGET_UNKNOWN_ARGUMENT",
                    f"Argument '{target.argument_name}' does not exist in the block.",
                )
            )
            continue
        expected_dtype = {definition.dtype, argument.dtype}
        if target.dtype not in expected_dtype or len(expected_dtype) != 1:
            diagnostics.append(
                _diagnostic(
                    target,
                    "PARAMETER_TARGET_TYPE_MISMATCH",
                    "Parameter, target, and block argument dtypes must match.",
                )
            )
        expected_units = {definition.unit, argument.unit}
        if target.unit not in expected_units or len(expected_units) != 1:
            diagnostics.append(
                _diagnostic(
                    target,
                    "PARAMETER_TARGET_UNIT_MISMATCH",
                    "Parameter, target, and block argument units must match.",
                )
            )
    return tuple(diagnostics)


def _diagnostic(
    target: ParameterTargetIR,
    code: str,
    message: str,
) -> ParameterDiagnosticIR:
    return ParameterDiagnosticIR(
        diagnostic_id=f"parameter.target.{target.target_id}.{code.lower()}",
        severity="error",
        code=code,
        message=message,
        object_path=f"parameter_targets.{target.target_id}",
        source_span=target.source_span,
        suggestion="Fix the explicit parameter-to-argument mapping.",
        metadata={
            "parameter_name": target.parameter_name,
            "block_id": target.block_id,
            "argument_name": target.argument_name,
        },
    )
