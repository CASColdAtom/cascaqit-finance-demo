"""Canonical user-facing parameter values and typed expression trees."""

from __future__ import annotations

import json
import keyword
import math
import re
from collections.abc import Mapping
from dataclasses import dataclass, field, replace
from types import MappingProxyType
from typing import Any, Literal, Union

from cascaqit.native_ir.base import IRMixin
from cascaqit.syntax import SourceSpan

__all__ = [
    "CANONICAL_PARAMETER_SCHEMA_VERSION",
    "CompileImpact",
    "Expression",
    "Parameter",
    "ParameterDType",
    "ParameterScalar",
]

CANONICAL_PARAMETER_SCHEMA_VERSION = "cascaqit.parameters.v2"
ParameterDType = Literal["float", "int", "bool"]
CompileImpact = Literal["bind_only", "recompile"]
ParameterScalar = Union[bool, int, float]
NumericScalar = Union[int, float]
ExpressionOperator = Literal[
    "positive",
    "negative",
    "add",
    "subtract",
    "multiply",
    "divide",
    "power",
]


class _Arithmetic:
    """Build canonical expression nodes through Python arithmetic."""

    def _as_expression(self) -> Expression:
        raise NotImplementedError

    def __add__(self, other: Operand) -> Expression:
        return Expression.binary("add", self._as_expression(), other)

    def __radd__(self, other: Operand) -> Expression:
        return Expression.binary("add", other, self._as_expression())

    def __sub__(self, other: Operand) -> Expression:
        return Expression.binary("subtract", self._as_expression(), other)

    def __rsub__(self, other: Operand) -> Expression:
        return Expression.binary("subtract", other, self._as_expression())

    def __mul__(self, other: Operand) -> Expression:
        return Expression.binary("multiply", self._as_expression(), other)

    def __rmul__(self, other: Operand) -> Expression:
        return Expression.binary("multiply", other, self._as_expression())

    def __truediv__(self, other: Operand) -> Expression:
        return Expression.binary("divide", self._as_expression(), other)

    def __rtruediv__(self, other: Operand) -> Expression:
        return Expression.binary("divide", other, self._as_expression())

    def __pow__(self, other: Operand) -> Expression:
        return Expression.binary("power", self._as_expression(), other)

    def __rpow__(self, other: Operand) -> Expression:
        return Expression.binary("power", other, self._as_expression())

    def __pos__(self) -> Expression:
        return Expression.unary("positive", self._as_expression())

    def __neg__(self) -> Expression:
        return Expression.unary("negative", self._as_expression())


@dataclass(frozen=True)
class Parameter(_Arithmetic, IRMixin):
    """One immutable typed parameter shared by every programming mode."""

    name: str
    dtype: ParameterDType = "float"
    unit: str | None = None
    default: ParameterScalar | None = None
    lower_bound: int | float | None = None
    upper_bound: int | float | None = None
    expression: Expression | None = None
    compile_impact: CompileImpact = "bind_only"
    source_span: SourceSpan | None = None
    metadata: Mapping[str, Any] = field(default_factory=dict)
    schema_version: str = CANONICAL_PARAMETER_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_name(self.name, "name")
        if self.dtype not in {"float", "int", "bool"}:
            raise ValueError("dtype must be float, int, or bool.")
        if self.unit is not None and (
            not isinstance(self.unit, str) or not self.unit.strip()
        ):
            raise ValueError("unit must be None or a non-empty string.")
        if self.compile_impact not in {"bind_only", "recompile"}:
            raise ValueError("compile_impact must be bind_only or recompile.")
        if self.expression is not None and not isinstance(self.expression, Expression):
            raise TypeError("expression must be Expression or None.")
        if self.expression is not None and self.default is not None:
            raise ValueError("default and expression are mutually exclusive.")
        if self.expression is not None:
            if self.expression.dtype != self.dtype:
                raise TypeError("expression dtype must match parameter dtype.")
            if self.expression.unit != self.unit:
                raise ValueError("expression unit must match parameter unit exactly.")
        if self.default is not None:
            _validate_scalar(self.default, self.dtype, "default")
        if self.dtype == "bool" and (
            self.lower_bound is not None or self.upper_bound is not None
        ):
            raise ValueError("bool parameters cannot define numeric bounds.")
        for field_name in ("lower_bound", "upper_bound"):
            value = getattr(self, field_name)
            if value is not None:
                _validate_scalar(value, self.dtype, field_name)
        if (
            self.lower_bound is not None
            and self.upper_bound is not None
            and self.lower_bound > self.upper_bound
        ):
            raise ValueError("lower_bound must not exceed upper_bound.")
        if self.default is not None and not self.contains(self.default):
            raise ValueError("default must be within parameter bounds.")
        if self.source_span is not None and not isinstance(
            self.source_span, SourceSpan
        ):
            raise TypeError("source_span must be SourceSpan or None.")
        object.__setattr__(self, "metadata", _freeze_mapping(self.metadata))

    @property
    def required(self) -> bool:
        """Return whether binding must provide a concrete value."""
        return self.default is None and self.expression is None

    @property
    def dependencies(self) -> tuple[str, ...]:
        """Return stable expression dependencies for a derived parameter."""
        return () if self.expression is None else self.expression.dependencies

    def contains(self, value: ParameterScalar) -> bool:
        """Return whether a typed finite value satisfies the declared bounds."""
        _validate_scalar(value, self.dtype, "value")
        if self.lower_bound is not None and value < self.lower_bound:
            return False
        return not (self.upper_bound is not None and value > self.upper_bound)

    def evaluate(self, values: Mapping[str, ParameterScalar]) -> ParameterScalar:
        """Resolve this parameter from bindings, a default, or its expression."""
        if self.expression is not None:
            value = self.expression.evaluate(values)
        elif self.name in values:
            value = values[self.name]
        elif self.default is not None:
            value = self.default
        else:
            raise ValueError(f"Parameter '{self.name}' has no bound value.")
        _validate_scalar(value, self.dtype, self.name)
        if not self.contains(value):
            raise ValueError(f"Parameter '{self.name}' is outside its bounds.")
        return value

    def _as_expression(self) -> Expression:
        return Expression.reference(self)

    def to_ir(self) -> ParameterIR:
        """Project this value object into the canonical wire representation."""
        from cascaqit.parameters.ir import ParameterIR

        return ParameterIR(
            name=self.name,
            dtype=self.dtype,
            unit=self.unit,
            default=self.default,
            lower_bound=self.lower_bound,
            upper_bound=self.upper_bound,
            expression=self.expression,
            compile_impact=self.compile_impact,
            source_span=self.source_span,
            metadata=self.metadata,
        )

    @classmethod
    def from_ir(cls, parameter: ParameterIR) -> Parameter:
        """Restore a canonical value object from its wire representation."""
        from cascaqit.parameters.ir import ParameterIR

        if not isinstance(parameter, ParameterIR):
            raise TypeError("parameter must be ParameterIR.")
        return cls(
            name=parameter.name,
            dtype=parameter.dtype,
            unit=parameter.unit,
            default=parameter.default,
            lower_bound=parameter.lower_bound,
            upper_bound=parameter.upper_bound,
            expression=parameter.expression,
            compile_impact=parameter.compile_impact,
            source_span=parameter.source_span,
            metadata=parameter.metadata,
            schema_version=parameter.schema_version,
        )

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> Parameter:
        """Build a canonical parameter from JSON-compatible data."""
        expression = data.get("expression")
        span = data.get("source_span")
        return cls(
            name=str(data["name"]),
            dtype=data.get("dtype", "float"),
            unit=None if data.get("unit") is None else str(data["unit"]),
            default=data.get("default"),
            lower_bound=data.get("lower_bound"),
            upper_bound=data.get("upper_bound"),
            expression=(
                None
                if expression is None
                else Expression.from_dict(_require_mapping(expression, "expression"))
            ),
            compile_impact=data.get("compile_impact", "bind_only"),
            source_span=(
                None
                if span is None
                else SourceSpan.from_dict(dict(_require_mapping(span, "source_span")))
            ),
            metadata=dict(_require_mapping(data.get("metadata", {}), "metadata")),
            schema_version=str(
                data.get("schema_version", CANONICAL_PARAMETER_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> Parameter:
        """Build a canonical parameter from JSON text."""
        return cls.from_dict(_json_object(text, "Parameter"))


@dataclass(frozen=True)
class Expression(_Arithmetic, IRMixin):
    """A serializable, typed arithmetic expression tree."""

    node_type: Literal["literal", "parameter", "unary", "binary"]
    dtype: ParameterDType
    unit: str | None = None
    operator: ExpressionOperator | None = None
    operands: tuple[Expression, ...] = ()
    value: NumericScalar | None = None
    parameter_name: str | None = None
    schema_version: str = CANONICAL_PARAMETER_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.node_type not in {"literal", "parameter", "unary", "binary"}:
            raise ValueError("unsupported expression node_type.")
        if self.dtype not in {"float", "int"}:
            raise TypeError("expression dtype must be numeric.")
        if self.unit is not None and not self.unit.strip():
            raise ValueError("expression unit must be None or non-empty.")
        if any(not isinstance(item, Expression) for item in self.operands):
            raise TypeError("expression operands must contain Expression values.")
        expected_arity = {"literal": 0, "parameter": 0, "unary": 1, "binary": 2}
        if len(self.operands) != expected_arity[self.node_type]:
            raise ValueError("expression operand count does not match node_type.")
        if self.node_type == "literal":
            _validate_numeric(self.value, "expression literal")
        elif self.value is not None:
            raise ValueError("only literal expressions may contain value.")
        if self.node_type == "parameter":
            if self.parameter_name is None:
                raise ValueError("parameter expression requires parameter_name.")
            _require_name(self.parameter_name, "parameter_name")
        elif self.parameter_name is not None:
            raise ValueError("only parameter expressions may contain parameter_name.")
        valid_operator = (
            self.operator in {"positive", "negative"}
            if self.node_type == "unary"
            else self.operator
            in {"add", "subtract", "multiply", "divide", "power"}
            if self.node_type == "binary"
            else self.operator is None
        )
        if not valid_operator:
            raise ValueError("operator does not match expression node_type.")

    @property
    def dependencies(self) -> tuple[str, ...]:
        """Return unique parameter references in stable order."""
        if self.parameter_name is not None:
            return (self.parameter_name,)
        return tuple(
            sorted({name for operand in self.operands for name in operand.dependencies})
        )

    @classmethod
    def literal(cls, value: NumericScalar) -> Expression:
        """Create a finite dimensionless literal node."""
        normalized = _validate_numeric(value, "expression literal")
        dtype: ParameterDType = "int" if isinstance(normalized, int) else "float"
        return cls(node_type="literal", dtype=dtype, value=normalized)

    @classmethod
    def reference(cls, parameter: Parameter) -> Expression:
        """Create a typed reference to one numeric parameter."""
        if not isinstance(parameter, Parameter):
            raise TypeError("parameter must be Parameter.")
        if parameter.dtype == "bool":
            raise TypeError(
                "arithmetic expressions require numeric parameters, not bool."
            )
        return cls(
            node_type="parameter",
            dtype=parameter.dtype,
            unit=parameter.unit,
            parameter_name=parameter.name,
        )

    @classmethod
    def unary(
        cls,
        operator: Literal["positive", "negative"],
        operand: Operand,
    ) -> Expression:
        """Create a typed unary operation."""
        expression = _coerce_expression(operand)
        return cls(
            node_type="unary",
            dtype=expression.dtype,
            unit=expression.unit,
            operator=operator,
            operands=(expression,),
        )

    @classmethod
    def binary(
        cls,
        operator: Literal["add", "subtract", "multiply", "divide", "power"],
        left: Operand,
        right: Operand,
    ) -> Expression:
        """Create a binary operation after type and unit inference."""
        left_expression = _coerce_expression(left)
        right_expression = _coerce_expression(right)
        if operator in {"add", "subtract"}:
            left_expression, right_expression = _annotate_additive_literal_unit(
                left_expression, right_expression
            )
        dtype, unit = _infer_binary_contract(
            operator, left_expression, right_expression
        )
        if (
            operator == "divide"
            and right_expression.node_type == "literal"
            and right_expression.value == 0
        ):
            raise ZeroDivisionError("expression divisor must not be zero.")
        return cls(
            node_type="binary",
            dtype=dtype,
            unit=unit,
            operator=operator,
            operands=(left_expression, right_expression),
        )

    def evaluate(self, values: Mapping[str, ParameterScalar]) -> NumericScalar:
        """Evaluate the expression using finite, type-compatible bindings."""
        if self.node_type == "literal":
            assert self.value is not None
            return self.value
        if self.node_type == "parameter":
            assert self.parameter_name is not None
            if self.parameter_name not in values:
                raise ValueError(
                    f"Parameter '{self.parameter_name}' has no bound value."
                )
            return _validate_numeric(values[self.parameter_name], self.parameter_name)
        evaluated = tuple(operand.evaluate(values) for operand in self.operands)
        if self.operator == "positive":
            result: NumericScalar = +evaluated[0]
        elif self.operator == "negative":
            result = -evaluated[0]
        elif self.operator == "add":
            result = evaluated[0] + evaluated[1]
        elif self.operator == "subtract":
            result = evaluated[0] - evaluated[1]
        elif self.operator == "multiply":
            result = evaluated[0] * evaluated[1]
        elif self.operator == "divide":
            result = evaluated[0] / evaluated[1]
        elif self.operator == "power":
            result = evaluated[0] ** evaluated[1]
        else:
            raise ValueError("expression operator is not executable.")
        return _validate_numeric(result, "expression result")

    def _as_expression(self) -> Expression:
        return self

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> Expression:
        """Build an expression tree from JSON-compatible data."""
        operands = data.get("operands", ())
        if not isinstance(operands, (list, tuple)):
            raise TypeError("expression operands must be an array.")
        return cls(
            node_type=data["node_type"],
            dtype=data["dtype"],
            unit=None if data.get("unit") is None else str(data["unit"]),
            operator=data.get("operator"),
            operands=tuple(
                cls.from_dict(_require_mapping(item, "expression operand"))
                for item in operands
            ),
            value=data.get("value"),
            parameter_name=(
                None
                if data.get("parameter_name") is None
                else str(data["parameter_name"])
            ),
            schema_version=str(
                data.get("schema_version", CANONICAL_PARAMETER_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> Expression:
        """Build an expression tree from JSON text."""
        return cls.from_dict(_json_object(text, "Expression"))


Operand = Union[NumericScalar, Parameter, Expression]


def _coerce_expression(value: Operand) -> Expression:
    if isinstance(value, Expression):
        return value
    if isinstance(value, Parameter):
        return Expression.reference(value)
    return Expression.literal(value)


def _infer_binary_contract(
    operator: str,
    left: Expression,
    right: Expression,
) -> tuple[ParameterDType, str | None]:
    if operator in {"add", "subtract"}:
        if left.unit != right.unit:
            raise ValueError("addition and subtraction require matching units.")
        dtype: ParameterDType = (
            "float" if "float" in {left.dtype, right.dtype} else "int"
        )
        return dtype, left.unit
    if operator == "multiply":
        dtype = "float" if "float" in {left.dtype, right.dtype} else "int"
        return dtype, _compose_units(left.unit, right.unit, divide=False)
    if operator == "divide":
        return "float", _compose_units(left.unit, right.unit, divide=True)
    if operator == "power":
        if right.node_type != "literal" or not isinstance(right.value, int):
            raise TypeError("expression exponent must be an integer literal.")
        dtype = "float" if left.dtype == "float" or right.value < 0 else "int"
        return dtype, _power_unit(left.unit, right.value)
    raise ValueError(f"unsupported expression operator: {operator!r}.")


def _annotate_additive_literal_unit(
    left: Expression,
    right: Expression,
) -> tuple[Expression, Expression]:
    if left.node_type == "literal" and left.unit is None and right.unit is not None:
        left = replace(left, unit=right.unit)
    if right.node_type == "literal" and right.unit is None and left.unit is not None:
        right = replace(right, unit=left.unit)
    return left, right


_UNIT_PART = re.compile(r"([*/]?)([^*/]+)")


def _unit_factors(unit: str | None) -> dict[str, int]:
    if unit is None:
        return {}
    factors: dict[str, int] = {}
    for marker, raw_part in _UNIT_PART.findall(unit):
        part = raw_part.strip()
        if part == "1":
            continue
        name, separator, exponent_text = part.partition("^")
        exponent = int(exponent_text) if separator else 1
        if marker == "/":
            exponent = -exponent
        factors[name] = factors.get(name, 0) + exponent
    return {name: exponent for name, exponent in factors.items() if exponent}


def _compose_units(left: str | None, right: str | None, *, divide: bool) -> str | None:
    factors = _unit_factors(left)
    direction = -1 if divide else 1
    for name, exponent in _unit_factors(right).items():
        factors[name] = factors.get(name, 0) + direction * exponent
    return _format_unit(factors)


def _power_unit(unit: str | None, exponent: int) -> str | None:
    return _format_unit(
        {name: value * exponent for name, value in _unit_factors(unit).items()}
    )


def _format_unit(factors: Mapping[str, int]) -> str | None:
    numerator = [
        _format_unit_factor(name, value)
        for name, value in sorted(factors.items())
        if value > 0
    ]
    denominator = [
        _format_unit_factor(name, -value)
        for name, value in sorted(factors.items())
        if value < 0
    ]
    if not numerator and not denominator:
        return None
    numerator_text = "*".join(numerator) if numerator else "1"
    if not denominator:
        return numerator_text
    return f"{numerator_text}/{'*'.join(denominator)}"


def _format_unit_factor(name: str, exponent: int) -> str:
    return name if exponent == 1 else f"{name}^{exponent}"


def _require_name(value: object, field_name: str) -> None:
    if (
        not isinstance(value, str)
        or not value.isidentifier()
        or keyword.iskeyword(value)
    ):
        raise ValueError(f"{field_name} must be a non-keyword Python identifier.")


def _validate_scalar(
    value: object,
    dtype: ParameterDType,
    field_name: str,
) -> ParameterScalar:
    valid = (
        (dtype == "bool" and isinstance(value, bool))
        or (dtype == "int" and isinstance(value, int) and not isinstance(value, bool))
        or (
            dtype == "float"
            and isinstance(value, (int, float))
            and not isinstance(value, bool)
        )
    )
    if not valid:
        raise TypeError(f"{field_name} does not match dtype '{dtype}'.")
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError(f"{field_name} must be finite.")
    return value  # type: ignore[return-value]


def _validate_numeric(value: object, field_name: str) -> NumericScalar:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{field_name} must be a numeric scalar and not bool.")
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError(f"{field_name} must be finite.")
    return value


def _freeze_mapping(value: Mapping[str, Any]) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError("metadata must be a mapping.")
    return MappingProxyType(
        {str(key): _freeze_value(item) for key, item in sorted(value.items())}
    )


def _freeze_value(value: Any) -> Any:
    if isinstance(value, Mapping):
        return _freeze_mapping(value)
    if isinstance(value, (list, tuple)):
        return tuple(_freeze_value(item) for item in value)
    return value


def _require_mapping(value: object, field_name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{field_name} must be an object.")
    return value


def _json_object(text: str, type_name: str) -> Mapping[str, Any]:
    data = json.loads(text)
    if not isinstance(data, dict):
        raise TypeError(f"{type_name} JSON must contain an object.")
    return data


if False:  # pragma: no cover - imported only for static typing
    from cascaqit.parameters.ir import ParameterIR
