"""Source-aware diagnostics for unified parameter orchestration."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Literal

from cascaqit.native_ir.base import IRMixin
from cascaqit.syntax import SourceSpan

__all__ = ["ParameterDiagnosticIR"]

ParameterDiagnosticSeverity = Literal["info", "warning", "error"]


@dataclass(frozen=True)
class ParameterDiagnosticIR(IRMixin):
    """A source-aware diagnostic emitted by parameter orchestration."""

    diagnostic_id: str
    severity: ParameterDiagnosticSeverity
    code: str
    message: str
    object_path: str | None = None
    source_span: SourceSpan | None = None
    suggestion: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    stage: Literal["parameter"] = "parameter"
    schema_version: str = "cascaqit.parameters.v1"

    def __post_init__(self) -> None:
        for field_name in ("diagnostic_id", "code", "message"):
            value = getattr(self, field_name)
            if not isinstance(value, str) or not value.strip():
                raise ValueError(f"{field_name} must be a non-empty string.")
        if self.severity not in {"info", "warning", "error"}:
            raise ValueError("severity must be info, warning, or error.")
        if self.stage != "parameter":
            raise ValueError("stage must be parameter.")
        if self.source_span is not None and not isinstance(
            self.source_span, SourceSpan
        ):
            raise TypeError("source_span must be SourceSpan or None.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ParameterDiagnosticIR:
        """Build a parameter diagnostic from a dictionary."""
        span_data = data.get("source_span")
        return cls(
            diagnostic_id=str(data["diagnostic_id"]),
            severity=data["severity"],
            code=str(data["code"]),
            message=str(data["message"]),
            object_path=data.get("object_path"),
            source_span=(
                None if span_data is None else SourceSpan.from_dict(span_data)
            ),
            suggestion=data.get("suggestion"),
            metadata=dict(data.get("metadata", {})),
            stage=data.get("stage", "parameter"),
            schema_version=str(
                data.get("schema_version", "cascaqit.parameters.v1")
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> ParameterDiagnosticIR:
        """Build a parameter diagnostic from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("ParameterDiagnosticIR JSON must contain an object.")
        return cls.from_dict(data)
