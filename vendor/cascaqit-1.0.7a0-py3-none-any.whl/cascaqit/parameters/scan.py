"""Deterministic parameter scans for the hybrid parameter model."""

from __future__ import annotations

import itertools
import json
import math
from dataclasses import dataclass, field, replace
from typing import Any, Literal

from cascaqit.native_ir.base import IRMixin, stable_json
from cascaqit.parameters.canonical import (
    CANONICAL_PARAMETER_SCHEMA_VERSION,
    ParameterScalar,
)
from cascaqit.parameters.diagnostics import ParameterDiagnosticIR
from cascaqit.parameters.ir import ParameterBindIR
from cascaqit.parameters.manager import ParameterManager

__all__ = ["ParameterScan", "ParameterScanResult"]

ParameterScanMode = Literal["explicit", "cartesian"]


@dataclass(frozen=True)
class ParameterScanResult(IRMixin):
    """Validated bind sets produced by a deterministic parameter scan."""

    scan_id: str
    schema_hash: str
    bind_sets: tuple[ParameterBindIR, ...]
    diagnostics: tuple[ParameterDiagnosticIR, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = CANONICAL_PARAMETER_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_identifier(self.scan_id, field_name="scan_id")
        _require_hash(self.schema_hash, field_name="schema_hash")
        if any(not isinstance(item, ParameterBindIR) for item in self.bind_sets):
            raise TypeError("bind_sets must contain ParameterBindIR values.")
        if any(
            not isinstance(item, ParameterDiagnosticIR)
            for item in self.diagnostics
        ):
            raise TypeError("diagnostics must contain ParameterDiagnosticIR values.")

    @property
    def has_errors(self) -> bool:
        """Return whether any scan point failed validation."""
        return any(item.severity == "error" for item in self.diagnostics)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ParameterScanResult:
        """Build a parameter scan result from a dictionary."""
        return cls(
            scan_id=str(data["scan_id"]),
            schema_hash=str(data["schema_hash"]),
            bind_sets=tuple(
                ParameterBindIR.from_dict(item)
                for item in data.get("bind_sets", ())
            ),
            diagnostics=tuple(
                ParameterDiagnosticIR.from_dict(item)
                for item in data.get("diagnostics", ())
            ),
            metadata=dict(data.get("metadata", {})),
            schema_version=str(
                data.get("schema_version", CANONICAL_PARAMETER_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> ParameterScanResult:
        """Build a parameter scan result from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("ParameterScanResult JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class ParameterScan(IRMixin):
    """An ordered explicit list or deterministic Cartesian parameter grid."""

    scan_id: str
    mode: ParameterScanMode
    points: tuple[dict[str, ParameterScalar], ...]
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = CANONICAL_PARAMETER_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_identifier(self.scan_id, field_name="scan_id")
        if self.mode not in {"explicit", "cartesian"}:
            raise ValueError("mode must be explicit or cartesian.")
        for point in self.points:
            if not isinstance(point, dict):
                raise TypeError("points must contain dictionaries.")
            _normalize_point(point)

    @classmethod
    def explicit(
        cls,
        *,
        scan_id: str,
        points: tuple[dict[str, ParameterScalar], ...]
        | list[dict[str, ParameterScalar]],
        metadata: dict[str, Any] | None = None,
    ) -> ParameterScan:
        """Create a scan from an explicit ordered list of value mappings."""
        return cls(
            scan_id=scan_id,
            mode="explicit",
            points=tuple(_normalize_point(point) for point in points),
            metadata={} if metadata is None else metadata,
        )

    @classmethod
    def cartesian(
        cls,
        *,
        scan_id: str,
        grid: dict[
            str,
            tuple[ParameterScalar, ...] | list[ParameterScalar],
        ],
        metadata: dict[str, Any] | None = None,
    ) -> ParameterScan:
        """Create a scan from a stable Cartesian product of sorted axes."""
        names = tuple(sorted(grid))
        for name in names:
            _require_identifier(name, field_name="grid parameter name")
        axes = tuple(
            tuple(_normalize_scalar(value) for value in grid[name])
            for name in names
        )
        points = (
            ()
            if not names
            else tuple(
                {name: value for name, value in zip(names, values)}
                for values in itertools.product(*axes)
            )
        )
        return cls(
            scan_id=scan_id,
            mode="cartesian",
            points=points,
            metadata={} if metadata is None else metadata,
        )

    def expand(self, manager: ParameterManager) -> ParameterScanResult:
        """Bind all points without running a backend, kernel, or sweep runtime."""
        if not isinstance(manager, ParameterManager):
            raise TypeError("manager must be ParameterManager.")
        schema_hash = manager.schema.stable_hash()
        diagnostics: list[ParameterDiagnosticIR] = []
        bind_sets: list[ParameterBindIR] = []
        seen_values: set[str] = set()
        if not self.points:
            diagnostics.append(
                _diagnostic(
                    self.scan_id,
                    "PARAMETER_SCAN_EMPTY",
                    "Parameter scan does not contain any points.",
                    "Provide at least one explicit point or non-empty grid axis.",
                )
            )
        for index, point in enumerate(self.points):
            binding = manager.bind(
                point,
                bind_id=f"{self.scan_id}.bind.{index:06d}",
            )
            if binding.has_errors:
                diagnostics.extend(
                    _scan_diagnostic(item, self.scan_id, index)
                    for item in binding.diagnostics
                )
                continue
            if binding.bind_set is None:
                raise AssertionError(
                    "successful parameter binding requires a bind set."
                )
            values_key = stable_json(binding.bind_set.values)
            if values_key in seen_values:
                diagnostics.append(
                    _diagnostic(
                        f"{self.scan_id}.{index}",
                        "PARAMETER_SCAN_DUPLICATE_POINT",
                        "Parameter scan contains a duplicate resolved bind point.",
                        "Remove the duplicate point from the scan.",
                        object_path=f"parameter_scans.{self.scan_id}.points[{index}]",
                        metadata={"scan_id": self.scan_id, "scan_index": index},
                    )
                )
                continue
            seen_values.add(values_key)
            bind_sets.append(binding.bind_set)
        return ParameterScanResult(
            scan_id=self.scan_id,
            schema_hash=schema_hash,
            bind_sets=tuple(bind_sets),
            diagnostics=tuple(diagnostics),
            metadata={
                "mode": self.mode,
                "point_count": len(self.points),
                "bind_count": len(bind_sets),
                **self.metadata,
                "execution_performed": False,
            },
        )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ParameterScan:
        """Build a parameter scan from a dictionary."""
        return cls(
            scan_id=str(data["scan_id"]),
            mode=data["mode"],
            points=tuple(
                _normalize_point(item) for item in data.get("points", ())
            ),
            metadata=dict(data.get("metadata", {})),
            schema_version=str(
                data.get("schema_version", CANONICAL_PARAMETER_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> ParameterScan:
        """Build a parameter scan from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("ParameterScan JSON must contain an object.")
        return cls.from_dict(data)


def _normalize_point(point: object) -> dict[str, ParameterScalar]:
    if not isinstance(point, dict):
        raise TypeError("scan point must be a dictionary.")
    normalized: dict[str, ParameterScalar] = {}
    for name, value in point.items():
        normalized_name = str(name)
        _require_identifier(normalized_name, field_name="scan parameter name")
        normalized[normalized_name] = _normalize_scalar(value)
    return {name: normalized[name] for name in sorted(normalized)}


def _normalize_scalar(value: object) -> ParameterScalar:
    if not isinstance(value, (bool, int, float)):
        raise TypeError("scan values must be bool, int, or float.")
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("scan values must be finite.")
    return value


def _scan_diagnostic(
    diagnostic: ParameterDiagnosticIR,
    scan_id: str,
    index: int,
) -> ParameterDiagnosticIR:
    return replace(
        diagnostic,
        diagnostic_id=f"scan.{scan_id}.{index}.{diagnostic.diagnostic_id}",
        object_path=f"parameter_scans.{scan_id}.points[{index}]",
        metadata={
            **diagnostic.metadata,
            "scan_id": scan_id,
            "scan_index": index,
        },
    )


def _diagnostic(
    identity: str,
    code: str,
    message: str,
    suggestion: str,
    *,
    object_path: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> ParameterDiagnosticIR:
    return ParameterDiagnosticIR(
        diagnostic_id=f"parameter.scan.{identity}.{code.lower()}",
        severity="error",
        code=code,
        message=message,
        object_path=object_path,
        suggestion=suggestion,
        metadata={} if metadata is None else metadata,
    )


def _require_identifier(value: str, *, field_name: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field_name} must be a non-empty string.")


def _require_hash(value: str, *, field_name: str) -> None:
    if len(value) != 64 or any(
        character not in "0123456789abcdef" for character in value
    ):
        raise ValueError(f"{field_name} must be a lowercase SHA-256 hex digest.")
