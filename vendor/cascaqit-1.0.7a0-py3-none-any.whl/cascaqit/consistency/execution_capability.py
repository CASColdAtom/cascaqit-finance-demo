"""Side-effect-free execution capability contracts for program dispatch."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Literal

from cascaqit.diagnostics import DiagnosticsIR, with_diagnostic_taxonomy
from cascaqit.digital import DigitalProgramIR
from cascaqit.hybrid import HybridProgramIR, assess_hybrid_backend_readiness
from cascaqit.native_ir import ProgramIR
from cascaqit.native_ir.base import IRMixin
from cascaqit.native_ir.models import SCHEMA_VERSION

__all__ = [
    "ExecutionBackendMode",
    "ExecutionCapabilityIR",
    "ExecutionMode",
    "ExecutionProgramKind",
    "ExecutionSupportStatus",
    "assess_execution_capability",
]

ExecutionProgramKind = Literal["analog", "digital", "hybrid", "unknown"]
ExecutionMode = Literal["simulate", "compile", "package", "backend_run"]
ExecutionBackendMode = Literal[
    "local_simulator",
    "local_mock",
    "live_hardware",
    "cloud",
]
ExecutionSupportStatus = Literal["supported", "planned", "blocked", "unsupported"]

_MODE_STAGES: dict[ExecutionMode, tuple[str, ...]] = {
    "simulate": ("validation", "simulation"),
    "compile": ("validation", "discretization", "compilation"),
    "package": ("validation", "discretization", "compilation", "package"),
    "backend_run": (
        "validation",
        "discretization",
        "compilation",
        "package",
        "backend_run",
    ),
}


@dataclass(frozen=True)
class ExecutionCapabilityIR(IRMixin):
    """Side-effect-free execution capability assessment."""

    capability_id: str
    program_kind: ExecutionProgramKind
    requested_mode: ExecutionMode
    backend_mode: ExecutionBackendMode
    current_status: ExecutionSupportStatus
    v0_14_target_status: ExecutionSupportStatus
    supported_stages: tuple[str, ...] = ()
    planned_stages: tuple[str, ...] = ()
    blocked_stages: tuple[str, ...] = ()
    blocking_diagnostics: tuple[DiagnosticsIR, ...] = ()
    diagnostics: tuple[DiagnosticsIR, ...] = ()
    next_action: str | None = None
    offline_deterministic: bool = True
    hardware_execution: bool = False
    cloud_execution: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ExecutionCapabilityIR:
        """Build an execution capability assessment from a dictionary."""
        return cls(
            capability_id=str(data["capability_id"]),
            program_kind=data["program_kind"],
            requested_mode=data["requested_mode"],
            backend_mode=data.get("backend_mode", "local_mock"),
            current_status=data["current_status"],
            v0_14_target_status=data.get(
                "v0_14_target_status",
                data["current_status"],
            ),
            supported_stages=tuple(
                str(stage) for stage in data.get("supported_stages", ())
            ),
            planned_stages=tuple(
                str(stage) for stage in data.get("planned_stages", ())
            ),
            blocked_stages=tuple(
                str(stage) for stage in data.get("blocked_stages", ())
            ),
            blocking_diagnostics=tuple(
                DiagnosticsIR.from_dict(diagnostic)
                for diagnostic in data.get("blocking_diagnostics", ())
            ),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(diagnostic)
                for diagnostic in data.get("diagnostics", ())
            ),
            next_action=data.get("next_action"),
            offline_deterministic=bool(data.get("offline_deterministic", True)),
            hardware_execution=bool(data.get("hardware_execution", False)),
            cloud_execution=bool(data.get("cloud_execution", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> ExecutionCapabilityIR:
        """Build an execution capability assessment from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("ExecutionCapabilityIR JSON must contain an object.")
        return cls.from_dict(data)


def assess_execution_capability(
    program: object,
    *,
    requested_mode: ExecutionMode = "backend_run",
    backend_mode: ExecutionBackendMode = "local_mock",
) -> ExecutionCapabilityIR:
    """Assess execution support without executing downstream pipeline stages."""
    program_kind = _program_kind(program)
    requested_stages = _MODE_STAGES[requested_mode]
    diagnostics = list(_shape_diagnostics(program, program_kind))
    blocking = [
        diagnostic
        for diagnostic in diagnostics
        if diagnostic.severity in {"warning", "error"}
    ]
    if program_kind == "unknown":
        blocking.append(
            _diagnostic(
                code="EXECUTION_PROGRAM_KIND_UNSUPPORTED",
                message="Execution capability cannot classify this program object.",
                object_path="program",
                severity="error",
                metadata={"program_type": type(program).__name__},
            )
        )
    if blocking:
        return _capability(
            program=program,
            program_kind=program_kind,
            requested_mode=requested_mode,
            backend_mode=backend_mode,
            current_status="blocked",
            target_status="blocked",
            supported_stages=(),
            planned_stages=(),
            blocked_stages=requested_stages,
            diagnostics=tuple(diagnostics),
            blocking_diagnostics=tuple(blocking),
            next_action="Resolve blocking diagnostics before execution planning.",
        )

    current_status, target_status, supported, planned, blocked, extra = _matrix(
        program_kind=program_kind,
        requested_mode=requested_mode,
        backend_mode=backend_mode,
    )
    diagnostics.extend(extra)
    if (
        isinstance(program, HybridProgramIR)
        and requested_mode == "backend_run"
    ):
        diagnostics.extend(
            assess_hybrid_backend_readiness(program).blocking_diagnostics
        )
    blocking = [
        diagnostic
        for diagnostic in diagnostics
        if diagnostic.severity in {"warning", "error"}
        and current_status in {"blocked", "unsupported"}
    ]
    return _capability(
        program=program,
        program_kind=program_kind,
        requested_mode=requested_mode,
        backend_mode=backend_mode,
        current_status=current_status,
        target_status=target_status,
        supported_stages=supported,
        planned_stages=planned,
        blocked_stages=blocked,
        diagnostics=tuple(diagnostics),
        blocking_diagnostics=tuple(blocking),
        next_action=_next_action(current_status, target_status, program_kind),
    )


def _program_kind(program: object) -> ExecutionProgramKind:
    if isinstance(program, ProgramIR) and program.program_type == "analog":
        return "analog"
    if isinstance(program, DigitalProgramIR):
        return "digital"
    if isinstance(program, HybridProgramIR):
        return "hybrid"
    if hasattr(program, "to_ir"):
        return "analog"
    return "unknown"


def _shape_diagnostics(
    program: object,
    program_kind: ExecutionProgramKind,
) -> tuple[DiagnosticsIR, ...]:
    if isinstance(program, DigitalProgramIR):
        return program.validate_ir_only()
    if isinstance(program, HybridProgramIR):
        return program.validate_ir_only()
    if isinstance(program, ProgramIR):
        return _analog_shape_diagnostics(program)
    if program_kind == "analog":
        return (
            _diagnostic(
                code="EXECUTION_ANALOG_BUILDER_ACCEPTED",
                message=(
                    "Analog builder-like object can be planned as analog; "
                    "materialize ProgramIR before compile/package/backend run."
                ),
                object_path="program",
                severity="info",
            ),
        )
    return ()


def _analog_shape_diagnostics(program: ProgramIR) -> tuple[DiagnosticsIR, ...]:
    diagnostics: list[DiagnosticsIR] = []
    if not program.measurements:
        diagnostics.append(
            _diagnostic(
                code="EXECUTION_ANALOG_MEASUREMENT_MISSING",
                message="Analog execution requires at least one terminal measurement.",
                object_path="program.measurements",
                severity="error",
            )
        )
    if not program.register.sites:
        diagnostics.append(
            _diagnostic(
                code="EXECUTION_ANALOG_REGISTER_EMPTY",
                message="Analog execution requires at least one register site.",
                object_path="program.register.sites",
                severity="error",
            )
        )
    if diagnostics:
        return tuple(diagnostics)
    return (
        _diagnostic(
            code="EXECUTION_ANALOG_SHAPE_VALID",
            message="Analog program shape is sufficient for execution planning.",
            object_path="program",
            severity="info",
        ),
    )


def _matrix(
    *,
    program_kind: ExecutionProgramKind,
    requested_mode: ExecutionMode,
    backend_mode: ExecutionBackendMode,
) -> tuple[
    ExecutionSupportStatus,
    ExecutionSupportStatus,
    tuple[str, ...],
    tuple[str, ...],
    tuple[str, ...],
    tuple[DiagnosticsIR, ...],
]:
    requested_stages = _MODE_STAGES[requested_mode]
    if program_kind == "analog":
        if (
            backend_mode in {"live_hardware", "cloud"}
            and requested_mode == "backend_run"
        ):
            return (
                "blocked",
                "planned",
                tuple(stage for stage in requested_stages if stage != "backend_run"),
                (),
                ("backend_run",),
                (
                    _diagnostic(
                        code="EXECUTION_LIVE_BACKEND_UNAVAILABLE",
                        message=(
                            "Live hardware/cloud backend execution is not enabled "
                            "in the default offline SDK path."
                        ),
                        object_path="backend_mode",
                        severity="error",
                    ),
                ),
            )
        return (
            "supported",
            "supported",
            requested_stages,
            (),
            (),
            (_supported_diagnostic(program_kind, requested_mode),),
        )
    if program_kind == "digital":
        if requested_mode == "simulate":
            return (
                "supported",
                "supported",
                requested_stages,
                (),
                (),
                (_supported_diagnostic(program_kind, requested_mode),),
            )
        if backend_mode in {"local_mock", "local_simulator"}:
            return (
                "supported",
                "supported",
                requested_stages,
                (),
                (),
                (
                    _supported_diagnostic(program_kind, requested_mode),
                ),
            )
        return (
            "blocked",
            "blocked",
            ("validation",),
            (),
            tuple(stage for stage in requested_stages if stage != "validation"),
            (
                _diagnostic(
                    code="EXECUTION_DIGITAL_LIVE_BACKEND_BLOCKED",
                    message=(
                        "Live digital hardware/cloud execution requires target "
                        "native gate and calibration constraints."
                    ),
                    object_path="backend_mode",
                    severity="error",
                ),
            ),
        )
    if program_kind == "hybrid":
        if requested_mode == "simulate":
            return (
                "supported",
                "supported",
                requested_stages,
                (),
                (),
                (
                    _diagnostic(
                        code="EXECUTION_HYBRID_PLAN_SIMULATION_SUPPORTED",
                        message=(
                            "Hybrid simulation is supported as plan-first local "
                            "simulation with explicit boundary diagnostics."
                        ),
                        object_path="hybrid_program",
                        severity="info",
                    ),
                ),
            )
        return (
            "blocked",
            "blocked",
            ("validation",),
            (),
            tuple(stage for stage in requested_stages if stage != "validation"),
            (
                _diagnostic(
                    code="EXECUTION_HYBRID_BACKEND_UNSUPPORTED",
                    message=(
                        "Hybrid compile/package/backend execution is blocked "
                        "until full DAQC lowering and state handoff are designed."
                    ),
                    object_path="hybrid_program",
                    severity="error",
                ),
            ),
        )
    return (
        "blocked",
        "blocked",
        (),
        (),
        requested_stages,
        (),
    )


def _capability(
    *,
    program: object,
    program_kind: ExecutionProgramKind,
    requested_mode: ExecutionMode,
    backend_mode: ExecutionBackendMode,
    current_status: ExecutionSupportStatus,
    target_status: ExecutionSupportStatus,
    supported_stages: tuple[str, ...],
    planned_stages: tuple[str, ...],
    blocked_stages: tuple[str, ...],
    diagnostics: tuple[DiagnosticsIR, ...],
    blocking_diagnostics: tuple[DiagnosticsIR, ...],
    next_action: str | None,
) -> ExecutionCapabilityIR:
    return ExecutionCapabilityIR(
        capability_id=(
            f"execution_capability.{program_kind}.{requested_mode}.{backend_mode}"
        ),
        program_kind=program_kind,
        requested_mode=requested_mode,
        backend_mode=backend_mode,
        current_status=current_status,
        v0_14_target_status=target_status,
        supported_stages=supported_stages,
        planned_stages=planned_stages,
        blocked_stages=blocked_stages,
        blocking_diagnostics=blocking_diagnostics,
        diagnostics=diagnostics,
        next_action=next_action,
        metadata={
            "program_id": _program_id(program),
            "program_type": type(program).__name__,
            "side_effect_free": True,
            "compiler_invoked": False,
            "package_builder_invoked": False,
            "backend_invoked": False,
            "simulator_invoked": False,
        },
    )


def _program_id(program: object) -> str | None:
    return getattr(program, "program_id", None)


def _supported_diagnostic(
    program_kind: ExecutionProgramKind,
    requested_mode: ExecutionMode,
) -> DiagnosticsIR:
    return _diagnostic(
        code=f"EXECUTION_{program_kind.upper()}_{requested_mode.upper()}_SUPPORTED",
        message=f"{program_kind} {requested_mode} is supported in the offline path.",
        object_path="program",
        severity="info",
    )


def _next_action(
    current_status: ExecutionSupportStatus,
    target_status: ExecutionSupportStatus,
    program_kind: ExecutionProgramKind,
) -> str:
    if current_status == "supported":
        return "Proceed with the requested execution path."
    if current_status == "planned" and target_status == "supported":
        return f"Complete the planned runtime path before executing {program_kind}."
    if current_status == "blocked":
        return "Do not compile, package, or submit until blockers are resolved."
    return "Use a supported execution mode or keep this program as a contract."


def _diagnostic(
    *,
    code: str,
    message: str,
    object_path: str,
    severity: Literal["info", "warning", "error"],
    metadata: dict[str, Any] | None = None,
) -> DiagnosticsIR:
    return with_diagnostic_taxonomy(
        DiagnosticsIR(
            diagnostic_id=f"execution_capability.{code.lower()}",
            stage="validation",
            severity=severity,
            code=code,
            message=message,
            object_path=object_path,
            metadata={} if metadata is None else dict(metadata),
        ),
        reason_category="execution_capability",
        action="use_supported_execution_path",
    )
