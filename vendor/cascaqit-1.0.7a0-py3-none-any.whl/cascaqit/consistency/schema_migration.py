"""Local schema migration diff discipline helpers."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Literal, cast

from cascaqit.diagnostics import DiagnosticsIR, with_diagnostic_taxonomy
from cascaqit.native_ir.base import IRMixin, canonicalize
from cascaqit.native_ir.models import SCHEMA_VERSION

__all__ = [
    "SchemaMigrationCheckIR",
    "SchemaMigrationStatus",
    "compare_schema_migration",
    "schema_migration_note_template",
]

SchemaMigrationStatus = Literal["compatible", "review_required", "blocked"]

_NEGATIVE_BOUNDARY_FIELDS = {
    "artifact_bytes_read",
    "backend_called",
    "cloud_compile_used",
    "cloud_execution",
    "hardware_execution",
    "metadata_only",
    "network_accessed",
    "result_interpreted",
    "source_result_mutated",
}


@dataclass(frozen=True)
class SchemaMigrationCheckIR(IRMixin):
    """Metadata-only report for local JSON schema migration review."""

    check_id: str
    status: SchemaMigrationStatus
    schema_name: str
    old_title: str | None
    new_title: str | None
    compatible_changes: tuple[dict[str, Any], ...] = ()
    review_required_changes: tuple[dict[str, Any], ...] = ()
    blocked_changes: tuple[dict[str, Any], ...] = ()
    diagnostics: tuple[DiagnosticsIR, ...] = ()
    metadata_only: bool = True
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SchemaMigrationCheckIR:
        """Build a schema migration check from a dictionary."""
        return cls(
            check_id=str(data["check_id"]),
            status=data["status"],
            schema_name=str(data["schema_name"]),
            old_title=data.get("old_title"),
            new_title=data.get("new_title"),
            compatible_changes=tuple(
                canonicalize(item) for item in data.get("compatible_changes", ())
            ),
            review_required_changes=tuple(
                canonicalize(item)
                for item in data.get("review_required_changes", ())
            ),
            blocked_changes=tuple(
                canonicalize(item) for item in data.get("blocked_changes", ())
            ),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(item)
                for item in data.get("diagnostics", ())
            ),
            metadata_only=bool(data.get("metadata_only", True)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> SchemaMigrationCheckIR:
        """Build a schema migration check from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("SchemaMigrationCheckIR JSON must contain an object.")
        return cls.from_dict(data)


def compare_schema_migration(
    old_schema: dict[str, Any],
    new_schema: dict[str, Any],
    *,
    schema_name: str,
    check_id: str | None = None,
) -> SchemaMigrationCheckIR:
    """Compare two local JSON schemas and classify migration risk."""
    if not isinstance(old_schema, dict) or not isinstance(new_schema, dict):
        raise TypeError("old_schema and new_schema must be JSON schema objects.")
    compatible: list[dict[str, Any]] = []
    review_required: list[dict[str, Any]] = []
    blocked: list[dict[str, Any]] = []

    _compare_root_properties(old_schema, new_schema, compatible, review_required)
    _compare_required(old_schema, new_schema, review_required, blocked)
    _compare_additional_properties(old_schema, new_schema, review_required)
    _compare_enum_const(old_schema, new_schema, review_required, blocked)
    _compare_negative_boundary_constraints(
        old_schema,
        new_schema,
        review_required,
        blocked,
    )

    diagnostics = tuple(
        [
            *(
                _diagnostic(
                    schema_name=schema_name,
                    change=change,
                    severity="error",
                )
                for change in blocked
            ),
            *(
                _diagnostic(
                    schema_name=schema_name,
                    change=change,
                    severity="warning",
                )
                for change in review_required
            ),
        ]
    )
    status: SchemaMigrationStatus
    if blocked:
        status = "blocked"
    elif review_required:
        status = "review_required"
    else:
        status = "compatible"
    return SchemaMigrationCheckIR(
        check_id=check_id or f"schema_migration.{schema_name}",
        status=status,
        schema_name=schema_name,
        old_title=_string_or_none(old_schema.get("title")),
        new_title=_string_or_none(new_schema.get("title")),
        compatible_changes=tuple(compatible),
        review_required_changes=tuple(review_required),
        blocked_changes=tuple(blocked),
        diagnostics=diagnostics,
        metadata={
            "schema_diff_version": "schema_migration.v0_22",
            "root_fields_checked": True,
            "required_fields_checked": True,
            "enum_const_checked": True,
            "additional_properties_checked": True,
            "metadata_only_negative_constraints_checked": True,
        },
    )


def schema_migration_note_template(
    *,
    schema_name: str,
    from_version: str = "v0.x",
    to_version: str = "v0.x",
) -> str:
    """Return a local Markdown template for documenting schema migrations."""
    return (
        f"# Schema Migration Note: {schema_name}\n\n"
        f"- From: {from_version}\n"
        f"- To: {to_version}\n"
        "- Compatibility: compatible | review_required | blocked\n"
        "- User-visible change: \n"
        "- Root field changes: \n"
        "- Required field changes: \n"
        "- Enum/const changes: \n"
        "- additionalProperties changes: \n"
        "- Metadata-only negative constraints: preserved | changed\n"
        "- Golden fixture updates: none | deliberate\n"
        "- Tests added or updated: \n"
        "- Migration rationale: \n"
    )


def _compare_root_properties(
    old_schema: dict[str, Any],
    new_schema: dict[str, Any],
    compatible: list[dict[str, Any]],
    review_required: list[dict[str, Any]],
) -> None:
    old_properties = _properties(old_schema)
    new_properties = _properties(new_schema)
    old_fields = set(old_properties)
    new_fields = set(new_properties)
    for field_name in sorted(new_fields - old_fields):
        if field_name == "metadata":
            compatible.append(
                _change(
                    kind="root_field_added",
                    path=f"/properties/{field_name}",
                    detail="Approved metadata extension point added.",
                )
            )
        else:
            review_required.append(
                _change(
                    kind="root_field_added",
                    path=f"/properties/{field_name}",
                    detail="New root fields require migration notes.",
                )
            )
    for field_name in sorted(old_fields - new_fields):
        review_required.append(
            _change(
                kind="root_field_removed",
                path=f"/properties/{field_name}",
                detail="Removed root fields require migration notes.",
            )
        )


def _compare_required(
    old_schema: dict[str, Any],
    new_schema: dict[str, Any],
    review_required: list[dict[str, Any]],
    blocked: list[dict[str, Any]],
) -> None:
    old_required = set(_string_items(old_schema.get("required", ())))
    new_required = set(_string_items(new_schema.get("required", ())))
    for field_name in sorted(new_required - old_required):
        blocked.append(
            _change(
                kind="required_field_added",
                path="/required",
                field=field_name,
                detail="Adding required fields breaks existing payload readers.",
            )
        )
    for field_name in sorted(old_required - new_required):
        review_required.append(
            _change(
                kind="required_field_removed",
                path="/required",
                field=field_name,
                detail="Removing required fields changes the contract.",
            )
        )


def _compare_additional_properties(
    old_schema: dict[str, Any],
    new_schema: dict[str, Any],
    review_required: list[dict[str, Any]],
) -> None:
    for path, old_value, new_value in _walk_keyword_pair(
        old_schema,
        new_schema,
        "additionalProperties",
    ):
        if canonicalize(old_value) != canonicalize(new_value):
            review_required.append(
                _change(
                    kind="additional_properties_changed",
                    path=path,
                    old=canonicalize(old_value),
                    new=canonicalize(new_value),
                    detail="additionalProperties changes require review.",
                )
            )


def _compare_enum_const(
    old_schema: dict[str, Any],
    new_schema: dict[str, Any],
    review_required: list[dict[str, Any]],
    blocked: list[dict[str, Any]],
) -> None:
    for keyword in ("enum", "const"):
        for path, old_value, new_value in _walk_keyword_pair(
            old_schema,
            new_schema,
            keyword,
        ):
            if canonicalize(old_value) == canonicalize(new_value):
                continue
            old_set = set(_hashable_items(old_value)) if keyword == "enum" else None
            new_set = set(_hashable_items(new_value)) if keyword == "enum" else None
            if keyword == "enum" and old_set is not None and new_set is not None:
                removed = sorted(old_set - new_set)
                added = sorted(new_set - old_set)
                target = blocked if removed else review_required
                target.append(
                    _change(
                        kind="enum_changed",
                        path=path,
                        added=added,
                        removed=removed,
                        detail="Enum value changes require migration review.",
                    )
                )
            else:
                blocked.append(
                    _change(
                        kind="const_changed",
                        path=path,
                        old=canonicalize(old_value),
                        new=canonicalize(new_value),
                        detail="Const changes can invalidate existing payloads.",
                    )
                )


def _compare_negative_boundary_constraints(
    old_schema: dict[str, Any],
    new_schema: dict[str, Any],
    review_required: list[dict[str, Any]],
    blocked: list[dict[str, Any]],
) -> None:
    old_constraints = _negative_constraints(old_schema)
    new_constraints = _negative_constraints(new_schema)
    for path, old_value in sorted(old_constraints.items()):
        if path not in new_constraints:
            blocked.append(
                _change(
                    kind="negative_constraint_removed",
                    path=path,
                    old=old_value,
                    detail="Metadata-only negative constraints must not be removed.",
                )
            )
        elif canonicalize(new_constraints[path]) != canonicalize(old_value):
            blocked.append(
                _change(
                    kind="negative_constraint_changed",
                    path=path,
                    old=old_value,
                    new=new_constraints[path],
                    detail="Metadata-only negative constraints must not be loosened.",
                )
            )
    for path, new_value in sorted(new_constraints.items()):
        if path not in old_constraints:
            review_required.append(
                _change(
                    kind="negative_constraint_added",
                    path=path,
                    new=new_value,
                    detail="New negative constraints are allowed but require review.",
                )
            )


def _negative_constraints(schema: Any, path: str = "") -> dict[str, Any]:
    constraints: dict[str, Any] = {}
    if isinstance(schema, dict):
        properties = schema.get("properties")
        if isinstance(properties, dict):
            for field_name, field_schema in properties.items():
                child_path = f"{path}/properties/{field_name}"
                if (
                    field_name in _NEGATIVE_BOUNDARY_FIELDS
                    and isinstance(field_schema, dict)
                    and "const" in field_schema
                ):
                    constraints[f"{child_path}/const"] = canonicalize(
                        field_schema["const"]
                    )
                constraints.update(_negative_constraints(field_schema, child_path))
        for key, value in schema.items():
            if key not in {"properties"}:
                constraints.update(_negative_constraints(value, f"{path}/{key}"))
    elif isinstance(schema, list):
        for index, item in enumerate(schema):
            constraints.update(_negative_constraints(item, f"{path}/{index}"))
    return constraints


def _walk_keyword_pair(
    old_schema: Any,
    new_schema: Any,
    keyword: str,
    path: str = "",
) -> tuple[tuple[str, Any, Any], ...]:
    pairs: list[tuple[str, Any, Any]] = []
    if isinstance(old_schema, dict) and isinstance(new_schema, dict):
        if keyword in old_schema or keyword in new_schema:
            pairs.append(
                (
                    f"{path}/{keyword}",
                    old_schema.get(keyword),
                    new_schema.get(keyword),
                )
            )
        for key in sorted(set(old_schema) | set(new_schema)):
            if key == keyword:
                continue
            pairs.extend(
                _walk_keyword_pair(
                    old_schema.get(key),
                    new_schema.get(key),
                    keyword,
                    f"{path}/{key}",
                )
            )
    elif isinstance(old_schema, list) and isinstance(new_schema, list):
        for index, (old_item, new_item) in enumerate(zip(old_schema, new_schema)):
            pairs.extend(
                _walk_keyword_pair(old_item, new_item, keyword, f"{path}/{index}")
            )
    return tuple(pairs)


def _diagnostic(
    *,
    schema_name: str,
    change: dict[str, Any],
    severity: Literal["warning", "error"],
) -> DiagnosticsIR:
    return with_diagnostic_taxonomy(
        DiagnosticsIR(
            diagnostic_id=f"schema_migration.{schema_name}.{change['kind']}",
            stage="serialization",
            severity=severity,
            code=f"SCHEMA_{str(change['kind']).upper()}",
            message=str(change["detail"]),
            object_path=str(change["path"]),
            suggestion="Add migration notes or preserve the previous schema contract.",
            metadata={"schema_name": schema_name, **change},
        ),
        reason_category="schema",
        taxonomy_stage="schema",
        action="document_or_restore_schema_migration",
    )


def _properties(schema: dict[str, Any]) -> dict[str, Any]:
    properties = schema.get("properties", {})
    return properties if isinstance(properties, dict) else {}


def _string_items(value: Any) -> tuple[str, ...]:
    if not isinstance(value, list):
        return ()
    return tuple(str(item) for item in value)


def _hashable_items(value: Any) -> tuple[Any, ...]:
    if not isinstance(value, list):
        return ()
    return tuple(canonicalize(item) for item in value)


def _string_or_none(value: Any) -> str | None:
    return None if value is None else str(value)


def _change(**kwargs: Any) -> dict[str, Any]:
    return cast(dict[str, Any], canonicalize(kwargs))
