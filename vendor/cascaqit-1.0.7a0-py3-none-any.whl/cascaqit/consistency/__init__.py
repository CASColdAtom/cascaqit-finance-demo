"""Focused public execution-capability and schema-migration checks."""

from cascaqit.consistency.execution_capability import (
    ExecutionBackendMode,
    ExecutionCapabilityIR,
    ExecutionMode,
    ExecutionProgramKind,
    ExecutionSupportStatus,
    assess_execution_capability,
)
from cascaqit.consistency.schema_migration import (
    SchemaMigrationCheckIR,
    SchemaMigrationStatus,
    compare_schema_migration,
    schema_migration_note_template,
)

__all__ = [
    "ExecutionBackendMode",
    "ExecutionCapabilityIR",
    "ExecutionMode",
    "ExecutionProgramKind",
    "ExecutionSupportStatus",
    "SchemaMigrationCheckIR",
    "SchemaMigrationStatus",
    "assess_execution_capability",
    "compare_schema_migration",
    "schema_migration_note_template",
]
