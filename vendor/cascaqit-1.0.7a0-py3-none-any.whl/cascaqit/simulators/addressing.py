"""Runtime evidence shared by dynamic site-addressing state consumers."""

from __future__ import annotations

from typing import Any

from cascaqit.native_ir import ProgramIR, SiteAddressingIR


def site_addressing_provenance_metadata(
    program: ProgramIR,
    *,
    consumer: str,
) -> dict[str, Any]:
    """Return provenance metadata only when a program has dynamic addressing."""
    terms = _ordered_addressing_terms(program)
    if not any(addressing.is_dynamic for _, _, addressing in terms):
        return {}
    return {
        "site_addressing": {
            "consumer": consumer,
            "program_hash": program.stable_hash(),
            "dynamic_term_count": sum(
                addressing.is_dynamic for _, _, addressing in terms
            ),
            "terms": [
                {
                    "control_kind": control_kind,
                    "term_index": term_index,
                    "addressing_hash": addressing.stable_hash(),
                    "source_kind": addressing.source_kind,
                    "frame_count": addressing.frame_count,
                    "duration": addressing.duration,
                    "time_unit": addressing.time_unit,
                    "interpolation": addressing.interpolation,
                }
                for control_kind, term_index, addressing in terms
            ],
        }
    }


def _ordered_addressing_terms(
    program: ProgramIR,
) -> tuple[tuple[str, int, SiteAddressingIR], ...]:
    detuning = tuple(
        ("local_detuning", index, term.addressing)
        for index, term in enumerate(program.hamiltonian.local_detuning_terms)
    )
    rabi = tuple(
        ("local_rabi", index, term.addressing)
        for index, term in enumerate(program.hamiltonian.local_rabi_terms)
    )
    return detuning + rabi
