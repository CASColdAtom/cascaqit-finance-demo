"""Executable pure-state model shared by local simulator kernels."""

from __future__ import annotations

import hashlib
import math
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from typing import Literal, Optional, Union

from cascaqit.exceptions import ProgramValidationError
from cascaqit.native_ir.base import stable_json
from cascaqit.simulators.models import (
    SimulationStateIR,
    build_state_vector_metadata_summary,
)

__all__ = ["SimulationState", "StateProvenance"]

SimulationBasis = Literal["logical_two_level"]
ContextScalar = Optional[Union[bool, int, float, str]]
ContextItems = tuple[tuple[str, ContextScalar], ...]
ContextInput = Union[Mapping[str, ContextScalar], Sequence[tuple[str, ContextScalar]]]

_NORMALIZATION_TOLERANCE = 1e-9


@dataclass(frozen=True)
class StateProvenance:
    """Compact immutable lineage for one executable simulation state."""

    producer: str
    parent_state_id: str | None = None
    parent_state_hash: str | None = None
    source_hash: str | None = None
    step_index: int = 0
    metadata: ContextItems = ()

    def __post_init__(self) -> None:
        if not self.producer.strip():
            _raise_state_error(
                "State provenance producer must not be empty.",
                code="SIMULATION_STATE_PROVENANCE_PRODUCER_EMPTY",
                object_path="simulation_state.provenance.producer",
                suggestion="Record the kernel or builder that produced the state.",
            )
        if self.step_index < 0:
            _raise_state_error(
                "State provenance step_index must be non-negative.",
                code="SIMULATION_STATE_PROVENANCE_STEP_INVALID",
                object_path="simulation_state.provenance.step_index",
                suggestion=(
                    "Use zero for an initial state and increment each transition."
                ),
            )
        object.__setattr__(self, "metadata", _normalize_context(self.metadata))

    @classmethod
    def initial(cls) -> StateProvenance:
        """Return provenance for a caller-created initial state."""
        return cls(producer="SimulationState.initial")

    def to_dict(self) -> dict[str, object]:
        """Return a deterministic JSON-compatible lineage summary."""
        return {
            "producer": self.producer,
            "parent_state_id": self.parent_state_id,
            "parent_state_hash": self.parent_state_hash,
            "source_hash": self.source_hash,
            "step_index": self.step_index,
            "metadata": dict(self.metadata),
        }


@dataclass(frozen=True)
class SimulationState:
    """Normalized executable state-vector with explicit logical semantics."""

    state_id: str
    amplitudes: tuple[complex, ...]
    logical_order: tuple[str, ...]
    basis: SimulationBasis = "logical_two_level"
    logical_time: float = 0.0
    time_unit: str = "us"
    noise_context: ContextItems = ()
    rng_state: tuple[int, ...] | None = None
    provenance: StateProvenance = field(default_factory=StateProvenance.initial)

    def __post_init__(self) -> None:
        state_id = str(self.state_id)
        if not state_id.strip():
            _raise_state_error(
                "Simulation state_id must not be empty.",
                code="SIMULATION_STATE_ID_EMPTY",
                object_path="simulation_state.state_id",
                suggestion="Pass a stable state id such as 'state.initial'.",
            )
        object.__setattr__(self, "state_id", state_id)

        logical_order = tuple(str(item) for item in self.logical_order)
        if not logical_order or any(not item for item in logical_order):
            _raise_state_error(
                "Simulation state logical_order must contain logical ids.",
                code="SIMULATION_STATE_LOGICAL_ORDER_EMPTY",
                object_path="simulation_state.logical_order",
                suggestion="Declare at least one non-empty logical qubit or atom id.",
            )
        if len(set(logical_order)) != len(logical_order):
            _raise_state_error(
                "Simulation state logical_order ids must be unique.",
                code="SIMULATION_STATE_LOGICAL_ORDER_DUPLICATE",
                object_path="simulation_state.logical_order",
                suggestion="List each logical qubit or atom id exactly once.",
            )
        object.__setattr__(self, "logical_order", logical_order)

        try:
            amplitudes = tuple(complex(value) for value in self.amplitudes)
        except (TypeError, ValueError) as exc:
            _raise_state_error(
                "Simulation amplitudes must contain complex-compatible values.",
                code="SIMULATION_STATE_AMPLITUDE_INVALID",
                object_path="simulation_state.amplitudes",
                suggestion="Pass one finite complex amplitude per basis state.",
                metadata={"cause": type(exc).__name__},
            )
        expected_dimension = 2 ** len(logical_order)
        if len(amplitudes) != expected_dimension:
            _raise_state_error(
                "Simulation state dimension does not match logical_order.",
                code="SIMULATION_STATE_DIMENSION_MISMATCH",
                object_path="simulation_state.amplitudes",
                suggestion=(
                    f"Pass exactly {expected_dimension} amplitudes for "
                    f"{len(logical_order)} logical ids."
                ),
                metadata={
                    "actual_dimension": len(amplitudes),
                    "expected_dimension": expected_dimension,
                },
            )
        if any(
            not math.isfinite(value.real) or not math.isfinite(value.imag)
            for value in amplitudes
        ):
            _raise_state_error(
                "Simulation state amplitudes must be finite.",
                code="SIMULATION_STATE_AMPLITUDE_NONFINITE",
                object_path="simulation_state.amplitudes",
                suggestion="Remove NaN or infinite amplitude values.",
            )
        object.__setattr__(self, "amplitudes", amplitudes)

        norm = math.sqrt(sum(abs(value) ** 2 for value in amplitudes))
        if not math.isclose(
            norm,
            1.0,
            rel_tol=0.0,
            abs_tol=_NORMALIZATION_TOLERANCE,
        ):
            _raise_state_error(
                "Simulation state amplitudes must be normalized.",
                code="SIMULATION_STATE_NORM_INVALID",
                object_path="simulation_state.amplitudes",
                suggestion="Normalize the state vector before constructing the state.",
                metadata={"norm": norm},
            )

        if self.basis != "logical_two_level":
            _raise_state_error(
                f"Unsupported simulation basis: {self.basis!r}.",
                code="SIMULATION_STATE_BASIS_UNSUPPORTED",
                object_path="simulation_state.basis",
                suggestion="Use the P0 'logical_two_level' basis.",
                metadata={"basis": str(self.basis)},
            )
        if not math.isfinite(self.logical_time) or self.logical_time < 0.0:
            _raise_state_error(
                "Simulation logical_time must be finite and non-negative.",
                code="SIMULATION_STATE_LOGICAL_TIME_INVALID",
                object_path="simulation_state.logical_time",
                suggestion="Use zero for an initial state or a positive elapsed time.",
            )
        object.__setattr__(self, "logical_time", float(self.logical_time))
        if not self.time_unit.strip():
            _raise_state_error(
                "Simulation time_unit must not be empty.",
                code="SIMULATION_STATE_TIME_UNIT_EMPTY",
                object_path="simulation_state.time_unit",
                suggestion="Use an explicit unit such as 'us'.",
            )
        object.__setattr__(
            self,
            "noise_context",
            _normalize_context(self.noise_context),
        )
        if self.rng_state is not None:
            rng_state = tuple(self.rng_state)
            if any(not isinstance(value, int) for value in rng_state):
                _raise_state_error(
                    "Simulation rng_state values must be integers.",
                    code="SIMULATION_STATE_RNG_STATE_INVALID",
                    object_path="simulation_state.rng_state",
                    suggestion="Pass an integer tuple or omit rng_state.",
                )
            object.__setattr__(self, "rng_state", rng_state)
        if not isinstance(self.provenance, StateProvenance):
            raise TypeError("provenance must be StateProvenance.")

    @classmethod
    def zero(
        cls,
        logical_order: Sequence[str],
        *,
        state_id: str = "state.initial",
        logical_time: float = 0.0,
        time_unit: str = "us",
        noise_context: ContextInput = (),
        rng_state: tuple[int, ...] | None = None,
    ) -> SimulationState:
        """Create the normalized all-zero logical state."""
        order = tuple(logical_order)
        dimension = 2 ** len(order)
        amplitudes = (1.0 + 0.0j, *(0j for _ in range(max(0, dimension - 1))))
        return cls(
            state_id=state_id,
            amplitudes=amplitudes,
            logical_order=order,
            logical_time=logical_time,
            time_unit=time_unit,
            noise_context=_normalize_context(noise_context),
            rng_state=rng_state,
        )

    @classmethod
    def from_amplitudes(
        cls,
        amplitudes: Sequence[complex],
        *,
        logical_order: Sequence[str],
        state_id: str,
        basis: SimulationBasis = "logical_two_level",
        logical_time: float = 0.0,
        time_unit: str = "us",
        noise_context: ContextInput = (),
        rng_state: tuple[int, ...] | None = None,
        provenance: StateProvenance | None = None,
    ) -> SimulationState:
        """Create an executable state from caller-provided amplitudes."""
        return cls(
            state_id=state_id,
            amplitudes=tuple(amplitudes),
            logical_order=tuple(logical_order),
            basis=basis,
            logical_time=logical_time,
            time_unit=time_unit,
            noise_context=_normalize_context(noise_context),
            rng_state=rng_state,
            provenance=(
                StateProvenance.initial() if provenance is None else provenance
            ),
        )

    @property
    def norm(self) -> float:
        """Return the Euclidean norm of the state vector."""
        return math.sqrt(sum(abs(value) ** 2 for value in self.amplitudes))

    @property
    def dimension(self) -> int:
        """Return the Hilbert-space dimension."""
        return len(self.amplitudes)

    def context_dict(self) -> dict[str, ContextScalar]:
        """Return a caller-owned copy of the immutable noise context."""
        return dict(self.noise_context)

    def probabilities(self) -> dict[str, float]:
        """Return computational-basis probabilities in logical_order."""
        width = len(self.logical_order)
        return {
            format(index, f"0{width}b"): abs(amplitude) ** 2
            for index, amplitude in enumerate(self.amplitudes)
        }

    def amplitude_hash(self) -> str:
        """Return a deterministic hash of physical state content and ordering."""
        return _hash_payload(
            {
                "amplitudes": _amplitude_payload(self.amplitudes),
                "basis": self.basis,
                "logical_order": list(self.logical_order),
            }
        )

    def stable_hash(self) -> str:
        """Return a deterministic semantic state hash excluding state_id."""
        return _hash_payload(
            {
                "amplitude_hash": self.amplitude_hash(),
                "basis": self.basis,
                "logical_order": list(self.logical_order),
                "logical_time": self.logical_time.hex(),
                "time_unit": self.time_unit,
                "noise_context": dict(self.noise_context),
                "rng_state": self.rng_state,
                "provenance": {
                    "producer": self.provenance.producer,
                    "parent_state_hash": self.provenance.parent_state_hash,
                    "source_hash": self.provenance.source_hash,
                    "step_index": self.provenance.step_index,
                    "metadata": dict(self.provenance.metadata),
                },
            }
        )

    def transitioned(
        self,
        amplitudes: Sequence[complex],
        *,
        producer: str,
        source_hash: str | None = None,
        elapsed_time: float = 0.0,
        state_id: str | None = None,
        noise_context: ContextInput | None = None,
        provenance_metadata: ContextInput = (),
    ) -> SimulationState:
        """Return a new state in the same basis and logical ordering."""
        if not math.isfinite(elapsed_time) or elapsed_time < 0.0:
            _raise_state_error(
                "Simulation elapsed_time must be finite and non-negative.",
                code="SIMULATION_STATE_ELAPSED_TIME_INVALID",
                object_path="simulation_state.transition.elapsed_time",
                suggestion="Pass the non-negative duration consumed by the kernel.",
            )
        step_index = self.provenance.step_index + 1
        return SimulationState.from_amplitudes(
            amplitudes,
            logical_order=self.logical_order,
            state_id=(state_id or f"{self.state_id}.step.{step_index}"),
            basis=self.basis,
            logical_time=self.logical_time + elapsed_time,
            time_unit=self.time_unit,
            noise_context=(
                self.noise_context if noise_context is None else noise_context
            ),
            rng_state=self.rng_state,
            provenance=StateProvenance(
                producer=producer,
                parent_state_id=self.state_id,
                parent_state_hash=self.stable_hash(),
                source_hash=source_hash,
                step_index=step_index,
                metadata=_normalize_context(provenance_metadata),
            ),
        )

    def permute(
        self,
        logical_order: Sequence[str],
        *,
        state_id: str | None = None,
    ) -> SimulationState:
        """Return the same state represented in a new explicit logical order."""
        new_order = tuple(str(item) for item in logical_order)
        if len(new_order) != len(self.logical_order) or set(new_order) != set(
            self.logical_order
        ):
            _raise_state_error(
                "State permutation must contain the same logical ids.",
                code="SIMULATION_STATE_PERMUTATION_MISMATCH",
                object_path="simulation_state.logical_order",
                suggestion="Reorder every current logical id exactly once.",
                metadata={
                    "current_order": list(self.logical_order),
                    "requested_order": list(new_order),
                },
            )
        width = len(self.logical_order)
        output = [0j] * self.dimension
        for old_index, amplitude in enumerate(self.amplitudes):
            old_bits = format(old_index, f"0{width}b")
            bit_by_id = dict(zip(self.logical_order, old_bits))
            new_bits = "".join(bit_by_id[item] for item in new_order)
            output[int(new_bits, 2)] = amplitude
        step_index = self.provenance.step_index + 1
        return SimulationState.from_amplitudes(
            output,
            logical_order=new_order,
            state_id=(state_id or f"{self.state_id}.permute.{step_index}"),
            basis=self.basis,
            logical_time=self.logical_time,
            time_unit=self.time_unit,
            noise_context=self.noise_context,
            rng_state=self.rng_state,
            provenance=StateProvenance(
                producer="SimulationState.permute",
                parent_state_id=self.state_id,
                parent_state_hash=self.stable_hash(),
                step_index=step_index,
                metadata=_normalize_context(
                    {
                        "from_order": ",".join(self.logical_order),
                        "to_order": ",".join(new_order),
                    }
                ),
            ),
        )

    def to_summary(self) -> SimulationStateIR:
        """Project the executable state to metadata without amplitudes."""
        return build_state_vector_metadata_summary(
            state_id=self.state_id,
            basis=self.basis,
            dimension=self.dimension,
            norm=self.norm,
            qubit_order=self.logical_order,
            returned_state_bytes=False,
            truncated=False,
            metadata={
                "executable_state": True,
                "state_hash": self.stable_hash(),
                "amplitude_hash": self.amplitude_hash(),
                "logical_time": self.logical_time,
                "time_unit": self.time_unit,
                "noise_context": dict(self.noise_context),
                "provenance": self.provenance.to_dict(),
                "state_bytes_returned": False,
            },
        )


def _normalize_context(value: ContextInput) -> ContextItems:
    raw_items = value.items() if isinstance(value, Mapping) else value
    normalized: list[tuple[str, ContextScalar]] = []
    seen: set[str] = set()
    for raw_key, raw_value in raw_items:
        key = str(raw_key)
        if not key or key in seen:
            _raise_state_error(
                "Simulation context keys must be non-empty and unique.",
                code="SIMULATION_STATE_CONTEXT_KEY_INVALID",
                object_path="simulation_state.noise_context",
                suggestion="Use one non-empty value for each context key.",
            )
        if not isinstance(raw_value, (str, bool, int, float, type(None))):
            _raise_state_error(
                "Simulation context values must be JSON scalar values.",
                code="SIMULATION_STATE_CONTEXT_VALUE_INVALID",
                object_path=f"simulation_state.noise_context.{key}",
                suggestion="Use a string, bool, integer, finite float, or null.",
            )
        if isinstance(raw_value, float) and not math.isfinite(raw_value):
            _raise_state_error(
                "Simulation context float values must be finite.",
                code="SIMULATION_STATE_CONTEXT_VALUE_INVALID",
                object_path=f"simulation_state.noise_context.{key}",
                suggestion="Replace NaN or infinite context values.",
            )
        seen.add(key)
        normalized.append((key, raw_value))
    return tuple(sorted(normalized, key=lambda item: item[0]))


def _amplitude_payload(amplitudes: tuple[complex, ...]) -> list[list[str]]:
    return [[value.real.hex(), value.imag.hex()] for value in amplitudes]


def _hash_payload(payload: dict[str, object]) -> str:
    return hashlib.sha256(stable_json(payload).encode("utf-8")).hexdigest()


def _raise_state_error(
    message: str,
    *,
    code: str,
    object_path: str,
    suggestion: str,
    metadata: dict[str, object] | None = None,
) -> None:
    raise ProgramValidationError(
        message,
        code=code,
        stage="simulation",
        object_path=object_path,
        suggestion=suggestion,
        metadata={
            "reason_category": "simulation_state",
            **({} if metadata is None else metadata),
        },
    )
