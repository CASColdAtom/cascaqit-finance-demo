"""Small-scale local simulator for MVP analog AHS programs."""

from __future__ import annotations

import json
import math
import random
from collections import Counter
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Literal, Protocol

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.exceptions import ProgramValidationError
from cascaqit.native_ir.base import stable_json
from cascaqit.native_ir.models import (
    ANALOG_BIT_ORDER_CONVENTION,
    ProgramIR,
    SimulatorConfigIR,
    WaveformIR,
)
from cascaqit.results import (
    ResultIR,
    ResultReferencesIR,
    RunTraceEventIR,
    RunTraceIR,
    SimulationSolverEvidenceIR,
)
from cascaqit.simulators.adaptive import fixed_step_solver_evidence
from cascaqit.simulators.addressing import site_addressing_provenance_metadata
from cascaqit.simulators.diagnostics import build_diagnostics_summary
from cascaqit.simulators.execution_evidence import solver_evidence_metadata
from cascaqit.simulators.local_rabi import (
    sample_local_rabi_fields,
    site_phase_pattern_provenance_metadata,
)
from cascaqit.simulators.models import (
    SimulationAlgorithmIR,
    build_probability_state_summary,
    build_sample_state_summary,
    select_simulation_algorithm,
)
from cascaqit.simulators.runtime_lineage import (
    build_runtime_references,
    build_runtime_trace,
    build_state_transition,
    runtime_lineage_metadata,
)
from cascaqit.simulators.state import SimulationState
from cascaqit.simulators.waveform_sampling import sample_waveform as _sample_waveform
from cascaqit.targets import MockNeutralAtomTarget, TargetSnapshot, TargetSpec
from cascaqit.validation import validate_program

__all__ = ["AnalogStateVectorKernel", "LocalAhsSimulator"]


class _ProgramLike(Protocol):
    """Protocol for wrappers exposing ProgramIR."""

    @property
    def program_ir(self) -> ProgramIR:
        """Return wrapped ProgramIR."""


class _BuilderLike(Protocol):
    """Protocol for builders exposing to_ir()."""

    def to_ir(self) -> ProgramIR:
        """Build and return ProgramIR."""


@dataclass(frozen=True)
class AnalogStateVectorKernel:
    """Evolve an explicit shared state through a global AHS program."""

    blockade_radius: float = 0.0
    steps: int = 400
    max_hilbert_dim: int = 2**16

    def evolve(
        self,
        program: ProgramIR,
        initial_state: SimulationState,
    ) -> SimulationState:
        """Return a new executable state after RK4 Hamiltonian evolution."""
        if not isinstance(program, ProgramIR):
            raise TypeError("AnalogStateVectorKernel accepts ProgramIR.")
        if not isinstance(initial_state, SimulationState):
            raise TypeError("AnalogStateVectorKernel accepts SimulationState.")
        _validate_local_detuning_kernel_contract(program)
        _validate_local_rabi_kernel_contract(program)
        if initial_state.basis != "logical_two_level":
            _raise_analog_state_error(
                "Analog state kernel requires the logical two-level basis.",
                code="ANALOG_STATE_BASIS_UNSUPPORTED",
                object_path="simulation_state.basis",
                suggestion="Convert the state to the P0 logical_two_level basis.",
                metadata={"basis": str(initial_state.basis)},
            )
        atom_order = _atom_order(program)
        if initial_state.logical_order != atom_order:
            _raise_analog_state_error(
                "AHS register atoms must match the state logical order.",
                code="ANALOG_STATE_LOGICAL_ORDER_MISMATCH",
                object_path="simulation_state.logical_order",
                suggestion=(
                    "Apply an explicit SimulationState.permute() before evolution."
                ),
                metadata={
                    "program_order": list(atom_order),
                    "state_order": list(initial_state.logical_order),
                },
            )
        expected_dimension = 2 ** len(atom_order)
        if initial_state.dimension != expected_dimension:
            _raise_analog_state_error(
                "Simulation state dimension does not match the AHS register.",
                code="ANALOG_STATE_DIMENSION_MISMATCH",
                object_path="simulation_state.amplitudes",
                suggestion="Pass one amplitude for every AHS register basis state.",
                metadata={
                    "actual_dimension": initial_state.dimension,
                    "expected_dimension": expected_dimension,
                },
            )
        time_units = {
            program.hamiltonian.rabi.time_unit,
            program.hamiltonian.detuning.time_unit,
        }
        if isinstance(program.hamiltonian.phase, WaveformIR):
            time_units.add(program.hamiltonian.phase.time_unit)
        time_units.update(
            term.waveform.time_unit for term in program.hamiltonian.local_detuning_terms
        )
        for term in program.hamiltonian.local_rabi_terms:
            time_units.add(term.rabi.time_unit)
            if isinstance(term.phase, WaveformIR):
                time_units.add(term.phase.time_unit)
        if time_units != {initial_state.time_unit}:
            _raise_analog_state_error(
                "AHS waveform and simulation state time units must match.",
                code="ANALOG_STATE_TIME_UNIT_MISMATCH",
                object_path="simulation_state.time_unit",
                suggestion="Use one explicit time unit across state and waveforms.",
                metadata={
                    "state_time_unit": initial_state.time_unit,
                    "waveform_time_units": sorted(time_units),
                },
            )
        if expected_dimension > self.max_hilbert_dim:
            _raise_analog_state_error(
                (
                    f"Program Hilbert dimension {expected_dimension} exceeds "
                    f"configured maximum {self.max_hilbert_dim}."
                ),
                code="ANALOG_STATE_HILBERT_DIMENSION_EXCEEDED",
                object_path="analog_program.register",
                suggestion="Reduce the register size or raise max_hilbert_dim.",
                metadata={
                    "actual_dimension": expected_dimension,
                    "max_hilbert_dim": self.max_hilbert_dim,
                },
            )
        if len(atom_order) > 4:
            _raise_analog_state_error(
                "LocalAhsSimulator MVP supports at most 4 atoms.",
                code="ANALOG_STATE_ATOM_LIMIT_EXCEEDED",
                object_path="analog_program.register",
                suggestion="Reduce the active register to at most four atoms.",
                metadata={"atom_count": len(atom_order), "max_atoms": 4},
            )
        if self.steps <= 0:
            _raise_analog_state_error(
                "Analog state kernel time steps must be positive.",
                code="ANALOG_STATE_TIME_STEPS_INVALID",
                object_path="analog_state_kernel.steps",
                suggestion="Configure at least one RK4 time step.",
                metadata={"steps": self.steps},
            )

        amplitudes = list(initial_state.amplitudes)
        duration = _duration(program)
        if duration > 0.0:
            dt = duration / self.steps
            for step in range(self.steps):
                time = (step + 0.5) * dt
                amplitudes = _rk4_step(
                    amplitudes,
                    dt,
                    program=program,
                    time=time,
                    blockade_radius=self.blockade_radius,
                )
                amplitudes = _normalize(amplitudes)
        evidence = fixed_step_solver_evidence(
            integrator_requested="fixed_step_krylov",
            steps=self.steps,
            duration=duration,
            logical_time_offset=initial_state.logical_time,
            time_unit=initial_state.time_unit,
            algorithm="reference_rk4",
        )
        return initial_state.transitioned(
            amplitudes,
            producer="AnalogStateVectorKernel",
            source_hash=program.stable_hash(),
            elapsed_time=duration,
            state_id=f"state.{program.program_id}.analog",
            provenance_metadata={
                "blockade_radius": self.blockade_radius,
                "time_steps": self.steps,
                "solver_evidence_json": stable_json(evidence.to_dict()),
            },
        )


@dataclass(frozen=True)
class LocalAhsSimulator:
    """Small exact-state simulator for MVP global Rydberg AHS programs."""

    target: TargetSpec | None = None
    seed: int | None = None
    time_steps: int = 400
    created_at: str | None = None

    def run(
        self,
        program: ProgramIR | _ProgramLike | _BuilderLike,
        *,
        shots: int = 1000,
        config: SimulatorConfigIR | None = None,
    ) -> ResultIR:
        """Run a small AHS program and return ResultIR."""
        program_ir = _as_program_ir(program)
        simulator_config = _effective_config(
            config,
            default_shots=shots,
            default_seed=self.seed,
        )
        run_shots = simulator_config.shots
        run_seed = simulator_config.seed
        target = self.target or (
            MockNeutralAtomTarget.local_ahs_v0_1()
            if (
                program_ir.hamiltonian.local_detuning_terms
                or program_ir.hamiltonian.local_rabi_terms
            )
            else MockNeutralAtomTarget.v0_1()
        )
        target_snapshot = target.to_snapshot(source="local_simulator")
        references = _result_references(
            program_ir=program_ir,
            target_snapshot=target_snapshot,
        )
        atom_order = _atom_order(program_ir)
        hilbert_dimension = _hilbert_dimension(program_ir)
        algorithm = select_simulation_algorithm(
            simulator_name="LocalAhsSimulator",
            program_type="analog",
            requested_method=simulator_config.method,
            hilbert_dimension=hilbert_dimension,
            max_hilbert_dim=simulator_config.max_hilbert_dim,
            seed=run_seed,
            parameters={
                "time_steps": self.time_steps,
                "tolerance": simulator_config.tolerance,
                "return_probabilities": simulator_config.return_probabilities,
            },
        )
        input_diagnostics = validate_program(program_ir, target, shots=run_shots or 1)
        if any(diagnostic.severity == "error" for diagnostic in input_diagnostics):
            return _empty_invalid_result(
                program_ir,
                target,
                target_snapshot=target_snapshot,
                references=references,
                shots=run_shots,
                seed=run_seed,
                time_steps=self.time_steps,
                created_at=self.created_at,
                config=simulator_config,
                algorithm=algorithm,
                diagnostics=input_diagnostics,
            )
        final_state: SimulationState | None = None
        if atom_order:
            initial_state = SimulationState.zero(
                atom_order,
                state_id=f"state.{program_ir.program_id}.initial",
                time_unit=program_ir.hamiltonian.rabi.time_unit,
            )
            final_state = AnalogStateVectorKernel(
                blockade_radius=float(target.metadata.get("blockade_radius", 0.0)),
                steps=self.time_steps,
                max_hilbert_dim=simulator_config.max_hilbert_dim,
            ).evolve(program_ir, initial_state)
            probabilities = final_state.probabilities()
        else:
            probabilities = {"": 1.0}
        samples = _sample(probabilities, shots=run_shots, seed=run_seed)
        counts = dict(Counter(samples))
        if run_shots == 0:
            counts = {}
        probability_state = build_probability_state_summary(
            probabilities,
            state_id=f"state.{program_ir.program_id}.probabilities",
            basis="ground_rydberg_occupation",
            atom_order=atom_order,
            metadata={
                "source": "LocalAhsSimulator",
                "returned_inline": simulator_config.return_probabilities,
            },
        )
        sample_state = build_sample_state_summary(
            samples,
            state_id=f"state.{program_ir.program_id}.samples",
            basis="ground_rydberg_occupation",
            atom_order=atom_order,
            metadata={"source": "LocalAhsSimulator"},
        )
        completed_diagnostic = DiagnosticsIR(
            diagnostic_id="simulation.completed",
            stage="simulation",
            severity="info",
            code="SIMULATION_COMPLETED",
            message="Local AHS simulation completed.",
            object_path="result",
        )
        runtime_metadata: dict[str, object] = {
            "references": references.to_dict(),
            "run_trace": _run_trace(
                program_id=program_ir.program_id,
                references=references,
                created_at=_created_at(self.created_at),
                completed=True,
            ).to_dict(),
        }
        if final_state is not None:
            raw_evidence = dict(final_state.provenance.metadata).get(
                "solver_evidence_json"
            )
            if not isinstance(raw_evidence, str):
                raise ProgramValidationError(
                    "Local AHS kernel omitted solver evidence.",
                    code="SIMULATION_SOLVER_EVIDENCE_MISSING",
                    stage="simulation",
                    object_path="simulation_state.provenance.solver_evidence_json",
                )
            evidence_data = json.loads(raw_evidence)
            if not isinstance(evidence_data, dict):
                raise ProgramValidationError(
                    "Local AHS solver evidence is not an object.",
                    code="SIMULATION_SOLVER_EVIDENCE_INVALID",
                    stage="simulation",
                    object_path="simulation_state.provenance.solver_evidence_json",
                )
            evidence = SimulationSolverEvidenceIR.from_dict(evidence_data)
            transition = build_state_transition(
                transition_id=f"transition.0.{program_ir.program_id}",
                order_index=0,
                block_id=program_ir.program_id,
                program_kind="analog",
                program_hash=program_ir.stable_hash(),
                kernel=final_state.provenance.producer,
                input_state_hash=initial_state.stable_hash(),
                output_state_hash=final_state.stable_hash(),
                input_logical_time=initial_state.logical_time,
                output_logical_time=final_state.logical_time,
                time_unit=final_state.time_unit,
                solver_evidence=evidence,
                metadata={
                    "input_state_id": initial_state.state_id,
                    "output_state_id": final_state.state_id,
                    "logical_order": list(final_state.logical_order),
                    **site_addressing_provenance_metadata(
                        program_ir,
                        consumer=final_state.provenance.producer,
                    ),
                    **site_phase_pattern_provenance_metadata(
                        program_ir,
                        consumer=final_state.provenance.producer,
                    ),
                },
            )
            references = build_runtime_references(
                program_hash=program_ir.stable_hash(),
                target_snapshot_hash=target_snapshot.target_snapshot_hash,
                initial_state_hash=initial_state.stable_hash(),
                final_state_hash=final_state.stable_hash(),
            )
            trace = build_runtime_trace(
                trace_id=f"trace.{program_ir.program_id}.local_analog",
                transitions=(transition,),
                references=references,
                execution_mode="standalone_analog",
                terminal_message="Terminal Analog sampling completed.",
                terminal_metadata={"shots": run_shots, "seed": run_seed},
            )
            runtime_metadata = {
                **solver_evidence_metadata(evidence),
                **runtime_lineage_metadata(
                    transitions=(transition,),
                    references=references,
                    trace=trace,
                ),
                "state_hash": final_state.stable_hash(),
            }

        return ResultIR(
            result_id=f"result.{program_ir.program_id}",
            program_hash=references.program_hash,
            target_id=target.target_id,
            shots=run_shots,
            counts=counts,
            samples=samples,
            probabilities=(
                probabilities if simulator_config.return_probabilities else None
            ),
            observables=_observables(
                probabilities,
                program_ir=program_ir,
                target=target,
                selected=simulator_config.observables,
            ),
            bit_ordering={
                "convention": program_ir.bit_ordering.get(
                    "convention", ANALOG_BIT_ORDER_CONVENTION
                ),
                "atom_order": ",".join(atom_order),
            },
            diagnostics=(completed_diagnostic,),
            metadata={
                "created_at": _created_at(self.created_at),
                "seed": run_seed,
                **runtime_metadata,
                "simulator": {
                    "method": "exact_state_rk4",
                    "time_steps": self.time_steps,
                    "config": simulator_config.to_dict(),
                },
                "diagnostics_summary": _diagnostics_summary((completed_diagnostic,)),
                "simulation_algorithm": algorithm.to_dict(),
                "simulation_state": {
                    "primary": probability_state.to_dict(),
                    "samples": sample_state.to_dict(),
                    "state_bytes_returned": False,
                    "physical_accuracy": "small_exact_state_baseline",
                },
                "target_snapshot": _target_snapshot_metadata(target_snapshot),
                "register_snapshot": program_ir.register.snapshot_evidence(),
            },
        )


def _as_program_ir(program: ProgramIR | _ProgramLike | _BuilderLike) -> ProgramIR:
    if isinstance(program, ProgramIR):
        return program
    if hasattr(program, "program_ir"):
        return program.program_ir
    return program.to_ir()


def _rk4_step(
    state: list[complex],
    dt: float,
    *,
    program: ProgramIR,
    time: float,
    blockade_radius: float,
) -> list[complex]:
    k1 = _derivative(state, program=program, time=time, blockade_radius=blockade_radius)
    k2 = _derivative(
        _add_scaled(state, k1, dt / 2.0),
        program=program,
        time=time,
        blockade_radius=blockade_radius,
    )
    k3 = _derivative(
        _add_scaled(state, k2, dt / 2.0),
        program=program,
        time=time,
        blockade_radius=blockade_radius,
    )
    k4 = _derivative(
        _add_scaled(state, k3, dt),
        program=program,
        time=time,
        blockade_radius=blockade_radius,
    )
    return [
        amplitude + dt * (a + 2.0 * b + 2.0 * c + d) / 6.0
        for amplitude, a, b, c, d in zip(state, k1, k2, k3, k4)
    ]


def _derivative(
    state: list[complex],
    *,
    program: ProgramIR,
    time: float,
    blockade_radius: float,
) -> list[complex]:
    h_state = _hamiltonian_apply(
        state,
        program=program,
        time=time,
        blockade_radius=blockade_radius,
    )
    return [-1j * value for value in h_state]


def _hamiltonian_apply(
    state: list[complex],
    *,
    program: ProgramIR,
    time: float,
    blockade_radius: float,
) -> list[complex]:
    atom_count = int(math.log2(len(state)))
    rabi = _sample_waveform(program.hamiltonian.rabi, time)
    detuning = _sample_waveform(program.hamiltonian.detuning, time)
    phase = (
        _sample_waveform(program.hamiltonian.phase, time)
        if isinstance(program.hamiltonian.phase, WaveformIR)
        else program.hamiltonian.phase
    )
    local_detuning_fields = tuple(
        (_sample_waveform(term.waveform, time), term.addressing.weights_at(time))
        for term in program.hamiltonian.local_detuning_terms
    )
    local_rabi_fields = sample_local_rabi_fields(program, time)
    output = [0j] * len(state)

    interactions = _interaction_pairs(program, atom_count, blockade_radius)
    for basis_index, amplitude in enumerate(state):
        excitation_count = bin(basis_index).count("1")
        diagonal = -detuning * excitation_count
        for local_value, weights in local_detuning_fields:
            diagonal -= local_value * sum(
                weights[atom_index]
                for atom_index in range(atom_count)
                if _occupied(basis_index, atom_index, atom_count)
            )
        for left, right, strength in interactions:
            if _occupied(basis_index, left, atom_count) and _occupied(
                basis_index,
                right,
                atom_count,
            ):
                diagonal += strength
        output[basis_index] += diagonal * amplitude

        for atom_index in range(atom_count):
            flipped = basis_index ^ (1 << (atom_count - atom_index - 1))
            # This sign is selected from the source state, matching
            # exp(-i*phase)|g><r| + h.c. for both global and local drives.
            phase_sign = -1.0 if _occupied(basis_index, atom_index, atom_count) else 1.0
            global_drive = rabi * complex(
                math.cos(phase),
                phase_sign * math.sin(phase),
            )
            addressed_drive = 0.0j
            # Add coherent addressed fields before applying the 1/2 factor.
            for local_rabi_value, local_phases, weights in local_rabi_fields:
                local_phase = local_phases[atom_index]
                addressed_drive += (
                    local_rabi_value
                    * weights[atom_index]
                    * complex(
                        math.cos(local_phase),
                        phase_sign * math.sin(local_phase),
                    )
                )
            output[flipped] += 0.5 * (global_drive + addressed_drive) * amplitude
    return output


def _interaction_pairs(
    program: ProgramIR,
    atom_count: int,
    blockade_radius: float,
) -> tuple[tuple[int, int, float], ...]:
    sites = tuple(site for site in program.register.sites if site.is_active)
    pairs: list[tuple[int, int, float]] = []
    for left in range(atom_count):
        for right in range(left + 1, atom_count):
            distance = math.dist(sites[left].position, sites[right].position)
            if distance <= 0.0:
                strength = 1e6
            elif distance < blockade_radius:
                strength = (blockade_radius / distance) ** 6 * math.pi
            else:
                strength = 0.0
            if strength:
                pairs.append((left, right, strength))
    return tuple(pairs)


def _duration(program: ProgramIR) -> float:
    waveforms = [program.hamiltonian.rabi, program.hamiltonian.detuning]
    waveforms.extend(term.waveform for term in program.hamiltonian.local_detuning_terms)
    for term in program.hamiltonian.local_rabi_terms:
        waveforms.append(term.rabi)
        if isinstance(term.phase, WaveformIR):
            waveforms.append(term.phase)
    return max(waveform.duration for waveform in waveforms)


def _global_duration(program: ProgramIR) -> float:
    return max(program.hamiltonian.rabi.duration, program.hamiltonian.detuning.duration)


def _validate_local_detuning_kernel_contract(program: ProgramIR) -> None:
    global_duration = _global_duration(program)
    active_site_ids = program.register.active_site_ids
    for index, term in enumerate(program.hamiltonian.local_detuning_terms):
        path = f"analog_program.hamiltonian.local_detuning_terms[{index}]"
        if term.waveform.duration != global_duration:
            _raise_analog_state_error(
                "Local detuning duration must match the global program duration.",
                code="ANALOG_STATE_LOCAL_DURATION_MISMATCH",
                object_path=f"{path}.waveform.duration",
                suggestion="Use one duration for the global and local controls.",
                metadata={
                    "global_duration": global_duration,
                    "local_duration": term.waveform.duration,
                },
            )
        if term.addressing.site_ids != active_site_ids:
            _raise_analog_state_error(
                "Local detuning pattern order must match active register order.",
                code="ANALOG_STATE_LOCAL_PATTERN_ORDER_MISMATCH",
                object_path=f"{path}.addressing.site_ids",
                suggestion="Project the site pattern through AHSProgram.",
                metadata={
                    "active_site_ids": list(active_site_ids),
                    "addressing_site_ids": list(term.addressing.site_ids),
                },
            )


def _validate_local_rabi_kernel_contract(program: ProgramIR) -> None:
    global_duration = _global_duration(program)
    active_site_ids = program.register.active_site_ids
    for index, term in enumerate(program.hamiltonian.local_rabi_terms):
        path = f"analog_program.hamiltonian.local_rabi_terms[{index}]"
        if term.rabi.duration != global_duration:
            _raise_analog_state_error(
                "Local Rabi duration must match the global program duration.",
                code="ANALOG_STATE_LOCAL_RABI_DURATION_MISMATCH",
                object_path=f"{path}.rabi.duration",
                suggestion="Use one duration for global and local controls.",
            )
        if term.addressing.site_ids != active_site_ids:
            _raise_analog_state_error(
                "Local Rabi pattern order must match active register order.",
                code="ANALOG_STATE_LOCAL_RABI_PATTERN_ORDER_MISMATCH",
                object_path=f"{path}.addressing.site_ids",
                suggestion="Project the site pattern through AHSProgram.",
            )
        if term.phase_pattern.site_ids != active_site_ids:
            _raise_analog_state_error(
                "Local Rabi phase pattern order must match active register order.",
                code="ANALOG_STATE_LOCAL_RABI_PHASE_PATTERN_ORDER_MISMATCH",
                object_path=f"{path}.phase_pattern.site_ids",
                suggestion="Project the phase pattern through AHSProgram.",
            )


def _atom_order(program: ProgramIR) -> tuple[str, ...]:
    return tuple(str(site.atom_id) for site in program.register.sites if site.is_active)


def _hilbert_dimension(program: ProgramIR) -> int:
    return int(2 ** len(_atom_order(program)))


def _sample(
    probabilities: dict[str, float],
    *,
    shots: int,
    seed: int | None,
) -> tuple[str, ...]:
    if shots <= 0:
        return ()
    rng = random.Random(seed)
    outcomes = tuple(sorted(probabilities))
    weights = tuple(probabilities[outcome] for outcome in outcomes)
    return tuple(rng.choices(outcomes, weights=weights, k=shots))


def _observables(
    probabilities: dict[str, float],
    *,
    program_ir: ProgramIR,
    target: TargetSpec,
    selected: tuple[str, ...] = (),
) -> dict[str, float | dict[str, float]]:
    if not probabilities:
        return {"mean_excitation": 0.0, "occupation": {}, "energy": 0.0}
    atom_count = len(next(iter(probabilities)))
    occupation = _occupation(probabilities, atom_count)
    mean = sum(occupation.values())
    all_observables: dict[str, float | dict[str, float]] = {
        "correlation_z": _zz_correlation(probabilities, atom_count),
        "energy": _expected_energy(
            probabilities,
            program_ir=program_ir,
            target=target,
        ),
        "mean_excitation": mean / atom_count if atom_count else 0.0,
        "occupation": occupation,
    }
    if not selected:
        return all_observables
    return {name: all_observables[name] for name in selected if name in all_observables}


def _occupation(probabilities: dict[str, float], atom_count: int) -> dict[str, float]:
    occupation = {f"q{index}": 0.0 for index in range(atom_count)}
    for bits, probability in probabilities.items():
        for index, bit in enumerate(bits):
            if bit == "1":
                occupation[f"q{index}"] += probability
    return occupation


def _zz_correlation(
    probabilities: dict[str, float],
    atom_count: int,
) -> dict[str, float]:
    correlations: dict[str, float] = {}
    for left in range(atom_count):
        for right in range(left + 1, atom_count):
            value = 0.0
            for bits, probability in probabilities.items():
                left_z = 1.0 if bits[left] == "1" else -1.0
                right_z = 1.0 if bits[right] == "1" else -1.0
                value += left_z * right_z * probability
            correlations[f"q{left},q{right}"] = value
    return correlations


def _expected_energy(
    probabilities: dict[str, float],
    *,
    program_ir: ProgramIR,
    target: TargetSpec,
) -> float:
    time = _duration(program_ir)
    detuning = _sample_waveform(program_ir.hamiltonian.detuning, time)
    local_fields = tuple(
        (_sample_waveform(term.waveform, time), term.addressing.weights_at(time))
        for term in program_ir.hamiltonian.local_detuning_terms
    )
    pairs = _interaction_pairs(
        program_ir,
        len(tuple(site for site in program_ir.register.sites if site.is_active)),
        float(target.metadata.get("blockade_radius", 0.0)),
    )
    energy = 0.0
    for bits, probability in probabilities.items():
        diagonal = -detuning * bits.count("1")
        for local_value, weights in local_fields:
            diagonal -= local_value * sum(
                weights[index] for index, bit in enumerate(bits) if bit == "1"
            )
        for left, right, strength in pairs:
            if bits[left] == "1" and bits[right] == "1":
                diagonal += strength
        energy += diagonal * probability
    return energy


def _empty_invalid_result(
    program_ir: ProgramIR,
    target: TargetSpec,
    *,
    target_snapshot: TargetSnapshot,
    references: ResultReferencesIR,
    shots: int,
    seed: int | None,
    time_steps: int,
    created_at: str | None,
    config: SimulatorConfigIR,
    algorithm: SimulationAlgorithmIR,
    diagnostics: tuple[DiagnosticsIR, ...],
) -> ResultIR:
    invalid_diagnostic = DiagnosticsIR(
        diagnostic_id="simulation.input_invalid",
        stage="simulation",
        severity="error",
        code="SIMULATION_INPUT_INVALID",
        message="Simulation input failed target validation.",
        object_path="program",
        suggestion="Inspect validation diagnostics and fix the program.",
    )
    result_diagnostics = (invalid_diagnostic, *diagnostics)
    return ResultIR(
        result_id=f"result.{program_ir.program_id}",
        program_hash=program_ir.stable_hash(),
        target_id=target.target_id,
        shots=shots,
        counts={},
        samples=(),
        probabilities=None,
        observables={},
        bit_ordering={
            "convention": program_ir.bit_ordering.get(
                "convention", ANALOG_BIT_ORDER_CONVENTION
            ),
            "atom_order": ",".join(program_ir.register.active_atom_ids),
        },
        diagnostics=result_diagnostics,
        metadata={
            "created_at": _created_at(created_at),
            "seed": seed,
            "references": references.to_dict(),
            "run_trace": _run_trace(
                program_id=program_ir.program_id,
                references=references,
                created_at=_created_at(created_at),
                completed=False,
            ).to_dict(),
            "simulator": {
                "method": "exact_state_rk4",
                "time_steps": time_steps,
                "config": config.to_dict(),
            },
            "diagnostics_summary": _diagnostics_summary(result_diagnostics),
            "simulation_algorithm": algorithm.to_dict(),
            "simulation_state": {
                "primary": None,
                "samples": None,
                "state_bytes_returned": False,
                "physical_accuracy": "not_computed_input_invalid",
            },
            "target_snapshot": _target_snapshot_metadata(target_snapshot),
            "register_snapshot": program_ir.register.snapshot_evidence(),
        },
    )


def _target_snapshot_metadata(snapshot: TargetSnapshot) -> dict[str, str]:
    """Return compact ResultIR metadata for a target snapshot."""
    return {
        "snapshot_id": snapshot.snapshot_id,
        "target_snapshot_hash": snapshot.target_snapshot_hash,
        "source": snapshot.source,
        "status": snapshot.status,
    }


def _result_references(
    *,
    program_ir: ProgramIR,
    target_snapshot: TargetSnapshot,
) -> ResultReferencesIR:
    """Build the minimal reproducibility references for a local result."""
    return ResultReferencesIR(
        program_hash=program_ir.stable_hash(),
        target_snapshot_hash=target_snapshot.target_snapshot_hash,
    )


def _diagnostics_summary(
    diagnostics: tuple[DiagnosticsIR, ...],
) -> dict[str, object]:
    return build_diagnostics_summary(diagnostics)


def _run_trace(
    *,
    program_id: str,
    references: ResultReferencesIR,
    created_at: str,
    completed: bool,
) -> RunTraceIR:
    """Build a compact local simulator trace."""
    terminal_stage: Literal["completed", "failed"] = (
        "completed" if completed else "failed"
    )
    terminal_status = "ok" if completed else "error"
    return RunTraceIR(
        trace_id=f"trace.{program_id}.local",
        references=references,
        events=(
            RunTraceEventIR(
                stage="running",
                event_time=created_at,
                status="ok",
                message="Local AHS simulation started.",
            ),
            RunTraceEventIR(
                stage=terminal_stage,
                event_time=created_at,
                status=terminal_status,
                message=(
                    "Local AHS simulation completed."
                    if completed
                    else "Local AHS simulation failed validation."
                ),
            ),
        ),
    )


def _effective_config(
    config: SimulatorConfigIR | None,
    *,
    default_shots: int,
    default_seed: int | None,
) -> SimulatorConfigIR:
    """Return a simulator config while preserving the legacy run API."""
    if config is not None:
        return config
    return SimulatorConfigIR(shots=default_shots, seed=default_seed)


def _created_at(value: str | None) -> str:
    return value if value is not None else datetime.now(timezone.utc).isoformat()


def _occupied(basis_index: int, atom_index: int, atom_count: int) -> bool:
    return bool(basis_index & (1 << (atom_count - atom_index - 1)))


def _add_scaled(
    left: list[complex],
    right: list[complex],
    scale: float,
) -> list[complex]:
    return [
        left_value + scale * right_value for left_value, right_value in zip(left, right)
    ]


def _normalize(state: list[complex]) -> list[complex]:
    norm = math.sqrt(sum(abs(value) ** 2 for value in state))
    return [value / norm for value in state]


def _raise_analog_state_error(
    message: str,
    *,
    code: str,
    object_path: str,
    suggestion: str,
    metadata: dict[str, object] | None = None,
) -> None:
    raise ProgramValidationError(
        message,
        code=code,
        stage="simulation",
        object_path=object_path,
        suggestion=suggestion,
        metadata={
            "reason_category": "analog_state_kernel",
            **({} if metadata is None else metadata),
        },
    )
