"""Register snapshot evidence shared by local simulation result producers."""

from __future__ import annotations

from collections.abc import Iterable
from typing import Any

from cascaqit.native_ir import ProgramIR

__all__ = ["collect_register_snapshot_evidence"]


def collect_register_snapshot_evidence(
    programs: Iterable[ProgramIR],
) -> list[dict[str, Any]]:
    """Return unique register snapshots in first-consumer order."""
    evidence: list[dict[str, Any]] = []
    seen_hashes: set[str] = set()
    for program in programs:
        snapshot = program.register.snapshot_evidence()
        snapshot_hash = str(snapshot["snapshot_hash"])
        if snapshot_hash in seen_hashes:
            continue
        seen_hashes.add(snapshot_hash)
        evidence.append(snapshot)
    return evidence
