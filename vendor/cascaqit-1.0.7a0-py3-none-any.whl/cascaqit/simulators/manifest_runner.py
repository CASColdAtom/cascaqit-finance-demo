"""Local simulation manifest runner and report section contracts."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Literal

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.hybrid import HybridSimulationPlanIR
from cascaqit.native_ir.base import IRMixin
from cascaqit.native_ir.models import SCHEMA_VERSION, SimulatorConfigIR
from cascaqit.results import ResultIR
from cascaqit.simulators.diagnostics import build_diagnostics_summary
from cascaqit.simulators.facade import Simulator
from cascaqit.simulators.models import (
    SimulationManifestIR,
    diagnose_simulation_manifest,
)
from cascaqit.simulators.noise import NoiseModelIR

__all__ = [
    "SimulationManifestRunIR",
    "SimulationReportSectionIR",
    "build_simulation_report_section",
    "run_simulation_manifest",
]

SimulationOutputKind = Literal["result", "hybrid_plan"]


@dataclass(frozen=True)
class SimulationReportSectionIR(IRMixin):
    """Metadata-only report section for one local simulation output."""

    section_id: str
    manifest_id: str
    program_kind: str
    output_kind: SimulationOutputKind
    output_id: str
    output_hash: str
    status: Literal["completed", "planned", "blocked"]
    shots: int
    counts_summary: dict[str, Any]
    probability_summary: dict[str, Any]
    observable_summary: dict[str, Any]
    state_summary: dict[str, Any]
    algorithm_summary: dict[str, Any]
    diagnostics_summary: dict[str, Any]
    noise_summary: dict[str, Any]
    boundary_flags: dict[str, Any]
    metadata_only: bool = True
    validation_rerun: bool = False
    compilation_rerun: bool = False
    backend_called: bool = False
    network_accessed: bool = False
    artifact_bytes_read: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SimulationReportSectionIR:
        """Build a simulation report section from a dictionary."""
        return cls(
            section_id=str(data["section_id"]),
            manifest_id=str(data["manifest_id"]),
            program_kind=str(data["program_kind"]),
            output_kind=data["output_kind"],
            output_id=str(data["output_id"]),
            output_hash=str(data["output_hash"]),
            status=data["status"],
            shots=int(data["shots"]),
            counts_summary=dict(data["counts_summary"]),
            probability_summary=dict(data["probability_summary"]),
            observable_summary=dict(data["observable_summary"]),
            state_summary=dict(data["state_summary"]),
            algorithm_summary=dict(data["algorithm_summary"]),
            diagnostics_summary=dict(data["diagnostics_summary"]),
            noise_summary=dict(data["noise_summary"]),
            boundary_flags=dict(data["boundary_flags"]),
            metadata_only=bool(data.get("metadata_only", True)),
            validation_rerun=bool(data.get("validation_rerun", False)),
            compilation_rerun=bool(data.get("compilation_rerun", False)),
            backend_called=bool(data.get("backend_called", False)),
            network_accessed=bool(data.get("network_accessed", False)),
            artifact_bytes_read=bool(data.get("artifact_bytes_read", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> SimulationReportSectionIR:
        """Build a simulation report section from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("SimulationReportSectionIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class SimulationManifestRunIR(IRMixin):
    """Envelope for one manifest-driven local simulation run."""

    run_id: str
    manifest_id: str
    manifest_hash: str
    output_kind: SimulationOutputKind
    output_id: str
    output_hash: str
    report_section: SimulationReportSectionIR
    manifest_diagnostics: tuple[DiagnosticsIR, ...]
    metadata_only: bool = True
    simulator_called: bool = True
    backend_called: bool = False
    network_accessed: bool = False
    credential_secret_read: bool = False
    artifact_bytes_read: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SimulationManifestRunIR:
        """Build a manifest run envelope from a dictionary."""
        return cls(
            run_id=str(data["run_id"]),
            manifest_id=str(data["manifest_id"]),
            manifest_hash=str(data["manifest_hash"]),
            output_kind=data["output_kind"],
            output_id=str(data["output_id"]),
            output_hash=str(data["output_hash"]),
            report_section=SimulationReportSectionIR.from_dict(
                data["report_section"]
            ),
            manifest_diagnostics=tuple(
                DiagnosticsIR.from_dict(item)
                for item in data.get("manifest_diagnostics", ())
            ),
            metadata_only=bool(data.get("metadata_only", True)),
            simulator_called=bool(data.get("simulator_called", True)),
            backend_called=bool(data.get("backend_called", False)),
            network_accessed=bool(data.get("network_accessed", False)),
            credential_secret_read=bool(data.get("credential_secret_read", False)),
            artifact_bytes_read=bool(data.get("artifact_bytes_read", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> SimulationManifestRunIR:
        """Build a manifest run envelope from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("SimulationManifestRunIR JSON must contain an object.")
        return cls.from_dict(data)


def run_simulation_manifest(
    manifest: SimulationManifestIR,
    program: Any,
    *,
    simulator: Simulator | None = None,
    noise_model: NoiseModelIR | None = None,
    hybrid_plan_only: bool = True,
) -> tuple[ResultIR | HybridSimulationPlanIR, SimulationManifestRunIR]:
    """Run a manifest through the local Simulator and build a report section."""
    manifest_diagnostics = diagnose_simulation_manifest(manifest)
    if any(diagnostic.severity == "error" for diagnostic in manifest_diagnostics):
        raise ValueError("Simulation manifest has blocking diagnostics.")
    local_simulator = simulator or Simulator(seed=manifest.seed)
    config = _config_from_manifest(manifest)
    output = local_simulator.run(
        program,
        shots=manifest.shots,
        config=config,
        noise_model=noise_model,
        noise_mode=manifest.noise_mode,
        hybrid_plan_only=hybrid_plan_only,
    )
    section = build_simulation_report_section(manifest, output)
    run = SimulationManifestRunIR(
        run_id=f"simulation_run.{manifest.manifest_id}",
        manifest_id=manifest.manifest_id,
        manifest_hash=manifest.stable_hash(),
        output_kind=section.output_kind,
        output_id=section.output_id,
        output_hash=section.output_hash,
        report_section=section,
        manifest_diagnostics=manifest_diagnostics,
        metadata_only=True,
        simulator_called=True,
        backend_called=False,
        network_accessed=False,
        credential_secret_read=False,
        artifact_bytes_read=False,
        metadata={
            "runner": "run_simulation_manifest",
            "offline_deterministic": True,
            "hardware_execution": False,
            "cloud_execution": False,
        },
    )
    return output, run


def build_simulation_report_section(
    manifest: SimulationManifestIR,
    output: ResultIR | HybridSimulationPlanIR,
) -> SimulationReportSectionIR:
    """Build a metadata-only report section from an existing simulator output."""
    if isinstance(output, ResultIR):
        return _result_report_section(manifest, output)
    if isinstance(output, HybridSimulationPlanIR):
        return _hybrid_plan_report_section(manifest, output)
    raise TypeError("output must be ResultIR or HybridSimulationPlanIR.")


def _result_report_section(
    manifest: SimulationManifestIR,
    result: ResultIR,
) -> SimulationReportSectionIR:
    diagnostics = tuple(result.diagnostics)
    return SimulationReportSectionIR(
        section_id=f"simulation_report.{manifest.manifest_id}",
        manifest_id=manifest.manifest_id,
        program_kind=manifest.program_kind,
        output_kind="result",
        output_id=result.result_id,
        output_hash=result.stable_hash(),
        status="completed",
        shots=result.shots,
        counts_summary=_counts_summary(result.counts),
        probability_summary=_probability_summary(result.probabilities),
        observable_summary=_observable_summary(result.observables),
        state_summary=_state_summary(result.metadata.get("simulation_state")),
        algorithm_summary=_algorithm_summary(
            result.metadata.get("simulation_algorithm"),
            result.metadata.get("unified_simulator"),
        ),
        diagnostics_summary=_diagnostics_summary(diagnostics),
        noise_summary=_noise_summary(result.metadata),
        boundary_flags=_boundary_flags(result.metadata),
        metadata={
            "source_kind": "ResultIR",
            "result_id": result.result_id,
            "program_hash": result.program_hash,
            "manifest_hash": manifest.stable_hash(),
        },
    )


def _hybrid_plan_report_section(
    manifest: SimulationManifestIR,
    plan: HybridSimulationPlanIR,
) -> SimulationReportSectionIR:
    diagnostics = (*plan.diagnostics, *_boundary_result_diagnostics(plan))
    return SimulationReportSectionIR(
        section_id=f"simulation_report.{manifest.manifest_id}",
        manifest_id=manifest.manifest_id,
        program_kind=manifest.program_kind,
        output_kind="hybrid_plan",
        output_id=plan.plan_id,
        output_hash=plan.stable_hash(),
        status="planned" if plan.executable else "blocked",
        shots=manifest.shots,
        counts_summary={"available": False, "total_shots": 0, "top_counts": []},
        probability_summary={"available": False, "basis_count": 0},
        observable_summary={"available": False, "keys": []},
        state_summary={
            "available": True,
            "state_source": "HybridSimulationPlanIR",
            "block_count": len(plan.block_states),
            "block_states": [state.to_dict() for state in plan.block_states],
        },
        algorithm_summary={
            "available": True,
            "selected_simulator": "HybridBlockSimulator",
            "execution_mode": plan.execution_mode,
            "plan_only": True,
        },
        diagnostics_summary=_diagnostics_summary(diagnostics),
        noise_summary={"available": False, "noise_mode": manifest.noise_mode},
        boundary_flags={
            "offline_deterministic": True,
            "hardware_execution": False,
            "cloud_execution": False,
            "full_daqc_state_handoff": False,
            "hybrid_plan_only": True,
            "boundary_diagnostic_count": len(plan.boundary_diagnostics),
            "boundary_warning_count": sum(
                1 for item in plan.boundary_diagnostics if item.status == "warning"
            ),
            "boundary_error_count": sum(
                1 for item in plan.boundary_diagnostics if item.status == "error"
            ),
            "executable": plan.executable,
        },
        metadata={
            "source_kind": "HybridSimulationPlanIR",
            "plan_id": plan.plan_id,
            "program_id": plan.program_id,
            "manifest_hash": manifest.stable_hash(),
        },
    )


def _config_from_manifest(manifest: SimulationManifestIR) -> SimulatorConfigIR:
    config_data = dict(manifest.simulator_config)
    config_data.setdefault("shots", manifest.shots)
    config_data.setdefault("seed", manifest.seed)
    config_data.setdefault("method", manifest.method)
    return SimulatorConfigIR.from_dict(config_data)


def _counts_summary(counts: dict[str, int]) -> dict[str, Any]:
    total = sum(counts.values())
    top_counts = sorted(counts.items(), key=lambda item: (-item[1], item[0]))[:8]
    return {
        "available": bool(counts),
        "total_shots": total,
        "unique_bitstrings": len(counts),
        "top_counts": [
            {"bitstring": bitstring, "count": count}
            for bitstring, count in top_counts
        ],
    }


def _probability_summary(probabilities: dict[str, float] | None) -> dict[str, Any]:
    if probabilities is None:
        return {"available": False, "basis_count": 0, "probability_mass": None}
    return {
        "available": True,
        "basis_count": len(probabilities),
        "probability_mass": sum(probabilities.values()),
        "top_probabilities": [
            {"bitstring": bitstring, "probability": probability}
            for bitstring, probability in sorted(
                probabilities.items(),
                key=lambda item: (-item[1], item[0]),
            )[:8]
        ],
    }


def _observable_summary(observables: dict[str, Any]) -> dict[str, Any]:
    return {
        "available": bool(observables),
        "keys": sorted(observables),
        "values": {key: observables[key] for key in sorted(observables)[:16]},
    }


def _state_summary(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict):
        return {"available": False, "state_bytes_returned": False}
    primary = value.get("primary")
    primary_kind = primary.get("state_kind") if isinstance(primary, dict) else None
    return {
        "available": True,
        "primary_state_kind": primary_kind,
        "state_bytes_returned": bool(value.get("state_bytes_returned", False)),
        "physical_accuracy": value.get("physical_accuracy"),
        "keys": sorted(str(key) for key in value),
    }


def _algorithm_summary(algorithm: Any, facade: Any) -> dict[str, Any]:
    summary: dict[str, Any] = {"available": False}
    if isinstance(algorithm, dict):
        summary.update(
            {
                "available": True,
                "simulator_name": algorithm.get("simulator_name"),
                "method_requested": algorithm.get("method_requested"),
                "method_selected": algorithm.get("method_selected"),
                "algorithm_family": algorithm.get("algorithm_family"),
                "deterministic": algorithm.get("deterministic"),
                "seed": algorithm.get("seed"),
            }
        )
    if isinstance(facade, dict):
        summary["facade"] = {
            "selected_simulator": facade.get("selected_simulator"),
            "validate_before_run": facade.get("validate_before_run"),
            "offline_deterministic": facade.get("offline_deterministic"),
        }
    return summary


def _diagnostics_summary(diagnostics: tuple[DiagnosticsIR, ...]) -> dict[str, Any]:
    return build_diagnostics_summary(diagnostics)


def _noise_summary(metadata: dict[str, Any]) -> dict[str, Any]:
    report = metadata.get("noise_application_report")
    if isinstance(report, dict):
        return {
            "available": True,
            "noise_model_id": report.get("noise_model_id"),
            "physical_accuracy": report.get("physical_accuracy"),
            "counts_modified": report.get("counts_modified"),
            "injection_points": report.get("injection_points"),
        }
    facade = metadata.get("unified_simulator")
    noise_mode = facade.get("noise_mode") if isinstance(facade, dict) else "unknown"
    return {"available": False, "noise_mode": noise_mode}


def _boundary_flags(metadata: dict[str, Any]) -> dict[str, Any]:
    facade = metadata.get("unified_simulator")
    if not isinstance(facade, dict):
        return {
            "offline_deterministic": True,
            "hardware_execution": False,
            "cloud_execution": False,
            "full_daqc_state_handoff": False,
        }
    return {
        "offline_deterministic": bool(facade.get("offline_deterministic", True)),
        "hardware_execution": bool(facade.get("hardware_execution", False)),
        "cloud_execution": bool(facade.get("cloud_execution", False)),
        "full_daqc_state_handoff": bool(
            facade.get("full_daqc_state_handoff", False)
        ),
        "hybrid_plan_only": bool(facade.get("hybrid_plan_only", False)),
    }


def _boundary_result_diagnostics(
    plan: HybridSimulationPlanIR,
) -> tuple[DiagnosticsIR, ...]:
    diagnostics: list[DiagnosticsIR] = []
    for boundary in plan.boundary_diagnostics:
        severity: Literal["info", "warning", "error"]
        if boundary.status == "error":
            severity = "error"
        elif boundary.status == "warning":
            severity = "warning"
        else:
            severity = "info"
        diagnostics.append(
            DiagnosticsIR(
                diagnostic_id=f"simulation.{boundary.boundary_id}",
                stage="simulation",
                severity=severity,
                code=boundary.code,
                message=boundary.message,
                object_path=boundary.object_path,
                suggestion=boundary.suggestion,
                metadata=boundary.metadata,
            )
        )
    return tuple(diagnostics)
