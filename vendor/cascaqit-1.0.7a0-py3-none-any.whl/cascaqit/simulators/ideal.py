"""Scalable NumPy/SciPy ideal-state kernels."""

from __future__ import annotations

import math
from collections import Counter
from dataclasses import dataclass, replace
from functools import cache
from typing import TYPE_CHECKING, Any, Literal, cast

import numpy as np
from numpy.typing import NDArray
from scipy.sparse.linalg import (  # type: ignore[import-untyped]
    LinearOperator,
    expm_multiply,
)

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.digital import DigitalProgramIR, GateIR
from cascaqit.exceptions import ProgramValidationError
from cascaqit.native_ir import ProgramIR, WaveformIR
from cascaqit.observables import ObservableSet
from cascaqit.results import (
    ResultIR,
    ResultReferencesIR,
    SimulationSolverEvidenceIR,
    StateTransitionIR,
)
from cascaqit.simulators.adaptive import (
    fixed_step_solver_evidence,
    integrate_dop853_segments,
)
from cascaqit.simulators.addressing import site_addressing_provenance_metadata
from cascaqit.simulators.analog_timing import analog_control_boundaries
from cascaqit.simulators.array_state import (
    ArrayStateProvenance,
    StateVectorState,
    SubspaceState,
)
from cascaqit.simulators.execution_evidence import (
    aggregate_solver_evidence,
    not_applicable_solver_evidence,
    solver_evidence_from_provenance,
    solver_evidence_metadata,
)
from cascaqit.simulators.local_rabi import (
    sample_local_rabi_fields,
    site_phase_pattern_provenance_metadata,
)
from cascaqit.simulators.observable_evaluator import evaluate_observables
from cascaqit.simulators.planning import (
    SelectedSimulationIntegrator,
    SimulationIntegrator,
)
from cascaqit.simulators.register_evidence import collect_register_snapshot_evidence
from cascaqit.simulators.runtime_lineage import (
    build_runtime_references,
    build_runtime_trace,
    build_state_transition,
    runtime_lineage_metadata,
)
from cascaqit.simulators.waveform_sampling import sample_waveform as _sample_waveform

if TYPE_CHECKING:
    from cascaqit.simulators.local_hybrid import LocalExecutionBundle

__all__ = [
    "MatrixFreeAnalogStateVectorKernel",
    "NumpyDigitalStateVectorKernel",
    "build_blockade_basis",
    "blockade_basis_dimension",
    "run_scalable_analog_ideal",
    "run_scalable_digital_ideal",
    "run_scalable_hybrid_ideal",
    "validate_scalable_hybrid_bundle",
    "zero_state_vector",
]

ComplexArray = NDArray[np.complexfloating[Any, Any]]
ArrayDType = Literal["complex64", "complex128"]


def zero_state_vector(
    logical_order: tuple[str, ...],
    *,
    dtype: ArrayDType = "complex128",
    producer: str = "zero_state_vector",
) -> StateVectorState:
    """Allocate the computational all-zero state without Python element copies."""
    if not logical_order:
        raise ValueError("logical_order must not be empty.")
    amplitudes = np.zeros(2 ** len(logical_order), dtype=np.dtype(dtype))
    amplitudes[0] = 1.0
    return StateVectorState(
        amplitudes=amplitudes,
        logical_order=logical_order,
        provenance=ArrayStateProvenance.initial(producer),
    )


def run_scalable_digital_ideal(
    program: DigitalProgramIR,
    *,
    shots: int,
    seed: int | None,
    dtype: ArrayDType,
    return_probabilities: bool,
    observables: ObservableSet | None = None,
) -> ResultIR:
    """Execute a Digital program through the scalable tensor-axis kernel."""
    order = tuple(program.circuit.qubits)
    initial_state = zero_state_vector(order, dtype=dtype)
    state = NumpyDigitalStateVectorKernel().evolve(
        program,
        initial_state,
    )
    result = _state_result(
        state,
        result_id=f"result.{program.program_id}",
        program_hash=program.stable_hash(),
        target_id="local.digital_simulator",
        shots=shots,
        seed=seed,
        return_probabilities=return_probabilities,
        program_kind="digital",
        observables=observables,
    )
    evidence = not_applicable_solver_evidence(
        integrator_requested="auto",
        logical_time=state.logical_time,
        time_unit=state.time_unit,
        consumer="NumpyDigitalStateVectorKernel",
    )
    transition = build_state_transition(
        transition_id=f"transition.0.{program.program_id}",
        order_index=0,
        block_id=program.program_id,
        program_kind="digital",
        program_hash=program.stable_hash(),
        kernel=state.provenance.producer,
        input_state_hash=initial_state.stable_hash(),
        output_state_hash=state.stable_hash(),
        input_logical_time=initial_state.logical_time,
        output_logical_time=state.logical_time,
        time_unit=state.time_unit,
        solver_evidence=evidence,
        metadata={"logical_order": list(state.logical_order)},
    )
    references = build_runtime_references(
        program_hash=program.stable_hash(),
        initial_state_hash=initial_state.stable_hash(),
        final_state_hash=state.stable_hash(),
    )
    trace = build_runtime_trace(
        trace_id=f"trace.{program.program_id}.scalable_digital",
        transitions=(transition,),
        references=references,
        execution_mode="standalone_digital",
        terminal_message="Terminal Digital sampling completed.",
        terminal_metadata={"shots": shots, "seed": seed},
    )
    return replace(
        result,
        metadata={
            **result.metadata,
            **solver_evidence_metadata(evidence),
            **runtime_lineage_metadata(
                transitions=(transition,),
                references=references,
                trace=trace,
            ),
        },
    )


def run_scalable_analog_ideal(
    program: ProgramIR,
    *,
    shots: int,
    seed: int | None,
    dtype: ArrayDType,
    steps: int,
    blockade_radius: float,
    target_id: str,
    return_probabilities: bool,
    use_subspace: bool = False,
    observables: ObservableSet | None = None,
    integrator_requested: SimulationIntegrator = "fixed_step_krylov",
    integrator_selected: SelectedSimulationIntegrator = "fixed_step_krylov",
    rtol: float = 1e-9,
    atol: float = 1e-11,
    max_steps: int = 10_000,
) -> ResultIR:
    """Execute an Analog program through the scalable matrix-free kernel."""
    order = _atom_order(program)
    kernel = MatrixFreeAnalogStateVectorKernel(
        steps=steps,
        blockade_radius=blockade_radius,
        integrator_requested=integrator_requested,
        integrator_selected=integrator_selected,
        rtol=rtol,
        atol=atol,
        max_steps=max_steps,
    )
    if use_subspace:
        basis_indices = build_blockade_basis(program, blockade_radius)
        amplitudes = np.zeros(basis_indices.size, dtype=np.dtype(dtype))
        amplitudes[0] = 1.0
        initial_state: StateVectorState | SubspaceState = SubspaceState(
            amplitudes=amplitudes,
            basis_indices=basis_indices,
            logical_order=order,
            provenance=ArrayStateProvenance.initial("zero_subspace_state"),
        )
        state: StateVectorState | SubspaceState = kernel.evolve_subspace(
            program,
            cast(SubspaceState, initial_state),
        )
    else:
        initial_state = zero_state_vector(order, dtype=dtype)
        state = kernel.evolve(program, initial_state)
    result = _state_result(
        state,
        result_id=f"result.{program.program_id}",
        program_hash=program.stable_hash(),
        target_id=target_id,
        shots=shots,
        seed=seed,
        return_probabilities=return_probabilities,
        program_kind="analog",
        observables=observables,
    )
    evidence = solver_evidence_from_provenance(
        state.provenance.metadata,
        object_path="simulation_state.provenance.solver_evidence",
    )
    transition = build_state_transition(
        transition_id=f"transition.0.{program.program_id}",
        order_index=0,
        block_id=program.program_id,
        program_kind="analog",
        program_hash=program.stable_hash(),
        kernel=state.provenance.producer,
        input_state_hash=initial_state.stable_hash(),
        output_state_hash=state.stable_hash(),
        input_logical_time=initial_state.logical_time,
        output_logical_time=state.logical_time,
        time_unit=state.time_unit,
        solver_evidence=evidence,
        metadata={"logical_order": list(state.logical_order)},
    )
    references = build_runtime_references(
        program_hash=program.stable_hash(),
        initial_state_hash=initial_state.stable_hash(),
        final_state_hash=state.stable_hash(),
    )
    trace = build_runtime_trace(
        trace_id=f"trace.{program.program_id}.scalable_analog",
        transitions=(transition,),
        references=references,
        execution_mode="standalone_analog",
        terminal_message="Terminal Analog sampling completed.",
        terminal_metadata={"shots": shots, "seed": seed},
    )
    return replace(
        result,
        metadata={
            **result.metadata,
            "register_snapshot": program.register.snapshot_evidence(),
            **solver_evidence_metadata(evidence),
            **runtime_lineage_metadata(
                transitions=(transition,),
                references=references,
                trace=trace,
            ),
        },
    )


def validate_scalable_hybrid_bundle(bundle: LocalExecutionBundle) -> None:
    """Validate the array-engine boundary without allocating its state vector."""
    from cascaqit.simulators.local_hybrid import (
        AnalogStepPayload,
        DigitalStepPayload,
        LocalExecutionBundle,
        MeasurementStepPayload,
    )

    if not isinstance(bundle, LocalExecutionBundle):
        raise TypeError("bundle must be LocalExecutionBundle.")
    if not isinstance(bundle.payloads[-1], MeasurementStepPayload):
        raise ProgramValidationError(
            "Scalable Hybrid execution requires one terminal measurement.",
            code="SCALABLE_HYBRID_MEASUREMENT_BOUNDARY_INVALID",
            stage="simulation",
            object_path="bundle.payloads",
        )
    for index, payload in enumerate(bundle.payloads[:-1]):
        if isinstance(payload, MeasurementStepPayload):
            raise ProgramValidationError(
                "Scalable Hybrid execution does not support mid-circuit measurement.",
                code="SCALABLE_HYBRID_MEASUREMENT_BOUNDARY_INVALID",
                stage="simulation",
                object_path=f"bundle.payloads[{index}]",
            )
        if isinstance(payload, DigitalStepPayload):
            diagnostics = tuple(
                item
                for item in payload.program.validate_ir_only()
                if item.severity == "error"
            )
            if diagnostics:
                raise ProgramValidationError(
                    "Hybrid Digital payload failed scalable preflight.",
                    code="SCALABLE_HYBRID_DIGITAL_PROGRAM_INVALID",
                    stage="simulation",
                    object_path=f"bundle.payloads[{index}].program",
                    diagnostics=diagnostics,
                )
        elif isinstance(payload, AnalogStepPayload):
            _validate_analog_inputs(payload.program, payload.logical_order)
        else:
            raise ProgramValidationError(
                "Hybrid bundle contains an unsupported quantum payload.",
                code="SCALABLE_HYBRID_PAYLOAD_UNSUPPORTED",
                stage="simulation",
                object_path=f"bundle.payloads[{index}]",
            )


def run_scalable_hybrid_ideal(
    bundle: LocalExecutionBundle,
    *,
    dtype: ArrayDType,
    steps: int,
    blockade_radius: float,
    target_id: str,
    return_probabilities: bool = True,
    observables: ObservableSet | None = None,
    integrator_requested: SimulationIntegrator = "fixed_step_krylov",
    integrator_selected: SelectedSimulationIntegrator = "fixed_step_krylov",
    rtol: float = 1e-9,
    atol: float = 1e-11,
    max_steps: int = 10_000,
) -> ResultIR:
    """Execute Digital-Analog blocks over one continuous NumPy state vector."""
    from cascaqit.simulators.local_hybrid import (
        AnalogStepPayload,
        DigitalStepPayload,
        MeasurementStepPayload,
    )

    validate_scalable_hybrid_bundle(bundle)
    measurement = cast(MeasurementStepPayload, bundle.payloads[-1])
    state = zero_state_vector(
        measurement.logical_order,
        dtype=dtype,
        producer="ScalableHybridInitialState",
    )
    initial_state = state
    transitions: list[StateTransitionIR] = []
    solver_evidences: list[SimulationSolverEvidenceIR] = []
    digital = NumpyDigitalStateVectorKernel()
    analog = MatrixFreeAnalogStateVectorKernel(
        steps=steps,
        blockade_radius=blockade_radius,
        integrator_requested=integrator_requested,
        integrator_selected=integrator_selected,
        rtol=rtol,
        atol=atol,
        max_steps=max_steps,
    )
    for index, payload in enumerate(bundle.payloads[:-1]):
        quantum_payload = cast(Any, payload)
        input_state = state
        if isinstance(quantum_payload, DigitalStepPayload):
            state = digital.evolve(quantum_payload.program, input_state)
            evidence = not_applicable_solver_evidence(
                integrator_requested=integrator_requested,
                logical_time=state.logical_time,
                time_unit=state.time_unit,
                consumer=state.provenance.producer,
            )
        else:
            state = analog.evolve(quantum_payload.program, input_state)
        input_hash = input_state.stable_hash()
        if state.provenance.parent_state_hash != input_hash:
            raise ProgramValidationError(
                "Scalable Hybrid state lineage is discontinuous.",
                code="SCALABLE_HYBRID_STATE_CHAIN_BROKEN",
                stage="simulation",
                object_path=f"bundle.payloads[{index}]",
            )
        transition_metadata: dict[str, Any] = {
            "payload_id": quantum_payload.payload_id,
            "payload_hash": quantum_payload.stable_hash(),
            "logical_order": list(state.logical_order),
            "producer": state.provenance.producer,
        }
        if isinstance(quantum_payload, AnalogStepPayload):
            evidence = solver_evidence_from_provenance(
                state.provenance.metadata,
                object_path=(
                    f"bundle.payloads[{index}].provenance.solver_evidence"
                ),
            )
            solver_evidences.append(evidence)
            addressing = state.provenance.metadata.get("site_addressing")
            if isinstance(addressing, dict):
                transition_metadata["site_addressing"] = addressing
            phase_pattern = state.provenance.metadata.get("site_phase_pattern")
            if isinstance(phase_pattern, dict):
                transition_metadata["site_phase_pattern"] = phase_pattern
        transitions.append(
            build_state_transition(
                transition_id=f"transition.{index}.{quantum_payload.block_id}",
                order_index=index,
                block_id=quantum_payload.block_id,
                program_kind=quantum_payload.payload_kind,
                program_hash=quantum_payload.program.stable_hash(),
                kernel=state.provenance.producer,
                input_state_hash=input_hash,
                output_state_hash=state.stable_hash(),
                input_logical_time=input_state.logical_time,
                output_logical_time=state.logical_time,
                time_unit=state.time_unit,
                solver_evidence=evidence,
                metadata=transition_metadata,
            )
        )
    result = _state_result(
        state,
        result_id=f"result.{bundle.bundle_id}",
        program_hash=bundle.base_plan.program_hash,
        target_id=target_id,
        shots=measurement.shots,
        seed=measurement.seed,
        return_probabilities=return_probabilities,
        program_kind="hybrid",
        observables=observables,
    )
    solver_evidence = aggregate_solver_evidence(
        solver_evidences,
        integrator_requested=integrator_requested,
        integrator_selected=integrator_selected,
        aggregation_scope="hybrid_quantum_blocks",
    )
    transition_tuple = tuple(transitions)
    references = build_runtime_references(
        program_hash=bundle.base_plan.program_hash,
        plan_hash=bundle.base_plan_hash,
        bundle_hash=bundle.stable_hash(),
        initial_state_hash=initial_state.stable_hash(),
        final_state_hash=state.stable_hash(),
        metadata={"graph_hash": bundle.base_plan.graph_hash},
    )
    trace = build_runtime_trace(
        trace_id=f"trace.{bundle.bundle_id}.scalable_hybrid",
        transitions=transition_tuple,
        references=references,
        execution_mode="local_hybrid_shared_state",
        terminal_message="Terminal computational-basis measurement completed.",
        terminal_metadata={
            "measurement_key": measurement.measurement_key,
            "shots": measurement.shots,
            "seed": measurement.seed,
        },
    )
    return replace(
        result,
        metadata={
            **result.metadata,
            **solver_evidence_metadata(solver_evidence),
            "bundle_hash": bundle.stable_hash(),
            **runtime_lineage_metadata(
                transitions=transition_tuple,
                references=references,
                trace=trace,
            ),
            "measurement": {
                "basis": measurement.basis,
                "key": measurement.measurement_key,
                "targets": list(measurement.logical_order),
            },
            "register_snapshots": collect_register_snapshot_evidence(
                payload.program
                for payload in bundle.payloads
                if isinstance(payload, AnalogStepPayload)
            ),
        },
    )


@dataclass(frozen=True)
class NumpyDigitalStateVectorKernel:
    """Apply local Digital gates through tensor axes, never a global unitary."""

    def evolve(
        self,
        program: DigitalProgramIR,
        initial_state: StateVectorState,
    ) -> StateVectorState:
        if not isinstance(program, DigitalProgramIR):
            raise TypeError("program must be DigitalProgramIR.")
        if not isinstance(initial_state, StateVectorState):
            raise TypeError("initial_state must be StateVectorState.")
        logical_order = tuple(program.circuit.qubits)
        if initial_state.logical_order != logical_order:
            raise ProgramValidationError(
                "Digital program order does not match scalable state order.",
                code="DIGITAL_ARRAY_STATE_LOGICAL_ORDER_MISMATCH",
                stage="simulation",
                object_path="simulation_state.logical_order",
            )
        diagnostics = tuple(
            item for item in program.validate_ir_only() if item.severity == "error"
        )
        if diagnostics:
            raise ProgramValidationError(
                "Digital program failed scalable kernel validation.",
                code="DIGITAL_ARRAY_STATE_PROGRAM_INVALID",
                stage="simulation",
                object_path="digital_program",
                diagnostics=diagnostics,
            )
        amplitudes = np.array(initial_state.amplitudes, copy=True)
        qubit_index = {name: index for index, name in enumerate(logical_order)}
        for gate in program.circuit.gates:
            amplitudes = self.apply_gate(
                amplitudes,
                gate,
                qubit_index=qubit_index,
            )
        return StateVectorState(
            amplitudes=amplitudes,
            logical_order=logical_order,
            basis=initial_state.basis,
            logical_time=initial_state.logical_time,
            time_unit=initial_state.time_unit,
            noise_context=initial_state.noise_context,
            provenance=ArrayStateProvenance(
                producer="NumpyDigitalStateVectorKernel",
                parent_state_hash=initial_state.stable_hash(),
                step_index=initial_state.provenance.step_index + 1,
                metadata={
                    "program_hash": program.stable_hash(),
                    "gate_count": len(program.circuit.gates),
                    "algorithm": "tensor_axis",
                },
            ),
        )

    def apply_gate(
        self,
        amplitudes: ComplexArray,
        gate: GateIR,
        *,
        qubit_index: dict[str, int],
    ) -> ComplexArray:
        """Apply one at-most-three-qubit gate to an existing state vector."""
        if gate.name == "i":
            return amplitudes
        targets = tuple(qubit_index[target] for target in gate.targets)
        matrix = _gate_matrix(gate, dtype=amplitudes.dtype)
        qubit_count = len(qubit_index)
        tensor = amplitudes.reshape((2,) * qubit_count)
        front_axes = tuple(range(len(targets)))
        moved = np.moveaxis(tensor, targets, front_axes)
        updated = _local_matrix_action(matrix, moved.reshape(matrix.shape[1], -1))
        restored = np.moveaxis(
            updated.reshape((2,) * qubit_count),
            front_axes,
            targets,
        )
        return np.ascontiguousarray(restored.reshape(-1))


@dataclass(frozen=True)
class MatrixFreeAnalogStateVectorKernel:
    """Evolve ideal AHS states with fixed Krylov or segmented DOP853."""

    steps: int = 32
    blockade_radius: float = 0.0
    integrator_requested: SimulationIntegrator = "fixed_step_krylov"
    integrator_selected: SelectedSimulationIntegrator = "fixed_step_krylov"
    rtol: float = 1e-9
    atol: float = 1e-11
    max_steps: int = 10_000

    def __post_init__(self) -> None:
        if (
            not isinstance(self.steps, int)
            or isinstance(self.steps, bool)
            or self.steps <= 0
        ):
            raise ValueError("steps must be a positive integer.")
        if not math.isfinite(self.blockade_radius) or self.blockade_radius < 0.0:
            raise ValueError("blockade_radius must be finite and non-negative.")
        if self.integrator_requested not in {
            "auto",
            "adaptive_dop853",
            "fixed_step_krylov",
        }:
            raise ValueError("integrator_requested is unsupported.")
        if self.integrator_selected not in {
            "adaptive_dop853",
            "fixed_step_krylov",
        }:
            raise ValueError("Analog state evolution requires a selected integrator.")
        if (
            self.integrator_requested != "auto"
            and self.integrator_requested != self.integrator_selected
        ):
            raise ValueError("Explicit integrator request cannot be changed silently.")
        for value, field_name in ((self.rtol, "rtol"), (self.atol, "atol")):
            if not math.isfinite(value) or value <= 0.0:
                raise ValueError(f"{field_name} must be finite and positive.")
        if (
            not isinstance(self.max_steps, int)
            or isinstance(self.max_steps, bool)
            or self.max_steps <= 0
        ):
            raise ValueError("max_steps must be a positive integer.")

    def evolve(
        self,
        program: ProgramIR,
        initial_state: StateVectorState,
    ) -> StateVectorState:
        """Evolve a full Hilbert-space state without materializing Hamiltonian."""
        _validate_analog_inputs(program, initial_state.logical_order)
        evolved, evidence = self._propagate(
            program,
            initial_state.amplitudes,
            basis_indices=None,
            logical_time_offset=initial_state.logical_time,
        )
        return StateVectorState(
            amplitudes=evolved,
            logical_order=initial_state.logical_order,
            basis=initial_state.basis,
            logical_time=initial_state.logical_time + _duration(program),
            time_unit=initial_state.time_unit,
            noise_context=initial_state.noise_context,
            provenance=_analog_provenance(
                program,
                initial_state.stable_hash(),
                initial_state.provenance.step_index,
                representation="state_vector",
                evidence=evidence,
            ),
        )

    def evolve_subspace(
        self,
        program: ProgramIR,
        initial_state: SubspaceState,
    ) -> SubspaceState:
        """Evolve an explicit blockade basis with projected matrix-free flips."""
        _validate_analog_inputs(program, initial_state.logical_order)
        evolved, evidence = self._propagate(
            program,
            initial_state.amplitudes,
            basis_indices=initial_state.basis_indices,
            logical_time_offset=initial_state.logical_time,
        )
        return SubspaceState(
            amplitudes=evolved,
            basis_indices=initial_state.basis_indices,
            logical_order=initial_state.logical_order,
            basis=initial_state.basis,
            logical_time=initial_state.logical_time + _duration(program),
            time_unit=initial_state.time_unit,
            noise_context=initial_state.noise_context,
            provenance=_analog_provenance(
                program,
                initial_state.stable_hash(),
                initial_state.provenance.step_index,
                representation="subspace",
                evidence=evidence,
            ),
        )

    def _propagate(
        self,
        program: ProgramIR,
        amplitudes: ComplexArray,
        *,
        basis_indices: NDArray[np.integer[Any]] | None,
        logical_time_offset: float,
    ) -> tuple[ComplexArray, SimulationSolverEvidenceIR]:
        duration = _duration(program)
        if self.integrator_selected == "adaptive_dop853":

            def rhs(time: float, values: ComplexArray) -> ComplexArray:
                hamiltonian, _ = _analog_linear_operator(
                    program,
                    time=time,
                    dtype=values.dtype,
                    blockade_radius=self.blockade_radius,
                    basis_indices=basis_indices,
                )
                return np.asarray(-1j * hamiltonian.matvec(values))

            integration = integrate_dop853_segments(
                rhs,
                np.array(amplitudes, copy=True),
                boundaries=analog_control_boundaries(program),
                integrator_requested=self.integrator_requested,
                rtol=self.rtol,
                atol=self.atol,
                max_steps=self.max_steps,
                logical_time_offset=logical_time_offset,
            )
            state = np.asarray(integration.values, dtype=amplitudes.dtype)
            evidence = integration.evidence
        else:
            state = np.array(amplitudes, copy=True)
            dt = duration / self.steps
            for step in range(self.steps):
                time = (step + 0.5) * dt
                hamiltonian, trace = _analog_linear_operator(
                    program,
                    time=time,
                    dtype=state.dtype,
                    blockade_radius=self.blockade_radius,
                    basis_indices=basis_indices,
                )
                scaled = LinearOperator(
                    hamiltonian.shape,
                    matvec=lambda vector, op=hamiltonian: (
                        -1j * dt * op.matvec(vector)
                    ),
                    rmatvec=lambda vector, op=hamiltonian: (
                        1j * dt * op.rmatvec(vector)
                    ),
                    dtype=state.dtype,
                )
                state = np.asarray(
                    expm_multiply(scaled, state, traceA=-1j * dt * trace),
                    dtype=amplitudes.dtype,
                )
            evidence = fixed_step_solver_evidence(
                integrator_requested=self.integrator_requested,
                steps=self.steps,
                duration=duration,
                logical_time_offset=logical_time_offset,
                time_unit="us",
                algorithm="scipy.sparse.linalg.expm_multiply",
            )
        norm = float(np.linalg.norm(state.astype(np.complex128, copy=False)))
        if norm <= 0.0 or not math.isfinite(norm):
            raise ProgramValidationError(
                "Analog propagation produced an invalid state norm.",
                code="ANALOG_ARRAY_STATE_NORM_INVALID",
                stage="simulation",
                object_path="simulation_state.amplitudes",
                metadata={"norm": norm},
            )
        normalized = np.asarray(state / norm, dtype=amplitudes.dtype)
        dtype_epsilon = float(np.finfo(normalized.real.dtype).eps)
        evidence = replace(
            evidence,
            metadata={
                **evidence.metadata,
                "norm_before_normalization": norm,
                "normalization_correction": abs(1.0 - norm),
                "output_dtype": str(normalized.dtype),
                "output_dtype_epsilon": dtype_epsilon,
                "requested_tolerance_below_output_precision": (
                    self.integrator_selected == "adaptive_dop853"
                    and (self.rtol < dtype_epsilon or self.atol < dtype_epsilon)
                ),
            },
        )
        return normalized, evidence


def build_blockade_basis(
    program: ProgramIR,
    blockade_radius: float,
) -> NDArray[np.int64]:
    """Return ordered full-space indexes that satisfy pair blockade constraints."""
    if not math.isfinite(blockade_radius) or blockade_radius < 0.0:
        raise ValueError("blockade_radius must be finite and non-negative.")
    atom_count = len(_atom_order(program))
    conflicts = _earlier_conflict_masks(program, blockade_radius)
    indices: list[int] = []

    # Unoccupied-first depth-first traversal preserves ascending full-space indexes.
    def visit(atom_index: int, occupied: int, basis_index: int) -> None:
        if atom_index == atom_count:
            indices.append(basis_index)
            return
        visit(atom_index + 1, occupied, basis_index)
        if occupied & conflicts[atom_index] == 0:
            bit = 1 << (atom_count - atom_index - 1)
            visit(atom_index + 1, occupied | (1 << atom_index), basis_index | bit)

    visit(0, 0, 0)
    return np.asarray(indices, dtype=np.int64)


def blockade_basis_dimension(program: ProgramIR, blockade_radius: float) -> int:
    """Count the explicit blockade basis without materializing basis indexes."""
    if not math.isfinite(blockade_radius) or blockade_radius < 0.0:
        raise ValueError("blockade_radius must be finite and non-negative.")
    atom_count = len(_atom_order(program))
    conflicts = _earlier_conflict_masks(program, blockade_radius)

    @cache
    def count(atom_index: int, occupied: int) -> int:
        if atom_index == atom_count:
            return 1
        total = count(atom_index + 1, occupied)
        if occupied & conflicts[atom_index] == 0:
            total += count(atom_index + 1, occupied | (1 << atom_index))
        return total

    return count(0, 0)


def _earlier_conflict_masks(
    program: ProgramIR,
    blockade_radius: float,
) -> tuple[int, ...]:
    masks = [0] * len(_atom_order(program))
    for left, right in _blockade_pairs(program, blockade_radius):
        masks[right] |= 1 << left
    return tuple(masks)


def _local_matrix_action(matrix: ComplexArray, values: ComplexArray) -> ComplexArray:
    output = np.zeros_like(values)
    for row in range(matrix.shape[0]):
        for column in range(matrix.shape[1]):
            coefficient = matrix[row, column]
            if coefficient != 0:
                output[row] += coefficient * values[column]
    return output


def _state_result(
    state: StateVectorState | SubspaceState,
    *,
    result_id: str,
    program_hash: str,
    target_id: str,
    shots: int,
    seed: int | None,
    return_probabilities: bool,
    program_kind: Literal["digital", "analog", "hybrid"],
    observables: ObservableSet | None = None,
) -> ResultIR:
    state_norm = float(np.linalg.norm(state.amplitudes))
    width = len(state.logical_order)
    probabilities: dict[str, float] | None = None
    if shots > 0 or return_probabilities:
        probabilities_array: NDArray[np.float64] = np.asarray(
            np.abs(state.amplitudes) ** 2,
            dtype=np.float64,
        )
        probability_sum = float(np.sum(probabilities_array))
        if probability_sum <= 0.0 or not math.isfinite(probability_sum):
            raise ProgramValidationError(
                "Scalable state has invalid total probability.",
                code="SCALABLE_STATE_PROBABILITY_INVALID",
                stage="simulation",
                object_path="simulation_state.amplitudes",
                metadata={"probability_sum": probability_sum},
            )
        probabilities_array = probabilities_array / probability_sum
        basis_indices = (
            None if isinstance(state, StateVectorState) else state.basis_indices
        )
        if shots > 0:
            sampled = np.random.default_rng(seed).choice(
                state.dimension,
                size=shots,
                p=probabilities_array,
            )
            samples = tuple(
                format(
                    (
                        int(index)
                        if basis_indices is None
                        else int(basis_indices[int(index)])
                    ),
                    f"0{width}b",
                )
                for index in sampled
            )
            counts = dict(Counter(samples))
        else:
            samples = ()
            counts = {}
        if return_probabilities:
            probabilities = {
                format(
                    index if basis_indices is None else int(basis_indices[index]),
                    f"0{width}b",
                ): float(value)
                for index, value in enumerate(probabilities_array)
            }
    else:
        samples = ()
        counts = {}
    diagnostic = DiagnosticsIR(
        diagnostic_id=f"simulation.scalable.{program_kind}.completed",
        stage="simulation",
        severity="info",
        code="SCALABLE_IDEAL_SIMULATION_COMPLETED",
        message="Scalable ideal state-vector simulation completed.",
        object_path="result",
        metadata={"program_kind": program_kind},
    )
    references = ResultReferencesIR(program_hash=program_hash)
    observable_batch = (
        None if observables is None else evaluate_observables(state, observables)
    )
    return ResultIR(
        result_id=result_id,
        program_hash=program_hash,
        target_id=target_id,
        shots=shots,
        counts=counts,
        samples=samples,
        probabilities=probabilities,
        observables={
            "state_norm": state_norm,
        },
        observable_batch=observable_batch,
        bit_ordering={
            "convention": "logical_order",
            "logical_order": ",".join(state.logical_order),
        },
        diagnostics=(diagnostic,),
        metadata={
            "seed": seed,
            "references": references.to_dict(),
            "simulator": {
                "name": "ScalableIdealEngine",
                "method": (
                    "state_vector"
                    if isinstance(state, StateVectorState)
                    else "subspace"
                ),
                "array_backend": "numpy.cpu",
                "program_kind": program_kind,
            },
            "bitstring_ordering": {
                "convention": "logical_order",
                "logical_order": list(state.logical_order),
                "bitstring_index": "left_to_right_matches_logical_order",
            },
            "simulation_state": state.to_dict(),
            "state_hash": state.stable_hash(),
            "state_bytes_returned": False,
            "offline_deterministic": True,
            "network_accessed": False,
        },
    )


def _analog_linear_operator(
    program: ProgramIR,
    *,
    time: float,
    dtype: np.dtype[Any],
    blockade_radius: float,
    basis_indices: NDArray[np.integer[Any]] | None,
) -> tuple[LinearOperator, complex]:
    atom_count = len(_atom_order(program))
    full_dimension = 2**atom_count
    basis = (
        np.arange(full_dimension, dtype=np.int64)
        if basis_indices is None
        else np.asarray(basis_indices, dtype=np.int64)
    )
    diagonal = _analog_diagonal(
        program,
        basis,
        time=time,
        blockade_radius=blockade_radius,
    ).astype(dtype, copy=False)
    rabi = _sample_waveform(program.hamiltonian.rabi, time)
    phase = _sample_phase(program, time)
    local_fields = sample_local_rabi_fields(program, time)
    lookup: NDArray[np.int64] | None = None
    if basis_indices is not None:
        lookup = np.full(full_dimension, -1, dtype=np.int64)
        lookup[basis] = np.arange(basis.size, dtype=np.int64)

    def matmat(matrix: NDArray[Any]) -> ComplexArray:
        values = np.asarray(matrix, dtype=dtype).reshape(basis.size, -1)
        output: ComplexArray = np.asarray(
            diagonal[:, np.newaxis] * values,
            dtype=dtype,
        )
        if rabi == 0.0 and not any(
            amplitude != 0.0 for amplitude, _, _ in local_fields
        ):
            return output
        # The batch axis is retained so one index traversal serves every vector.
        for atom_index in range(atom_count):
            mask = 1 << (atom_count - atom_index - 1)
            occupied = (basis & mask) != 0
            # Coefficients are indexed by the source basis state: g -> r uses
            # exp(+i*phase), while r -> g uses its Hermitian conjugate.
            global_coefficient = rabi * np.where(
                occupied,
                np.exp(-1j * phase),
                np.exp(1j * phase),
            )
            local_coefficient: ComplexArray = np.zeros(basis.size, dtype=dtype)
            # Addressed lasers are coherent fields: every declared complex
            # amplitude contributes before the Hamiltonian flips this site.
            for local_amplitude, local_phases, weights in local_fields:
                local_phase = local_phases[atom_index]
                local_coefficient += np.asarray(
                    local_amplitude
                    * weights[atom_index]
                    * np.where(
                        occupied,
                        np.exp(-1j * local_phase),
                        np.exp(1j * local_phase),
                    ),
                    dtype=dtype,
                )
            # Global and addressed lasers are coherent fields, so their complex
            # amplitudes add before the Hamiltonian acts on the state.
            coefficient = 0.5 * (global_coefficient + local_coefficient)
            flipped = basis ^ mask
            if lookup is None:
                output[flipped] += coefficient[:, np.newaxis] * values
            else:
                targets = lookup[flipped]
                valid = targets >= 0
                output[targets[valid]] += coefficient[valid, np.newaxis] * values[valid]
        return np.asarray(output, dtype=dtype)

    def matvec(vector: NDArray[Any]) -> ComplexArray:
        return matmat(vector).reshape(-1)

    operator = LinearOperator(
        (basis.size, basis.size),
        matvec=matvec,
        matmat=matmat,
        rmatvec=matvec,
        rmatmat=matmat,
        dtype=dtype,
    )
    return operator, complex(np.sum(diagonal))


def _analog_diagonal(
    program: ProgramIR,
    basis: NDArray[np.int64],
    *,
    time: float,
    blockade_radius: float,
) -> NDArray[np.float64]:
    atom_count = len(_atom_order(program))
    detuning = _sample_waveform(program.hamiltonian.detuning, time)
    diagonal = np.zeros(basis.size, dtype=np.float64)
    occupations: list[NDArray[np.bool_]] = []
    for atom_index in range(atom_count):
        mask = 1 << (atom_count - atom_index - 1)
        occupied = (basis & mask) != 0
        occupations.append(occupied)
        diagonal -= detuning * occupied
    for term in program.hamiltonian.local_detuning_terms:
        local_value = _sample_waveform(term.waveform, time)
        for atom_index, weight in enumerate(term.addressing.weights_at(time)):
            diagonal -= local_value * weight * occupations[atom_index]
    for left, right, strength in _interaction_pairs(program, blockade_radius):
        diagonal += strength * occupations[left] * occupations[right]
    return diagonal


def _validate_analog_inputs(
    program: ProgramIR,
    logical_order: tuple[str, ...],
) -> None:
    if not isinstance(program, ProgramIR):
        raise TypeError("program must be ProgramIR.")
    if logical_order != _atom_order(program):
        raise ProgramValidationError(
            "Analog register order does not match scalable state order.",
            code="ANALOG_ARRAY_STATE_LOGICAL_ORDER_MISMATCH",
            stage="simulation",
            object_path="simulation_state.logical_order",
        )


def _analog_provenance(
    program: ProgramIR,
    parent_hash: str,
    parent_step: int,
    *,
    representation: str,
    evidence: SimulationSolverEvidenceIR,
) -> ArrayStateProvenance:
    return ArrayStateProvenance(
        producer="MatrixFreeAnalogStateVectorKernel",
        parent_state_hash=parent_hash,
        step_index=parent_step + 1,
        metadata={
            "program_hash": program.stable_hash(),
            "algorithm": (
                "adaptive_dop853"
                if evidence.integrator_selected == "adaptive_dop853"
                else "piecewise_midpoint_expm_multiply"
            ),
            "integrator_selected": evidence.integrator_selected,
            "representation": representation,
            "steps": evidence.accepted_steps,
            "solver_evidence": evidence.to_dict(),
            "solver_evidence_hash": evidence.stable_hash(),
            **site_addressing_provenance_metadata(
                program,
                consumer=f"MatrixFreeAnalogStateVectorKernel.{representation}",
            ),
            **site_phase_pattern_provenance_metadata(
                program,
                consumer=f"MatrixFreeAnalogStateVectorKernel.{representation}",
            ),
        },
    )


def _atom_order(program: ProgramIR) -> tuple[str, ...]:
    return tuple(str(site.atom_id) for site in program.register.sites if site.is_active)


def _duration(program: ProgramIR) -> float:
    waveforms = [program.hamiltonian.rabi, program.hamiltonian.detuning]
    waveforms.extend(term.waveform for term in program.hamiltonian.local_detuning_terms)
    for term in program.hamiltonian.local_rabi_terms:
        waveforms.append(term.rabi)
        if isinstance(term.phase, WaveformIR):
            waveforms.append(term.phase)
    return max(waveform.duration for waveform in waveforms)


def _sample_phase(program: ProgramIR, time: float) -> float:
    phase = program.hamiltonian.phase
    if isinstance(phase, WaveformIR):
        return _sample_waveform(phase, time)
    return float(phase)


def _sample_control_phase(phase: WaveformIR | float, time: float) -> float:
    return _sample_waveform(phase, time) if isinstance(phase, WaveformIR) else phase


def _blockade_pairs(
    program: ProgramIR,
    blockade_radius: float,
) -> tuple[tuple[int, int], ...]:
    sites = tuple(site for site in program.register.sites if site.is_active)
    return tuple(
        (left, right)
        for left in range(len(sites))
        for right in range(left + 1, len(sites))
        if math.dist(sites[left].position, sites[right].position) < blockade_radius
    )


def _interaction_pairs(
    program: ProgramIR,
    blockade_radius: float,
) -> tuple[tuple[int, int, float], ...]:
    sites = tuple(site for site in program.register.sites if site.is_active)
    pairs: list[tuple[int, int, float]] = []
    for left in range(len(sites)):
        for right in range(left + 1, len(sites)):
            distance = math.dist(sites[left].position, sites[right].position)
            if distance <= 0.0:
                strength = 1e6
            elif distance < blockade_radius:
                strength = (blockade_radius / distance) ** 6 * math.pi
            else:
                strength = 0.0
            if strength:
                pairs.append((left, right, strength))
    return tuple(pairs)


def _gate_matrix(gate: GateIR, *, dtype: np.dtype[Any]) -> ComplexArray:
    name = gate.name
    values: object
    if name == "x":
        values = ((0, 1), (1, 0))
    elif name == "y":
        values = ((0, -1j), (1j, 0))
    elif name == "z":
        values = ((1, 0), (0, -1))
    elif name == "h":
        scale = 1 / math.sqrt(2)
        values = ((scale, scale), (scale, -scale))
    elif name in {"s", "sdg", "t", "tdg", "p"}:
        angle = {
            "s": math.pi / 2,
            "sdg": -math.pi / 2,
            "t": math.pi / 4,
            "tdg": -math.pi / 4,
            "p": gate.parameters.get("theta", gate.parameters.get("lambda", 0.0)),
        }[name]
        values = ((1, 0), (0, np.exp(1j * angle)))
    elif name in {"rx", "ry", "rz"}:
        return _rotation_matrix(name, gate.parameters["theta"], dtype=dtype)
    elif name == "u":
        theta = gate.parameters["theta"]
        phi = gate.parameters["phi"]
        lam = gate.parameters["lambda"]
        values = (
            (math.cos(theta / 2), -np.exp(1j * lam) * math.sin(theta / 2)),
            (
                np.exp(1j * phi) * math.sin(theta / 2),
                np.exp(1j * (phi + lam)) * math.cos(theta / 2),
            ),
        )
    elif name in {"cx", "cy", "cz", "swap"}:
        return _two_qubit_matrix(name, dtype=dtype)
    elif name == "ccx":
        matrix = np.eye(8, dtype=dtype)
        matrix[[6, 7]] = matrix[[7, 6]]
        return matrix
    else:
        raise ProgramValidationError(
            f"Digital gate '{name}' is not supported by the scalable kernel.",
            code="DIGITAL_ARRAY_GATE_UNSUPPORTED",
            stage="simulation",
            object_path=f"digital_gates.{gate.gate_id}.name",
        )
    return np.asarray(values, dtype=dtype)


def _rotation_matrix(
    name: str,
    theta: float,
    *,
    dtype: np.dtype[Any],
) -> ComplexArray:
    cosine = math.cos(theta / 2)
    sine = math.sin(theta / 2)
    if name == "rx":
        values = ((cosine, -1j * sine), (-1j * sine, cosine))
    elif name == "ry":
        values = ((cosine, -sine), (sine, cosine))
    else:
        values = (
            (np.exp(-0.5j * theta), 0),
            (0, np.exp(0.5j * theta)),
        )
    return np.asarray(values, dtype=dtype)


def _two_qubit_matrix(name: str, *, dtype: np.dtype[Any]) -> ComplexArray:
    matrix = np.eye(4, dtype=dtype)
    if name == "cx":
        matrix[[2, 3]] = matrix[[3, 2]]
    elif name == "cy":
        matrix[2:, 2:] = np.asarray(((0, -1j), (1j, 0)), dtype=dtype)
    elif name == "cz":
        matrix[3, 3] = -1
    else:
        matrix[[1, 2]] = matrix[[2, 1]]
    return matrix
