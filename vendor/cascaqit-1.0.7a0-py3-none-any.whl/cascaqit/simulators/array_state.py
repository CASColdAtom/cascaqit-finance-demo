"""Immutable NumPy state contracts for scalable simulation engines."""

from __future__ import annotations

import hashlib
import math
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from typing import Any, Literal, Protocol, TypeVar, Union, runtime_checkable

import numpy as np
from numpy.typing import NDArray

from cascaqit.native_ir.base import IRMixin, stable_json

__all__ = [
    "ArrayBackendProtocol",
    "ArrayStateProvenance",
    "DensityMatrixState",
    "NumpyArrayBackend",
    "StateVectorState",
    "SubspaceState",
    "TrajectoryBatchState",
]

ARRAY_STATE_SCHEMA_VERSION = "cascaqit.simulation.array_state.v1"
ArrayDType = Literal["complex64", "complex128"]
ContextScalar = Union[None, bool, int, float, str]
ContextItems = tuple[tuple[str, ContextScalar], ...]
ContextInput = Union[Mapping[str, ContextScalar], Sequence[tuple[str, ContextScalar]]]
ComplexArray = NDArray[np.complexfloating[Any, Any]]
IntegerArray = NDArray[np.integer[Any]]
BooleanArray = NDArray[np.bool_]
_ArrayT = TypeVar("_ArrayT", bound=np.generic)

_NORMALIZATION_TOLERANCE = 1e-7
_COMPLEX64_NORMALIZATION_TOLERANCE = 1e-6
_DENSITY_TOLERANCE = 1e-9


@runtime_checkable
class ArrayBackendProtocol(Protocol):
    """Minimum allocation boundary required by scalable state engines."""

    @property
    def backend_id(self) -> str:
        """Return the stable array backend identifier."""

    def array(
        self,
        value: object,
        *,
        dtype: ArrayDType,
        copy: bool = True,
    ) -> ComplexArray:
        """Create one complex array."""

    def zeros(self, shape: tuple[int, ...], *, dtype: ArrayDType) -> ComplexArray:
        """Allocate one zero-filled complex array."""


class _ArrayStateContract(Protocol):
    @property
    def logical_order(self) -> tuple[str, ...]: ...

    @property
    def basis(self) -> str: ...

    @property
    def logical_time(self) -> float: ...

    @property
    def time_unit(self) -> str: ...

    @property
    def noise_context(self) -> ContextItems: ...

    @property
    def provenance(self) -> ArrayStateProvenance: ...

    @property
    def schema_version(self) -> str: ...

    def stable_hash(self) -> str:
        """Return the stable semantic state hash."""


@dataclass(frozen=True)
class NumpyArrayBackend:
    """CPU NumPy implementation of the scalable array boundary."""

    backend_id: str = "numpy.cpu"

    def array(
        self,
        value: object,
        *,
        dtype: ArrayDType,
        copy: bool = True,
    ) -> ComplexArray:
        return np.array(value, dtype=np.dtype(dtype), copy=copy)

    def zeros(self, shape: tuple[int, ...], *, dtype: ArrayDType) -> ComplexArray:
        return np.zeros(shape, dtype=np.dtype(dtype))


@dataclass(frozen=True)
class ArrayStateProvenance(IRMixin):
    """Compact lineage for a scalable state and explicit representation changes."""

    producer: str
    parent_state_hash: str | None = None
    conversion: str | None = None
    step_index: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = ARRAY_STATE_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if not isinstance(self.producer, str) or not self.producer.strip():
            raise ValueError("provenance producer must be a non-empty string.")
        if self.parent_state_hash is not None:
            _require_hash(self.parent_state_hash, "parent_state_hash")
        if self.conversion is not None and not self.conversion.strip():
            raise ValueError("conversion must be non-empty when provided.")
        if (
            not isinstance(self.step_index, int)
            or isinstance(self.step_index, bool)
            or self.step_index < 0
        ):
            raise ValueError("step_index must be a non-negative integer.")
        if not isinstance(self.metadata, dict):
            raise TypeError("provenance metadata must be a dictionary.")
        object.__setattr__(self, "metadata", dict(self.metadata))

    @classmethod
    def initial(cls, producer: str) -> ArrayStateProvenance:
        return cls(producer=producer)


@dataclass(frozen=True)
class StateVectorState:
    """Normalized immutable full-space pure state."""

    amplitudes: ComplexArray
    logical_order: tuple[str, ...]
    basis: str = "logical_two_level"
    logical_time: float = 0.0
    time_unit: str = "us"
    noise_context: ContextItems = ()
    provenance: ArrayStateProvenance = field(
        default_factory=lambda: ArrayStateProvenance.initial("StateVectorState")
    )
    schema_version: str = ARRAY_STATE_SCHEMA_VERSION

    def __post_init__(self) -> None:
        order = _validate_common_state(self)
        amplitudes = _immutable_complex_array(self.amplitudes)
        if amplitudes.ndim != 1 or amplitudes.shape != (2 ** len(order),):
            raise ValueError("amplitudes shape must be (2 ** logical_sites,).")
        _validate_finite(amplitudes, "amplitudes")
        _validate_normalized_rows(amplitudes[np.newaxis, :], "amplitudes")
        object.__setattr__(self, "amplitudes", amplitudes)

    @property
    def dtype(self) -> str:
        return self.amplitudes.dtype.name

    @property
    def dimension(self) -> int:
        return int(self.amplitudes.size)

    @property
    def content_hash(self) -> str:
        return _array_content_hash(self.amplitudes)

    def stable_hash(self) -> str:
        return _state_hash(self, arrays={"amplitudes": self.content_hash})

    def to_dict(self) -> dict[str, Any]:
        return _state_summary(
            self,
            state_kind="state_vector",
            arrays={"amplitudes": _array_summary(self.amplitudes)},
            metrics={"norm": float(np.linalg.norm(self.amplitudes))},
        )

    def to_density(self) -> DensityMatrixState:
        rho = np.outer(self.amplitudes, np.conjugate(self.amplitudes))
        return DensityMatrixState(
            rho=rho,
            logical_order=self.logical_order,
            basis=self.basis,
            logical_time=self.logical_time,
            time_unit=self.time_unit,
            noise_context=self.noise_context,
            provenance=_conversion_provenance(self, "pure_to_density"),
        )

    def to_trajectory_batch(
        self,
        trajectories: int,
        *,
        seed: int = 0,
    ) -> TrajectoryBatchState:
        _positive_int(trajectories, "trajectories")
        _integer(seed, "seed")
        amplitudes = np.repeat(self.amplitudes[np.newaxis, :], trajectories, axis=0)
        seeds = np.arange(seed, seed + trajectories, dtype=np.uint64)
        return TrajectoryBatchState(
            amplitudes=amplitudes,
            trajectory_seeds=seeds,
            jump_counts=np.zeros(trajectories, dtype=np.int64),
            occupations=np.ones(
                (trajectories, len(self.logical_order)),
                dtype=np.bool_,
            ),
            logical_order=self.logical_order,
            basis=self.basis,
            logical_time=self.logical_time,
            time_unit=self.time_unit,
            noise_context=self.noise_context,
            provenance=_conversion_provenance(self, "pure_to_trajectory_batch"),
        )

    def to_subspace(self, basis_indices: Sequence[int]) -> SubspaceState:
        basis = np.asarray(tuple(basis_indices), dtype=np.int64)
        _validate_subspace_basis(basis, self.dimension)
        mask = np.ones(self.dimension, dtype=np.bool_)
        mask[basis] = False
        if np.any(np.abs(self.amplitudes[mask]) > _NORMALIZATION_TOLERANCE):
            raise ValueError("state has non-zero support outside requested subspace.")
        return SubspaceState(
            amplitudes=self.amplitudes[basis],
            basis_indices=basis,
            logical_order=self.logical_order,
            basis=self.basis,
            logical_time=self.logical_time,
            time_unit=self.time_unit,
            noise_context=self.noise_context,
            provenance=_conversion_provenance(self, "full_to_subspace"),
        )


@dataclass(frozen=True)
class DensityMatrixState:
    """Immutable positive-semidefinite unit-trace density state."""

    rho: ComplexArray
    logical_order: tuple[str, ...]
    basis: str = "logical_two_level"
    logical_time: float = 0.0
    time_unit: str = "us"
    noise_context: ContextItems = ()
    provenance: ArrayStateProvenance = field(
        default_factory=lambda: ArrayStateProvenance.initial("DensityMatrixState")
    )
    schema_version: str = ARRAY_STATE_SCHEMA_VERSION

    def __post_init__(self) -> None:
        order = _validate_common_state(self)
        rho = _immutable_complex_array(self.rho)
        dimension = 2 ** len(order)
        if rho.ndim != 2 or rho.shape != (dimension, dimension):
            raise ValueError("rho shape must be (2 ** logical_sites,) repeated twice.")
        _validate_finite(rho, "rho")
        if not np.allclose(rho, np.conjugate(rho.T), rtol=0.0, atol=_DENSITY_TOLERANCE):
            raise ValueError("rho must be Hermitian.")
        trace = np.trace(rho)
        if not np.isclose(trace, 1.0, rtol=0.0, atol=_DENSITY_TOLERANCE):
            raise ValueError("rho must have unit trace.")
        minimum_eigenvalue = float(np.min(np.linalg.eigvalsh(rho)))
        if minimum_eigenvalue < -_DENSITY_TOLERANCE:
            raise ValueError("rho must be positive semidefinite.")
        object.__setattr__(self, "rho", rho)

    @property
    def dtype(self) -> str:
        return self.rho.dtype.name

    @property
    def dimension(self) -> int:
        return int(self.rho.shape[0])

    @property
    def content_hash(self) -> str:
        return _array_content_hash(self.rho)

    @property
    def trace(self) -> float:
        return float(np.trace(self.rho).real)

    @property
    def purity(self) -> float:
        # Hermiticity makes Tr(rho^2) equal to the Frobenius inner product.
        return float(np.vdot(self.rho, self.rho).real)

    @property
    def minimum_eigenvalue(self) -> float:
        return float(np.min(np.linalg.eigvalsh(self.rho)))

    def stable_hash(self) -> str:
        return _state_hash(self, arrays={"rho": self.content_hash})

    def to_dict(self) -> dict[str, Any]:
        return _state_summary(
            self,
            state_kind="density_matrix",
            arrays={"rho": _array_summary(self.rho)},
            metrics={
                "trace": self.trace,
                "purity": self.purity,
                "minimum_eigenvalue": self.minimum_eigenvalue,
            },
        )


@dataclass(frozen=True)
class TrajectoryBatchState:
    """Immutable batch of normalized stochastic pure-state trajectories."""

    amplitudes: ComplexArray
    trajectory_seeds: IntegerArray
    jump_counts: IntegerArray
    occupations: BooleanArray
    logical_order: tuple[str, ...]
    basis: str = "logical_two_level"
    logical_time: float = 0.0
    time_unit: str = "us"
    noise_context: ContextItems = ()
    provenance: ArrayStateProvenance = field(
        default_factory=lambda: ArrayStateProvenance.initial("TrajectoryBatchState")
    )
    schema_version: str = ARRAY_STATE_SCHEMA_VERSION

    def __post_init__(self) -> None:
        order = _validate_common_state(self)
        amplitudes = _immutable_complex_array(self.amplitudes)
        seeds = _immutable_integer_array(self.trajectory_seeds, "trajectory_seeds")
        jumps = _immutable_integer_array(self.jump_counts, "jump_counts")
        occupations = _immutable_array(self.occupations, np.dtype(np.bool_))
        if amplitudes.ndim != 2 or amplitudes.shape[1] != 2 ** len(order):
            raise ValueError("trajectory amplitudes shape must be (T, 2 ** sites).")
        trajectories = amplitudes.shape[0]
        if trajectories <= 0:
            raise ValueError("trajectory batch must contain at least one trajectory.")
        if seeds.shape != (trajectories,) or jumps.shape != (trajectories,):
            raise ValueError("trajectory seed and jump arrays must have shape (T,).")
        if occupations.shape != (trajectories, len(order)):
            raise ValueError("occupations shape must be (T, logical_sites).")
        if np.any(jumps < 0):
            raise ValueError("jump_counts must be non-negative.")
        _validate_finite(amplitudes, "amplitudes")
        _validate_normalized_rows(amplitudes, "amplitudes")
        object.__setattr__(self, "amplitudes", amplitudes)
        object.__setattr__(self, "trajectory_seeds", seeds)
        object.__setattr__(self, "jump_counts", jumps)
        object.__setattr__(self, "occupations", occupations)

    @property
    def dtype(self) -> str:
        return self.amplitudes.dtype.name

    @property
    def trajectory_count(self) -> int:
        return int(self.amplitudes.shape[0])

    @property
    def dimension(self) -> int:
        return int(self.amplitudes.shape[1])

    @property
    def content_hash(self) -> str:
        return _combined_array_hash(
            self.amplitudes,
            self.trajectory_seeds,
            self.jump_counts,
            self.occupations,
        )

    def stable_hash(self) -> str:
        return _state_hash(self, arrays={"batch": self.content_hash})

    def to_dict(self) -> dict[str, Any]:
        return _state_summary(
            self,
            state_kind="trajectory_batch",
            arrays={
                "amplitudes": _array_summary(self.amplitudes),
                "trajectory_seeds": _array_summary(self.trajectory_seeds),
                "jump_counts": _array_summary(self.jump_counts),
                "occupations": _array_summary(self.occupations),
            },
            metrics={
                "trajectory_count": self.trajectory_count,
                "total_jump_count": int(np.sum(self.jump_counts)),
            },
        )


@dataclass(frozen=True)
class SubspaceState:
    """Immutable pure state over an explicit ordered full-space basis subset."""

    amplitudes: ComplexArray
    basis_indices: IntegerArray
    logical_order: tuple[str, ...]
    basis: str = "logical_two_level"
    logical_time: float = 0.0
    time_unit: str = "us"
    noise_context: ContextItems = ()
    provenance: ArrayStateProvenance = field(
        default_factory=lambda: ArrayStateProvenance.initial("SubspaceState")
    )
    schema_version: str = ARRAY_STATE_SCHEMA_VERSION

    def __post_init__(self) -> None:
        order = _validate_common_state(self)
        amplitudes = _immutable_complex_array(self.amplitudes)
        basis_indices = _immutable_integer_array(self.basis_indices, "basis_indices")
        if amplitudes.ndim != 1 or basis_indices.ndim != 1:
            raise ValueError("subspace amplitudes and basis_indices must be vectors.")
        if amplitudes.shape != basis_indices.shape:
            raise ValueError("subspace amplitudes and basis_indices shapes must match.")
        _validate_subspace_basis(basis_indices, 2 ** len(order))
        _validate_finite(amplitudes, "amplitudes")
        _validate_normalized_rows(amplitudes[np.newaxis, :], "amplitudes")
        object.__setattr__(self, "amplitudes", amplitudes)
        object.__setattr__(self, "basis_indices", basis_indices)

    @property
    def dtype(self) -> str:
        return self.amplitudes.dtype.name

    @property
    def dimension(self) -> int:
        return int(self.amplitudes.size)

    @property
    def full_dimension(self) -> int:
        return int(2 ** len(self.logical_order))

    @property
    def content_hash(self) -> str:
        return _combined_array_hash(self.amplitudes, self.basis_indices)

    def stable_hash(self) -> str:
        return _state_hash(self, arrays={"subspace": self.content_hash})

    def to_dict(self) -> dict[str, Any]:
        return _state_summary(
            self,
            state_kind="subspace",
            arrays={
                "amplitudes": _array_summary(self.amplitudes),
                "basis_indices": _array_summary(self.basis_indices),
            },
            metrics={
                "subspace_dimension": self.dimension,
                "full_dimension": self.full_dimension,
            },
        )


def _validate_common_state(state: _ArrayStateContract) -> tuple[str, ...]:
    order = tuple(str(item) for item in state.logical_order)
    if not order or any(not item for item in order) or len(set(order)) != len(order):
        raise ValueError("logical_order must contain unique non-empty identifiers.")
    basis = state.basis
    if not isinstance(basis, str) or not basis.strip():
        raise ValueError("basis must be a non-empty string.")
    logical_time = state.logical_time
    if (
        not isinstance(logical_time, (int, float))
        or isinstance(logical_time, bool)
        or not math.isfinite(float(logical_time))
        or float(logical_time) < 0.0
    ):
        raise ValueError("logical_time must be finite and non-negative.")
    time_unit = state.time_unit
    if not isinstance(time_unit, str) or not time_unit.strip():
        raise ValueError("time_unit must be a non-empty string.")
    provenance = state.provenance
    if not isinstance(provenance, ArrayStateProvenance):
        raise TypeError("provenance must be ArrayStateProvenance.")
    context = _normalize_context(state.noise_context)
    object.__setattr__(state, "logical_order", order)
    object.__setattr__(state, "logical_time", float(logical_time))
    object.__setattr__(state, "noise_context", context)
    return order


def _immutable_complex_array(value: object) -> ComplexArray:
    source = np.asarray(value)
    if source.dtype not in {np.dtype(np.complex64), np.dtype(np.complex128)}:
        raise TypeError("state arrays must use complex64 or complex128 dtype.")
    return _immutable_array(source, source.dtype)


def _immutable_integer_array(value: object, field_name: str) -> IntegerArray:
    source = np.asarray(value)
    if not np.issubdtype(source.dtype, np.integer):
        raise TypeError(f"{field_name} must use an integer dtype.")
    return _immutable_array(source, source.dtype)


def _immutable_array(
    value: object,
    dtype: np.dtype[_ArrayT],
) -> NDArray[_ArrayT]:
    output: NDArray[_ArrayT] = np.array(value, dtype=dtype, copy=True, order="C")
    output.setflags(write=False)
    return output


def _validate_finite(array: ComplexArray, field_name: str) -> None:
    if not bool(np.all(np.isfinite(array))):
        raise ValueError(f"{field_name} must contain only finite values.")


def _validate_normalized_rows(array: ComplexArray, field_name: str) -> None:
    norms = np.sum(np.abs(array) ** 2, axis=1)
    tolerance = (
        _COMPLEX64_NORMALIZATION_TOLERANCE
        if array.dtype == np.complex64
        else 1e-10
    )
    if not bool(np.allclose(norms, 1.0, rtol=0.0, atol=tolerance)):
        raise ValueError(f"{field_name} rows must be normalized.")


def _validate_subspace_basis(basis: IntegerArray, full_dimension: int) -> None:
    if basis.ndim != 1 or basis.size <= 0:
        raise ValueError("basis_indices must be a non-empty vector.")
    if np.any(basis < 0) or np.any(basis >= full_dimension):
        raise ValueError("basis_indices entries must be inside the full Hilbert space.")
    if np.unique(basis).size != basis.size:
        raise ValueError("basis_indices entries must be unique.")


def _normalize_context(context: ContextInput) -> ContextItems:
    items = context.items() if isinstance(context, Mapping) else context
    normalized: list[tuple[str, ContextScalar]] = []
    for key, value in items:
        name = str(key)
        if not name:
            raise ValueError("noise context keys must not be empty.")
        if value is not None and not isinstance(value, (bool, int, float, str)):
            raise TypeError("noise context values must be scalar JSON values.")
        if isinstance(value, float) and not math.isfinite(value):
            raise ValueError("noise context float values must be finite.")
        normalized.append((name, value))
    normalized.sort(key=lambda item: item[0])
    if len({key for key, _ in normalized}) != len(normalized):
        raise ValueError("noise context keys must be unique.")
    return tuple(normalized)


def _array_content_hash(array: NDArray[Any]) -> str:
    digest = hashlib.sha256()
    digest.update(array.dtype.str.encode("ascii"))
    digest.update(stable_json(list(array.shape)).encode("ascii"))
    digest.update(array.tobytes(order="C"))
    return digest.hexdigest()


def _combined_array_hash(*arrays: NDArray[Any]) -> str:
    digest = hashlib.sha256()
    for array in arrays:
        digest.update(_array_content_hash(array).encode("ascii"))
    return digest.hexdigest()


def _array_summary(array: NDArray[Any]) -> dict[str, Any]:
    return {
        "shape": list(array.shape),
        "dtype": array.dtype.name,
        "nbytes": int(array.nbytes),
        "content_hash": _array_content_hash(array),
        "returned_state_bytes": False,
    }


def _state_hash(state: _ArrayStateContract, *, arrays: dict[str, str]) -> str:
    payload = _common_summary(state)
    payload["array_hashes"] = arrays
    return hashlib.sha256(stable_json(payload).encode("ascii")).hexdigest()


def _state_summary(
    state: _ArrayStateContract,
    *,
    state_kind: str,
    arrays: dict[str, dict[str, Any]],
    metrics: dict[str, Any],
) -> dict[str, Any]:
    output = _common_summary(state)
    output.update(
        {
            "state_kind": state_kind,
            "arrays": arrays,
            "metrics": metrics,
            "stable_hash": state.stable_hash(),
            "returned_state_bytes": False,
        }
    )
    return output


def _common_summary(state: _ArrayStateContract) -> dict[str, Any]:
    provenance = state.provenance
    return {
        "basis": state.basis,
        "logical_order": list(state.logical_order),
        "logical_time": state.logical_time,
        "time_unit": state.time_unit,
        "noise_context": dict(state.noise_context),
        "provenance": provenance.to_dict(),
        "schema_version": state.schema_version,
    }


def _conversion_provenance(
    source: StateVectorState,
    conversion: str,
) -> ArrayStateProvenance:
    return ArrayStateProvenance(
        producer=f"StateVectorState.{conversion}",
        parent_state_hash=source.stable_hash(),
        conversion=conversion,
        step_index=source.provenance.step_index + 1,
    )


def _positive_int(value: object, field_name: str) -> None:
    if not isinstance(value, int) or isinstance(value, bool) or value <= 0:
        raise ValueError(f"{field_name} must be a positive integer.")


def _integer(value: object, field_name: str) -> None:
    if not isinstance(value, int) or isinstance(value, bool):
        raise TypeError(f"{field_name} must be an integer.")


def _require_hash(value: object, field_name: str) -> None:
    if (
        not isinstance(value, str)
        or len(value) != 64
        or any(character not in "0123456789abcdef" for character in value)
    ):
        raise ValueError(f"{field_name} must be a lowercase SHA-256 digest.")
