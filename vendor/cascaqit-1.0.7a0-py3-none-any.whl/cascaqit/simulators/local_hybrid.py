"""Native payload contracts for the local hybrid simulator."""

from __future__ import annotations

import hashlib
import json
import random
from collections import Counter
from collections.abc import Iterable
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field, replace
from typing import (
    TYPE_CHECKING,
    Any,
    Callable,
    Literal,
    NoReturn,
    Protocol,
    Union,
    cast,
)

from cascaqit.backends.job_state import JobState, validate_job_state
from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.digital import DigitalMeasurementIR, DigitalProgramIR
from cascaqit.exceptions import CASCAQitRuntimeError, ProgramValidationError
from cascaqit.hybrid import (
    LocalExecutionPlan,
    LocalExecutionStep,
    OrchestrationDiagnosticIR,
)
from cascaqit.native_ir import ProgramIR, WaveformIR
from cascaqit.native_ir.base import IRMixin
from cascaqit.observables import ObservableSet
from cascaqit.parameters import ParameterManager, ParameterScan
from cascaqit.parameters.ir import ParameterBindIR
from cascaqit.parameters.mapping import validate_parameter_targets
from cascaqit.results import (
    ResultIR,
    ResultReferencesIR,
    RunTraceEventIR,
    RunTraceIR,
    SimulationSolverEvidenceIR,
    StateTransitionIR,
    result_references_from_result,
    simulation_execution_config_from_metadata,
    simulation_solver_evidence_from_metadata,
)
from cascaqit.results.resource_usage import (
    LocalResourceMeasurement,
    estimated_peak_bytes_from_metadata,
)
from cascaqit.simulators.addressing import site_addressing_provenance_metadata
from cascaqit.simulators.digital import DigitalStateVectorKernel
from cascaqit.simulators.execution_evidence import (
    aggregate_solver_evidence,
    execution_config_metadata,
    not_applicable_solver_evidence,
    require_result_solver_evidence,
    solver_evidence_metadata,
)
from cascaqit.simulators.local_ahs import AnalogStateVectorKernel
from cascaqit.simulators.local_rabi import site_phase_pattern_provenance_metadata
from cascaqit.simulators.planning import (
    SimulationExecutionPlan,
    SimulationOptions,
    SimulationPlanner,
    SimulationPlanningRequest,
    SweepResourcePlanIR,
)
from cascaqit.simulators.register_evidence import collect_register_snapshot_evidence
from cascaqit.simulators.runtime_lineage import (
    build_runtime_references,
    build_runtime_trace,
    build_state_transition,
    runtime_lineage_metadata,
)
from cascaqit.simulators.state import SimulationState
from cascaqit.syntax import SourceSpan

if TYPE_CHECKING:
    from cascaqit.analog import AHSProgram, AtomRegister
    from cascaqit.digital import Circuit
    from cascaqit.simulators.physical_noise import NoiseModel
    from cascaqit.syntax.decorators import BlockDefinition

__all__ = [
    "LOCAL_HYBRID_SCHEMA_VERSION",
    "AnalogStepPayload",
    "AnalogStepAdapter",
    "DigitalStepPayload",
    "DigitalStepAdapter",
    "LocalExecutionBundle",
    "LocalExecutionBundleResult",
    "LocalHybridExecutionBuilder",
    "LocalProgramFactory",
    "LocalHybridStateRun",
    "LocalHybridMeasurementResult",
    "LocalHybridScanFailurePolicy",
    "LocalHybridScanItemResult",
    "LocalHybridScanItemOutcome",
    "LocalHybridScanItemState",
    "LocalHybridScanJobResult",
    "LocalHybridScanJobStatusIR",
    "LocalHybridScanResult",
    "LocalHybridCapabilityIR",
    "LocalHybridJob",
    "LocalHybridJobStatusIR",
    "LocalHybridScanJob",
    "LocalHybridSimulator",
    "LocalStepPayload",
    "MeasurementStepPayload",
    "bind_local_execution_bundle",
    "run_local_hybrid_state",
    "measure_local_hybrid_state",
]

LOCAL_HYBRID_SCHEMA_VERSION = "cascaqit.simulators.local_hybrid.v1"
PayloadKind = Literal["digital", "analog", "measurement"]
_ValidationStage = Literal["compile", "simulation"]
_HYBRID_DIGITAL_GATES = frozenset({"h", "x", "rx", "ry", "rz", "cx", "cz"})
_HYBRID_ANALOG_WAVEFORMS = frozenset(
    {
        "constant",
        "linear",
        "piecewise_constant",
        "piecewise_linear",
        "interpolated",
    }
)


def _require_identifier(value: object, *, field_name: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field_name} must be a non-empty string.")


def _normalize_logical_order(value: object) -> tuple[str, ...]:
    if not isinstance(value, (tuple, list)):
        raise TypeError("logical_order must be a tuple or list of strings.")
    if any(not isinstance(item, str) for item in value):
        raise TypeError("logical_order must contain strings.")
    order = tuple(value)
    if not order or any(not item.strip() for item in order):
        raise ValueError("logical_order must contain non-empty logical ids.")
    if len(set(order)) != len(order):
        raise ValueError("logical_order ids must be unique.")
    return order


def _validate_common_payload(
    *,
    payload_id: object,
    block_id: object,
    payload_kind: object,
    expected_kind: PayloadKind,
    logical_order: object,
    source_span: object,
    metadata: object,
    schema_version: object,
) -> tuple[tuple[str, ...], dict[str, Any]]:
    _require_identifier(payload_id, field_name="payload_id")
    _require_identifier(block_id, field_name="block_id")
    if payload_kind != expected_kind:
        raise ValueError(f"payload_kind must be '{expected_kind}'.")
    order = _normalize_logical_order(logical_order)
    if source_span is not None and not isinstance(source_span, SourceSpan):
        raise TypeError("source_span must be SourceSpan or None.")
    if not isinstance(metadata, dict):
        raise TypeError("metadata must be a dictionary.")
    _require_identifier(schema_version, field_name="schema_version")
    return order, dict(metadata)


def _json_object(text: str, *, type_name: str) -> dict[str, Any]:
    data = json.loads(text)
    if not isinstance(data, dict):
        raise TypeError(f"{type_name} JSON must contain an object.")
    return data


def _require_hash(value: object, *, field_name: str) -> None:
    if (
        not isinstance(value, str)
        or len(value) != 64
        or any(character not in "0123456789abcdef" for character in value)
    ):
        raise ValueError(f"{field_name} must be a lowercase SHA-256 hex digest.")


@dataclass(frozen=True)
class DigitalStepPayload(IRMixin):
    """Native digital program bound to one local execution step."""

    payload_id: str
    block_id: str
    program: DigitalProgramIR
    logical_order: tuple[str, ...]
    payload_kind: Literal["digital"] = "digital"
    source_span: SourceSpan | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = LOCAL_HYBRID_SCHEMA_VERSION

    def __post_init__(self) -> None:
        order, metadata = _validate_common_payload(
            payload_id=self.payload_id,
            block_id=self.block_id,
            payload_kind=self.payload_kind,
            expected_kind="digital",
            logical_order=self.logical_order,
            source_span=self.source_span,
            metadata=self.metadata,
            schema_version=self.schema_version,
        )
        if not isinstance(self.program, DigitalProgramIR):
            raise TypeError("program must be a native DigitalProgramIR.")
        if self.program.program_type != "digital":
            raise ValueError("digital payload program_type must be 'digital'.")
        if self.program.circuit.measurements:
            raise ValueError(
                "digital payload programs cannot contain embedded measurements."
            )
        program_order = tuple(self.program.circuit.qubits)
        if order != program_order:
            raise ValueError(
                "logical_order must exactly match the digital circuit qubit order."
            )
        object.__setattr__(self, "logical_order", order)
        object.__setattr__(self, "metadata", metadata)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DigitalStepPayload:
        """Build a digital step payload from a dictionary."""
        span_data = data.get("source_span")
        return cls(
            payload_id=data["payload_id"],
            block_id=data["block_id"],
            program=DigitalProgramIR.from_dict(data["program"]),
            logical_order=data["logical_order"],
            payload_kind=data.get("payload_kind", "digital"),
            source_span=(
                None if span_data is None else SourceSpan.from_dict(span_data)
            ),
            metadata=data.get("metadata", {}),
            schema_version=data.get(
                "schema_version",
                LOCAL_HYBRID_SCHEMA_VERSION,
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> DigitalStepPayload:
        """Build a digital step payload from JSON text."""
        return cls.from_dict(_json_object(text, type_name=cls.__name__))


@dataclass(frozen=True)
class AnalogStepPayload(IRMixin):
    """Native analog program bound to one local execution step."""

    payload_id: str
    block_id: str
    program: ProgramIR
    logical_order: tuple[str, ...]
    payload_kind: Literal["analog"] = "analog"
    source_span: SourceSpan | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = LOCAL_HYBRID_SCHEMA_VERSION

    def __post_init__(self) -> None:
        order, metadata = _validate_common_payload(
            payload_id=self.payload_id,
            block_id=self.block_id,
            payload_kind=self.payload_kind,
            expected_kind="analog",
            logical_order=self.logical_order,
            source_span=self.source_span,
            metadata=self.metadata,
            schema_version=self.schema_version,
        )
        if not isinstance(self.program, ProgramIR):
            raise TypeError("program must be a native analog ProgramIR.")
        if self.program.program_type != "analog":
            raise ValueError("analog payload program_type must be 'analog'.")
        if self.program.measurements:
            raise ValueError(
                "analog payload programs cannot contain embedded measurements."
            )
        program_order = tuple(
            str(site.atom_id) for site in self.program.register.sites if site.is_active
        )
        if order != program_order:
            raise ValueError(
                "logical_order must exactly match the active analog atom order."
            )
        object.__setattr__(self, "logical_order", order)
        object.__setattr__(self, "metadata", metadata)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> AnalogStepPayload:
        """Build an analog step payload from a dictionary."""
        span_data = data.get("source_span")
        return cls(
            payload_id=data["payload_id"],
            block_id=data["block_id"],
            program=ProgramIR.from_dict(data["program"]),
            logical_order=data["logical_order"],
            payload_kind=data.get("payload_kind", "analog"),
            source_span=(
                None if span_data is None else SourceSpan.from_dict(span_data)
            ),
            metadata=data.get("metadata", {}),
            schema_version=data.get(
                "schema_version",
                LOCAL_HYBRID_SCHEMA_VERSION,
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> AnalogStepPayload:
        """Build an analog step payload from JSON text."""
        return cls.from_dict(_json_object(text, type_name=cls.__name__))


@dataclass(frozen=True)
class MeasurementStepPayload(IRMixin):
    """Terminal computational-basis measurement for a local hybrid run."""

    payload_id: str
    block_id: str
    measurement: DigitalMeasurementIR
    logical_order: tuple[str, ...]
    shots: int
    seed: int | None = None
    terminal: bool = True
    payload_kind: Literal["measurement"] = "measurement"
    source_span: SourceSpan | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = LOCAL_HYBRID_SCHEMA_VERSION

    def __post_init__(self) -> None:
        order, metadata = _validate_common_payload(
            payload_id=self.payload_id,
            block_id=self.block_id,
            payload_kind=self.payload_kind,
            expected_kind="measurement",
            logical_order=self.logical_order,
            source_span=self.source_span,
            metadata=self.metadata,
            schema_version=self.schema_version,
        )
        if not isinstance(self.measurement, DigitalMeasurementIR):
            raise TypeError("measurement must be a native DigitalMeasurementIR.")
        if self.measurement.basis != "computational":
            raise ValueError("measurement basis must be 'computational'.")
        if tuple(self.measurement.targets) != order:
            raise ValueError("measurement targets must exactly match logical_order.")
        _require_identifier(
            self.measurement.measurement_id,
            field_name="measurement_id",
        )
        _require_identifier(self.measurement.key, field_name="measurement key")
        if self.terminal is not True:
            raise ValueError("local hybrid measurement must be terminal.")
        if (
            not isinstance(self.shots, int)
            or isinstance(self.shots, bool)
            or self.shots <= 0
        ):
            raise ValueError("shots must be a positive integer.")
        if self.seed is not None and (
            not isinstance(self.seed, int) or isinstance(self.seed, bool)
        ):
            raise TypeError("seed must be an integer or None.")
        object.__setattr__(self, "logical_order", order)
        object.__setattr__(self, "metadata", metadata)

    @property
    def basis(self) -> Literal["computational"]:
        """Return the only measurement basis supported by the P0 runner."""
        return "computational"

    @property
    def measurement_key(self) -> str:
        """Return the native measurement result key."""
        return self.measurement.key

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> MeasurementStepPayload:
        """Build a measurement step payload from a dictionary."""
        span_data = data.get("source_span")
        return cls(
            payload_id=data["payload_id"],
            block_id=data["block_id"],
            measurement=DigitalMeasurementIR.from_dict(data["measurement"]),
            logical_order=data["logical_order"],
            shots=data["shots"],
            seed=data.get("seed"),
            terminal=data.get("terminal", True),
            payload_kind=data.get("payload_kind", "measurement"),
            source_span=(
                None if span_data is None else SourceSpan.from_dict(span_data)
            ),
            metadata=data.get("metadata", {}),
            schema_version=data.get(
                "schema_version",
                LOCAL_HYBRID_SCHEMA_VERSION,
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> MeasurementStepPayload:
        """Build a measurement step payload from JSON text."""
        return cls.from_dict(_json_object(text, type_name=cls.__name__))


LocalStepPayload = Union[
    DigitalStepPayload,
    AnalogStepPayload,
    MeasurementStepPayload,
]


class LocalProgramFactory(Protocol):
    """Build one native Digital or Analog program from a parameter bind set."""

    def __call__(
        self,
        bind_set: ParameterBindIR,
    ) -> Circuit | DigitalProgramIR | AHSProgram | ProgramIR:
        """Return a native user program for one local execution block."""
        ...


class LocalHybridExecutionBuilder:
    """Bind native user programs to an immutable local execution plan."""

    def __init__(self, plan: LocalExecutionPlan) -> None:
        if not isinstance(plan, LocalExecutionPlan):
            raise TypeError("plan must be LocalExecutionPlan.")
        self._plan = plan
        self._payloads: dict[str, LocalStepPayload] = {}
        self._factories: dict[str, LocalProgramFactory] = {}
        self._factory_cache: dict[tuple[str, str], LocalStepPayload] = {}

    @property
    def plan(self) -> LocalExecutionPlan:
        """Return the unchanged static plan used by this builder."""
        return self._plan

    @property
    def payloads(self) -> tuple[LocalStepPayload, ...]:
        """Return currently bound payloads in plan step order."""
        return tuple(
            self._payloads[step.block_id]
            for step in self._plan.steps
            if step.block_id in self._payloads
        )

    @property
    def bound_block_ids(self) -> tuple[str, ...]:
        """Return bound block ids in plan step order."""
        bound = set(self._payloads).union(self._factories)
        return tuple(
            step.block_id for step in self._plan.steps if step.block_id in bound
        )

    @property
    def has_errors(self) -> bool:
        """Return whether current bindings fail existing Bundle validation."""
        return bool(self.diagnostics())

    def diagnostics(
        self,
        *,
        bind_set: ParameterBindIR | None = None,
    ) -> tuple[OrchestrationDiagnosticIR, ...]:
        """Validate current bindings without executing a simulator kernel."""
        return self.build(bind_set=bind_set).diagnostics

    def build(
        self,
        *,
        bind_set: ParameterBindIR | None = None,
        bundle_id: str | None = None,
    ) -> LocalExecutionBundleResult:
        """Build a ready Bundle or return the existing binding diagnostics."""
        if bind_set is not None and not isinstance(bind_set, ParameterBindIR):
            raise TypeError("bind_set must be ParameterBindIR or None.")
        if self._factories and bind_set is None:
            return LocalExecutionBundleResult(
                bundle=None,
                diagnostics=(self._bind_set_required_diagnostic(),),
            )
        return bind_local_execution_bundle(
            self._plan,
            self.payloads if bind_set is None else self._resolved_payloads(bind_set),
            bundle_id=bundle_id,
        )

    def run(
        self,
        *,
        simulator: LocalHybridSimulator | None = None,
        initial_state: SimulationState | None = None,
        job_id: str | None = None,
        bind_set: ParameterBindIR | None = None,
        bundle_id: str | None = None,
        backend_id: str = "local.hybrid_simulator",
        backend_called: bool = False,
        execution_metadata: dict[str, Any] | None = None,
    ) -> LocalHybridJob:
        """Build the Bundle and return a submitted existing local Job."""
        if simulator is not None and not isinstance(simulator, LocalHybridSimulator):
            raise TypeError("simulator must be LocalHybridSimulator or None.")
        if initial_state is not None and not isinstance(
            initial_state,
            SimulationState,
        ):
            raise TypeError("initial_state must be SimulationState or None.")
        result = self.build(bind_set=bind_set, bundle_id=bundle_id)
        if result.bundle is None:
            diagnostics = result.diagnostics
            raise ProgramValidationError(
                "Local hybrid execution builder is not ready to run.",
                code="LOCAL_HYBRID_BUILDER_NOT_READY",
                stage="compile",
                object_path="builder.bindings",
                suggestion="Resolve every binding diagnostic before run().",
                metadata={
                    "diagnostic_codes": [item.code for item in diagnostics],
                    "binding_diagnostics": [item.to_dict() for item in diagnostics],
                },
            )
        executor = simulator or LocalHybridSimulator()
        return executor.run(
            result.bundle,
            initial_state=initial_state,
            job_id=job_id,
            backend_id=backend_id,
            backend_called=backend_called,
            execution_metadata=execution_metadata,
        )

    def run_scan(
        self,
        scan: ParameterScan,
        manager: ParameterManager,
        *,
        simulator: LocalHybridSimulator | None = None,
        initial_state: SimulationState | None = None,
        options: SimulationOptions | None = None,
    ) -> LocalHybridScanResult:
        """Run a validated parameter scan with strict fail-fast semantics."""
        job = self.submit_scan(
            scan,
            manager,
            simulator=simulator,
            initial_state=initial_state,
            options=options,
            failure_policy="fail_fast",
        )
        aggregate = job.result()
        self._factory_cache.update(job.builder._factory_cache)
        if aggregate.status.state != "completed":
            failed = aggregate.failed_items[0]
            completed = tuple(
                item
                for item in aggregate.successful_items
                if item.scan_index < failed.scan_index
            )
            cause = job._failure_causes[failed.scan_index]
            raise ProgramValidationError(
                "Local hybrid parameter scan failed at one bind point.",
                code="LOCAL_HYBRID_SCAN_POINT_FAILED",
                stage="simulation",
                object_path=(
                    f"parameter_scans.{scan.scan_id}.points[{failed.scan_index}]"
                ),
                suggestion="Fix the failing factory or program before retrying.",
                metadata={
                    "scan_id": scan.scan_id,
                    "scan_index": failed.scan_index,
                    "parameter_bind_id": failed.bind_set.parameter_bind_id,
                    "parameter_bind_hash": failed.bind_set.parameter_bind_hash,
                    "completed_bind_ids": [
                        item.bind_set.parameter_bind_id for item in completed
                    ],
                    "completed_result_ids": [
                        item.result.result_id
                        for item in completed
                        if item.result is not None
                    ],
                },
                cause=cause,
            ) from cause
        items = tuple(
            LocalHybridScanItemResult(
                scan_index=item.scan_index,
                bind_set=item.bind_set,
                job_id=cast(str, item.job_id),
                measurement_result=cast(
                    LocalHybridMeasurementResult,
                    item.measurement_result,
                ),
            )
            for item in aggregate.items
        )
        return LocalHybridScanResult(
            scan_id=scan.scan_id,
            plan_hash=self._plan.stable_hash(),
            items=items,
            metadata={
                "parameter_scan_hash": scan.stable_hash(),
                "parameter_schema_hash": aggregate.parameter_schema_hash,
                "run_count": len(items),
                "execution_mode": "resource_bounded_scan",
                "scan_resource_plan": aggregate.metadata["scan_resource_plan"],
                "simulation_resource_usage": aggregate.metadata[
                    "simulation_resource_usage"
                ],
                "backend_called": False,
                "network_accessed": False,
                "execution_package_created": False,
            },
        )

    def submit_scan(
        self,
        scan: ParameterScan,
        manager: ParameterManager,
        *,
        simulator: LocalHybridSimulator | None = None,
        initial_state: SimulationState | None = None,
        options: SimulationOptions | None = None,
        failure_policy: LocalHybridScanFailurePolicy = "fail_fast",
        job_id: str | None = None,
        backend_id: str = "local.hybrid_simulator",
        backend_called: bool = False,
        execution_metadata: dict[str, Any] | None = None,
        _execution_plan: SimulationExecutionPlan | None = None,
        _item_executor: Callable[
            [LocalExecutionBundle, str], LocalHybridMeasurementResult
        ]
        | None = None,
    ) -> LocalHybridScanJob:
        """Validate and snapshot a submitted local hybrid scan job."""
        if not isinstance(scan, ParameterScan):
            raise TypeError("scan must be ParameterScan.")
        if not isinstance(manager, ParameterManager):
            raise TypeError("manager must be ParameterManager.")
        if options is not None and not isinstance(options, SimulationOptions):
            raise TypeError("options must be SimulationOptions or None.")
        if _execution_plan is not None and not isinstance(
            _execution_plan,
            SimulationExecutionPlan,
        ):
            raise TypeError("_execution_plan must be SimulationExecutionPlan or None.")
        if _item_executor is not None and not callable(_item_executor):
            raise TypeError("_item_executor must be callable or None.")
        if simulator is not None and not isinstance(simulator, LocalHybridSimulator):
            raise TypeError("simulator must be LocalHybridSimulator or None.")
        if initial_state is not None and not isinstance(
            initial_state,
            SimulationState,
        ):
            raise TypeError("initial_state must be SimulationState or None.")
        if failure_policy not in {"fail_fast", "continue_on_error"}:
            raise ValueError(
                "failure_policy must be 'fail_fast' or 'continue_on_error'."
            )
        if execution_metadata is not None and not isinstance(
            execution_metadata,
            dict,
        ):
            raise TypeError("execution_metadata must be a dictionary or None.")

        target_diagnostics = validate_parameter_targets(
            manager.schema,
            self._plan,
            manager.targets,
        )
        if target_diagnostics:
            raise ProgramValidationError(
                "Hybrid parameter targets are invalid for the compiled plan.",
                code="LOCAL_HYBRID_PARAMETER_TARGET_INVALID",
                stage="compile",
                object_path="parameter_targets",
                suggestion="Fix every target before submitting the scan.",
                metadata={
                    "scan_id": scan.scan_id,
                    "diagnostic_codes": [item.code for item in target_diagnostics],
                    "target_diagnostics": [
                        item.to_dict() for item in target_diagnostics
                    ],
                    "completed_bind_ids": [],
                },
                diagnostics=target_diagnostics,
            )
        static_target_ids = tuple(
            sorted(
                target.target_id
                for target in manager.targets
                if target.block_id not in self._factories
            )
        )
        if static_target_ids:
            raise ProgramValidationError(
                "Scanned parameter targets require factory-backed block bindings.",
                code="LOCAL_HYBRID_PARAMETER_TARGET_STATIC_BINDING",
                stage="compile",
                object_path="parameter_targets",
                suggestion=(
                    "Bind every targeted Digital or Analog block with a factory "
                    "that consumes the ParameterBindIR."
                ),
                metadata={
                    "scan_id": scan.scan_id,
                    "target_ids": list(static_target_ids),
                    "completed_bind_ids": [],
                },
            )

        expansion = scan.expand(manager)
        if expansion.has_errors:
            raise ProgramValidationError(
                "Parameter scan is invalid and cannot be submitted.",
                code="LOCAL_HYBRID_SCAN_INVALID",
                stage="compile",
                object_path=f"parameter_scans.{scan.scan_id}",
                suggestion="Resolve every parameter scan diagnostic before submitting.",
                metadata={
                    "scan_id": scan.scan_id,
                    "diagnostic_codes": [item.code for item in expansion.diagnostics],
                    "scan_diagnostics": [
                        item.to_dict() for item in expansion.diagnostics
                    ],
                    "completed_bind_ids": [],
                },
            )
        execution_plan = _execution_plan or self._plan_scan_execution(options)
        resource_plan = SimulationPlanner().plan_sweep(
            execution_plan,
            bind_count=len(expansion.bind_sets),
            failure_policy=failure_policy,
        )

        resolved_job_id = f"local_scan_job.{scan.scan_id}" if job_id is None else job_id
        _require_identifier(resolved_job_id, field_name="job_id")
        snapshot = LocalHybridExecutionBuilder(self._plan)
        snapshot._payloads = dict(self._payloads)
        snapshot._factories = dict(self._factories)
        snapshot._factory_cache = dict(self._factory_cache)
        resolved_simulator = simulator or LocalHybridSimulator()
        item_executor = _item_executor or _make_scan_item_executor(
            execution_plan,
            simulator=resolved_simulator,
            initial_state=initial_state,
            backend_id=backend_id,
            backend_called=backend_called,
            execution_metadata=execution_metadata,
        )
        return LocalHybridScanJob(
            job_id=resolved_job_id,
            scan=scan,
            parameter_schema_hash=expansion.schema_hash,
            bind_sets=expansion.bind_sets,
            builder=snapshot,
            simulator=resolved_simulator,
            initial_state=initial_state,
            failure_policy=failure_policy,
            resource_plan=resource_plan,
            execution_plan=execution_plan,
            backend_id=backend_id,
            backend_called=backend_called,
            execution_metadata=execution_metadata,
            item_executor=item_executor,
        )

    def _plan_scan_execution(
        self,
        options: SimulationOptions | None,
    ) -> SimulationExecutionPlan:
        """Plan direct advanced-builder scans from their terminal state shape."""
        measurement = next(
            (
                payload
                for payload in self._payloads.values()
                if isinstance(payload, MeasurementStepPayload)
            ),
            None,
        )
        if measurement is None:
            raise ProgramValidationError(
                "Parameter scan requires a terminal measurement binding.",
                code="LOCAL_HYBRID_SCAN_MEASUREMENT_MISSING",
                stage="compile",
                object_path="builder.bindings",
            )
        time_integration_required = any(
            step.kernel_kind == "analog" for step in self._plan.steps
        )
        resolved_options = options or SimulationOptions(
            seed=0 if measurement.seed is None else measurement.seed
        )
        # Direct builder scans deliberately execute the small reference kernel. Auto
        # therefore selects its real fixed-step integrator; an explicit adaptive
        # request remains visible to preflight and is rejected rather than downgraded.
        if time_integration_required and resolved_options.integrator == "auto":
            resolved_options = replace(
                resolved_options,
                integrator="fixed_step_krylov",
            )
        return SimulationPlanner().plan(
            SimulationPlanningRequest(
                program_kind="hybrid",
                logical_sites=len(measurement.logical_order),
                time_integration_required=time_integration_required,
                options=resolved_options,
            )
        )

    def bind_digital(
        self,
        block_id: str,
        program: Circuit | DigitalProgramIR,
    ) -> LocalHybridExecutionBuilder:
        """Snapshot and bind a native digital program to a digital step."""
        from cascaqit.digital import Circuit

        step = self._resolve_step(block_id, expected_kind="digital")
        self._ensure_unbound(step)
        if not isinstance(program, (Circuit, DigitalProgramIR)):
            raise TypeError("program must be Circuit or DigitalProgramIR.")
        self._payloads[step.block_id] = self._make_digital_payload(step, program)
        return self

    def bind_analog(
        self,
        block_id: str,
        program: AHSProgram | ProgramIR,
    ) -> LocalHybridExecutionBuilder:
        """Snapshot and bind a native analog program to an analog step."""
        from cascaqit.analog import AHSProgram

        step = self._resolve_step(block_id, expected_kind="analog")
        self._ensure_unbound(step)
        if not isinstance(program, (AHSProgram, ProgramIR)):
            raise TypeError("program must be AHSProgram or ProgramIR.")
        self._payloads[step.block_id] = self._make_analog_payload(step, program)
        return self

    def bind_declaration(
        self,
        block_id: str,
        definition: BlockDefinition,
        *args: object,
        register: AtomRegister | None = None,
        **kwargs: object,
    ) -> LocalHybridExecutionBuilder:
        """Lower and bind one opt-in decorator declaration in a single step."""
        from cascaqit.analog import AHSProgram
        from cascaqit.digital import Circuit
        from cascaqit.syntax.decorators import BlockDefinition

        if not isinstance(definition, BlockDefinition):
            raise TypeError("definition must be BlockDefinition.")
        program = definition.lower(*args, register=register, **kwargs)
        if isinstance(program, Circuit):
            self.bind_digital(block_id, program)
        elif isinstance(program, AHSProgram):
            self.bind_analog(block_id, program)
        else:
            raise TypeError("lowered declaration must be Circuit or AHSProgram.")
        body = definition.body_declaration
        assert body is not None
        payload = self._payloads[block_id]
        self._payloads[block_id] = replace(
            payload,
            metadata={
                **payload.metadata,
                "declaration_source": "decorator_body",
                "body_declaration_hash": body.stable_hash(),
                "function_body_executed": False,
            },
        )
        return self

    def bind_digital_factory(
        self,
        block_id: str,
        factory: LocalProgramFactory,
    ) -> LocalHybridExecutionBuilder:
        """Register a typed parameter factory for one digital step."""
        step = self._resolve_step(
            block_id,
            expected_kind="digital",
            kind_mismatch_code="LOCAL_HYBRID_FACTORY_KIND_MISMATCH",
        )
        self._ensure_unbound(step, factory=True)
        if not callable(factory):
            raise TypeError("factory must be callable.")
        self._factories[step.block_id] = factory
        return self

    def bind_analog_factory(
        self,
        block_id: str,
        factory: LocalProgramFactory,
    ) -> LocalHybridExecutionBuilder:
        """Register a typed parameter factory for one analog step."""
        step = self._resolve_step(
            block_id,
            expected_kind="analog",
            kind_mismatch_code="LOCAL_HYBRID_FACTORY_KIND_MISMATCH",
        )
        self._ensure_unbound(step, factory=True)
        if not callable(factory):
            raise TypeError("factory must be callable.")
        self._factories[step.block_id] = factory
        return self

    def measure(
        self,
        block_id: str,
        *,
        targets: str | Iterable[str],
        shots: int,
        seed: int | None,
        key: str = "result",
    ) -> LocalHybridExecutionBuilder:
        """Bind the only terminal measurement supported by the local runner."""
        step = self._resolve_step(block_id, expected_kind="measurement")
        self._ensure_unbound(step)
        if seed is None:
            self._raise_builder_error(
                step,
                code="LOCAL_HYBRID_BUILDER_SEED_REQUIRED",
                message="Local hybrid measurement requires an explicit seed.",
                object_path="measurement.seed",
                suggestion="Pass an integer seed for deterministic local sampling.",
            )
        target_order = (targets,) if isinstance(targets, str) else tuple(targets)
        logical_order, _ = self._project_resource_order(
            target_order,
            step,
            object_path="measurement.targets",
        )
        try:
            payload = MeasurementStepPayload(
                payload_id=self._payload_id(step),
                block_id=step.block_id,
                measurement=DigitalMeasurementIR.measure(
                    logical_order,
                    measurement_id=f"measurement.{step.order_index}.{step.block_id}",
                    key=key,
                ),
                logical_order=logical_order,
                shots=shots,
                seed=seed,
                source_span=step.source_span,
                metadata=self._binding_metadata(step),
            )
        except (TypeError, ValueError) as exc:
            self._raise_program_invalid(
                step,
                object_path="measurement",
                message="Measurement configuration is invalid.",
                suggestion=(
                    "Use all mapped targets, positive shots, and a non-empty key."
                ),
                cause=exc,
            )
        self._payloads[step.block_id] = payload
        return self

    def _resolve_step(
        self,
        block_id: str,
        *,
        expected_kind: PayloadKind,
        kind_mismatch_code: str = "LOCAL_HYBRID_BUILDER_KIND_MISMATCH",
    ) -> LocalExecutionStep:
        step = next(
            (item for item in self._plan.steps if item.block_id == block_id),
            None,
        )
        if step is None:
            raise ProgramValidationError(
                f"Plan has no block '{block_id}'.",
                code="LOCAL_HYBRID_BUILDER_BLOCK_UNKNOWN",
                stage="compile",
                object_path="builder.block_id",
                suggestion="Use a block id from LocalExecutionPlan.steps.",
                metadata={"block_id": block_id},
            )
        if step.kernel_kind != expected_kind:
            self._raise_builder_error(
                step,
                code=kind_mismatch_code,
                message=(
                    f"Block '{block_id}' requires a {step.kernel_kind} payload, "
                    f"not {expected_kind}."
                ),
                object_path=f"plan.steps[{step.order_index}].kernel_kind",
                suggestion=f"Use the builder method for {step.kernel_kind} blocks.",
                metadata={"actual": expected_kind, "expected": step.kernel_kind},
            )
        return step

    def _ensure_unbound(
        self,
        step: LocalExecutionStep,
        *,
        factory: bool = False,
    ) -> None:
        if step.block_id in self._factories or (
            factory and step.block_id in self._payloads
        ):
            self._raise_builder_error(
                step,
                code="LOCAL_HYBRID_FACTORY_BLOCK_DUPLICATE",
                message=f"Block '{step.block_id}' already has a binding.",
                object_path=f"plan.steps[{step.order_index}]",
                suggestion="Choose either one static binding or one factory binding.",
            )
        if step.block_id in self._payloads:
            self._raise_builder_error(
                step,
                code="LOCAL_HYBRID_BUILDER_BLOCK_DUPLICATE",
                message=f"Block '{step.block_id}' already has a static binding.",
                object_path=f"plan.steps[{step.order_index}]",
                suggestion="Bind each plan block exactly once.",
            )

    def _resolved_payloads(
        self,
        bind_set: ParameterBindIR,
    ) -> tuple[LocalStepPayload, ...]:
        bind_hash = bind_set.parameter_bind_hash
        resolved: list[LocalStepPayload] = []
        for step in self._plan.steps:
            static_payload = self._payloads.get(step.block_id)
            if static_payload is not None:
                resolved.append(static_payload)
                continue
            factory = self._factories.get(step.block_id)
            if factory is None:
                continue
            cache_key = (step.block_id, bind_hash)
            payload = self._factory_cache.get(cache_key)
            if payload is None:
                payload = self._evaluate_factory(step, factory, bind_set, bind_hash)
                self._factory_cache[cache_key] = payload
            resolved.append(payload)
        return tuple(resolved)

    def _evaluate_factory(
        self,
        step: LocalExecutionStep,
        factory: LocalProgramFactory,
        bind_set: ParameterBindIR,
        bind_hash: str,
    ) -> LocalStepPayload:
        try:
            output = factory(bind_set)
        except Exception as exc:
            self._raise_builder_error(
                step,
                code="LOCAL_HYBRID_FACTORY_FAILED",
                message=f"Factory for block '{step.block_id}' failed.",
                object_path=f"builder.factories.{step.block_id}",
                suggestion="Fix the factory and rebuild with the same BindSet.",
                metadata=self._factory_error_metadata(
                    bind_set,
                    bind_hash,
                    actual_type=type(exc).__name__,
                ),
                cause=exc,
            )

        from cascaqit.analog import AHSProgram
        from cascaqit.digital import Circuit

        if step.kernel_kind == "digital":
            if isinstance(output, (AHSProgram, ProgramIR)):
                self._raise_factory_output_error(
                    step,
                    bind_set,
                    bind_hash,
                    output,
                    code="LOCAL_HYBRID_FACTORY_KIND_MISMATCH",
                    message="Digital block factory returned an Analog program.",
                )
            if not isinstance(output, (Circuit, DigitalProgramIR)):
                self._raise_factory_output_error(
                    step,
                    bind_set,
                    bind_hash,
                    output,
                    code="LOCAL_HYBRID_FACTORY_OUTPUT_INVALID",
                    message="Digital block factory returned an unsupported value.",
                )
            return self._make_digital_payload(step, output, bind_set=bind_set)

        if isinstance(output, (Circuit, DigitalProgramIR)):
            self._raise_factory_output_error(
                step,
                bind_set,
                bind_hash,
                output,
                code="LOCAL_HYBRID_FACTORY_KIND_MISMATCH",
                message="Analog block factory returned a Digital program.",
            )
        if not isinstance(output, (AHSProgram, ProgramIR)):
            self._raise_factory_output_error(
                step,
                bind_set,
                bind_hash,
                output,
                code="LOCAL_HYBRID_FACTORY_OUTPUT_INVALID",
                message="Analog block factory returned an unsupported value.",
            )
        return self._make_analog_payload(step, output, bind_set=bind_set)

    def _make_digital_payload(
        self,
        step: LocalExecutionStep,
        program: Circuit | DigitalProgramIR,
        *,
        bind_set: ParameterBindIR | None = None,
    ) -> DigitalStepPayload:
        from cascaqit.digital import Circuit

        error_code = (
            "LOCAL_HYBRID_BUILDER_PROGRAM_INVALID"
            if bind_set is None
            else "LOCAL_HYBRID_FACTORY_OUTPUT_INVALID"
        )
        factory_metadata = (
            None
            if bind_set is None
            else self._factory_error_metadata(
                bind_set,
                bind_set.parameter_bind_hash,
                actual_type=type(program).__name__,
            )
        )
        try:
            native = program.to_program() if isinstance(program, Circuit) else program
            snapshot = DigitalProgramIR.from_dict(native.to_dict())
        except Exception as exc:
            self._raise_program_invalid(
                step,
                code=error_code,
                object_path="program",
                message="Digital program cannot be converted to native IR.",
                suggestion="Return a valid Circuit or DigitalProgramIR.",
                metadata=factory_metadata,
                cause=exc,
            )
        source_hash = snapshot.stable_hash()
        errors = tuple(
            item for item in snapshot.validate_ir_only() if item.severity == "error"
        )
        if errors:
            self._raise_program_invalid(
                step,
                code=error_code,
                object_path="program.circuit",
                message="Digital program is invalid for local hybrid binding.",
                suggestion="Fix the digital circuit diagnostics before binding it.",
                metadata={
                    **({} if factory_metadata is None else factory_metadata),
                    "diagnostic_codes": [item.code for item in errors],
                },
            )
        if snapshot.circuit.measurements:
            self._raise_program_invalid(
                step,
                code=error_code,
                object_path="program.circuit.measurements",
                message="Digital hybrid steps cannot contain measurements.",
                suggestion=(
                    "Remove Circuit.measure()/measure_all() and configure the "
                    "terminal measurement with builder.measure()."
                ),
                metadata=factory_metadata,
            )
        projected, logical_order = self._project_digital_program(snapshot, step)
        try:
            return DigitalStepPayload(
                payload_id=self._payload_id(step),
                block_id=step.block_id,
                program=projected,
                logical_order=logical_order,
                source_span=step.source_span,
                metadata=self._binding_metadata(
                    step,
                    source_program_hash=source_hash,
                    bind_set=bind_set,
                ),
            )
        except (TypeError, ValueError) as exc:
            self._raise_program_invalid(
                step,
                code=error_code,
                object_path="program",
                message="Digital program cannot form a local hybrid payload.",
                suggestion="Use a native digital program in the Hybrid subset.",
                metadata=factory_metadata,
                cause=exc,
            )

    def _make_analog_payload(
        self,
        step: LocalExecutionStep,
        program: AHSProgram | ProgramIR,
        *,
        bind_set: ParameterBindIR | None = None,
    ) -> AnalogStepPayload:
        from cascaqit.analog import AHSProgram

        error_code = (
            "LOCAL_HYBRID_BUILDER_PROGRAM_INVALID"
            if bind_set is None
            else "LOCAL_HYBRID_FACTORY_OUTPUT_INVALID"
        )
        factory_metadata = (
            None
            if bind_set is None
            else self._factory_error_metadata(
                bind_set,
                bind_set.parameter_bind_hash,
                actual_type=type(program).__name__,
            )
        )
        try:
            native = (
                program._to_hybrid_block_ir()
                if isinstance(program, AHSProgram)
                else program
            )
            snapshot = ProgramIR.from_dict(native.to_dict())
        except Exception as exc:
            self._raise_program_invalid(
                step,
                code=error_code,
                object_path="program",
                message="Analog program cannot be converted to native IR.",
                suggestion="Return a valid AHSProgram or analog ProgramIR.",
                metadata=factory_metadata,
                cause=exc,
            )
        if snapshot.measurements:
            self._raise_program_invalid(
                step,
                code=error_code,
                object_path="program.measurements",
                message="Analog hybrid steps cannot contain measurements.",
                suggestion=(
                    "Remove AHSProgram.measure() and configure the terminal "
                    "measurement with builder.measure()."
                ),
                metadata=factory_metadata,
            )
        source_hash = snapshot.stable_hash()
        projected, logical_order = self._project_analog_program(snapshot, step)
        try:
            return AnalogStepPayload(
                payload_id=self._payload_id(step),
                block_id=step.block_id,
                program=projected,
                logical_order=logical_order,
                source_span=step.source_span,
                metadata=self._binding_metadata(
                    step,
                    source_program_hash=source_hash,
                    bind_set=bind_set,
                ),
            )
        except (TypeError, ValueError) as exc:
            self._raise_program_invalid(
                step,
                code=error_code,
                object_path="program",
                message="Analog program cannot form a local hybrid payload.",
                suggestion="Use a native analog ProgramIR in the Hybrid subset.",
                metadata=factory_metadata,
                cause=exc,
            )

    def _project_digital_program(
        self,
        program: DigitalProgramIR,
        step: LocalExecutionStep,
    ) -> tuple[DigitalProgramIR, tuple[str, ...]]:
        logical_order, projection = self._project_resource_order(
            program.circuit.qubits,
            step,
            object_path="program.circuit.qubits",
        )
        circuit = replace(
            program.circuit,
            qubits=logical_order,
            gates=tuple(
                replace(
                    gate,
                    targets=tuple(projection[target] for target in gate.targets),
                    controls=tuple(projection[target] for target in gate.controls),
                )
                for gate in program.circuit.gates
            ),
            measurements=tuple(
                replace(
                    measurement,
                    targets=tuple(projection[target] for target in measurement.targets),
                )
                for measurement in program.circuit.measurements
            ),
        )
        return replace(program, circuit=circuit), logical_order

    def _project_analog_program(
        self,
        program: ProgramIR,
        step: LocalExecutionStep,
    ) -> tuple[ProgramIR, tuple[str, ...]]:
        atom_order = tuple(
            str(site.atom_id) for site in program.register.sites if site.is_active
        )
        logical_order, projection = self._project_resource_order(
            atom_order,
            step,
            object_path="program.register.sites",
        )
        register = replace(
            program.register,
            sites=tuple(
                replace(
                    site,
                    atom_id=(
                        projection.get(site.atom_id, site.atom_id)
                        if site.is_active and site.atom_id is not None
                        else site.atom_id
                    ),
                )
                for site in program.register.sites
            ),
        )
        return replace(program, register=register), logical_order

    def _project_resource_order(
        self,
        source_order: Iterable[str],
        step: LocalExecutionStep,
        *,
        object_path: str,
    ) -> tuple[tuple[str, ...], dict[str, str]]:
        order = tuple(source_order)
        local_ids = set(step.mapping)
        logical_ids = set(step.mapping.values())
        if len(order) == len(local_ids) and set(order) == local_ids:
            projection = {item: step.mapping[item] for item in order}
        elif len(order) == len(logical_ids) and set(order) == logical_ids:
            projection = {item: item for item in order}
        else:
            self._raise_builder_error(
                step,
                code="LOCAL_HYBRID_BUILDER_MAPPING_MISMATCH",
                message="Program resources do not match the plan step mapping.",
                object_path=object_path,
                suggestion=(
                    "Use the block-local resource ids or the compiled logical ids."
                ),
                metadata={
                    "actual": list(order),
                    "local_ids": list(step.mapping),
                    "logical_ids": list(step.mapping.values()),
                },
            )
        return tuple(projection[item] for item in order), projection

    @staticmethod
    def _payload_id(step: LocalExecutionStep) -> str:
        return f"payload.{step.order_index}.{step.block_id}.{step.kernel_kind}"

    @staticmethod
    def _binding_metadata(
        step: LocalExecutionStep,
        *,
        source_program_hash: str | None = None,
        bind_set: ParameterBindIR | None = None,
    ) -> dict[str, Any]:
        metadata: dict[str, Any] = {
            "binding_mode": (
                "static_builder" if bind_set is None else "parameter_factory"
            ),
            "kernel_execution": False,
            "step_id": step.step_id,
            "resource_mapping": dict(step.mapping),
        }
        if source_program_hash is not None:
            metadata["source_program_hash"] = source_program_hash
        if bind_set is not None:
            metadata.update(
                {
                    "parameter_bind_id": bind_set.parameter_bind_id,
                    "parameter_bind_hash": bind_set.parameter_bind_hash,
                    "parameter_schema_hash": bind_set.parameter_schema_hash,
                    "compile_required": bind_set.compile_required,
                }
            )
        return metadata

    def _bind_set_required_diagnostic(self) -> OrchestrationDiagnosticIR:
        block_ids = [
            step.block_id
            for step in self._plan.steps
            if step.block_id in self._factories
        ]
        return OrchestrationDiagnosticIR(
            diagnostic_id="local_factory.bind_set.required",
            stage="compile",
            severity="error",
            code="LOCAL_HYBRID_FACTORY_BIND_SET_REQUIRED",
            message="Parameterized local program factories require a BindSet.",
            object_path="builder.bind_set",
            suggestion="Pass bind_set=ParameterBindIR(...) to build() or run().",
            metadata={"factory_block_ids": block_ids},
        )

    @staticmethod
    def _factory_error_metadata(
        bind_set: ParameterBindIR,
        bind_hash: str,
        *,
        actual_type: str,
    ) -> dict[str, Any]:
        return {
            "actual_type": actual_type,
            "parameter_bind_id": bind_set.parameter_bind_id,
            "parameter_bind_hash": bind_hash,
            "parameter_schema_hash": bind_set.parameter_schema_hash,
        }

    def _raise_factory_output_error(
        self,
        step: LocalExecutionStep,
        bind_set: ParameterBindIR,
        bind_hash: str,
        output: object,
        *,
        code: str,
        message: str,
    ) -> NoReturn:
        self._raise_builder_error(
            step,
            code=code,
            message=message,
            object_path=f"builder.factories.{step.block_id}.output",
            suggestion=(
                "Return Circuit/DigitalProgramIR for Digital blocks or "
                "AHSProgram/ProgramIR for Analog blocks."
            ),
            metadata=self._factory_error_metadata(
                bind_set,
                bind_hash,
                actual_type=type(output).__name__,
            ),
        )

    def _raise_program_invalid(
        self,
        step: LocalExecutionStep,
        *,
        code: str = "LOCAL_HYBRID_BUILDER_PROGRAM_INVALID",
        object_path: str,
        message: str,
        suggestion: str,
        metadata: dict[str, Any] | None = None,
        cause: BaseException | None = None,
    ) -> NoReturn:
        self._raise_builder_error(
            step,
            code=code,
            message=message,
            object_path=object_path,
            suggestion=suggestion,
            metadata=metadata,
            cause=cause,
        )

    @staticmethod
    def _raise_builder_error(
        step: LocalExecutionStep,
        *,
        code: str,
        message: str,
        object_path: str,
        suggestion: str,
        metadata: dict[str, Any] | None = None,
        cause: BaseException | None = None,
    ) -> NoReturn:
        raise ProgramValidationError(
            message,
            code=code,
            stage="compile",
            object_path=object_path,
            suggestion=suggestion,
            trace_references={"step_id": step.step_id, "block_id": step.block_id},
            metadata={} if metadata is None else metadata,
            cause=cause,
        )


@dataclass(frozen=True)
class DigitalStepAdapter:
    """Apply the Hybrid P0 digital subset through the existing state kernel."""

    kernel: DigitalStateVectorKernel = field(
        default_factory=lambda: DigitalStateVectorKernel(max_qubits=2)
    )

    def __post_init__(self) -> None:
        if not isinstance(self.kernel, DigitalStateVectorKernel):
            raise TypeError("kernel must be DigitalStateVectorKernel.")
        if self.kernel.max_qubits > 2:
            raise ValueError("hybrid digital adapter supports at most 2 qubits.")

    def apply(
        self,
        step: LocalExecutionStep,
        payload: DigitalStepPayload,
        initial_state: SimulationState,
    ) -> SimulationState:
        """Validate one digital step and return its evolved state."""
        if not isinstance(payload, DigitalStepPayload):
            raise TypeError("payload must be DigitalStepPayload.")
        if not isinstance(initial_state, SimulationState):
            raise TypeError("initial_state must be SimulationState.")
        self.validate(step, payload, stage="simulation")
        return self.kernel.evolve(payload.program, initial_state)

    def validate(
        self,
        step: LocalExecutionStep,
        payload: DigitalStepPayload,
        *,
        stage: _ValidationStage = "compile",
    ) -> None:
        """Validate static Digital payload capability without evolving state."""
        if not isinstance(payload, DigitalStepPayload):
            raise TypeError("payload must be DigitalStepPayload.")
        _validate_adapter_payload(
            step,
            payload,
            expected_kind="digital",
            stage=stage,
        )
        unsupported = tuple(
            sorted(
                {
                    gate.name
                    for gate in payload.program.circuit.gates
                    if gate.name not in _HYBRID_DIGITAL_GATES
                }
            )
        )
        if unsupported:
            _raise_adapter_error(
                "Digital payload uses gates outside the Hybrid P0 subset.",
                code="LOCAL_HYBRID_DIGITAL_GATE_UNSUPPORTED",
                object_path="payload.program.circuit.gates",
                suggestion="Use only H, X, RX, RY, RZ, CX, and CZ gates.",
                step=step,
                payload=payload,
                stage=stage,
                metadata={"unsupported_gates": list(unsupported)},
            )


@dataclass(frozen=True)
class AnalogStepAdapter:
    """Apply the Hybrid P0 analog subset through the existing state kernel."""

    kernel: AnalogStateVectorKernel = field(
        default_factory=lambda: AnalogStateVectorKernel(max_hilbert_dim=4)
    )

    def __post_init__(self) -> None:
        if not isinstance(self.kernel, AnalogStateVectorKernel):
            raise TypeError("kernel must be AnalogStateVectorKernel.")
        if self.kernel.max_hilbert_dim > 4:
            raise ValueError("hybrid analog adapter supports at most dimension 4.")

    def apply(
        self,
        step: LocalExecutionStep,
        payload: AnalogStepPayload,
        initial_state: SimulationState,
    ) -> SimulationState:
        """Validate one analog step and return its evolved state."""
        if not isinstance(payload, AnalogStepPayload):
            raise TypeError("payload must be AnalogStepPayload.")
        if not isinstance(initial_state, SimulationState):
            raise TypeError("initial_state must be SimulationState.")
        self.validate(step, payload, stage="simulation")
        return self.kernel.evolve(payload.program, initial_state)

    def validate(
        self,
        step: LocalExecutionStep,
        payload: AnalogStepPayload,
        *,
        stage: _ValidationStage = "compile",
    ) -> None:
        """Validate static Analog payload capability without evolving state."""
        if not isinstance(payload, AnalogStepPayload):
            raise TypeError("payload must be AnalogStepPayload.")
        _validate_adapter_payload(
            step,
            payload,
            expected_kind="analog",
            stage=stage,
        )
        hamiltonian = payload.program.hamiltonian
        if hamiltonian.hamiltonian_type != "rydberg":
            _raise_adapter_error(
                "Analog payload must use the global Rydberg Hamiltonian.",
                code="LOCAL_HYBRID_ANALOG_HAMILTONIAN_UNSUPPORTED",
                object_path="payload.program.hamiltonian.hamiltonian_type",
                suggestion="Use the native global Rydberg Hamiltonian.",
                step=step,
                payload=payload,
                stage=stage,
            )
        waveforms = [hamiltonian.rabi, hamiltonian.detuning]
        if isinstance(hamiltonian.phase, WaveformIR):
            waveforms.append(hamiltonian.phase)
        waveforms.extend(term.waveform for term in hamiltonian.local_detuning_terms)
        for term in hamiltonian.local_rabi_terms:
            waveforms.append(term.rabi)
            if isinstance(term.phase, WaveformIR):
                waveforms.append(term.phase)
        unsupported = tuple(
            sorted(
                {
                    waveform.kind
                    for waveform in waveforms
                    if waveform.kind not in _HYBRID_ANALOG_WAVEFORMS
                }
            )
        )
        if unsupported:
            _raise_adapter_error(
                "Analog payload uses waveforms outside the Hybrid P0 subset.",
                code="LOCAL_HYBRID_ANALOG_WAVEFORM_UNSUPPORTED",
                object_path="payload.program.hamiltonian",
                suggestion=(
                    "Use constant, linear, piecewise, or interpolated waveforms."
                ),
                step=step,
                payload=payload,
                stage=stage,
                metadata={"unsupported_waveforms": list(unsupported)},
            )


def _validate_adapter_payload(
    step: LocalExecutionStep,
    payload: DigitalStepPayload | AnalogStepPayload,
    *,
    expected_kind: Literal["digital", "analog"],
    stage: _ValidationStage,
) -> None:
    if not isinstance(step, LocalExecutionStep):
        raise TypeError("step must be LocalExecutionStep.")
    if step.kernel_kind != expected_kind:
        _raise_adapter_error(
            "Plan step kernel kind does not match the adapter.",
            code="LOCAL_HYBRID_ADAPTER_KIND_MISMATCH",
            object_path="step.kernel_kind",
            suggestion=f"Use the {step.kernel_kind} adapter for this step.",
            step=step,
            payload=payload,
            stage=stage,
        )
    if step.block_id != payload.block_id:
        _raise_adapter_error(
            "Plan step and payload block ids do not match.",
            code="LOCAL_HYBRID_ADAPTER_BLOCK_MISMATCH",
            object_path="payload.block_id",
            suggestion="Bind the payload to its matching plan step.",
            step=step,
            payload=payload,
            stage=stage,
        )
    if set(step.mapping.values()) != set(payload.logical_order):
        _raise_adapter_error(
            "Plan step mapping and payload logical ids do not match.",
            code="LOCAL_HYBRID_ADAPTER_MAPPING_MISMATCH",
            object_path="step.mapping",
            suggestion="Compile payload ids from the explicit step mapping.",
            step=step,
            payload=payload,
            stage=stage,
        )


def _raise_adapter_error(
    message: str,
    *,
    code: str,
    object_path: str,
    suggestion: str,
    step: LocalExecutionStep,
    payload: DigitalStepPayload | AnalogStepPayload,
    stage: _ValidationStage = "simulation",
    metadata: dict[str, Any] | None = None,
) -> None:
    raise ProgramValidationError(
        message,
        code=code,
        stage=stage,
        object_path=object_path,
        suggestion=suggestion,
        trace_references={"step_id": step.step_id, "block_id": step.block_id},
        source_hashes={"payload_hash": payload.stable_hash()},
        metadata={} if metadata is None else metadata,
    )


_PAYLOAD_TYPES = (DigitalStepPayload, AnalogStepPayload, MeasurementStepPayload)


def _payload_from_dict(data: dict[str, Any]) -> LocalStepPayload:
    kind = data.get("payload_kind")
    if kind == "digital":
        return DigitalStepPayload.from_dict(data)
    if kind == "analog":
        return AnalogStepPayload.from_dict(data)
    if kind == "measurement":
        return MeasurementStepPayload.from_dict(data)
    raise ValueError(f"unsupported local hybrid payload_kind: {kind!r}.")


@dataclass(frozen=True)
class LocalExecutionBundle(IRMixin):
    """Validated executable input that leaves the base plan unchanged."""

    bundle_id: str
    base_plan: LocalExecutionPlan
    base_plan_hash: str
    payloads: tuple[LocalStepPayload, ...]
    payload_hashes: tuple[str, ...]
    execution_ready: bool = True
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = LOCAL_HYBRID_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_identifier(self.bundle_id, field_name="bundle_id")
        if not isinstance(self.base_plan, LocalExecutionPlan):
            raise TypeError("base_plan must be LocalExecutionPlan.")
        _require_hash(self.base_plan_hash, field_name="base_plan_hash")
        if self.base_plan_hash != self.base_plan.stable_hash():
            raise ValueError("base_plan_hash must match the base plan.")
        if not isinstance(self.payloads, (tuple, list)) or any(
            not isinstance(payload, _PAYLOAD_TYPES) for payload in self.payloads
        ):
            raise TypeError("payloads must contain native local step payloads.")
        payloads = tuple(self.payloads)
        if not payloads or len(payloads) != len(self.base_plan.steps):
            raise ValueError("bundle must contain exactly one payload per plan step.")
        if not isinstance(self.payload_hashes, (tuple, list)):
            raise TypeError("payload_hashes must be a tuple or list.")
        payload_hashes = tuple(self.payload_hashes)
        if any(not isinstance(item, str) for item in payload_hashes):
            raise TypeError("payload_hashes must contain strings.")
        if payload_hashes != tuple(payload.stable_hash() for payload in payloads):
            raise ValueError("payload_hashes must match payload content and order.")
        if self.execution_ready is not True:
            raise ValueError("a local execution bundle must be execution-ready.")
        if not isinstance(self.metadata, dict):
            raise TypeError("metadata must be a dictionary.")
        _require_identifier(self.schema_version, field_name="schema_version")

        payload_ids = tuple(payload.payload_id for payload in payloads)
        if len(set(payload_ids)) != len(payload_ids):
            raise ValueError("bundle payload ids must be unique.")
        block_ids = tuple(payload.block_id for payload in payloads)
        if len(set(block_ids)) != len(block_ids):
            raise ValueError("bundle payload block ids must be unique.")
        expected_requirements = tuple(
            f"payload:{step.block_id}:{step.kernel_kind}"
            for step in self.base_plan.steps
        )
        if self.base_plan.payload_requirements != expected_requirements:
            raise ValueError("base plan payload requirements are inconsistent.")

        canonical_order = payloads[0].logical_order
        for step, payload in zip(self.base_plan.steps, payloads):
            if payload.block_id != step.block_id:
                raise ValueError("payload order must match base plan step order.")
            if payload.payload_kind != step.kernel_kind:
                raise ValueError("payload kind must match the plan kernel kind.")
            if payload.logical_order != canonical_order:
                raise ValueError("all payloads must use one logical_order.")
            if set(step.mapping.values()) != set(payload.logical_order):
                raise ValueError("step mapping must match payload logical ids.")

        object.__setattr__(self, "payloads", payloads)
        object.__setattr__(self, "payload_hashes", payload_hashes)
        object.__setattr__(self, "metadata", dict(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> LocalExecutionBundle:
        """Build a local execution bundle from a dictionary."""
        return cls(
            bundle_id=data["bundle_id"],
            base_plan=LocalExecutionPlan.from_dict(data["base_plan"]),
            base_plan_hash=data["base_plan_hash"],
            payloads=tuple(
                _payload_from_dict(item) for item in data.get("payloads", ())
            ),
            payload_hashes=data.get("payload_hashes", ()),
            execution_ready=data.get("execution_ready", True),
            metadata=data.get("metadata", {}),
            schema_version=data.get(
                "schema_version",
                LOCAL_HYBRID_SCHEMA_VERSION,
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> LocalExecutionBundle:
        """Build a local execution bundle from JSON text."""
        return cls.from_dict(_json_object(text, type_name=cls.__name__))


@dataclass(frozen=True)
class LocalExecutionBundleResult(IRMixin):
    """A ready bundle or source-aware diagnostics that blocked binding."""

    bundle: LocalExecutionBundle | None
    diagnostics: tuple[OrchestrationDiagnosticIR, ...] = ()
    schema_version: str = LOCAL_HYBRID_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.bundle is not None and not isinstance(
            self.bundle, LocalExecutionBundle
        ):
            raise TypeError("bundle must be LocalExecutionBundle or None.")
        if any(
            not isinstance(item, OrchestrationDiagnosticIR) for item in self.diagnostics
        ):
            raise TypeError(
                "diagnostics must contain OrchestrationDiagnosticIR values."
            )
        if self.has_errors and self.bundle is not None:
            raise ValueError("bundle binding with errors must not expose a bundle.")
        if not self.has_errors and self.bundle is None:
            raise ValueError("successful bundle binding must expose a bundle.")
        _require_identifier(self.schema_version, field_name="schema_version")

    @property
    def has_errors(self) -> bool:
        """Return whether payload binding was blocked."""
        return any(item.severity == "error" for item in self.diagnostics)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> LocalExecutionBundleResult:
        """Build a local execution bundle result from a dictionary."""
        bundle_data = data.get("bundle")
        return cls(
            bundle=(
                None
                if bundle_data is None
                else LocalExecutionBundle.from_dict(bundle_data)
            ),
            diagnostics=tuple(
                OrchestrationDiagnosticIR.from_dict(item)
                for item in data.get("diagnostics", ())
            ),
            schema_version=data.get(
                "schema_version",
                LOCAL_HYBRID_SCHEMA_VERSION,
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> LocalExecutionBundleResult:
        """Build a bundle binding result from JSON text."""
        return cls.from_dict(_json_object(text, type_name=cls.__name__))


@dataclass(frozen=True)
class LocalHybridStateRun:
    """Executable final state and trace from the pre-measurement runner core."""

    bundle: LocalExecutionBundle
    initial_state: SimulationState
    final_state: SimulationState
    transitions: tuple[StateTransitionIR, ...]

    def __post_init__(self) -> None:
        if not isinstance(self.bundle, LocalExecutionBundle):
            raise TypeError("bundle must be LocalExecutionBundle.")
        if not isinstance(self.initial_state, SimulationState):
            raise TypeError("initial_state must be SimulationState.")
        if not isinstance(self.final_state, SimulationState):
            raise TypeError("final_state must be SimulationState.")
        if any(
            not isinstance(item, StateTransitionIR)
            for item in self.transitions
        ):
            raise TypeError(
                "transitions must contain StateTransitionIR values."
            )
        if not isinstance(self.bundle.payloads[-1], MeasurementStepPayload):
            raise ValueError("state run bundle must end with terminal measurement.")
        expected_transitions = len(self.bundle.payloads) - 1
        if len(self.transitions) != expected_transitions:
            raise ValueError(
                "state run must contain exactly one transition per quantum step."
            )
        for transition, step, payload in zip(
            self.transitions,
            self.bundle.base_plan.steps,
            self.bundle.payloads,
        ):
            if (
                transition.metadata.get("step_id") != step.step_id
                or transition.block_id != step.block_id
                or transition.metadata.get("payload_id") != payload.payload_id
                or transition.metadata.get("payload_hash") != payload.stable_hash()
            ):
                raise ValueError("transition identity does not match the bundle.")
        if self.transitions[0].input_state_hash != self.initial_state.stable_hash():
            raise ValueError("first transition must reference the initial state.")
        for left, right in zip(self.transitions, self.transitions[1:]):
            if left.output_state_hash != right.input_state_hash:
                raise ValueError("transition state hash chain is broken.")
        if self.transitions[-1].output_state_hash != self.final_state.stable_hash():
            raise ValueError("last transition must reference the final state.")

    @property
    def bundle_hash(self) -> str:
        """Return the stable bundle hash used for this run."""
        return self.bundle.stable_hash()


@dataclass(frozen=True)
class LocalHybridMeasurementResult(IRMixin):
    """Unified terminal measurement result and its reproducibility trace."""

    result: ResultIR
    trace: RunTraceIR
    diagnostics: tuple[DiagnosticsIR, ...]
    bundle_hash: str
    final_state_hash: str
    schema_version: str = LOCAL_HYBRID_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if not isinstance(self.result, ResultIR):
            raise TypeError("result must be ResultIR.")
        if not isinstance(self.trace, RunTraceIR):
            raise TypeError("trace must be RunTraceIR.")
        if any(not isinstance(item, DiagnosticsIR) for item in self.diagnostics):
            raise TypeError("diagnostics must contain DiagnosticsIR values.")
        _require_hash(self.bundle_hash, field_name="bundle_hash")
        _require_hash(self.final_state_hash, field_name="final_state_hash")
        if self.result.diagnostics != self.diagnostics:
            raise ValueError("result diagnostics must match measurement diagnostics.")
        if self.result.metadata.get("run_trace") != self.trace.to_dict():
            raise ValueError("result metadata must contain the matching run trace.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> LocalHybridMeasurementResult:
        """Build a terminal measurement result from a dictionary."""
        return cls(
            result=ResultIR.from_dict(data["result"]),
            trace=RunTraceIR.from_dict(data["trace"]),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(item) for item in data["diagnostics"]
            ),
            bundle_hash=data["bundle_hash"],
            final_state_hash=data["final_state_hash"],
            schema_version=data.get(
                "schema_version",
                LOCAL_HYBRID_SCHEMA_VERSION,
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> LocalHybridMeasurementResult:
        """Build a terminal measurement result from JSON text."""
        return cls.from_dict(_json_object(text, type_name=cls.__name__))


@dataclass(frozen=True)
class LocalHybridScanItemResult(IRMixin):
    """One completed BindSet and its existing local measurement result."""

    scan_index: int
    bind_set: ParameterBindIR
    job_id: str
    measurement_result: LocalHybridMeasurementResult
    schema_version: str = LOCAL_HYBRID_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if (
            not isinstance(self.scan_index, int)
            or isinstance(self.scan_index, bool)
            or self.scan_index < 0
        ):
            raise ValueError("scan_index must be a non-negative integer.")
        if not isinstance(self.bind_set, ParameterBindIR):
            raise TypeError("bind_set must be ParameterBindIR.")
        _require_identifier(self.job_id, field_name="job_id")
        if not isinstance(self.measurement_result, LocalHybridMeasurementResult):
            raise TypeError("measurement_result must be LocalHybridMeasurementResult.")
        if (
            self.measurement_result.trace.references.bundle_hash
            != self.measurement_result.bundle_hash
        ):
            raise ValueError("measurement trace must reference the item bundle hash.")
        _require_identifier(self.schema_version, field_name="schema_version")

    @property
    def bundle_hash(self) -> str:
        """Return the immutable Bundle fact referenced by this item."""
        return self.measurement_result.bundle_hash

    @property
    def result(self) -> ResultIR:
        """Return the existing unified ResultIR for this point."""
        return self.measurement_result.result

    @property
    def trace(self) -> RunTraceIR:
        """Return the existing RunTraceIR for this point."""
        return self.measurement_result.trace

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> LocalHybridScanItemResult:
        """Build one completed scan item from a dictionary."""
        return cls(
            scan_index=data["scan_index"],
            bind_set=ParameterBindIR.from_dict(data["bind_set"]),
            job_id=data["job_id"],
            measurement_result=LocalHybridMeasurementResult.from_dict(
                data["measurement_result"]
            ),
            schema_version=data.get(
                "schema_version",
                LOCAL_HYBRID_SCHEMA_VERSION,
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> LocalHybridScanItemResult:
        """Build one completed scan item from JSON text."""
        return cls.from_dict(_json_object(text, type_name=cls.__name__))


@dataclass(frozen=True)
class LocalHybridScanResult(IRMixin):
    """Ordered completed results from one resource-planned parameter scan."""

    scan_id: str
    plan_hash: str
    items: tuple[LocalHybridScanItemResult, ...]
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = LOCAL_HYBRID_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_identifier(self.scan_id, field_name="scan_id")
        _require_hash(self.plan_hash, field_name="plan_hash")
        if not isinstance(self.items, (tuple, list)) or any(
            not isinstance(item, LocalHybridScanItemResult) for item in self.items
        ):
            raise TypeError("items must contain LocalHybridScanItemResult values.")
        items = tuple(self.items)
        if not items:
            raise ValueError("local hybrid scan result must contain at least one item.")
        if tuple(item.scan_index for item in items) != tuple(range(len(items))):
            raise ValueError("scan item indexes must be contiguous and ordered.")
        bind_ids = tuple(item.bind_set.parameter_bind_id for item in items)
        if len(set(bind_ids)) != len(bind_ids):
            raise ValueError("scan item bind ids must be unique.")
        if any(
            item.trace.references.plan_hash != self.plan_hash
            for item in items
        ):
            raise ValueError("scan item traces must reference the result plan hash.")
        if not isinstance(self.metadata, dict):
            raise TypeError("metadata must be a dictionary.")
        _require_identifier(self.schema_version, field_name="schema_version")
        object.__setattr__(self, "items", items)
        object.__setattr__(self, "metadata", dict(self.metadata))

    @property
    def bind_sets(self) -> tuple[ParameterBindIR, ...]:
        """Return BindSets in stable scan order."""
        return tuple(item.bind_set for item in self.items)

    @property
    def results(self) -> tuple[ResultIR, ...]:
        """Return existing ResultIR facts in stable scan order."""
        return tuple(item.result for item in self.items)

    @property
    def traces(self) -> tuple[RunTraceIR, ...]:
        """Return existing RunTraceIR facts in stable scan order."""
        return tuple(item.trace for item in self.items)

    @property
    def bundle_hashes(self) -> tuple[str, ...]:
        """Return Bundle fact hashes in stable scan order."""
        return tuple(item.bundle_hash for item in self.items)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> LocalHybridScanResult:
        """Build a bounded local scan result from a dictionary."""
        return cls(
            scan_id=data["scan_id"],
            plan_hash=data["plan_hash"],
            items=tuple(
                LocalHybridScanItemResult.from_dict(item)
                for item in data.get("items", ())
            ),
            metadata=data.get("metadata", {}),
            schema_version=data.get(
                "schema_version",
                LOCAL_HYBRID_SCHEMA_VERSION,
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> LocalHybridScanResult:
        """Build a bounded local scan result from JSON text."""
        return cls.from_dict(_json_object(text, type_name=cls.__name__))


LocalHybridScanFailurePolicy = Literal["fail_fast", "continue_on_error"]
LocalHybridScanItemState = Literal[
    "pending",
    "running",
    "completed",
    "failed",
    "not_run",
    "cancelled",
]
@dataclass(frozen=True)
class LocalHybridScanItemOutcome(IRMixin):
    """One parameter point outcome within a local hybrid scan job."""

    scan_index: int
    bind_set: ParameterBindIR
    state: LocalHybridScanItemState
    job_id: str | None = None
    bundle_id: str | None = None
    measurement_result: LocalHybridMeasurementResult | None = None
    diagnostics: tuple[DiagnosticsIR, ...] = ()
    trace: RunTraceIR | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = LOCAL_HYBRID_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if (
            not isinstance(self.scan_index, int)
            or isinstance(self.scan_index, bool)
            or self.scan_index < 0
        ):
            raise ValueError("scan_index must be a non-negative integer.")
        if not isinstance(self.bind_set, ParameterBindIR):
            raise TypeError("bind_set must be ParameterBindIR.")
        if self.state not in {
            "pending",
            "running",
            "completed",
            "failed",
            "not_run",
            "cancelled",
        }:
            raise ValueError("invalid local hybrid scan item state.")
        if self.job_id is not None:
            _require_identifier(self.job_id, field_name="job_id")
        if self.bundle_id is not None:
            _require_identifier(self.bundle_id, field_name="bundle_id")
        if self.measurement_result is not None and not isinstance(
            self.measurement_result,
            LocalHybridMeasurementResult,
        ):
            raise TypeError(
                "measurement_result must be LocalHybridMeasurementResult or None."
            )
        if not isinstance(self.diagnostics, (tuple, list)) or any(
            not isinstance(item, DiagnosticsIR) for item in self.diagnostics
        ):
            raise TypeError("diagnostics must contain DiagnosticsIR values.")
        if self.trace is not None and not isinstance(self.trace, RunTraceIR):
            raise TypeError("trace must be RunTraceIR or None.")
        if not isinstance(self.metadata, dict):
            raise TypeError("metadata must be a dictionary.")
        _require_identifier(self.schema_version, field_name="schema_version")

        diagnostics = tuple(self.diagnostics)
        if self.state == "completed":
            if self.job_id is None or self.bundle_id is None:
                raise ValueError("completed scan items require job_id and bundle_id.")
            if self.measurement_result is None:
                raise ValueError("completed scan items require a measurement result.")
            if self.trace != self.measurement_result.trace:
                raise ValueError(
                    "completed scan item trace must match its measurement result."
                )
            if any(item.severity == "error" for item in diagnostics):
                raise ValueError(
                    "completed scan items cannot contain error diagnostics."
                )
        elif self.state == "failed":
            if self.measurement_result is not None:
                raise ValueError(
                    "failed scan items cannot contain a measurement result."
                )
            if not any(item.severity == "error" for item in diagnostics):
                raise ValueError("failed scan items require an error diagnostic.")
        elif self.state in {"pending", "not_run", "cancelled"}:
            if any(
                value is not None
                for value in (
                    self.job_id,
                    self.bundle_id,
                    self.measurement_result,
                    self.trace,
                )
            ):
                raise ValueError(
                    f"{self.state} scan items cannot contain execution facts."
                )
            if any(item.severity == "error" for item in diagnostics):
                raise ValueError(
                    f"{self.state} scan items cannot contain error diagnostics."
                )
        elif self.measurement_result is not None:
            raise ValueError("running scan items cannot contain a measurement result.")

        object.__setattr__(self, "diagnostics", diagnostics)
        object.__setattr__(self, "metadata", dict(self.metadata))

    @property
    def result(self) -> ResultIR | None:
        """Return the completed ResultIR, if this point completed."""
        if self.measurement_result is None:
            return None
        return self.measurement_result.result

    @property
    def bundle_hash(self) -> str | None:
        """Return the completed Bundle hash, if one exists."""
        if self.measurement_result is None:
            return None
        return self.measurement_result.bundle_hash

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> LocalHybridScanItemOutcome:
        """Build one local scan item outcome from a dictionary."""
        measurement_data = data.get("measurement_result")
        trace_data = data.get("trace")
        return cls(
            scan_index=data["scan_index"],
            bind_set=ParameterBindIR.from_dict(data["bind_set"]),
            state=data["state"],
            job_id=data.get("job_id"),
            bundle_id=data.get("bundle_id"),
            measurement_result=(
                None
                if measurement_data is None
                else LocalHybridMeasurementResult.from_dict(measurement_data)
            ),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(item) for item in data.get("diagnostics", ())
            ),
            trace=(None if trace_data is None else RunTraceIR.from_dict(trace_data)),
            metadata=data.get("metadata", {}),
            schema_version=data.get(
                "schema_version",
                LOCAL_HYBRID_SCHEMA_VERSION,
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> LocalHybridScanItemOutcome:
        """Build one local scan item outcome from JSON text."""
        return cls.from_dict(_json_object(text, type_name=cls.__name__))


@dataclass(frozen=True)
class LocalHybridScanJobStatusIR(IRMixin):
    """Immutable lifecycle and item-count snapshot for one local scan job."""

    job_id: str
    scan_id: str
    state: JobState
    failure_policy: LocalHybridScanFailurePolicy
    total_items: int
    pending_count: int = 0
    running_count: int = 0
    completed_count: int = 0
    failed_count: int = 0
    not_run_count: int = 0
    cancelled_count: int = 0
    message: str = "Local hybrid scan job status."
    backend_id: str = "local.hybrid_simulator"
    backend_called: bool = False
    network_accessed: bool = False
    execution_package_created: bool = False
    schema_version: str = LOCAL_HYBRID_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_identifier(self.job_id, field_name="job_id")
        _require_identifier(self.scan_id, field_name="scan_id")
        validate_job_state(self.state)
        if self.failure_policy not in {"fail_fast", "continue_on_error"}:
            raise ValueError("invalid local hybrid scan failure policy.")
        counts = (
            self.total_items,
            self.pending_count,
            self.running_count,
            self.completed_count,
            self.failed_count,
            self.not_run_count,
            self.cancelled_count,
        )
        if any(
            not isinstance(value, int) or isinstance(value, bool) or value < 0
            for value in counts
        ):
            raise ValueError("local scan job counts must be non-negative integers.")
        if self.total_items < 1:
            raise ValueError("local scan jobs require a positive item count.")
        if sum(counts[1:]) != self.total_items:
            raise ValueError("local scan job item counts must equal total_items.")
        _require_identifier(self.message, field_name="message")
        _require_identifier(self.backend_id, field_name="backend_id")
        _require_identifier(self.schema_version, field_name="schema_version")

        if self.state in {"created", "queued"} and (
            self.pending_count != self.total_items
        ):
            raise ValueError("created or queued scan jobs must have all items pending.")
        if self.state == "running" and self.running_count < 1:
            raise ValueError("running scan jobs must have at least one running item.")
        if self.state == "completed" and self.completed_count != self.total_items:
            raise ValueError("completed scan jobs must complete every item.")
        if self.state == "partially_completed" and not (
            self.completed_count > 0 and self.failed_count > 0
        ):
            raise ValueError(
                "partially completed scan jobs require successes and failures."
            )
        if self.state == "failed" and not (
            self.completed_count == 0 and self.failed_count > 0
        ):
            raise ValueError("failed scan jobs require failures and no successes.")
        if self.state == "cancelled" and (
            self.cancelled_count < 1
            or self.pending_count > 0
            or self.running_count > 0
        ):
            raise ValueError(
                "cancelled scan jobs require cancelled items and no active items."
            )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> LocalHybridScanJobStatusIR:
        """Build a local scan job status snapshot from a dictionary."""
        return cls(
            job_id=data["job_id"],
            scan_id=data["scan_id"],
            state=data["state"],
            failure_policy=data["failure_policy"],
            total_items=data["total_items"],
            pending_count=data.get("pending_count", 0),
            running_count=data.get("running_count", 0),
            completed_count=data.get("completed_count", 0),
            failed_count=data.get("failed_count", 0),
            not_run_count=data.get("not_run_count", 0),
            cancelled_count=data.get("cancelled_count", 0),
            message=data.get("message", "Local hybrid scan job status."),
            backend_id=data.get("backend_id", "local.hybrid_simulator"),
            backend_called=data.get("backend_called", False),
            network_accessed=data.get("network_accessed", False),
            execution_package_created=data.get("execution_package_created", False),
            schema_version=data.get(
                "schema_version",
                LOCAL_HYBRID_SCHEMA_VERSION,
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> LocalHybridScanJobStatusIR:
        """Build a local scan job status snapshot from JSON text."""
        return cls.from_dict(_json_object(text, type_name=cls.__name__))


@dataclass(frozen=True)
class LocalHybridScanJobResult(IRMixin):
    """Terminal aggregate result for one local hybrid scan job."""

    job_id: str
    scan_id: str
    plan_hash: str
    parameter_scan_hash: str
    parameter_schema_hash: str
    status: LocalHybridScanJobStatusIR
    items: tuple[LocalHybridScanItemOutcome, ...]
    diagnostics: tuple[DiagnosticsIR, ...]
    trace: RunTraceIR
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = LOCAL_HYBRID_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_identifier(self.job_id, field_name="job_id")
        _require_identifier(self.scan_id, field_name="scan_id")
        _require_hash(self.plan_hash, field_name="plan_hash")
        _require_hash(self.parameter_scan_hash, field_name="parameter_scan_hash")
        _require_hash(self.parameter_schema_hash, field_name="parameter_schema_hash")
        if not isinstance(self.status, LocalHybridScanJobStatusIR):
            raise TypeError("status must be LocalHybridScanJobStatusIR.")
        if self.status.state not in {"completed", "partially_completed", "failed"}:
            raise ValueError(
                "scan job results require a result-bearing terminal state."
            )
        if self.status.job_id != self.job_id or self.status.scan_id != self.scan_id:
            raise ValueError("scan job result identity must match its status.")
        if not isinstance(self.items, (tuple, list)) or any(
            not isinstance(item, LocalHybridScanItemOutcome) for item in self.items
        ):
            raise TypeError("items must contain LocalHybridScanItemOutcome values.")
        items = tuple(self.items)
        if not items:
            raise ValueError("local scan job results require at least one item.")
        if tuple(item.scan_index for item in items) != tuple(range(len(items))):
            raise ValueError("scan job item indexes must be contiguous and ordered.")
        bind_ids = tuple(item.bind_set.parameter_bind_id for item in items)
        if len(set(bind_ids)) != len(bind_ids):
            raise ValueError("scan job item bind ids must be unique.")
        if any(item.state not in {"completed", "failed", "not_run"} for item in items):
            raise ValueError("scan job results can contain only terminal item states.")
        state_counts = Counter(item.state for item in items)
        if (
            state_counts["completed"] != self.status.completed_count
            or state_counts["failed"] != self.status.failed_count
            or state_counts["not_run"] != self.status.not_run_count
        ):
            raise ValueError("scan job result items must match status counts.")
        if self.status.total_items != len(items):
            raise ValueError(
                "scan job result item count must match status total_items."
            )
        if not isinstance(self.diagnostics, (tuple, list)) or any(
            not isinstance(item, DiagnosticsIR) for item in self.diagnostics
        ):
            raise TypeError("diagnostics must contain DiagnosticsIR values.")
        diagnostics = tuple(self.diagnostics)
        item_diagnostics = tuple(
            diagnostic for item in items for diagnostic in item.diagnostics
        )
        if diagnostics != item_diagnostics:
            raise ValueError(
                "scan job diagnostics must match ordered item diagnostics."
            )
        if not isinstance(self.trace, RunTraceIR):
            raise TypeError("trace must be RunTraceIR.")
        if self.trace.references.plan_hash != self.plan_hash:
            raise ValueError("scan job trace must reference the result plan hash.")
        if not isinstance(self.metadata, dict):
            raise TypeError("metadata must be a dictionary.")
        _require_identifier(self.schema_version, field_name="schema_version")
        object.__setattr__(self, "items", items)
        object.__setattr__(self, "diagnostics", diagnostics)
        object.__setattr__(self, "metadata", dict(self.metadata))

    @property
    def successful_items(self) -> tuple[LocalHybridScanItemOutcome, ...]:
        """Return completed item outcomes in scan order."""
        return tuple(item for item in self.items if item.state == "completed")

    @property
    def failed_items(self) -> tuple[LocalHybridScanItemOutcome, ...]:
        """Return failed item outcomes in scan order."""
        return tuple(item for item in self.items if item.state == "failed")

    @property
    def not_run_items(self) -> tuple[LocalHybridScanItemOutcome, ...]:
        """Return fail-fast item outcomes that were not executed."""
        return tuple(item for item in self.items if item.state == "not_run")

    @property
    def bind_sets(self) -> tuple[ParameterBindIR, ...]:
        """Return all BindSets in stable scan order."""
        return tuple(item.bind_set for item in self.items)

    @property
    def results(self) -> tuple[ResultIR, ...]:
        """Return successful ResultIR facts in stable scan order."""
        return tuple(
            result
            for item in self.successful_items
            if (result := item.result) is not None
        )

    @property
    def counts(self) -> tuple[dict[str, int], ...]:
        """Return successful counts dictionaries in stable scan order."""
        return tuple(dict(result.counts) for result in self.results)

    @property
    def probabilities(self) -> tuple[dict[str, float] | None, ...]:
        """Return successful probability dictionaries in stable scan order."""
        return tuple(
            None if result.probabilities is None else dict(result.probabilities)
            for result in self.results
        )

    @property
    def traces(self) -> tuple[RunTraceIR, ...]:
        """Return available item traces in stable scan order."""
        return tuple(item.trace for item in self.items if item.trace is not None)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> LocalHybridScanJobResult:
        """Build a terminal local scan job result from a dictionary."""
        return cls(
            job_id=data["job_id"],
            scan_id=data["scan_id"],
            plan_hash=data["plan_hash"],
            parameter_scan_hash=data["parameter_scan_hash"],
            parameter_schema_hash=data["parameter_schema_hash"],
            status=LocalHybridScanJobStatusIR.from_dict(data["status"]),
            items=tuple(
                LocalHybridScanItemOutcome.from_dict(item)
                for item in data.get("items", ())
            ),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(item) for item in data.get("diagnostics", ())
            ),
            trace=RunTraceIR.from_dict(data["trace"]),
            metadata=data.get("metadata", {}),
            schema_version=data.get(
                "schema_version",
                LOCAL_HYBRID_SCHEMA_VERSION,
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> LocalHybridScanJobResult:
        """Build a terminal local scan job result from JSON text."""
        return cls.from_dict(_json_object(text, type_name=cls.__name__))


def _derive_scan_seed(root_seed: int, scan_index: int) -> int:
    """Derive a schedule-independent uint64 seed for one scan point."""
    if not isinstance(root_seed, int) or isinstance(root_seed, bool):
        raise TypeError("root_seed must be an integer.")
    if (
        not isinstance(scan_index, int)
        or isinstance(scan_index, bool)
        or scan_index < 0
    ):
        raise ValueError("scan_index must be a non-negative integer.")
    # Index zero preserves static/single-bind equivalence. Remaining points use a
    # domain-separated digest and therefore do not depend on worker scheduling.
    if scan_index == 0:
        return root_seed
    digest = hashlib.sha256(f"scan:{root_seed}:{scan_index}".encode("ascii"))
    return int.from_bytes(digest.digest()[:8], "big", signed=False)


def _with_scan_seed(
    bundle: LocalExecutionBundle,
    *,
    scan_seed: int,
    scan_index: int,
) -> LocalExecutionBundle:
    """Return a bundle whose terminal sampler owns the derived point seed."""
    measurement = cast(MeasurementStepPayload, bundle.payloads[-1])
    seeded_measurement = replace(
        measurement,
        seed=scan_seed,
        metadata={
            **measurement.metadata,
            "root_seed_derivation": "root_seed -> scan_index",
            "scan_index": scan_index,
            "scan_seed": scan_seed,
        },
    )
    payloads = (*bundle.payloads[:-1], seeded_measurement)
    return replace(
        bundle,
        payloads=payloads,
        payload_hashes=tuple(payload.stable_hash() for payload in payloads),
        metadata={
            **bundle.metadata,
            "scan_index": scan_index,
            "scan_seed": scan_seed,
        },
    )


def _make_scan_item_executor(
    execution_plan: SimulationExecutionPlan,
    *,
    simulator: LocalHybridSimulator,
    initial_state: SimulationState | None,
    backend_id: str,
    backend_called: bool,
    execution_metadata: dict[str, Any] | None,
    analog_time_steps: int = 400,
    blockade_radius: float = 0.0,
    return_probabilities: bool = True,
    noise_model: NoiseModel | None = None,
    observables: ObservableSet | None = None,
) -> Callable[[LocalExecutionBundle, str], LocalHybridMeasurementResult]:
    """Build one immutable per-item executor from the accepted simulation plan."""
    # Direct ExecutionBuilder scans retain their explicit reference simulator.
    # LocalBackend-owned scans always honor the resource/integrator plan.
    use_reference = not backend_called or initial_state is not None
    metadata = {} if execution_metadata is None else dict(execution_metadata)
    if use_reference:
        if execution_plan.integrator_selected == "adaptive_dop853":
            raise ProgramValidationError(
                "Reference Hybrid scans do not support adaptive integration.",
                code="REFERENCE_HYBRID_INTEGRATOR_UNSUPPORTED",
                stage="simulation",
                object_path="simulation_options.integrator",
                suggestion=(
                    "Use integrator='fixed_step_krylov' or submit through "
                    "LocalBackend for adaptive execution."
                ),
                metadata={"large_array_allocated": False},
            )

        def execute_reference(
            bundle: LocalExecutionBundle,
            job_id: str,
        ) -> LocalHybridMeasurementResult:
            return simulator.run(
                bundle,
                initial_state=initial_state,
                job_id=job_id,
                backend_id=backend_id,
                backend_called=backend_called,
                execution_metadata=metadata,
            ).measurement_result()

        return execute_reference
    if initial_state is not None:
        raise ProgramValidationError(
            "Scalable parameter sweeps do not accept a reference SimulationState.",
            code="SCALABLE_HYBRID_SCAN_INITIAL_STATE_UNSUPPORTED",
            stage="simulation",
            object_path="scan.initial_state",
        )
    if noise_model is not None:
        if execution_plan.method_selected not in {
            "density_matrix",
            "trajectory",
        }:
            raise ProgramValidationError(
                "Noisy parameter sweep requires a noisy-state simulation plan.",
                code="LOCAL_HYBRID_NOISY_SCAN_METHOD_UNSUPPORTED",
                stage="simulation",
                object_path="simulation_plan.method_selected",
            )

        def execute_noisy(
            bundle: LocalExecutionBundle,
            job_id: str,
        ) -> LocalHybridMeasurementResult:
            from cascaqit.simulators.physical_noise import (
                run_physical_noisy_hybrid,
            )

            method = cast(
                Literal["density_matrix", "trajectory"],
                execution_plan.method_selected,
            )
            # Sweep concurrency owns the worker budget. Keeping each trajectory
            # item serial prevents nested pools from exceeding planned CPU/RAM.
            simulation_workers = 1
            result = run_physical_noisy_hybrid(
                bundle,
                noise_model,
                method=method,
                dtype=execution_plan.dtype,
                trajectories=execution_plan.trajectories,
                steps=min(analog_time_steps, execution_plan.max_steps),
                chunk_size=min(16, execution_plan.trajectories),
                workers=simulation_workers,
                blockade_radius=blockade_radius,
                target_id=backend_id,
                return_probabilities=return_probabilities,
                observables=observables,
                integrator_requested=execution_plan.integrator_requested,
                integrator_selected=execution_plan.integrator_selected,
                rtol=execution_plan.rtol,
                atol=execution_plan.atol,
                max_steps=execution_plan.max_steps,
            )
            selected_simulator = (
                "ExactDensityNoiseEngine"
                if method == "density_matrix"
                else "BatchedTrajectoryNoiseEngine"
            )
            evidence = require_result_solver_evidence(
                result.metadata,
                plan=execution_plan,
            )
            measurement = cast(MeasurementStepPayload, bundle.payloads[-1])
            enriched = replace(
                result,
                metadata={
                    **metadata,
                    **result.metadata,
                    **execution_config_metadata(
                        execution_plan,
                        evidence,
                        workers=simulation_workers,
                        seed=cast(int, measurement.seed),
                        execution_scope="scan_item",
                    ),
                    "backend_id": backend_id,
                    "selected_simulator": selected_simulator,
                    "backend_called": backend_called,
                    "simulation_workers": simulation_workers,
                    "offline_deterministic": True,
                    "network_accessed": False,
                    "execution_package_created": False,
                },
            )
            return _measurement_result_from_result(
                bundle,
                enriched,
                job_id=job_id,
                selected_simulator=selected_simulator,
            )

        return execute_noisy
    if execution_plan.method_selected not in {"state_vector", "subspace"}:
        raise ProgramValidationError(
            "Ideal parameter sweep requires a state-vector simulation plan.",
            code="LOCAL_HYBRID_SCAN_METHOD_UNSUPPORTED",
            stage="simulation",
            object_path="simulation_plan.method_selected",
        )

    def execute_scalable(
        bundle: LocalExecutionBundle,
        job_id: str,
    ) -> LocalHybridMeasurementResult:
        from cascaqit.simulators.ideal import run_scalable_hybrid_ideal

        result = run_scalable_hybrid_ideal(
            bundle,
            dtype=execution_plan.dtype,
            steps=min(analog_time_steps, execution_plan.max_steps),
            blockade_radius=blockade_radius,
            target_id=backend_id,
            return_probabilities=return_probabilities,
            observables=observables,
            integrator_requested=execution_plan.integrator_requested,
            integrator_selected=execution_plan.integrator_selected,
            rtol=execution_plan.rtol,
            atol=execution_plan.atol,
            max_steps=execution_plan.max_steps,
        )
        evidence = require_result_solver_evidence(
            result.metadata,
            plan=execution_plan,
        )
        measurement = cast(MeasurementStepPayload, bundle.payloads[-1])
        enriched = replace(
            result,
            metadata={
                **metadata,
                **result.metadata,
                **execution_config_metadata(
                    execution_plan,
                    evidence,
                    workers=1,
                    seed=cast(int, measurement.seed),
                    execution_scope="scan_item",
                ),
                "backend_id": backend_id,
                "selected_simulator": "ScalableIdealEngine",
                "backend_called": backend_called,
                "offline_deterministic": True,
                "network_accessed": False,
                "execution_package_created": False,
            },
        )
        return _measurement_result_from_result(
            bundle,
            enriched,
            job_id=job_id,
            selected_simulator="ScalableIdealEngine",
        )

    return execute_scalable


def _measurement_result_from_result(
    bundle: LocalExecutionBundle,
    result: ResultIR,
    *,
    job_id: str,
    selected_simulator: str,
) -> LocalHybridMeasurementResult:
    """Attach the standard scan trace contract to one array-engine ResultIR."""
    state_hash = result.metadata.get("state_hash")
    if not isinstance(state_hash, str):
        raise ProgramValidationError(
            "Array-engine scan result omitted its final state hash.",
            code="LOCAL_HYBRID_SCAN_STATE_HASH_MISSING",
            stage="simulation",
            object_path="result.metadata.state_hash",
        )
    bundle_hash = bundle.stable_hash()
    existing_references = result_references_from_result(result)
    if existing_references is None:
        raise ProgramValidationError(
            "Array-engine scan result omitted canonical runtime references.",
            code="LOCAL_HYBRID_SCAN_REFERENCES_MISSING",
            stage="simulation",
            object_path="result.metadata.references",
        )
    references = replace(
        existing_references,
        plan_hash=bundle.base_plan.stable_hash(),
        bundle_hash=bundle_hash,
        metadata={
            **existing_references.metadata,
            "graph_hash": bundle.base_plan.graph_hash,
        },
    )
    transitions = result.state_transitions()
    trace = build_runtime_trace(
        trace_id=f"trace.{job_id}",
        transitions=transitions,
        references=references,
        execution_mode="resource_bounded_scan",
        terminal_message="Local hybrid array-engine scan item completed.",
        terminal_metadata={
            "job_id": job_id,
            "result_id": result.result_id,
            "selected_simulator": selected_simulator,
        },
    )
    traced_result = replace(
        result,
        metadata={
            **result.metadata,
            **runtime_lineage_metadata(
                transitions=transitions,
                references=references,
                trace=trace,
            ),
        },
    )
    return LocalHybridMeasurementResult(
        result=traced_result,
        trace=trace,
        diagnostics=traced_result.diagnostics,
        bundle_hash=bundle_hash,
        final_state_hash=state_hash,
    )


class LocalHybridScanJob:
    """Synchronous resource-bounded scan job that executes and caches once."""

    def __init__(
        self,
        *,
        job_id: str,
        scan: ParameterScan,
        parameter_schema_hash: str,
        bind_sets: tuple[ParameterBindIR, ...],
        builder: LocalHybridExecutionBuilder,
        simulator: LocalHybridSimulator,
        initial_state: SimulationState | None,
        failure_policy: LocalHybridScanFailurePolicy,
        resource_plan: SweepResourcePlanIR,
        execution_plan: SimulationExecutionPlan,
        backend_id: str = "local.hybrid_simulator",
        backend_called: bool = False,
        execution_metadata: dict[str, Any] | None = None,
        item_executor: Callable[
            [LocalExecutionBundle, str], LocalHybridMeasurementResult
        ]
        | None = None,
    ) -> None:
        _require_identifier(job_id, field_name="job_id")
        if not isinstance(scan, ParameterScan):
            raise TypeError("scan must be ParameterScan.")
        _require_hash(parameter_schema_hash, field_name="parameter_schema_hash")
        if not isinstance(bind_sets, tuple) or any(
            not isinstance(item, ParameterBindIR) for item in bind_sets
        ):
            raise TypeError("bind_sets must contain ParameterBindIR values.")
        if not bind_sets:
            raise ValueError("local scan jobs require at least one BindSet.")
        if not isinstance(builder, LocalHybridExecutionBuilder):
            raise TypeError("builder must be LocalHybridExecutionBuilder.")
        if not isinstance(simulator, LocalHybridSimulator):
            raise TypeError("simulator must be LocalHybridSimulator.")
        if initial_state is not None and not isinstance(initial_state, SimulationState):
            raise TypeError("initial_state must be SimulationState or None.")
        if failure_policy not in {"fail_fast", "continue_on_error"}:
            raise ValueError("invalid local scan failure policy.")
        if not isinstance(resource_plan, SweepResourcePlanIR):
            raise TypeError("resource_plan must be SweepResourcePlanIR.")
        if resource_plan.bind_count != len(bind_sets):
            raise ValueError("resource_plan bind_count must match bind_sets.")
        if resource_plan.failure_policy != failure_policy:
            raise ValueError("resource_plan failure policy must match the Job.")
        if not isinstance(execution_plan, SimulationExecutionPlan):
            raise TypeError("execution_plan must be SimulationExecutionPlan.")
        _require_identifier(backend_id, field_name="backend_id")
        if not isinstance(backend_called, bool):
            raise TypeError("backend_called must be a boolean.")
        if execution_metadata is not None and not isinstance(
            execution_metadata,
            dict,
        ):
            raise TypeError("execution_metadata must be a dictionary or None.")
        if item_executor is not None and not callable(item_executor):
            raise TypeError("item_executor must be callable or None.")

        self.job_id = job_id
        self.scan = scan
        self.parameter_schema_hash = parameter_schema_hash
        self.bind_sets = bind_sets
        self.builder = builder
        self.simulator = simulator
        self.initial_state = initial_state
        self.failure_policy = failure_policy
        self.resource_plan = resource_plan
        self.execution_plan = execution_plan
        self.backend_id = backend_id
        self.backend_called = backend_called
        self.execution_metadata = (
            {} if execution_metadata is None else dict(execution_metadata)
        )
        self.item_executor = item_executor
        self._state: JobState = "queued"
        self._outcomes = tuple(
            LocalHybridScanItemOutcome(
                scan_index=index,
                bind_set=bind_set,
                state="pending",
            )
            for index, bind_set in enumerate(bind_sets)
        )
        self._result: LocalHybridScanJobResult | None = None
        self._failure_causes: dict[int, Exception] = {}

    def status(self) -> LocalHybridScanJobStatusIR:
        """Return an immutable lifecycle snapshot without executing the job."""
        counts = Counter(item.state for item in self._outcomes)
        return LocalHybridScanJobStatusIR(
            job_id=self.job_id,
            scan_id=self.scan.scan_id,
            state=self._state,
            failure_policy=self.failure_policy,
            total_items=len(self._outcomes),
            pending_count=counts["pending"],
            running_count=counts["running"],
            completed_count=counts["completed"],
            failed_count=counts["failed"],
            not_run_count=counts["not_run"],
            cancelled_count=counts["cancelled"],
            message={
                "created": "Local hybrid scan job was created.",
                "queued": (
                    "Local hybrid scan job is ready for synchronous execution."
                ),
                "running": "Local hybrid scan job is running in bounded batches.",
                "completed": "Local hybrid scan job completed.",
                "partially_completed": (
                    "Local hybrid scan job completed with partial results."
                ),
                "failed": "Local hybrid scan job failed without a successful item.",
                "cancelled": "Local hybrid scan job was cancelled before execution.",
                "expired": "Local hybrid scan job expired before execution.",
            }[self._state],
        )

    def result(self) -> LocalHybridScanJobResult:
        """Execute every point once and return the cached terminal aggregate."""
        if self._result is not None:
            return self._result
        if self._state == "cancelled":
            raise CASCAQitRuntimeError(
                "Cancelled local hybrid scan job has no result.",
                code="LOCAL_HYBRID_SCAN_JOB_CANCELLED",
                stage="simulation",
                object_path="scan_job.state",
            )
        self._state = "running"
        measurement = LocalResourceMeasurement.start()
        if self.failure_policy == "fail_fast":
            self._run_fail_fast()
        else:
            self._run_bounded_parallel()

        completed_count = sum(item.state == "completed" for item in self._outcomes)
        failed_count = sum(item.state == "failed" for item in self._outcomes)
        if failed_count == 0:
            self._state = "completed"
        elif completed_count > 0:
            self._state = "partially_completed"
        else:
            self._state = "failed"
        status = self.status()
        diagnostics = tuple(
            diagnostic
            for outcome in self._outcomes
            for diagnostic in outcome.diagnostics
        )
        trace = self._aggregate_trace(status)
        result_metadata: dict[str, Any] = {
            "execution_mode": "resource_bounded_scan",
            "failure_policy": self.failure_policy,
            "run_count": len(self._outcomes),
            "scan_resource_plan": self.resource_plan.to_dict(),
            "backend_called": self.backend_called,
            "network_accessed": False,
            "execution_package_created": False,
            "quantum_state_shared_across_items": False,
            **self.execution_metadata,
        }
        item_evidences = tuple(
            evidence
            for outcome in self._outcomes
            if outcome.result is not None
            for evidence in (
                simulation_solver_evidence_from_metadata(outcome.result.metadata),
            )
            if evidence is not None
        )
        if item_evidences:
            aggregate_evidence = aggregate_solver_evidence(
                item_evidences,
                integrator_requested=self.execution_plan.integrator_requested,
                integrator_selected=self.execution_plan.integrator_selected,
                aggregation_scope="scan_items",
            )
            result_metadata.update(
                execution_config_metadata(
                    self.execution_plan,
                    aggregate_evidence,
                    workers=self.resource_plan.selected_workers,
                    seed=self.resource_plan.root_seed,
                    execution_scope="scan",
                )
            )
        usage = measurement.finish(
            measurement_scope="scan",
            estimated_peak_bytes=self.resource_plan.estimated_peak_bytes,
        )
        result_metadata["simulation_resource_usage"] = usage.to_dict()
        if self.backend_called or self.backend_id != "local.hybrid_simulator":
            result_metadata["backend_id"] = self.backend_id
        self._result = LocalHybridScanJobResult(
            job_id=self.job_id,
            scan_id=self.scan.scan_id,
            plan_hash=self.builder.plan.stable_hash(),
            parameter_scan_hash=self.scan.stable_hash(),
            parameter_schema_hash=self.parameter_schema_hash,
            status=status,
            items=self._outcomes,
            diagnostics=diagnostics,
            trace=trace,
            metadata=result_metadata,
        )
        return self._result

    def _run_fail_fast(self) -> None:
        """Execute strictly in index order so not_run always means never started."""
        for index, bind_set in enumerate(self.bind_sets):
            outcome, cause, cache = self._execute_item(index, bind_set)
            self.builder._factory_cache.update(cache)
            if cause is None:
                self._replace_outcome(index, outcome)
                continue
            self._record_failure(
                index,
                bind_set,
                job_id=cast(str, outcome.job_id),
                bundle_id=cast(str, outcome.bundle_id),
                exc=cause,
            )
            self._mark_remaining_not_run(index + 1)
            break

    def _run_bounded_parallel(self) -> None:
        """Run fixed-size batches so futures cannot retain unbounded workspaces."""
        workers = self.resource_plan.selected_workers
        with ThreadPoolExecutor(max_workers=workers) as executor:
            for start in range(0, len(self.bind_sets), workers):
                batch = tuple(enumerate(self.bind_sets[start : start + workers], start))
                for index, bind_set in batch:
                    self._mark_running(index, bind_set)
                # executor.map yields in input order, making result reduction and
                # factory-cache publication independent of completion scheduling.
                completed = executor.map(
                    lambda pair: self._execute_item(*pair, mark_running=False),
                    batch,
                )
                for (index, bind_set), (outcome, cause, cache) in zip(
                    batch,
                    completed,
                ):
                    self.builder._factory_cache.update(cache)
                    if cause is None:
                        self._replace_outcome(index, outcome)
                    else:
                        self._record_failure(
                            index,
                            bind_set,
                            job_id=cast(str, outcome.job_id),
                            bundle_id=cast(str, outcome.bundle_id),
                            exc=cause,
                        )

    def _execute_item(
        self,
        index: int,
        bind_set: ParameterBindIR,
        *,
        mark_running: bool = True,
    ) -> tuple[
        LocalHybridScanItemOutcome,
        Exception | None,
        dict[tuple[str, str], LocalStepPayload],
    ]:
        """Build and execute one isolated point without mutating shared Job state."""
        job_id = f"{self.job_id}.{index:06d}"
        bundle_id = f"local_scan_bundle.{self.scan.scan_id}.{index:06d}"
        if mark_running:
            self._mark_running(index, bind_set)
        measurement = LocalResourceMeasurement.start()
        worker_builder = self._worker_builder()
        try:
            built = worker_builder.build(bind_set=bind_set, bundle_id=bundle_id)
            if built.bundle is None:
                raise ProgramValidationError(
                    "Local hybrid scan item failed binding preflight.",
                    code="LOCAL_HYBRID_BUILDER_NOT_READY",
                    stage="compile",
                    object_path=f"parameter_scans.{self.scan.scan_id}.points[{index}]",
                    diagnostics=built.diagnostics,
                )
            scan_seed = _derive_scan_seed(self.resource_plan.root_seed, index)
            bundle = _with_scan_seed(
                built.bundle,
                scan_seed=scan_seed,
                scan_index=index,
            )
            if self.item_executor is None:
                measurement_result = self.simulator.run(
                    bundle,
                    initial_state=self.initial_state,
                    job_id=job_id,
                    backend_id=self.backend_id,
                    backend_called=self.backend_called,
                    execution_metadata=self.execution_metadata,
                ).measurement_result()
            else:
                measurement_result = self.item_executor(bundle, job_id)
            item_execution_config = simulation_execution_config_from_metadata(
                measurement_result.result.metadata
            )
            if item_execution_config is not None:
                # Every point receives a schedule-independent derived seed.  Its
                # kernel worker count stays one while the parent scan owns the pool.
                item_workers = int(
                    measurement_result.result.metadata.get(
                        "simulation_workers",
                        1,
                    )
                )
                measurement_result = replace(
                    measurement_result,
                    result=replace(
                        measurement_result.result,
                        metadata={
                            **measurement_result.result.metadata,
                            "simulation_execution_config": replace(
                                item_execution_config,
                                workers=item_workers,
                                worker_semantics="kernel_concurrency",
                                seed=scan_seed,
                                seed_semantics="derived_scan_seed",
                                execution_scope="scan_item",
                            ).to_dict(),
                        },
                    ),
                )
            # Wall time belongs to this point, while process RSS belongs to the
            # parent scan because other points may execute concurrently.
            usage = measurement.finish(
                measurement_scope="scan_item",
                estimated_peak_bytes=self.resource_plan.per_run_peak_bytes,
                rss_owned_by_parent_scan=True,
            )
            measurement_result = replace(
                measurement_result,
                result=replace(
                    measurement_result.result,
                    metadata={
                        **measurement_result.result.metadata,
                        "simulation_resource_usage": usage.to_dict(),
                    },
                ),
            )
            return (
                LocalHybridScanItemOutcome(
                    scan_index=index,
                    bind_set=bind_set,
                    state="completed",
                    job_id=job_id,
                    bundle_id=bundle_id,
                    measurement_result=measurement_result,
                    diagnostics=measurement_result.diagnostics,
                    trace=measurement_result.trace,
                    metadata={
                        "parameter_bind_hash": bind_set.parameter_bind_hash,
                        "bundle_hash": measurement_result.bundle_hash,
                        "scan_seed": scan_seed,
                    },
                ),
                None,
                worker_builder._factory_cache,
            )
        except Exception as exc:
            return (
                LocalHybridScanItemOutcome(
                    scan_index=index,
                    bind_set=bind_set,
                    state="running",
                    job_id=job_id,
                    bundle_id=bundle_id,
                ),
                exc,
                worker_builder._factory_cache,
            )

    def _mark_running(self, index: int, bind_set: ParameterBindIR) -> None:
        self._replace_outcome(
            index,
            LocalHybridScanItemOutcome(
                scan_index=index,
                bind_set=bind_set,
                state="running",
                job_id=f"{self.job_id}.{index:06d}",
                bundle_id=f"local_scan_bundle.{self.scan.scan_id}.{index:06d}",
            ),
        )

    def _worker_builder(self) -> LocalHybridExecutionBuilder:
        worker = LocalHybridExecutionBuilder(self.builder.plan)
        worker._payloads = dict(self.builder._payloads)
        worker._factories = dict(self.builder._factories)
        worker._factory_cache = dict(self.builder._factory_cache)
        return worker

    def cancel(self) -> None:
        """Cancel a queued scan job; terminal and running states do not change."""
        if self._state != "queued":
            return
        self._state = "cancelled"
        self._outcomes = tuple(
            LocalHybridScanItemOutcome(
                scan_index=item.scan_index,
                bind_set=item.bind_set,
                state="cancelled",
            )
            for item in self._outcomes
        )

    @property
    def diagnostics(self) -> tuple[DiagnosticsIR, ...]:
        """Return item diagnostics without triggering execution."""
        return tuple(
            diagnostic
            for outcome in self._outcomes
            for diagnostic in outcome.diagnostics
        )

    @property
    def trace(self) -> RunTraceIR | None:
        """Return the aggregate trace after successful execution."""
        if self._result is None:
            return None
        return self._result.trace

    def _replace_outcome(
        self,
        index: int,
        outcome: LocalHybridScanItemOutcome,
    ) -> None:
        items = list(self._outcomes)
        items[index] = outcome
        self._outcomes = tuple(items)

    def _aggregate_trace(
        self,
        status: LocalHybridScanJobStatusIR,
    ) -> RunTraceIR:
        events = (
            (
                RunTraceEventIR(
                    stage="queued",
                    event_time="logical:scan:queued",
                    status="ok",
                    message="Local hybrid scan job was queued.",
                    metadata={
                        "scan_id": self.scan.scan_id,
                        "job_id": self.job_id,
                        "failure_policy": self.failure_policy,
                        "total_items": len(self._outcomes),
                    },
                ),
            )
            + tuple(
                RunTraceEventIR(
                    stage=("completed" if item.state == "completed" else "failed"),
                    event_time=f"logical:item:{item.scan_index:06d}",
                    status={
                        "completed": "ok",
                        "failed": "error",
                        "not_run": "skipped",
                    }[item.state],
                    message={
                        "completed": "Completed local hybrid scan item.",
                        "failed": "Local hybrid scan item failed.",
                        "not_run": "Local hybrid scan item was not run after failure.",
                    }[item.state],
                    metadata={
                        "scan_index": item.scan_index,
                        "item_state": item.state,
                        "parameter_bind_id": item.bind_set.parameter_bind_id,
                        "job_id": item.job_id,
                        "bundle_id": item.bundle_id,
                        "result_id": (
                            None if item.result is None else item.result.result_id
                        ),
                    },
                )
                for item in self._outcomes
            )
            + (
                RunTraceEventIR(
                    stage=("failed" if status.state == "failed" else "completed"),
                    event_time="logical:scan:terminal",
                    status={
                        "completed": "ok",
                        "partially_completed": "warning",
                        "failed": "error",
                    }[status.state],
                    message={
                        "completed": "Local hybrid scan job completed.",
                        "partially_completed": (
                            "Local hybrid scan job completed with partial results."
                        ),
                        "failed": "Local hybrid scan job failed.",
                    }[status.state],
                    metadata=status.to_dict(),
                ),
            )
        )
        return RunTraceIR(
            trace_id=f"trace.{self.job_id}",
            events=events,
            references=ResultReferencesIR(
                program_hash=self.builder.plan.program_hash,
                plan_hash=self.builder.plan.stable_hash(),
                metadata={
                    "graph_hash": self.builder.plan.graph_hash,
                    "parameter_scan_hash": self.scan.stable_hash(),
                    "parameter_schema_hash": self.parameter_schema_hash,
                },
            ),
            metadata={
                "execution_mode": "resource_bounded_scan",
                "scan_id": self.scan.scan_id,
                "job_id": self.job_id,
                "failure_policy": self.failure_policy,
                "selected_workers": self.resource_plan.selected_workers,
                **(
                    {
                        "backend_id": self.backend_id,
                        "backend_called": self.backend_called,
                    }
                    if self.backend_called
                    or self.backend_id != "local.hybrid_simulator"
                    else {}
                ),
            },
        )

    def _record_failure(
        self,
        index: int,
        bind_set: ParameterBindIR,
        *,
        job_id: str,
        bundle_id: str,
        exc: Exception,
    ) -> None:
        self._failure_causes[index] = exc
        trace = RunTraceIR(
            trace_id=f"trace.{self.job_id}.item.{index:06d}.failed",
            events=(
                RunTraceEventIR(
                    stage="failed",
                    event_time=f"logical:item:{index:06d}:failure",
                    status="error",
                    message="Local hybrid scan item failed.",
                    metadata={
                        "scan_index": index,
                        "parameter_bind_id": bind_set.parameter_bind_id,
                        "exception_type": type(exc).__name__,
                    },
                ),
            ),
            references=ResultReferencesIR(
                program_hash=self.builder.plan.program_hash,
                plan_hash=self.builder.plan.stable_hash(),
                metadata={
                    "graph_hash": self.builder.plan.graph_hash,
                    "parameter_scan_hash": self.scan.stable_hash(),
                    "parameter_schema_hash": self.parameter_schema_hash,
                    "parameter_bind_id": bind_set.parameter_bind_id,
                    "parameter_bind_hash": bind_set.parameter_bind_hash,
                    "job_id": job_id,
                    "bundle_id": bundle_id,
                },
            ),
            metadata={
                "execution_mode": "resource_bounded_scan",
                "scan_id": self.scan.scan_id,
                "scan_index": index,
                "failure_policy": self.failure_policy,
            },
        )
        diagnostic = DiagnosticsIR(
            diagnostic_id=f"trace.{self.job_id}.item.{index:06d}.failed",
            stage="simulation",
            severity="error",
            code=str(getattr(exc, "code", "LOCAL_HYBRID_SCAN_ITEM_FAILED")),
            message="Local hybrid scan item failed.",
            object_path=f"parameter_scans.{self.scan.scan_id}.points[{index}]",
            suggestion=getattr(exc, "suggestion", None),
            metadata={
                "scan_id": self.scan.scan_id,
                "scan_index": index,
                "parameter_bind_id": bind_set.parameter_bind_id,
                "exception_type": type(exc).__name__,
            },
        )
        self._replace_outcome(
            index,
            LocalHybridScanItemOutcome(
                scan_index=index,
                bind_set=bind_set,
                state="failed",
                job_id=job_id,
                bundle_id=bundle_id,
                diagnostics=(diagnostic,),
                trace=trace,
                metadata={
                    "parameter_bind_hash": bind_set.parameter_bind_hash,
                    "failure_code": diagnostic.code,
                },
            ),
        )

    def _mark_remaining_not_run(self, start_index: int) -> None:
        for remaining_index in range(start_index, len(self.bind_sets)):
            self._replace_outcome(
                remaining_index,
                LocalHybridScanItemOutcome(
                    scan_index=remaining_index,
                    bind_set=self.bind_sets[remaining_index],
                    state="not_run",
                ),
            )


@dataclass(frozen=True)
class LocalHybridCapabilityIR(IRMixin):
    """Resource-driven capability summary for local Hybrid simulation."""

    backend_id: str = "local.hybrid_simulator"
    supported_gates: tuple[str, ...] = tuple(sorted(_HYBRID_DIGITAL_GATES))
    supported_waveforms: tuple[str, ...] = tuple(sorted(_HYBRID_ANALOG_WAVEFORMS))
    planned_simulation_methods: tuple[str, ...] = (
        "state_vector",
        "subspace",
        "density_matrix",
        "trajectory",
    )
    executable_simulation_methods: tuple[str, ...] = ("state_vector",)
    supported_devices: tuple[str, ...] = ("cpu",)
    supported_dtypes: tuple[str, ...] = ("complex64", "complex128")
    resource_driven_planning: bool = True
    default_memory_fraction: float = 0.8
    scalable_engine_status: Literal["contract_only"] = "contract_only"
    local_detuning_status: Literal["experimental"] = "experimental"
    local_detuning_addressing: tuple[str, ...] = (
        "site_pattern_static",
        "site_mask_static",
        "site_mask_piecewise",
    )
    local_rabi_status: Literal["experimental"] = "experimental"
    local_rabi_addressing: tuple[str, ...] = (
        "site_pattern_static",
        "site_mask_static",
        "site_mask_piecewise",
    )
    measurement_basis: Literal["computational"] = "computational"
    execution_model: Literal["synchronous"] = "synchronous"
    offline_deterministic: bool = True
    noise_supported: bool = False
    hardware_or_cloud_supported: bool = False
    execution_package_created: bool = False
    schema_version: str = LOCAL_HYBRID_SCHEMA_VERSION


@dataclass(frozen=True)
class LocalHybridJobStatusIR(IRMixin):
    """Immutable snapshot of one synchronous local hybrid job."""

    job_id: str
    state: JobState
    bundle_hash: str
    execution_count: int
    message: str
    backend_id: str = "local.hybrid_simulator"
    backend_called: bool = False
    network_accessed: bool = False
    execution_package_created: bool = False
    schema_version: str = LOCAL_HYBRID_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_identifier(self.job_id, field_name="job_id")
        validate_job_state(self.state)
        _require_hash(self.bundle_hash, field_name="bundle_hash")
        if self.execution_count not in {0, 1}:
            raise ValueError("execution_count must be zero or one.")
        _require_identifier(self.message, field_name="message")


class LocalHybridJob:
    """Synchronous local job that executes and caches at most once."""

    def __init__(
        self,
        *,
        job_id: str,
        bundle: LocalExecutionBundle,
        initial_state: SimulationState | None = None,
        digital_adapter: DigitalStepAdapter | None = None,
        analog_adapter: AnalogStepAdapter | None = None,
        backend_id: str = "local.hybrid_simulator",
        backend_called: bool = False,
        execution_metadata: dict[str, Any] | None = None,
    ) -> None:
        _require_identifier(job_id, field_name="job_id")
        _require_identifier(backend_id, field_name="backend_id")
        if not isinstance(backend_called, bool):
            raise TypeError("backend_called must be a boolean.")
        if execution_metadata is not None and not isinstance(
            execution_metadata,
            dict,
        ):
            raise TypeError("execution_metadata must be a dictionary or None.")
        if not isinstance(bundle, LocalExecutionBundle):
            raise TypeError("bundle must be LocalExecutionBundle.")
        if initial_state is not None and not isinstance(initial_state, SimulationState):
            raise TypeError("initial_state must be SimulationState or None.")
        if digital_adapter is not None and not isinstance(
            digital_adapter, DigitalStepAdapter
        ):
            raise TypeError("digital_adapter must be DigitalStepAdapter or None.")
        if analog_adapter is not None and not isinstance(
            analog_adapter, AnalogStepAdapter
        ):
            raise TypeError("analog_adapter must be AnalogStepAdapter or None.")
        self.job_id = job_id
        self.bundle = bundle
        self.initial_state = initial_state
        self.digital_adapter = digital_adapter
        self.analog_adapter = analog_adapter
        self.backend_id = backend_id
        self.backend_called = backend_called
        self.execution_metadata = (
            {} if execution_metadata is None else dict(execution_metadata)
        )
        self._state: JobState = "queued"
        self._execution_count = 0
        self._measurement_result: LocalHybridMeasurementResult | None = None
        self._error: Exception | None = None
        self._failure_diagnostics: tuple[DiagnosticsIR, ...] = ()
        self._failure_trace: RunTraceIR | None = None

    def status(self) -> LocalHybridJobStatusIR:
        """Return a deterministic lifecycle snapshot without executing."""
        return LocalHybridJobStatusIR(
            job_id=self.job_id,
            state=self._state,
            bundle_hash=self.bundle.stable_hash(),
            execution_count=self._execution_count,
            message={
                "created": "Local hybrid job was created.",
                "queued": "Local hybrid job is ready for synchronous execution.",
                "running": "Local hybrid job is running synchronously.",
                "completed": "Local hybrid job completed.",
                "partially_completed": (
                    "Local hybrid job completed with partial results."
                ),
                "failed": "Local hybrid job failed.",
                "cancelled": "Local hybrid job was cancelled before execution.",
                "expired": "Local hybrid job expired before execution.",
            }[self._state],
            backend_id=self.backend_id,
            backend_called=self.backend_called,
        )

    def result(self) -> ResultIR:
        """Execute once when needed and return the cached unified ResultIR."""
        if self._measurement_result is not None:
            return self._measurement_result.result
        if self._state == "cancelled":
            raise CASCAQitRuntimeError(
                "Cancelled local hybrid job has no result.",
                code="LOCAL_HYBRID_JOB_CANCELLED",
                stage="simulation",
                object_path="job.state",
            )
        if self._error is not None:
            raise self._error
        self._state = "running"
        self._execution_count = 1
        measurement = LocalResourceMeasurement.start()
        try:
            state_run = run_local_hybrid_state(
                self.bundle,
                initial_state=self.initial_state,
                digital_adapter=self.digital_adapter,
                analog_adapter=self.analog_adapter,
            )
            self._measurement_result = measure_local_hybrid_state(
                state_run,
                backend_id=self.backend_id,
                backend_called=self.backend_called,
            )
            if self.execution_metadata:
                enriched_result = replace(
                    self._measurement_result.result,
                    metadata={
                        **self._measurement_result.result.metadata,
                        **self.execution_metadata,
                    },
                )
                self._measurement_result = replace(
                    self._measurement_result,
                    result=enriched_result,
                )
            result = self._measurement_result.result
            estimated_peak_bytes = estimated_peak_bytes_from_metadata(result.metadata)
            usage = measurement.finish(
                measurement_scope="job",
                estimated_peak_bytes=estimated_peak_bytes,
            )
            self._measurement_result = replace(
                self._measurement_result,
                result=replace(
                    result,
                    metadata={
                        **result.metadata,
                        "simulation_resource_usage": usage.to_dict(),
                    },
                ),
            )
        except Exception as exc:
            self._state = "failed"
            self._error = exc
            (
                self._failure_diagnostics,
                self._failure_trace,
            ) = _local_job_failure_evidence(self, exc)
            raise
        self._state = "completed"
        return self._measurement_result.result

    def measurement_result(self) -> LocalHybridMeasurementResult:
        """Return the cached Result/Trace wrapper, executing once if needed."""
        self.result()
        return cast(LocalHybridMeasurementResult, self._measurement_result)

    def cancel(self) -> None:
        """Cancel a queued job; terminal states remain unchanged."""
        if self._state == "queued":
            self._state = "cancelled"

    @property
    def diagnostics(self) -> tuple[DiagnosticsIR, ...]:
        """Return completed or failed diagnostics without triggering execution."""
        if self._measurement_result is not None:
            return self._measurement_result.diagnostics
        return self._failure_diagnostics

    @property
    def trace(self) -> RunTraceIR | None:
        """Return completed or failed trace without triggering execution."""
        if self._measurement_result is not None:
            return self._measurement_result.trace
        return self._failure_trace


@dataclass(frozen=True)
class LocalHybridSimulator:
    """Offline synchronous entry point for validated local execution bundles."""

    digital_adapter: DigitalStepAdapter = field(default_factory=DigitalStepAdapter)
    analog_adapter: AnalogStepAdapter = field(default_factory=AnalogStepAdapter)

    def __post_init__(self) -> None:
        if not isinstance(self.digital_adapter, DigitalStepAdapter):
            raise TypeError("digital_adapter must be DigitalStepAdapter.")
        if not isinstance(self.analog_adapter, AnalogStepAdapter):
            raise TypeError("analog_adapter must be AnalogStepAdapter.")

    @property
    def capability(self) -> LocalHybridCapabilityIR:
        """Return the frozen Hybrid P0 capability summary."""
        return LocalHybridCapabilityIR()

    def run(
        self,
        bundle: LocalExecutionBundle,
        *,
        initial_state: SimulationState | None = None,
        job_id: str | None = None,
        backend_id: str = "local.hybrid_simulator",
        backend_called: bool = False,
        execution_metadata: dict[str, Any] | None = None,
    ) -> LocalHybridJob:
        """Create a submitted synchronous job without executing it."""
        self.preflight(bundle, initial_state=initial_state)
        resolved_job_id = f"local_job.{bundle.bundle_id}" if job_id is None else job_id
        return LocalHybridJob(
            job_id=resolved_job_id,
            bundle=bundle,
            initial_state=initial_state,
            digital_adapter=self.digital_adapter,
            analog_adapter=self.analog_adapter,
            backend_id=backend_id,
            backend_called=backend_called,
            execution_metadata=execution_metadata,
        )

    def preflight(
        self,
        bundle: LocalExecutionBundle,
        *,
        initial_state: SimulationState | None = None,
    ) -> None:
        """Reject guaranteed static execution failures before Job creation."""
        if not isinstance(bundle, LocalExecutionBundle):
            raise TypeError("bundle must be LocalExecutionBundle.")
        if initial_state is not None and not isinstance(initial_state, SimulationState):
            raise TypeError("initial_state must be SimulationState or None.")
        quantum_payloads = _validate_execution_boundary(bundle, stage="compile")
        state = initial_state or SimulationState.zero(
            quantum_payloads[0].logical_order,
            state_id=f"state.{bundle.bundle_id}.preflight",
            time_unit=_initial_time_unit(quantum_payloads),
        )
        _validate_preflight_initial_state(quantum_payloads, state)
        measurement = cast(MeasurementStepPayload, bundle.payloads[-1])
        if measurement.seed is None:
            _raise_runner_error(
                "Terminal measurement requires an explicit deterministic seed.",
                code="LOCAL_HYBRID_MEASUREMENT_SEED_REQUIRED",
                object_path="measurement.seed",
                suggestion="Set an integer seed on MeasurementStepPayload.",
                stage="compile",
            )
        for step, payload in zip(bundle.base_plan.steps[:-1], quantum_payloads):
            if isinstance(payload, DigitalStepPayload):
                self.digital_adapter.validate(step, payload)
            else:
                self.analog_adapter.validate(step, payload)


def bind_local_execution_bundle(
    plan: LocalExecutionPlan,
    payloads: Iterable[LocalStepPayload],
    *,
    bundle_id: str | None = None,
) -> LocalExecutionBundleResult:
    """Validate native payloads and bind them without running a kernel."""
    if not isinstance(plan, LocalExecutionPlan):
        raise TypeError("plan must be LocalExecutionPlan.")
    try:
        bound_payloads = tuple(payloads)
    except TypeError as exc:
        raise TypeError("payloads must be an iterable of local step payloads.") from exc
    resolved_bundle_id = (
        f"local_bundle.{plan.plan_id}" if bundle_id is None else bundle_id
    )
    _require_identifier(resolved_bundle_id, field_name="bundle_id")

    diagnostics: list[OrchestrationDiagnosticIR] = []
    valid_payloads: list[LocalStepPayload] = []
    for index, payload in enumerate(bound_payloads):
        if not isinstance(payload, _PAYLOAD_TYPES):
            _add_binding_diagnostic(
                diagnostics,
                code="LOCAL_BUNDLE_PAYLOAD_TYPE_INVALID",
                message="Bundle payload is not a native local step payload.",
                object_path=f"payloads[{index}]",
                suggestion=(
                    "Use DigitalStepPayload, AnalogStepPayload, or "
                    "MeasurementStepPayload."
                ),
                metadata={"index": index, "actual_type": type(payload).__name__},
            )
            continue
        valid_payloads.append(payload)

    _diagnose_plan_requirements(plan, diagnostics)
    _diagnose_payload_identity(plan, valid_payloads, diagnostics)
    _diagnose_payload_alignment(plan, valid_payloads, diagnostics)
    if diagnostics:
        return LocalExecutionBundleResult(bundle=None, diagnostics=tuple(diagnostics))

    payload_tuple = tuple(valid_payloads)
    bundle = LocalExecutionBundle(
        bundle_id=resolved_bundle_id,
        base_plan=plan,
        base_plan_hash=plan.stable_hash(),
        payloads=payload_tuple,
        payload_hashes=tuple(payload.stable_hash() for payload in payload_tuple),
        metadata={
            "base_plan_execution_ready": plan.execution_ready,
            "kernel_execution": False,
            "mixed_state_handoff_executed": False,
            "payload_count": len(payload_tuple),
        },
    )
    return LocalExecutionBundleResult(bundle=bundle)


def run_local_hybrid_state(
    bundle: LocalExecutionBundle,
    *,
    initial_state: SimulationState | None = None,
    digital_adapter: DigitalStepAdapter | None = None,
    analog_adapter: AnalogStepAdapter | None = None,
) -> LocalHybridStateRun:
    """Run Digital/Analog steps serially and stop before terminal measurement."""
    if not isinstance(bundle, LocalExecutionBundle):
        raise TypeError("bundle must be LocalExecutionBundle.")
    if initial_state is not None and not isinstance(initial_state, SimulationState):
        raise TypeError("initial_state must be SimulationState or None.")
    if digital_adapter is not None and not isinstance(
        digital_adapter, DigitalStepAdapter
    ):
        raise TypeError("digital_adapter must be DigitalStepAdapter or None.")
    if analog_adapter is not None and not isinstance(analog_adapter, AnalogStepAdapter):
        raise TypeError("analog_adapter must be AnalogStepAdapter or None.")

    quantum_payloads = _validate_execution_boundary(bundle, stage="simulation")

    first_order = quantum_payloads[0].logical_order
    state = initial_state or SimulationState.zero(
        first_order,
        state_id=f"state.{bundle.bundle_id}.initial",
        time_unit=_initial_time_unit(quantum_payloads),
    )
    start_state = state
    digital = digital_adapter or DigitalStepAdapter()
    analog = analog_adapter or AnalogStepAdapter()
    transitions: list[StateTransitionIR] = []
    for step, payload in zip(bundle.base_plan.steps[:-1], quantum_payloads):
        input_state = state
        if isinstance(payload, DigitalStepPayload):
            state = digital.apply(step, payload, input_state)
            quantum_payload: DigitalStepPayload | AnalogStepPayload = payload
            evidence = not_applicable_solver_evidence(
                integrator_requested="fixed_step_krylov",
                logical_time=state.logical_time,
                time_unit=state.time_unit,
                consumer=state.provenance.producer,
            )
            transition_metadata: dict[str, Any] = {}
        else:
            quantum_payload = payload
            state = analog.apply(
                step,
                quantum_payload,
                input_state,
            )
            provenance_metadata = dict(state.provenance.metadata)
            raw_evidence = provenance_metadata.get("solver_evidence_json")
            if not isinstance(raw_evidence, str):
                raise ProgramValidationError(
                    "Reference Analog kernel omitted solver evidence.",
                    code="SIMULATION_SOLVER_EVIDENCE_MISSING",
                    stage="simulation",
                    object_path=(
                        f"bundle.payloads[{step.order_index}]"
                        ".provenance.solver_evidence_json"
                    ),
                )
            evidence_data = json.loads(raw_evidence)
            if not isinstance(evidence_data, dict):
                raise ProgramValidationError(
                    "Reference Analog solver evidence is not an object.",
                    code="SIMULATION_SOLVER_EVIDENCE_INVALID",
                    stage="simulation",
                    object_path=(
                        f"bundle.payloads[{step.order_index}]"
                        ".provenance.solver_evidence_json"
                    ),
                )
            evidence = SimulationSolverEvidenceIR.from_dict(evidence_data)
            transition_metadata = site_addressing_provenance_metadata(
                quantum_payload.program,
                consumer=state.provenance.producer,
            )
            transition_metadata.update(
                site_phase_pattern_provenance_metadata(
                    quantum_payload.program,
                    consumer=state.provenance.producer,
                )
            )
        source_hash = quantum_payload.program.stable_hash()
        if state.provenance.parent_state_hash != input_state.stable_hash():
            _raise_runner_error(
                "Kernel output does not reference the actual input state.",
                code="LOCAL_HYBRID_STATE_CHAIN_BROKEN",
                object_path="simulation_state.provenance.parent_state_hash",
                suggestion="Use a state kernel that preserves explicit lineage.",
                metadata={"step_id": step.step_id},
            )
        if state.provenance.source_hash != source_hash:
            _raise_runner_error(
                "Kernel output source hash does not match the step program.",
                code="LOCAL_HYBRID_STATE_SOURCE_HASH_MISMATCH",
                object_path="simulation_state.provenance.source_hash",
                suggestion="Record the native program hash in kernel provenance.",
                metadata={"step_id": step.step_id},
            )
        transitions.append(
            build_state_transition(
                transition_id=f"transition.{step.order_index}.{step.block_id}",
                order_index=step.order_index,
                block_id=step.block_id,
                program_kind=quantum_payload.payload_kind,
                program_hash=source_hash,
                kernel=state.provenance.producer,
                input_state_hash=input_state.stable_hash(),
                input_logical_time=input_state.logical_time,
                output_state_hash=state.stable_hash(),
                output_logical_time=state.logical_time,
                time_unit=state.time_unit,
                solver_evidence=evidence,
                metadata={
                    **transition_metadata,
                    "step_id": step.step_id,
                    "payload_id": quantum_payload.payload_id,
                    "payload_hash": quantum_payload.stable_hash(),
                    "input_state_id": input_state.state_id,
                    "output_state_id": state.state_id,
                    "logical_order": list(state.logical_order),
                    "producer": state.provenance.producer,
                },
            )
        )
    return LocalHybridStateRun(
        bundle=bundle,
        initial_state=start_state,
        final_state=state,
        transitions=tuple(transitions),
    )


def measure_local_hybrid_state(
    state_run: LocalHybridStateRun,
    *,
    backend_id: str = "local.hybrid_simulator",
    backend_called: bool = False,
) -> LocalHybridMeasurementResult:
    """Sample the final state and assemble deterministic Result/Trace IR."""
    if not isinstance(state_run, LocalHybridStateRun):
        raise TypeError("state_run must be LocalHybridStateRun.")
    _require_identifier(backend_id, field_name="backend_id")
    if not isinstance(backend_called, bool):
        raise TypeError("backend_called must be a boolean.")
    measurement = cast(MeasurementStepPayload, state_run.bundle.payloads[-1])
    if measurement.seed is None:
        _raise_runner_error(
            "Terminal measurement requires an explicit deterministic seed.",
            code="LOCAL_HYBRID_MEASUREMENT_SEED_REQUIRED",
            object_path="measurement.seed",
            suggestion="Set an integer seed on MeasurementStepPayload.",
        )
    probabilities = state_run.final_state.probabilities()
    outcomes = tuple(sorted(probabilities))
    rng = random.Random(measurement.seed)
    samples = tuple(
        rng.choices(
            outcomes,
            weights=tuple(probabilities[item] for item in outcomes),
            k=measurement.shots,
        )
    )
    counts = dict(sorted(Counter(samples).items()))
    bundle = state_run.bundle
    plan = bundle.base_plan
    bundle_hash = bundle.stable_hash()
    final_state_hash = state_run.final_state.stable_hash()
    injected_backend = backend_called or backend_id != "local.hybrid_simulator"
    trace_id = f"trace.{bundle.bundle_id}.local_hybrid"
    references = build_runtime_references(
        program_hash=plan.program_hash,
        plan_hash=bundle.base_plan_hash,
        bundle_hash=bundle_hash,
        initial_state_hash=state_run.initial_state.stable_hash(),
        final_state_hash=final_state_hash,
        metadata={"graph_hash": plan.graph_hash},
    )
    trace = build_runtime_trace(
        trace_id=trace_id,
        transitions=state_run.transitions,
        references=references,
        execution_mode="local_hybrid_shared_state",
        terminal_message="Terminal computational-basis measurement completed.",
        terminal_metadata={
            "measurement_key": measurement.measurement_key,
            "shots": measurement.shots,
            "seed": measurement.seed,
        },
    )
    analog_evidences = tuple(
        SimulationSolverEvidenceIR.from_dict(
            cast(dict[str, Any], item.metadata["solver_evidence"])
        )
        for item in state_run.transitions
        if item.program_kind == "analog"
    )
    solver_evidence = aggregate_solver_evidence(
        analog_evidences,
        integrator_requested="fixed_step_krylov",
        integrator_selected=(
            "fixed_step_krylov" if analog_evidences else "not_applicable"
        ),
        aggregation_scope="reference_hybrid_quantum_blocks",
    )
    diagnostic = DiagnosticsIR(
        diagnostic_id=f"{trace_id}.completed",
        stage="simulation",
        severity="info",
        code="LOCAL_HYBRID_SIMULATION_COMPLETED",
        message="Local hybrid shared-state simulation and measurement completed.",
        object_path="result",
        suggestion=None,
        metadata={
            "trace_id": trace_id,
            "source_span": None
            if measurement.source_span is None
            else measurement.source_span.to_dict(),
            **({"backend_id": backend_id} if injected_backend else {}),
        },
    )
    diagnostics = (diagnostic,)
    state_summary = state_run.final_state.to_summary().to_dict()
    result = ResultIR(
        result_id=f"result.{bundle.bundle_id}",
        program_hash=plan.program_hash,
        target_id=backend_id,
        shots=measurement.shots,
        counts=counts,
        samples=samples,
        probabilities=probabilities,
        bit_ordering={
            "convention": "logical_order",
            "logical_order": ",".join(state_run.final_state.logical_order),
        },
        diagnostics=diagnostics,
        metadata={
            "seed": measurement.seed,
            "measurement": {
                "basis": measurement.basis,
                "key": measurement.measurement_key,
                "targets": list(measurement.logical_order),
            },
            "register_snapshots": collect_register_snapshot_evidence(
                payload.program
                for payload in state_run.bundle.payloads
                if isinstance(payload, AnalogStepPayload)
            ),
            **solver_evidence_metadata(solver_evidence),
            **runtime_lineage_metadata(
                transitions=state_run.transitions,
                references=references,
                trace=trace,
            ),
            "simulation_state": {
                "final": state_summary,
                "state_bytes_returned": False,
            },
            "backend_called": backend_called,
            "network_accessed": False,
            **(
                {
                    "backend_id": backend_id,
                    "execution_package_created": False,
                }
                if injected_backend
                else {}
            ),
        },
    )
    return LocalHybridMeasurementResult(
        result=result,
        trace=trace,
        diagnostics=diagnostics,
        bundle_hash=bundle_hash,
        final_state_hash=final_state_hash,
    )


def _validate_execution_boundary(
    bundle: LocalExecutionBundle,
    *,
    stage: _ValidationStage,
) -> tuple[DigitalStepPayload | AnalogStepPayload, ...]:
    measurement_indices = tuple(
        index
        for index, payload in enumerate(bundle.payloads)
        if isinstance(payload, MeasurementStepPayload)
    )
    if measurement_indices != (len(bundle.payloads) - 1,):
        _raise_runner_error(
            "Local hybrid state runner requires one terminal measurement payload.",
            code="LOCAL_HYBRID_MEASUREMENT_BOUNDARY_INVALID",
            object_path="bundle.payloads",
            suggestion="Place exactly one measurement payload after all quantum steps.",
            stage=stage,
            metadata={"measurement_indices": list(measurement_indices)},
        )
    quantum_payloads = bundle.payloads[:-1]
    if not quantum_payloads:
        _raise_runner_error(
            "Local hybrid state runner requires a Digital or Analog step.",
            code="LOCAL_HYBRID_QUANTUM_STEP_MISSING",
            object_path="bundle.payloads",
            suggestion="Add at least one Digital or Analog block before measurement.",
            stage=stage,
        )
    return tuple(
        payload
        for payload in quantum_payloads
        if isinstance(payload, (DigitalStepPayload, AnalogStepPayload))
    )


def _validate_preflight_initial_state(
    payloads: tuple[DigitalStepPayload | AnalogStepPayload, ...],
    initial_state: SimulationState,
) -> None:
    expected_order = payloads[0].logical_order
    if initial_state.logical_order != expected_order:
        _raise_runner_error(
            "Initial state logical order does not match the Hybrid payload order.",
            code="LOCAL_HYBRID_INITIAL_STATE_LOGICAL_ORDER_MISMATCH",
            object_path="simulation_state.logical_order",
            suggestion=(
                "Apply an explicit SimulationState.permute() before submission."
            ),
            stage="compile",
            metadata={
                "expected_order": list(expected_order),
                "state_order": list(initial_state.logical_order),
            },
        )
    for index, payload in enumerate(payloads):
        if not isinstance(payload, AnalogStepPayload):
            continue
        waveform_units = _analog_time_units(payload)
        if waveform_units != {initial_state.time_unit}:
            _raise_runner_error(
                "Initial state and Analog waveform time units do not match.",
                code="LOCAL_HYBRID_INITIAL_STATE_TIME_UNIT_MISMATCH",
                object_path=f"bundle.payloads[{index}].program.hamiltonian",
                suggestion=(
                    "Use one explicit time unit for the initial state and every "
                    "Analog waveform."
                ),
                stage="compile",
                metadata={
                    "block_id": payload.block_id,
                    "state_time_unit": initial_state.time_unit,
                    "waveform_time_units": sorted(waveform_units),
                },
            )


def _analog_time_units(payload: AnalogStepPayload) -> set[str]:
    hamiltonian = payload.program.hamiltonian
    units = {
        hamiltonian.rabi.time_unit,
        hamiltonian.detuning.time_unit,
    }
    if isinstance(hamiltonian.phase, WaveformIR):
        units.add(hamiltonian.phase.time_unit)
    units.update(term.waveform.time_unit for term in hamiltonian.local_detuning_terms)
    for term in hamiltonian.local_rabi_terms:
        units.add(term.rabi.time_unit)
        if isinstance(term.phase, WaveformIR):
            units.add(term.phase.time_unit)
    return units


def _initial_time_unit(
    payloads: tuple[DigitalStepPayload | AnalogStepPayload, ...],
) -> str:
    for payload in payloads:
        if isinstance(payload, AnalogStepPayload):
            return payload.program.hamiltonian.rabi.time_unit
    return "us"


def _local_job_failure_evidence(
    job: LocalHybridJob,
    exc: Exception,
) -> tuple[tuple[DiagnosticsIR, ...], RunTraceIR]:
    code = getattr(exc, "code", "LOCAL_HYBRID_JOB_EXECUTION_FAILED")
    diagnostic = DiagnosticsIR(
        diagnostic_id=f"trace.{job.job_id}.failed",
        stage="simulation",
        severity="error",
        code=str(code),
        message=str(exc) or type(exc).__name__,
        object_path=getattr(exc, "object_path", "job.result"),
        suggestion=getattr(exc, "suggestion", None),
        metadata={"job_id": job.job_id, "exception_type": type(exc).__name__},
    )
    references = ResultReferencesIR(
        program_hash=job.bundle.base_plan.program_hash,
        plan_hash=job.bundle.base_plan_hash,
        bundle_hash=job.bundle.stable_hash(),
        metadata={
            "graph_hash": job.bundle.base_plan.graph_hash,
        },
    )
    trace = RunTraceIR(
        trace_id=f"trace.{job.job_id}.failed",
        references=references,
        events=(
            RunTraceEventIR(
                stage="failed",
                event_time="logical:failure",
                status="error",
                message=diagnostic.message,
                metadata={"code": diagnostic.code, "job_id": job.job_id},
            ),
        ),
        metadata={"execution_mode": "local_hybrid_shared_state"},
    )
    return (diagnostic,), trace


def _raise_runner_error(
    message: str,
    *,
    code: str,
    object_path: str,
    suggestion: str,
    stage: _ValidationStage = "simulation",
    metadata: dict[str, Any] | None = None,
) -> None:
    raise ProgramValidationError(
        message,
        code=code,
        stage=stage,
        object_path=object_path,
        suggestion=suggestion,
        metadata={} if metadata is None else metadata,
    )


def _diagnose_plan_requirements(
    plan: LocalExecutionPlan,
    diagnostics: list[OrchestrationDiagnosticIR],
) -> None:
    expected = tuple(
        f"payload:{step.block_id}:{step.kernel_kind}" for step in plan.steps
    )
    if plan.payload_requirements != expected:
        _add_binding_diagnostic(
            diagnostics,
            code="LOCAL_BUNDLE_PLAN_REQUIREMENTS_MISMATCH",
            message="Base plan payload requirements do not match its steps.",
            object_path="plan.payload_requirements",
            suggestion="Recompile the HybridProgram before binding payloads.",
            metadata={"expected": list(expected)},
        )


def _diagnose_payload_identity(
    plan: LocalExecutionPlan,
    payloads: list[LocalStepPayload],
    diagnostics: list[OrchestrationDiagnosticIR],
) -> None:
    seen_payload_ids: set[str] = set()
    seen_block_ids: set[str] = set()
    plan_block_ids = {step.block_id for step in plan.steps}
    for index, payload in enumerate(payloads):
        if payload.payload_id in seen_payload_ids:
            _add_binding_diagnostic(
                diagnostics,
                code="LOCAL_BUNDLE_PAYLOAD_ID_DUPLICATE",
                message="Bundle payload ids must be unique.",
                object_path=f"payloads[{index}].payload_id",
                suggestion="Assign one stable payload id to each step payload.",
                source_span=payload.source_span,
                metadata={"payload_id": payload.payload_id},
            )
        seen_payload_ids.add(payload.payload_id)
        if payload.block_id in seen_block_ids:
            _add_binding_diagnostic(
                diagnostics,
                code="LOCAL_BUNDLE_BLOCK_DUPLICATE",
                message="More than one payload targets the same block.",
                object_path=f"payloads[{index}].block_id",
                suggestion="Bind exactly one payload to each plan block.",
                source_span=payload.source_span,
                metadata={"block_id": payload.block_id},
            )
        seen_block_ids.add(payload.block_id)
        if payload.block_id not in plan_block_ids:
            _add_binding_diagnostic(
                diagnostics,
                code="LOCAL_BUNDLE_BLOCK_UNKNOWN",
                message="Payload references a block that is absent from the plan.",
                object_path=f"payloads[{index}].block_id",
                suggestion="Use a block id from LocalExecutionPlan.steps.",
                source_span=payload.source_span,
                metadata={"block_id": payload.block_id},
            )

    for step in plan.steps:
        if not any(payload.block_id == step.block_id for payload in payloads):
            _add_binding_diagnostic(
                diagnostics,
                code="LOCAL_BUNDLE_PAYLOAD_MISSING",
                message="A plan step has no bound payload.",
                object_path=f"plan.steps[{step.order_index}]",
                suggestion="Provide one native payload for this block.",
                source_span=step.source_span,
                metadata={"block_id": step.block_id},
            )


def _diagnose_payload_alignment(
    plan: LocalExecutionPlan,
    payloads: list[LocalStepPayload],
    diagnostics: list[OrchestrationDiagnosticIR],
) -> None:
    step_block_ids = tuple(step.block_id for step in plan.steps)
    payload_block_ids = tuple(payload.block_id for payload in payloads)
    if (
        len(payload_block_ids) == len(step_block_ids)
        and len(set(payload_block_ids)) == len(payload_block_ids)
        and set(payload_block_ids) == set(step_block_ids)
        and payload_block_ids != step_block_ids
    ):
        _add_binding_diagnostic(
            diagnostics,
            code="LOCAL_BUNDLE_PAYLOAD_ORDER_MISMATCH",
            message="Payload order does not match the base plan step order.",
            object_path="payloads",
            suggestion="Order payloads by LocalExecutionPlan.steps.",
            metadata={"expected_block_ids": list(step_block_ids)},
        )

    unique_by_block = {
        payload.block_id: payload
        for payload in payloads
        if sum(item.block_id == payload.block_id for item in payloads) == 1
    }
    ordered_matches = [
        (step, unique_by_block[step.block_id])
        for step in plan.steps
        if step.block_id in unique_by_block
    ]
    canonical_order = (
        None if not ordered_matches else ordered_matches[0][1].logical_order
    )
    for step, payload in ordered_matches:
        source_span = payload.source_span or step.source_span
        if payload.payload_kind != step.kernel_kind:
            _add_binding_diagnostic(
                diagnostics,
                code="LOCAL_BUNDLE_PAYLOAD_KIND_MISMATCH",
                message="Payload kind does not match the plan kernel kind.",
                object_path=f"plan.steps[{step.order_index}].kernel_kind",
                suggestion="Bind the native payload type required by this step.",
                source_span=source_span,
                metadata={
                    "actual": payload.payload_kind,
                    "expected": step.kernel_kind,
                },
            )
        if canonical_order is not None and payload.logical_order != canonical_order:
            _add_binding_diagnostic(
                diagnostics,
                code="LOCAL_BUNDLE_LOGICAL_ORDER_MISMATCH",
                message="Payloads do not share one explicit logical order.",
                object_path=f"payloads[{step.order_index}].logical_order",
                suggestion="Compile every payload to the same logical order.",
                source_span=source_span,
                metadata={
                    "actual": list(payload.logical_order),
                    "expected": list(canonical_order),
                },
            )
        if set(step.mapping.values()) != set(payload.logical_order):
            _add_binding_diagnostic(
                diagnostics,
                code="LOCAL_BUNDLE_MAPPING_MISMATCH",
                message="Step mapping and payload logical ids do not match.",
                object_path=f"plan.steps[{step.order_index}].mapping",
                suggestion="Compile payload ids from the step's explicit mapping.",
                source_span=source_span,
                metadata={
                    "mapping_targets": sorted(set(step.mapping.values())),
                    "payload_logical_order": list(payload.logical_order),
                },
            )


def _add_binding_diagnostic(
    diagnostics: list[OrchestrationDiagnosticIR],
    *,
    code: str,
    message: str,
    object_path: str,
    suggestion: str,
    source_span: SourceSpan | None = None,
    metadata: dict[str, Any] | None = None,
) -> None:
    diagnostics.append(
        OrchestrationDiagnosticIR(
            diagnostic_id=f"local_bundle.{len(diagnostics)}.{code.lower()}",
            stage="compile",
            severity="error",
            code=code,
            message=message,
            object_path=object_path,
            source_span=source_span,
            suggestion=suggestion,
            metadata={} if metadata is None else metadata,
        )
    )
