"""Canonical runtime lineage shared by standalone and Hybrid simulators."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Literal

from cascaqit.results import (
    ResultReferencesIR,
    RunTraceEventIR,
    RunTraceIR,
    SimulationSolverEvidenceIR,
    StateTransitionIR,
    validate_state_transition_chain,
)


def build_state_transition(
    *,
    transition_id: str,
    order_index: int,
    block_id: str,
    program_kind: Literal["digital", "analog"],
    program_hash: str,
    kernel: str,
    input_state_hash: str,
    output_state_hash: str,
    input_logical_time: float,
    output_logical_time: float,
    time_unit: str,
    solver_evidence: SimulationSolverEvidenceIR,
    metadata: Mapping[str, Any] | None = None,
) -> StateTransitionIR:
    """Build one transition whose solver hash and embedded evidence cannot drift."""
    return StateTransitionIR(
        transition_id=transition_id,
        order_index=order_index,
        block_id=block_id,
        program_kind=program_kind,
        program_hash=program_hash,
        kernel=kernel,
        input_state_hash=input_state_hash,
        output_state_hash=output_state_hash,
        input_logical_time=input_logical_time,
        output_logical_time=output_logical_time,
        time_unit=time_unit,
        solver_evidence_hash=solver_evidence.stable_hash(),
        metadata={
            **({} if metadata is None else dict(metadata)),
            "solver_evidence": solver_evidence.to_dict(),
        },
    )


def build_runtime_references(
    *,
    program_hash: str,
    initial_state_hash: str,
    final_state_hash: str,
    plan_hash: str | None = None,
    bundle_hash: str | None = None,
    target_snapshot_hash: str | None = None,
    metadata: Mapping[str, Any] | None = None,
) -> ResultReferencesIR:
    """Build the single references object used by Result and RunTrace."""
    return ResultReferencesIR(
        program_hash=program_hash,
        plan_hash=plan_hash,
        bundle_hash=bundle_hash,
        initial_state_hash=initial_state_hash,
        final_state_hash=final_state_hash,
        target_snapshot_hash=target_snapshot_hash,
        metadata={} if metadata is None else dict(metadata),
    )


def build_runtime_trace(
    *,
    trace_id: str,
    transitions: tuple[StateTransitionIR, ...],
    references: ResultReferencesIR,
    execution_mode: str,
    terminal_message: str,
    terminal_metadata: Mapping[str, Any],
) -> RunTraceIR:
    """Build transition events plus one terminal non-state-changing event."""
    if references.initial_state_hash is None or references.final_state_hash is None:
        raise ValueError("Runtime references require initial and final state hashes.")
    validate_state_transition_chain(
        transitions,
        initial_state_hash=references.initial_state_hash,
        final_state_hash=references.final_state_hash,
    )
    transition_events = tuple(
        RunTraceEventIR(
            stage="running",
            event_time=f"logical:{item.output_logical_time.hex()}",
            status="ok",
            message=f"Completed {item.program_kind} state transition.",
            metadata={"state_transition": item.to_dict()},
        )
        for item in transitions
    )
    terminal = RunTraceEventIR(
        stage="completed",
        event_time=f"logical:{transitions[-1].output_logical_time.hex()}",
        status="ok",
        message=terminal_message,
        metadata={
            **dict(terminal_metadata),
            "final_state_hash": references.final_state_hash,
        },
    )
    return RunTraceIR(
        trace_id=trace_id,
        events=(*transition_events, terminal),
        references=references,
        metadata={"execution_mode": execution_mode},
    )


def runtime_lineage_metadata(
    *,
    transitions: tuple[StateTransitionIR, ...],
    references: ResultReferencesIR,
    trace: RunTraceIR,
) -> dict[str, object]:
    """Project one canonical lineage into Result metadata without duplicating facts."""
    if trace.references != references:
        raise ValueError("RunTrace references must match Result references.")
    serialized = [item.to_dict() for item in transitions]
    return {
        "references": references.to_dict(),
        "state_transitions": serialized,
        # Existing consumers may retain this key, but its value is now exactly the
        # canonical transition serialization rather than a second schema.
        "block_state_chain": serialized,
        "run_trace": trace.to_dict(),
    }
