"""Noise model contracts and metadata-only noisy simulator wrapper."""

from __future__ import annotations

import json
import random
from collections import Counter
from dataclasses import dataclass, field, replace
from typing import Any, Literal, Union

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.native_ir.base import IRMixin
from cascaqit.native_ir.models import SCHEMA_VERSION, ProgramIR, SimulatorConfigIR
from cascaqit.results import ResultIR
from cascaqit.simulators.local_ahs import LocalAhsSimulator
from cascaqit.targets import CalibrationSnapshot

__all__ = [
    "NoiseChannelIR",
    "NoiseApplicationReportIR",
    "NoiseModelIR",
    "NoisyAhsSimulator",
    "ReadoutConfusionMatrixIR",
    "apply_atom_loss_noise",
    "apply_digital_readout_noise",
    "apply_readout_noise",
    "derive_noise_metadata_from_calibration",
    "diagnose_noise_support",
]

NoiseChannelType = Literal["atom_loss", "readout_error", "dephasing"]
NoiseApplicationMode = Literal["metadata_only"]
NoisePostProcessingMode = Literal[
    "metadata_only",
    "readout_post_processing_only",
    "atom_loss_post_processing_only",
]
NoiseProgramType = Literal["analog", "digital", "hybrid"]
ReadoutTarget = Union[tuple[str, ...], Literal["all"]]


@dataclass(frozen=True)
class NoiseApplicationReportIR(IRMixin):
    """Unified report for deterministic noise post-processing."""

    report_id: str
    noise_model_id: str
    mode: NoisePostProcessingMode
    seed: int | None = None
    source_result_id: str | None = None
    source_result_hash: str | None = None
    channels_applied: tuple[str, ...] = ()
    injection_points: tuple[str, ...] = ()
    counts_modified: bool = False
    samples_modified: bool = False
    probabilities_modified: bool = False
    physical_accuracy: str = "not_claimed"
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = SCHEMA_VERSION

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> NoiseApplicationReportIR:
        """Build a noise application report from a dictionary."""
        return cls(
            report_id=str(data["report_id"]),
            noise_model_id=str(data["noise_model_id"]),
            mode=data["mode"],
            seed=data.get("seed"),
            source_result_id=data.get("source_result_id"),
            source_result_hash=data.get("source_result_hash"),
            channels_applied=tuple(
                str(channel) for channel in data.get("channels_applied", ())
            ),
            injection_points=tuple(
                str(point) for point in data.get("injection_points", ())
            ),
            counts_modified=bool(data.get("counts_modified", False)),
            samples_modified=bool(data.get("samples_modified", False)),
            probabilities_modified=bool(data.get("probabilities_modified", False)),
            physical_accuracy=str(data.get("physical_accuracy", "not_claimed")),
            metadata=dict(data.get("metadata", {})),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
        )

    @classmethod
    def from_json(cls, text: str) -> NoiseApplicationReportIR:
        """Build a noise application report from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("NoiseApplicationReportIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class NoiseChannelIR(IRMixin):
    """Analog noise channel contract."""

    channel_id: str
    channel_type: NoiseChannelType
    value: float
    value_unit: str
    targets: tuple[str, ...] | Literal["all"] = "all"
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def atom_loss(
        cls,
        probability: float,
        *,
        channel_id: str = "noise.atom_loss",
        targets: tuple[str, ...] | Literal["all"] = "all",
        metadata: dict[str, Any] | None = None,
    ) -> NoiseChannelIR:
        """Build an atom-loss probability channel."""
        return cls(
            channel_id=channel_id,
            channel_type="atom_loss",
            value=float(probability),
            value_unit="probability",
            targets=targets,
            metadata={} if metadata is None else dict(metadata),
        )

    @classmethod
    def readout_error(
        cls,
        probability: float,
        *,
        channel_id: str = "noise.readout_error",
        targets: tuple[str, ...] | Literal["all"] = "all",
        metadata: dict[str, Any] | None = None,
    ) -> NoiseChannelIR:
        """Build a readout-error probability channel."""
        return cls(
            channel_id=channel_id,
            channel_type="readout_error",
            value=float(probability),
            value_unit="probability",
            targets=targets,
            metadata={} if metadata is None else dict(metadata),
        )

    @classmethod
    def dephasing(
        cls,
        rate: float,
        *,
        channel_id: str = "noise.dephasing",
        rate_unit: str = "1/us",
        targets: tuple[str, ...] | Literal["all"] = "all",
        metadata: dict[str, Any] | None = None,
    ) -> NoiseChannelIR:
        """Build a dephasing-rate metadata channel."""
        return cls(
            channel_id=channel_id,
            channel_type="dephasing",
            value=float(rate),
            value_unit=rate_unit,
            targets=targets,
            metadata={} if metadata is None else dict(metadata),
        )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> NoiseChannelIR:
        """Build a noise channel from a dictionary."""
        targets = data.get("targets", "all")
        return cls(
            channel_id=str(data["channel_id"]),
            channel_type=data["channel_type"],
            value=float(data["value"]),
            value_unit=str(data["value_unit"]),
            targets=(
                "all"
                if targets == "all"
                else tuple(str(target) for target in targets)
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> NoiseChannelIR:
        """Build a noise channel from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("NoiseChannelIR JSON must contain an object.")
        return cls.from_dict(data)

    def validate(self) -> tuple[DiagnosticsIR, ...]:
        """Return structural diagnostics for this noise channel."""
        diagnostics: list[DiagnosticsIR] = []
        if self.channel_type in {"atom_loss", "readout_error"} and not (
            0.0 <= self.value <= 1.0
        ):
            diagnostics.append(
                _diagnostic(
                    code="NOISE_PROBABILITY_OUT_OF_RANGE",
                    message="Noise probability values must be within [0, 1].",
                    object_path=f"noise.channels.{self.channel_id}.value",
                    severity="error",
                    metadata={"channel_type": self.channel_type},
                )
            )
        if self.channel_type == "dephasing" and self.value < 0.0:
            diagnostics.append(
                _diagnostic(
                    code="NOISE_RATE_NEGATIVE",
                    message="Noise rates must be non-negative.",
                    object_path=f"noise.channels.{self.channel_id}.value",
                    severity="error",
                    metadata={"channel_type": self.channel_type},
                )
            )
        return tuple(diagnostics)


@dataclass(frozen=True)
class NoiseModelIR(IRMixin):
    """Analog noise model contract for metadata-only simulator workflows."""

    noise_model_id: str
    channels: tuple[NoiseChannelIR, ...]
    application_mode: NoiseApplicationMode = "metadata_only"
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> NoiseModelIR:
        """Build a noise model from a dictionary."""
        return cls(
            noise_model_id=str(data["noise_model_id"]),
            channels=tuple(
                NoiseChannelIR.from_dict(channel)
                for channel in data.get("channels", ())
            ),
            application_mode=data.get("application_mode", "metadata_only"),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> NoiseModelIR:
        """Build a noise model from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("NoiseModelIR JSON must contain an object.")
        return cls.from_dict(data)

    @classmethod
    def from_calibration_metadata(
        cls,
        calibration: CalibrationSnapshot,
        *,
        noise_model_id: str | None = None,
    ) -> NoiseModelIR:
        """Build a metadata-only noise model from calibration metadata."""
        metadata = derive_noise_metadata_from_calibration(calibration)
        raw_noise = metadata["noise_metadata"]
        channels: list[NoiseChannelIR] = []
        if "atom_loss_probability" in raw_noise:
            channels.append(
                NoiseChannelIR.atom_loss(
                    float(raw_noise["atom_loss_probability"]),
                    metadata={"source": "calibration_metadata"},
                )
            )
        if "readout_error_probability" in raw_noise:
            channels.append(
                NoiseChannelIR.readout_error(
                    float(raw_noise["readout_error_probability"]),
                    metadata={"source": "calibration_metadata"},
                )
            )
        if "dephasing_rate" in raw_noise:
            channels.append(
                NoiseChannelIR.dephasing(
                    float(raw_noise["dephasing_rate"]),
                    rate_unit=str(raw_noise.get("dephasing_rate_unit", "1/us")),
                    metadata={"source": "calibration_metadata"},
                )
            )
        return cls(
            noise_model_id=(
                noise_model_id
                or f"noise.{calibration.calibration_profile_id}"
            ),
            channels=tuple(channels),
            metadata=metadata,
        )

    def validate(self) -> tuple[DiagnosticsIR, ...]:
        """Return structural diagnostics for this noise model."""
        diagnostics: list[DiagnosticsIR] = []
        channel_ids = [channel.channel_id for channel in self.channels]
        if len(set(channel_ids)) != len(channel_ids):
            diagnostics.append(
                _diagnostic(
                    code="NOISE_DUPLICATE_CHANNEL_ID",
                    message="Noise channel identifiers must be unique.",
                    object_path="noise.channels",
                    severity="error",
                )
            )
        for channel in self.channels:
            diagnostics.extend(channel.validate())
        if not diagnostics:
            diagnostics.append(
                DiagnosticsIR(
                    diagnostic_id="noise.model.valid",
                    stage="validation",
                    severity="info",
                    code="NOISE_MODEL_VALID",
                    message="Noise model is valid as metadata-only data.",
                    object_path="noise_model",
                    metadata={"application_mode": self.application_mode},
                )
            )
        return tuple(diagnostics)

    def summary(self) -> dict[str, Any]:
        """Return a compact JSON-compatible noise summary."""
        return {
            "noise_model_id": self.noise_model_id,
            "application_mode": self.application_mode,
            "channel_count": len(self.channels),
            "channels": [
                {
                    "channel_id": channel.channel_id,
                    "channel_type": channel.channel_type,
                    "value": channel.value,
                    "value_unit": channel.value_unit,
                    "targets": channel.targets,
                }
                for channel in self.channels
            ],
            "physical_accuracy": "not_claimed",
            "schema_version": self.schema_version,
        }


@dataclass(frozen=True)
class ReadoutConfusionMatrixIR(IRMixin):
    """Single-bit readout confusion matrix contract.

    Matrix entries follow true-bit rows and measured-bit columns:
    p00=P(measured 0 | true 0), p01=P(measured 1 | true 0),
    p10=P(measured 0 | true 1), p11=P(measured 1 | true 1).
    """

    matrix_id: str
    p00: float
    p01: float
    p10: float
    p11: float
    targets: ReadoutTarget = "all"
    source_channel_id: str | None = None
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def symmetric(
        cls,
        probability: float,
        *,
        matrix_id: str = "readout.confusion.symmetric",
        targets: ReadoutTarget = "all",
        source_channel_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> ReadoutConfusionMatrixIR:
        """Build a symmetric bit-flip readout confusion matrix."""
        error = float(probability)
        return cls(
            matrix_id=matrix_id,
            p00=1.0 - error,
            p01=error,
            p10=error,
            p11=1.0 - error,
            targets=targets,
            source_channel_id=source_channel_id,
            metadata={} if metadata is None else dict(metadata),
        )

    @classmethod
    def from_noise_channel(
        cls,
        channel: NoiseChannelIR,
        *,
        matrix_id: str | None = None,
    ) -> ReadoutConfusionMatrixIR:
        """Build a confusion matrix from a readout-error noise channel."""
        if channel.channel_type != "readout_error":
            raise ValueError("ReadoutConfusionMatrixIR requires readout_error channel.")
        return cls.symmetric(
            channel.value,
            matrix_id=matrix_id or f"readout.confusion.{channel.channel_id}",
            targets=channel.targets,
            source_channel_id=channel.channel_id,
            metadata={"source": "NoiseChannelIR"},
        )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ReadoutConfusionMatrixIR:
        """Build a readout confusion matrix from a dictionary."""
        targets = data.get("targets", "all")
        return cls(
            matrix_id=str(data["matrix_id"]),
            p00=float(data["p00"]),
            p01=float(data["p01"]),
            p10=float(data["p10"]),
            p11=float(data["p11"]),
            targets=(
                "all"
                if targets == "all"
                else tuple(str(target) for target in targets)
            ),
            source_channel_id=data.get("source_channel_id"),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> ReadoutConfusionMatrixIR:
        """Build a readout confusion matrix from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("ReadoutConfusionMatrixIR JSON must contain an object.")
        return cls.from_dict(data)

    def validate(self) -> tuple[DiagnosticsIR, ...]:
        """Return structural diagnostics for this confusion matrix."""
        diagnostics: list[DiagnosticsIR] = []
        entries = {
            "p00": self.p00,
            "p01": self.p01,
            "p10": self.p10,
            "p11": self.p11,
        }
        for name, value in entries.items():
            if not 0.0 <= value <= 1.0:
                diagnostics.append(
                    _diagnostic(
                        code="READOUT_CONFUSION_PROBABILITY_OUT_OF_RANGE",
                        message=(
                            "Readout confusion probabilities must be within "
                            "[0, 1]."
                        ),
                        object_path=f"readout_confusion_matrix.{name}",
                        severity="error",
                        metadata={"matrix_id": self.matrix_id},
                    )
                )
        if abs((self.p00 + self.p01) - 1.0) > 1e-12:
            diagnostics.append(
                _diagnostic(
                    code="READOUT_CONFUSION_ROW_SUM_INVALID",
                    message="Readout confusion row for true bit 0 must sum to 1.",
                    object_path="readout_confusion_matrix.row.0",
                    severity="error",
                    metadata={"matrix_id": self.matrix_id},
                )
            )
        if abs((self.p10 + self.p11) - 1.0) > 1e-12:
            diagnostics.append(
                _diagnostic(
                    code="READOUT_CONFUSION_ROW_SUM_INVALID",
                    message="Readout confusion row for true bit 1 must sum to 1.",
                    object_path="readout_confusion_matrix.row.1",
                    severity="error",
                    metadata={"matrix_id": self.matrix_id},
                )
            )
        if not diagnostics:
            diagnostics.append(
                DiagnosticsIR(
                    diagnostic_id="noise.readout_confusion_matrix.valid",
                    stage="validation",
                    severity="info",
                    code="READOUT_CONFUSION_MATRIX_VALID",
                    message="Readout confusion matrix is structurally valid.",
                    object_path="readout_confusion_matrix",
                    metadata={"matrix_id": self.matrix_id},
                )
            )
        return tuple(diagnostics)


@dataclass(frozen=True)
class NoisyAhsSimulator:
    """Metadata-only noisy AHS simulator wrapper.

    The wrapper delegates dynamics and sampling to LocalAhsSimulator, then
    attaches noise metadata and diagnostics to ResultIR. It does not implement
    a physical noisy evolution engine.
    """

    noise_model: NoiseModelIR
    base_simulator: LocalAhsSimulator = field(default_factory=LocalAhsSimulator)

    def run(
        self,
        program: ProgramIR | Any,
        *,
        shots: int = 1000,
        config: SimulatorConfigIR | None = None,
    ) -> ResultIR:
        """Run the base simulator and attach noise metadata to the result."""
        result = self.base_simulator.run(program, shots=shots, config=config)
        diagnostics = (
            *result.diagnostics,
            *diagnose_noise_support(self.noise_model, program_type="analog"),
            DiagnosticsIR(
                diagnostic_id="noise.metadata_only",
                stage="simulation",
                severity="warning",
                code="NOISE_METADATA_ONLY",
                message=(
                    "NoiseModelIR was recorded in Result metadata; physical "
                    "noisy dynamics were not simulated."
                ),
                object_path="result.metadata.noise_model",
                suggestion=(
                    "Treat this result as a deterministic skeleton, not a "
                    "physically accurate noisy simulation."
                ),
                metadata={"application_mode": self.noise_model.application_mode},
            ),
        )
        report = _build_noise_application_report(
            report_id=f"noise_report.{result.result_id}.metadata_only",
            result=result,
            noise_model=self.noise_model,
            mode="metadata_only",
            seed=None,
            channels=(),
            injection_points=("result.metadata",),
            counts_modified=False,
            samples_modified=False,
            probabilities_modified=False,
            metadata={"base_simulator": "LocalAhsSimulator"},
        )
        return replace(
            result,
            diagnostics=diagnostics,
            metadata={
                **result.metadata,
                "noise_model": self.noise_model.to_dict(),
                "noise_summary": self.noise_model.summary(),
                "noise_application_report": report.to_dict(),
                "noise_application": {
                    "mode": "metadata_only",
                    "base_simulator": "LocalAhsSimulator",
                    "counts_modified": False,
                    "probabilities_modified": False,
                    "physical_accuracy": "not_claimed",
                },
            },
        )


def apply_readout_noise(
    result: ResultIR,
    noise_model: NoiseModelIR,
    *,
    seed: int | None = None,
) -> ResultIR:
    """Apply deterministic readout-only post-processing to result samples.

    This function changes samples and counts only. It preserves physical
    probabilities and does not simulate atom loss, dephasing, or noisy dynamics.
    """
    if not isinstance(result, ResultIR):
        raise TypeError("apply_readout_noise accepts ResultIR.")
    if not isinstance(noise_model, NoiseModelIR):
        raise TypeError("apply_readout_noise accepts NoiseModelIR.")
    matrices = tuple(
        ReadoutConfusionMatrixIR.from_noise_channel(channel)
        for channel in noise_model.channels
        if channel.channel_type == "readout_error"
    )
    diagnostics: list[DiagnosticsIR] = [
        *result.diagnostics,
        *noise_model.validate(),
        *_unsupported_physical_noise_diagnostics(noise_model),
    ]
    for matrix in matrices:
        diagnostics.extend(
            diagnostic
            for diagnostic in matrix.validate()
            if diagnostic.severity != "info"
        )
    if not matrices:
        diagnostics.append(
            _diagnostic(
                code="READOUT_NOISE_NO_READOUT_CHANNEL",
                message="Noise model has no readout_error channel to apply.",
                object_path="noise_model.channels",
                severity="warning",
                metadata={"noise_model_id": noise_model.noise_model_id},
            )
        )
        return _readout_result(
            result,
            noise_model=noise_model,
            matrices=matrices,
            seed=seed,
            samples=result.samples,
            diagnostics=tuple(diagnostics),
        )
    invalid_matrix = any(
        diagnostic.severity == "error"
        for matrix in matrices
        for diagnostic in matrix.validate()
    )
    if invalid_matrix:
        return _readout_result(
            result,
            noise_model=noise_model,
            matrices=matrices,
            seed=seed,
            samples=result.samples,
            diagnostics=tuple(diagnostics),
        )

    rng = random.Random(seed)
    noisy_samples = tuple(
        _apply_readout_to_sample(sample, matrices=matrices, rng=rng)
        for sample in result.samples
    )
    diagnostics.append(
        DiagnosticsIR(
            diagnostic_id="noise.readout_post_processing_applied",
            stage="simulation",
            severity="warning",
            code="READOUT_NOISE_POST_PROCESSING_ONLY",
            message=(
                "Readout noise was applied to samples and counts only; "
                "physical probabilities were preserved."
            ),
            object_path="result",
            suggestion=(
                "Use this as readout post-processing, not as a full noisy "
                "simulation."
            ),
            metadata={
                "noise_model_id": noise_model.noise_model_id,
                "matrix_count": len(matrices),
                "seed": seed,
            },
        )
    )
    return _readout_result(
        result,
        noise_model=noise_model,
        matrices=matrices,
        seed=seed,
        samples=noisy_samples,
        diagnostics=tuple(diagnostics),
    )


def apply_digital_readout_noise(
    result: ResultIR,
    noise_model: NoiseModelIR,
    *,
    seed: int | None = None,
) -> ResultIR:
    """Apply readout post-processing to digital results with bit-order metadata."""
    if not isinstance(result, ResultIR):
        raise TypeError("apply_digital_readout_noise accepts ResultIR.")
    bitstring_ordering = result.metadata.get("bitstring_ordering")
    if not isinstance(bitstring_ordering, dict):
        diagnostics = (
            *result.diagnostics,
            _diagnostic(
                code="DIGITAL_READOUT_NOISE_BITSTRING_ORDERING_MISSING",
                message=(
                    "Digital readout post-processing requires explicit "
                    "bitstring ordering metadata."
                ),
                object_path="result.metadata.bitstring_ordering",
                severity="error",
                metadata={"noise_model_id": noise_model.noise_model_id},
            ),
        )
        return _readout_result(
            result,
            noise_model=noise_model,
            matrices=(),
            seed=seed,
            samples=result.samples,
            diagnostics=diagnostics,
            program_type="digital",
            injection_points=("digital_result.samples", "digital_result.counts"),
            extra_metadata={"bitstring_ordering_required": True},
        )
    noisy = apply_readout_noise(result, noise_model, seed=seed)
    report = dict(noisy.metadata["noise_application_report"])
    report_metadata = dict(report.get("metadata", {}))
    report_metadata.update(
        {
            "program_type": "digital",
            "bitstring_ordering": bitstring_ordering,
            "bitstring_ordering_required": True,
        }
    )
    report["metadata"] = report_metadata
    report["injection_points"] = [
        "digital_result.samples",
        "digital_result.counts",
    ]
    readout_application = dict(noisy.metadata["readout_noise_application"])
    readout_application.update(
        {
            "program_type": "digital",
            "bitstring_ordering": bitstring_ordering,
            "bitstring_ordering_required": True,
        }
    )
    return replace(
        noisy,
        metadata={
            **noisy.metadata,
            "noise_application_report": report,
            "readout_noise_application": readout_application,
        },
    )


def apply_atom_loss_noise(
    result: ResultIR,
    noise_model: NoiseModelIR,
    *,
    seed: int | None = None,
    lost_symbol: str = "x",
) -> ResultIR:
    """Apply deterministic atom-loss post-processing to samples and counts."""
    if not isinstance(result, ResultIR):
        raise TypeError("apply_atom_loss_noise accepts ResultIR.")
    if not isinstance(noise_model, NoiseModelIR):
        raise TypeError("apply_atom_loss_noise accepts NoiseModelIR.")
    channels = tuple(
        channel
        for channel in noise_model.channels
        if channel.channel_type == "atom_loss"
    )
    diagnostics: list[DiagnosticsIR] = [
        *result.diagnostics,
        *noise_model.validate(),
        *_unsupported_physical_noise_diagnostics(
            noise_model,
            context="atom_loss_post_processing",
        ),
    ]
    if not channels:
        diagnostics.append(
            _diagnostic(
                code="ATOM_LOSS_NO_ATOM_LOSS_CHANNEL",
                message="Noise model has no atom_loss channel to apply.",
                object_path="noise_model.channels",
                severity="warning",
                metadata={"noise_model_id": noise_model.noise_model_id},
            )
        )
        return _atom_loss_result(
            result,
            noise_model=noise_model,
            channels=channels,
            seed=seed,
            lost_symbol=lost_symbol,
            samples=result.samples,
            diagnostics=tuple(diagnostics),
        )
    rng = random.Random(seed)
    noisy_samples = tuple(
        _apply_atom_loss_to_sample(
            sample,
            channels=channels,
            rng=rng,
            lost_symbol=lost_symbol,
        )
        for sample in result.samples
    )
    diagnostics.append(
        DiagnosticsIR(
            diagnostic_id="noise.atom_loss_post_processing_applied",
            stage="simulation",
            severity="warning",
            code="ATOM_LOSS_POST_PROCESSING_ONLY",
            message=(
                "Atom-loss noise was applied to samples and counts only; "
                "physical probabilities were preserved."
            ),
            object_path="result",
            suggestion=(
                "Use this as deterministic post-processing, not as physical "
                "atom-loss dynamics."
            ),
            metadata={
                "noise_model_id": noise_model.noise_model_id,
                "channel_count": len(channels),
                "seed": seed,
                "lost_symbol": lost_symbol,
            },
        )
    )
    return _atom_loss_result(
        result,
        noise_model=noise_model,
        channels=channels,
        seed=seed,
        lost_symbol=lost_symbol,
        samples=noisy_samples,
        diagnostics=tuple(diagnostics),
    )


def derive_noise_metadata_from_calibration(
    calibration: CalibrationSnapshot,
) -> dict[str, Any]:
    """Extract deterministic noise metadata from a calibration snapshot."""
    raw_noise = calibration.metadata.get("noise_model")
    if raw_noise is None:
        raw_noise = calibration.metadata.get("noise", {})
    return {
        "calibration_profile_id": calibration.calibration_profile_id,
        "calibration_snapshot_hash": calibration.calibration_snapshot_hash,
        "target_id": calibration.target_id,
        "source": calibration.source,
        "derivation": "metadata_only",
        "noise_metadata": dict(raw_noise),
    }


def diagnose_noise_support(
    noise_model: NoiseModelIR,
    *,
    program_type: NoiseProgramType = "analog",
) -> tuple[DiagnosticsIR, ...]:
    """Return diagnostics for applying a noise model to a program type."""
    if program_type == "digital":
        return (
            _diagnostic(
                code="NOISE_DIGITAL_UNSUPPORTED",
                message="Digital noise simulation is not implemented.",
                object_path="noise_model",
                severity="warning",
                metadata={"program_type": program_type},
            ),
        )
    if program_type == "hybrid":
        return (
            _diagnostic(
                code="NOISE_HYBRID_UNSUPPORTED",
                message="Hybrid noise simulation is not implemented.",
                object_path="noise_model",
                severity="warning",
                metadata={"program_type": program_type},
            ),
        )
    return noise_model.validate()


def _diagnostic(
    *,
    code: str,
    message: str,
    object_path: str,
    severity: Literal["info", "warning", "error"],
    metadata: dict[str, Any] | None = None,
) -> DiagnosticsIR:
    diagnostic_metadata = {} if metadata is None else dict(metadata)
    if severity != "info":
        diagnostic_metadata.setdefault("reason_category", "noise")
        diagnostic_metadata.setdefault("taxonomy_stage", "simulation")
        diagnostic_metadata.setdefault("actionable", True)
        diagnostic_metadata.setdefault("action", "inspect_noise_model_support")
    return DiagnosticsIR(
        diagnostic_id=f"noise.{code.lower()}",
        stage="simulation",
        severity=severity,
        code=code,
        message=message,
        object_path=object_path,
        suggestion=(
            "Keep NoiseModelIR as serialized metadata until a physical noisy "
            "simulator is implemented."
        ),
        metadata=diagnostic_metadata,
    )


def _unsupported_physical_noise_diagnostics(
    noise_model: NoiseModelIR,
    *,
    context: Literal[
        "readout_post_processing",
        "atom_loss_post_processing",
    ] = "readout_post_processing",
) -> tuple[DiagnosticsIR, ...]:
    diagnostics: list[DiagnosticsIR] = []
    for channel in noise_model.channels:
        if (
            channel.channel_type == "atom_loss"
            and context != "atom_loss_post_processing"
        ):
            diagnostics.append(
                _diagnostic(
                    code="READOUT_NOISE_ATOM_LOSS_UNSUPPORTED",
                    message=(
                        "Atom-loss physical simulation is not part of readout "
                        "post-processing."
                    ),
                    object_path=f"noise.channels.{channel.channel_id}",
                    severity="warning",
                    metadata={"channel_type": channel.channel_type},
                )
            )
        if channel.channel_type == "dephasing":
            diagnostics.append(
                _diagnostic(
                    code=(
                        "ATOM_LOSS_NOISE_DEPHASING_UNSUPPORTED"
                        if context == "atom_loss_post_processing"
                        else "READOUT_NOISE_DEPHASING_UNSUPPORTED"
                    ),
                    message=(
                        "Dephasing physical simulation is not part of "
                        f"{context}."
                    ),
                    object_path=f"noise.channels.{channel.channel_id}",
                    severity="warning",
                    metadata={"channel_type": channel.channel_type},
                )
            )
    return tuple(diagnostics)


def _apply_readout_to_sample(
    sample: str,
    *,
    matrices: tuple[ReadoutConfusionMatrixIR, ...],
    rng: random.Random,
) -> str:
    bits = list(sample)
    for index, bit in enumerate(bits):
        if bit not in {"0", "1"}:
            continue
        for matrix in matrices:
            if not _matrix_targets_bit(matrix, index=index, bit_count=len(bits)):
                continue
            threshold = matrix.p01 if bit == "0" else matrix.p10
            if rng.random() < threshold:
                bit = "1" if bit == "0" else "0"
        bits[index] = bit
    return "".join(bits)


def _apply_atom_loss_to_sample(
    sample: str,
    *,
    channels: tuple[NoiseChannelIR, ...],
    rng: random.Random,
    lost_symbol: str,
) -> str:
    bits = list(sample)
    for index, bit in enumerate(bits):
        if bit not in {"0", "1"}:
            continue
        for channel in channels:
            if not _channel_targets_bit(
                channel,
                index=index,
                bit_count=len(bits),
            ):
                continue
            if rng.random() < channel.value:
                bit = lost_symbol
                break
        bits[index] = bit
    return "".join(bits)


def _matrix_targets_bit(
    matrix: ReadoutConfusionMatrixIR,
    *,
    index: int,
    bit_count: int,
) -> bool:
    if matrix.targets == "all":
        return True
    target_labels = {str(target) for target in matrix.targets}
    return (
        str(index) in target_labels
        or f"bit.{index}" in target_labels
        or f"q{index}" in target_labels
        or f"q{bit_count - index - 1}" in target_labels
    )


def _channel_targets_bit(
    channel: NoiseChannelIR,
    *,
    index: int,
    bit_count: int,
) -> bool:
    if channel.targets == "all":
        return True
    target_labels = {str(target) for target in channel.targets}
    return (
        str(index) in target_labels
        or f"bit.{index}" in target_labels
        or f"q{index}" in target_labels
        or f"q{bit_count - index - 1}" in target_labels
    )


def _readout_result(
    result: ResultIR,
    *,
    noise_model: NoiseModelIR,
    matrices: tuple[ReadoutConfusionMatrixIR, ...],
    seed: int | None,
    samples: tuple[str, ...],
    diagnostics: tuple[DiagnosticsIR, ...],
    program_type: NoiseProgramType = "analog",
    injection_points: tuple[str, ...] = ("result.samples", "result.counts"),
    extra_metadata: dict[str, Any] | None = None,
) -> ResultIR:
    counts = dict(sorted(Counter(samples).items()))
    counts_modified = counts != result.counts
    channels = tuple(
        channel.channel_id
        for channel in noise_model.channels
        if channel.channel_type == "readout_error"
    )
    report = _build_noise_application_report(
        report_id=f"noise_report.{result.result_id}.readout",
        result=result,
        noise_model=noise_model,
        mode="readout_post_processing_only",
        seed=seed,
        channels=channels,
        injection_points=injection_points,
        counts_modified=counts_modified,
        samples_modified=samples != result.samples,
        probabilities_modified=False,
        metadata={
            "matrix_ids": [matrix.matrix_id for matrix in matrices],
            "matrix_count": len(matrices),
            "program_type": program_type,
            **({} if extra_metadata is None else dict(extra_metadata)),
        },
    )
    return replace(
        result,
        result_id=f"{result.result_id}.readout_noise",
        counts=counts,
        samples=samples,
        probabilities=result.probabilities,
        diagnostics=diagnostics,
        metadata={
            **result.metadata,
            "noise_application_report": report.to_dict(),
            "readout_noise_application": {
                "mode": "readout_post_processing_only",
                "noise_model_id": noise_model.noise_model_id,
                "seed": seed,
                "source_result_id": result.result_id,
                "source_result_hash": result.stable_hash(),
                "source_counts": dict(sorted(result.counts.items())),
                "noisy_counts": counts,
                "counts_modified": counts_modified,
                "samples_modified": samples != result.samples,
                "probabilities_modified": False,
                "physical_accuracy": "readout_only_not_full_noisy_simulation",
                "matrix_ids": [matrix.matrix_id for matrix in matrices],
                "matrix_count": len(matrices),
                **({} if extra_metadata is None else dict(extra_metadata)),
            },
            "readout_confusion_matrices": [
                matrix.to_dict() for matrix in matrices
            ],
        },
    )


def _atom_loss_result(
    result: ResultIR,
    *,
    noise_model: NoiseModelIR,
    channels: tuple[NoiseChannelIR, ...],
    seed: int | None,
    lost_symbol: str,
    samples: tuple[str, ...],
    diagnostics: tuple[DiagnosticsIR, ...],
) -> ResultIR:
    counts = dict(sorted(Counter(samples).items()))
    counts_modified = counts != result.counts
    report = _build_noise_application_report(
        report_id=f"noise_report.{result.result_id}.atom_loss",
        result=result,
        noise_model=noise_model,
        mode="atom_loss_post_processing_only",
        seed=seed,
        channels=tuple(channel.channel_id for channel in channels),
        injection_points=("result.samples", "result.counts"),
        counts_modified=counts_modified,
        samples_modified=samples != result.samples,
        probabilities_modified=False,
        metadata={
            "lost_symbol": lost_symbol,
            "channel_count": len(channels),
        },
    )
    return replace(
        result,
        result_id=f"{result.result_id}.atom_loss_noise",
        counts=counts,
        samples=samples,
        probabilities=result.probabilities,
        diagnostics=diagnostics,
        metadata={
            **result.metadata,
            "noise_application_report": report.to_dict(),
            "atom_loss_noise_application": {
                "mode": "atom_loss_post_processing_only",
                "noise_model_id": noise_model.noise_model_id,
                "seed": seed,
                "source_result_id": result.result_id,
                "source_result_hash": result.stable_hash(),
                "source_counts": dict(sorted(result.counts.items())),
                "noisy_counts": counts,
                "counts_modified": counts_modified,
                "samples_modified": samples != result.samples,
                "probabilities_modified": False,
                "physical_accuracy": "not_claimed",
                "lost_symbol": lost_symbol,
                "channel_ids": [channel.channel_id for channel in channels],
                "channel_count": len(channels),
            },
        },
    )


def _build_noise_application_report(
    *,
    report_id: str,
    result: ResultIR,
    noise_model: NoiseModelIR,
    mode: NoisePostProcessingMode,
    seed: int | None,
    channels: tuple[str, ...],
    injection_points: tuple[str, ...],
    counts_modified: bool,
    samples_modified: bool,
    probabilities_modified: bool,
    metadata: dict[str, Any] | None = None,
) -> NoiseApplicationReportIR:
    return NoiseApplicationReportIR(
        report_id=report_id,
        noise_model_id=noise_model.noise_model_id,
        mode=mode,
        seed=seed,
        source_result_id=result.result_id,
        source_result_hash=result.stable_hash(),
        channels_applied=channels,
        injection_points=injection_points,
        counts_modified=counts_modified,
        samples_modified=samples_modified,
        probabilities_modified=probabilities_modified,
        physical_accuracy="not_claimed",
        metadata={} if metadata is None else dict(metadata),
    )
