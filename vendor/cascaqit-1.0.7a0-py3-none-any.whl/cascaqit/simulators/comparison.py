"""Deterministic simulation result comparison helpers."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Literal, Union

from cascaqit.hybrid import HybridSimulationPlanIR
from cascaqit.native_ir.base import IRMixin, canonicalize
from cascaqit.native_ir.models import SCHEMA_VERSION
from cascaqit.results import ResultIR
from cascaqit.simulators.manifest_runner import (
    SimulationReportSectionIR,
    build_simulation_report_section,
)
from cascaqit.simulators.models import build_simulation_manifest

__all__ = [
    "SimulationComparisonIR",
    "compare_simulation_outputs",
    "compare_simulation_report_sections",
]

SimulationComparisonStatus = Literal["same", "different"]
SimulationComparisonEntryKind = Literal[
    "exact_value",
    "sampling_count",
    "metadata",
    "noise_report",
    "unsupported_boundary",
]
SimulationComparable = Union[
    ResultIR,
    HybridSimulationPlanIR,
    SimulationReportSectionIR,
]


@dataclass(frozen=True)
class SimulationComparisonIR(IRMixin):
    """Metadata-only deterministic comparison between local simulation outputs."""

    comparison_id: str
    status: SimulationComparisonStatus
    left_label: str
    right_label: str
    left_kind: str
    right_kind: str
    left_hash: str
    right_hash: str
    entries: tuple[dict[str, Any], ...]
    summary: dict[str, Any]
    interpretation: dict[str, Any]
    metadata_only: bool = True
    statistical_significance_claimed: bool = False
    physical_calibration_claimed: bool = False
    hardware_consistency_claimed: bool = False
    backend_called: bool = False
    network_accessed: bool = False
    artifact_bytes_read: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SimulationComparisonIR:
        """Build a simulation comparison from a dictionary."""
        return cls(
            comparison_id=str(data["comparison_id"]),
            status=data["status"],
            left_label=str(data["left_label"]),
            right_label=str(data["right_label"]),
            left_kind=str(data["left_kind"]),
            right_kind=str(data["right_kind"]),
            left_hash=str(data["left_hash"]),
            right_hash=str(data["right_hash"]),
            entries=tuple(dict(entry) for entry in data.get("entries", ())),
            summary=dict(data["summary"]),
            interpretation=dict(data["interpretation"]),
            metadata_only=bool(data.get("metadata_only", True)),
            statistical_significance_claimed=bool(
                data.get("statistical_significance_claimed", False)
            ),
            physical_calibration_claimed=bool(
                data.get("physical_calibration_claimed", False)
            ),
            hardware_consistency_claimed=bool(
                data.get("hardware_consistency_claimed", False)
            ),
            backend_called=bool(data.get("backend_called", False)),
            network_accessed=bool(data.get("network_accessed", False)),
            artifact_bytes_read=bool(data.get("artifact_bytes_read", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> SimulationComparisonIR:
        """Build a simulation comparison from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("SimulationComparisonIR JSON must contain an object.")
        return cls.from_dict(data)


def compare_simulation_outputs(
    left: SimulationComparable,
    right: SimulationComparable,
    *,
    comparison_id: str | None = None,
    left_label: str = "left",
    right_label: str = "right",
    metadata: dict[str, Any] | None = None,
) -> SimulationComparisonIR:
    """Compare supported local simulation outputs without external side effects."""
    left_section = _to_report_section(left, label=left_label)
    right_section = _to_report_section(right, label=right_label)
    return compare_simulation_report_sections(
        left_section,
        right_section,
        comparison_id=comparison_id,
        left_label=left_label,
        right_label=right_label,
        metadata=metadata,
    )


def compare_simulation_report_sections(
    left: SimulationReportSectionIR,
    right: SimulationReportSectionIR,
    *,
    comparison_id: str | None = None,
    left_label: str = "left",
    right_label: str = "right",
    metadata: dict[str, Any] | None = None,
) -> SimulationComparisonIR:
    """Compare two simulation report sections by simulator-specific categories."""
    entries = tuple(
        sorted(
            (
                *_compare_counts(left, right),
                *_compare_probabilities(left, right),
                *_compare_observables(left, right),
                *_compare_metadata(left, right),
                *_compare_noise(left, right),
                *_compare_boundaries(left, right),
            ),
            key=lambda entry: (str(entry["entry_kind"]), str(entry["path"])),
        )
    )
    summary = _summary(entries)
    return SimulationComparisonIR(
        comparison_id=comparison_id
        or f"simulation_comparison.{left_label}.{right_label}",
        status="different" if summary["different_total"] > 0 else "same",
        left_label=left_label,
        right_label=right_label,
        left_kind=left.output_kind,
        right_kind=right.output_kind,
        left_hash=left.stable_hash(),
        right_hash=right.stable_hash(),
        entries=entries,
        summary=summary,
        interpretation={
            "deterministic_summary_only": True,
            "statistical_significance_claimed": False,
            "physical_calibration_claimed": False,
            "hardware_consistency_claimed": False,
            "notes": (
                "Differences are deterministic payload differences only; "
                "they are not statistical, physical calibration, or hardware "
                "consistency claims."
            ),
        },
        metadata_only=True,
        statistical_significance_claimed=False,
        physical_calibration_claimed=False,
        hardware_consistency_claimed=False,
        backend_called=False,
        network_accessed=False,
        artifact_bytes_read=False,
        metadata={} if metadata is None else dict(metadata),
    )


def _to_report_section(
    output: SimulationComparable,
    *,
    label: str,
) -> SimulationReportSectionIR:
    if isinstance(output, SimulationReportSectionIR):
        return output
    if isinstance(output, ResultIR):
        manifest = build_simulation_manifest(
            manifest_id=f"comparison.{label}.manifest",
            program_kind="digital",
            program_ref=output.result_id,
            program_hash=output.program_hash,
            shots=output.shots,
        )
        return build_simulation_report_section(manifest, output)
    if isinstance(output, HybridSimulationPlanIR):
        manifest = build_simulation_manifest(
            manifest_id=f"comparison.{label}.manifest",
            program_kind="hybrid",
            program_ref=output.program_id,
            program_hash=output.stable_hash(),
            shots=0,
        )
        return build_simulation_report_section(manifest, output)
    raise TypeError("output must be ResultIR, HybridSimulationPlanIR, or section.")


def _compare_counts(
    left: SimulationReportSectionIR,
    right: SimulationReportSectionIR,
) -> list[dict[str, Any]]:
    return _compare_mapping(
        "counts_summary",
        left.counts_summary,
        right.counts_summary,
        entry_kind="sampling_count",
    )


def _compare_probabilities(
    left: SimulationReportSectionIR,
    right: SimulationReportSectionIR,
) -> list[dict[str, Any]]:
    return _compare_mapping(
        "probability_summary",
        left.probability_summary,
        right.probability_summary,
        entry_kind="exact_value",
    )


def _compare_observables(
    left: SimulationReportSectionIR,
    right: SimulationReportSectionIR,
) -> list[dict[str, Any]]:
    return _compare_mapping(
        "observable_summary",
        left.observable_summary,
        right.observable_summary,
        entry_kind="exact_value",
    )


def _compare_metadata(
    left: SimulationReportSectionIR,
    right: SimulationReportSectionIR,
) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    for field_name in (
        "program_kind",
        "output_kind",
        "status",
        "state_summary",
        "algorithm_summary",
        "diagnostics_summary",
    ):
        entries.extend(
            _compare_values(
                field_name,
                getattr(left, field_name),
                getattr(right, field_name),
                entry_kind="metadata",
            )
        )
    return entries


def _compare_noise(
    left: SimulationReportSectionIR,
    right: SimulationReportSectionIR,
) -> list[dict[str, Any]]:
    return _compare_mapping(
        "noise_summary",
        left.noise_summary,
        right.noise_summary,
        entry_kind="noise_report",
    )


def _compare_boundaries(
    left: SimulationReportSectionIR,
    right: SimulationReportSectionIR,
) -> list[dict[str, Any]]:
    return _compare_mapping(
        "boundary_flags",
        left.boundary_flags,
        right.boundary_flags,
        entry_kind="unsupported_boundary",
    )


def _compare_mapping(
    path: str,
    left: dict[str, Any],
    right: dict[str, Any],
    *,
    entry_kind: SimulationComparisonEntryKind,
) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    keys = sorted(set(left) | set(right))
    for key in keys:
        entries.extend(
            _compare_values(
                f"{path}.{key}",
                left.get(key),
                right.get(key),
                entry_kind=entry_kind,
            )
        )
    return entries


def _compare_values(
    path: str,
    left: Any,
    right: Any,
    *,
    entry_kind: SimulationComparisonEntryKind,
) -> list[dict[str, Any]]:
    left_value = canonicalize(left)
    right_value = canonicalize(right)
    if left_value == right_value:
        return [
            _entry(
                path,
                entry_kind=entry_kind,
                changed=False,
                left=left_value,
                right=right_value,
            )
        ]
    return [
        _entry(
            path,
            entry_kind=entry_kind,
            changed=True,
            left=left_value,
            right=right_value,
        )
    ]


def _entry(
    path: str,
    *,
    entry_kind: SimulationComparisonEntryKind,
    changed: bool,
    left: Any,
    right: Any,
) -> dict[str, Any]:
    return {
        "path": path,
        "entry_kind": entry_kind,
        "changed": changed,
        "left": left,
        "right": right,
    }


def _summary(entries: tuple[dict[str, Any], ...]) -> dict[str, Any]:
    by_kind: dict[str, dict[str, int]] = {}
    different_total = 0
    for entry in entries:
        kind = str(entry["entry_kind"])
        if kind not in by_kind:
            by_kind[kind] = {"same": 0, "different": 0}
        if entry["changed"]:
            different_total += 1
            by_kind[kind]["different"] += 1
        else:
            by_kind[kind]["same"] += 1
    return {
        "entry_count": len(entries),
        "different_total": different_total,
        "matches": different_total == 0,
        "by_kind": by_kind,
    }
