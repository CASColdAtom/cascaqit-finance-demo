"""Unified offline simulator facade for supported program models."""

from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Any, Literal

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.digital import DigitalProgramIR
from cascaqit.hybrid import HybridProgram, HybridProgramIR, HybridSimulationPlanIR
from cascaqit.native_ir import ProgramIR, SimulatorConfigIR
from cascaqit.results import ResultIR
from cascaqit.simulators.diagnostics import build_diagnostics_summary
from cascaqit.simulators.digital import LocalDigitalSimulator
from cascaqit.simulators.hybrid import HybridBlockSimulator
from cascaqit.simulators.local_ahs import LocalAhsSimulator
from cascaqit.simulators.local_backend import LocalBackend
from cascaqit.simulators.noise import (
    NoiseModelIR,
    apply_atom_loss_noise,
    apply_digital_readout_noise,
    apply_readout_noise,
)
from cascaqit.simulators.planning import SimulationOptions
from cascaqit.targets import TargetSpec

__all__ = ["Simulator"]

NoiseMode = Literal["none", "readout", "digital_readout", "atom_loss"]
SimulationProgramKind = Literal["analog", "digital", "hybrid"]
_REFERENCE_DIGITAL_MAX_SITES = 4


@dataclass(frozen=True)
class Simulator:
    """Unified local simulator facade for analog, digital, and hybrid inputs."""

    seed: int | None = None
    target: TargetSpec | None = None
    created_at: str | None = None
    analog_time_steps: int = 400

    def run(
        self,
        program: Any,
        *,
        shots: int | None = None,
        config: SimulatorConfigIR | None = None,
        noise_model: NoiseModelIR | None = None,
        noise_mode: NoiseMode = "none",
        options: SimulationOptions | None = None,
        hybrid_plan_only: bool = True,
    ) -> ResultIR | HybridSimulationPlanIR:
        """Dispatch to the supported local simulator for a program object."""
        if isinstance(program, DigitalProgramIR):
            diagnostics = program.validate_ir_only()
            result = _without_local_backend_metadata(
                self._backend()
                .run(
                    program,
                    shots=None if config is not None else shots,
                    config=config,
                    options=options,
                )
                .result()
            )
            result = self._apply_noise(
                result,
                program_kind="digital",
                noise_model=noise_model,
                noise_mode=noise_mode,
            )
            return _with_result_metadata(
                result,
                program_kind="digital",
                selected_simulator="LocalDigitalSimulator",
                validate_before_run=True,
                validation_diagnostics=diagnostics,
                noise_mode=noise_mode,
                hybrid_plan_only=hybrid_plan_only,
            )
        if isinstance(program, HybridProgram):
            result = self._backend().run(
                program,
                shots=None if config is not None else shots,
                config=config,
                options=options,
            ).result()
            result = self._apply_noise(
                result,
                program_kind="hybrid",
                noise_model=noise_model,
                noise_mode=noise_mode,
            )
            return _with_result_metadata(
                result,
                program_kind="hybrid",
                selected_simulator="LocalHybridSimulator",
                validate_before_run=True,
                validation_diagnostics=tuple(result.diagnostics),
                noise_mode=noise_mode,
                hybrid_plan_only=False,
                full_daqc_state_handoff=True,
            )
        if isinstance(program, HybridProgramIR):
            diagnostics = program.validate_ir_only()
            output = self._hybrid().run(
                program,
                shots=1000 if shots is None else shots,
                config=config,
                plan_only=hybrid_plan_only,
            )
            if isinstance(output, HybridSimulationPlanIR):
                return _with_plan_metadata(
                    output,
                    validate_before_run=True,
                    validation_diagnostics=diagnostics,
                    hybrid_plan_only=hybrid_plan_only,
                )
            result = self._apply_noise(
                output,
                program_kind="hybrid",
                noise_model=noise_model,
                noise_mode=noise_mode,
            )
            return _with_result_metadata(
                result,
                program_kind="hybrid",
                selected_simulator="HybridBlockSimulator",
                validate_before_run=True,
                validation_diagnostics=diagnostics,
                noise_mode=noise_mode,
                hybrid_plan_only=hybrid_plan_only,
            )
        if _is_analog_like(program):
            backend_program = (
                program.program_ir
                if not isinstance(program, ProgramIR) and hasattr(program, "program_ir")
                else program
            )
            result = _without_local_backend_metadata(
                self._backend()
                .run(
                    backend_program,
                    shots=None if config is not None else shots,
                    config=config,
                    options=options,
                )
                .result()
            )
            result = self._apply_noise(
                result,
                program_kind="analog",
                noise_model=noise_model,
                noise_mode=noise_mode,
            )
            return _with_result_metadata(
                result,
                program_kind="analog",
                selected_simulator="LocalAhsSimulator",
                validate_before_run=True,
                validation_diagnostics=tuple(result.diagnostics),
                noise_mode=noise_mode,
                hybrid_plan_only=hybrid_plan_only,
            )
        raise TypeError(
            "Simulator.run accepts analog, digital, or hybrid programs; "
            "shared-state Hybrid execution requires HybridProgram."
        )

    def plan(self, program: HybridProgramIR) -> HybridSimulationPlanIR:
        """Build a hybrid simulation plan through the unified facade."""
        if not isinstance(program, HybridProgramIR):
            raise TypeError("Simulator.plan accepts HybridProgramIR.")
        diagnostics = program.validate_ir_only()
        return _with_plan_metadata(
            self._hybrid().plan(program),
            validate_before_run=True,
            validation_diagnostics=diagnostics,
            hybrid_plan_only=True,
        )

    def _analog(self) -> LocalAhsSimulator:
        return LocalAhsSimulator(
            target=self.target,
            seed=self.seed,
            time_steps=self.analog_time_steps,
            created_at=self.created_at,
        )

    def _backend(self) -> LocalBackend:
        return LocalBackend(
            seed=self.seed,
            target=self.target,
            analog_time_steps=self.analog_time_steps,
            created_at=self.created_at,
        )

    def _digital(self) -> LocalDigitalSimulator:
        return LocalDigitalSimulator(
            seed=self.seed,
            max_qubits=_REFERENCE_DIGITAL_MAX_SITES,
            created_at=self.created_at,
        )

    def _hybrid(self) -> HybridBlockSimulator:
        return HybridBlockSimulator(
            digital_simulator=self._digital(),
            analog_simulator=self._analog(),
            created_at=self.created_at,
        )

    def _apply_noise(
        self,
        result: ResultIR,
        *,
        program_kind: SimulationProgramKind,
        noise_model: NoiseModelIR | None,
        noise_mode: NoiseMode,
    ) -> ResultIR:
        if noise_model is None or noise_mode == "none":
            return result
        if noise_mode == "readout":
            return apply_readout_noise(result, noise_model, seed=self.seed)
        if noise_mode == "digital_readout":
            return apply_digital_readout_noise(result, noise_model, seed=self.seed)
        if noise_mode == "atom_loss":
            return apply_atom_loss_noise(result, noise_model, seed=self.seed)
        raise ValueError(
            f"Unsupported noise_mode {noise_mode!r} for {program_kind} program."
        )


def _is_analog_like(program: Any) -> bool:
    return isinstance(program, ProgramIR) or hasattr(program, "program_ir") or hasattr(
        program,
        "to_ir",
    )


def _with_result_metadata(
    result: ResultIR,
    *,
    program_kind: SimulationProgramKind,
    selected_simulator: str,
    validate_before_run: bool,
    validation_diagnostics: tuple[DiagnosticsIR, ...],
    noise_mode: NoiseMode,
    hybrid_plan_only: bool,
    full_daqc_state_handoff: bool = False,
) -> ResultIR:
    return replace(
        result,
        metadata={
            **result.metadata,
            "diagnostics_summary": _diagnostics_summary(tuple(result.diagnostics)),
            "unified_simulator": {
                "facade": "Simulator",
                "program_kind": program_kind,
                "selected_simulator": selected_simulator,
                "validate_before_run": validate_before_run,
                "validation_summary": _diagnostics_summary(validation_diagnostics),
                "noise_mode": noise_mode,
                "hybrid_plan_only": hybrid_plan_only,
                "offline_deterministic": True,
                "hardware_execution": False,
                "cloud_execution": False,
                "full_daqc_state_handoff": full_daqc_state_handoff,
            },
        },
    )


def _without_local_backend_metadata(result: ResultIR) -> ResultIR:
    metadata = dict(result.metadata)
    for key in (
        "backend_id",
        "selected_simulator",
        "backend_called",
        "offline_deterministic",
        "network_accessed",
        "execution_package_created",
        "simulation_plan",
        "simulation_plan_hash",
        "simulation_resource_estimate",
        "simulation_resource_usage",
        "simulation_truthfulness",
    ):
        metadata.pop(key, None)
    return replace(result, metadata=metadata)


def _with_plan_metadata(
    plan: HybridSimulationPlanIR,
    *,
    validate_before_run: bool,
    validation_diagnostics: tuple[DiagnosticsIR, ...],
    hybrid_plan_only: bool,
) -> HybridSimulationPlanIR:
    return replace(
        plan,
        metadata={
            **plan.metadata,
            "unified_simulator": {
                "facade": "Simulator",
                "program_kind": "hybrid",
                "selected_simulator": "HybridBlockSimulator",
                "validate_before_run": validate_before_run,
                "validation_summary": _diagnostics_summary(validation_diagnostics),
                "noise_mode": "none",
                "hybrid_plan_only": hybrid_plan_only,
                "offline_deterministic": True,
                "hardware_execution": False,
                "cloud_execution": False,
                "full_daqc_state_handoff": False,
            },
        },
    )


def _diagnostics_summary(
    diagnostics: tuple[DiagnosticsIR, ...],
) -> dict[str, object]:
    return build_diagnostics_summary(diagnostics)
