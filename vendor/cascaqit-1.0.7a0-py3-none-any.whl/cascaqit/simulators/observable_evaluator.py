"""Shared single-source Pauli observable batch evaluation."""

from __future__ import annotations

import json
import math
from collections import Counter
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from typing import Any, Union

import numpy as np
from numpy.typing import NDArray

from cascaqit.native_ir.base import IRMixin
from cascaqit.observables import (
    OBSERVABLE_SCHEMA_VERSION,
    Observable,
    ObservableBatchResultIR,
    ObservableEstimatorKind,
    ObservableResultIR,
    ObservableSet,
    ObservableSourceKind,
    PauliBasis,
)
from cascaqit.simulators.array_state import (
    DensityMatrixState,
    StateVectorState,
    SubspaceState,
    TrajectoryBatchState,
)

__all__ = ["ZBasisMeasurementBatch", "evaluate_observables"]

_EXPECTATION_IMAGINARY_TOLERANCE = 1e-6


@dataclass(frozen=True)
class ZBasisMeasurementBatch(IRMixin):
    """Immutable computational-basis counts with explicit logical bit order."""

    counts: tuple[tuple[str, int], ...]
    logical_order: tuple[str, ...]
    measurement_basis: str = "Z"
    schema_version: str = OBSERVABLE_SCHEMA_VERSION

    def __post_init__(self) -> None:
        order = tuple(self.logical_order)
        if (
            not order
            or any(
                not isinstance(target, str)
                or not target
                or target != target.strip()
                for target in order
            )
            or len(order) != len(set(order))
        ):
            raise ValueError(
                "logical_order must contain unique non-empty trimmed strings."
            )
        if self.measurement_basis != "Z":
            raise ValueError("measurement_basis must be Z.")
        raw_counts = tuple(self.counts)
        normalized: list[tuple[str, int]] = []
        for item in raw_counts:
            if not isinstance(item, tuple) or len(item) != 2:
                raise TypeError("counts must contain (bitstring, count) pairs.")
            bitstring, count = item
            if (
                not isinstance(bitstring, str)
                or len(bitstring) != len(order)
                or any(bit not in {"0", "1"} for bit in bitstring)
            ):
                raise ValueError(
                    "count bitstrings must contain one 0/1 bit per logical target."
                )
            if (
                not isinstance(count, int)
                or isinstance(count, bool)
                or count <= 0
            ):
                raise ValueError("counts must be positive integers.")
            normalized.append((bitstring, count))
        normalized.sort(key=lambda item: item[0])
        if len({bitstring for bitstring, _ in normalized}) != len(normalized):
            raise ValueError("counts must contain unique bitstrings.")
        if sum(count for _, count in normalized) < 2:
            raise ValueError(
                "observable standard error requires at least two samples."
            )
        object.__setattr__(self, "logical_order", order)
        object.__setattr__(self, "counts", tuple(normalized))

    @property
    def sample_count(self) -> int:
        """Return the actual number of measurement shots."""
        return sum(count for _, count in self.counts)

    def to_dict(self) -> dict[str, Any]:
        """Return stable wire data without expanding counts into samples."""
        return {
            "counts": dict(self.counts),
            "logical_order": list(self.logical_order),
            "measurement_basis": self.measurement_basis,
            "schema_version": self.schema_version,
        }

    @classmethod
    def from_samples(
        cls,
        samples: Iterable[str],
        *,
        logical_order: Iterable[str],
    ) -> ZBasisMeasurementBatch:
        """Build compact evidence from raw ordered samples."""
        return cls(
            counts=tuple(Counter(samples).items()),
            logical_order=tuple(logical_order),
        )

    @classmethod
    def from_counts(
        cls,
        counts: Mapping[str, int],
        *,
        logical_order: Iterable[str],
    ) -> ZBasisMeasurementBatch:
        """Build compact evidence from an existing counts mapping."""
        if not isinstance(counts, Mapping):
            raise TypeError("counts must be a mapping.")
        return cls(
            counts=tuple(counts.items()),
            logical_order=tuple(logical_order),
        )

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ZBasisMeasurementBatch:
        """Build measurement evidence from JSON-compatible data."""
        counts = data.get("counts")
        if not isinstance(counts, Mapping):
            raise TypeError("counts must be an object.")
        logical_order = data.get("logical_order")
        if not isinstance(logical_order, (list, tuple)):
            raise TypeError("logical_order must be an array.")
        return cls.from_counts(
            counts,
            logical_order=logical_order,
        )

    @classmethod
    def from_json(cls, text: str) -> ZBasisMeasurementBatch:
        """Build measurement evidence from JSON text."""
        data = json.loads(text)
        if not isinstance(data, Mapping):
            raise TypeError("ZBasisMeasurementBatch JSON must contain an object.")
        return cls.from_dict(data)


ObservableEvaluationSource = Union[
    StateVectorState,
    SubspaceState,
    DensityMatrixState,
    TrajectoryBatchState,
    ZBasisMeasurementBatch,
]


def evaluate_observables(
    source: ObservableEvaluationSource,
    observable_set: ObservableSet,
) -> ObservableBatchResultIR:
    """Evaluate an ordered observable batch from exactly one physical source."""
    if not isinstance(observable_set, ObservableSet):
        raise TypeError("observable_set must be ObservableSet.")
    if not isinstance(
        source,
        (
            StateVectorState,
            SubspaceState,
            DensityMatrixState,
            TrajectoryBatchState,
            ZBasisMeasurementBatch,
        ),
    ):
        raise TypeError(
            "source must be a supported state or ZBasisMeasurementBatch."
        )
    if isinstance(source, TrajectoryBatchState) and source.trajectory_count < 2:
        raise ValueError(
            "trajectory observable standard error requires at least two trajectories."
        )
    if not isinstance(source, ZBasisMeasurementBatch) and (
        source.basis != "logical_two_level"
    ):
        raise ValueError("observable evaluation requires logical_two_level basis.")

    _validate_compatibility(source, observable_set)
    if isinstance(source, StateVectorState):
        items = _evaluate_state_vector(source, observable_set)
    elif isinstance(source, SubspaceState):
        items = _evaluate_subspace(source, observable_set)
    elif isinstance(source, DensityMatrixState):
        items = _evaluate_density(source, observable_set)
    elif isinstance(source, TrajectoryBatchState):
        items = _evaluate_trajectories(source, observable_set)
    else:
        items = _evaluate_z_samples(source, observable_set)
    return ObservableBatchResultIR.from_results(observable_set, items)


def _validate_compatibility(
    source: ObservableEvaluationSource,
    observable_set: ObservableSet,
) -> None:
    order = source.logical_order
    available = set(order)
    for observable in observable_set:
        unknown = tuple(
            target for target in observable.targets if target not in available
        )
        if unknown:
            raise ValueError(
                f"observable '{observable.name}' has unknown target(s): {unknown}."
            )
        if isinstance(source, ZBasisMeasurementBatch) and any(
            basis not in {PauliBasis.I, PauliBasis.Z}
            for basis in observable.bases
        ):
            raise ValueError(
                f"observable '{observable.name}' is incompatible with Z-basis samples."
            )
        if isinstance(source, TrajectoryBatchState):
            lost_targets = tuple(
                target
                for target in observable.targets
                if not bool(
                    np.all(
                        source.occupations[:, source.logical_order.index(target)]
                    )
                )
            )
            if lost_targets:
                raise ValueError(
                    f"observable '{observable.name}' targets lost atoms: "
                    f"{lost_targets}."
                )


def _evaluate_state_vector(
    source: StateVectorState,
    observable_set: ObservableSet,
) -> tuple[ObservableResultIR, ...]:
    source_hash = source.stable_hash()
    return tuple(
        _exact_result(
            observable,
            _pure_expectation(source.amplitudes, observable, source.logical_order),
            source_kind=ObservableSourceKind.STATE_VECTOR,
            source_hash=source_hash,
            estimator_kind=ObservableEstimatorKind.EXACT_STATE,
        )
        for observable in observable_set
    )


def _evaluate_subspace(
    source: SubspaceState,
    observable_set: ObservableSet,
) -> tuple[ObservableResultIR, ...]:
    source_hash = source.stable_hash()
    position_by_basis = {
        int(basis_index): position
        for position, basis_index in enumerate(source.basis_indices)
    }
    items: list[ObservableResultIR] = []
    for observable in observable_set:
        transformed, phases = _pauli_action(
            observable,
            source.logical_order,
            source.basis_indices,
        )
        expectation = 0j
        for position, transformed_index in enumerate(transformed):
            transformed_position = position_by_basis.get(int(transformed_index))
            if transformed_position is not None:
                expectation += (
                    np.conjugate(source.amplitudes[transformed_position])
                    * phases[position]
                    * source.amplitudes[position]
                )
        items.append(
            _exact_result(
                observable,
                _real_expectation(expectation),
                source_kind=ObservableSourceKind.SUBSPACE,
                source_hash=source_hash,
                estimator_kind=ObservableEstimatorKind.EXACT_STATE,
            )
        )
    return tuple(items)


def _evaluate_density(
    source: DensityMatrixState,
    observable_set: ObservableSet,
) -> tuple[ObservableResultIR, ...]:
    source_hash = source.stable_hash()
    indices = np.arange(source.dimension, dtype=np.int64)
    items: list[ObservableResultIR] = []
    for observable in observable_set:
        transformed, phases = _pauli_action(
            observable,
            source.logical_order,
            indices,
        )
        expectation = np.sum(source.rho[indices, transformed] * phases)
        items.append(
            _exact_result(
                observable,
                _real_expectation(complex(expectation)),
                source_kind=ObservableSourceKind.DENSITY_MATRIX,
                source_hash=source_hash,
                estimator_kind=ObservableEstimatorKind.EXACT_DENSITY,
            )
        )
    return tuple(items)


def _evaluate_trajectories(
    source: TrajectoryBatchState,
    observable_set: ObservableSet,
) -> tuple[ObservableResultIR, ...]:
    source_hash = source.stable_hash()
    indices = np.arange(source.dimension, dtype=np.int64)
    items: list[ObservableResultIR] = []
    for observable in observable_set:
        transformed, phases = _pauli_action(
            observable,
            source.logical_order,
            indices,
        )
        values = np.sum(
            np.conjugate(source.amplitudes[:, transformed])
            * source.amplitudes
            * phases[np.newaxis, :],
            axis=1,
        )
        real_values = np.asarray(
            [_real_expectation(complex(value)) for value in values],
            dtype=np.float64,
        )
        expectation = _clip_expectation(float(np.mean(real_values)))
        standard_error = float(
            np.std(real_values, ddof=1) / math.sqrt(source.trajectory_count)
        )
        items.append(
            ObservableResultIR(
                observable=observable,
                expectation=expectation,
                variance=_pauli_variance(expectation),
                standard_error=standard_error,
                sample_count=source.trajectory_count,
                source_kind=ObservableSourceKind.TRAJECTORY_BATCH,
                source_hash=source_hash,
                estimator_kind=ObservableEstimatorKind.TRAJECTORY_MEAN,
            )
        )
    return tuple(items)


def _evaluate_z_samples(
    source: ZBasisMeasurementBatch,
    observable_set: ObservableSet,
) -> tuple[ObservableResultIR, ...]:
    source_hash = source.stable_hash()
    index_by_target = {
        target: index for index, target in enumerate(source.logical_order)
    }
    items: list[ObservableResultIR] = []
    for observable in observable_set:
        weighted_sum = 0
        for bitstring, count in source.counts:
            value = 1
            for term in observable.terms:
                if term.basis is PauliBasis.Z:
                    value *= 1 if bitstring[index_by_target[term.target]] == "0" else -1
            weighted_sum += value * count
        expectation = _clip_expectation(weighted_sum / source.sample_count)
        variance = _pauli_variance(expectation)
        # For +/-1 outcomes, the unbiased sample-mean variance is the
        # population variance divided by n - 1.
        standard_error = math.sqrt(variance / (source.sample_count - 1))
        items.append(
            ObservableResultIR(
                observable=observable,
                expectation=expectation,
                variance=variance,
                standard_error=standard_error,
                sample_count=source.sample_count,
                source_kind=ObservableSourceKind.SAMPLES,
                source_hash=source_hash,
                estimator_kind=ObservableEstimatorKind.SAMPLE_MEAN,
            )
        )
    return tuple(items)


def _pure_expectation(
    amplitudes: NDArray[np.complexfloating[Any, Any]],
    observable: Observable,
    logical_order: tuple[str, ...],
) -> float:
    indices = np.arange(amplitudes.shape[-1], dtype=np.int64)
    transformed, phases = _pauli_action(observable, logical_order, indices)
    value = np.vdot(amplitudes[transformed], phases * amplitudes)
    return _real_expectation(complex(value))


def _pauli_action(
    observable: Observable,
    logical_order: tuple[str, ...],
    basis_indices: NDArray[np.integer[Any]],
) -> tuple[NDArray[np.int64], NDArray[np.complex128]]:
    """Return O|i> target indices and phases without a dense operator."""
    indices = np.asarray(basis_indices, dtype=np.int64)
    transformed = np.array(indices, copy=True)
    phases = np.ones(indices.shape, dtype=np.complex128)
    width = len(logical_order)
    index_by_target = {
        target: position for position, target in enumerate(logical_order)
    }
    for term in observable.terms:
        shift = width - 1 - index_by_target[term.target]
        bit = (indices >> shift) & 1
        if term.basis is PauliBasis.X:
            transformed ^= 1 << shift
        elif term.basis is PauliBasis.Y:
            transformed ^= 1 << shift
            phases *= np.where(bit == 0, 1j, -1j)
        elif term.basis is PauliBasis.Z:
            phases *= 1 - 2 * bit
    return transformed, phases


def _exact_result(
    observable: Observable,
    expectation: float,
    *,
    source_kind: ObservableSourceKind,
    source_hash: str,
    estimator_kind: ObservableEstimatorKind,
) -> ObservableResultIR:
    expectation = _clip_expectation(expectation)
    return ObservableResultIR(
        observable=observable,
        expectation=expectation,
        variance=_pauli_variance(expectation),
        standard_error=0.0,
        sample_count=None,
        source_kind=source_kind,
        source_hash=source_hash,
        estimator_kind=estimator_kind,
    )


def _real_expectation(value: complex) -> float:
    if not math.isfinite(value.real) or not math.isfinite(value.imag):
        raise ValueError("observable expectation must be finite.")
    if abs(value.imag) > _EXPECTATION_IMAGINARY_TOLERANCE:
        raise ValueError("Hermitian Pauli expectation has a non-real component.")
    return _clip_expectation(float(value.real))


def _clip_expectation(value: float) -> float:
    return min(max(value, -1.0), 1.0)


def _pauli_variance(expectation: float) -> float:
    # Every Pauli product squares to identity, so <O^2> is exactly one.
    return min(max(1.0 - expectation * expectation, 0.0), 1.0)
