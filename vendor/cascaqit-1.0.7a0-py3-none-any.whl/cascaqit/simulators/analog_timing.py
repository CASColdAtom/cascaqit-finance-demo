"""Canonical control boundaries for Analog time integration."""

from __future__ import annotations

from cascaqit.native_ir import ProgramIR, WaveformIR


def analog_control_boundaries(program: ProgramIR) -> tuple[float, ...]:
    """Return sorted block-relative waveform and addressing boundaries."""
    duration = _program_duration(program)
    boundaries = {0.0, duration}
    for waveform in _waveforms(program):
        boundaries.add(float(waveform.duration))
        if waveform.times is not None:
            boundaries.update(float(value) for value in waveform.times)
    for detuning_term in program.hamiltonian.local_detuning_terms:
        boundaries.update(float(value) for value in detuning_term.addressing.times)
        boundaries.add(float(detuning_term.addressing.duration))
    for rabi_term in program.hamiltonian.local_rabi_terms:
        boundaries.update(float(value) for value in rabi_term.addressing.times)
        boundaries.add(float(rabi_term.addressing.duration))
    return tuple(sorted(value for value in boundaries if 0.0 <= value <= duration))


def _waveforms(program: ProgramIR) -> tuple[WaveformIR, ...]:
    values = [program.hamiltonian.rabi, program.hamiltonian.detuning]
    if isinstance(program.hamiltonian.phase, WaveformIR):
        values.append(program.hamiltonian.phase)
    values.extend(
        detuning_term.waveform
        for detuning_term in program.hamiltonian.local_detuning_terms
    )
    for rabi_term in program.hamiltonian.local_rabi_terms:
        values.append(rabi_term.rabi)
        if isinstance(rabi_term.phase, WaveformIR):
            values.append(rabi_term.phase)
    return tuple(values)


def _program_duration(program: ProgramIR) -> float:
    return max(waveform.duration for waveform in _waveforms(program))
