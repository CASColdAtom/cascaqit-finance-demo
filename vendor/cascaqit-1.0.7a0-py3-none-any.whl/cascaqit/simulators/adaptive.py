"""Shared adaptive integration with explicit discontinuity boundaries."""

from __future__ import annotations

import math
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

import numpy as np
from numpy.typing import NDArray
from scipy.integrate import DOP853  # type: ignore[import-untyped]

from cascaqit.exceptions import ProgramValidationError
from cascaqit.results import SimulationSolverEvidenceIR
from cascaqit.simulators.planning import SimulationIntegrator

ComplexArray = NDArray[np.complexfloating[Any, Any]]
ComplexRhs = Callable[[float, ComplexArray], ComplexArray]


@dataclass(frozen=True)
class AdaptiveIntegrationResult:
    """Final vector and the exact statistics exposed by SciPy."""

    values: ComplexArray
    evidence: SimulationSolverEvidenceIR


def integrate_dop853_segments(
    rhs: ComplexRhs,
    initial_values: ComplexArray,
    *,
    boundaries: tuple[float, ...],
    integrator_requested: SimulationIntegrator,
    rtol: float,
    atol: float,
    max_steps: int,
    logical_time_offset: float = 0.0,
    time_unit: str = "us",
) -> AdaptiveIntegrationResult:
    """Integrate each smooth segment and stop after ``max_steps`` accepted steps."""
    _validate_inputs(
        boundaries,
        rtol=rtol,
        atol=atol,
        max_steps=max_steps,
        logical_time_offset=logical_time_offset,
    )
    state = np.asarray(initial_values)
    accepted_steps = 0
    function_evaluations = 0
    step_sizes: list[float] = []
    segment_count = 0

    for left, right in zip(boundaries, boundaries[1:]):
        if right == left:
            continue
        segment_count += 1
        # Step controls are left-closed. Evaluating the previous segment at its
        # right endpoint would sample the next SiteAddressing frame in a final RK
        # stage, so clamp only that endpoint to the current segment's left limit.
        left_limit_of_right = float(np.nextafter(right, left))

        def segment_rhs(
            time: float,
            values: ComplexArray,
            *,
            segment_right: float = right,
            endpoint_left_limit: float = left_limit_of_right,
        ) -> ComplexArray:
            evaluation_time = (
                endpoint_left_limit if time >= segment_right else time
            )
            return np.asarray(rhs(evaluation_time, values))

        solver = DOP853(
            segment_rhs,
            left,
            state,
            right,
            rtol=rtol,
            atol=atol,
        )
        while solver.status == "running":
            if accepted_steps >= max_steps:
                raise ProgramValidationError(
                    "Adaptive integration exceeded max_steps.",
                    code="SIMULATION_ADAPTIVE_MAX_STEPS_EXCEEDED",
                    stage="simulation",
                    object_path="simulation_options.max_steps",
                    metadata={
                        "accepted_steps": accepted_steps,
                        "max_steps": max_steps,
                        "segment_start": left,
                        "segment_end": right,
                        "large_array_allocated": True,
                    },
                )
            message = solver.step()
            if solver.status == "failed":
                raise ProgramValidationError(
                    "Adaptive integration failed.",
                    code="SIMULATION_ADAPTIVE_SOLVER_FAILED",
                    stage="simulation",
                    object_path="simulation_solver",
                    metadata={
                        "accepted_steps": accepted_steps,
                        "segment_start": left,
                        "segment_end": right,
                        "solver_message": message,
                    },
                )
            accepted_steps += 1
            if solver.step_size is not None:
                step_sizes.append(float(solver.step_size))
        function_evaluations += int(solver.nfev)
        state = np.asarray(solver.y)

    if not np.all(np.isfinite(state)):
        raise ProgramValidationError(
            "Adaptive integration produced non-finite state values.",
            code="SIMULATION_ADAPTIVE_STATE_NON_FINITE",
            stage="simulation",
            object_path="simulation_state",
        )

    evidence = SimulationSolverEvidenceIR(
        integrator_requested=integrator_requested,
        integrator_selected="adaptive_dop853",
        tolerance_applied=True,
        relative_tolerance=rtol,
        absolute_tolerance=atol,
        accepted_steps=accepted_steps,
        function_evaluations=function_evaluations,
        segment_count=segment_count,
        # DOP853 does not expose internal rejected trial-step counts.
        rejected_steps=None,
        rejected_steps_available=False,
        min_step_size=min(step_sizes) if step_sizes else None,
        max_step_size=max(step_sizes) if step_sizes else None,
        initial_time=logical_time_offset + boundaries[0],
        final_time=logical_time_offset + boundaries[-1],
        time_unit=time_unit,
        termination_reason="completed",
        metadata={
            "solver": "scipy.integrate.DOP853",
            "control_boundaries": list(boundaries),
        },
    )
    return AdaptiveIntegrationResult(values=state, evidence=evidence)


def fixed_step_solver_evidence(
    *,
    integrator_requested: SimulationIntegrator,
    steps: int,
    duration: float,
    logical_time_offset: float,
    time_unit: str,
    algorithm: str,
) -> SimulationSolverEvidenceIR:
    """Describe executed fixed slices without attaching unused tolerances."""
    step_size = None if steps == 0 else duration / steps
    return SimulationSolverEvidenceIR(
        integrator_requested=integrator_requested,
        integrator_selected="fixed_step_krylov",
        tolerance_applied=False,
        relative_tolerance=None,
        absolute_tolerance=None,
        accepted_steps=steps,
        function_evaluations=None,
        segment_count=steps,
        rejected_steps=None,
        rejected_steps_available=False,
        min_step_size=step_size,
        max_step_size=step_size,
        initial_time=logical_time_offset,
        final_time=logical_time_offset + duration,
        time_unit=time_unit,
        termination_reason="completed",
        metadata={"solver": algorithm},
    )


def _validate_inputs(
    boundaries: tuple[float, ...],
    *,
    rtol: float,
    atol: float,
    max_steps: int,
    logical_time_offset: float,
) -> None:
    if len(boundaries) < 2:
        raise ValueError("boundaries must contain start and end times.")
    if any(not math.isfinite(value) or value < 0.0 for value in boundaries):
        raise ValueError("boundaries must be finite and non-negative.")
    if any(right <= left for left, right in zip(boundaries, boundaries[1:])):
        raise ValueError("boundaries must be strictly increasing.")
    for value, field_name in ((rtol, "rtol"), (atol, "atol")):
        if not math.isfinite(value) or value <= 0.0:
            raise ValueError(f"{field_name} must be finite and positive.")
    if not isinstance(max_steps, int) or isinstance(max_steps, bool) or max_steps <= 0:
        raise ValueError("max_steps must be a positive integer.")
    if not math.isfinite(logical_time_offset) or logical_time_offset < 0.0:
        raise ValueError("logical_time_offset must be finite and non-negative.")
