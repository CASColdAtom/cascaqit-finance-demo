"""Narrow factual benchmark for the optional Pulser reference workload."""

from __future__ import annotations

import json
import math
import platform
import sys
import time
from dataclasses import dataclass, field
from statistics import median
from typing import Any, Callable

from cascaqit.native_ir.base import IRMixin
from cascaqit.native_ir.models import SCHEMA_VERSION, ProgramIR
from cascaqit.simulators.local_ahs import LocalAhsSimulator
from cascaqit.simulators.pulser_reference import (
    PulserReferenceAdapter,
    PulserReferenceError,
    _materialize_projection,
    _run_materialized_projection,
)

__all__ = ["PulserReferenceBenchmarkIR", "benchmark_pulser_reference"]

_PHASES = (
    "projection",
    "reference_setup",
    "reference_run",
    "native_run",
)


@dataclass(frozen=True)
class PulserReferenceBenchmarkIR(IRMixin):
    """Warm-up and median timing facts for one frozen local workload."""

    benchmark_id: str
    program_hash: str
    warmup_runs: int
    measured_runs: int
    phase_samples_seconds: dict[str, tuple[float, ...]]
    phase_medians_seconds: dict[str, float]
    environment: dict[str, str]
    actual_reference_execution: bool
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.warmup_runs < 0 or self.measured_runs <= 0:
            raise ValueError("Benchmark run counts are invalid.")
        if set(self.phase_samples_seconds) != set(_PHASES):
            raise ValueError("Benchmark samples must contain all frozen phases.")
        if set(self.phase_medians_seconds) != set(_PHASES):
            raise ValueError("Benchmark medians must contain all frozen phases.")
        if any(
            len(samples) != self.measured_runs
            or any(value < 0.0 for value in samples)
            for samples in self.phase_samples_seconds.values()
        ):
            raise ValueError("Benchmark samples must match measured_runs.")
        if any(
            value < 0.0
            or not math.isclose(
                value,
                median(self.phase_samples_seconds[phase]),
            )
            for phase, value in self.phase_medians_seconds.items()
        ):
            raise ValueError("Benchmark medians must match the measured samples.")
        if not self.actual_reference_execution:
            raise ValueError("Benchmark evidence requires actual reference execution.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PulserReferenceBenchmarkIR:
        """Build benchmark evidence from a JSON-compatible dictionary."""
        return cls(
            benchmark_id=str(data["benchmark_id"]),
            program_hash=str(data["program_hash"]),
            warmup_runs=int(data["warmup_runs"]),
            measured_runs=int(data["measured_runs"]),
            phase_samples_seconds={
                str(key): tuple(float(value) for value in values)
                for key, values in data["phase_samples_seconds"].items()
            },
            phase_medians_seconds={
                str(key): float(value)
                for key, value in data["phase_medians_seconds"].items()
            },
            environment={
                str(key): str(value)
                for key, value in data.get("environment", {}).items()
            },
            actual_reference_execution=bool(data["actual_reference_execution"]),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> PulserReferenceBenchmarkIR:
        """Build benchmark evidence from JSON."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("Pulser benchmark JSON must contain an object.")
        return cls.from_dict(data)


def benchmark_pulser_reference(
    program: ProgramIR,
    *,
    warmup_runs: int = 1,
    measured_runs: int = 5,
    clock: Callable[[], float] = time.perf_counter,
) -> PulserReferenceBenchmarkIR:
    """Measure frozen local phases without making a relative performance claim."""
    if not isinstance(program, ProgramIR):
        raise TypeError("benchmark_pulser_reference accepts ProgramIR.")
    if warmup_runs < 0 or measured_runs < 1 or measured_runs > 20:
        raise ValueError("Use warmup_runs >= 0 and 1 <= measured_runs <= 20.")
    adapter = PulserReferenceAdapter()
    capability = adapter.check(program)
    if not capability.actual_execution_available:
        raise PulserReferenceError(
            "Pulser benchmark requires the compatible optional runtime.",
            code="PULSER_REFERENCE_BENCHMARK_UNAVAILABLE",
            object_path="pulser_reference_benchmark",
            suggestion="Install the reference-pulser extra in an isolated environment.",
            diagnostics=capability.diagnostics,
        )
    solver_configuration: dict[str, Any] = {
        "sampling_rate": 1.0,
        "atol": 1e-12,
        "rtol": 1e-12,
        "progress_bar": False,
    }
    simulator = LocalAhsSimulator()
    for _ in range(warmup_runs):
        projection = adapter.project(program)
        emulator = _materialize_projection(projection, solver_configuration)
        _run_materialized_projection(emulator, solver_configuration)
        simulator.run(program, shots=0)
    samples: dict[str, list[float]] = {phase: [] for phase in _PHASES}
    for _ in range(measured_runs):
        started = clock()
        projection = adapter.project(program)
        projected = clock()
        emulator = _materialize_projection(projection, solver_configuration)
        prepared = clock()
        _run_materialized_projection(emulator, solver_configuration)
        referenced = clock()
        simulator.run(program, shots=0)
        native = clock()
        samples["projection"].append(projected - started)
        samples["reference_setup"].append(prepared - projected)
        samples["reference_run"].append(referenced - prepared)
        samples["native_run"].append(native - referenced)
    frozen_samples = {
        phase: tuple(samples[phase])
        for phase in _PHASES
    }
    return PulserReferenceBenchmarkIR(
        benchmark_id=f"benchmark.pulser.reference.{program.program_id}",
        program_hash=program.stable_hash(),
        warmup_runs=warmup_runs,
        measured_runs=measured_runs,
        phase_samples_seconds=frozen_samples,
        phase_medians_seconds={
            phase: median(frozen_samples[phase])
            for phase in _PHASES
        },
        environment={
            "python": platform.python_version(),
            "platform": platform.platform(),
            **capability.package_versions,
        },
        actual_reference_execution=True,
        metadata={
            "clock": "time.perf_counter",
            "workload_scope": "one_site_global_rydberg",
            "performance_ratio_claimed": False,
            "network_accessed": False,
            "hardware_execution": False,
            "cloud_execution": False,
            "python_executable": sys.executable,
        },
    )
