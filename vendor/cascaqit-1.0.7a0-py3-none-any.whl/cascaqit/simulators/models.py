"""Shared simulator metadata contracts."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Literal

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.native_ir.base import IRMixin
from cascaqit.native_ir.models import SCHEMA_VERSION

__all__ = [
    "SimulationManifestIR",
    "SimulationAlgorithmIR",
    "SimulationStateIR",
    "build_simulation_manifest",
    "build_probability_state_summary",
    "build_sample_state_summary",
    "build_state_vector_metadata_summary",
    "diagnose_simulation_manifest",
    "diagnose_simulation_state",
    "select_simulation_algorithm",
]

SimulationManifestProgramKind = Literal["analog", "digital", "hybrid"]
SimulationManifestNoiseMode = Literal["none", "readout", "digital_readout", "atom_loss"]
SimulationStateKind = Literal[
    "state_vector",
    "density_matrix",
    "probability_distribution",
    "samples",
    "classical_register",
    "summary",
]
SimulationProgramType = Literal["analog", "digital", "hybrid", "unknown"]


@dataclass(frozen=True)
class SimulationManifestIR(IRMixin):
    """Metadata-only local simulation workflow manifest."""

    manifest_id: str
    program_kind: SimulationManifestProgramKind
    program_ref: str
    program_hash: str
    simulator_name: str
    shots: int
    seed: int | None = None
    method: str = "auto"
    noise_mode: SimulationManifestNoiseMode = "none"
    expected_outputs: tuple[str, ...] = ("counts",)
    target_summary: dict[str, Any] = field(default_factory=dict)
    simulator_config: dict[str, Any] = field(default_factory=dict)
    noise_model_ref: str | None = None
    run_tags: tuple[str, ...] = ()
    offline_deterministic: bool = True
    hardware_execution: bool = False
    cloud_execution: bool = False
    backend_called: bool = False
    network_accessed: bool = False
    credential_secret_read: bool = False
    artifact_bytes_read: bool = False
    returned_state_bytes: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SimulationManifestIR:
        """Build a simulation manifest from a dictionary."""
        return cls(
            manifest_id=str(data["manifest_id"]),
            program_kind=data["program_kind"],
            program_ref=str(data["program_ref"]),
            program_hash=str(data["program_hash"]),
            simulator_name=str(data["simulator_name"]),
            shots=int(data["shots"]),
            seed=None if data.get("seed") is None else int(data["seed"]),
            method=str(data.get("method", "auto")),
            noise_mode=data.get("noise_mode", "none"),
            expected_outputs=tuple(
                str(output) for output in data.get("expected_outputs", ("counts",))
            ),
            target_summary=dict(data.get("target_summary", {})),
            simulator_config=dict(data.get("simulator_config", {})),
            noise_model_ref=(
                None
                if data.get("noise_model_ref") is None
                else str(data["noise_model_ref"])
            ),
            run_tags=tuple(str(tag) for tag in data.get("run_tags", ())),
            offline_deterministic=bool(data.get("offline_deterministic", True)),
            hardware_execution=bool(data.get("hardware_execution", False)),
            cloud_execution=bool(data.get("cloud_execution", False)),
            backend_called=bool(data.get("backend_called", False)),
            network_accessed=bool(data.get("network_accessed", False)),
            credential_secret_read=bool(data.get("credential_secret_read", False)),
            artifact_bytes_read=bool(data.get("artifact_bytes_read", False)),
            returned_state_bytes=bool(data.get("returned_state_bytes", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> SimulationManifestIR:
        """Build a simulation manifest from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("SimulationManifestIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class SimulationStateIR(IRMixin):
    """Metadata-only summary of a simulator state artifact."""

    state_id: str
    state_kind: SimulationStateKind
    basis: str
    dimension: int | None = None
    atom_order: tuple[str, ...] = ()
    qubit_order: tuple[str, ...] = ()
    probability_mass: float | None = None
    norm: float | None = None
    trace: float | None = None
    sample_count: int | None = None
    returned_state_bytes: bool = False
    truncated: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SimulationStateIR:
        """Build a simulation state summary from a dictionary."""
        return cls(
            state_id=str(data["state_id"]),
            state_kind=data["state_kind"],
            basis=str(data["basis"]),
            dimension=(
                None if data.get("dimension") is None else int(data["dimension"])
            ),
            atom_order=tuple(str(atom) for atom in data.get("atom_order", ())),
            qubit_order=tuple(str(qubit) for qubit in data.get("qubit_order", ())),
            probability_mass=(
                None
                if data.get("probability_mass") is None
                else float(data["probability_mass"])
            ),
            norm=None if data.get("norm") is None else float(data["norm"]),
            trace=None if data.get("trace") is None else float(data["trace"]),
            sample_count=(
                None
                if data.get("sample_count") is None
                else int(data["sample_count"])
            ),
            returned_state_bytes=bool(data.get("returned_state_bytes", False)),
            truncated=bool(data.get("truncated", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> SimulationStateIR:
        """Build a simulation state summary from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("SimulationStateIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class SimulationAlgorithmIR(IRMixin):
    """Deterministic record of simulator method selection."""

    algorithm_id: str
    simulator_name: str
    program_type: SimulationProgramType
    method_requested: str
    method_selected: str
    algorithm_family: str
    selection_reason: tuple[str, ...]
    deterministic: bool = True
    seed: int | None = None
    parameters: dict[str, Any] = field(default_factory=dict)
    limits: dict[str, Any] = field(default_factory=dict)
    diagnostics: tuple[DiagnosticsIR, ...] = ()
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SimulationAlgorithmIR:
        """Build simulation algorithm metadata from a dictionary."""
        return cls(
            algorithm_id=str(data["algorithm_id"]),
            simulator_name=str(data["simulator_name"]),
            program_type=data.get("program_type", "unknown"),
            method_requested=str(data["method_requested"]),
            method_selected=str(data["method_selected"]),
            algorithm_family=str(data["algorithm_family"]),
            selection_reason=tuple(
                str(reason) for reason in data.get("selection_reason", ())
            ),
            deterministic=bool(data.get("deterministic", True)),
            seed=None if data.get("seed") is None else int(data["seed"]),
            parameters=dict(data.get("parameters", {})),
            limits=dict(data.get("limits", {})),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(diagnostic)
                for diagnostic in data.get("diagnostics", ())
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> SimulationAlgorithmIR:
        """Build simulation algorithm metadata from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("SimulationAlgorithmIR JSON must contain an object.")
        return cls.from_dict(data)


def build_simulation_manifest(
    *,
    manifest_id: str,
    program_kind: SimulationManifestProgramKind,
    program_ref: str,
    program_hash: str,
    simulator_name: str = "Simulator",
    shots: int,
    seed: int | None = None,
    method: str = "auto",
    noise_mode: SimulationManifestNoiseMode = "none",
    expected_outputs: tuple[str, ...] = ("counts",),
    target_summary: dict[str, Any] | None = None,
    simulator_config: dict[str, Any] | None = None,
    noise_model_ref: str | None = None,
    run_tags: tuple[str, ...] = (),
    metadata: dict[str, Any] | None = None,
) -> SimulationManifestIR:
    """Build a metadata-only local simulation manifest."""
    return SimulationManifestIR(
        manifest_id=manifest_id,
        program_kind=program_kind,
        program_ref=program_ref,
        program_hash=program_hash,
        simulator_name=simulator_name,
        shots=shots,
        seed=seed,
        method=method,
        noise_mode=noise_mode,
        expected_outputs=expected_outputs,
        target_summary={} if target_summary is None else dict(target_summary),
        simulator_config={} if simulator_config is None else dict(simulator_config),
        noise_model_ref=noise_model_ref,
        run_tags=run_tags,
        offline_deterministic=True,
        hardware_execution=False,
        cloud_execution=False,
        backend_called=False,
        network_accessed=False,
        credential_secret_read=False,
        artifact_bytes_read=False,
        returned_state_bytes=False,
        metadata={} if metadata is None else dict(metadata),
    )


def diagnose_simulation_manifest(
    manifest: SimulationManifestIR,
) -> tuple[DiagnosticsIR, ...]:
    """Validate a simulation manifest without contacting external systems."""
    diagnostics: list[DiagnosticsIR] = []
    if manifest.shots <= 0:
        diagnostics.append(
            _diagnostic(
                code="SIMULATION_MANIFEST_SHOTS_INVALID",
                message="Simulation manifest shots must be positive.",
                object_path="simulation_manifest.shots",
                severity="error",
                metadata={"shots": manifest.shots},
            )
        )
    if manifest.program_kind not in {"analog", "digital", "hybrid"}:
        diagnostics.append(
            _diagnostic(
                code="SIMULATION_MANIFEST_PROGRAM_KIND_INVALID",
                message="Simulation manifest program kind is not supported.",
                object_path="simulation_manifest.program_kind",
                severity="error",
                metadata={"program_kind": manifest.program_kind},
            )
        )
    if manifest.noise_mode not in {"none", "readout", "digital_readout", "atom_loss"}:
        diagnostics.append(
            _diagnostic(
                code="SIMULATION_MANIFEST_NOISE_MODE_INVALID",
                message="Simulation manifest noise mode is not supported.",
                object_path="simulation_manifest.noise_mode",
                severity="error",
                metadata={"noise_mode": manifest.noise_mode},
            )
        )
    if manifest.noise_mode != "none" and manifest.noise_model_ref is None:
        diagnostics.append(
            _diagnostic(
                code="SIMULATION_MANIFEST_NOISE_MODEL_MISSING",
                message="A noise model reference is required for noisy simulations.",
                object_path="simulation_manifest.noise_model_ref",
                severity="warning",
                suggestion=(
                    "Attach a NoiseModelIR reference before running this manifest."
                ),
                metadata={"noise_mode": manifest.noise_mode},
            )
        )
    if manifest.returned_state_bytes:
        diagnostics.append(
            _diagnostic(
                code="SIMULATION_MANIFEST_STATE_BYTES_NOT_ALLOWED",
                message="Simulation manifests must not embed returned state bytes.",
                object_path="simulation_manifest.returned_state_bytes",
                severity="error",
            )
        )
    if (
        not manifest.offline_deterministic
        or manifest.hardware_execution
        or manifest.cloud_execution
        or manifest.backend_called
        or manifest.network_accessed
        or manifest.credential_secret_read
        or manifest.artifact_bytes_read
    ):
        diagnostics.append(
            _diagnostic(
                code="SIMULATION_MANIFEST_OFFLINE_BOUNDARY_VIOLATION",
                message=(
                    "Simulation manifests must preserve the offline local boundary."
                ),
                object_path="simulation_manifest",
                severity="error",
                metadata={
                    "offline_deterministic": manifest.offline_deterministic,
                    "hardware_execution": manifest.hardware_execution,
                    "cloud_execution": manifest.cloud_execution,
                    "backend_called": manifest.backend_called,
                    "network_accessed": manifest.network_accessed,
                    "credential_secret_read": manifest.credential_secret_read,
                    "artifact_bytes_read": manifest.artifact_bytes_read,
                },
            )
        )
    if not diagnostics:
        diagnostics.append(
            _diagnostic(
                code="SIMULATION_MANIFEST_VALID",
                message="Simulation manifest is structurally valid.",
                object_path="simulation_manifest",
                severity="info",
                metadata={
                    "program_kind": manifest.program_kind,
                    "noise_mode": manifest.noise_mode,
                    "offline_deterministic": manifest.offline_deterministic,
                },
            )
        )
    return tuple(diagnostics)


def build_probability_state_summary(
    probabilities: dict[str, float],
    *,
    state_id: str,
    basis: str,
    atom_order: tuple[str, ...] = (),
    qubit_order: tuple[str, ...] = (),
    metadata: dict[str, Any] | None = None,
) -> SimulationStateIR:
    """Build a metadata-only probability distribution state summary."""
    return SimulationStateIR(
        state_id=state_id,
        state_kind="probability_distribution",
        basis=basis,
        dimension=len(probabilities),
        atom_order=atom_order,
        qubit_order=qubit_order,
        probability_mass=sum(float(value) for value in probabilities.values()),
        returned_state_bytes=False,
        truncated=False,
        metadata={} if metadata is None else dict(metadata),
    )


def build_sample_state_summary(
    samples: tuple[str, ...],
    *,
    state_id: str,
    basis: str,
    atom_order: tuple[str, ...] = (),
    qubit_order: tuple[str, ...] = (),
    metadata: dict[str, Any] | None = None,
) -> SimulationStateIR:
    """Build a metadata-only sample state summary."""
    dimension = len(set(samples)) if samples else 0
    return SimulationStateIR(
        state_id=state_id,
        state_kind="samples",
        basis=basis,
        dimension=dimension,
        atom_order=atom_order,
        qubit_order=qubit_order,
        sample_count=len(samples),
        returned_state_bytes=False,
        truncated=False,
        metadata={} if metadata is None else dict(metadata),
    )


def build_state_vector_metadata_summary(
    *,
    state_id: str,
    basis: str,
    dimension: int,
    norm: float | None,
    atom_order: tuple[str, ...] = (),
    qubit_order: tuple[str, ...] = (),
    returned_state_bytes: bool = False,
    truncated: bool = False,
    metadata: dict[str, Any] | None = None,
) -> SimulationStateIR:
    """Build a state-vector metadata summary without requiring amplitudes."""
    return SimulationStateIR(
        state_id=state_id,
        state_kind="state_vector",
        basis=basis,
        dimension=dimension,
        atom_order=atom_order,
        qubit_order=qubit_order,
        norm=norm,
        returned_state_bytes=returned_state_bytes,
        truncated=truncated,
        metadata={} if metadata is None else dict(metadata),
    )


def diagnose_simulation_state(
    state: SimulationStateIR,
    *,
    tolerance: float = 1e-9,
) -> tuple[DiagnosticsIR, ...]:
    """Validate state summary invariants without inspecting large state bytes."""
    diagnostics: list[DiagnosticsIR] = []
    if state.dimension is not None and state.dimension < 0:
        diagnostics.append(
            _diagnostic(
                code="SIMULATION_STATE_DIMENSION_INVALID",
                message="Simulation state dimension must be non-negative.",
                object_path="simulation_state.dimension",
                severity="error",
            )
        )
    if state.probability_mass is not None and (
        abs(state.probability_mass - 1.0) > tolerance
    ):
        diagnostics.append(
            _diagnostic(
                code="SIMULATION_STATE_PROBABILITY_MASS_INVALID",
                message="Probability distribution state mass must be close to 1.",
                object_path="simulation_state.probability_mass",
                severity="error",
                metadata={"probability_mass": state.probability_mass},
            )
        )
    if state.norm is not None and abs(state.norm - 1.0) > tolerance:
        diagnostics.append(
            _diagnostic(
                code="SIMULATION_STATE_NORM_INVALID",
                message="State-vector norm must be close to 1.",
                object_path="simulation_state.norm",
                severity="error",
                metadata={"norm": state.norm},
            )
        )
    if state.trace is not None and abs(state.trace - 1.0) > tolerance:
        diagnostics.append(
            _diagnostic(
                code="SIMULATION_STATE_TRACE_INVALID",
                message="Density-matrix trace must be close to 1.",
                object_path="simulation_state.trace",
                severity="error",
                metadata={"trace": state.trace},
            )
        )
    if not diagnostics:
        diagnostics.append(
            _diagnostic(
                code="SIMULATION_STATE_VALID",
                message="Simulation state summary is structurally valid.",
                object_path="simulation_state",
                severity="info",
                metadata={"state_kind": state.state_kind},
            )
        )
    return tuple(diagnostics)


def select_simulation_algorithm(
    *,
    simulator_name: str,
    program_type: SimulationProgramType,
    requested_method: str,
    hilbert_dimension: int | None = None,
    max_hilbert_dim: int | None = None,
    seed: int | None = None,
    parameters: dict[str, Any] | None = None,
    metadata: dict[str, Any] | None = None,
) -> SimulationAlgorithmIR:
    """Return deterministic simulator method-selection metadata."""
    supported = {"auto", "exact", "ode", "exact_state_rk4"}
    diagnostics: list[DiagnosticsIR] = []
    if requested_method not in supported:
        diagnostics.append(
            _diagnostic(
                code="SIMULATION_METHOD_UNSUPPORTED",
                message="Requested simulator method is not supported by this release.",
                object_path="simulation_algorithm.method_requested",
                severity="warning",
                suggestion="Use method='auto' or method='exact'.",
                metadata={"requested_method": requested_method},
            )
        )
    if (
        hilbert_dimension is not None
        and max_hilbert_dim is not None
        and hilbert_dimension > max_hilbert_dim
    ):
        diagnostics.append(
            _diagnostic(
                code="SIMULATION_METHOD_DIMENSION_LIMIT_EXCEEDED",
                message="Hilbert dimension exceeds the configured simulation limit.",
                object_path="simulation_algorithm.limits.max_hilbert_dim",
                severity="error",
                metadata={
                    "hilbert_dimension": hilbert_dimension,
                    "max_hilbert_dim": max_hilbert_dim,
                },
            )
        )
    selection_reason = _selection_reason(
        program_type=program_type,
        requested_method=requested_method,
        hilbert_dimension=hilbert_dimension,
        max_hilbert_dim=max_hilbert_dim,
    )
    if not diagnostics:
        diagnostics.append(
            _diagnostic(
                code="SIMULATION_METHOD_SELECTED",
                message="Simulator method selection metadata was recorded.",
                object_path="simulation_algorithm",
                severity="info",
                metadata={"method_selected": "exact_state_rk4"},
            )
        )
    return SimulationAlgorithmIR(
        algorithm_id=f"algorithm.{simulator_name}.{program_type}",
        simulator_name=simulator_name,
        program_type=program_type,
        method_requested=requested_method,
        method_selected="exact_state_rk4",
        algorithm_family="exact_state_ode",
        selection_reason=selection_reason,
        deterministic=True,
        seed=seed,
        parameters={} if parameters is None else dict(parameters),
        limits={
            "hilbert_dimension": hilbert_dimension,
            "max_hilbert_dim": max_hilbert_dim,
        },
        diagnostics=tuple(diagnostics),
        metadata={} if metadata is None else dict(metadata),
    )


def _selection_reason(
    *,
    program_type: SimulationProgramType,
    requested_method: str,
    hilbert_dimension: int | None,
    max_hilbert_dim: int | None,
) -> tuple[str, ...]:
    reasons = [
        f"program_type={program_type}",
        f"requested_method={requested_method}",
    ]
    if requested_method == "auto":
        reasons.append("auto selects exact_state_rk4 for the local AHS baseline")
    else:
        reasons.append("explicit method is recorded for review")
    if hilbert_dimension is not None:
        reasons.append(f"hilbert_dimension={hilbert_dimension}")
    if max_hilbert_dim is not None:
        reasons.append(f"max_hilbert_dim={max_hilbert_dim}")
    return tuple(reasons)


def _diagnostic(
    *,
    code: str,
    message: str,
    object_path: str,
    severity: Literal["info", "warning", "error"],
    suggestion: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> DiagnosticsIR:
    return DiagnosticsIR(
        diagnostic_id=f"simulation.{code.lower()}",
        stage="simulation",
        severity=severity,
        code=code,
        message=message,
        object_path=object_path,
        suggestion=suggestion,
        metadata={} if metadata is None else dict(metadata),
    )
