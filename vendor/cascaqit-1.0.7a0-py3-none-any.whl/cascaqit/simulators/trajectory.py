"""Batched quantum-trajectory kernels with continuous Hybrid state lineage."""

from __future__ import annotations

import hashlib
import math
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from typing import Any, Literal, Union, cast

import numpy as np
from numpy.typing import NDArray
from scipy.sparse.linalg import (  # type: ignore[import-untyped]
    LinearOperator,
    expm_multiply,
)

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.digital import DigitalProgramIR, GateIR
from cascaqit.exceptions import ProgramValidationError
from cascaqit.native_ir import ProgramIR
from cascaqit.results import ResultIR, SimulationSolverEvidenceIR, StateTransitionIR
from cascaqit.simulators.adaptive import fixed_step_solver_evidence
from cascaqit.simulators.addressing import site_addressing_provenance_metadata
from cascaqit.simulators.array_state import (
    ArrayStateProvenance,
    TrajectoryBatchState,
)
from cascaqit.simulators.execution_evidence import (
    aggregate_solver_evidence,
    not_applicable_solver_evidence,
    solver_evidence_metadata,
)
from cascaqit.simulators.ideal import (
    ArrayDType,
    ComplexArray,
    _analog_linear_operator,
    _duration,
    _gate_matrix,
    _local_matrix_action,
    validate_scalable_hybrid_bundle,
)
from cascaqit.simulators.local_hybrid import (
    AnalogStepPayload,
    DigitalStepPayload,
    LocalExecutionBundle,
    MeasurementStepPayload,
)
from cascaqit.simulators.local_rabi import site_phase_pattern_provenance_metadata
from cascaqit.simulators.register_evidence import collect_register_snapshot_evidence
from cascaqit.simulators.runtime_lineage import (
    build_runtime_references,
    build_runtime_trace,
    build_state_transition,
    runtime_lineage_metadata,
)

__all__ = [
    "BatchedTrajectoryKernel",
    "TrajectoryBatchRun",
    "apply_trajectory_amplitude_damping",
    "apply_trajectory_atom_loss",
    "apply_trajectory_pauli_channel",
    "apply_trajectory_unitary_channel",
    "build_trajectory_result",
    "derive_trajectory_seed",
    "run_trajectory_hybrid",
    "trajectory_hashes",
    "zero_trajectory_batch",
]


def derive_trajectory_seed(root_seed: int, trajectory_index: int) -> int:
    """Derive one stable uint64 seed without depending on worker scheduling."""
    if not isinstance(root_seed, int) or isinstance(root_seed, bool):
        raise TypeError("root_seed must be an integer.")
    if (
        not isinstance(trajectory_index, int)
        or isinstance(trajectory_index, bool)
        or trajectory_index < 0
    ):
        raise ValueError("trajectory_index must be a non-negative integer.")
    digest = hashlib.sha256(f"{root_seed}:{trajectory_index}".encode("ascii"))
    return int.from_bytes(digest.digest()[:8], "big", signed=False)


def zero_trajectory_batch(
    logical_order: tuple[str, ...],
    trajectories: int,
    *,
    seed: int,
    dtype: ArrayDType = "complex128",
) -> TrajectoryBatchState:
    """Create identical zero states with independently derived trajectory seeds."""
    if not logical_order:
        raise ValueError("logical_order must not be empty.")
    if not isinstance(trajectories, int) or isinstance(trajectories, bool):
        raise TypeError("trajectories must be an integer.")
    if trajectories <= 0:
        raise ValueError("trajectories must be positive.")
    dimension = 2 ** len(logical_order)
    amplitudes = np.zeros((trajectories, dimension), dtype=np.dtype(dtype))
    amplitudes[:, 0] = 1.0
    seeds = np.asarray(
        [derive_trajectory_seed(seed, index) for index in range(trajectories)],
        dtype=np.uint64,
    )
    return TrajectoryBatchState(
        amplitudes=amplitudes,
        trajectory_seeds=seeds,
        jump_counts=np.zeros(trajectories, dtype=np.int64),
        occupations=np.ones(
            (trajectories, len(logical_order)),
            dtype=np.bool_,
        ),
        logical_order=logical_order,
        noise_context=(("model", "physical_dephasing_trajectory"),),
        provenance=ArrayStateProvenance.initial("zero_trajectory_batch"),
    )


@dataclass(frozen=True)
class TrajectoryBatchRun:
    """Continuous D-A-D trajectory result before terminal sampling."""

    bundle: LocalExecutionBundle
    initial_state: TrajectoryBatchState
    final_state: TrajectoryBatchState
    transitions: tuple[StateTransitionIR, ...]
    dephasing_rate: float
    steps: int
    chunk_size: int
    workers: int
    blockade_radius: float


@dataclass(frozen=True)
class BatchedTrajectoryKernel:
    """Apply tensor Digital gates and chunked matrix-free Analog propagation."""

    steps: int = 8
    blockade_radius: float = 0.0
    chunk_size: int = 16
    workers: int = 1

    def __post_init__(self) -> None:
        for field_name in ("steps", "chunk_size", "workers"):
            value = getattr(self, field_name)
            if not isinstance(value, int) or isinstance(value, bool) or value <= 0:
                raise ValueError(f"{field_name} must be a positive integer.")
        if not math.isfinite(self.blockade_radius) or self.blockade_radius < 0.0:
            raise ValueError("blockade_radius must be finite and non-negative.")

    def evolve_digital(
        self,
        program: DigitalProgramIR,
        initial_state: TrajectoryBatchState,
    ) -> TrajectoryBatchState:
        if tuple(program.circuit.qubits) != initial_state.logical_order:
            raise ProgramValidationError(
                "Digital program order does not match trajectory state order.",
                code="DIGITAL_TRAJECTORY_LOGICAL_ORDER_MISMATCH",
                stage="simulation",
                object_path="simulation_state.logical_order",
            )
        amplitudes = np.array(initial_state.amplitudes, copy=True)
        qubit_index = {
            name: index for index, name in enumerate(initial_state.logical_order)
        }
        for gate in program.circuit.gates:
            if gate.name == "i":
                continue
            amplitudes = _batched_gate_action(
                amplitudes,
                gate,
                qubit_index=qubit_index,
            )
        return _trajectory_state(
            initial_state,
            amplitudes=amplitudes,
            jump_counts=initial_state.jump_counts,
            logical_time=initial_state.logical_time,
            producer="BatchedTrajectoryKernel.digital",
            metadata={
                "program_hash": program.stable_hash(),
                "gate_count": len(program.circuit.gates),
            },
        )

    def evolve_analog(
        self,
        program: ProgramIR,
        initial_state: TrajectoryBatchState,
        *,
        dephasing_rate: float,
        dephasing_targets: tuple[str, ...] | None = None,
    ) -> TrajectoryBatchState:
        order = tuple(
            str(site.atom_id) for site in program.register.sites if site.is_active
        )
        if order != initial_state.logical_order:
            raise ProgramValidationError(
                "Analog program order does not match trajectory state order.",
                code="ANALOG_TRAJECTORY_LOGICAL_ORDER_MISMATCH",
                stage="simulation",
                object_path="simulation_state.logical_order",
            )
        if not math.isfinite(dephasing_rate) or dephasing_rate < 0.0:
            raise ValueError("dephasing_rate must be finite and non-negative.")
        target_names = order if dephasing_targets is None else dephasing_targets
        if len(set(target_names)) != len(target_names) or any(
            target not in order for target in target_names
        ):
            raise ValueError(
                "dephasing_targets must be unique members of logical_order."
            )
        target_axes = tuple(order.index(target) for target in target_names)
        duration = _duration(program)
        if duration == 0.0:
            return initial_state
        amplitudes = np.array(initial_state.amplitudes, copy=True)
        jump_counts = np.array(initial_state.jump_counts, copy=True)
        # A new substream per state transition prevents separate Analog blocks from
        # replaying identical jumps while remaining independent of worker scheduling.
        generators = [
            np.random.default_rng(
                derive_trajectory_seed(
                    int(seed),
                    initial_state.provenance.step_index,
                )
            )
            for seed in initial_state.trajectory_seeds
        ]
        dt = duration / self.steps
        for step in range(self.steps):
            # Two stochastic half channels mirror density Strang splitting.
            _apply_phase_jumps(
                amplitudes,
                jump_counts,
                generators,
                rate=dephasing_rate,
                duration=0.5 * dt,
                logical_sites=len(order),
                target_axes=target_axes,
            )
            hamiltonian, trace = _analog_linear_operator(
                program,
                time=(step + 0.5) * dt,
                dtype=amplitudes.dtype,
                blockade_radius=self.blockade_radius,
                basis_indices=None,
            )
            amplitudes = self._unitary_chunks(
                amplitudes,
                hamiltonian,
                trace=trace,
                dt=dt,
            )
            _apply_phase_jumps(
                amplitudes,
                jump_counts,
                generators,
                rate=dephasing_rate,
                duration=0.5 * dt,
                logical_sites=len(order),
                target_axes=target_axes,
            )
        return _trajectory_state(
            initial_state,
            amplitudes=amplitudes,
            jump_counts=jump_counts,
            logical_time=initial_state.logical_time + duration,
            producer="BatchedTrajectoryKernel.analog",
            metadata={
                "program_hash": program.stable_hash(),
                "algorithm": "chunked_strang_phase_jump",
                "steps": self.steps,
                "chunk_size": self.chunk_size,
                "workers": self.workers,
                "dephasing_rate": dephasing_rate,
                **site_addressing_provenance_metadata(
                    program,
                    consumer="BatchedTrajectoryKernel.analog",
                ),
                **site_phase_pattern_provenance_metadata(
                    program,
                    consumer="BatchedTrajectoryKernel.analog",
                ),
            },
        )

    def _unitary_chunks(
        self,
        amplitudes: ComplexArray,
        hamiltonian: LinearOperator,
        *,
        trace: complex,
        dt: float,
    ) -> ComplexArray:
        output = np.empty_like(amplitudes)
        scaled = LinearOperator(
            hamiltonian.shape,
            matvec=lambda vector: -1j * dt * hamiltonian.matvec(vector),
            matmat=lambda matrix: -1j * dt * hamiltonian.matmat(matrix),
            rmatvec=lambda vector: 1j * dt * hamiltonian.rmatvec(vector),
            rmatmat=lambda matrix: 1j * dt * hamiltonian.rmatmat(matrix),
            dtype=amplitudes.dtype,
        )
        ranges = tuple(
            (start, min(start + self.chunk_size, amplitudes.shape[0]))
            for start in range(0, amplitudes.shape[0], self.chunk_size)
        )

        def propagate(bounds: tuple[int, int]) -> tuple[int, int, ComplexArray]:
            start, stop = bounds
            block = np.asarray(
                expm_multiply(
                    scaled,
                    amplitudes[start:stop].T,
                    traceA=-1j * dt * trace,
                ).T,
                dtype=amplitudes.dtype,
            )
            norms = np.linalg.norm(block, axis=1)
            return start, stop, block / norms[:, np.newaxis]

        if self.workers == 1:
            propagated = map(propagate, ranges)
            for start, stop, block in propagated:
                output[start:stop] = block
            return output

        # Submit at most one chunk per worker so completed futures cannot retain an
        # unbounded number of Krylov workspaces. Results are committed by chunk order.
        with ThreadPoolExecutor(max_workers=self.workers) as executor:
            for batch_start in range(0, len(ranges), self.workers):
                batch = ranges[batch_start : batch_start + self.workers]
                for start, stop, block in executor.map(propagate, batch):
                    output[start:stop] = block
        return output


def run_trajectory_hybrid(
    bundle: LocalExecutionBundle,
    *,
    trajectories: int,
    seed: int,
    dtype: ArrayDType,
    steps: int,
    chunk_size: int,
    blockade_radius: float,
    dephasing_rate: float,
    workers: int = 1,
) -> TrajectoryBatchRun:
    """Run one prepared Hybrid bundle with every trajectory crossing every block."""
    validate_scalable_hybrid_bundle(bundle)
    measurement = cast(MeasurementStepPayload, bundle.payloads[-1])
    state = zero_trajectory_batch(
        measurement.logical_order,
        trajectories,
        seed=seed,
        dtype=dtype,
    )
    initial_state = state
    kernel = BatchedTrajectoryKernel(
        steps=steps,
        blockade_radius=blockade_radius,
        chunk_size=chunk_size,
        workers=workers,
    )
    input_hashes = trajectory_hashes(state)
    transitions: list[StateTransitionIR] = []
    for order_index, raw_payload in enumerate(bundle.payloads[:-1]):
        payload = cast(Union[DigitalStepPayload, AnalogStepPayload], raw_payload)
        input_state = state
        if isinstance(payload, DigitalStepPayload):
            state = kernel.evolve_digital(payload.program, state)
        else:
            state = kernel.evolve_analog(
                payload.program,
                state,
                dephasing_rate=dephasing_rate,
            )
        site_addressing = None
        site_phase_pattern = None
        if isinstance(payload, AnalogStepPayload):
            raw_addressing = state.provenance.metadata.get("site_addressing")
            if isinstance(raw_addressing, dict):
                site_addressing = raw_addressing
            raw_phase_pattern = state.provenance.metadata.get("site_phase_pattern")
            if isinstance(raw_phase_pattern, dict):
                site_phase_pattern = raw_phase_pattern
        output_hashes = trajectory_hashes(state)
        if isinstance(payload, AnalogStepPayload):
            solver_evidence = fixed_step_solver_evidence(
                integrator_requested="auto",
                steps=steps,
                duration=state.logical_time - input_state.logical_time,
                logical_time_offset=input_state.logical_time,
                time_unit=state.time_unit,
                algorithm="scipy.sparse.linalg.expm_multiply",
            )
            kernel_name = "BatchedTrajectoryKernel.analog"
        else:
            solver_evidence = not_applicable_solver_evidence(
                integrator_requested="auto",
                logical_time=state.logical_time,
                time_unit=state.time_unit,
                consumer="BatchedTrajectoryKernel.digital",
            )
            kernel_name = "BatchedTrajectoryKernel.digital"
        transition_metadata: dict[str, Any] = {
            "input_trajectory_hash_digest": _hash_strings(input_hashes),
            "output_trajectory_hash_digest": _hash_strings(output_hashes),
            "trajectory_count": len(output_hashes),
        }
        if site_addressing is not None:
            transition_metadata["site_addressing"] = site_addressing
        if site_phase_pattern is not None:
            transition_metadata["site_phase_pattern"] = site_phase_pattern
        transitions.append(
            build_state_transition(
                transition_id=f"transition.{order_index}.{payload.block_id}",
                order_index=order_index,
                block_id=payload.block_id,
                program_kind=cast(Any, payload.payload_kind),
                program_hash=payload.program.stable_hash(),
                kernel=kernel_name,
                input_state_hash=input_state.stable_hash(),
                output_state_hash=state.stable_hash(),
                input_logical_time=input_state.logical_time,
                output_logical_time=state.logical_time,
                time_unit=state.time_unit,
                solver_evidence=solver_evidence,
                metadata=transition_metadata,
            )
        )
        # Reuse the exact output tuple as the next input evidence.
        input_hashes = output_hashes
    return TrajectoryBatchRun(
        bundle=bundle,
        initial_state=initial_state,
        final_state=state,
        transitions=tuple(transitions),
        dephasing_rate=dephasing_rate,
        steps=steps,
        chunk_size=chunk_size,
        workers=workers,
        blockade_radius=blockade_radius,
    )


def build_trajectory_result(
    run: TrajectoryBatchRun,
    *,
    target_id: str = "local.trajectory_simulator",
    return_probabilities: bool = True,
) -> ResultIR:
    """Aggregate samples and a 95% confidence interval from final trajectories."""
    measurement = cast(MeasurementStepPayload, run.bundle.payloads[-1])
    state = run.final_state
    per_trajectory_probabilities = np.abs(state.amplitudes) ** 2
    probabilities_array = np.mean(per_trajectory_probabilities, axis=0)
    probabilities_array /= np.sum(probabilities_array)
    samples_index = np.random.default_rng(measurement.seed).choice(
        state.dimension,
        size=measurement.shots,
        p=probabilities_array,
    )
    width = len(state.logical_order)
    samples = tuple(format(int(index), f"0{width}b") for index in samples_index)
    counts = dict(Counter(samples))

    # The first-site excitation is evaluated per trajectory before aggregation.
    first_site_mask = np.arange(state.dimension) >= state.dimension // 2
    trajectory_observable = np.sum(
        per_trajectory_probabilities[:, first_site_mask],
        axis=1,
    )
    mean = float(np.mean(trajectory_observable))
    standard_error = float(
        np.std(trajectory_observable, ddof=1) / math.sqrt(state.trajectory_count)
    )
    confidence = (
        max(0.0, mean - 1.96 * standard_error),
        min(1.0, mean + 1.96 * standard_error),
    )
    component_evidence = tuple(
        SimulationSolverEvidenceIR.from_dict(transition.metadata["solver_evidence"])
        for transition in run.transitions
        if transition.program_kind == "analog"
    )
    solver_evidence = (
        aggregate_solver_evidence(
            component_evidence,
            integrator_requested="auto",
            integrator_selected="fixed_step_krylov",
            aggregation_scope="BatchedTrajectoryEngine",
        )
        if component_evidence
        else not_applicable_solver_evidence(
            integrator_requested="auto",
            consumer="BatchedTrajectoryEngine",
        )
    )
    references = build_runtime_references(
        program_hash=run.bundle.base_plan.program_hash,
        plan_hash=run.bundle.base_plan_hash,
        bundle_hash=run.bundle.stable_hash(),
        initial_state_hash=run.initial_state.stable_hash(),
        final_state_hash=state.stable_hash(),
        metadata={"graph_hash": run.bundle.base_plan.graph_hash},
    )
    trace = build_runtime_trace(
        trace_id=f"trace.{run.bundle.bundle_id}.trajectory",
        transitions=run.transitions,
        references=references,
        execution_mode="local_hybrid_trajectory",
        terminal_message="Terminal trajectory sampling completed.",
        terminal_metadata={
            "shots": measurement.shots,
            "seed": measurement.seed,
            "trajectory_count": state.trajectory_count,
        },
    )
    diagnostic = DiagnosticsIR(
        diagnostic_id="simulation.trajectory.hybrid.completed",
        stage="simulation",
        severity="info",
        code="TRAJECTORY_HYBRID_SIMULATION_COMPLETED",
        message="Batched physical dephasing trajectory simulation completed.",
        object_path="result",
        metadata={"trajectory_count": state.trajectory_count},
    )
    probabilities = None
    if return_probabilities:
        probabilities = {
            format(index, f"0{width}b"): float(value)
            for index, value in enumerate(probabilities_array)
        }
    return ResultIR(
        result_id=f"result.{run.bundle.bundle_id}.trajectory",
        program_hash=run.bundle.base_plan.program_hash,
        target_id=target_id,
        shots=measurement.shots,
        counts=counts,
        samples=samples,
        probabilities=probabilities,
        observables={
            "first_site_excitation_probability": mean,
            "first_site_excitation_standard_error": standard_error,
            "first_site_excitation_ci95_low": confidence[0],
            "first_site_excitation_ci95_high": confidence[1],
        },
        bit_ordering={
            "convention": "logical_order",
            "logical_order": ",".join(state.logical_order),
        },
        diagnostics=(diagnostic,),
        metadata={
            "seed": measurement.seed,
            **solver_evidence_metadata(solver_evidence),
            **runtime_lineage_metadata(
                transitions=run.transitions,
                references=references,
                trace=trace,
            ),
            "simulation_truthfulness": "physical_state_evolution",
            "simulator": {
                "name": "BatchedTrajectoryEngine",
                "method": "trajectory",
                "array_backend": "numpy.cpu",
            },
            "noise_report": {
                "channel": "dephasing",
                "rate": run.dephasing_rate,
                "injection_point": "analog_evolution",
                "unraveling": "exact_finite_interval_phase_flip",
                "non_hermitian_term": "scalar_identity_removed_by_normalization",
                "total_jump_count": int(np.sum(state.jump_counts)),
            },
            "trajectory_count": state.trajectory_count,
            "register_snapshots": collect_register_snapshot_evidence(
                payload.program
                for payload in run.bundle.payloads
                if isinstance(payload, AnalogStepPayload)
            ),
            "dtype": state.dtype,
            "steps": run.steps,
            "chunk_size": run.chunk_size,
            "workers": run.workers,
            "blockade_radius": run.blockade_radius,
            "trajectory_state": state.to_dict(),
            "state_hash": state.stable_hash(),
            "per_trajectory_hash_chain_continuous": all(
                left.metadata["output_trajectory_hash_digest"]
                == right.metadata["input_trajectory_hash_digest"]
                for left, right in zip(run.transitions, run.transitions[1:])
            ),
            "state_bytes_returned": False,
            "offline_deterministic": True,
            "network_accessed": False,
        },
    )


def _batched_gate_action(
    amplitudes: ComplexArray,
    gate: GateIR,
    *,
    qubit_index: dict[str, int],
) -> ComplexArray:
    targets = tuple(qubit_index[target] for target in gate.targets)
    matrix = _gate_matrix(gate, dtype=amplitudes.dtype)
    logical_sites = len(qubit_index)
    trajectory_count = amplitudes.shape[0]
    tensor = amplitudes.T.reshape((2,) * logical_sites + (trajectory_count,))
    front_axes = tuple(range(len(targets)))
    # Keeping trajectories last lets one local matrix action serve the whole batch.
    moved = np.moveaxis(tensor, targets, front_axes)
    updated = _local_matrix_action(matrix, moved.reshape(matrix.shape[1], -1))
    restored = np.moveaxis(
        updated.reshape((2,) * logical_sites + (trajectory_count,)),
        front_axes,
        targets,
    )
    return np.ascontiguousarray(restored.reshape(-1, trajectory_count).T)


def _apply_phase_jumps(
    amplitudes: ComplexArray,
    jump_counts: NDArray[np.integer[Any]],
    generators: list[np.random.Generator],
    *,
    rate: float,
    duration: float,
    logical_sites: int,
    target_axes: tuple[int, ...],
) -> None:
    if rate == 0.0 or duration == 0.0 or not target_axes:
        return
    # For L=sqrt(rate/2) Z, H_eff adds only -i*rate/4 times identity, which
    # disappears on trajectory normalization. Sampling odd jump parity with
    # this closed-form probability is therefore the exact finite-interval
    # dephasing unraveling, not a post-processing approximation.
    probability = 0.5 * (1.0 - math.exp(-rate * duration))
    basis = np.arange(amplitudes.shape[1], dtype=np.uint64)
    signs = tuple(
        np.where(
            ((basis >> (logical_sites - axis - 1)) & 1) == 0,
            1.0,
            -1.0,
        )
        for axis in target_axes
    )
    for trajectory_index, generator in enumerate(generators):
        jumped = np.flatnonzero(generator.random(len(target_axes)) < probability)
        for local_index in jumped:
            amplitudes[trajectory_index] *= signs[int(local_index)]
        jump_counts[trajectory_index] += jumped.size


def _trajectory_state(
    parent: TrajectoryBatchState,
    *,
    amplitudes: ComplexArray,
    jump_counts: NDArray[np.integer[Any]],
    logical_time: float,
    producer: str,
    metadata: dict[str, Any],
) -> TrajectoryBatchState:
    return TrajectoryBatchState(
        amplitudes=amplitudes,
        trajectory_seeds=parent.trajectory_seeds,
        jump_counts=jump_counts,
        occupations=parent.occupations,
        logical_order=parent.logical_order,
        basis=parent.basis,
        logical_time=logical_time,
        time_unit=parent.time_unit,
        noise_context=parent.noise_context,
        provenance=ArrayStateProvenance(
            producer=producer,
            parent_state_hash=parent.stable_hash(),
            step_index=parent.provenance.step_index + 1,
            metadata=metadata,
        ),
    )


def trajectory_hashes(state: TrajectoryBatchState) -> tuple[str, ...]:
    """Return deterministic content hashes for every trajectory in batch order."""
    hashes: list[str] = []
    for index, amplitudes in enumerate(state.amplitudes):
        digest = hashlib.sha256()
        digest.update(amplitudes.dtype.str.encode("ascii"))
        digest.update(amplitudes.tobytes(order="C"))
        digest.update(int(state.trajectory_seeds[index]).to_bytes(8, "big"))
        digest.update(int(state.jump_counts[index]).to_bytes(8, "big"))
        digest.update(state.occupations[index].tobytes(order="C"))
        hashes.append(digest.hexdigest())
    return tuple(hashes)


def apply_trajectory_pauli_channel(
    state: TrajectoryBatchState,
    *,
    probability: float,
    targets: tuple[str, ...],
    pauli: Literal["x", "z"],
    channel_id: str,
    correlated: bool = False,
    logical_time_advance: float = 0.0,
) -> TrajectoryBatchState:
    """Apply an independently seeded stochastic local or correlated Pauli map."""
    _validate_probability(probability)
    target_axes = _target_axes(state, targets)
    amplitudes = np.array(state.amplitudes, copy=True)
    generators = _channel_generators(state, channel_id)
    masks = tuple(1 << (len(state.logical_order) - axis - 1) for axis in target_axes)
    basis = np.arange(state.dimension, dtype=np.int64)
    permutations = tuple(basis ^ mask for mask in masks)
    signs = tuple(
        np.where((basis & mask) == 0, 1.0, -1.0).astype(amplitudes.dtype)
        for mask in masks
    )
    for trajectory_index, generator in enumerate(generators):
        selected = (
            np.repeat(generator.random() < probability, len(targets))
            if correlated
            else generator.random(len(targets)) < probability
        )
        for target_index in np.flatnonzero(selected):
            if pauli == "x":
                amplitudes[trajectory_index] = amplitudes[trajectory_index][
                    permutations[int(target_index)]
                ]
            else:
                amplitudes[trajectory_index] *= signs[int(target_index)]
    return _noise_trajectory_state(
        state,
        amplitudes=amplitudes,
        jump_counts=state.jump_counts,
        occupations=state.occupations,
        channel_id=channel_id,
        model=f"stochastic_{pauli}",
        metadata={
            "probability": probability,
            "correlated": correlated,
            "logical_time_advance": logical_time_advance,
        },
        logical_time_advance=logical_time_advance,
    )


def apply_trajectory_unitary_channel(
    state: TrajectoryBatchState,
    operator: ComplexArray,
    *,
    targets: tuple[str, ...],
    channel_id: str,
) -> TrajectoryBatchState:
    """Apply one local unitary to every trajectory without a global matrix."""
    target_axes = _target_axes(state, targets)
    local = np.asarray(operator, dtype=state.amplitudes.dtype)
    local_dimension = 2 ** len(targets)
    if local.shape != (local_dimension, local_dimension):
        raise ValueError("operator shape does not match targets.")
    if not np.allclose(
        np.conjugate(local.T) @ local,
        np.eye(local_dimension),
        rtol=0.0,
        atol=1e-10,
    ):
        raise ValueError("operator must be unitary.")
    trajectories = state.trajectory_count
    sites = len(state.logical_order)
    tensor = state.amplitudes.T.reshape((2,) * sites + (trajectories,))
    front_axes = tuple(range(len(target_axes)))
    moved = np.moveaxis(tensor, target_axes, front_axes)
    updated = _local_matrix_action(local, moved.reshape(local_dimension, -1))
    restored = np.moveaxis(
        updated.reshape((2,) * sites + (trajectories,)),
        front_axes,
        target_axes,
    )
    amplitudes = np.ascontiguousarray(restored.reshape(-1, trajectories).T)
    return _noise_trajectory_state(
        state,
        amplitudes=amplitudes,
        jump_counts=state.jump_counts,
        occupations=state.occupations,
        channel_id=channel_id,
        model="local_unitary",
        metadata={"target_count": len(targets)},
    )


def apply_trajectory_amplitude_damping(
    state: TrajectoryBatchState,
    *,
    probability: float,
    targets: tuple[str, ...],
    channel_id: str,
) -> TrajectoryBatchState:
    """Apply amplitude damping with state-dependent jump/no-jump sampling."""
    _validate_probability(probability)
    target_axes = _target_axes(state, targets)
    amplitudes = np.array(state.amplitudes, copy=True)
    jump_counts = np.array(state.jump_counts, copy=True)
    generators = _channel_generators(state, channel_id)
    basis = np.arange(state.dimension, dtype=np.int64)
    for axis in target_axes:
        mask = 1 << (len(state.logical_order) - axis - 1)
        excited = (basis & mask) != 0
        ground = ~excited
        for trajectory_index, generator in enumerate(generators):
            row = amplitudes[trajectory_index]
            excited_probability = float(np.sum(np.abs(row[excited]) ** 2))
            jump_probability = probability * excited_probability
            if generator.random() < jump_probability:
                # K1 maps each excited basis amplitude onto its ground partner.
                mapped = np.zeros_like(row)
                mapped[ground] = row[basis[ground] | mask] * math.sqrt(probability)
                amplitudes[trajectory_index] = mapped / math.sqrt(jump_probability)
                jump_counts[trajectory_index] += 1
            else:
                # K0 attenuates excited amplitudes and retains the no-jump branch.
                row[excited] *= math.sqrt(1.0 - probability)
                norm = math.sqrt(
                    max(1.0 - jump_probability, float(np.finfo(float).tiny))
                )
                amplitudes[trajectory_index] = row / norm
    return _noise_trajectory_state(
        state,
        amplitudes=amplitudes,
        jump_counts=jump_counts,
        occupations=state.occupations,
        channel_id=channel_id,
        model="amplitude_damping_jump",
        metadata={"probability": probability},
    )


def apply_trajectory_atom_loss(
    state: TrajectoryBatchState,
    *,
    probability: float,
    targets: tuple[str, ...],
    channel_id: str,
) -> TrajectoryBatchState:
    """Sample atom erasure and retain the lost-site fact in occupations."""
    _validate_probability(probability)
    target_axes = _target_axes(state, targets)
    amplitudes = np.array(state.amplitudes, copy=True)
    occupations = np.array(state.occupations, copy=True)
    jump_counts = np.array(state.jump_counts, copy=True)
    generators = _channel_generators(state, channel_id)
    basis = np.arange(state.dimension, dtype=np.int64)
    for axis in target_axes:
        mask = 1 << (len(state.logical_order) - axis - 1)
        ground = (basis & mask) == 0
        for trajectory_index, generator in enumerate(generators):
            if not occupations[trajectory_index, axis]:
                continue
            if generator.random() >= probability:
                continue
            row = amplitudes[trajectory_index]
            ground_probability = float(np.sum(np.abs(row[ground]) ** 2))
            choose_ground = generator.random() < ground_probability
            branch_probability = (
                ground_probability if choose_ground else 1.0 - ground_probability
            )
            mapped = np.zeros_like(row)
            if choose_ground:
                mapped[ground] = row[ground]
            else:
                # The erased atom leaves the Hilbert state; mapping the sampled
                # internal branch to |0> keeps a normalized conditional state while
                # occupations carries the physical vacuum/erasure distinction.
                mapped[ground] = row[basis[ground] | mask]
            amplitudes[trajectory_index] = mapped / math.sqrt(
                max(branch_probability, float(np.finfo(float).tiny))
            )
            occupations[trajectory_index, axis] = False
            jump_counts[trajectory_index] += 1
    return _noise_trajectory_state(
        state,
        amplitudes=amplitudes,
        jump_counts=jump_counts,
        occupations=occupations,
        channel_id=channel_id,
        model="occupation_erasure_jump",
        metadata={"probability": probability},
    )


def _noise_trajectory_state(
    parent: TrajectoryBatchState,
    *,
    amplitudes: ComplexArray,
    jump_counts: NDArray[np.integer[Any]],
    occupations: NDArray[np.bool_],
    channel_id: str,
    model: str,
    metadata: dict[str, Any],
    logical_time_advance: float = 0.0,
) -> TrajectoryBatchState:
    return TrajectoryBatchState(
        amplitudes=amplitudes,
        trajectory_seeds=parent.trajectory_seeds,
        jump_counts=jump_counts,
        occupations=occupations,
        logical_order=parent.logical_order,
        basis=parent.basis,
        logical_time=parent.logical_time + logical_time_advance,
        time_unit=parent.time_unit,
        noise_context=parent.noise_context,
        provenance=ArrayStateProvenance(
            producer="BatchedTrajectoryKernel.noise",
            parent_state_hash=parent.stable_hash(),
            step_index=parent.provenance.step_index + 1,
            metadata={"channel_id": channel_id, "model": model, **metadata},
        ),
    )


def _channel_generators(
    state: TrajectoryBatchState,
    channel_id: str,
) -> list[np.random.Generator]:
    digest = hashlib.sha256(channel_id.encode("utf-8")).digest()
    salt = int.from_bytes(digest[:8], "big")
    stream = salt ^ state.provenance.step_index
    return [
        np.random.default_rng(derive_trajectory_seed(int(seed), stream))
        for seed in state.trajectory_seeds
    ]


def _target_axes(
    state: TrajectoryBatchState,
    targets: tuple[str, ...],
) -> tuple[int, ...]:
    if not targets or len(set(targets)) != len(targets):
        raise ValueError("targets must be non-empty and unique.")
    if any(target not in state.logical_order for target in targets):
        raise ValueError("targets must be members of logical_order.")
    return tuple(state.logical_order.index(target) for target in targets)


def _validate_probability(probability: float) -> None:
    if not math.isfinite(probability) or not 0.0 <= probability <= 1.0:
        raise ValueError("probability must be finite and within [0, 1].")


def _hash_strings(values: tuple[str, ...]) -> str:
    digest = hashlib.sha256()
    for value in values:
        digest.update(value.encode("ascii"))
    return digest.hexdigest()
