"""Exact density-matrix reference kernels for Digital and Analog programs."""

from __future__ import annotations

import math
from collections.abc import Iterable
from dataclasses import dataclass, replace

import numpy as np
from numpy.typing import NDArray
from scipy.sparse.linalg import (  # type: ignore[import-untyped]
    LinearOperator,
    expm_multiply,
)

from cascaqit.digital import DigitalProgramIR
from cascaqit.exceptions import ProgramValidationError
from cascaqit.native_ir import ProgramIR
from cascaqit.simulators.adaptive import (
    fixed_step_solver_evidence,
    integrate_dop853_segments,
)
from cascaqit.simulators.addressing import site_addressing_provenance_metadata
from cascaqit.simulators.analog_timing import analog_control_boundaries
from cascaqit.simulators.array_state import (
    ArrayStateProvenance,
    DensityMatrixState,
)
from cascaqit.simulators.ideal import (
    ArrayDType,
    ComplexArray,
    _analog_linear_operator,
    _duration,
    _gate_matrix,
    _local_matrix_action,
)
from cascaqit.simulators.local_rabi import site_phase_pattern_provenance_metadata
from cascaqit.simulators.planning import (
    SelectedSimulationIntegrator,
    SimulationIntegrator,
)

__all__ = [
    "ExactDensityMatrixKernel",
    "apply_density_kraus_channel",
    "zero_density_matrix",
]


def zero_density_matrix(
    logical_order: tuple[str, ...],
    *,
    dtype: ArrayDType = "complex128",
) -> DensityMatrixState:
    """Return the computational all-zero density matrix."""
    if not logical_order:
        raise ValueError("logical_order must not be empty.")
    dimension = 2 ** len(logical_order)
    rho = np.zeros((dimension, dimension), dtype=np.dtype(dtype))
    rho[0, 0] = 1.0
    return DensityMatrixState(
        rho=rho,
        logical_order=logical_order,
        provenance=ArrayStateProvenance.initial("zero_density_matrix"),
    )


def apply_density_kraus_channel(
    state: DensityMatrixState,
    kraus_operators: Iterable[ComplexArray],
    *,
    targets: tuple[str, ...],
    channel_id: str = "density.kraus",
) -> DensityMatrixState:
    """Apply one local CPTP Kraus map and preserve explicit state lineage."""
    if not isinstance(state, DensityMatrixState):
        raise TypeError("state must be DensityMatrixState.")
    operators = tuple(
        np.asarray(item, dtype=state.rho.dtype) for item in kraus_operators
    )
    if not operators:
        raise ValueError("kraus_operators must not be empty.")
    if not targets or any(target not in state.logical_order for target in targets):
        raise ValueError("targets must be non-empty members of logical_order.")
    local_dimension = 2 ** len(targets)
    if any(item.shape != (local_dimension, local_dimension) for item in operators):
        raise ValueError("Kraus operator shape does not match targets.")
    completeness = sum(
        np.conjugate(operator.T) @ operator for operator in operators
    )
    if not np.allclose(
        completeness,
        np.eye(local_dimension),
        rtol=0.0,
        atol=1e-10,
    ):
        raise ValueError("kraus_operators must satisfy sum(K^dagger K) = I.")
    target_axes = tuple(state.logical_order.index(target) for target in targets)
    evolved = np.zeros_like(state.rho)
    # Each term is applied locally on ket and bra axes; no global Kraus matrix exists.
    for operator in operators:
        evolved += _local_density_action(
            state.rho,
            operator,
            target_axes=target_axes,
            logical_sites=len(state.logical_order),
        )
    evolved = _stabilize_density(evolved)
    return DensityMatrixState(
        rho=evolved,
        logical_order=state.logical_order,
        basis=state.basis,
        logical_time=state.logical_time,
        time_unit=state.time_unit,
        noise_context=state.noise_context,
        provenance=ArrayStateProvenance(
            producer="ExactDensityMatrixKernel.kraus",
            parent_state_hash=state.stable_hash(),
            step_index=state.provenance.step_index + 1,
            metadata={
                "channel_id": channel_id,
                "target_count": len(targets),
                "kraus_count": len(operators),
            },
        ),
    )


@dataclass(frozen=True)
class ExactDensityMatrixKernel:
    """Small-scale exact Kraus/Lindblad reference over immutable density states."""

    steps: int = 32
    blockade_radius: float = 0.0
    integrator_requested: SimulationIntegrator = "fixed_step_krylov"
    integrator_selected: SelectedSimulationIntegrator = "fixed_step_krylov"
    rtol: float = 1e-9
    atol: float = 1e-11
    max_steps: int = 10_000

    def __post_init__(self) -> None:
        if (
            not isinstance(self.steps, int)
            or isinstance(self.steps, bool)
            or self.steps <= 0
        ):
            raise ValueError("steps must be a positive integer.")
        if not math.isfinite(self.blockade_radius) or self.blockade_radius < 0.0:
            raise ValueError("blockade_radius must be finite and non-negative.")
        if self.integrator_requested not in {
            "auto",
            "adaptive_dop853",
            "fixed_step_krylov",
        }:
            raise ValueError("integrator_requested is unsupported.")
        if self.integrator_selected not in {
            "adaptive_dop853",
            "fixed_step_krylov",
        }:
            raise ValueError("Density evolution requires a selected integrator.")
        if (
            self.integrator_requested != "auto"
            and self.integrator_requested != self.integrator_selected
        ):
            raise ValueError("Explicit integrator request cannot be changed silently.")
        for value, field_name in ((self.rtol, "rtol"), (self.atol, "atol")):
            if not math.isfinite(value) or value <= 0.0:
                raise ValueError(f"{field_name} must be finite and positive.")
        if (
            not isinstance(self.max_steps, int)
            or isinstance(self.max_steps, bool)
            or self.max_steps <= 0
        ):
            raise ValueError("max_steps must be a positive integer.")

    def evolve_digital(
        self,
        program: DigitalProgramIR,
        initial_state: DensityMatrixState,
        *,
        dephasing_rate: float = 0.0,
        dephasing_duration: float = 0.0,
        dephasing_targets: tuple[str, ...] | None = None,
    ) -> DensityMatrixState:
        """Apply Digital unitaries and an optional exact dephasing channel."""
        if not isinstance(program, DigitalProgramIR):
            raise TypeError("program must be DigitalProgramIR.")
        if not isinstance(initial_state, DensityMatrixState):
            raise TypeError("initial_state must be DensityMatrixState.")
        order = tuple(program.circuit.qubits)
        if order != initial_state.logical_order:
            raise ProgramValidationError(
                "Digital program order does not match density state order.",
                code="DIGITAL_DENSITY_LOGICAL_ORDER_MISMATCH",
                stage="simulation",
                object_path="simulation_state.logical_order",
            )
        rho = np.array(initial_state.rho, copy=True)
        qubit_index = {name: index for index, name in enumerate(order)}
        for gate in program.circuit.gates:
            if gate.name == "i":
                continue
            rho = _local_density_action(
                rho,
                _gate_matrix(gate, dtype=rho.dtype),
                target_axes=tuple(qubit_index[target] for target in gate.targets),
                logical_sites=len(order),
            )
        targets = order if dephasing_targets is None else dephasing_targets
        rho = _apply_dephasing(
            rho,
            rate=dephasing_rate,
            duration=dephasing_duration,
            target_axes=tuple(qubit_index[target] for target in targets),
            logical_sites=len(order),
        )
        rho = _stabilize_density(rho)
        return DensityMatrixState(
            rho=rho,
            logical_order=order,
            basis=initial_state.basis,
            logical_time=initial_state.logical_time + dephasing_duration,
            time_unit=initial_state.time_unit,
            noise_context=initial_state.noise_context,
            provenance=ArrayStateProvenance(
                producer="ExactDensityMatrixKernel.digital",
                parent_state_hash=initial_state.stable_hash(),
                step_index=initial_state.provenance.step_index + 1,
                metadata={
                    "program_hash": program.stable_hash(),
                    "gate_count": len(program.circuit.gates),
                    "dephasing_rate": dephasing_rate,
                    "dephasing_duration": dephasing_duration,
                },
            ),
        )

    def evolve_analog(
        self,
        program: ProgramIR,
        initial_state: DensityMatrixState,
        *,
        dephasing_rate: float = 0.0,
        dephasing_targets: tuple[str, ...] | None = None,
    ) -> DensityMatrixState:
        """Integrate a matrix-free Analog Lindblad reference with Strang splitting."""
        if not isinstance(program, ProgramIR):
            raise TypeError("program must be ProgramIR.")
        if not isinstance(initial_state, DensityMatrixState):
            raise TypeError("initial_state must be DensityMatrixState.")
        order = tuple(
            str(site.atom_id) for site in program.register.sites if site.is_active
        )
        if order != initial_state.logical_order:
            raise ProgramValidationError(
                "Analog program order does not match density state order.",
                code="ANALOG_DENSITY_LOGICAL_ORDER_MISMATCH",
                stage="simulation",
                object_path="simulation_state.logical_order",
            )
        duration = _duration(program)
        if duration == 0.0:
            return initial_state
        _validate_rate_duration(dephasing_rate, duration)
        target_names = order if dephasing_targets is None else dephasing_targets
        if len(set(target_names)) != len(target_names) or any(
            target not in order for target in target_names
        ):
            raise ValueError(
                "dephasing_targets must be unique members of logical_order."
            )
        target_axes = tuple(order.index(target) for target in target_names)
        rho = np.array(initial_state.rho, copy=True)
        if self.integrator_selected == "adaptive_dop853":
            differences = _dephasing_difference_counts(
                logical_sites=len(order),
                target_axes=target_axes,
            )

            def rhs(time: float, values: ComplexArray) -> ComplexArray:
                matrix = np.asarray(values).reshape(rho.shape)
                derivative = _density_lindblad_rhs(
                    program,
                    matrix,
                    time=time,
                    dephasing_rate=dephasing_rate,
                    dephasing_differences=differences,
                    blockade_radius=self.blockade_radius,
                )
                return np.asarray(derivative.reshape(-1))

            integration = integrate_dop853_segments(
                rhs,
                np.asarray(rho.reshape(-1)),
                boundaries=analog_control_boundaries(program),
                integrator_requested=self.integrator_requested,
                rtol=self.rtol,
                atol=self.atol,
                max_steps=self.max_steps,
                logical_time_offset=initial_state.logical_time,
            )
            rho = np.asarray(
                integration.values.reshape(rho.shape),
                dtype=initial_state.rho.dtype,
            )
            evidence = integration.evidence
        else:
            dt = duration / self.steps
            for step in range(self.steps):
                # Symmetric splitting keeps each dephasing half-step CPTP.
                rho = _apply_dephasing(
                    rho,
                    rate=dephasing_rate,
                    duration=0.5 * dt,
                    target_axes=target_axes,
                    logical_sites=len(order),
                )
                hamiltonian, trace = _analog_linear_operator(
                    program,
                    time=(step + 0.5) * dt,
                    dtype=rho.dtype,
                    blockade_radius=self.blockade_radius,
                    basis_indices=None,
                )
                rho = _unitary_density_step(rho, hamiltonian, trace=trace, dt=dt)
                rho = _apply_dephasing(
                    rho,
                    rate=dephasing_rate,
                    duration=0.5 * dt,
                    target_axes=target_axes,
                    logical_sites=len(order),
                )
            evidence = fixed_step_solver_evidence(
                integrator_requested=self.integrator_requested,
                steps=self.steps,
                duration=duration,
                logical_time_offset=initial_state.logical_time,
                time_unit="us",
                algorithm="strang_krylov_lindblad",
            )
        trace_before = complex(np.trace(rho))
        hermiticity_error = float(np.max(np.abs(rho - np.conjugate(rho.T))))
        minimum_eigenvalue = _minimum_density_eigenvalue(rho)
        rho = _stabilize_density(rho)
        evidence = replace(
            evidence,
            metadata={
                **evidence.metadata,
                "trace_before_stabilization": {
                    "real": float(trace_before.real),
                    "imag": float(trace_before.imag),
                },
                "hermiticity_error_before_stabilization": hermiticity_error,
                "minimum_eigenvalue_before_stabilization": minimum_eigenvalue,
                "positivity_evidence_available": minimum_eigenvalue is not None,
                "stabilization_applied": True,
                "output_dtype": str(rho.dtype),
            },
        )
        return DensityMatrixState(
            rho=rho,
            logical_order=order,
            basis=initial_state.basis,
            logical_time=initial_state.logical_time + duration,
            time_unit=initial_state.time_unit,
            noise_context=initial_state.noise_context,
            provenance=ArrayStateProvenance(
                producer="ExactDensityMatrixKernel.analog",
                parent_state_hash=initial_state.stable_hash(),
                step_index=initial_state.provenance.step_index + 1,
                metadata={
                    "program_hash": program.stable_hash(),
                    "algorithm": (
                        "adaptive_dop853_lindblad"
                        if evidence.integrator_selected == "adaptive_dop853"
                        else "strang_krylov_lindblad"
                    ),
                    "integrator_selected": evidence.integrator_selected,
                    "steps": evidence.accepted_steps,
                    "dephasing_rate": dephasing_rate,
                    "solver_evidence": evidence.to_dict(),
                    "solver_evidence_hash": evidence.stable_hash(),
                    **site_addressing_provenance_metadata(
                        program,
                        consumer="ExactDensityMatrixKernel.analog",
                    ),
                    **site_phase_pattern_provenance_metadata(
                        program,
                        consumer="ExactDensityMatrixKernel.analog",
                    ),
                },
            ),
        )


def _local_density_action(
    rho: ComplexArray,
    operator: ComplexArray,
    *,
    target_axes: tuple[int, ...],
    logical_sites: int,
) -> ComplexArray:
    # After transpose, right multiplication by K^dagger is a left K* action.
    left = _left_local_action(
        rho,
        operator,
        target_axes=target_axes,
        logical_sites=logical_sites,
    )
    right_transpose = _left_local_action(
        left.T,
        np.conjugate(operator),
        target_axes=target_axes,
        logical_sites=logical_sites,
    )
    return np.ascontiguousarray(right_transpose.T)


def _left_local_action(
    values: ComplexArray,
    operator: ComplexArray,
    *,
    target_axes: tuple[int, ...],
    logical_sites: int,
) -> ComplexArray:
    dimension = 2**logical_sites
    tensor = values.reshape((2,) * logical_sites + (dimension,))
    front_axes = tuple(range(len(target_axes)))
    moved = np.moveaxis(tensor, target_axes, front_axes)
    updated = _local_matrix_action(
        operator,
        moved.reshape(operator.shape[1], -1),
    )
    restored = np.moveaxis(
        updated.reshape((2,) * logical_sites + (dimension,)),
        front_axes,
        target_axes,
    )
    return np.ascontiguousarray(restored.reshape(dimension, dimension))


def _apply_dephasing(
    rho: ComplexArray,
    *,
    rate: float,
    duration: float,
    target_axes: tuple[int, ...],
    logical_sites: int,
) -> ComplexArray:
    _validate_rate_duration(rate, duration)
    if rate == 0.0 or duration == 0.0 or not target_axes:
        return np.array(rho, copy=True)
    differences = _dephasing_difference_counts(
        logical_sites=logical_sites,
        target_axes=target_axes,
    )
    damping = np.exp(-rate * duration * differences)
    return np.asarray(rho * damping, dtype=rho.dtype)


def _dephasing_difference_counts(
    *,
    logical_sites: int,
    target_axes: tuple[int, ...],
) -> NDArray[np.uint8]:
    dimension = 2**logical_sites
    indices = np.arange(dimension, dtype=np.uint64)
    xor = np.bitwise_xor(indices[:, np.newaxis], indices[np.newaxis, :])
    differences = np.zeros((dimension, dimension), dtype=np.uint8)
    # Independent Z dephasing damps once per target bit that differs on bra and ket.
    for axis in target_axes:
        differences += ((xor >> (logical_sites - axis - 1)) & 1).astype(np.uint8)
    return differences


def _density_lindblad_rhs(
    program: ProgramIR,
    rho: ComplexArray,
    *,
    time: float,
    dephasing_rate: float,
    dephasing_differences: NDArray[np.uint8],
    blockade_radius: float,
) -> ComplexArray:
    hamiltonian, _ = _analog_linear_operator(
        program,
        time=time,
        dtype=rho.dtype,
        blockade_radius=blockade_radius,
        basis_indices=None,
    )
    left = np.asarray(hamiltonian.matmat(rho))
    # (H rho^dagger)^dagger = rho H for the Hermitian Analog Hamiltonian.
    right = np.conjugate(
        np.asarray(hamiltonian.matmat(np.conjugate(rho.T))).T
    )
    derivative = -1j * (left - right)
    if dephasing_rate != 0.0:
        derivative -= dephasing_rate * dephasing_differences * rho
    return np.asarray(derivative, dtype=rho.dtype)


def _unitary_density_step(
    rho: ComplexArray,
    hamiltonian: LinearOperator,
    *,
    trace: complex,
    dt: float,
) -> ComplexArray:
    scaled = LinearOperator(
        hamiltonian.shape,
        matvec=lambda vector: -1j * dt * hamiltonian.matvec(vector),
        matmat=lambda matrix: -1j * dt * hamiltonian.matmat(matrix),
        rmatvec=lambda vector: 1j * dt * hamiltonian.rmatvec(vector),
        dtype=rho.dtype,
    )
    left = np.asarray(
        expm_multiply(scaled, rho, traceA=-1j * dt * trace),
        dtype=rho.dtype,
    )
    # Transposing rho turns the right U^dagger action into a left U* action.
    conjugate_hamiltonian = LinearOperator(
        hamiltonian.shape,
        matvec=lambda vector: np.conjugate(
            hamiltonian.matvec(np.conjugate(vector))
        ),
        matmat=lambda matrix: np.conjugate(
            hamiltonian.matmat(np.conjugate(matrix))
        ),
        rmatvec=lambda vector: np.conjugate(
            hamiltonian.rmatvec(np.conjugate(vector))
        ),
        dtype=rho.dtype,
    )
    scaled_conjugate = LinearOperator(
        conjugate_hamiltonian.shape,
        matvec=lambda vector: 1j * dt * conjugate_hamiltonian.matvec(vector),
        matmat=lambda matrix: 1j * dt * conjugate_hamiltonian.matmat(matrix),
        rmatvec=lambda vector: -1j * dt * conjugate_hamiltonian.rmatvec(vector),
        dtype=rho.dtype,
    )
    return np.asarray(
        expm_multiply(
            scaled_conjugate,
            left.T,
            traceA=1j * dt * np.conjugate(trace),
        ).T,
        dtype=rho.dtype,
    )


def _validate_rate_duration(rate: float, duration: float) -> None:
    if not math.isfinite(rate) or rate < 0.0:
        raise ValueError("dephasing rate must be finite and non-negative.")
    if not math.isfinite(duration) or duration < 0.0:
        raise ValueError("duration must be finite and non-negative.")


def _minimum_density_eigenvalue(rho: ComplexArray) -> float | None:
    # Cubic eigendecomposition is useful for small reference cases but would
    # dominate the larger density workload that the planner already budgeted.
    if rho.shape[0] > 64:
        return None
    hermitian = 0.5 * (rho + np.conjugate(rho.T))
    return float(np.min(np.linalg.eigvalsh(hermitian)).real)


def _stabilize_density(rho: ComplexArray) -> ComplexArray:
    hermitian = 0.5 * (rho + np.conjugate(rho.T))
    trace = float(np.trace(hermitian).real)
    if trace <= 0.0 or not math.isfinite(trace):
        raise ProgramValidationError(
            "Density evolution produced an invalid trace.",
            code="DENSITY_TRACE_INVALID",
            stage="simulation",
            object_path="density_state.rho",
            metadata={"trace": trace},
        )
    return np.asarray(hermitian / trace, dtype=rho.dtype)
