"""Shared sampling and provenance for site-patterned local Rabi drives."""

from __future__ import annotations

from typing import Any

from cascaqit.native_ir import ProgramIR, WaveformIR
from cascaqit.simulators.waveform_sampling import sample_waveform

LocalRabiFieldSample = tuple[
    float,
    tuple[float, ...],
    tuple[float, ...],
]


def sample_local_rabi_fields(
    program: ProgramIR,
    time: float,
) -> tuple[LocalRabiFieldSample, ...]:
    """Sample amplitude, per-site phase, and addressing in register order."""
    fields: list[LocalRabiFieldSample] = []
    for term in program.hamiltonian.local_rabi_terms:
        shared_phase = (
            sample_waveform(term.phase, time)
            if isinstance(term.phase, WaveformIR)
            else float(term.phase)
        )
        fields.append(
            (
                sample_waveform(term.rabi, time),
                tuple(
                    shared_phase + offset
                    for offset in term.phase_pattern.offsets
                ),
                term.addressing.weights_at(time),
            )
        )
    return tuple(fields)


def site_phase_pattern_provenance_metadata(
    program: ProgramIR,
    *,
    consumer: str,
) -> dict[str, Any]:
    """Return runtime evidence when at least one site offset is non-zero."""
    terms = tuple(program.hamiltonian.local_rabi_terms)
    if not any(
        any(offset != 0.0 for offset in term.phase_pattern.offsets)
        for term in terms
    ):
        return {}
    return {
        "site_phase_pattern": {
            "consumer": consumer,
            "program_hash": program.stable_hash(),
            "semantics": "site_phase=shared_phase+phase_offset",
            "terms": [
                {
                    "term_index": index,
                    "phase_pattern_hash": term.phase_pattern.stable_hash(),
                    "site_ids": list(term.phase_pattern.site_ids),
                    "offsets": list(term.phase_pattern.offsets),
                    "unit": term.phase_pattern.unit,
                }
                for index, term in enumerate(terms)
            ],
        }
    }
