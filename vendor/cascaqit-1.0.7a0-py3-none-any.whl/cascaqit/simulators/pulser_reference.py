"""Optional Pulser reference-simulation contracts and dependency boundary."""

from __future__ import annotations

import importlib.util
import json
import math
from dataclasses import dataclass, field
from hashlib import sha256
from importlib import import_module
from importlib.metadata import PackageNotFoundError, version
from typing import Any, Literal, NoReturn

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.exceptions import CapabilityError
from cascaqit.native_ir.base import IRMixin
from cascaqit.native_ir.models import (
    ANALOG_BIT_ORDER_CONVENTION,
    SCHEMA_VERSION,
    ProgramIR,
    WaveformIR,
)
from cascaqit.results import ResultIR

__all__ = [
    "PulserProjectionIR",
    "PulserReferenceAdapter",
    "PulserReferenceCapabilityIR",
    "PulserReferenceComparisonIR",
    "PulserReferenceError",
    "PulserReferenceRunIR",
    "compare_pulser_reference",
    "probe_pulser_reference",
]

PulserReferenceStatus = Literal["available", "unavailable", "unsupported"]

_CORE_PACKAGE = "pulser-core"
_SIMULATION_PACKAGE = "pulser-simulation"
_CORE_MODULE = "pulser"
_SIMULATION_MODULE = "pulser_simulation"
_SUPPORTED_MAJOR = 1
_DEFAULT_THRESHOLDS = {
    "minimum_state_fidelity": 1.0 - 1e-6,
    "maximum_probability_error": 1e-4,
    "maximum_z_error": 1e-4,
}


class PulserReferenceError(CapabilityError):
    """Pulser reference dependency, capability, or execution boundary error."""

    default_code = "PULSER_REFERENCE_ERROR"
    default_stage = "simulation"


@dataclass(frozen=True)
class PulserReferenceCapabilityIR(IRMixin):
    """Dependency and execution readiness for the optional Pulser adapter."""

    capability_id: str
    status: PulserReferenceStatus
    dependency_available: bool
    actual_execution_available: bool
    package_versions: dict[str, str] = field(default_factory=dict)
    supported_features: tuple[str, ...] = ()
    diagnostics: tuple[DiagnosticsIR, ...] = ()
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Reject readiness combinations that could overstate execution."""
        if self.status not in ("available", "unavailable", "unsupported"):
            raise ValueError(f"Unsupported Pulser reference status: {self.status}")
        if self.actual_execution_available and not self.dependency_available:
            raise ValueError("Actual execution requires available Pulser dependencies.")
        if self.actual_execution_available and self.status != "available":
            raise ValueError("Actual execution requires available capability status.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PulserReferenceCapabilityIR:
        """Build capability evidence from a JSON-compatible dictionary."""
        return cls(
            capability_id=str(data["capability_id"]),
            status=data["status"],
            dependency_available=bool(data["dependency_available"]),
            actual_execution_available=bool(data["actual_execution_available"]),
            package_versions={
                str(key): str(value)
                for key, value in data.get("package_versions", {}).items()
            },
            supported_features=tuple(
                str(item) for item in data.get("supported_features", ())
            ),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(item) for item in data.get("diagnostics", ())
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> PulserReferenceCapabilityIR:
        """Build capability evidence from JSON."""
        return cls.from_dict(_json_object(text, "capability"))


@dataclass(frozen=True)
class PulserProjectionIR(IRMixin):
    """Pure CASCAQit provenance for a native-to-Pulser projection."""

    projection_id: str
    program_id: str
    program_hash: str
    atom_order: tuple[str, ...]
    basis_mapping: dict[str, str]
    unit_mapping: dict[str, str]
    waveform_kinds: tuple[str, ...]
    sequence_spec: dict[str, Any]
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PulserProjectionIR:
        """Build projection provenance from a JSON-compatible dictionary."""
        return cls(
            projection_id=str(data["projection_id"]),
            program_id=str(data["program_id"]),
            program_hash=str(data["program_hash"]),
            atom_order=tuple(str(item) for item in data.get("atom_order", ())),
            basis_mapping={
                str(key): str(value)
                for key, value in data.get("basis_mapping", {}).items()
            },
            unit_mapping={
                str(key): str(value)
                for key, value in data.get("unit_mapping", {}).items()
            },
            waveform_kinds=tuple(str(item) for item in data.get("waveform_kinds", ())),
            sequence_spec=dict(data.get("sequence_spec", {})),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> PulserProjectionIR:
        """Build projection provenance from JSON."""
        return cls.from_dict(_json_object(text, "projection"))


@dataclass(frozen=True)
class PulserReferenceRunIR(IRMixin):
    """Normalized evidence for one optional Pulser reference run."""

    run_id: str
    projection: PulserProjectionIR
    actual_execution: bool
    result: ResultIR | None = None
    statevector: tuple[tuple[float, float], ...] = ()
    package_versions: dict[str, str] = field(default_factory=dict)
    solver_configuration: dict[str, Any] = field(default_factory=dict)
    diagnostics: tuple[DiagnosticsIR, ...] = ()
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Prevent fixtures or empty results from claiming real execution."""
        if self.actual_execution and self.result is None:
            raise ValueError("Actual Pulser execution requires a normalized result.")
        if self.actual_execution and not self.package_versions:
            raise ValueError("Actual Pulser execution requires package versions.")
        if self.actual_execution and len(self.statevector) != 2:
            raise ValueError("Actual 1-site Pulser execution requires two amplitudes.")
        if not self.actual_execution and self.result is not None:
            raise ValueError("A normalized result requires actual Pulser execution.")
        if not self.actual_execution and self.statevector:
            raise ValueError("A statevector requires actual Pulser execution.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PulserReferenceRunIR:
        """Build run evidence from a JSON-compatible dictionary."""
        result = data.get("result")
        return cls(
            run_id=str(data["run_id"]),
            projection=PulserProjectionIR.from_dict(data["projection"]),
            actual_execution=bool(data["actual_execution"]),
            result=None if result is None else ResultIR.from_dict(result),
            statevector=tuple(
                (float(item[0]), float(item[1])) for item in data.get("statevector", ())
            ),
            package_versions={
                str(key): str(value)
                for key, value in data.get("package_versions", {}).items()
            },
            solver_configuration=dict(data.get("solver_configuration", {})),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(item) for item in data.get("diagnostics", ())
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> PulserReferenceRunIR:
        """Build run evidence from JSON."""
        return cls.from_dict(_json_object(text, "reference run"))


@dataclass(frozen=True)
class PulserReferenceComparisonIR(IRMixin):
    """Typed numerical comparison between native and Pulser results."""

    comparison_id: str
    native_result_hash: str
    reference_run_hash: str
    actual_reference_execution: bool
    passed: bool
    metrics: dict[str, float] = field(default_factory=dict)
    thresholds: dict[str, float] = field(default_factory=dict)
    diagnostics: tuple[DiagnosticsIR, ...] = ()
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """A comparison cannot pass without real reference execution."""
        if self.passed and not self.actual_reference_execution:
            raise ValueError(
                "A passing comparison requires actual reference execution."
            )
        if self.passed and not self.metrics:
            raise ValueError("A passing comparison requires numerical metrics.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PulserReferenceComparisonIR:
        """Build comparison evidence from a JSON-compatible dictionary."""
        return cls(
            comparison_id=str(data["comparison_id"]),
            native_result_hash=str(data["native_result_hash"]),
            reference_run_hash=str(data["reference_run_hash"]),
            actual_reference_execution=bool(data["actual_reference_execution"]),
            passed=bool(data["passed"]),
            metrics={
                str(key): float(value) for key, value in data.get("metrics", {}).items()
            },
            thresholds={
                str(key): float(value)
                for key, value in data.get("thresholds", {}).items()
            },
            diagnostics=tuple(
                DiagnosticsIR.from_dict(item) for item in data.get("diagnostics", ())
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> PulserReferenceComparisonIR:
        """Build comparison evidence from JSON."""
        return cls.from_dict(_json_object(text, "comparison"))


def probe_pulser_reference() -> PulserReferenceCapabilityIR:
    """Inspect optional Pulser packages without importing or executing them."""
    versions, missing = _dependency_versions()
    if missing:
        return PulserReferenceCapabilityIR(
            capability_id="pulser.reference.dependencies",
            status="unavailable",
            dependency_available=False,
            actual_execution_available=False,
            package_versions=versions,
            diagnostics=(
                _diagnostic(
                    "PULSER_REFERENCE_DEPENDENCY_UNAVAILABLE",
                    "Pulser reference dependencies are not installed.",
                    suggestion=(
                        "Install the reference-pulser extra in an isolated "
                        "environment before running reference validation."
                    ),
                    metadata={"missing": missing},
                ),
            ),
            metadata={"network_accessed": False, "packages_imported": False},
        )
    incompatible = {
        package: package_version
        for package, package_version in versions.items()
        if _major_version(package_version) != _SUPPORTED_MAJOR
    }
    if incompatible:
        return PulserReferenceCapabilityIR(
            capability_id="pulser.reference.dependencies",
            status="unsupported",
            dependency_available=True,
            actual_execution_available=False,
            package_versions=versions,
            diagnostics=(
                _diagnostic(
                    "PULSER_REFERENCE_VERSION_UNSUPPORTED",
                    "Installed Pulser dependency versions are outside >=1,<2.",
                    suggestion="Install compatible 1.x Pulser reference packages.",
                    metadata={"incompatible": incompatible},
                ),
            ),
            metadata={"network_accessed": False, "packages_imported": False},
        )
    return PulserReferenceCapabilityIR(
        capability_id="pulser.reference.dependencies",
        status="available",
        dependency_available=True,
        actual_execution_available=True,
        package_versions=versions,
        supported_features=(
            "analog.single_site",
            "drive.rydberg_global",
            "waveform.constant",
            "waveform.linear",
            "waveform.piecewise_constant",
            "waveform.piecewise_linear",
            "result.exact_probabilities",
            "result.statevector",
            "observable.z",
        ),
        metadata={"network_accessed": False, "packages_imported": False},
    )


class PulserReferenceAdapter:
    """Experimental adapter for bounded local Pulser reference execution."""

    def check(self, program: ProgramIR) -> PulserReferenceCapabilityIR:
        """Return semantic and dependency readiness without external execution."""
        if not isinstance(program, ProgramIR):
            raise TypeError("PulserReferenceAdapter.check accepts ProgramIR.")
        try:
            projection = _project_program(program)
        except PulserReferenceError as exc:
            capability = probe_pulser_reference()
            return PulserReferenceCapabilityIR(
                capability_id=f"pulser.reference.{program.program_id}",
                status="unsupported",
                dependency_available=capability.dependency_available,
                actual_execution_available=False,
                package_versions=capability.package_versions,
                diagnostics=(exc.to_diagnostic(),),
                metadata={
                    **capability.metadata,
                    "program_hash": program.stable_hash(),
                },
            )
        capability = probe_pulser_reference()
        return PulserReferenceCapabilityIR.from_dict(
            {
                **capability.to_dict(),
                "capability_id": f"pulser.reference.{program.program_id}",
                "metadata": {
                    **capability.metadata,
                    "program_hash": program.stable_hash(),
                    "projection_hash": projection.stable_hash(),
                },
            }
        )

    def project(self, program: ProgramIR) -> PulserProjectionIR:
        """Build a deterministic pure-CASCAQit Pulser sequence specification."""
        if not isinstance(program, ProgramIR):
            raise TypeError("PulserReferenceAdapter.project accepts ProgramIR.")
        return _project_program(program)

    def run(self, program: ProgramIR) -> PulserReferenceRunIR:
        """Materialize and execute the projection in the optional local runtime."""
        if not isinstance(program, ProgramIR):
            raise TypeError("PulserReferenceAdapter.run accepts ProgramIR.")
        capability = self.check(program)
        _require_actual_execution(
            capability,
            program_hash=program.stable_hash(),
            object_path="reference_adapter.run",
        )
        projection = self.project(program)
        solver_configuration: dict[str, Any] = {
            "sampling_rate": 1.0,
            "atol": 1e-12,
            "rtol": 1e-12,
            "progress_bar": False,
        }
        try:
            statevector = _execute_projection(projection, solver_configuration)
        except Exception as exc:
            raise PulserReferenceError(
                "Pulser local reference execution failed.",
                code="PULSER_REFERENCE_EXECUTION_FAILED",
                object_path="reference_adapter.run",
                suggestion="Inspect the Pulser runtime and frozen sequence spec.",
                source_hashes={
                    "program_hash": program.stable_hash(),
                    "projection_hash": projection.stable_hash(),
                },
                metadata={"exception_type": type(exc).__name__},
                cause=exc,
            ) from exc
        probabilities = {
            "0": abs(statevector[0]) ** 2,
            "1": abs(statevector[1]) ** 2,
        }
        result = ResultIR(
            result_id=f"result.pulser.reference.{program.program_id}",
            program_hash=program.stable_hash(),
            target_id="pulser.mock_device.local",
            shots=0,
            counts={},
            samples=(),
            probabilities=probabilities,
            observables={
                "z": probabilities["0"] - probabilities["1"],
                "mean_excitation": probabilities["1"],
                "occupation": {projection.atom_order[0]: probabilities["1"]},
            },
            bit_ordering={
                "convention": ANALOG_BIT_ORDER_CONVENTION,
                "atom_order": ",".join(projection.atom_order),
            },
            metadata={
                "actual_reference_execution": True,
                "provider": "pulser",
                "package_versions": capability.package_versions,
                "projection_hash": projection.stable_hash(),
                "statevector_returned_in_result": False,
                "network_accessed": False,
                "hardware_execution": False,
                "cloud_execution": False,
            },
        )
        encoded_state = tuple((value.real, value.imag) for value in statevector)
        return PulserReferenceRunIR(
            run_id=f"run.pulser.reference.{program.program_id}",
            projection=projection,
            actual_execution=True,
            result=result,
            statevector=encoded_state,
            package_versions=capability.package_versions,
            solver_configuration=solver_configuration,
            metadata={
                "provider": "pulser",
                "basis_order": ["g", "r"],
                "statevector_hash": _statevector_hash(encoded_state),
                "network_accessed": False,
                "hardware_execution": False,
                "cloud_execution": False,
            },
        )


def _require_actual_execution(
    capability: PulserReferenceCapabilityIR,
    *,
    program_hash: str,
    object_path: str,
) -> None:
    """Raise the shared structured preflight error for unavailable execution."""
    if capability.actual_execution_available:
        return
    diagnostic_codes = [item.code for item in capability.diagnostics]
    raise PulserReferenceError(
        "Pulser reference execution is unavailable.",
        code=(
            "PULSER_REFERENCE_CAPABILITY_UNSUPPORTED"
            if capability.status == "unsupported"
            else "PULSER_REFERENCE_DEPENDENCY_UNAVAILABLE"
        ),
        object_path=object_path,
        suggestion=capability.diagnostics[0].suggestion,
        source_hashes={"program_hash": program_hash},
        metadata={"diagnostic_codes": diagnostic_codes},
        diagnostics=capability.diagnostics,
    )


def compare_pulser_reference(
    native_result: ResultIR,
    reference_run: PulserReferenceRunIR,
    *,
    native_statevector: tuple[complex, ...] | None = None,
    thresholds: dict[str, float] | None = None,
) -> PulserReferenceComparisonIR:
    """Compare native and actual Pulser evidence with metric-specific limits."""
    if not isinstance(native_result, ResultIR):
        raise TypeError("native_result must be ResultIR.")
    if not isinstance(reference_run, PulserReferenceRunIR):
        raise TypeError("reference_run must be PulserReferenceRunIR.")
    limits = dict(_DEFAULT_THRESHOLDS if thresholds is None else thresholds)
    if set(limits) != set(_DEFAULT_THRESHOLDS) or any(
        not math.isfinite(value) or value < 0.0 for value in limits.values()
    ):
        raise ValueError("thresholds must define finite non-negative frozen metrics.")
    diagnostics: list[DiagnosticsIR] = []
    metrics: dict[str, float] = {}
    reference_result = reference_run.result
    if not reference_run.actual_execution or reference_result is None:
        diagnostics.append(
            _comparison_diagnostic(
                "PULSER_REFERENCE_ACTUAL_EXECUTION_REQUIRED",
                "Numerical comparison requires an actual Pulser run.",
                "Run the optional Pulser reference gate before comparison.",
            )
        )
    elif native_result.program_hash != reference_result.program_hash:
        diagnostics.append(
            _comparison_diagnostic(
                "PULSER_REFERENCE_PROGRAM_HASH_MISMATCH",
                "Native and Pulser results refer to different programs.",
                "Compare results projected from the same ProgramIR hash.",
                metadata={
                    "native_program_hash": native_result.program_hash,
                    "reference_program_hash": reference_result.program_hash,
                },
            )
        )
    if reference_result is not None:
        _compare_probabilities(
            native_result,
            reference_result,
            metrics=metrics,
            diagnostics=diagnostics,
        )
    _compare_statevectors(
        native_statevector,
        reference_run,
        metrics=metrics,
        diagnostics=diagnostics,
    )
    if "state_fidelity" in metrics and (
        metrics["state_fidelity"] < limits["minimum_state_fidelity"]
    ):
        diagnostics.append(
            _comparison_diagnostic(
                "PULSER_REFERENCE_STATE_FIDELITY_FAILED",
                "State fidelity is below the frozen threshold.",
                "Inspect basis, units, waveform sampling, and solver settings.",
                metadata={
                    "actual": metrics["state_fidelity"],
                    "minimum": limits["minimum_state_fidelity"],
                },
            )
        )
    for metric, threshold in (
        ("max_probability_error", "maximum_probability_error"),
        ("max_z_error", "maximum_z_error"),
    ):
        if metric in metrics and metrics[metric] > limits[threshold]:
            diagnostics.append(
                _comparison_diagnostic(
                    f"PULSER_REFERENCE_{metric.upper()}_FAILED",
                    f"{metric} exceeds the frozen threshold.",
                    "Inspect normalization, basis order, and waveform sampling.",
                    metadata={
                        "actual": metrics[metric],
                        "maximum": limits[threshold],
                    },
                )
            )
    required_metrics = {
        "state_fidelity",
        "max_probability_error",
        "max_z_error",
    }
    passed = (
        reference_run.actual_execution
        and reference_result is not None
        and not diagnostics
        and required_metrics.issubset(metrics)
    )
    return PulserReferenceComparisonIR(
        comparison_id=f"comparison.{reference_run.run_id}",
        native_result_hash=native_result.stable_hash(),
        reference_run_hash=reference_run.stable_hash(),
        actual_reference_execution=reference_run.actual_execution,
        passed=passed,
        metrics=metrics,
        thresholds=limits,
        diagnostics=tuple(diagnostics),
        metadata={
            "metric_policy": "state_probability_observable_specific",
            "uniform_one_percent_threshold_used": False,
        },
    )


def _compare_probabilities(
    native_result: ResultIR,
    reference_result: ResultIR,
    *,
    metrics: dict[str, float],
    diagnostics: list[DiagnosticsIR],
) -> None:
    native = native_result.probabilities
    reference = reference_result.probabilities
    if native is None or reference is None or set(native) != set(reference):
        diagnostics.append(
            _comparison_diagnostic(
                "PULSER_REFERENCE_PROBABILITIES_INCOMPATIBLE",
                "Comparable native and Pulser probabilities are required.",
                "Return the same normalized bitstring probability keys.",
            )
        )
        return
    values = [*native.values(), *reference.values()]
    if any(not math.isfinite(value) or value < 0.0 for value in values):
        diagnostics.append(
            _comparison_diagnostic(
                "PULSER_REFERENCE_PROBABILITIES_INVALID",
                "Comparison probabilities must be finite and non-negative.",
                "Fix the simulator result normalization before comparison.",
            )
        )
        return
    if not math.isclose(sum(native.values()), 1.0, abs_tol=1e-9) or not math.isclose(
        sum(reference.values()),
        1.0,
        abs_tol=1e-9,
    ):
        diagnostics.append(
            _comparison_diagnostic(
                "PULSER_REFERENCE_PROBABILITIES_NOT_NORMALIZED",
                "Native and Pulser probabilities must each sum to one.",
                "Normalize both distributions before comparison.",
            )
        )
        return
    metrics["max_probability_error"] = max(
        abs(native[key] - reference[key]) for key in native
    )
    native_z = native.get("0", 0.0) - native.get("1", 0.0)
    reference_z = reference.get("0", 0.0) - reference.get("1", 0.0)
    metrics["max_z_error"] = abs(native_z - reference_z)


def _compare_statevectors(
    native_statevector: tuple[complex, ...] | None,
    reference_run: PulserReferenceRunIR,
    *,
    metrics: dict[str, float],
    diagnostics: list[DiagnosticsIR],
) -> None:
    if native_statevector is None:
        diagnostics.append(
            _comparison_diagnostic(
                "PULSER_REFERENCE_NATIVE_STATE_REQUIRED",
                "State fidelity requires the native executable final state.",
                "Pass native_statevector from the Analog state kernel.",
            )
        )
        return
    reference_statevector = tuple(
        complex(real, imag) for real, imag in reference_run.statevector
    )
    if len(native_statevector) != len(reference_statevector) or not native_statevector:
        diagnostics.append(
            _comparison_diagnostic(
                "PULSER_REFERENCE_STATE_DIMENSION_MISMATCH",
                "Native and Pulser statevectors must have the same dimension.",
                "Check the one-site basis projection and state order.",
            )
        )
        return
    values = (*native_statevector, *reference_statevector)
    if any(
        not math.isfinite(value.real) or not math.isfinite(value.imag)
        for value in values
    ):
        diagnostics.append(
            _comparison_diagnostic(
                "PULSER_REFERENCE_STATE_NONFINITE",
                "Statevector amplitudes must be finite.",
                "Inspect both simulators for invalid numerical output.",
            )
        )
        return
    native_norm = sum(abs(value) ** 2 for value in native_statevector)
    reference_norm = sum(abs(value) ** 2 for value in reference_statevector)
    if native_norm <= 0.0 or reference_norm <= 0.0:
        diagnostics.append(
            _comparison_diagnostic(
                "PULSER_REFERENCE_STATE_ZERO_NORM",
                "Statevector norms must be positive.",
                "Return normalized non-zero final states.",
            )
        )
        return
    overlap = sum(
        native.conjugate() * reference
        for native, reference in zip(native_statevector, reference_statevector)
    )
    metrics["state_fidelity"] = abs(overlap) ** 2 / (native_norm * reference_norm)


def _comparison_diagnostic(
    code: str,
    message: str,
    suggestion: str,
    *,
    metadata: dict[str, Any] | None = None,
) -> DiagnosticsIR:
    return DiagnosticsIR(
        diagnostic_id=f"pulser.reference.comparison.{code.lower()}",
        stage="simulation",
        severity="error",
        code=code,
        message=message,
        object_path="pulser_reference_comparison",
        suggestion=suggestion,
        metadata={} if metadata is None else metadata,
    )


def _dependency_versions() -> tuple[dict[str, str], list[str]]:
    versions: dict[str, str] = {}
    missing: list[str] = []
    for package, module in (
        (_CORE_PACKAGE, _CORE_MODULE),
        (_SIMULATION_PACKAGE, _SIMULATION_MODULE),
    ):
        if importlib.util.find_spec(module) is None:
            missing.append(package)
            continue
        try:
            versions[package] = version(package)
        except PackageNotFoundError:
            missing.append(package)
    return versions, missing


def _project_program(program: ProgramIR) -> PulserProjectionIR:
    sites = program.register.sites
    filled_sites = tuple(site for site in sites if site.is_active)
    if len(sites) != 1 or len(filled_sites) != 1:
        _raise_projection_error(
            "Pulser reference projection requires exactly one filled site.",
            code="PULSER_REFERENCE_SITE_COUNT_UNSUPPORTED",
            object_path="program.register.sites",
            suggestion="Use one filled site with no vacancies for the reference path.",
            metadata={"site_count": len(sites), "filled_site_count": len(filled_sites)},
            program=program,
        )
    if program.register.coordinate_unit != "um":
        _raise_projection_error(
            "Pulser reference coordinates must use micrometers.",
            code="PULSER_REFERENCE_COORDINATE_UNIT_UNSUPPORTED",
            object_path="program.register.coordinate_unit",
            suggestion="Convert register coordinates to 'um'.",
            metadata={"coordinate_unit": program.register.coordinate_unit},
            program=program,
        )
    if program.hamiltonian.hamiltonian_type != "rydberg":
        _raise_projection_error(
            "Pulser reference projection only supports Rydberg Hamiltonians.",
            code="PULSER_REFERENCE_HAMILTONIAN_UNSUPPORTED",
            object_path="program.hamiltonian.hamiltonian_type",
            suggestion="Use the P0 global Rydberg Hamiltonian.",
            metadata={"hamiltonian_type": program.hamiltonian.hamiltonian_type},
            program=program,
        )
    if program.hamiltonian.local_detuning_terms:
        _raise_projection_error(
            "Local detuning is outside the Pulser reference subset.",
            code="PULSER_REFERENCE_LOCAL_DETUNING_UNSUPPORTED",
            object_path="program.hamiltonian.local_detuning_terms",
            suggestion="Use global detuning only.",
            program=program,
        )
    if program.hamiltonian.local_rabi_terms:
        _raise_projection_error(
            "Local Rabi control is outside the Pulser reference subset.",
            code="PULSER_REFERENCE_LOCAL_RABI_UNSUPPORTED",
            object_path="program.hamiltonian.local_rabi_terms",
            suggestion="Use global Rabi control only.",
            program=program,
        )
    if program.parameters or program.parameter_schema.parameters:
        _raise_projection_error(
            "Pulser reference projection requires a fully bound program.",
            code="PULSER_REFERENCE_PARAMETERS_UNBOUND",
            object_path="program.parameters",
            suggestion="Bind all parameters before reference projection.",
            program=program,
        )
    if (
        program.occupation_encoding.ground != 0
        or program.occupation_encoding.rydberg != 1
    ):
        _raise_projection_error(
            "Pulser reference projection requires ground=0 and rydberg=1.",
            code="PULSER_REFERENCE_OCCUPATION_ENCODING_UNSUPPORTED",
            object_path="program.occupation_encoding",
            suggestion="Use the default CASCAQit occupation encoding.",
            program=program,
        )
    if program.bit_ordering.get("convention") != ANALOG_BIT_ORDER_CONVENTION:
        _raise_projection_error(
            "Pulser reference projection requires active register bit order.",
            code="PULSER_REFERENCE_BIT_ORDER_UNSUPPORTED",
            object_path="program.bit_ordering.convention",
            suggestion="Use active_register_order for the reference workload.",
            program=program,
        )
    _validate_measurement(program)
    rabi = _waveform_spec(program, "rabi")
    detuning = _waveform_spec(program, "detuning")
    if rabi["duration"] != detuning["duration"]:
        _raise_projection_error(
            "Rabi and detuning durations must match for Pulser projection.",
            code="PULSER_REFERENCE_DURATION_MISMATCH",
            object_path="program.hamiltonian",
            suggestion="Use one duration across global drive waveforms.",
            metadata={
                "rabi_duration": rabi["duration"],
                "detuning_duration": detuning["duration"],
            },
            program=program,
        )
    phase = program.hamiltonian.phase
    if isinstance(phase, WaveformIR) or not math.isfinite(phase):
        _raise_projection_error(
            "Pulser reference projection requires one finite scalar phase.",
            code="PULSER_REFERENCE_PHASE_UNSUPPORTED",
            object_path="program.hamiltonian.phase",
            suggestion="Use a finite scalar phase in radians.",
            program=program,
        )
    phase_value = float(phase)
    site = filled_sites[0]
    if site.atom_id is None:
        raise AssertionError("An active register site must define atom_id.")
    waveform_kinds = tuple(sorted({str(rabi["kind"]), str(detuning["kind"])}))
    sequence_spec = {
        "register": {
            "atom_id": site.atom_id,
            "position": list(site.position),
            "coordinate_unit": "um",
        },
        "channel": "rydberg_global",
        "initial_state": {"cascaqit": "0", "pulser": "g"},
        "drive": {
            "rabi": rabi,
            "detuning": detuning,
            "phase": {"kind": "constant", "value": phase_value, "unit": "rad"},
        },
        "measurement": {
            "basis": "ground_rydberg",
            "targets": [site.atom_id],
        },
        "result_mapping": {
            "g": "0",
            "r": "1",
            "bit_order": [site.atom_id],
        },
    }
    return PulserProjectionIR(
        projection_id=f"pulser.projection.{program.program_id}",
        program_id=program.program_id,
        program_hash=program.stable_hash(),
        atom_order=(site.atom_id,),
        basis_mapping={"g": "0", "r": "1"},
        unit_mapping={
            "coordinate": "um",
            "time": "us",
            "frequency": "rad/us",
            "phase": "rad",
        },
        waveform_kinds=waveform_kinds,
        sequence_spec=sequence_spec,
        metadata={
            "actual_execution": False,
            "third_party_object_stored": False,
            "network_accessed": False,
        },
    )


def _execute_projection(
    projection: PulserProjectionIR,
    solver_configuration: dict[str, Any],
) -> tuple[complex, complex]:
    emulator = _materialize_projection(projection, solver_configuration)
    return _run_materialized_projection(emulator, solver_configuration)


def _materialize_projection(
    projection: PulserProjectionIR,
    solver_configuration: dict[str, Any],
) -> Any:
    pulser = import_module("pulser")
    devices = import_module("pulser.devices")
    simulation = import_module("pulser_simulation")
    spec = projection.sequence_spec
    register_spec = spec["register"]
    register = pulser.Register(
        {
            str(register_spec["atom_id"]): tuple(register_spec["position"]),
        }
    )
    sequence = pulser.Sequence(register, devices.MockDevice)
    channel_id = "cascaqit_reference"
    sequence.declare_channel(channel_id, str(spec["channel"]))
    drive = spec["drive"]
    pulse = pulser.Pulse(
        _materialize_waveform(drive["rabi"]),
        _materialize_waveform(drive["detuning"]),
        float(drive["phase"]["value"]),
    )
    sequence.add(pulse, channel_id)
    emulator = simulation.QutipEmulator.from_sequence(
        sequence,
        sampling_rate=float(solver_configuration["sampling_rate"]),
    )
    return emulator


def _run_materialized_projection(
    emulator: Any,
    solver_configuration: dict[str, Any],
) -> tuple[complex, complex]:
    results = emulator.run(
        progress_bar=bool(solver_configuration["progress_bar"]),
        atol=float(solver_configuration["atol"]),
        rtol=float(solver_configuration["rtol"]),
    )
    final_state = results.get_final_state(reduce_to_basis="ground-rydberg")
    raw = final_state.full().reshape(-1)
    if len(raw) != 2:
        raise ValueError(f"Expected two Pulser amplitudes, received {len(raw)}.")
    # Pulser orders the one-site ground-Rydberg basis as [|r>, |g>].
    return complex(raw[1]), complex(raw[0])


def _materialize_waveform(spec: dict[str, Any]) -> Any:
    waveforms = import_module("pulser.waveforms")
    duration_ns = _duration_ns(float(spec["duration"]))
    kind = str(spec["kind"])
    values = [float(value) for value in spec["values"]]
    if kind == "constant":
        return waveforms.ConstantWaveform(duration_ns, values[0])
    if kind == "linear":
        return waveforms.RampWaveform(duration_ns, values[0], values[-1])
    samples = _piecewise_samples(
        duration_ns=duration_ns,
        times=[float(value) for value in spec["times"]],
        values=values,
        constant=kind == "piecewise_constant",
    )
    return waveforms.CustomWaveform(samples)


def _duration_ns(duration_us: float) -> int:
    duration_ns = round(duration_us * 1000.0)
    if duration_ns < 1 or not math.isclose(duration_us * 1000.0, duration_ns):
        raise ValueError(
            "Pulser waveform duration must resolve to integer nanoseconds."
        )
    return duration_ns


def _piecewise_samples(
    *,
    duration_ns: int,
    times: list[float],
    values: list[float],
    constant: bool,
) -> list[float]:
    samples: list[float] = []
    for index in range(duration_ns):
        time_us = index / 1000.0
        value = values[-1]
        if time_us <= times[0]:
            value = values[0]
        else:
            for right_index, right_time in enumerate(times[1:], start=1):
                if time_us <= right_time:
                    left_time = times[right_index - 1]
                    left_value = values[right_index - 1]
                    if constant:
                        value = left_value
                    else:
                        fraction = (time_us - left_time) / (right_time - left_time)
                        value = left_value + fraction * (
                            values[right_index] - left_value
                        )
                    break
        samples.append(value)
    return samples


def _statevector_hash(statevector: tuple[tuple[float, float], ...]) -> str:
    payload = json.dumps(statevector, separators=(",", ":"))
    return sha256(payload.encode("ascii")).hexdigest()


def _validate_measurement(program: ProgramIR) -> None:
    if len(program.measurements) != 1:
        _raise_projection_error(
            "Pulser reference projection requires one terminal measurement.",
            code="PULSER_REFERENCE_MEASUREMENT_UNSUPPORTED",
            object_path="program.measurements",
            suggestion="Add one ground_rydberg terminal measurement.",
            metadata={"measurement_count": len(program.measurements)},
            program=program,
        )
    measurement = program.measurements[0]
    atom_id = next(site.atom_id for site in program.register.sites if site.is_active)
    valid_targets = measurement.targets == "all" or measurement.targets == (atom_id,)
    if measurement.basis != "ground_rydberg" or not valid_targets:
        _raise_projection_error(
            "Pulser reference measurement basis or targets are unsupported.",
            code="PULSER_REFERENCE_MEASUREMENT_UNSUPPORTED",
            object_path="program.measurements[0]",
            suggestion="Measure the only atom in the ground_rydberg basis.",
            metadata={
                "basis": measurement.basis,
                "targets": measurement.targets,
            },
            program=program,
        )


def _waveform_spec(program: ProgramIR, field_name: str) -> dict[str, Any]:
    waveform = getattr(program.hamiltonian, field_name)
    if waveform.kind not in (
        "constant",
        "linear",
        "piecewise_constant",
        "piecewise_linear",
    ):
        _raise_projection_error(
            "Waveform kind is outside the Pulser reference subset.",
            code="PULSER_REFERENCE_WAVEFORM_UNSUPPORTED",
            object_path=f"program.hamiltonian.{field_name}.kind",
            suggestion="Use constant, linear, or piecewise waveforms.",
            metadata={"kind": waveform.kind},
            program=program,
        )
    if waveform.time_unit != "us" or waveform.value_unit != "rad/us":
        _raise_projection_error(
            "Pulser reference waveforms require us and rad/us units.",
            code="PULSER_REFERENCE_WAVEFORM_UNIT_UNSUPPORTED",
            object_path=f"program.hamiltonian.{field_name}",
            suggestion="Convert time to us and angular frequency to rad/us.",
            metadata={
                "time_unit": waveform.time_unit,
                "value_unit": waveform.value_unit,
            },
            program=program,
        )
    if waveform.parameters or not waveform.values:
        _raise_projection_error(
            "Pulser reference waveforms must contain bound numeric values.",
            code="PULSER_REFERENCE_WAVEFORM_UNBOUND",
            object_path=f"program.hamiltonian.{field_name}.values",
            suggestion="Bind waveform parameters before projection.",
            program=program,
        )
    values = tuple(float(value) for value in waveform.values)
    times = (
        (0.0, waveform.duration)
        if waveform.times is None
        else tuple(float(time) for time in waveform.times)
    )
    if (
        not math.isfinite(waveform.duration)
        or waveform.duration <= 0.0
        or any(not math.isfinite(value) for value in values)
        or any(not math.isfinite(time) for time in times)
    ):
        _raise_projection_error(
            "Pulser reference waveform values and times must be finite.",
            code="PULSER_REFERENCE_WAVEFORM_VALUE_INVALID",
            object_path=f"program.hamiltonian.{field_name}",
            suggestion="Use finite values and a positive finite duration.",
            program=program,
        )
    return {
        "kind": waveform.kind,
        "duration": waveform.duration,
        "times": list(times),
        "values": list(values),
        "time_unit": "us",
        "value_unit": "rad/us",
    }


def _raise_projection_error(
    message: str,
    *,
    code: str,
    object_path: str,
    suggestion: str,
    program: ProgramIR,
    metadata: dict[str, Any] | None = None,
) -> NoReturn:
    raise PulserReferenceError(
        message,
        code=code,
        object_path=object_path,
        suggestion=suggestion,
        source_hashes={"program_hash": program.stable_hash()},
        metadata={} if metadata is None else metadata,
    )


def _major_version(package_version: str) -> int | None:
    prefix = package_version.split(".", 1)[0]
    try:
        return int(prefix)
    except ValueError:
        return None


def _diagnostic(
    code: str,
    message: str,
    *,
    suggestion: str,
    metadata: dict[str, Any] | None = None,
) -> DiagnosticsIR:
    return DiagnosticsIR(
        diagnostic_id=f"pulser.reference.{code.lower()}",
        stage="simulation",
        severity="error",
        code=code,
        message=message,
        object_path="reference_adapter.dependencies",
        suggestion=suggestion,
        metadata={} if metadata is None else metadata,
    )


def _json_object(text: str, label: str) -> dict[str, Any]:
    data = json.loads(text)
    if not isinstance(data, dict):
        raise TypeError(f"Pulser reference {label} JSON must contain an object.")
    return data
