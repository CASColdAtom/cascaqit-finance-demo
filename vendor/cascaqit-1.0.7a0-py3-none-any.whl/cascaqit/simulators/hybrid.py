"""Constrained hybrid simulator facade for plan-first workflows."""

from __future__ import annotations

from dataclasses import dataclass, replace
from datetime import datetime, timezone
from typing import Literal

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.digital import DigitalMeasurementIR, DigitalProgramIR, GateIR
from cascaqit.hybrid import (
    AnalogBlockIR,
    DigitalBlockIR,
    HybridProgramIR,
    HybridSimulationPlanIR,
    MeasureBlockIR,
    build_hybrid_simulation_plan,
)
from cascaqit.native_ir import SimulatorConfigIR
from cascaqit.results import ResultIR, ResultReferencesIR
from cascaqit.simulators.diagnostics import build_diagnostics_summary
from cascaqit.simulators.digital import LocalDigitalSimulator
from cascaqit.simulators.local_ahs import LocalAhsSimulator
from cascaqit.simulators.models import select_simulation_algorithm

__all__ = ["HybridBlockSimulator"]

HybridRunMode = Literal["plan_only", "execute_safe_subset"]


@dataclass(frozen=True)
class HybridBlockSimulator:
    """Legacy plan-first facade for HybridProgramIR review and safe subsets."""

    digital_simulator: LocalDigitalSimulator = LocalDigitalSimulator()
    analog_simulator: LocalAhsSimulator = LocalAhsSimulator()
    created_at: str | None = None

    def plan(self, program: HybridProgramIR) -> HybridSimulationPlanIR:
        """Return the deterministic hybrid simulation plan without execution."""
        _ensure_hybrid_program(program)
        return build_hybrid_simulation_plan(program)

    def run(
        self,
        program: HybridProgramIR,
        *,
        shots: int = 1000,
        config: SimulatorConfigIR | None = None,
        plan_only: bool = True,
    ) -> HybridSimulationPlanIR | ResultIR:
        """Plan by default; execute only explicitly supported safe subsets."""
        _ensure_hybrid_program(program)
        plan = build_hybrid_simulation_plan(program)
        simulator_config = _effective_config(
            config,
            default_shots=shots,
            default_seed=self.digital_simulator.seed,
        )
        if plan_only:
            return plan
        if _has_error(plan):
            return _unsupported_result(
                program,
                plan,
                shots=simulator_config.shots,
                config=simulator_config,
                code="HYBRID_SIMULATION_INPUT_INVALID",
                message="Hybrid simulation input failed validation.",
                severity="error",
                created_at=self.created_at,
                extra_diagnostics=tuple(plan.diagnostics),
            )
        if _has_mixed_analog_digital_boundary(plan):
            return _unsupported_result(
                program,
                plan,
                shots=simulator_config.shots,
                config=simulator_config,
                code="HYBRID_SIMULATION_UNSUPPORTED_MIXED_BOUNDARY",
                message=(
                    "Mixed analog/digital hybrid simulation is unsupported because "
                    "state handoff is not implemented."
                ),
                severity="warning",
                suggestion=(
                    "Use the plan artifact for boundary review; do not treat this "
                    "sequence as DAQC execution."
                ),
                created_at=self.created_at,
                extra_diagnostics=_boundary_diagnostics_as_result_diagnostics(plan),
            )
        digital_program = _digital_only_program(program)
        if digital_program is not None:
            result = self.digital_simulator.run(
                digital_program,
                config=simulator_config,
            )
            return _with_hybrid_metadata(
                result,
                program=program,
                plan=plan,
                mode="execute_safe_subset",
                subset="digital_only",
                created_at=self.created_at,
            )
        analog_block = _single_analog_block(program)
        if analog_block is not None:
            result = self.analog_simulator.run(
                analog_block.program,
                config=simulator_config,
            )
            return _with_hybrid_metadata(
                result,
                program=program,
                plan=plan,
                mode="execute_safe_subset",
                subset="analog_single_block",
                created_at=self.created_at,
            )
        return _unsupported_result(
            program,
            plan,
            shots=simulator_config.shots,
            config=simulator_config,
            code="HYBRID_SIMULATION_UNSUPPORTED_SHAPE",
            message="Hybrid simulator facade cannot execute this block shape.",
            severity="warning",
            suggestion=(
                "Use digital-only hybrid blocks or a single unambiguous analog "
                "block for local execution."
            ),
            created_at=self.created_at,
            extra_diagnostics=_boundary_diagnostics_as_result_diagnostics(plan),
        )


def _ensure_hybrid_program(program: HybridProgramIR) -> None:
    if not isinstance(program, HybridProgramIR):
        raise TypeError("HybridBlockSimulator accepts HybridProgramIR.")


def _effective_config(
    config: SimulatorConfigIR | None,
    *,
    default_shots: int,
    default_seed: int | None,
) -> SimulatorConfigIR:
    if config is not None:
        return config
    return SimulatorConfigIR(shots=default_shots, seed=default_seed)


def _has_error(plan: HybridSimulationPlanIR) -> bool:
    has_error_diagnostic = any(
        diagnostic.severity == "error" for diagnostic in plan.diagnostics
    )
    has_error_boundary = any(
        boundary.status == "error" for boundary in plan.boundary_diagnostics
    )
    return has_error_diagnostic or has_error_boundary


def _has_mixed_analog_digital_boundary(plan: HybridSimulationPlanIR) -> bool:
    return any(
        boundary.code == "HYBRID_STATE_HANDOFF_UNSUPPORTED"
        for boundary in plan.boundary_diagnostics
    )


def _digital_only_program(program: HybridProgramIR) -> DigitalProgramIR | None:
    digital_blocks = [
        block for block in program.blocks if isinstance(block, DigitalBlockIR)
    ]
    measure_blocks = [
        block for block in program.blocks if isinstance(block, MeasureBlockIR)
    ]
    if not digital_blocks:
        return None
    if any(isinstance(block, AnalogBlockIR) for block in program.blocks):
        return None
    if len(measure_blocks) > 1:
        return None
    if any(
        not isinstance(block, (DigitalBlockIR, MeasureBlockIR))
        for block in program.blocks
    ):
        return None
    if measure_blocks and not isinstance(program.blocks[-1], MeasureBlockIR):
        return None

    qubits: list[str] = []
    gates: list[GateIR] = []
    measurements: list[DigitalMeasurementIR] = []
    for block in digital_blocks:
        for qubit in block.circuit.qubits:
            if qubit not in qubits:
                qubits.append(qubit)
        gates.extend(block.circuit.gates)
        measurements.extend(block.circuit.measurements)
    if measure_blocks:
        measurements.extend(measure_blocks[0].measurements)
    metadata = {
        "source": "HybridBlockSimulator",
        "source_program_id": program.program_id,
        "source_block_ids": [block.block_id for block in digital_blocks],
    }
    return DigitalProgramIR(
        program_id=f"{program.program_id}.digital_subset",
        circuit=replace(
            digital_blocks[0].circuit,
            circuit_id=f"{program.program_id}.digital_subset",
            qubits=tuple(qubits),
            gates=tuple(gates),
            measurements=tuple(measurements),
            metadata=metadata,
        ),
        metadata=metadata,
    )


def _single_analog_block(program: HybridProgramIR) -> AnalogBlockIR | None:
    analog_blocks = [
        block for block in program.blocks if isinstance(block, AnalogBlockIR)
    ]
    if len(analog_blocks) != 1:
        return None
    if len(program.blocks) != 1:
        return None
    return analog_blocks[0]


def _with_hybrid_metadata(
    result: ResultIR,
    *,
    program: HybridProgramIR,
    plan: HybridSimulationPlanIR,
    mode: HybridRunMode,
    subset: str,
    created_at: str | None,
) -> ResultIR:
    completed = DiagnosticsIR(
        diagnostic_id="hybrid.simulation.safe_subset.completed",
        stage="simulation",
        severity="info",
        code="HYBRID_SIMULATION_SAFE_SUBSET_COMPLETED",
        message="Hybrid facade delegated an explicitly supported local subset.",
        object_path="result",
        metadata={
            "program_id": program.program_id,
            "subset": subset,
            "full_daqc_state_handoff": False,
        },
    )
    metadata = dict(result.metadata)
    metadata["created_at"] = metadata.get("created_at", _created_at(created_at))
    metadata["hybrid_simulation"] = {
        "facade": "HybridBlockSimulator",
        "mode": mode,
        "subset": subset,
        "program_id": program.program_id,
        "plan_id": plan.plan_id,
        "full_daqc_state_handoff": False,
        "plan": plan.to_dict(),
    }
    return replace(
        result,
        result_id=f"result.{program.program_id}",
        diagnostics=(completed, *result.diagnostics),
        metadata=metadata,
    )


def _unsupported_result(
    program: HybridProgramIR,
    plan: HybridSimulationPlanIR,
    *,
    shots: int,
    config: SimulatorConfigIR,
    code: str,
    message: str,
    severity: Literal["warning", "error"],
    created_at: str | None,
    suggestion: str | None = None,
    extra_diagnostics: tuple[DiagnosticsIR, ...] = (),
) -> ResultIR:
    references = ResultReferencesIR(
        program_hash=program.stable_hash(),
        metadata={
            "program_id": program.program_id,
            "hybrid_plan_id": plan.plan_id,
        },
    )
    algorithm = select_simulation_algorithm(
        simulator_name="HybridBlockSimulator",
        program_type="hybrid",
        requested_method=config.method,
        hilbert_dimension=None,
        max_hilbert_dim=config.max_hilbert_dim,
        seed=config.seed,
        parameters={"shots": shots, "plan_only": False},
        metadata={"execution_mode": "unsupported"},
    )
    primary = DiagnosticsIR(
        diagnostic_id=f"hybrid.{code.lower()}",
        stage="simulation",
        severity=severity,
        code=code,
        message=message,
        object_path="hybrid_program",
        suggestion=suggestion,
        metadata={
            "program_id": program.program_id,
            "plan_id": plan.plan_id,
            "full_daqc_state_handoff": False,
        },
    )
    diagnostics = (primary, *extra_diagnostics)
    return ResultIR(
        result_id=f"result.{program.program_id}",
        program_hash=program.stable_hash(),
        target_id="local.hybrid_block_simulator",
        shots=shots,
        counts={},
        samples=(),
        probabilities=None,
        diagnostics=diagnostics,
        metadata={
            "created_at": _created_at(created_at),
            "references": references.to_dict(),
            "simulator": {
                "name": "HybridBlockSimulator",
                "method": "plan_first_safe_subset",
                "config": config.to_dict(),
            },
            "simulation_algorithm": algorithm.to_dict(),
            "simulation_state": {
                "primary": None,
                "samples": None,
                "state_bytes_returned": False,
                "physical_accuracy": "not_computed_unsupported_hybrid_boundary",
            },
            "hybrid_simulation": {
                "facade": "HybridBlockSimulator",
                "mode": "execute_safe_subset",
                "subset": "unsupported",
                "program_id": program.program_id,
                "plan_id": plan.plan_id,
                "full_daqc_state_handoff": False,
                "plan": plan.to_dict(),
            },
            "diagnostics_summary": _diagnostics_summary(diagnostics),
        },
    )


def _boundary_diagnostics_as_result_diagnostics(
    plan: HybridSimulationPlanIR,
) -> tuple[DiagnosticsIR, ...]:
    diagnostics: list[DiagnosticsIR] = []
    for boundary in plan.boundary_diagnostics:
        if boundary.status == "ok":
            continue
        severity: Literal["warning", "error"] = (
            "error" if boundary.status == "error" else "warning"
        )
        diagnostics.append(
            DiagnosticsIR(
                diagnostic_id=f"hybrid.{boundary.code.lower()}",
                stage="simulation",
                severity=severity,
                code=boundary.code,
                message=boundary.message,
                object_path=boundary.object_path,
                suggestion=boundary.suggestion,
                metadata={
                    **boundary.metadata,
                    "boundary_id": boundary.boundary_id,
                    "plan_id": plan.plan_id,
                },
            )
        )
    return tuple(diagnostics)


def _diagnostics_summary(diagnostics: tuple[DiagnosticsIR, ...]) -> dict[str, object]:
    return build_diagnostics_summary(diagnostics)


def _created_at(value: str | None) -> str:
    if value is not None:
        return value
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
