"""Canonical physical noise contracts and executable Hybrid noise orchestration."""

from __future__ import annotations

import json
import math
from collections import Counter
from collections.abc import Mapping
from dataclasses import dataclass, field, replace
from typing import Any, Literal, Union, cast

import numpy as np

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.digital import DigitalProgramIR, GateIR
from cascaqit.exceptions import CapabilityError, ProgramValidationError
from cascaqit.native_ir.base import IRMixin
from cascaqit.observables import (
    ObservableBatchResultIR,
    ObservableSet,
)
from cascaqit.results import ResultIR, SimulationSolverEvidenceIR, StateTransitionIR
from cascaqit.simulators.adaptive import fixed_step_solver_evidence
from cascaqit.simulators.array_state import (
    ArrayStateProvenance,
    DensityMatrixState,
    TrajectoryBatchState,
)
from cascaqit.simulators.density import (
    ExactDensityMatrixKernel,
    apply_density_kraus_channel,
    zero_density_matrix,
)
from cascaqit.simulators.execution_evidence import (
    aggregate_solver_evidence,
    not_applicable_solver_evidence,
    solver_evidence_from_provenance,
    solver_evidence_metadata,
)
from cascaqit.simulators.ideal import (
    ArrayDType,
    ComplexArray,
    _duration,
    validate_scalable_hybrid_bundle,
)
from cascaqit.simulators.local_hybrid import (
    AnalogStepPayload,
    DigitalStepPayload,
    LocalExecutionBundle,
    MeasurementStepPayload,
)
from cascaqit.simulators.observable_evaluator import evaluate_observables
from cascaqit.simulators.planning import (
    SelectedSimulationIntegrator,
    SimulationIntegrator,
)
from cascaqit.simulators.register_evidence import collect_register_snapshot_evidence
from cascaqit.simulators.runtime_lineage import (
    build_runtime_references,
    build_runtime_trace,
    build_state_transition,
    runtime_lineage_metadata,
)
from cascaqit.simulators.trajectory import (
    BatchedTrajectoryKernel,
    apply_trajectory_amplitude_damping,
    apply_trajectory_atom_loss,
    apply_trajectory_pauli_channel,
    apply_trajectory_unitary_channel,
    trajectory_hashes,
    zero_trajectory_batch,
)

__all__ = [
    "NoiseApplicationRecord",
    "NoiseChannel",
    "NoiseModel",
    "NoiseReport",
    "apply_density_noise_channel",
    "apply_trajectory_noise_channel",
    "run_physical_noisy_hybrid",
    "validate_physical_noise_bundle",
]

NoiseChannelType = Literal[
    "preparation",
    "dephasing",
    "gate",
    "idle",
    "crosstalk",
    "boundary",
    "atom_loss",
    "readout",
]
NoiseTargets = Union[tuple[str, ...], Literal["all"]]
NoiseTruthfulness = Literal["physical_state_evolution", "measurement_model_only"]

_INJECTION_POINTS: dict[NoiseChannelType, str] = {
    "preparation": "initial_state",
    "dephasing": "analog_evolution",
    "gate": "after_each_digital_gate",
    "idle": "digital_idle_interval",
    "crosstalk": "control_schedule",
    "boundary": "block_boundary",
    "atom_loss": "analog_exit",
    "readout": "terminal_measurement",
}
_MODELS: dict[NoiseChannelType, str] = {
    "preparation": "independent_bit_flip",
    "dephasing": "lindblad_phase_flip",
    "gate": "independent_bit_flip",
    "idle": "finite_interval_dephasing",
    "crosstalk": "coherent_xx",
    "boundary": "amplitude_damping",
    "atom_loss": "occupation_erasure",
    "readout": "asymmetric_confusion",
}


@dataclass(frozen=True)
class NoiseChannel(IRMixin):
    """One executable physical channel with explicit parameters and prerequisites."""

    channel_id: str
    channel_type: NoiseChannelType
    parameters: dict[str, float]
    units: dict[str, str]
    targets: NoiseTargets = "all"
    model: str = ""
    injection_point: str = ""
    source: str = "user"
    schedule_ref: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = "cascaqit.noise.physical.v1"

    def __post_init__(self) -> None:
        if self.channel_type not in _INJECTION_POINTS:
            raise ValueError("channel_type is unsupported.")
        if not isinstance(self.channel_id, str) or not self.channel_id.strip():
            raise ValueError("channel_id must be a non-empty string.")
        targets = self.targets
        if targets != "all" and not isinstance(targets, tuple):
            raise TypeError("targets must be 'all' or a tuple of identifiers.")
        if targets != "all" and (
            not targets
            or len(set(targets)) != len(targets)
            or any(not isinstance(target, str) or not target for target in targets)
        ):
            raise ValueError("targets must be 'all' or unique non-empty identifiers.")
        if self.channel_type == "crosstalk" and (
            targets == "all" or len(targets) < 2
        ):
            raise ValueError("crosstalk requires at least two explicit targets.")
        expected_model = _MODELS[self.channel_type]
        expected_point = _INJECTION_POINTS[self.channel_type]
        model = expected_model if not self.model else self.model
        point = expected_point if not self.injection_point else self.injection_point
        if model != expected_model:
            raise ValueError(f"{self.channel_type} model must be {expected_model}.")
        if point != expected_point:
            raise ValueError(
                f"{self.channel_type} injection_point must be {expected_point}."
            )
        parameters = {str(key): float(value) for key, value in self.parameters.items()}
        if any(not math.isfinite(value) for value in parameters.values()):
            raise ValueError("noise parameters must be finite.")
        _validate_channel_parameters(self.channel_type, parameters, self.schedule_ref)
        if set(self.units) != set(parameters) or any(
            not isinstance(unit, str) or not unit.strip()
            for unit in self.units.values()
        ):
            raise ValueError("units must define every noise parameter exactly once.")
        if not isinstance(self.source, str) or not self.source.strip():
            raise ValueError("source must be a non-empty string.")
        object.__setattr__(self, "parameters", parameters)
        object.__setattr__(self, "units", dict(self.units))
        object.__setattr__(self, "model", model)
        object.__setattr__(self, "injection_point", point)
        object.__setattr__(self, "metadata", dict(self.metadata))

    @classmethod
    def preparation(
        cls,
        probability: float,
        *,
        targets: NoiseTargets = "all",
        channel_id: str = "noise.preparation",
        source: str = "user",
    ) -> NoiseChannel:
        return cls._probability_channel(
            "preparation", probability, targets, channel_id, source
        )

    @classmethod
    def dephasing(
        cls,
        rate: float,
        *,
        targets: NoiseTargets = "all",
        channel_id: str = "noise.dephasing",
        source: str = "user",
    ) -> NoiseChannel:
        return cls(
            channel_id=channel_id,
            channel_type="dephasing",
            parameters={"rate": rate},
            units={"rate": "1/us"},
            targets=targets,
            source=source,
        )

    @classmethod
    def gate(
        cls,
        probability: float,
        *,
        targets: NoiseTargets = "all",
        channel_id: str = "noise.gate",
        source: str = "user",
    ) -> NoiseChannel:
        return cls._probability_channel(
            "gate", probability, targets, channel_id, source
        )

    @classmethod
    def idle(
        cls,
        rate: float,
        *,
        duration: float,
        targets: NoiseTargets = "all",
        channel_id: str = "noise.idle",
        source: str = "user",
    ) -> NoiseChannel:
        return cls(
            channel_id=channel_id,
            channel_type="idle",
            parameters={"rate": rate, "duration": duration},
            units={"rate": "1/us", "duration": "us"},
            targets=targets,
            source=source,
        )

    @classmethod
    def crosstalk(
        cls,
        coupling: float,
        *,
        duration: float,
        targets: tuple[str, ...],
        schedule_ref: str,
        channel_id: str = "noise.crosstalk",
        source: str = "user",
    ) -> NoiseChannel:
        return cls(
            channel_id=channel_id,
            channel_type="crosstalk",
            parameters={"coupling": coupling, "duration": duration},
            units={"coupling": "rad/us", "duration": "us"},
            targets=targets,
            source=source,
            schedule_ref=schedule_ref,
        )

    @classmethod
    def boundary(
        cls,
        probability: float,
        *,
        targets: NoiseTargets = "all",
        channel_id: str = "noise.boundary",
        source: str = "user",
    ) -> NoiseChannel:
        return cls._probability_channel(
            "boundary", probability, targets, channel_id, source
        )

    @classmethod
    def atom_loss(
        cls,
        probability: float,
        *,
        targets: NoiseTargets = "all",
        channel_id: str = "noise.atom_loss",
        source: str = "user",
    ) -> NoiseChannel:
        return cls._probability_channel(
            "atom_loss", probability, targets, channel_id, source
        )

    @classmethod
    def readout(
        cls,
        p01: float,
        *,
        p10: float | None = None,
        targets: NoiseTargets = "all",
        channel_id: str = "noise.readout",
        source: str = "user",
    ) -> NoiseChannel:
        return cls(
            channel_id=channel_id,
            channel_type="readout",
            parameters={"p01": p01, "p10": p01 if p10 is None else p10},
            units={"p01": "probability", "p10": "probability"},
            targets=targets,
            source=source,
        )

    @classmethod
    def _probability_channel(
        cls,
        channel_type: NoiseChannelType,
        probability: float,
        targets: NoiseTargets,
        channel_id: str,
        source: str,
    ) -> NoiseChannel:
        return cls(
            channel_id=channel_id,
            channel_type=channel_type,
            parameters={"probability": probability},
            units={"probability": "probability"},
            targets=targets,
            source=source,
        )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> NoiseChannel:
        targets = data.get("targets", "all")
        return cls(
            channel_id=str(data["channel_id"]),
            channel_type=data["channel_type"],
            parameters=dict(data["parameters"]),
            units={str(key): str(value) for key, value in data["units"].items()},
            targets=(
                "all" if targets == "all" else tuple(str(item) for item in targets)
            ),
            model=str(data.get("model", "")),
            injection_point=str(data.get("injection_point", "")),
            source=str(data.get("source", "user")),
            schedule_ref=data.get("schedule_ref"),
            metadata=dict(data.get("metadata", {})),
            schema_version=str(
                data.get("schema_version", "cascaqit.noise.physical.v1")
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> NoiseChannel:
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("NoiseChannel JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class NoiseModel(IRMixin):
    """Canonical executable physical noise model used by Backend.run(noise=...)."""

    noise_model_id: str
    channels: tuple[NoiseChannel, ...]
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = "cascaqit.noise.physical.v1"

    def __post_init__(self) -> None:
        if not isinstance(self.noise_model_id, str) or not self.noise_model_id.strip():
            raise ValueError("noise_model_id must be a non-empty string.")
        channels = tuple(self.channels)
        if not channels or any(
            not isinstance(channel, NoiseChannel) for channel in self.channels
        ):
            raise ValueError("channels must contain at least one NoiseChannel.")
        ids = tuple(channel.channel_id for channel in channels)
        kinds = tuple(channel.channel_type for channel in channels)
        if len(set(ids)) != len(ids):
            raise ValueError("noise channel identifiers must be unique.")
        if len(set(kinds)) != len(kinds):
            raise ValueError("canonical NoiseModel accepts one channel per type.")
        object.__setattr__(self, "channels", channels)
        object.__setattr__(self, "metadata", dict(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> NoiseModel:
        return cls(
            noise_model_id=str(data["noise_model_id"]),
            channels=tuple(
                NoiseChannel.from_dict(item) for item in data.get("channels", ())
            ),
            metadata=dict(data.get("metadata", {})),
            schema_version=str(
                data.get("schema_version", "cascaqit.noise.physical.v1")
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> NoiseModel:
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("NoiseModel JSON must contain an object.")
        return cls.from_dict(data)

    def channel(self, channel_type: NoiseChannelType) -> NoiseChannel | None:
        return next(
            (item for item in self.channels if item.channel_type == channel_type),
            None,
        )

    @property
    def requires_trajectory(self) -> bool:
        return self.channel("atom_loss") is not None

    def validate_for(
        self,
        logical_order: tuple[str, ...],
        *,
        has_digital: bool,
        has_analog: bool,
        is_hybrid: bool,
    ) -> None:
        """Fail before state allocation when physical prerequisites are missing."""
        for channel in self.channels:
            _resolve_targets(channel, logical_order)
            if channel.channel_type in {"gate", "idle"} and not has_digital:
                _noise_prerequisite_error(channel, "a Digital block")
            if channel.channel_type in {"dephasing", "atom_loss"} and not has_analog:
                _noise_prerequisite_error(channel, "an Analog block")
            if channel.channel_type == "boundary" and not is_hybrid:
                _noise_prerequisite_error(channel, "at least two Hybrid blocks")


@dataclass(frozen=True)
class NoiseApplicationRecord(IRMixin):
    """One auditable physical or measurement-model injection."""

    channel_id: str
    channel_type: NoiseChannelType
    injection_point: str
    truthfulness: NoiseTruthfulness
    input_state_hash: str
    output_state_hash: str
    targets: tuple[str, ...]
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not isinstance(self.channel_id, str) or not self.channel_id.strip():
            raise ValueError("channel_id must be a non-empty string.")
        if self.channel_type not in _INJECTION_POINTS:
            raise ValueError("channel_type is unsupported.")
        if self.injection_point != _INJECTION_POINTS[self.channel_type]:
            raise ValueError("injection_point does not match channel_type.")
        if self.truthfulness not in {
            "physical_state_evolution",
            "measurement_model_only",
        }:
            raise ValueError("truthfulness is unsupported.")
        for name in ("input_state_hash", "output_state_hash"):
            value = getattr(self, name)
            if (
                not isinstance(value, str)
                or len(value) != 64
                or any(character not in "0123456789abcdef" for character in value)
            ):
                raise ValueError(f"{name} must be a lowercase SHA-256 digest.")
        targets = tuple(self.targets)
        if not targets or len(targets) != len(set(targets)):
            raise ValueError("targets must contain unique logical identifiers.")
        if any(not isinstance(target, str) or not target for target in targets):
            raise ValueError("targets must contain non-empty strings.")
        object.__setattr__(self, "targets", targets)
        object.__setattr__(self, "metadata", dict(self.metadata))

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> NoiseApplicationRecord:
        """Restore one applied-channel record from Result metadata."""
        return cls(
            channel_id=str(data["channel_id"]),
            channel_type=data["channel_type"],
            injection_point=str(data["injection_point"]),
            truthfulness=data["truthfulness"],
            input_state_hash=str(data["input_state_hash"]),
            output_state_hash=str(data["output_state_hash"]),
            targets=tuple(str(target) for target in data.get("targets", ())),
            metadata=dict(data.get("metadata", {})),
        )


@dataclass(frozen=True)
class NoiseReport(IRMixin):
    """Complete ordered record of every applied canonical noise channel."""

    noise_model_id: str
    noise_model_hash: str
    method: Literal["density_matrix", "trajectory"]
    records: tuple[NoiseApplicationRecord, ...]
    applied_channel_types: tuple[NoiseChannelType, ...]
    physical_application_count: int
    measurement_application_count: int
    truthfulness: NoiseTruthfulness

    def __post_init__(self) -> None:
        if not isinstance(self.noise_model_id, str) or not self.noise_model_id.strip():
            raise ValueError("noise_model_id must be a non-empty string.")
        if (
            not isinstance(self.noise_model_hash, str)
            or len(self.noise_model_hash) != 64
            or any(
                character not in "0123456789abcdef"
                for character in self.noise_model_hash
            )
        ):
            raise ValueError("noise_model_hash must be a lowercase SHA-256 digest.")
        if self.method not in {"density_matrix", "trajectory"}:
            raise ValueError("method must be density_matrix or trajectory.")
        records = tuple(self.records)
        if not records or any(
            not isinstance(record, NoiseApplicationRecord) for record in records
        ):
            raise ValueError("records must contain applied noise evidence.")
        derived_types = tuple(dict.fromkeys(record.channel_type for record in records))
        if tuple(self.applied_channel_types) != derived_types:
            raise ValueError("applied_channel_types must match record order.")
        physical_count = sum(
            record.truthfulness == "physical_state_evolution" for record in records
        )
        measurement_count = len(records) - physical_count
        if self.physical_application_count != physical_count:
            raise ValueError("physical_application_count must match records.")
        if self.measurement_application_count != measurement_count:
            raise ValueError("measurement_application_count must match records.")
        expected_truthfulness: NoiseTruthfulness = (
            "physical_state_evolution"
            if physical_count
            else "measurement_model_only"
        )
        if self.truthfulness != expected_truthfulness:
            raise ValueError("truthfulness must match applied record types.")
        object.__setattr__(self, "records", records)
        object.__setattr__(self, "applied_channel_types", derived_types)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> NoiseReport:
        """Restore and revalidate a complete physical-noise report."""
        return cls(
            noise_model_id=str(data["noise_model_id"]),
            noise_model_hash=str(data["noise_model_hash"]),
            method=data["method"],
            records=tuple(
                NoiseApplicationRecord.from_dict(record)
                for record in data.get("records", ())
            ),
            applied_channel_types=tuple(data.get("applied_channel_types", ())),
            physical_application_count=data["physical_application_count"],
            measurement_application_count=data["measurement_application_count"],
            truthfulness=data["truthfulness"],
        )


def apply_density_noise_channel(
    state: DensityMatrixState,
    channel: NoiseChannel,
) -> DensityMatrixState:
    """Apply one finite CPTP state channel to a density matrix."""
    targets = _resolve_targets(channel, state.logical_order)
    kind = channel.channel_type
    if kind in {"preparation", "gate"}:
        return _density_pauli(
            state,
            probability=channel.parameters["probability"],
            targets=targets,
            pauli="x",
            channel=channel,
        )
    if kind == "idle":
        probability = _dephasing_probability(
            channel.parameters["rate"], channel.parameters["duration"]
        )
        output = _density_pauli(
            state,
            probability=probability,
            targets=targets,
            pauli="z",
            channel=channel,
        )
        return _advance_density_time(
            output,
            channel.parameters["duration"],
            channel_id=channel.channel_id,
        )
    if kind == "crosstalk":
        operator = _coherent_xx_operator(
            len(targets),
            channel.parameters["coupling"] * channel.parameters["duration"],
            dtype=state.rho.dtype,
        )
        return apply_density_kraus_channel(
            state,
            (operator,),
            targets=targets,
            channel_id=channel.channel_id,
        )
    if kind == "boundary":
        result = state
        probability = channel.parameters["probability"]
        for target in targets:
            dtype = result.rho.dtype
            operators = (
                np.asarray(
                    ((1.0, 0.0), (0.0, math.sqrt(1.0 - probability))),
                    dtype=dtype,
                ),
                np.asarray(
                    ((0.0, math.sqrt(probability)), (0.0, 0.0)),
                    dtype=dtype,
                ),
            )
            result = apply_density_kraus_channel(
                result,
                operators,
                targets=(target,),
                channel_id=channel.channel_id,
            )
        return result
    if kind == "atom_loss":
        raise CapabilityError(
            "DensityMatrixState has no vacuum occupation axis for atom loss.",
            code="NOISE_ATOM_LOSS_REQUIRES_TRAJECTORY",
            stage="simulation",
            object_path=f"noise.channels.{channel.channel_id}",
            suggestion="Use SimulationOptions(method='trajectory').",
            metadata={"large_array_allocated": False},
        )
    raise ValueError(f"{kind} is integrated elsewhere and is not a finite state map.")


def apply_trajectory_noise_channel(
    state: TrajectoryBatchState,
    channel: NoiseChannel,
) -> TrajectoryBatchState:
    """Apply one finite stochastic state channel to a trajectory batch."""
    targets = _resolve_targets(channel, state.logical_order)
    kind = channel.channel_type
    if kind in {"preparation", "gate"}:
        return apply_trajectory_pauli_channel(
            state,
            probability=channel.parameters["probability"],
            targets=targets,
            pauli="x",
            channel_id=channel.channel_id,
        )
    if kind == "idle":
        return apply_trajectory_pauli_channel(
            state,
            probability=_dephasing_probability(
                channel.parameters["rate"], channel.parameters["duration"]
            ),
            targets=targets,
            pauli="z",
            channel_id=channel.channel_id,
            logical_time_advance=channel.parameters["duration"],
        )
    if kind == "crosstalk":
        operator = _coherent_xx_operator(
            len(targets),
            channel.parameters["coupling"] * channel.parameters["duration"],
            dtype=state.amplitudes.dtype,
        )
        return apply_trajectory_unitary_channel(
            state,
            operator,
            targets=targets,
            channel_id=channel.channel_id,
        )
    if kind == "boundary":
        return apply_trajectory_amplitude_damping(
            state,
            probability=channel.parameters["probability"],
            targets=targets,
            channel_id=channel.channel_id,
        )
    if kind == "atom_loss":
        return apply_trajectory_atom_loss(
            state,
            probability=channel.parameters["probability"],
            targets=targets,
            channel_id=channel.channel_id,
        )
    raise ValueError(f"{kind} is integrated elsewhere and is not a finite state map.")


def run_physical_noisy_hybrid(
    bundle: LocalExecutionBundle,
    noise_model: NoiseModel,
    *,
    method: Literal["density_matrix", "trajectory"],
    dtype: ArrayDType,
    trajectories: int,
    steps: int,
    chunk_size: int,
    workers: int,
    blockade_radius: float,
    target_id: str,
    return_probabilities: bool,
    observables: ObservableSet | None = None,
    integrator_requested: SimulationIntegrator = "fixed_step_krylov",
    integrator_selected: SelectedSimulationIntegrator = "fixed_step_krylov",
    rtol: float = 1e-9,
    atol: float = 1e-11,
    max_steps: int = 10_000,
) -> ResultIR:
    """Execute canonical physical channels over one continuous Hybrid state."""
    validate_physical_noise_bundle(bundle, noise_model, method=method)
    _validate_integrator_selection(
        bundle,
        method=method,
        integrator_requested=integrator_requested,
        integrator_selected=integrator_selected,
    )
    if method == "density_matrix":
        return _run_density_hybrid(
            bundle,
            noise_model,
            dtype=dtype,
            steps=steps,
            blockade_radius=blockade_radius,
            target_id=target_id,
            return_probabilities=return_probabilities,
            observables=observables,
            integrator_requested=integrator_requested,
            integrator_selected=integrator_selected,
            rtol=rtol,
            atol=atol,
            max_steps=max_steps,
        )
    return _run_trajectory_hybrid(
        bundle,
        noise_model,
        dtype=dtype,
        trajectories=trajectories,
        steps=steps,
        chunk_size=chunk_size,
        workers=workers,
        blockade_radius=blockade_radius,
        target_id=target_id,
        return_probabilities=return_probabilities,
        observables=observables,
        integrator_requested=integrator_requested,
        integrator_selected=integrator_selected,
    )


def _validate_integrator_selection(
    bundle: LocalExecutionBundle,
    *,
    method: Literal["density_matrix", "trajectory"],
    integrator_requested: SimulationIntegrator,
    integrator_selected: SelectedSimulationIntegrator,
) -> None:
    has_analog = any(
        isinstance(payload, AnalogStepPayload) for payload in bundle.payloads[:-1]
    )
    if has_analog == (integrator_selected == "not_applicable"):
        raise ProgramValidationError(
            "Integrator selection does not match executable Analog work.",
            code="SIMULATION_INTEGRATOR_SELECTION_MISMATCH",
            stage="simulation",
            object_path="simulation_plan.integrator_selected",
        )
    if (
        method == "trajectory"
        and has_analog
        and integrator_selected != "fixed_step_krylov"
    ):
        raise ProgramValidationError(
            "Trajectory execution requires fixed_step_krylov.",
            code="SIMULATION_INTEGRATOR_INAPPLICABLE",
            stage="simulation",
            object_path="simulation_plan.integrator_selected",
        )
    if (
        integrator_requested != "auto"
        and integrator_selected != integrator_requested
    ):
        raise ProgramValidationError(
            "Explicit integrator request changed before execution.",
            code="SIMULATION_INTEGRATOR_SELECTION_MISMATCH",
            stage="simulation",
            object_path="simulation_plan.integrator_selected",
        )


def validate_physical_noise_bundle(
    bundle: LocalExecutionBundle,
    noise_model: NoiseModel,
    *,
    method: Literal["density_matrix", "trajectory"],
) -> None:
    """Validate all physical prerequisites without allocating a simulation state."""
    validate_scalable_hybrid_bundle(bundle)
    measurement = cast(MeasurementStepPayload, bundle.payloads[-1])
    has_digital = any(
        isinstance(payload, DigitalStepPayload) for payload in bundle.payloads[:-1]
    )
    has_analog = any(
        isinstance(payload, AnalogStepPayload) for payload in bundle.payloads[:-1]
    )
    noise_model.validate_for(
        measurement.logical_order,
        has_digital=has_digital,
        has_analog=has_analog,
        is_hybrid=len(bundle.payloads[:-1]) > 1,
    )
    gate_channel = noise_model.channel("gate")
    gate_count = sum(
        len(payload.program.circuit.gates)
        for payload in bundle.payloads[:-1]
        if isinstance(payload, DigitalStepPayload)
    )
    if gate_channel is not None and gate_count == 0:
        _noise_prerequisite_error(gate_channel, "at least one Digital gate")
    # schedule_ref is resolved against executable block ids before any state exists.
    crosstalk = noise_model.channel("crosstalk")
    valid_schedule_refs = {
        payload.block_id for payload in bundle.payloads[:-1]
    } | {"all_control_blocks"}
    if crosstalk is not None and crosstalk.schedule_ref not in valid_schedule_refs:
        _noise_prerequisite_error(
            crosstalk,
            "a matching block_id schedule_ref or 'all_control_blocks'",
            code="NOISE_CONTROL_SCHEDULE_UNKNOWN",
        )
    if method == "density_matrix" and noise_model.requires_trajectory:
        _noise_prerequisite_error(
            cast(NoiseChannel, noise_model.channel("atom_loss")),
            "trajectory occupation state",
            code="NOISE_ATOM_LOSS_REQUIRES_TRAJECTORY",
        )


def _run_density_hybrid(
    bundle: LocalExecutionBundle,
    noise_model: NoiseModel,
    *,
    dtype: ArrayDType,
    steps: int,
    blockade_radius: float,
    target_id: str,
    return_probabilities: bool,
    observables: ObservableSet | None,
    integrator_requested: SimulationIntegrator,
    integrator_selected: SelectedSimulationIntegrator,
    rtol: float,
    atol: float,
    max_steps: int,
) -> ResultIR:
    measurement = cast(MeasurementStepPayload, bundle.payloads[-1])
    state = zero_density_matrix(measurement.logical_order, dtype=dtype)
    initial_state = state
    kernel = ExactDensityMatrixKernel(
        steps=steps,
        blockade_radius=blockade_radius,
        integrator_requested=integrator_requested,
        integrator_selected=(
            "fixed_step_krylov"
            if integrator_selected == "not_applicable"
            else integrator_selected
        ),
        rtol=rtol,
        atol=atol,
        max_steps=max_steps,
    )
    records: list[NoiseApplicationRecord] = []
    transitions: list[StateTransitionIR] = []
    solver_evidences: list[SimulationSolverEvidenceIR] = []
    state = _apply_density_at(state, noise_model, "preparation", records)
    payloads = bundle.payloads[:-1]
    for payload_index, raw_payload in enumerate(payloads):
        payload = cast(Union[DigitalStepPayload, AnalogStepPayload], raw_payload)
        input_state = initial_state if payload_index == 0 else state
        site_addressing: dict[str, Any] | None = None
        site_phase_pattern: dict[str, Any] | None = None
        solver_evidence: SimulationSolverEvidenceIR | None = None
        # Gate maps occur per gate; idle follows the block; boundary remains between
        # blocks. This ordering is part of the physical contract and report trace.
        if isinstance(payload, DigitalStepPayload):
            for gate in payload.program.circuit.gates:
                state = kernel.evolve_digital(
                    _single_gate(payload.program, gate), state
                )
                state = _apply_density_at(
                    state,
                    noise_model,
                    "gate",
                    records,
                    active_targets=gate.targets,
                )
            state = _apply_density_at(state, noise_model, "idle", records)
            solver_evidence = not_applicable_solver_evidence(
                integrator_requested=integrator_requested,
                logical_time=state.logical_time,
                time_unit=state.time_unit,
                consumer="ExactDensityMatrixKernel.digital",
            )
        else:
            analog = payload
            dephasing = noise_model.channel("dephasing")
            before = state
            state = kernel.evolve_analog(
                analog.program,
                state,
                dephasing_rate=(
                    0.0 if dephasing is None else dephasing.parameters["rate"]
                ),
                dephasing_targets=(
                    None
                    if dephasing is None
                    else _resolve_targets(dephasing, state.logical_order)
                ),
            )
            solver_evidence = solver_evidence_from_provenance(
                state.provenance.metadata,
                object_path=(
                    f"bundle.payloads[{payload_index}].provenance.solver_evidence"
                ),
            )
            solver_evidences.append(solver_evidence)
            raw_addressing = state.provenance.metadata.get("site_addressing")
            if isinstance(raw_addressing, dict):
                site_addressing = raw_addressing
            raw_phase_pattern = state.provenance.metadata.get("site_phase_pattern")
            if isinstance(raw_phase_pattern, dict):
                site_phase_pattern = raw_phase_pattern
            if dephasing is not None:
                records.append(_record(dephasing, before, state))
            state = _apply_density_at(state, noise_model, "atom_loss", records)
        state = _apply_density_at(
            state,
            noise_model,
            "crosstalk",
            records,
            schedule_ref=payload.block_id,
        )
        if payload_index < len(payloads) - 1:
            state = _apply_density_at(state, noise_model, "boundary", records)
        transitions.append(
            _density_transition(
                payload,
                input_state,
                state,
                order_index=payload_index,
                site_addressing=site_addressing,
                site_phase_pattern=site_phase_pattern,
                solver_evidence=solver_evidence,
            )
        )
    aggregate_evidence = aggregate_solver_evidence(
        solver_evidences,
        integrator_requested=integrator_requested,
        integrator_selected=integrator_selected,
        aggregation_scope="physical_density_hybrid_blocks",
    )
    return _build_density_result(
        bundle,
        state,
        noise_model,
        records,
        transitions,
        initial_state_hash=initial_state.stable_hash(),
        target_id=target_id,
        return_probabilities=return_probabilities,
        requested_observables=observables,
        solver_evidence=aggregate_evidence,
    )


def _run_trajectory_hybrid(
    bundle: LocalExecutionBundle,
    noise_model: NoiseModel,
    *,
    dtype: ArrayDType,
    trajectories: int,
    steps: int,
    chunk_size: int,
    workers: int,
    blockade_radius: float,
    target_id: str,
    return_probabilities: bool,
    observables: ObservableSet | None,
    integrator_requested: SimulationIntegrator,
    integrator_selected: SelectedSimulationIntegrator,
) -> ResultIR:
    measurement = cast(MeasurementStepPayload, bundle.payloads[-1])
    state = zero_trajectory_batch(
        measurement.logical_order,
        trajectories,
        seed=cast(int, measurement.seed),
        dtype=dtype,
    )
    initial_state = state
    kernel = BatchedTrajectoryKernel(
        steps=steps,
        blockade_radius=blockade_radius,
        chunk_size=chunk_size,
        workers=workers,
    )
    records: list[NoiseApplicationRecord] = []
    transitions: list[StateTransitionIR] = []
    solver_evidences: list[SimulationSolverEvidenceIR] = []
    state = _apply_trajectory_at(state, noise_model, "preparation", records)
    payloads = bundle.payloads[:-1]
    for payload_index, raw_payload in enumerate(payloads):
        payload = cast(Union[DigitalStepPayload, AnalogStepPayload], raw_payload)
        input_state = initial_state if payload_index == 0 else state
        site_addressing: dict[str, Any] | None = None
        site_phase_pattern: dict[str, Any] | None = None
        input_hashes = trajectory_hashes(input_state)
        solver_evidence: SimulationSolverEvidenceIR | None = None
        if isinstance(payload, DigitalStepPayload):
            for gate in payload.program.circuit.gates:
                state = kernel.evolve_digital(
                    _single_gate(payload.program, gate), state
                )
                state = _apply_trajectory_at(
                    state,
                    noise_model,
                    "gate",
                    records,
                    active_targets=gate.targets,
                )
            state = _apply_trajectory_at(state, noise_model, "idle", records)
            solver_evidence = not_applicable_solver_evidence(
                integrator_requested=integrator_requested,
                logical_time=state.logical_time,
                time_unit=state.time_unit,
                consumer="BatchedTrajectoryKernel.digital",
            )
        else:
            analog = payload
            dephasing = noise_model.channel("dephasing")
            before = state
            state = kernel.evolve_analog(
                analog.program,
                state,
                dephasing_rate=(
                    0.0 if dephasing is None else dephasing.parameters["rate"]
                ),
                dephasing_targets=(
                    None
                    if dephasing is None
                    else _resolve_targets(dephasing, state.logical_order)
                ),
            )
            solver_evidence = fixed_step_solver_evidence(
                integrator_requested=integrator_requested,
                steps=steps,
                duration=_duration(analog.program),
                logical_time_offset=input_state.logical_time,
                time_unit=input_state.time_unit,
                algorithm="batched_trajectory_krylov",
            )
            solver_evidences.append(solver_evidence)
            raw_addressing = state.provenance.metadata.get("site_addressing")
            if isinstance(raw_addressing, dict):
                site_addressing = raw_addressing
            raw_phase_pattern = state.provenance.metadata.get("site_phase_pattern")
            if isinstance(raw_phase_pattern, dict):
                site_phase_pattern = raw_phase_pattern
            if dephasing is not None:
                records.append(_record(dephasing, before, state))
            state = _apply_trajectory_at(state, noise_model, "atom_loss", records)
        state = _apply_trajectory_at(
            state,
            noise_model,
            "crosstalk",
            records,
            schedule_ref=payload.block_id,
        )
        if payload_index < len(payloads) - 1:
            state = _apply_trajectory_at(state, noise_model, "boundary", records)
        transition_metadata: dict[str, Any] = {
            "payload_id": payload.payload_id,
            "payload_hash": payload.stable_hash(),
            "logical_order": list(state.logical_order),
            "input_trajectory_hashes": list(input_hashes),
            "output_trajectory_hashes": list(trajectory_hashes(state)),
        }
        if site_addressing is not None:
            transition_metadata["site_addressing"] = site_addressing
        if site_phase_pattern is not None:
            transition_metadata["site_phase_pattern"] = site_phase_pattern
        if state.logical_time > input_state.logical_time and isinstance(
            payload, DigitalStepPayload
        ):
            transition_metadata["time_advance_source"] = "noise_model"
        transitions.append(
            build_state_transition(
                transition_id=f"transition.{payload_index}.{payload.block_id}",
                order_index=payload_index,
                block_id=payload.block_id,
                program_kind=payload.payload_kind,
                program_hash=payload.program.stable_hash(),
                kernel=(
                    "BatchedTrajectoryKernel.digital"
                    if isinstance(payload, DigitalStepPayload)
                    else "BatchedTrajectoryKernel.analog"
                ),
                input_state_hash=input_state.stable_hash(),
                output_state_hash=state.stable_hash(),
                input_logical_time=input_state.logical_time,
                output_logical_time=state.logical_time,
                time_unit=state.time_unit,
                solver_evidence=solver_evidence,
                metadata=transition_metadata,
            )
        )
    aggregate_evidence = aggregate_solver_evidence(
        solver_evidences,
        integrator_requested=integrator_requested,
        integrator_selected=integrator_selected,
        aggregation_scope="physical_trajectory_hybrid_blocks",
    )
    return _build_trajectory_result(
        bundle,
        state,
        noise_model,
        records,
        transitions,
        initial_state_hash=initial_state.stable_hash(),
        target_id=target_id,
        return_probabilities=return_probabilities,
        requested_observables=observables,
        solver_evidence=aggregate_evidence,
    )


def _apply_density_at(
    state: DensityMatrixState,
    model: NoiseModel,
    channel_type: NoiseChannelType,
    records: list[NoiseApplicationRecord],
    schedule_ref: str | None = None,
    active_targets: tuple[str, ...] | None = None,
) -> DensityMatrixState:
    channel = model.channel(channel_type)
    if channel is None:
        return state
    channel = _active_channel(channel, state.logical_order, active_targets)
    if channel is None:
        return state
    if channel_type == "crosstalk" and channel.schedule_ref not in {
        schedule_ref,
        "all_control_blocks",
    }:
        return state
    output = apply_density_noise_channel(state, channel)
    records.append(_record(channel, state, output))
    return output


def _apply_trajectory_at(
    state: TrajectoryBatchState,
    model: NoiseModel,
    channel_type: NoiseChannelType,
    records: list[NoiseApplicationRecord],
    schedule_ref: str | None = None,
    active_targets: tuple[str, ...] | None = None,
) -> TrajectoryBatchState:
    channel = model.channel(channel_type)
    if channel is None:
        return state
    channel = _active_channel(channel, state.logical_order, active_targets)
    if channel is None:
        return state
    if channel_type == "crosstalk" and channel.schedule_ref not in {
        schedule_ref,
        "all_control_blocks",
    }:
        return state
    output = apply_trajectory_noise_channel(state, channel)
    records.append(_record(channel, state, output))
    return output


def _record(
    channel: NoiseChannel,
    input_state: DensityMatrixState | TrajectoryBatchState,
    output_state: DensityMatrixState | TrajectoryBatchState,
) -> NoiseApplicationRecord:
    return NoiseApplicationRecord(
        channel_id=channel.channel_id,
        channel_type=channel.channel_type,
        injection_point=channel.injection_point,
        truthfulness="physical_state_evolution",
        input_state_hash=input_state.stable_hash(),
        output_state_hash=output_state.stable_hash(),
        targets=_resolve_targets(channel, input_state.logical_order),
        metadata={
            "model": channel.model,
            "parameters": channel.parameters,
            "schedule_ref": channel.schedule_ref,
        },
    )


def _build_density_result(
    bundle: LocalExecutionBundle,
    state: DensityMatrixState,
    model: NoiseModel,
    records: list[NoiseApplicationRecord],
    transitions: list[StateTransitionIR],
    *,
    initial_state_hash: str,
    target_id: str,
    return_probabilities: bool,
    requested_observables: ObservableSet | None,
    solver_evidence: SimulationSolverEvidenceIR,
) -> ResultIR:
    probabilities = np.array(np.diag(state.rho).real, dtype=np.float64, copy=True)
    probabilities /= np.sum(probabilities)
    observable_batch = (
        None
        if requested_observables is None
        else evaluate_observables(state, requested_observables)
    )
    result = _sample_result(
        bundle,
        state_hash=state.stable_hash(),
        state_summary=state.to_dict(),
        logical_order=state.logical_order,
        probabilities=probabilities,
        occupations=None,
        model=model,
        records=records,
        transitions=transitions,
        initial_state_hash=initial_state_hash,
        method="density_matrix",
        target_id=target_id,
        return_probabilities=return_probabilities,
        observables={
            "trace": state.trace,
            "purity": state.purity,
            "minimum_eigenvalue": state.minimum_eigenvalue,
        },
        observable_batch=observable_batch,
    )
    return replace(
        result,
        metadata={**result.metadata, **solver_evidence_metadata(solver_evidence)},
    )


def _build_trajectory_result(
    bundle: LocalExecutionBundle,
    state: TrajectoryBatchState,
    model: NoiseModel,
    records: list[NoiseApplicationRecord],
    transitions: list[StateTransitionIR],
    *,
    initial_state_hash: str,
    target_id: str,
    return_probabilities: bool,
    requested_observables: ObservableSet | None,
    solver_evidence: SimulationSolverEvidenceIR,
) -> ResultIR:
    per_trajectory = np.abs(state.amplitudes) ** 2
    probabilities = np.mean(per_trajectory, axis=0)
    probabilities /= np.sum(probabilities)
    first_site = np.arange(state.dimension) >= state.dimension // 2
    values = np.sum(per_trajectory[:, first_site], axis=1)
    standard_error = float(np.std(values, ddof=1) / math.sqrt(state.trajectory_count))
    observable_batch = (
        None
        if requested_observables is None
        else evaluate_observables(state, requested_observables)
    )
    result = _sample_result(
        bundle,
        state_hash=state.stable_hash(),
        state_summary=state.to_dict(),
        logical_order=state.logical_order,
        probabilities=probabilities,
        occupations=state.occupations,
        trajectory_probabilities=per_trajectory,
        model=model,
        records=records,
        transitions=transitions,
        initial_state_hash=initial_state_hash,
        method="trajectory",
        target_id=target_id,
        return_probabilities=return_probabilities,
        observables={
            "first_site_excitation_probability": float(np.mean(values)),
            "first_site_excitation_standard_error": standard_error,
            "first_site_excitation_ci95_low": max(
                0.0, float(np.mean(values)) - 1.96 * standard_error
            ),
            "first_site_excitation_ci95_high": min(
                1.0, float(np.mean(values)) + 1.96 * standard_error
            ),
        },
        observable_batch=observable_batch,
    )
    return replace(
        result,
        metadata={**result.metadata, **solver_evidence_metadata(solver_evidence)},
    )


def _sample_result(
    bundle: LocalExecutionBundle,
    *,
    state_hash: str,
    state_summary: dict[str, Any],
    logical_order: tuple[str, ...],
    probabilities: np.ndarray[Any, Any],
    occupations: np.ndarray[Any, Any] | None,
    model: NoiseModel,
    records: list[NoiseApplicationRecord],
    transitions: list[StateTransitionIR],
    initial_state_hash: str,
    method: Literal["density_matrix", "trajectory"],
    target_id: str,
    return_probabilities: bool,
    observables: dict[str, Any],
    observable_batch: ObservableBatchResultIR | None,
    trajectory_probabilities: np.ndarray[Any, Any] | None = None,
) -> ResultIR:
    measurement = cast(MeasurementStepPayload, bundle.payloads[-1])
    rng = np.random.default_rng(measurement.seed)
    width = len(logical_order)
    samples: list[str] = []
    for _ in range(measurement.shots):
        if trajectory_probabilities is None:
            basis_index = int(rng.choice(probabilities.size, p=probabilities))
            sample = list(format(basis_index, f"0{width}b"))
        else:
            # Sampling a trajectory before its basis state preserves correlation
            # between stochastic amplitudes and that trajectory's loss occupations.
            trajectory_index = int(rng.integers(trajectory_probabilities.shape[0]))
            basis_index = int(
                rng.choice(
                    probabilities.size,
                    p=trajectory_probabilities[trajectory_index],
                )
            )
            sample = list(format(basis_index, f"0{width}b"))
            assert occupations is not None
            for axis, occupied in enumerate(occupations[trajectory_index]):
                if not occupied:
                    sample[axis] = "x"
        samples.append("".join(sample))
    readout = model.channel("readout")
    if readout is not None:
        before_counts = dict(Counter(samples))
        samples = _apply_readout(samples, logical_order, readout, rng)
        after_counts = dict(Counter(samples))
        records.append(
            NoiseApplicationRecord(
                channel_id=readout.channel_id,
                channel_type="readout",
                injection_point=readout.injection_point,
                truthfulness="measurement_model_only",
                input_state_hash=state_hash,
                output_state_hash=state_hash,
                targets=_resolve_targets(readout, logical_order),
                metadata={
                    "model": readout.model,
                    "parameters": readout.parameters,
                    "counts_modified": before_counts != after_counts,
                },
            )
        )
    counts = dict(Counter(samples))
    physical_count = sum(
        item.truthfulness == "physical_state_evolution" for item in records
    )
    measurement_count = len(records) - physical_count
    # A readout-only model never upgrades itself to physical state evolution.
    truthfulness: NoiseTruthfulness = (
        "physical_state_evolution" if physical_count else "measurement_model_only"
    )
    report = NoiseReport(
        noise_model_id=model.noise_model_id,
        noise_model_hash=model.stable_hash(),
        method=method,
        records=tuple(records),
        applied_channel_types=tuple(
            dict.fromkeys(item.channel_type for item in records)
        ),
        physical_application_count=physical_count,
        measurement_application_count=measurement_count,
        truthfulness=truthfulness,
    )
    probability_map = None
    if return_probabilities and (
        occupations is None or bool(np.all(occupations))
    ):
        probability_map = {
            format(index, f"0{width}b"): float(value)
            for index, value in enumerate(probabilities)
        }
    diagnostic = DiagnosticsIR(
        diagnostic_id="simulation.noise.physical.completed",
        stage="simulation",
        severity="info",
        code="PHYSICAL_NOISE_SIMULATION_COMPLETED",
        message="Canonical physical noise simulation completed.",
        object_path="result",
        metadata={"method": method, "channel_count": len(model.channels)},
    )
    transition_tuple = tuple(transitions)
    references = build_runtime_references(
        program_hash=bundle.base_plan.program_hash,
        plan_hash=bundle.base_plan_hash,
        bundle_hash=bundle.stable_hash(),
        initial_state_hash=initial_state_hash,
        final_state_hash=state_hash,
        metadata={"graph_hash": bundle.base_plan.graph_hash},
    )
    trace = build_runtime_trace(
        trace_id=f"trace.{bundle.bundle_id}.physical_noise",
        transitions=transition_tuple,
        references=references,
        execution_mode=f"local_hybrid_{method}",
        terminal_message="Terminal noisy sampling completed.",
        terminal_metadata={
            "measurement_key": measurement.measurement_key,
            "shots": measurement.shots,
            "seed": measurement.seed,
        },
    )
    return ResultIR(
        result_id=f"result.{bundle.bundle_id}.physical_noise",
        program_hash=bundle.base_plan.program_hash,
        target_id=target_id,
        shots=measurement.shots,
        counts=counts,
        samples=tuple(samples),
        probabilities=probability_map,
        observables=observables,
        observable_batch=observable_batch,
        bit_ordering={
            "convention": "logical_order",
            "logical_order": ",".join(logical_order),
        },
        diagnostics=(diagnostic,),
        metadata={
            "simulation_truthfulness": truthfulness,
            "selected_simulator": (
                "ExactDensityNoiseEngine"
                if method == "density_matrix"
                else "BatchedTrajectoryNoiseEngine"
            ),
            "noise_report": report.to_dict(),
            "noise_report_hash": report.stable_hash(),
            "noise_model_hash": model.stable_hash(),
            "register_snapshots": collect_register_snapshot_evidence(
                payload.program
                for payload in bundle.payloads
                if isinstance(payload, AnalogStepPayload)
            ),
            "simulation_state": state_summary,
            "state_hash": state_hash,
            **runtime_lineage_metadata(
                transitions=transition_tuple,
                references=references,
                trace=trace,
            ),
            "state_bytes_returned": False,
            "offline_deterministic": True,
            "network_accessed": False,
        },
    )


def _density_pauli(
    state: DensityMatrixState,
    *,
    probability: float,
    targets: tuple[str, ...],
    pauli: Literal["x", "z"],
    channel: NoiseChannel,
) -> DensityMatrixState:
    dtype = state.rho.dtype
    local = np.asarray(
        ((0.0, 1.0), (1.0, 0.0))
        if pauli == "x"
        else ((1.0, 0.0), (0.0, -1.0)),
        dtype=dtype,
    )
    result = state
    for target in targets:
        result = apply_density_kraus_channel(
            result,
            (
                np.eye(2, dtype=dtype) * math.sqrt(1.0 - probability),
                local * math.sqrt(probability),
            ),
            targets=(target,),
            channel_id=channel.channel_id,
        )
    return result


def _coherent_xx_operator(
    target_count: int,
    angle: float,
    *,
    dtype: np.dtype[Any],
) -> ComplexArray:
    local_x = np.asarray(((0.0, 1.0), (1.0, 0.0)), dtype=dtype)
    interaction = local_x
    for _ in range(target_count - 1):
        interaction = np.kron(interaction, local_x)
    identity = np.eye(2**target_count, dtype=dtype)
    # Since P=X tensor ... tensor X has P^2=I, exp(-i angle P) is closed form.
    return np.asarray(
        math.cos(angle) * identity - 1j * math.sin(angle) * interaction,
        dtype=dtype,
    )


def _advance_density_time(
    state: DensityMatrixState,
    duration: float,
    *,
    channel_id: str,
) -> DensityMatrixState:
    return DensityMatrixState(
        rho=state.rho,
        logical_order=state.logical_order,
        basis=state.basis,
        logical_time=state.logical_time + duration,
        time_unit=state.time_unit,
        noise_context=state.noise_context,
        provenance=ArrayStateProvenance(
            producer="ExactDensityMatrixKernel.idle",
            parent_state_hash=state.stable_hash(),
            step_index=state.provenance.step_index + 1,
            metadata={"channel_id": channel_id, "duration": duration},
        ),
    )


def _single_gate(program: DigitalProgramIR, gate: GateIR) -> DigitalProgramIR:
    # Kernel-level gate splitting is what makes gate noise an after-each-gate map.
    return replace(program, circuit=replace(program.circuit, gates=(gate,)))


def _density_transition(
    payload: DigitalStepPayload | AnalogStepPayload,
    input_state: DensityMatrixState,
    output_state: DensityMatrixState,
    *,
    order_index: int,
    site_addressing: dict[str, Any] | None = None,
    site_phase_pattern: dict[str, Any] | None = None,
    solver_evidence: SimulationSolverEvidenceIR,
) -> StateTransitionIR:
    metadata: dict[str, Any] = {
        "payload_id": payload.payload_id,
        "payload_hash": payload.stable_hash(),
        "logical_order": list(output_state.logical_order),
    }
    if site_addressing is not None:
        metadata["site_addressing"] = site_addressing
    if site_phase_pattern is not None:
        metadata["site_phase_pattern"] = site_phase_pattern
    if output_state.logical_time > input_state.logical_time and isinstance(
        payload, DigitalStepPayload
    ):
        metadata["time_advance_source"] = "noise_model"
    return build_state_transition(
        transition_id=f"transition.{order_index}.{payload.block_id}",
        order_index=order_index,
        block_id=payload.block_id,
        program_kind=payload.payload_kind,
        program_hash=payload.program.stable_hash(),
        kernel=(
            "ExactDensityMatrixKernel.digital"
            if isinstance(payload, DigitalStepPayload)
            else "ExactDensityMatrixKernel.analog"
        ),
        input_state_hash=input_state.stable_hash(),
        output_state_hash=output_state.stable_hash(),
        input_logical_time=input_state.logical_time,
        output_logical_time=output_state.logical_time,
        time_unit=output_state.time_unit,
        solver_evidence=solver_evidence,
        metadata=metadata,
    )


def _apply_readout(
    samples: list[str],
    logical_order: tuple[str, ...],
    channel: NoiseChannel,
    rng: np.random.Generator,
) -> list[str]:
    targets = _resolve_targets(channel, logical_order)
    axes = tuple(logical_order.index(target) for target in targets)
    output: list[str] = []
    for value in samples:
        bits = list(value)
        for axis in axes:
            if bits[axis] == "0" and rng.random() < channel.parameters["p01"]:
                bits[axis] = "1"
            elif bits[axis] == "1" and rng.random() < channel.parameters["p10"]:
                bits[axis] = "0"
        output.append("".join(bits))
    return output


def _resolve_targets(
    channel: NoiseChannel,
    logical_order: tuple[str, ...],
) -> tuple[str, ...]:
    targets = logical_order if channel.targets == "all" else channel.targets
    if any(target not in logical_order for target in targets):
        raise ProgramValidationError(
            "Noise channel target is not present in the program logical order.",
            code="NOISE_TARGET_UNKNOWN",
            stage="simulation",
            object_path=f"noise.channels.{channel.channel_id}.targets",
            metadata={"targets": targets, "logical_order": logical_order},
        )
    return targets


def _active_channel(
    channel: NoiseChannel,
    logical_order: tuple[str, ...],
    active_targets: tuple[str, ...] | None,
) -> NoiseChannel | None:
    if active_targets is None:
        return channel
    configured = set(_resolve_targets(channel, logical_order))
    targets = tuple(target for target in active_targets if target in configured)
    return None if not targets else replace(channel, targets=targets)


def _validate_channel_parameters(
    channel_type: NoiseChannelType,
    parameters: dict[str, float],
    schedule_ref: str | None,
) -> None:
    expected = {
        "preparation": {"probability"},
        "dephasing": {"rate"},
        "gate": {"probability"},
        "idle": {"rate", "duration"},
        "crosstalk": {"coupling", "duration"},
        "boundary": {"probability"},
        "atom_loss": {"probability"},
        "readout": {"p01", "p10"},
    }[channel_type]
    if set(parameters) != expected:
        raise ValueError(f"{channel_type} parameters must be {sorted(expected)}.")
    for key, value in parameters.items():
        if key in {"probability", "p01", "p10"} and not 0.0 <= value <= 1.0:
            raise ValueError(f"{key} must be within [0, 1].")
        if key in {"rate", "coupling", "duration"} and value < 0.0:
            raise ValueError(f"{key} must be non-negative.")
    if channel_type in {"idle", "crosstalk"} and parameters["duration"] <= 0.0:
        raise ValueError(f"{channel_type} duration must be positive.")
    if channel_type == "crosstalk" and (
        schedule_ref is None or not schedule_ref.strip()
    ):
        raise ValueError("crosstalk requires a non-empty schedule_ref.")


def _noise_prerequisite_error(
    channel: NoiseChannel,
    prerequisite: str,
    *,
    code: str = "NOISE_PREREQUISITE_MISSING",
) -> None:
    raise CapabilityError(
        f"Noise channel '{channel.channel_id}' requires {prerequisite}.",
        code=code,
        stage="simulation",
        object_path=f"noise.channels.{channel.channel_id}",
        suggestion="Provide the physical prerequisite or remove the channel.",
        metadata={
            "channel_type": channel.channel_type,
            "required": prerequisite,
            "large_array_allocated": False,
        },
    )


def _dephasing_probability(rate: float, duration: float) -> float:
    return 0.5 * (1.0 - math.exp(-rate * duration))
