"""Digital semantic equivalence helpers backed by local simulation."""

from __future__ import annotations

import json
import math
from dataclasses import dataclass, field
from typing import Any, Literal

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.digital import DigitalProgramIR, GateIR, build_digital_program
from cascaqit.native_ir.base import IRMixin, canonicalize
from cascaqit.native_ir.models import SCHEMA_VERSION, SimulatorConfigIR
from cascaqit.results import ResultIR
from cascaqit.simulators.digital import LocalDigitalSimulator

__all__ = [
    "DigitalPhaseSensitiveDriftReportIR",
    "DigitalSemanticEquivalenceReportIR",
    "DigitalStatevectorEvidenceSummaryIR",
    "build_digital_phase_sensitive_drift_report",
    "compare_digital_program_semantics",
    "build_digital_statevector_evidence_summary",
]

DigitalPhaseSensitiveDriftStatus = Literal["phase_drift", "no_drift", "blocked"]
DigitalSemanticEquivalenceStatus = Literal["equivalent", "different", "blocked"]
StatevectorEvidenceStatus = Literal["ready", "unavailable", "blocked"]


@dataclass(frozen=True)
class DigitalSemanticEquivalenceReportIR(IRMixin):
    """Offline digital semantic equivalence report."""

    report_id: str
    status: DigitalSemanticEquivalenceStatus
    left_program_id: str
    right_program_id: str
    left_program_hash: str
    right_program_hash: str
    basis: str
    qubit_order: tuple[str, ...]
    tolerance: float
    max_probability_delta: float | None
    probability_deltas: tuple[dict[str, Any], ...]
    matched_bitstrings: tuple[str, ...]
    drift_bitstrings: tuple[str, ...]
    diagnostics: tuple[DiagnosticsIR, ...]
    left_result_ref: str | None = None
    right_result_ref: str | None = None
    metadata_only: bool = True
    offline_deterministic: bool = True
    simulator_name: str = "LocalDigitalSimulator"
    backend_called: bool = False
    cloud_called: bool = False
    network_accessed: bool = False
    cascaqit_compat_required: bool = False
    external_sdk_imported: bool = False
    execution_package_created: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize payload and enforce offline equivalence boundaries."""
        if not self.metadata_only:
            raise ValueError("Digital equivalence reports must remain metadata-only.")
        if not self.offline_deterministic:
            raise ValueError(
                "Digital equivalence reports must be offline deterministic."
            )
        if self.backend_called or self.cloud_called:
            raise ValueError("Digital equivalence must not call backend or cloud.")
        if self.network_accessed:
            raise ValueError("Digital equivalence must not access the network.")
        if self.cascaqit_compat_required:
            raise ValueError("Digital equivalence must not require compat.")
        if self.external_sdk_imported:
            raise ValueError("Digital equivalence must not import external SDKs.")
        if self.execution_package_created:
            raise ValueError("Digital equivalence must not create execution packages.")
        object.__setattr__(
            self,
            "qubit_order",
            tuple(str(qubit) for qubit in self.qubit_order),
        )
        object.__setattr__(
            self,
            "probability_deltas",
            tuple(canonicalize(dict(delta)) for delta in self.probability_deltas),
        )
        object.__setattr__(
            self,
            "matched_bitstrings",
            tuple(str(bitstring) for bitstring in self.matched_bitstrings),
        )
        object.__setattr__(
            self,
            "drift_bitstrings",
            tuple(str(bitstring) for bitstring in self.drift_bitstrings),
        )
        object.__setattr__(
            self,
            "diagnostics",
            tuple(
                diagnostic
                if isinstance(diagnostic, DiagnosticsIR)
                else DiagnosticsIR.from_dict(diagnostic)
                for diagnostic in self.diagnostics
            ),
        )
        object.__setattr__(self, "metadata", canonicalize(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DigitalSemanticEquivalenceReportIR:
        """Build a digital semantic equivalence report from a dictionary."""
        return cls(
            report_id=str(data["report_id"]),
            status=data["status"],
            left_program_id=str(data["left_program_id"]),
            right_program_id=str(data["right_program_id"]),
            left_program_hash=str(data["left_program_hash"]),
            right_program_hash=str(data["right_program_hash"]),
            basis=str(data["basis"]),
            qubit_order=tuple(str(item) for item in data.get("qubit_order", ())),
            tolerance=float(data["tolerance"]),
            max_probability_delta=(
                None
                if data.get("max_probability_delta") is None
                else float(data["max_probability_delta"])
            ),
            probability_deltas=tuple(
                dict(item) for item in data.get("probability_deltas", ())
            ),
            matched_bitstrings=tuple(
                str(item) for item in data.get("matched_bitstrings", ())
            ),
            drift_bitstrings=tuple(
                str(item) for item in data.get("drift_bitstrings", ())
            ),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(item)
                for item in data.get("diagnostics", ())
            ),
            left_result_ref=data.get("left_result_ref"),
            right_result_ref=data.get("right_result_ref"),
            metadata_only=bool(data.get("metadata_only", True)),
            offline_deterministic=bool(data.get("offline_deterministic", True)),
            simulator_name=str(data.get("simulator_name", "LocalDigitalSimulator")),
            backend_called=bool(data.get("backend_called", False)),
            cloud_called=bool(data.get("cloud_called", False)),
            network_accessed=bool(data.get("network_accessed", False)),
            cascaqit_compat_required=bool(
                data.get("cascaqit_compat_required", False)
            ),
            external_sdk_imported=bool(data.get("external_sdk_imported", False)),
            execution_package_created=bool(
                data.get("execution_package_created", False)
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> DigitalSemanticEquivalenceReportIR:
        """Build a digital semantic equivalence report from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError(
                "DigitalSemanticEquivalenceReportIR JSON must contain an object."
            )
        return cls.from_dict(data)


@dataclass(frozen=True)
class DigitalPhaseSensitiveDriftReportIR(IRMixin):
    """Metadata-only report for phase-sensitive semantic drift fixtures."""

    report_id: str
    status: DigitalPhaseSensitiveDriftStatus
    left_program_id: str
    right_program_id: str
    probe_program_ids: tuple[str, str]
    probe_gate: str
    probe_qubits: tuple[str, ...]
    probability_equivalence_status: DigitalSemanticEquivalenceStatus
    probed_equivalence_status: DigitalSemanticEquivalenceStatus
    max_probability_delta_before_probe: float | None
    max_probability_delta_after_probe: float | None
    phase_sensitive: bool
    statevector_evidence: dict[str, Any]
    diagnostics: tuple[DiagnosticsIR, ...]
    metadata_only: bool = True
    offline_deterministic: bool = True
    simulator_name: str = "LocalDigitalSimulator"
    backend_called: bool = False
    cloud_called: bool = False
    network_accessed: bool = False
    cascaqit_compat_required: bool = False
    external_sdk_imported: bool = False
    execution_package_created: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize drift report metadata and enforce offline boundaries."""
        if self.status not in ("phase_drift", "no_drift", "blocked"):
            raise ValueError(
                "DigitalPhaseSensitiveDriftReportIR has unsupported status."
            )
        if not self.metadata_only:
            raise ValueError("Phase-sensitive drift reports must be metadata-only.")
        if not self.offline_deterministic:
            raise ValueError("Phase-sensitive drift reports must be deterministic.")
        if self.backend_called or self.cloud_called:
            raise ValueError("Phase-sensitive drift must not call backend or cloud.")
        if self.network_accessed:
            raise ValueError("Phase-sensitive drift must not access the network.")
        if self.cascaqit_compat_required:
            raise ValueError("Phase-sensitive drift must not require compat.")
        if self.external_sdk_imported:
            raise ValueError("Phase-sensitive drift must not import external SDKs.")
        if self.execution_package_created:
            raise ValueError(
                "Phase-sensitive drift must not create execution packages."
            )
        object.__setattr__(
            self,
            "probe_program_ids",
            tuple(str(item) for item in self.probe_program_ids),
        )
        object.__setattr__(
            self,
            "probe_qubits",
            tuple(str(item) for item in self.probe_qubits),
        )
        object.__setattr__(
            self,
            "statevector_evidence",
            canonicalize(self.statevector_evidence),
        )
        object.__setattr__(
            self,
            "diagnostics",
            tuple(
                diagnostic
                if isinstance(diagnostic, DiagnosticsIR)
                else DiagnosticsIR.from_dict(diagnostic)
                for diagnostic in self.diagnostics
            ),
        )
        object.__setattr__(self, "metadata", canonicalize(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DigitalPhaseSensitiveDriftReportIR:
        """Build a phase-sensitive drift report from a dictionary."""
        if not isinstance(data, dict):
            raise TypeError(
                "DigitalPhaseSensitiveDriftReportIR dictionary must be an object."
            )
        return cls(
            report_id=str(data["report_id"]),
            status=data["status"],
            left_program_id=str(data["left_program_id"]),
            right_program_id=str(data["right_program_id"]),
            probe_program_ids=_two_item_tuple(data.get("probe_program_ids", ())),
            probe_gate=str(data["probe_gate"]),
            probe_qubits=tuple(str(item) for item in data.get("probe_qubits", ())),
            probability_equivalence_status=data["probability_equivalence_status"],
            probed_equivalence_status=data["probed_equivalence_status"],
            max_probability_delta_before_probe=(
                None
                if data.get("max_probability_delta_before_probe") is None
                else float(data["max_probability_delta_before_probe"])
            ),
            max_probability_delta_after_probe=(
                None
                if data.get("max_probability_delta_after_probe") is None
                else float(data["max_probability_delta_after_probe"])
            ),
            phase_sensitive=bool(data["phase_sensitive"]),
            statevector_evidence=dict(data.get("statevector_evidence", {})),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(item)
                for item in data.get("diagnostics", ())
            ),
            metadata_only=bool(data.get("metadata_only", True)),
            offline_deterministic=bool(data.get("offline_deterministic", True)),
            simulator_name=str(data.get("simulator_name", "LocalDigitalSimulator")),
            backend_called=bool(data.get("backend_called", False)),
            cloud_called=bool(data.get("cloud_called", False)),
            network_accessed=bool(data.get("network_accessed", False)),
            cascaqit_compat_required=bool(
                data.get("cascaqit_compat_required", False)
            ),
            external_sdk_imported=bool(data.get("external_sdk_imported", False)),
            execution_package_created=bool(
                data.get("execution_package_created", False)
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> DigitalPhaseSensitiveDriftReportIR:
        """Build a phase-sensitive drift report from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError(
                "DigitalPhaseSensitiveDriftReportIR JSON must contain an object."
            )
        return cls.from_dict(data)


@dataclass(frozen=True)
class DigitalStatevectorEvidenceSummaryIR(IRMixin):
    """Metadata-only statevector semantic evidence summary."""

    evidence_id: str
    status: StatevectorEvidenceStatus
    program_id: str
    program_hash: str
    result_id: str
    basis: str
    qubit_order: tuple[str, ...]
    dimension: int | None
    norm: float | None
    probability_mass: float | None
    phase_reference_policy: str
    state_bytes_returned: bool
    state_bytes_required: bool
    probability_source: str
    statevector_source: str
    diagnostics: tuple[DiagnosticsIR, ...]
    metadata_only: bool = True
    offline_deterministic: bool = True
    simulator_name: str = "LocalDigitalSimulator"
    backend_called: bool = False
    cloud_called: bool = False
    network_accessed: bool = False
    cascaqit_compat_required: bool = False
    external_sdk_imported: bool = False
    execution_package_created: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize summary metadata and enforce offline evidence boundaries."""
        if self.status not in ("ready", "unavailable", "blocked"):
            raise ValueError(
                "DigitalStatevectorEvidenceSummaryIR has unsupported status."
            )
        if not self.metadata_only:
            raise ValueError("Statevector evidence must remain metadata-only.")
        if not self.offline_deterministic:
            raise ValueError("Statevector evidence must be offline deterministic.")
        if self.backend_called or self.cloud_called:
            raise ValueError("Statevector evidence must not call backend or cloud.")
        if self.network_accessed:
            raise ValueError("Statevector evidence must not access the network.")
        if self.cascaqit_compat_required:
            raise ValueError("Statevector evidence must not require compat.")
        if self.external_sdk_imported:
            raise ValueError("Statevector evidence must not import external SDKs.")
        if self.execution_package_created:
            raise ValueError("Statevector evidence must not create execution packages.")
        if self.state_bytes_returned:
            raise ValueError("Statevector evidence must not return state bytes.")
        if self.state_bytes_required:
            raise ValueError("Statevector evidence must not require state bytes.")
        object.__setattr__(
            self,
            "qubit_order",
            tuple(str(qubit) for qubit in self.qubit_order),
        )
        object.__setattr__(
            self,
            "diagnostics",
            tuple(
                diagnostic
                if isinstance(diagnostic, DiagnosticsIR)
                else DiagnosticsIR.from_dict(diagnostic)
                for diagnostic in self.diagnostics
            ),
        )
        object.__setattr__(self, "metadata", canonicalize(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DigitalStatevectorEvidenceSummaryIR:
        """Build a statevector evidence summary from a dictionary."""
        if not isinstance(data, dict):
            raise TypeError(
                "DigitalStatevectorEvidenceSummaryIR dictionary must be an object."
            )
        return cls(
            evidence_id=str(data["evidence_id"]),
            status=data["status"],
            program_id=str(data["program_id"]),
            program_hash=str(data["program_hash"]),
            result_id=str(data["result_id"]),
            basis=str(data["basis"]),
            qubit_order=tuple(str(item) for item in data.get("qubit_order", ())),
            dimension=(
                None if data.get("dimension") is None else int(data["dimension"])
            ),
            norm=None if data.get("norm") is None else float(data["norm"]),
            probability_mass=(
                None
                if data.get("probability_mass") is None
                else float(data["probability_mass"])
            ),
            phase_reference_policy=str(data["phase_reference_policy"]),
            state_bytes_returned=bool(data["state_bytes_returned"]),
            state_bytes_required=bool(data["state_bytes_required"]),
            probability_source=str(data["probability_source"]),
            statevector_source=str(data["statevector_source"]),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(item)
                for item in data.get("diagnostics", ())
            ),
            metadata_only=bool(data.get("metadata_only", True)),
            offline_deterministic=bool(data.get("offline_deterministic", True)),
            simulator_name=str(data.get("simulator_name", "LocalDigitalSimulator")),
            backend_called=bool(data.get("backend_called", False)),
            cloud_called=bool(data.get("cloud_called", False)),
            network_accessed=bool(data.get("network_accessed", False)),
            cascaqit_compat_required=bool(
                data.get("cascaqit_compat_required", False)
            ),
            external_sdk_imported=bool(data.get("external_sdk_imported", False)),
            execution_package_created=bool(
                data.get("execution_package_created", False)
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> DigitalStatevectorEvidenceSummaryIR:
        """Build a statevector evidence summary from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError(
                "DigitalStatevectorEvidenceSummaryIR JSON must contain an object."
            )
        return cls.from_dict(data)


def compare_digital_program_semantics(
    left: DigitalProgramIR,
    right: DigitalProgramIR,
    *,
    report_id: str | None = None,
    tolerance: float = 1e-12,
    simulator: LocalDigitalSimulator | None = None,
    config: SimulatorConfigIR | None = None,
    metadata: dict[str, Any] | None = None,
) -> DigitalSemanticEquivalenceReportIR:
    """Compare two digital programs through local probability semantics."""
    if not isinstance(left, DigitalProgramIR) or not isinstance(
        right, DigitalProgramIR
    ):
        raise TypeError("compare_digital_program_semantics requires DigitalProgramIR.")
    if tolerance < 0.0 or not math.isfinite(tolerance):
        raise ValueError("tolerance must be a finite non-negative float.")
    qubit_order = tuple(left.circuit.qubits)
    if qubit_order != tuple(right.circuit.qubits):
        return _blocked_report(
            left,
            right,
            report_id=report_id,
            tolerance=tolerance,
            qubit_order=qubit_order,
            diagnostics=(
                _diagnostic(
                    code="DIGITAL_SEMANTIC_QUBIT_ORDER_MISMATCH",
                    message=(
                        "Digital semantic equivalence requires the same qubit order."
                    ),
                    object_path="digital_program.circuit.qubits",
                    severity="error",
                    metadata={
                        "left_qubit_order": list(qubit_order),
                        "right_qubit_order": list(right.circuit.qubits),
                    },
                ),
            ),
            metadata=metadata,
        )
    runner = LocalDigitalSimulator() if simulator is None else simulator
    effective_config = (
        SimulatorConfigIR(shots=0, seed=runner.seed)
        if config is None
        else config
    )
    left_result = runner.run(left, config=effective_config)
    right_result = runner.run(right, config=effective_config)
    left_statevector_evidence = build_digital_statevector_evidence_summary(
        left,
        left_result,
        evidence_id=f"statevector_evidence.{left.program_id}",
    )
    right_statevector_evidence = build_digital_statevector_evidence_summary(
        right,
        right_result,
        evidence_id=f"statevector_evidence.{right.program_id}",
    )
    input_diagnostics = _blocking_result_diagnostics(left_result, right_result)
    if input_diagnostics:
        return _blocked_report(
            left,
            right,
            report_id=report_id,
            tolerance=tolerance,
            qubit_order=qubit_order,
            diagnostics=input_diagnostics,
            left_result=left_result,
            right_result=right_result,
            metadata=_metadata_with_statevector_evidence(
                metadata,
                left_statevector_evidence=left_statevector_evidence,
                right_statevector_evidence=right_statevector_evidence,
            ),
        )
    probability_deltas = _probability_deltas(
        left_result.probabilities or {},
        right_result.probabilities or {},
    )
    drift_bitstrings = tuple(
        str(entry["bitstring"])
        for entry in probability_deltas
        if float(entry["absolute_delta"]) > tolerance
    )
    matched_bitstrings = tuple(
        str(entry["bitstring"])
        for entry in probability_deltas
        if float(entry["absolute_delta"]) <= tolerance
    )
    max_delta = (
        max(float(entry["absolute_delta"]) for entry in probability_deltas)
        if probability_deltas
        else 0.0
    )
    status: DigitalSemanticEquivalenceStatus = (
        "different" if drift_bitstrings else "equivalent"
    )
    return DigitalSemanticEquivalenceReportIR(
        report_id=report_id or f"digital_semantic_equivalence.{left.program_id}",
        status=status,
        left_program_id=left.program_id,
        right_program_id=right.program_id,
        left_program_hash=left.stable_hash(),
        right_program_hash=right.stable_hash(),
        basis="computational",
        qubit_order=qubit_order,
        tolerance=tolerance,
        max_probability_delta=max_delta,
        probability_deltas=probability_deltas,
        matched_bitstrings=matched_bitstrings,
        drift_bitstrings=drift_bitstrings,
        diagnostics=(
            _diagnostic(
                code=(
                    "DIGITAL_SEMANTIC_EQUIVALENCE_PASSED"
                    if status == "equivalent"
                    else "DIGITAL_SEMANTIC_EQUIVALENCE_DRIFT"
                ),
                message=(
                    "Digital programs are equivalent within probability tolerance."
                    if status == "equivalent"
                    else "Digital programs differ beyond probability tolerance."
                ),
                object_path="digital_semantic_equivalence.probabilities",
                severity="info" if status == "equivalent" else "warning",
                metadata={
                    "tolerance": tolerance,
                    "max_probability_delta": max_delta,
                    "drift_bitstrings": list(drift_bitstrings),
                },
            ),
        ),
        left_result_ref=left_result.result_id,
        right_result_ref=right_result.result_id,
        metadata=_metadata(
            metadata,
            effective_config=effective_config,
            left_result=left_result,
            right_result=right_result,
            left_statevector_evidence=left_statevector_evidence,
            right_statevector_evidence=right_statevector_evidence,
        ),
    )


def build_digital_phase_sensitive_drift_report(
    left: DigitalProgramIR,
    right: DigitalProgramIR,
    *,
    report_id: str | None = None,
    probe_gate: Literal["h"] = "h",
    probe_qubits: tuple[str, ...] | None = None,
    tolerance: float = 1e-12,
    simulator: LocalDigitalSimulator | None = None,
    config: SimulatorConfigIR | None = None,
    metadata: dict[str, Any] | None = None,
) -> DigitalPhaseSensitiveDriftReportIR:
    """Detect phase-sensitive drift through deterministic probe interference."""
    if probe_gate != "h":
        raise ValueError("Phase-sensitive drift fixtures currently support H probe.")
    if tuple(left.circuit.qubits) != tuple(right.circuit.qubits):
        diagnostics = (
            _diagnostic(
                code="DIGITAL_PHASE_DRIFT_QUBIT_ORDER_MISMATCH",
                message="Phase-sensitive drift fixtures require equal qubit order.",
                object_path="digital_program.circuit.qubits",
                severity="error",
                metadata={
                    "left_qubit_order": list(left.circuit.qubits),
                    "right_qubit_order": list(right.circuit.qubits),
                },
            ),
        )
        return _phase_drift_report(
            left,
            right,
            report_id=report_id,
            status="blocked",
            probe_program_ids=("", ""),
            probe_gate=probe_gate,
            probe_qubits=(),
            before_status="blocked",
            after_status="blocked",
            before_delta=None,
            after_delta=None,
            statevector_evidence={},
            diagnostics=diagnostics,
            metadata=metadata,
        )
    effective_probe_qubits = (
        tuple(left.circuit.qubits[:1]) if probe_qubits is None else probe_qubits
    )
    if not effective_probe_qubits:
        raise ValueError("Phase-sensitive drift fixtures require a probe qubit.")
    before = compare_digital_program_semantics(
        left,
        right,
        report_id=f"{report_id or 'digital_phase_drift'}.before_probe",
        tolerance=tolerance,
        simulator=simulator,
        config=config,
    )
    left_probe = _append_probe_gates(
        left,
        probe_gate=probe_gate,
        probe_qubits=effective_probe_qubits,
        suffix="phase_probe_left",
    )
    right_probe = _append_probe_gates(
        right,
        probe_gate=probe_gate,
        probe_qubits=effective_probe_qubits,
        suffix="phase_probe_right",
    )
    after = compare_digital_program_semantics(
        left_probe,
        right_probe,
        report_id=f"{report_id or 'digital_phase_drift'}.after_probe",
        tolerance=tolerance,
        simulator=simulator,
        config=config,
    )
    phase_sensitive = before.status == "equivalent" and after.status == "different"
    status: DigitalPhaseSensitiveDriftStatus
    if before.status == "blocked" or after.status == "blocked":
        status = "blocked"
    elif phase_sensitive:
        status = "phase_drift"
    else:
        status = "no_drift"
    diagnostics = (
        _diagnostic(
            code=(
                "DIGITAL_PHASE_SENSITIVE_DRIFT_DETECTED"
                if status == "phase_drift"
                else "DIGITAL_PHASE_SENSITIVE_DRIFT_NOT_DETECTED"
                if status == "no_drift"
                else "DIGITAL_PHASE_SENSITIVE_DRIFT_BLOCKED"
            ),
            message=(
                "Probe interference detected phase-sensitive semantic drift."
                if status == "phase_drift"
                else "Probe interference did not detect phase-sensitive drift."
                if status == "no_drift"
                else "Phase-sensitive drift fixture was blocked."
            ),
            object_path="digital_phase_sensitive_drift",
            severity="warning" if status == "phase_drift" else "info",
            metadata={
                "probability_equivalence_status": before.status,
                "probed_equivalence_status": after.status,
                "max_probability_delta_before_probe": (
                    before.max_probability_delta
                ),
                "max_probability_delta_after_probe": after.max_probability_delta,
                "probe_gate": probe_gate,
                "probe_qubits": list(effective_probe_qubits),
            },
        ),
    )
    return _phase_drift_report(
        left,
        right,
        report_id=report_id,
        status=status,
        probe_program_ids=(left_probe.program_id, right_probe.program_id),
        probe_gate=probe_gate,
        probe_qubits=effective_probe_qubits,
        before_status=before.status,
        after_status=after.status,
        before_delta=before.max_probability_delta,
        after_delta=after.max_probability_delta,
        statevector_evidence={
            "before": {
                "left": before.metadata.get("statevector_evidence", {}).get("left"),
                "right": before.metadata.get("statevector_evidence", {}).get("right"),
            },
            "after_probe": {
                "left": after.metadata.get("statevector_evidence", {}).get("left"),
                "right": after.metadata.get("statevector_evidence", {}).get("right"),
            },
        },
        diagnostics=diagnostics,
        metadata={
            **({} if metadata is None else dict(metadata)),
            "phase": "234",
            "fixture_kind": "probability_equivalent_statevector_different",
            "state_bytes_required": False,
            "probe_strategy": "append_same_h_probe_to_reveal_relative_phase",
        },
    )


def build_digital_statevector_evidence_summary(
    program: DigitalProgramIR,
    result: ResultIR,
    *,
    evidence_id: str | None = None,
    phase_reference_policy: str = "global_phase_not_fixed_metadata_only",
    tolerance: float = 1e-9,
    metadata: dict[str, Any] | None = None,
) -> DigitalStatevectorEvidenceSummaryIR:
    """Build metadata-only statevector evidence from local digital result data."""
    state = _statevector_summary_from_result(result)
    probability = _probability_summary_from_result(result)
    basis = str(state.get("basis") or probability.get("basis") or "computational")
    qubit_order = tuple(
        str(item)
        for item in (
            state.get("qubit_order")
            or probability.get("qubit_order")
            or program.circuit.qubits
        )
    )
    dimension = None if state.get("dimension") is None else int(state["dimension"])
    norm = None if state.get("norm") is None else float(state["norm"])
    probability_mass = (
        None
        if probability.get("probability_mass") is None
        else float(probability["probability_mass"])
    )
    returned_state_bytes = bool(
        state.get(
            "returned_state_bytes",
            result.metadata.get("simulation_state", {}).get(
                "state_bytes_returned", False
            ),
        )
    )
    diagnostics = _statevector_evidence_diagnostics(
        dimension=dimension,
        expected_dimension=2 ** len(tuple(program.circuit.qubits)),
        norm=norm,
        probability_mass=probability_mass,
        returned_state_bytes=returned_state_bytes,
        tolerance=tolerance,
    )
    status: StatevectorEvidenceStatus = (
        "blocked"
        if any(diagnostic.severity == "error" for diagnostic in diagnostics)
        else "ready"
    )
    if not state:
        status = "unavailable"
    return DigitalStatevectorEvidenceSummaryIR(
        evidence_id=evidence_id or f"statevector_evidence.{program.program_id}",
        status=status,
        program_id=program.program_id,
        program_hash=program.stable_hash(),
        result_id=result.result_id,
        basis=basis,
        qubit_order=qubit_order,
        dimension=dimension,
        norm=norm,
        probability_mass=probability_mass,
        phase_reference_policy=phase_reference_policy,
        state_bytes_returned=returned_state_bytes,
        state_bytes_required=False,
        probability_source="ResultIR.probabilities",
        statevector_source="ResultIR.metadata.simulation_state.state_vector",
        diagnostics=diagnostics,
        metadata={
            **({} if metadata is None else dict(metadata)),
            "comparison_kind": "statevector_metadata_evidence",
            "probability_linkage": {
                "basis": basis,
                "qubit_order": list(qubit_order),
                "dimension": dimension,
                "probability_mass": probability_mass,
            },
            "state_bytes_required": False,
            "state_bytes_returned": returned_state_bytes,
        },
    )


def _blocked_report(
    left: DigitalProgramIR,
    right: DigitalProgramIR,
    *,
    report_id: str | None,
    tolerance: float,
    qubit_order: tuple[str, ...],
    diagnostics: tuple[DiagnosticsIR, ...],
    left_result: ResultIR | None = None,
    right_result: ResultIR | None = None,
    metadata: dict[str, Any] | None,
) -> DigitalSemanticEquivalenceReportIR:
    return DigitalSemanticEquivalenceReportIR(
        report_id=report_id or f"digital_semantic_equivalence.{left.program_id}",
        status="blocked",
        left_program_id=left.program_id,
        right_program_id=right.program_id,
        left_program_hash=left.stable_hash(),
        right_program_hash=right.stable_hash(),
        basis="computational",
        qubit_order=qubit_order,
        tolerance=tolerance,
        max_probability_delta=None,
        probability_deltas=(),
        matched_bitstrings=(),
        drift_bitstrings=(),
        diagnostics=diagnostics,
        left_result_ref=None if left_result is None else left_result.result_id,
        right_result_ref=None if right_result is None else right_result.result_id,
        metadata={} if metadata is None else dict(metadata),
    )


def _probability_deltas(
    left: dict[str, float],
    right: dict[str, float],
) -> tuple[dict[str, Any], ...]:
    bitstrings = sorted(set(left) | set(right))
    return tuple(
        {
            "bitstring": bitstring,
            "left_probability": float(left.get(bitstring, 0.0)),
            "right_probability": float(right.get(bitstring, 0.0)),
            "absolute_delta": abs(
                float(left.get(bitstring, 0.0)) - float(right.get(bitstring, 0.0))
            ),
        }
        for bitstring in bitstrings
    )


def _blocking_result_diagnostics(
    left: ResultIR,
    right: ResultIR,
) -> tuple[DiagnosticsIR, ...]:
    diagnostics = [
        diagnostic
        for diagnostic in (*left.diagnostics, *right.diagnostics)
        if diagnostic.severity == "error"
    ]
    if left.probabilities is None or right.probabilities is None:
        diagnostics.append(
            _diagnostic(
                code="DIGITAL_SEMANTIC_PROBABILITIES_UNAVAILABLE",
                message="Digital semantic equivalence requires inline probabilities.",
                object_path="result.probabilities",
                severity="error",
            )
        )
    return tuple(diagnostics)


def _metadata(
    metadata: dict[str, Any] | None,
    *,
    effective_config: SimulatorConfigIR,
    left_result: ResultIR,
    right_result: ResultIR,
    left_statevector_evidence: DigitalStatevectorEvidenceSummaryIR,
    right_statevector_evidence: DigitalStatevectorEvidenceSummaryIR,
) -> dict[str, Any]:
    return {
        **({} if metadata is None else dict(metadata)),
        "comparison_kind": "simulator_backed_probability_equivalence",
        "simulator_config": effective_config.to_dict(),
        "left_result_hash": left_result.stable_hash(),
        "right_result_hash": right_result.stable_hash(),
        "probability_source": "ResultIR.probabilities",
        "state_bytes_required": False,
        "statevector_evidence": {
            "left": _statevector_linkage(left_statevector_evidence),
            "right": _statevector_linkage(right_statevector_evidence),
        },
        "semantic_evidence_level": (
            "simulator_backed_probability_and_statevector_metadata"
        ),
    }


def _metadata_with_statevector_evidence(
    metadata: dict[str, Any] | None,
    *,
    left_statevector_evidence: DigitalStatevectorEvidenceSummaryIR,
    right_statevector_evidence: DigitalStatevectorEvidenceSummaryIR,
) -> dict[str, Any]:
    return {
        **({} if metadata is None else dict(metadata)),
        "state_bytes_required": False,
        "statevector_evidence": {
            "left": _statevector_linkage(left_statevector_evidence),
            "right": _statevector_linkage(right_statevector_evidence),
        },
        "semantic_evidence_level": (
            "simulator_backed_probability_and_statevector_metadata"
        ),
    }


def _phase_drift_report(
    left: DigitalProgramIR,
    right: DigitalProgramIR,
    *,
    report_id: str | None,
    status: DigitalPhaseSensitiveDriftStatus,
    probe_program_ids: tuple[str, str],
    probe_gate: str,
    probe_qubits: tuple[str, ...],
    before_status: DigitalSemanticEquivalenceStatus,
    after_status: DigitalSemanticEquivalenceStatus,
    before_delta: float | None,
    after_delta: float | None,
    statevector_evidence: dict[str, Any],
    diagnostics: tuple[DiagnosticsIR, ...],
    metadata: dict[str, Any] | None,
) -> DigitalPhaseSensitiveDriftReportIR:
    return DigitalPhaseSensitiveDriftReportIR(
        report_id=report_id or f"digital_phase_sensitive_drift.{left.program_id}",
        status=status,
        left_program_id=left.program_id,
        right_program_id=right.program_id,
        probe_program_ids=probe_program_ids,
        probe_gate=probe_gate,
        probe_qubits=probe_qubits,
        probability_equivalence_status=before_status,
        probed_equivalence_status=after_status,
        max_probability_delta_before_probe=before_delta,
        max_probability_delta_after_probe=after_delta,
        phase_sensitive=status == "phase_drift",
        statevector_evidence=statevector_evidence,
        diagnostics=diagnostics,
        metadata={} if metadata is None else dict(metadata),
    )


def _two_item_tuple(value: Any) -> tuple[str, str]:
    items = tuple(str(item) for item in value)
    if len(items) != 2:
        raise ValueError("probe_program_ids must contain exactly two items.")
    return (items[0], items[1])


def _append_probe_gates(
    program: DigitalProgramIR,
    *,
    probe_gate: str,
    probe_qubits: tuple[str, ...],
    suffix: str,
) -> DigitalProgramIR:
    gates = list(program.circuit.gates)
    for index, qubit in enumerate(probe_qubits):
        if probe_gate == "h":
            gates.append(
                GateIR.h(
                    qubit,
                    gate_id=f"gate.{program.program_id}.{suffix}.{index}.h",
                    metadata={
                        "probe_kind": "phase_sensitive_interference",
                        "source_program_id": program.program_id,
                    },
                )
            )
        else:
            raise ValueError("Unsupported phase-sensitive probe gate.")
    return build_digital_program(
        program_id=f"{program.program_id}.{suffix}",
        qubits=program.circuit.qubits,
        gates=tuple(gates),
        measurements=program.circuit.measurements,
        circuit_id=f"{program.circuit.circuit_id}.{suffix}",
        metadata={
            **dict(program.metadata),
            "phase_sensitive_probe": {
                "probe_gate": probe_gate,
                "probe_qubits": list(probe_qubits),
                "source_program_id": program.program_id,
            },
        },
    )


def _statevector_linkage(
    evidence: DigitalStatevectorEvidenceSummaryIR,
) -> dict[str, Any]:
    return {
        "evidence_id": evidence.evidence_id,
        "status": evidence.status,
        "basis": evidence.basis,
        "qubit_order": list(evidence.qubit_order),
        "dimension": evidence.dimension,
        "norm": evidence.norm,
        "probability_mass": evidence.probability_mass,
        "phase_reference_policy": evidence.phase_reference_policy,
        "state_bytes_returned": evidence.state_bytes_returned,
        "state_bytes_required": evidence.state_bytes_required,
        "diagnostic_codes": [diagnostic.code for diagnostic in evidence.diagnostics],
    }


def _statevector_summary_from_result(result: ResultIR) -> dict[str, Any]:
    simulation_state = result.metadata.get("simulation_state", {})
    if not isinstance(simulation_state, dict):
        return {}
    state = simulation_state.get("state_vector", {})
    return dict(state) if isinstance(state, dict) else {}


def _probability_summary_from_result(result: ResultIR) -> dict[str, Any]:
    basis_probability = result.metadata.get("basis_probability", {})
    if isinstance(basis_probability, dict):
        return dict(basis_probability)
    state = result.metadata.get("simulation_state", {})
    if isinstance(state, dict) and isinstance(state.get("primary"), dict):
        primary = dict(state["primary"])
        return {
            "basis": primary.get("basis"),
            "qubit_order": primary.get("qubit_order", ()),
            "probability_mass": primary.get("probability_mass"),
        }
    return {}


def _statevector_evidence_diagnostics(
    *,
    dimension: int | None,
    expected_dimension: int,
    norm: float | None,
    probability_mass: float | None,
    returned_state_bytes: bool,
    tolerance: float,
) -> tuple[DiagnosticsIR, ...]:
    diagnostics: list[DiagnosticsIR] = []
    if returned_state_bytes:
        diagnostics.append(
            _diagnostic(
                code="DIGITAL_STATEVECTOR_EVIDENCE_BYTES_RETURNED",
                message="Statevector evidence must not return state bytes.",
                object_path="result.metadata.simulation_state.state_vector",
                severity="error",
                metadata={"returned_state_bytes": returned_state_bytes},
            )
        )
    if dimension is None:
        diagnostics.append(
            _diagnostic(
                code="DIGITAL_STATEVECTOR_EVIDENCE_UNAVAILABLE",
                message="Statevector metadata evidence is unavailable.",
                object_path="result.metadata.simulation_state.state_vector",
                severity="error",
            )
        )
    elif dimension != expected_dimension:
        diagnostics.append(
            _diagnostic(
                code="DIGITAL_STATEVECTOR_EVIDENCE_DIMENSION_MISMATCH",
                message="Statevector metadata dimension does not match qubit count.",
                object_path="result.metadata.simulation_state.state_vector.dimension",
                severity="error",
                metadata={
                    "dimension": dimension,
                    "expected_dimension": expected_dimension,
                },
            )
        )
    if norm is None or abs(norm - 1.0) > tolerance:
        diagnostics.append(
            _diagnostic(
                code="DIGITAL_STATEVECTOR_EVIDENCE_NORM_DRIFT",
                message="Statevector metadata norm is not within tolerance.",
                object_path="result.metadata.simulation_state.state_vector.norm",
                severity="error",
                metadata={"norm": norm, "tolerance": tolerance},
            )
        )
    if probability_mass is None or abs(probability_mass - 1.0) > tolerance:
        diagnostics.append(
            _diagnostic(
                code="DIGITAL_STATEVECTOR_EVIDENCE_PROBABILITY_MASS_DRIFT",
                message="Probability mass linked to statevector evidence drifted.",
                object_path="result.metadata.basis_probability.probability_mass",
                severity="error",
                metadata={"probability_mass": probability_mass, "tolerance": tolerance},
            )
        )
    if not diagnostics:
        diagnostics.append(
            _diagnostic(
                code="DIGITAL_STATEVECTOR_EVIDENCE_READY",
                message="Statevector metadata evidence is available.",
                object_path="digital_statevector_evidence",
                severity="info",
                metadata={
                    "dimension": dimension,
                    "norm": norm,
                    "probability_mass": probability_mass,
                    "state_bytes_required": False,
                },
            )
        )
    return tuple(diagnostics)


def _diagnostic(
    *,
    code: str,
    message: str,
    object_path: str,
    severity: Literal["info", "warning", "error"],
    metadata: dict[str, Any] | None = None,
) -> DiagnosticsIR:
    return DiagnosticsIR(
        diagnostic_id=f"digital_semantic_equivalence.{code.lower()}",
        stage="simulation",
        severity=severity,
        code=code,
        message=message,
        object_path=object_path,
        suggestion=(
            "Compare qubit order, gate sequence, lowering metadata, and "
            "measurement mapping."
            if severity != "info"
            else None
        ),
        metadata={} if metadata is None else dict(metadata),
    )
