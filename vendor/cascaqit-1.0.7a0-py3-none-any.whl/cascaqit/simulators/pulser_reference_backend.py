"""Backend contracts for the optional local Pulser reference runtime."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field, replace
from typing import Any, Literal

from cascaqit.backends.execution import (
    ExecutionProgramKind,
    LocalExecutionJob,
    LocalExecutionJobStatusIR,
)
from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.exceptions import CapabilityError
from cascaqit.native_ir.base import IRMixin
from cascaqit.native_ir.models import SCHEMA_VERSION, ProgramIR
from cascaqit.results import ResultIR
from cascaqit.simulators.pulser_reference import (
    PulserReferenceAdapter,
    PulserReferenceCapabilityIR,
    PulserReferenceRunIR,
    _require_actual_execution,
    probe_pulser_reference,
)

__all__ = [
    "PulserReferenceBackend",
    "PulserReferenceBackendCapabilityIR",
    "PulserReferenceJob",
]

PulserReferenceBackendStatus = Literal["available", "unavailable", "unsupported"]


@dataclass(frozen=True)
class PulserReferenceBackendCapabilityIR(IRMixin):
    """Bounded capability of the optional local Pulser reference backend."""

    status: PulserReferenceBackendStatus
    dependency_available: bool
    actual_execution_available: bool
    backend_id: str = "pulser.reference.local"
    supported_program_kinds: tuple[ExecutionProgramKind, ...] = ("analog",)
    execution_model: Literal["synchronous_lazy"] = "synchronous_lazy"
    supported_features: tuple[str, ...] = ()
    package_versions: dict[str, str] = field(default_factory=dict)
    diagnostics: tuple[DiagnosticsIR, ...] = ()
    single_site_only: bool = True
    exact_results_only: bool = True
    hybrid_state_handoff_supported: bool = False
    scan_supported: bool = False
    noise_supported: bool = False
    offline_deterministic: bool = True
    hardware_or_cloud_supported: bool = False
    execution_package_created: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Reject capability combinations that overstate reference execution."""
        if not isinstance(self.backend_id, str) or not self.backend_id.strip():
            raise ValueError("backend_id must be a non-empty string.")
        if self.status not in {"available", "unavailable", "unsupported"}:
            raise ValueError(f"Unsupported Pulser backend status: {self.status}")
        if self.actual_execution_available and not self.dependency_available:
            raise ValueError("Actual execution requires available dependencies.")
        if self.actual_execution_available and self.status != "available":
            raise ValueError("Actual execution requires available backend status.")
        if self.supported_program_kinds != ("analog",):
            raise ValueError("Pulser reference backend supports only Analog programs.")
        if self.execution_model != "synchronous_lazy":
            raise ValueError("Pulser reference backend must stay synchronous and lazy.")
        if not self.single_site_only or not self.exact_results_only:
            raise ValueError(
                "Pulser reference backend is limited to exact single-site runs."
            )
        if (
            self.hybrid_state_handoff_supported
            or self.scan_supported
            or self.noise_supported
            or not self.offline_deterministic
            or self.hardware_or_cloud_supported
            or self.execution_package_created
        ):
            raise ValueError("Pulser reference backend boundary cannot be broadened.")

    @classmethod
    def from_reference_capability(
        cls,
        capability: PulserReferenceCapabilityIR,
    ) -> PulserReferenceBackendCapabilityIR:
        """Project the existing dependency and semantic capability facts."""
        if not isinstance(capability, PulserReferenceCapabilityIR):
            raise TypeError("capability must be PulserReferenceCapabilityIR.")
        return cls(
            status=capability.status,
            dependency_available=capability.dependency_available,
            actual_execution_available=capability.actual_execution_available,
            supported_features=capability.supported_features,
            package_versions=dict(capability.package_versions),
            diagnostics=capability.diagnostics,
            metadata={
                **capability.metadata,
                "reference_capability_id": capability.capability_id,
            },
        )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PulserReferenceBackendCapabilityIR:
        """Build a capability from a JSON-compatible dictionary."""
        return cls(
            status=data["status"],
            dependency_available=bool(data["dependency_available"]),
            actual_execution_available=bool(data["actual_execution_available"]),
            backend_id=str(data.get("backend_id", "pulser.reference.local")),
            supported_program_kinds=tuple(
                data.get("supported_program_kinds", ("analog",))
            ),
            execution_model=data.get("execution_model", "synchronous_lazy"),
            supported_features=tuple(
                str(item) for item in data.get("supported_features", ())
            ),
            package_versions={
                str(key): str(value)
                for key, value in data.get("package_versions", {}).items()
            },
            diagnostics=tuple(
                DiagnosticsIR.from_dict(item) for item in data.get("diagnostics", ())
            ),
            single_site_only=bool(data.get("single_site_only", True)),
            exact_results_only=bool(data.get("exact_results_only", True)),
            hybrid_state_handoff_supported=bool(
                data.get("hybrid_state_handoff_supported", False)
            ),
            scan_supported=bool(data.get("scan_supported", False)),
            noise_supported=bool(data.get("noise_supported", False)),
            offline_deterministic=bool(data.get("offline_deterministic", True)),
            hardware_or_cloud_supported=bool(
                data.get("hardware_or_cloud_supported", False)
            ),
            execution_package_created=bool(
                data.get("execution_package_created", False)
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )


class PulserReferenceJob:
    """Thin typed evidence wrapper around the shared local execution Job."""

    def __init__(
        self,
        *,
        job_id: str,
        program_hash: str,
        backend_id: str,
        runner: Callable[[], PulserReferenceRunIR],
    ) -> None:
        if not callable(runner):
            raise TypeError("runner must be callable.")
        self.job_id = job_id
        self.backend_id = backend_id
        self._reference_runner = runner
        self._reference_run: PulserReferenceRunIR | None = None
        self._job = LocalExecutionJob(
            job_id=job_id,
            program_kind="analog",
            program_hash=program_hash,
            runner=self._run_reference,
            backend_id=backend_id,
        )

    def status(self) -> LocalExecutionJobStatusIR:
        """Return the shared immutable lifecycle snapshot."""
        return self._job.status()

    def result(self) -> ResultIR:
        """Execute at most once and return the cached standard ResultIR."""
        return self._job.result()

    def reference_run(self) -> PulserReferenceRunIR:
        """Return specialized evidence from the same cached execution."""
        result = self.result()
        reference_run = self._reference_run
        if reference_run is None or reference_run.result is not result:
            raise RuntimeError("Pulser reference evidence was not cached.")
        return reference_run

    def cancel(self) -> None:
        """Cancel the shared Job before execution starts."""
        self._job.cancel()

    def _run_reference(self) -> ResultIR:
        raw_run = self._reference_runner()
        if not isinstance(raw_run, PulserReferenceRunIR):
            raise TypeError("runner must return PulserReferenceRunIR.")
        if not raw_run.actual_execution or raw_run.result is None:
            raise RuntimeError("Pulser reference runner returned no actual result.")
        adapter_reference_run_hash = raw_run.stable_hash()
        result = replace(
            raw_run.result,
            metadata={
                **raw_run.result.metadata,
                "backend_id": self.backend_id,
                "selected_simulator": "PulserReferenceAdapter",
                "backend_called": True,
                "offline_deterministic": True,
                "network_accessed": False,
                "hardware_execution": False,
                "cloud_execution": False,
                "execution_package_created": False,
                "adapter_reference_run_hash": adapter_reference_run_hash,
            },
        )
        self._reference_run = replace(
            raw_run,
            result=result,
            metadata={
                **raw_run.metadata,
                "backend_id": self.backend_id,
                "backend_called": True,
                "execution_package_created": False,
                "adapter_reference_run_hash": adapter_reference_run_hash,
            },
        )
        return result


@dataclass(frozen=True)
class PulserReferenceBackend:
    """Offline exact Backend for the supported Pulser reference subset."""

    backend_id: str = "pulser.reference.local"
    adapter: PulserReferenceAdapter = field(
        default_factory=PulserReferenceAdapter,
        repr=False,
        compare=False,
    )

    def __post_init__(self) -> None:
        if not isinstance(self.backend_id, str) or not self.backend_id.strip():
            raise ValueError("backend_id must be a non-empty string.")
        if not isinstance(self.adapter, PulserReferenceAdapter):
            raise TypeError("adapter must be PulserReferenceAdapter.")

    @property
    def capability(self) -> PulserReferenceBackendCapabilityIR:
        """Return current dependency readiness without importing Pulser."""
        return PulserReferenceBackendCapabilityIR.from_reference_capability(
            probe_pulser_reference()
        )

    def run(
        self,
        program: object,
        *,
        shots: int | None = None,
        seed: int | None = None,
        job_id: str | None = None,
    ) -> PulserReferenceJob:
        """Preflight one exact Analog program and return a lazy local Job."""
        native = _reference_program(program)
        _validate_exact_options(shots=shots, seed=seed)
        capability = self.adapter.check(native)
        _require_actual_execution(
            capability,
            program_hash=native.stable_hash(),
            object_path="reference_backend.run",
        )
        resolved_job_id = (
            f"pulser_reference_job.{native.stable_hash()[:16]}"
            if job_id is None
            else job_id
        )
        return PulserReferenceJob(
            job_id=resolved_job_id,
            program_hash=native.stable_hash(),
            backend_id=self.backend_id,
            runner=lambda: self.adapter.run(native),
        )


def _reference_program(program: object) -> ProgramIR:
    from cascaqit.analog import AHSProgram

    if isinstance(program, AHSProgram):
        return ProgramIR.from_dict(program.to_ir().to_dict())
    if isinstance(program, ProgramIR):
        return ProgramIR.from_dict(program.to_dict())
    raise CapabilityError(
        "Pulser reference Backend requires AHSProgram or ProgramIR.",
        code="PULSER_REFERENCE_BACKEND_PROGRAM_UNSUPPORTED",
        stage="backend",
        object_path="reference_backend.run.program",
        suggestion="Use the documented single-site global Analog subset.",
        metadata={"actual_type": type(program).__name__},
    )


def _validate_exact_options(*, shots: object, seed: object) -> None:
    if shots is not None and (
        not isinstance(shots, int) or isinstance(shots, bool) or shots != 0
    ):
        raise CapabilityError(
            "Pulser reference Backend supports exact results only.",
            code="PULSER_REFERENCE_BACKEND_SHOTS_UNSUPPORTED",
            stage="backend",
            object_path="reference_backend.run.shots",
            suggestion="Pass shots=0 or omit shots.",
            metadata={"actual_shots": shots},
        )
    if seed is not None:
        raise CapabilityError(
            "Pulser reference Backend does not use a sampling seed.",
            code="PULSER_REFERENCE_BACKEND_SEED_UNSUPPORTED",
            stage="backend",
            object_path="reference_backend.run.seed",
            suggestion="Omit seed for exact deterministic execution.",
            metadata={"actual_seed": seed},
        )
