"""Internal diagnostics summary helpers for local simulator metadata."""

from __future__ import annotations

from typing import Any

from cascaqit.diagnostics import DiagnosticsIR

_STABLE_SEVERITY_KEYS = ("info", "warning", "error")


def build_diagnostics_summary(
    diagnostics: tuple[DiagnosticsIR, ...],
) -> dict[str, Any]:
    """Return the stable diagnostics metadata summary used by simulators.

    The summary is a convenience projection for ResultIR metadata and reports.
    ResultIR.diagnostics remains the source of truth for diagnostic content.
    """
    by_severity = {severity: 0 for severity in _STABLE_SEVERITY_KEYS}
    for diagnostic in diagnostics:
        by_severity[diagnostic.severity] = by_severity.get(
            diagnostic.severity,
            0,
        ) + 1
    return {
        "total": len(diagnostics),
        "by_severity": by_severity,
        "codes": [diagnostic.code for diagnostic in diagnostics],
    }
