"""Small deterministic state-vector simulator for DigitalProgramIR."""

from __future__ import annotations

import math
import random
from collections import Counter
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Literal

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.digital import (
    DigitalMeasurementIR,
    DigitalProgramIR,
    GateIR,
    build_digital_measurement_register_summary,
)
from cascaqit.exceptions import ProgramValidationError
from cascaqit.native_ir.models import SimulatorConfigIR
from cascaqit.results import ResultIR, ResultReferencesIR
from cascaqit.simulators.diagnostics import build_diagnostics_summary
from cascaqit.simulators.execution_evidence import (
    not_applicable_solver_evidence,
    solver_evidence_metadata,
)
from cascaqit.simulators.models import (
    SimulationAlgorithmIR,
    build_probability_state_summary,
    build_sample_state_summary,
    build_state_vector_metadata_summary,
    select_simulation_algorithm,
)
from cascaqit.simulators.runtime_lineage import (
    build_runtime_references,
    build_runtime_trace,
    build_state_transition,
    runtime_lineage_metadata,
)
from cascaqit.simulators.state import SimulationState

__all__ = ["DigitalStateVectorKernel", "LocalDigitalSimulator"]

_SIMULATOR_SUPPORTED_GATES = frozenset(
    {
        "i",
        "x",
        "y",
        "z",
        "h",
        "s",
        "sdg",
        "t",
        "tdg",
        "rx",
        "ry",
        "rz",
        "p",
        "u",
        "cx",
        "cy",
        "cz",
        "swap",
        "ccx",
    }
)


@dataclass(frozen=True)
class DigitalStateVectorKernel:
    """Evolve an explicit shared state through a static digital program."""

    max_qubits: int = 4

    def evolve(
        self,
        program: DigitalProgramIR,
        initial_state: SimulationState,
    ) -> SimulationState:
        """Return a new executable state after applying all digital gates."""
        if not isinstance(program, DigitalProgramIR):
            raise TypeError("DigitalStateVectorKernel accepts DigitalProgramIR.")
        if not isinstance(initial_state, SimulationState):
            raise TypeError("DigitalStateVectorKernel accepts SimulationState.")
        if initial_state.basis != "logical_two_level":
            _raise_digital_state_error(
                "Digital state kernel requires the logical two-level basis.",
                code="DIGITAL_STATE_BASIS_UNSUPPORTED",
                object_path="simulation_state.basis",
                suggestion="Convert the state to the P0 logical_two_level basis.",
                metadata={"basis": str(initial_state.basis)},
            )
        program_order = tuple(program.circuit.qubits)
        if initial_state.logical_order != program_order:
            _raise_digital_state_error(
                "Digital program qubits must match the state logical order.",
                code="DIGITAL_STATE_LOGICAL_ORDER_MISMATCH",
                object_path="simulation_state.logical_order",
                suggestion=(
                    "Apply an explicit SimulationState.permute() before evolution."
                ),
                metadata={
                    "program_order": list(program_order),
                    "state_order": list(initial_state.logical_order),
                },
            )
        diagnostics = _validate_program_for_simulation(
            program,
            max_qubits=self.max_qubits,
        )
        error_codes = tuple(
            diagnostic.code
            for diagnostic in diagnostics
            if diagnostic.severity == "error"
        )
        if error_codes:
            _raise_digital_state_error(
                "Digital program is not executable by the state kernel.",
                code="DIGITAL_STATE_PROGRAM_INVALID",
                object_path="digital_program",
                suggestion="Inspect the validation codes and fix the program.",
                metadata={"diagnostic_codes": list(error_codes)},
            )

        amplitudes = list(initial_state.amplitudes)
        qubit_index = {
            qubit: index for index, qubit in enumerate(program_order)
        }
        for gate in program.circuit.gates:
            amplitudes = _apply_gate(
                amplitudes,
                gate,
                qubit_index=qubit_index,
            )
        return initial_state.transitioned(
            amplitudes,
            producer="DigitalStateVectorKernel",
            source_hash=program.stable_hash(),
            state_id=f"state.{program.program_id}.digital",
            provenance_metadata={"gate_count": len(program.circuit.gates)},
        )


@dataclass(frozen=True)
class LocalDigitalSimulator:
    """Small exact state-vector simulator for static digital circuits."""

    seed: int | None = None
    max_qubits: int = 4
    target_id: str = "local.digital_simulator"
    created_at: str | None = None

    def run(
        self,
        program: DigitalProgramIR,
        *,
        shots: int = 1000,
        config: SimulatorConfigIR | None = None,
    ) -> ResultIR:
        """Run a small digital program and return ResultIR."""
        if not isinstance(program, DigitalProgramIR):
            raise TypeError("LocalDigitalSimulator.run accepts DigitalProgramIR.")
        simulator_config = _effective_config(
            config,
            default_shots=shots,
            default_seed=self.seed,
        )
        run_shots = simulator_config.shots
        run_seed = simulator_config.seed
        qubit_order = tuple(program.circuit.qubits)
        hilbert_dimension = 2 ** len(qubit_order)
        references = ResultReferencesIR(program_hash=program.stable_hash())
        algorithm = select_simulation_algorithm(
            simulator_name="LocalDigitalSimulator",
            program_type="digital",
            requested_method=simulator_config.method,
            hilbert_dimension=hilbert_dimension,
            max_hilbert_dim=min(simulator_config.max_hilbert_dim, 2**self.max_qubits),
            seed=run_seed,
            parameters={
                "gate_count": len(program.circuit.gates),
                "return_probabilities": simulator_config.return_probabilities,
            },
            metadata={"max_qubits": self.max_qubits},
        )
        diagnostics = [
            *_validate_program_for_simulation(program, max_qubits=self.max_qubits),
        ]
        if any(diagnostic.severity == "error" for diagnostic in diagnostics):
            return _invalid_result(
                program,
                shots=run_shots,
                diagnostics=tuple(diagnostics),
                algorithm=algorithm,
                references=references,
                seed=run_seed,
                created_at=self.created_at,
            )

        initial_state = SimulationState.zero(
            qubit_order,
            state_id=f"state.{program.program_id}.initial",
        )
        final_state = DigitalStateVectorKernel(max_qubits=self.max_qubits).evolve(
            program,
            initial_state,
        )
        evidence = not_applicable_solver_evidence(
            integrator_requested="auto",
            logical_time=final_state.logical_time,
            time_unit=final_state.time_unit,
            consumer=final_state.provenance.producer,
        )
        transition = build_state_transition(
            transition_id=f"transition.0.{program.program_id}",
            order_index=0,
            block_id=program.program_id,
            program_kind="digital",
            program_hash=program.stable_hash(),
            kernel=final_state.provenance.producer,
            input_state_hash=initial_state.stable_hash(),
            output_state_hash=final_state.stable_hash(),
            input_logical_time=initial_state.logical_time,
            output_logical_time=final_state.logical_time,
            time_unit=final_state.time_unit,
            solver_evidence=evidence,
            metadata={
                "input_state_id": initial_state.state_id,
                "output_state_id": final_state.state_id,
                "logical_order": list(final_state.logical_order),
            },
        )
        references = build_runtime_references(
            program_hash=program.stable_hash(),
            initial_state_hash=initial_state.stable_hash(),
            final_state_hash=final_state.stable_hash(),
        )
        trace = build_runtime_trace(
            trace_id=f"trace.{program.program_id}.local_digital",
            transitions=(transition,),
            references=references,
            execution_mode="standalone_digital",
            terminal_message="Terminal Digital sampling completed.",
            terminal_metadata={"shots": run_shots, "seed": run_seed},
        )
        state = list(final_state.amplitudes)
        probabilities = _probabilities(state, qubit_count=len(qubit_order))
        samples = _sample(probabilities, shots=run_shots, seed=run_seed)
        counts = dict(Counter(samples)) if run_shots > 0 else {}
        measurement_projection = _measurement_projection(
            program,
            probabilities=probabilities,
            samples=samples,
            qubit_order=qubit_order,
        )
        observables = _z_expectations(probabilities, qubit_order=qubit_order)
        completed_diagnostic = DiagnosticsIR(
            diagnostic_id="digital.simulation.completed",
            stage="simulation",
            severity="info",
            code="DIGITAL_SIMULATION_COMPLETED",
            message="Local digital state-vector simulation completed.",
            object_path="result",
            metadata={"program_id": program.program_id},
        )
        validation_diagnostics = _result_alignment_diagnostics(
            probabilities,
            samples=samples,
            shots=run_shots,
            qubit_order=qubit_order,
            state_dimension=len(state),
        )
        state_vector_summary = build_state_vector_metadata_summary(
            state_id=f"state.{program.program_id}.state_vector",
            basis="computational",
            dimension=len(state),
            norm=_state_norm(state),
            qubit_order=qubit_order,
            returned_state_bytes=False,
            metadata={"source": "LocalDigitalSimulator"},
        )
        probability_state = build_probability_state_summary(
            probabilities,
            state_id=f"state.{program.program_id}.probabilities",
            basis="computational",
            qubit_order=qubit_order,
            metadata={
                "source": "LocalDigitalSimulator",
                "returned_inline": simulator_config.return_probabilities,
            },
        )
        sample_state = build_sample_state_summary(
            samples,
            state_id=f"state.{program.program_id}.samples",
            basis="computational",
            qubit_order=qubit_order,
            metadata={"source": "LocalDigitalSimulator"},
        )
        simulator_metadata = {
            "name": "LocalDigitalSimulator",
            "method": "state_vector",
            "config": simulator_config.to_dict(),
            "max_qubits": self.max_qubits,
            "qubit_order": list(qubit_order),
        }
        result_metadata: dict[str, Any] = {
            "created_at": _created_at(self.created_at),
            "seed": run_seed,
            **solver_evidence_metadata(evidence),
            **runtime_lineage_metadata(
                transitions=(transition,),
                references=references,
                trace=trace,
            ),
            "simulator": simulator_metadata,
            "bitstring_ordering": {
                "convention": "digital_qubit_order",
                "qubit_order": list(qubit_order),
                "bitstring_index": "left_to_right_matches_qubit_order",
                "zero_state": "0",
                "one_state": "1",
            },
            "basis_probability": {
                "basis": "computational",
                "qubit_order": list(qubit_order),
                "probability_mass": sum(probabilities.values()),
                "returned_inline": simulator_config.return_probabilities,
            },
            "diagnostics_summary": _diagnostics_summary(
                (completed_diagnostic, *validation_diagnostics)
            ),
            "simulation_algorithm": algorithm.to_dict(),
            "simulation_state": {
                "state_vector": state_vector_summary.to_dict(),
                "primary": probability_state.to_dict(),
                "samples": sample_state.to_dict(),
                "state_bytes_returned": False,
                "physical_accuracy": "small_exact_state_vector_baseline",
            },
            "state_hash": final_state.stable_hash(),
        }
        if measurement_projection is not None:
            result_metadata["measurement_projection"] = measurement_projection
        return ResultIR(
            result_id=f"result.{program.program_id}",
            program_hash=program.stable_hash(),
            target_id=self.target_id,
            shots=run_shots,
            counts=counts,
            samples=samples,
            probabilities=(
                probabilities if simulator_config.return_probabilities else None
            ),
            observables=observables,
            bit_ordering={
                "convention": "digital_qubit_order",
                "qubits": ",".join(qubit_order),
            },
            diagnostics=(
                completed_diagnostic,
                *validation_diagnostics,
            ),
            metadata=result_metadata,
        )


def _effective_config(
    config: SimulatorConfigIR | None,
    *,
    default_shots: int,
    default_seed: int | None,
) -> SimulatorConfigIR:
    if config is not None:
        return config
    return SimulatorConfigIR(shots=default_shots, seed=default_seed)


def _validate_program_for_simulation(
    program: DigitalProgramIR,
    *,
    max_qubits: int,
) -> tuple[DiagnosticsIR, ...]:
    diagnostics: list[DiagnosticsIR] = []
    diagnostics.extend(
        diagnostic
        for diagnostic in program.validate_ir_only()
        if diagnostic.severity != "info"
    )
    if len(program.circuit.qubits) > max_qubits:
        diagnostics.append(
            _diagnostic(
                code="DIGITAL_SIMULATION_QUBIT_LIMIT_EXCEEDED",
                message="LocalDigitalSimulator supports only small circuits.",
                object_path="digital_program.circuit.qubits",
                severity="error",
                metadata={
                    "qubit_count": len(program.circuit.qubits),
                    "max_qubits": max_qubits,
                },
            )
        )
    for index, measurement in enumerate(program.circuit.measurements):
        if measurement.basis not in {"computational", "z"}:
            diagnostics.append(
                _diagnostic(
                    code="DIGITAL_MEASUREMENT_BASIS_UNSUPPORTED",
                    message=(
                        "Only computational/Z-basis terminal measurement is "
                        "supported."
                    ),
                    object_path=f"digital_program.circuit.measurements[{index}].basis",
                    severity="error",
                    metadata={"basis": measurement.basis},
                )
            )
    for index, gate in enumerate(program.circuit.gates):
        if gate.name not in _SIMULATOR_SUPPORTED_GATES:
            diagnostics.append(
                _diagnostic(
                    code="DIGITAL_SIMULATION_GATE_UNSUPPORTED",
                    message=(
                        "LocalDigitalSimulator supports only the documented "
                        "static digital gate set."
                    ),
                    object_path=f"digital_program.circuit.gates[{index}].name",
                    severity="error",
                    metadata={
                        "gate_name": gate.name,
                        "supported_gates": sorted(_SIMULATOR_SUPPORTED_GATES),
                    },
                )
            )
        non_finite_parameters = [
            name
            for name, value in gate.parameters.items()
            if not math.isfinite(value)
        ]
        if non_finite_parameters:
            diagnostics.append(
                _diagnostic(
                    code="DIGITAL_GATE_PARAMETER_NONFINITE",
                    message="Digital simulator gate parameters must be finite.",
                    object_path=f"digital_program.circuit.gates[{index}].parameters",
                    severity="error",
                    metadata={
                        "gate_name": gate.name,
                        "parameter_names": non_finite_parameters,
                    },
                )
            )
    if not diagnostics:
        diagnostics.append(
            _diagnostic(
                code="DIGITAL_SIMULATION_INPUT_VALID",
                message="Digital program is supported by the local baseline simulator.",
                object_path="digital_program",
                severity="info",
                metadata={"program_id": program.program_id},
            )
        )
    return tuple(diagnostics)


def _invalid_result(
    program: DigitalProgramIR,
    *,
    shots: int,
    diagnostics: tuple[DiagnosticsIR, ...],
    algorithm: SimulationAlgorithmIR,
    references: ResultReferencesIR,
    seed: int | None,
    created_at: str | None,
) -> ResultIR:
    invalid_diagnostic = _diagnostic(
        code="DIGITAL_SIMULATION_INPUT_INVALID",
        message="Digital simulation input failed validation.",
        object_path="digital_program",
        severity="error",
        suggestion="Inspect diagnostics and fix the digital program.",
    )
    result_diagnostics = (invalid_diagnostic, *diagnostics)
    return ResultIR(
        result_id=f"result.{program.program_id}",
        program_hash=program.stable_hash(),
        target_id="local.digital_simulator",
        shots=shots,
        counts={},
        samples=(),
        probabilities=None,
        diagnostics=result_diagnostics,
        metadata={
            "created_at": _created_at(created_at),
            "references": references.to_dict(),
            "seed": seed,
            "simulator": {"name": "LocalDigitalSimulator", "method": "state_vector"},
            "diagnostics_summary": _diagnostics_summary(result_diagnostics),
            "simulation_algorithm": algorithm.to_dict(),
            "simulation_state": {
                "state_vector": None,
                "primary": None,
                "samples": None,
                "state_bytes_returned": False,
                "physical_accuracy": "not_computed_input_invalid",
            },
        },
    )


def _apply_gate(
    state: list[complex],
    gate: GateIR,
    *,
    qubit_index: dict[str, int],
) -> list[complex]:
    if gate.name == "i":
        return state
    if gate.name == "x":
        return _apply_single_qubit_gate(
            state,
            qubit_index[gate.targets[0]],
            _x_matrix(),
        )
    if gate.name == "y":
        return _apply_single_qubit_gate(
            state,
            qubit_index[gate.targets[0]],
            _y_matrix(),
        )
    if gate.name == "z":
        return _apply_single_qubit_gate(
            state,
            qubit_index[gate.targets[0]],
            _z_matrix(),
        )
    if gate.name == "h":
        return _apply_single_qubit_gate(
            state,
            qubit_index[gate.targets[0]],
            _h_matrix(),
        )
    if gate.name == "s":
        return _apply_single_qubit_gate(
            state,
            qubit_index[gate.targets[0]],
            _phase_matrix(math.pi / 2.0),
        )
    if gate.name == "sdg":
        return _apply_single_qubit_gate(
            state,
            qubit_index[gate.targets[0]],
            _phase_matrix(-math.pi / 2.0),
        )
    if gate.name == "t":
        return _apply_single_qubit_gate(
            state,
            qubit_index[gate.targets[0]],
            _phase_matrix(math.pi / 4.0),
        )
    if gate.name == "tdg":
        return _apply_single_qubit_gate(
            state,
            qubit_index[gate.targets[0]],
            _phase_matrix(-math.pi / 4.0),
        )
    if gate.name == "rx":
        return _apply_single_qubit_gate(
            state,
            qubit_index[gate.targets[0]],
            _rx_matrix(gate.parameters["theta"]),
        )
    if gate.name == "ry":
        return _apply_single_qubit_gate(
            state,
            qubit_index[gate.targets[0]],
            _ry_matrix(gate.parameters["theta"]),
        )
    if gate.name == "rz":
        return _apply_single_qubit_gate(
            state,
            qubit_index[gate.targets[0]],
            _rz_matrix(gate.parameters["theta"]),
        )
    if gate.name == "p":
        return _apply_single_qubit_gate(
            state,
            qubit_index[gate.targets[0]],
            _phase_matrix(gate.parameters["theta"]),
        )
    if gate.name == "u":
        return _apply_single_qubit_gate(
            state,
            qubit_index[gate.targets[0]],
            _u_matrix(
                gate.parameters["theta"],
                gate.parameters["phi"],
                gate.parameters["lambda"],
            ),
        )
    if gate.name == "cx":
        return _apply_controlled_single_qubit_gate(
            state,
            control=qubit_index[gate.targets[0]],
            target=qubit_index[gate.targets[1]],
            matrix=_x_matrix(),
        )
    if gate.name == "cy":
        return _apply_controlled_single_qubit_gate(
            state,
            control=qubit_index[gate.targets[0]],
            target=qubit_index[gate.targets[1]],
            matrix=_y_matrix(),
        )
    if gate.name == "cz":
        return _apply_cz(
            state,
            control=qubit_index[gate.targets[0]],
            target=qubit_index[gate.targets[1]],
        )
    if gate.name == "swap":
        return _apply_swap(
            state,
            left=qubit_index[gate.targets[0]],
            right=qubit_index[gate.targets[1]],
        )
    if gate.name == "ccx":
        return _apply_ccx(
            state,
            control0=qubit_index[gate.targets[0]],
            control1=qubit_index[gate.targets[1]],
            target=qubit_index[gate.targets[2]],
        )
    raise ValueError(f"Unsupported digital gate: {gate.name!r}")


def _x_matrix() -> tuple[tuple[complex, complex], tuple[complex, complex]]:
    return ((0j, 1.0 + 0j), (1.0 + 0j, 0j))


def _y_matrix() -> tuple[tuple[complex, complex], tuple[complex, complex]]:
    return ((0j, -1j), (1j, 0j))


def _z_matrix() -> tuple[tuple[complex, complex], tuple[complex, complex]]:
    return ((1.0 + 0j, 0j), (0j, -1.0 + 0j))


def _h_matrix() -> tuple[tuple[complex, complex], tuple[complex, complex]]:
    scale = 1.0 / math.sqrt(2.0)
    return ((scale + 0j, scale + 0j), (scale + 0j, -scale + 0j))


def _rx_matrix(theta: float) -> tuple[tuple[complex, complex], tuple[complex, complex]]:
    half = theta / 2.0
    cosine = math.cos(half)
    sine = math.sin(half)
    return ((cosine, -1j * sine), (-1j * sine, cosine))


def _ry_matrix(theta: float) -> tuple[tuple[complex, complex], tuple[complex, complex]]:
    half = theta / 2.0
    cosine = math.cos(half)
    sine = math.sin(half)
    return ((cosine, -sine), (sine, cosine))


def _rz_matrix(theta: float) -> tuple[tuple[complex, complex], tuple[complex, complex]]:
    half = theta / 2.0
    return (
        (complex(math.cos(-half), math.sin(-half)), 0j),
        (0j, complex(math.cos(half), math.sin(half))),
    )


def _phase_matrix(
    theta: float,
) -> tuple[tuple[complex, complex], tuple[complex, complex]]:
    return ((1.0 + 0j, 0j), (0j, complex(math.cos(theta), math.sin(theta))))


def _u_matrix(
    theta: float,
    phi: float,
    lam: float,
) -> tuple[tuple[complex, complex], tuple[complex, complex]]:
    half = theta / 2.0
    cosine = math.cos(half)
    sine = math.sin(half)
    exp_phi = complex(math.cos(phi), math.sin(phi))
    exp_lam = complex(math.cos(lam), math.sin(lam))
    exp_phi_lam = complex(math.cos(phi + lam), math.sin(phi + lam))
    return (
        (cosine + 0j, -exp_lam * sine),
        (exp_phi * sine, exp_phi_lam * cosine),
    )


def _apply_single_qubit_gate(
    state: list[complex],
    qubit: int,
    matrix: tuple[tuple[complex, complex], tuple[complex, complex]],
) -> list[complex]:
    qubit_count = _qubit_count_from_state(state)
    mask = 1 << (qubit_count - qubit - 1)
    output = list(state)
    for index in range(len(state)):
        if index & mask:
            continue
        paired = index | mask
        zero = state[index]
        one = state[paired]
        output[index] = matrix[0][0] * zero + matrix[0][1] * one
        output[paired] = matrix[1][0] * zero + matrix[1][1] * one
    return output


def _apply_controlled_single_qubit_gate(
    state: list[complex],
    *,
    control: int,
    target: int,
    matrix: tuple[tuple[complex, complex], tuple[complex, complex]],
) -> list[complex]:
    qubit_count = _qubit_count_from_state(state)
    control_mask = 1 << (qubit_count - control - 1)
    target_mask = 1 << (qubit_count - target - 1)
    output = list(state)
    for index in range(len(state)):
        if not index & control_mask or index & target_mask:
            continue
        paired = index | target_mask
        zero = state[index]
        one = state[paired]
        output[index] = matrix[0][0] * zero + matrix[0][1] * one
        output[paired] = matrix[1][0] * zero + matrix[1][1] * one
    return output


def _apply_cz(state: list[complex], *, control: int, target: int) -> list[complex]:
    qubit_count = _qubit_count_from_state(state)
    control_mask = 1 << (qubit_count - control - 1)
    target_mask = 1 << (qubit_count - target - 1)
    output = list(state)
    for index, amplitude in enumerate(state):
        if index & control_mask and index & target_mask:
            output[index] = -amplitude
    return output


def _apply_swap(state: list[complex], *, left: int, right: int) -> list[complex]:
    if left == right:
        return state
    qubit_count = _qubit_count_from_state(state)
    left_mask = 1 << (qubit_count - left - 1)
    right_mask = 1 << (qubit_count - right - 1)
    output = list(state)
    for index, amplitude in enumerate(state):
        left_bit = bool(index & left_mask)
        right_bit = bool(index & right_mask)
        if left_bit == right_bit:
            output[index] = amplitude
            continue
        swapped = index ^ left_mask ^ right_mask
        output[swapped] = amplitude
    return output


def _apply_ccx(
    state: list[complex],
    *,
    control0: int,
    control1: int,
    target: int,
) -> list[complex]:
    qubit_count = _qubit_count_from_state(state)
    control0_mask = 1 << (qubit_count - control0 - 1)
    control1_mask = 1 << (qubit_count - control1 - 1)
    target_mask = 1 << (qubit_count - target - 1)
    output = list(state)
    for index, amplitude in enumerate(state):
        if (
            index & control0_mask
            and index & control1_mask
            and not index & target_mask
        ):
            paired = index | target_mask
            output[index] = state[paired]
            output[paired] = amplitude
    return output


def _probabilities(state: list[complex], *, qubit_count: int) -> dict[str, float]:
    raw = {
        format(index, f"0{qubit_count}b"): abs(amplitude) ** 2
        for index, amplitude in enumerate(state)
    }
    total = sum(raw.values())
    return {key: value / total for key, value in raw.items()}


def _z_expectations(
    probabilities: dict[str, float],
    *,
    qubit_order: tuple[str, ...],
) -> dict[str, float | dict[str, float]]:
    expectations: dict[str, float] = {}
    for index, qubit in enumerate(qubit_order):
        value = 0.0
        for bitstring, probability in probabilities.items():
            value += (1.0 if bitstring[index] == "0" else -1.0) * probability
        expectations[f"z:{qubit}"] = value
    return {
        "pauli_z": expectations,
    }


def _measurement_projection(
    program: DigitalProgramIR,
    *,
    probabilities: dict[str, float],
    samples: tuple[str, ...],
    qubit_order: tuple[str, ...],
) -> dict[str, Any] | None:
    summary = build_digital_measurement_register_summary(program)
    measurements = tuple(program.circuit.measurements)
    if not _needs_measurement_projection(measurements, qubit_order=qubit_order):
        return None
    return {
        "projection_kind": "local_digital_register_projection",
        "metadata_only": True,
        "counts_are_full_bitstrings": True,
        "samples_are_full_bitstrings": True,
        "hardware_execution": False,
        "cloud_execution": False,
        "hanyuan_live_digital_execution": "unsupported",
        "measurement_mapping": summary.measurement_mapping,
        "duplicate_keys": summary.metadata["duplicate_keys"],
        "repeated_targets": summary.metadata["repeated_targets"],
        "uncovered_qubits": summary.metadata["uncovered_qubits"],
        "registers": [
            _measurement_register_projection(
                measurement,
                probabilities=probabilities,
                samples=samples,
                qubit_order=qubit_order,
            )
            for measurement in measurements
        ],
    }


def _needs_measurement_projection(
    measurements: tuple[DigitalMeasurementIR, ...],
    *,
    qubit_order: tuple[str, ...],
) -> bool:
    if len(measurements) != 1:
        return bool(measurements)
    return measurements[0].targets != qubit_order


def _measurement_register_projection(
    measurement: DigitalMeasurementIR,
    *,
    probabilities: dict[str, float],
    samples: tuple[str, ...],
    qubit_order: tuple[str, ...],
) -> dict[str, Any]:
    target_indices = tuple(qubit_order.index(target) for target in measurement.targets)
    projected_probabilities: dict[str, float] = {}
    for bitstring, probability in probabilities.items():
        projected = _project_bitstring(bitstring, target_indices=target_indices)
        projected_probabilities[projected] = (
            projected_probabilities.get(projected, 0.0) + probability
        )
    projected_samples = tuple(
        _project_bitstring(sample, target_indices=target_indices)
        for sample in samples
    )
    projected_counts = dict(Counter(projected_samples)) if samples else {}
    return {
        "measurement_id": measurement.measurement_id,
        "key": measurement.key,
        "basis": measurement.basis,
        "targets": list(measurement.targets),
        "target_bit_indices": list(target_indices),
        "bitstring_index": "left_to_right_matches_qubit_order",
        "probabilities": projected_probabilities,
        "counts": projected_counts,
        "samples": list(projected_samples),
    }


def _project_bitstring(
    bitstring: str,
    *,
    target_indices: tuple[int, ...],
) -> str:
    return "".join(bitstring[index] for index in target_indices)


def _result_alignment_diagnostics(
    probabilities: dict[str, float],
    *,
    samples: tuple[str, ...],
    shots: int,
    qubit_order: tuple[str, ...],
    state_dimension: int,
) -> tuple[DiagnosticsIR, ...]:
    diagnostics: list[DiagnosticsIR] = []
    probability_mass = sum(probabilities.values())
    if abs(probability_mass - 1.0) > 1e-9:
        diagnostics.append(
            _diagnostic(
                code="DIGITAL_PROBABILITY_MASS_INVALID",
                message="Digital probability mass must be close to 1.",
                object_path="result.probabilities",
                severity="error",
                metadata={"probability_mass": probability_mass},
            )
        )
    expected_dimension = 2 ** len(qubit_order)
    if state_dimension != expected_dimension:
        diagnostics.append(
            _diagnostic(
                code="DIGITAL_STATE_DIMENSION_INVALID",
                message="Digital state dimension must match qubit order.",
                object_path="result.metadata.simulation_state.state_vector.dimension",
                severity="error",
                metadata={
                    "state_dimension": state_dimension,
                    "expected_dimension": expected_dimension,
                },
            )
        )
    if shots != len(samples):
        diagnostics.append(
            _diagnostic(
                code="DIGITAL_SAMPLE_COUNT_MISMATCH",
                message="Digital sample count must match requested shots.",
                object_path="result.samples",
                severity="error",
                metadata={"shots": shots, "sample_count": len(samples)},
            )
        )
    if not diagnostics:
        diagnostics.append(
            _diagnostic(
                code="DIGITAL_RESULT_ALIGNMENT_VALID",
                message="Digital result probabilities, samples, and bit order align.",
                object_path="result",
                severity="info",
                metadata={
                    "probability_mass": probability_mass,
                    "state_dimension": state_dimension,
                    "qubit_order": list(qubit_order),
                },
            )
        )
    return tuple(diagnostics)


def _diagnostics_summary(
    diagnostics: tuple[DiagnosticsIR, ...],
) -> dict[str, object]:
    return build_diagnostics_summary(diagnostics)


def _sample(
    probabilities: dict[str, float],
    *,
    shots: int,
    seed: int | None,
) -> tuple[str, ...]:
    if shots <= 0:
        return ()
    rng = random.Random(seed)
    outcomes = tuple(sorted(probabilities))
    weights = tuple(probabilities[outcome] for outcome in outcomes)
    return tuple(rng.choices(outcomes, weights=weights, k=shots))


def _state_norm(state: list[complex]) -> float:
    return math.sqrt(sum(abs(amplitude) ** 2 for amplitude in state))


def _qubit_count_from_state(state: list[complex]) -> int:
    return int(math.log2(len(state)))


def _created_at(value: str | None) -> str:
    return value if value is not None else datetime.now(timezone.utc).isoformat()


def _diagnostic(
    *,
    code: str,
    message: str,
    object_path: str,
    severity: Literal["info", "warning", "error"],
    suggestion: str | None = None,
    metadata: dict[str, object] | None = None,
) -> DiagnosticsIR:
    diagnostic_metadata = {} if metadata is None else dict(metadata)
    if severity != "info":
        diagnostic_metadata.setdefault("reason_category", "simulation")
        diagnostic_metadata.setdefault("taxonomy_stage", "simulation")
        diagnostic_metadata.setdefault("actionable", bool(suggestion))
        if suggestion:
            diagnostic_metadata.setdefault(
                "action",
                "fix_digital_simulation_input",
            )
    return DiagnosticsIR(
        diagnostic_id=f"digital.simulation.{code.lower()}",
        stage="simulation",
        severity=severity,
        code=code,
        message=message,
        object_path=object_path,
        suggestion=suggestion,
        metadata=diagnostic_metadata,
    )


def _raise_digital_state_error(
    message: str,
    *,
    code: str,
    object_path: str,
    suggestion: str,
    metadata: dict[str, object] | None = None,
) -> None:
    raise ProgramValidationError(
        message,
        code=code,
        stage="simulation",
        object_path=object_path,
        suggestion=suggestion,
        metadata={
            "reason_category": "digital_state_kernel",
            **({} if metadata is None else metadata),
        },
    )
