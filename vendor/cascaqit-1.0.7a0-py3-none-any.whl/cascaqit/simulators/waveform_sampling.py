"""Shared numeric sampling for executable Analog waveforms."""

from __future__ import annotations

from functools import lru_cache
from typing import Any

from scipy.interpolate import PchipInterpolator  # type: ignore[import-untyped]

from cascaqit.native_ir import WaveformIR

__all__ = ["sample_waveform"]


def sample_waveform(waveform: WaveformIR, time: float) -> float:
    """Evaluate one bound waveform using its declared interpolation semantics."""
    if waveform.values is None:
        if "bound_value" in waveform.parameters:
            return float(waveform.parameters["bound_value"])
        return float(waveform.parameters.get("value", 0.0))
    if waveform.kind == "constant":
        return float(waveform.values[0])
    if waveform.times is None:
        if waveform.kind == "interpolated":
            raise ValueError("interpolated waveform requires explicit sample times.")
        return float(waveform.values[-1])
    if time <= waveform.times[0]:
        return float(waveform.values[0])
    if waveform.kind == "interpolated":
        # PCHIP does not extrapolate. Clamp only this new kind so the established
        # left-continuous piecewise-constant endpoint remains unchanged.
        if time >= waveform.times[-1]:
            return float(waveform.values[-1])
        return float(_pchip(waveform.times, waveform.values)(time))
    for index, right_time in enumerate(waveform.times[1:], start=1):
        if time <= right_time:
            left_time = waveform.times[index - 1]
            left_value = waveform.values[index - 1]
            if waveform.kind == "piecewise_constant":
                return float(left_value)
            fraction = (time - left_time) / (right_time - left_time)
            return float(left_value + fraction * (waveform.values[index] - left_value))
    return float(waveform.values[-1])


@lru_cache(maxsize=256)
def _pchip(
    times: tuple[float, ...],
    values: tuple[float, ...],
) -> Any:
    """Cache immutable PCHIP coefficients across solver time steps.

    Time evolution samples the same control thousands of times. Caching on the
    numeric tuples keeps interpolation setup O(points) per waveform, not per step.
    """
    return PchipInterpolator(times, values, extrapolate=False)
