"""Private dependency-light helpers shared across native SDK packages."""
