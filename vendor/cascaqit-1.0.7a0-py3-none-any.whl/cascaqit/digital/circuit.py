"""User-facing fluent builder for static digital circuits."""

from __future__ import annotations

import copy
import hashlib
import json
import math
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, NoReturn, Union, cast

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.digital.models import (
    DigitalGateName,
    DigitalMeasurementIR,
    DigitalProgramIR,
    GateIR,
    build_digital_program,
)
from cascaqit.exceptions import ProgramValidationError
from cascaqit.native_ir.base import IRMixin, canonicalize, stable_json
from cascaqit.native_ir.models import SCHEMA_VERSION
from cascaqit.parameters.affine import AffineForm, _AffineFormError, affine_form
from cascaqit.parameters.canonical import Expression, Parameter

if TYPE_CHECKING:
    from cascaqit.results import ResultIR

__all__ = ["Circuit", "GateParameterOccurrence"]

QubitRef = Union[int, str]
DigitalValue = Union[int, float, Parameter, Expression]

_GATE_SIGNATURES: dict[str, tuple[int, tuple[str, ...]]] = {
    "i": (1, ()),
    "x": (1, ()),
    "y": (1, ()),
    "z": (1, ()),
    "h": (1, ()),
    "s": (1, ()),
    "sdg": (1, ()),
    "t": (1, ()),
    "tdg": (1, ()),
    "rx": (1, ("theta",)),
    "ry": (1, ("theta",)),
    "rz": (1, ("theta",)),
    "p": (1, ("theta",)),
    "u": (1, ("theta", "phi", "lambda")),
    "cx": (2, ()),
    "cy": (2, ()),
    "cz": (2, ()),
    "swap": (2, ()),
    "ccx": (3, ()),
}

_SELF_INVERSE_GATES = frozenset(
    {"i", "x", "y", "z", "h", "cx", "cy", "cz", "swap", "ccx"}
)
_PAIRED_INVERSE_GATES: dict[str, DigitalGateName] = {
    "s": "sdg",
    "sdg": "s",
    "t": "tdg",
    "tdg": "t",
}
_ANGLE_INVERSE_GATES = frozenset({"rx", "ry", "rz", "p"})
_CONTROLLED_GATE_NAMES: dict[DigitalGateName, DigitalGateName] = {
    "i": "i",
    "x": "cx",
    "y": "cy",
    "z": "cz",
    "cx": "ccx",
}
_MAX_REPEAT_COUNT = 1024


@dataclass(frozen=True)
class _ParameterizedGate:
    """Private declaration retained until all parameter values are bound."""

    gate_id: str
    name: DigitalGateName
    targets: tuple[str, ...]
    parameters: dict[str, DigitalValue]
    controls: tuple[str, ...] = ()
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class GateParameterOccurrence(IRMixin):
    """Stable observation of one gate parameter field in a Circuit snapshot."""

    occurrence_id: str
    source_circuit_hash: str
    gate_index: int
    gate_id: str
    gate_name: DigitalGateName
    targets: tuple[str, ...]
    parameter_name: str
    parameter_value: DigitalValue
    affine_form: AffineForm | None
    supported: bool
    unsupported_reason: str | None = None

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> GateParameterOccurrence:
        """Restore an occurrence without accessing Circuit private objects."""
        raw_value = data["parameter_value"]
        value: DigitalValue
        if isinstance(raw_value, bool):
            raise TypeError("occurrence parameter_value must not be bool.")
        if isinstance(raw_value, (int, float)):
            value = raw_value
        elif isinstance(raw_value, Mapping) and "node_type" in raw_value:
            value = Expression.from_dict(raw_value)
        elif isinstance(raw_value, Mapping) and "name" in raw_value:
            value = Parameter.from_dict(raw_value)
        else:
            raise TypeError("occurrence parameter_value has an unknown shape.")
        raw_form = data.get("affine_form")
        return cls(
            occurrence_id=str(data["occurrence_id"]),
            source_circuit_hash=str(data["source_circuit_hash"]),
            gate_index=int(data["gate_index"]),
            gate_id=str(data["gate_id"]),
            gate_name=cast(DigitalGateName, data["gate_name"]),
            targets=tuple(str(target) for target in data["targets"]),
            parameter_name=str(data["parameter_name"]),
            parameter_value=value,
            affine_form=(
                None
                if raw_form is None
                else AffineForm.from_dict(cast(Mapping[str, object], raw_form))
            ),
            supported=bool(data["supported"]),
            unsupported_reason=(
                None
                if data.get("unsupported_reason") is None
                else str(data["unsupported_reason"])
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> GateParameterOccurrence:
        """Restore an occurrence from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("GateParameterOccurrence JSON must contain an object.")
        return cls.from_dict(data)


class Circuit:
    """Build and run a static digital circuit without constructing IR objects."""

    def __init__(
        self,
        qubits: int | Sequence[str],
        *,
        program_id: str = "program.digital",
        metadata: dict[str, Any] | None = None,
    ) -> None:
        self._qubits = _normalize_qubits(qubits)
        if not str(program_id).strip():
            _raise_builder_error(
                "Digital circuit program_id must not be empty.",
                code="DIGITAL_CIRCUIT_PROGRAM_ID_EMPTY",
                object_path="circuit.program_id",
                suggestion="Pass a non-empty program_id such as 'program.bell'.",
            )
        self._program_id = str(program_id)
        self._metadata = {} if metadata is None else dict(metadata)
        self._gates: list[GateIR | _ParameterizedGate] = []
        self._measurements: list[DigitalMeasurementIR] = []
        self._parameters: list[Parameter] = []
        self._bound_parameter_values: dict[str, float] | None = None
        self._control_depth = 0

    @property
    def program_id(self) -> str:
        """Return the program identifier used by to_program()."""
        return self._program_id

    @property
    def qubits(self) -> tuple[str, ...]:
        """Return the stable logical qubit order."""
        return self._qubits

    @property
    def metadata(self) -> dict[str, Any]:
        """Return an independent copy of user and transformation metadata."""
        return copy.deepcopy(self._metadata)

    @property
    def gates(self) -> tuple[GateIR, ...]:
        """Return the gates built so far as immutable native IR."""
        self._require_bound()
        return tuple(
            gate for gate in self._gates if isinstance(gate, GateIR)
        )

    @property
    def measurements(self) -> tuple[DigitalMeasurementIR, ...]:
        """Return terminal measurements built so far as immutable native IR."""
        return tuple(self._measurements)

    @property
    def parameters(self) -> tuple[Parameter, ...]:
        """Return parameter declarations in stable declaration order."""
        return tuple(self._parameters)

    @property
    def gate_names(self) -> tuple[DigitalGateName, ...]:
        """Return declared gate names without requiring parameter binding."""
        return tuple(gate.name for gate in self._gates)

    @property
    def referenced_parameter_names(self) -> tuple[str, ...]:
        """Return referenced parameters in declaration order."""
        referenced = self._referenced_parameter_names()
        return tuple(
            parameter.name
            for parameter in self._parameters
            if parameter.name in referenced
        )

    @property
    def is_bound(self) -> bool:
        """Return whether every gate can be lowered to numeric native IR."""
        return not any(
            isinstance(gate, _ParameterizedGate) for gate in self._gates
        )

    def snapshot(self) -> Circuit:
        """Return an independent copy of this possibly parameterized circuit."""
        snapshot = copy.copy(self)
        snapshot._gates = [
            _copy_declared_gate(gate, gate_id=gate.gate_id)
            for gate in self._gates
        ]
        snapshot._measurements = [
            DigitalMeasurementIR.from_dict(measurement.to_dict())
            for measurement in self._measurements
        ]
        snapshot._parameters = list(self._parameters)
        snapshot._metadata = dict(self._metadata)
        snapshot._bound_parameter_values = (
            None
            if self._bound_parameter_values is None
            else dict(self._bound_parameter_values)
        )
        return snapshot

    def structural_payload(self) -> dict[str, Any]:
        """Return the canonical parameterized operation snapshot."""
        # Ansatz identity must follow operations and parameter expressions.  A
        # caller may safely rename the wrapper program without changing it.
        payload = {
            "schema": "cascaqit.digital.circuit.structure.v1",
            "qubits": self._qubits,
            "parameters": self._parameters,
            "gates": self._gates,
            "measurements": self._measurements,
        }
        canonical = canonicalize(payload)
        if not isinstance(canonical, dict):
            raise TypeError("Circuit structural payload must be a dictionary.")
        return canonical

    def structural_hash(self) -> str:
        """Hash executable declarations independently of labels and metadata."""
        return hashlib.sha256(
            stable_json(self.structural_payload()).encode("utf-8")
        ).hexdigest()

    def parameter_occurrences(self) -> tuple[GateParameterOccurrence, ...]:
        """Return every declared gate parameter in stable operation order."""
        source_hash = self.structural_hash()
        parameter_order = tuple(parameter.name for parameter in self._parameters)
        occurrences: list[GateParameterOccurrence] = []
        for gate_index, gate in enumerate(self._gates):
            for parameter_name in _GATE_SIGNATURES[gate.name][1]:
                value = gate.parameters[parameter_name]
                form: AffineForm | None = None
                unsupported_reason: str | None = None
                try:
                    form = affine_form(value, parameter_order=parameter_order)
                except _AffineFormError as exc:
                    unsupported_reason = exc.code
                except (ArithmeticError, TypeError, ValueError, OverflowError):
                    unsupported_reason = "PARAMETER_AFFINE_ANALYSIS_FAILED"

                symbolic = isinstance(value, (Parameter, Expression))
                if not symbolic or (form is not None and not form.coefficients):
                    unsupported_reason = "DIGITAL_GRADIENT_PARAMETER_NUMERIC"
                elif gate.name not in {"rx", "ry", "rz"} or parameter_name != "theta":
                    unsupported_reason = "DIGITAL_GRADIENT_GATE_UNSUPPORTED"

                occurrence_id = (
                    "occurrence."
                    + hashlib.sha256(
                        stable_json(
                            {
                                "schema": (
                                    "cascaqit.digital.gate_parameter_occurrence.v1"
                                ),
                                "source_circuit_hash": source_hash,
                                "gate_id": gate.gate_id,
                                "parameter_name": parameter_name,
                            }
                        ).encode("utf-8")
                    ).hexdigest()
                )
                occurrences.append(
                    GateParameterOccurrence(
                        occurrence_id=occurrence_id,
                        source_circuit_hash=source_hash,
                        gate_index=gate_index,
                        gate_id=gate.gate_id,
                        gate_name=gate.name,
                        targets=gate.targets,
                        parameter_name=parameter_name,
                        parameter_value=value,
                        affine_form=form,
                        supported=unsupported_reason is None,
                        unsupported_reason=unsupported_reason,
                    )
                )
        return tuple(occurrences)

    def shift_parameter_occurrence(
        self,
        occurrence_id: str,
        shift: float,
    ) -> Circuit:
        """Return a snapshot with one symbolic RX/RY/RZ angle shifted."""
        if isinstance(shift, bool):
            shift_value = math.nan
        else:
            try:
                shift_value = float(shift)
            except (TypeError, ValueError):
                shift_value = math.nan
        if not math.isfinite(shift_value):
            _raise_builder_error(
                "Digital gate parameter shift must be finite.",
                code="DIGITAL_CIRCUIT_PARAMETER_SHIFT_INVALID",
                object_path="circuit.parameter_shift.shift",
                suggestion="Pass one finite angle in radians.",
            )
        matches = tuple(
            occurrence
            for occurrence in self.parameter_occurrences()
            if occurrence.occurrence_id == occurrence_id
        )
        if len(matches) != 1:
            _raise_builder_error(
                "Digital gate parameter occurrence is unknown.",
                code="DIGITAL_CIRCUIT_PARAMETER_OCCURRENCE_UNKNOWN",
                object_path="circuit.parameter_occurrences",
                suggestion="Use an occurrence_id returned by this Circuit snapshot.",
                metadata={"occurrence_id": str(occurrence_id)},
            )
        occurrence = matches[0]
        if not isinstance(occurrence.parameter_value, (Parameter, Expression)):
            _raise_builder_error(
                "A numeric gate parameter occurrence cannot be shifted symbolically.",
                code="DIGITAL_CIRCUIT_PARAMETER_OCCURRENCE_NUMERIC",
                object_path=f"circuit.gates[{occurrence.gate_index}].parameters",
                suggestion="Use a Parameter or Expression when declaring the gate.",
                metadata={"occurrence_id": occurrence.occurrence_id},
            )
        if (
            occurrence.gate_name not in {"rx", "ry", "rz"}
            or occurrence.parameter_name != "theta"
        ):
            _raise_builder_error(
                "Only symbolic RX, RY, and RZ theta occurrences can be shifted.",
                code="DIGITAL_CIRCUIT_PARAMETER_SHIFT_GATE_UNSUPPORTED",
                object_path=f"circuit.gates[{occurrence.gate_index}].parameters",
                suggestion="Select a symbolic theta occurrence from RX, RY, or RZ.",
                metadata={"occurrence_id": occurrence.occurrence_id},
            )

        shifted = self.snapshot()
        gate = shifted._gates[occurrence.gate_index]
        assert isinstance(gate, _ParameterizedGate)
        parameters = dict(gate.parameters)
        parameters[occurrence.parameter_name] = occurrence.parameter_value + shift_value
        shifted._gates[occurrence.gate_index] = _copy_declared_gate(
            gate,
            gate_id=gate.gate_id,
            parameters=parameters,
        )
        shifted._bound_parameter_values = None
        shifted._metadata["parameter_shift"] = {
            "occurrence_id": occurrence.occurrence_id,
            "shift": shift_value,
            "source_circuit_hash": occurrence.source_circuit_hash,
        }
        return shifted

    @classmethod
    def from_structural_payload(
        cls,
        payload: Mapping[str, Any],
        *,
        program_id: str = "program.digital.restored",
    ) -> Circuit:
        """Restore the parameterized operations captured by structural_payload()."""
        canonical = canonicalize(payload)
        if not isinstance(canonical, dict):
            raise TypeError("Circuit structural payload must be a dictionary.")
        if canonical.get("schema") != "cascaqit.digital.circuit.structure.v1":
            raise ValueError("Unsupported Circuit structural payload schema.")
        raw_qubits = canonical.get("qubits")
        raw_parameters = canonical.get("parameters")
        raw_gates = canonical.get("gates")
        raw_measurements = canonical.get("measurements")
        if not all(
            isinstance(value, list)
            for value in (
                raw_qubits,
                raw_parameters,
                raw_gates,
                raw_measurements,
            )
        ):
            raise TypeError("Circuit structural payload arrays are invalid.")

        qubits = cast(list[Any], raw_qubits)
        parameters = cast(list[Any], raw_parameters)
        gates = cast(list[Any], raw_gates)
        measurements = cast(list[Any], raw_measurements)

        circuit = cls(tuple(qubits), program_id=program_id)
        circuit._parameters = [
            Parameter.from_dict(item) for item in parameters
        ]
        definitions = {item.name: item for item in circuit._parameters}
        restored_gates: list[GateIR | _ParameterizedGate] = []
        for item in gates:
            if not isinstance(item, dict):
                raise TypeError("Circuit structural gate must be a dictionary.")
            raw_values = item.get("parameters", {})
            if not isinstance(raw_values, dict):
                raise TypeError("Circuit structural gate parameters are invalid.")
            values = {
                str(name): _restore_structural_value(value, definitions)
                for name, value in raw_values.items()
            }
            if any(
                isinstance(value, (Parameter, Expression))
                for value in values.values()
            ):
                restored_gates.append(
                    _ParameterizedGate(
                        gate_id=str(item["gate_id"]),
                        name=cast(DigitalGateName, item["name"]),
                        targets=tuple(item["targets"]),
                        parameters=values,
                        controls=tuple(item.get("controls", ())),
                        schema_version=str(item.get("schema_version", SCHEMA_VERSION)),
                        metadata=dict(item.get("metadata", {})),
                    )
                )
            else:
                restored_gates.append(GateIR.from_dict(item))
        circuit._gates = restored_gates
        circuit._measurements = [
            DigitalMeasurementIR.from_dict(item) for item in measurements
        ]
        if stable_json(circuit.structural_payload()) != stable_json(canonical):
            raise ValueError("Circuit structural payload cannot be reconstructed.")
        return circuit

    def parameter(
        self,
        name: str,
        *,
        default: float | None = None,
        lower_bound: float | None = None,
        upper_bound: float | None = None,
    ) -> Parameter:
        """Declare one float/radian parameter owned by this circuit."""
        if any(parameter.name == name for parameter in self._parameters):
            _raise_builder_error(
                f"Digital parameter '{name}' is already declared.",
                code="DIGITAL_CIRCUIT_PARAMETER_DUPLICATE",
                object_path=f"circuit.parameters.{name}",
                suggestion="Use the existing parameter or choose a unique name.",
                metadata={"parameter_name": name},
            )
        try:
            parameter = Parameter(
                name=name,
                unit="rad",
                default=default,
                lower_bound=lower_bound,
                upper_bound=upper_bound,
            )
        except (TypeError, ValueError) as exc:
            _raise_builder_error(
                f"Digital parameter '{name}' is invalid: {exc}",
                code="DIGITAL_CIRCUIT_PARAMETER_DECLARATION_INVALID",
                object_path=f"circuit.parameters.{name}",
                suggestion=(
                    "Use a unique identifier and finite radian bounds/default."
                ),
                metadata={"parameter_name": str(name)},
            )
        self._parameters.append(parameter)
        return parameter

    def bind(self, values: Mapping[str, float]) -> Circuit:
        """Return an independent circuit with all declarations bound to floats."""
        if not isinstance(values, Mapping):
            _raise_builder_error(
                "Digital parameter bindings must be a mapping.",
                code="DIGITAL_CIRCUIT_BIND_VALUES_INVALID",
                object_path="circuit.parameters",
                suggestion="Pass a mapping such as {'theta': 0.5}.",
            )
        provided = {str(name): value for name, value in values.items()}
        definitions = {parameter.name: parameter for parameter in self._parameters}
        unknown = tuple(sorted(set(provided) - set(definitions)))
        if unknown:
            _raise_builder_error(
                "Unknown Digital parameter bindings: " + ", ".join(unknown),
                code="DIGITAL_CIRCUIT_BIND_UNKNOWN",
                object_path="circuit.parameters",
                suggestion="Remove unknown values or declare those parameters.",
                metadata={"unknown_parameters": list(unknown)},
            )
        referenced = self._referenced_parameter_names()
        missing = tuple(
            name
            for name in sorted(referenced)
            if name not in provided and definitions[name].default is None
        )
        if missing:
            _raise_builder_error(
                "Missing Digital parameter bindings: " + ", ".join(missing),
                code="DIGITAL_CIRCUIT_BIND_MISSING",
                object_path="circuit.parameters",
                suggestion="Bind every referenced parameter without a default.",
                metadata={"missing_parameters": list(missing)},
            )
        resolved: dict[str, float] = {}
        for name in sorted(set(provided) | referenced):
            definition = definitions[name]
            try:
                resolved[name] = definition.evaluate(provided)
            except (TypeError, ValueError) as exc:
                _raise_builder_error(
                    f"Digital parameter '{name}' is invalid: {exc}",
                    code="DIGITAL_CIRCUIT_BIND_VALUE_INVALID",
                    object_path=f"circuit.parameters.{name}",
                    suggestion="Pass a finite value within the declared bounds.",
                    metadata={"parameter_name": name},
                )
        bound = Circuit(
            self._qubits,
            program_id=self._program_id,
            metadata=self._metadata,
        )
        bound._parameters = list(self._parameters)
        bound._measurements = list(self._measurements)
        bound._gates = [
            self._bind_gate(gate, resolved)
            for gate in self._gates
        ]
        bound._bound_parameter_values = dict(resolved)
        bound._control_depth = self._control_depth
        return bound

    def append(
        self,
        name: str,
        qubits: QubitRef | Sequence[QubitRef],
        *,
        parameters: Mapping[str, DigitalValue] | None = None,
    ) -> Circuit:
        """Append one supported gate through a uniform user-facing entrypoint."""
        if name not in _GATE_SIGNATURES:
            _raise_builder_error(
                f"Unknown Digital gate '{name}'.",
                code="DIGITAL_CIRCUIT_APPEND_GATE_UNKNOWN",
                object_path="circuit.gates",
                suggestion="Use one of: " + ", ".join(sorted(_GATE_SIGNATURES)),
                metadata={"gate_name": str(name)},
            )
        self._ensure_gate_can_be_added(name)
        arity, expected_parameter_names = _GATE_SIGNATURES[name]
        targets = self._normalize_append_targets(qubits, name, arity)
        if parameters is None:
            provided_parameters: dict[str, DigitalValue] = {}
        elif isinstance(parameters, Mapping):
            provided_parameters = {
                str(key): value for key, value in parameters.items()
            }
        else:
            _raise_builder_error(
                f"Gate '{name}' parameters must be a mapping.",
                code="DIGITAL_CIRCUIT_APPEND_PARAMETERS_INVALID",
                object_path=f"circuit.gates.{name}.parameters",
                suggestion="Pass a mapping from parameter name to value.",
                metadata={"gate_name": name},
            )
        actual_names = set(provided_parameters)
        expected_names = set(expected_parameter_names)
        if actual_names != expected_names:
            _raise_builder_error(
                f"Gate '{name}' parameters do not match its signature.",
                code="DIGITAL_CIRCUIT_APPEND_PARAMETER_SHAPE_INVALID",
                object_path=f"circuit.gates.{name}.parameters",
                suggestion=(
                    "Pass exactly these parameters: "
                    + (", ".join(expected_parameter_names) or "none")
                    + "."
                ),
                metadata={
                    "gate_name": name,
                    "expected_parameters": list(expected_parameter_names),
                    "actual_parameters": sorted(actual_names),
                },
            )
        normalized_parameters = {
            parameter_name: self._normalize_gate_parameter(
                provided_parameters[parameter_name],
                name,
                parameter_name,
            )
            for parameter_name in expected_parameter_names
        }
        self._append_parameter_aware_gate(
            cast(DigitalGateName, name),
            targets,
            normalized_parameters,
        )
        return self

    def compose(
        self,
        other: Circuit,
        *,
        qubit_map: Mapping[QubitRef, QubitRef] | None = None,
    ) -> Circuit:
        """Append another circuit as a validated, qubit-mapped subcircuit."""
        if not isinstance(other, Circuit):
            _raise_builder_error(
                "Digital compose requires another Circuit.",
                code="DIGITAL_CIRCUIT_COMPOSE_TYPE_INVALID",
                object_path="circuit.compose",
                suggestion="Pass a Circuit instance as the subcircuit.",
            )
        if self._measurements and (other._gates or other._measurements):
            _raise_builder_error(
                "Cannot compose operations after terminal measurement.",
                code="DIGITAL_CIRCUIT_COMPOSE_AFTER_MEASUREMENT",
                object_path="circuit.measurements",
                suggestion="Compose all subcircuits before terminal measurement.",
            )
        mapping = self._normalize_compose_mapping(other, qubit_map)
        merged_parameters = list(self._parameters)
        definitions = {parameter.name: parameter for parameter in merged_parameters}
        for parameter in other._parameters:
            existing = definitions.get(parameter.name)
            if existing is not None and existing != parameter:
                _raise_builder_error(
                    f"Digital parameter '{parameter.name}' conflicts during compose.",
                    code="DIGITAL_CIRCUIT_COMPOSE_PARAMETER_CONFLICT",
                    object_path=f"circuit.parameters.{parameter.name}",
                    suggestion=(
                        "Use identical default/bounds or rename one parameter."
                    ),
                    metadata={"parameter_name": parameter.name},
                )
            if existing is None:
                merged_parameters.append(parameter)
                definitions[parameter.name] = parameter
        existing_keys = {measurement.key for measurement in self._measurements}
        conflicting_keys = tuple(
            sorted(
                existing_keys
                & {measurement.key for measurement in other._measurements}
            )
        )
        if conflicting_keys:
            _raise_builder_error(
                "Digital measurement keys conflict during compose: "
                + ", ".join(conflicting_keys),
                code="DIGITAL_CIRCUIT_COMPOSE_MEASUREMENT_KEY_CONFLICT",
                object_path="circuit.measurements",
                suggestion="Rename measurement keys before composing circuits.",
                metadata={"measurement_keys": list(conflicting_keys)},
            )
        gate_offset = len(self._gates)
        mapped_gates: list[GateIR | _ParameterizedGate] = []
        for index, gate in enumerate(other._gates):
            gate_id = f"gate.{gate_offset + index}.{gate.name}"
            if isinstance(gate, GateIR):
                mapped_gates.append(
                    GateIR(
                        gate_id=gate_id,
                        name=gate.name,
                        targets=tuple(mapping[target] for target in gate.targets),
                        parameters=dict(gate.parameters),
                        controls=tuple(mapping[item] for item in gate.controls),
                        schema_version=gate.schema_version,
                        metadata=dict(gate.metadata),
                    )
                )
            else:
                mapped_gates.append(
                    _ParameterizedGate(
                        gate_id=gate_id,
                        name=gate.name,
                        targets=tuple(mapping[target] for target in gate.targets),
                        parameters=dict(gate.parameters),
                        controls=tuple(mapping[item] for item in gate.controls),
                        schema_version=gate.schema_version,
                        metadata=dict(gate.metadata),
                    )
                )
        measurement_offset = len(self._measurements)
        mapped_measurements = [
            DigitalMeasurementIR(
                measurement_id=f"measurement.{measurement_offset + index}",
                targets=tuple(mapping[target] for target in measurement.targets),
                key=measurement.key,
                basis=measurement.basis,
                schema_version=measurement.schema_version,
                metadata=dict(measurement.metadata),
            )
            for index, measurement in enumerate(other._measurements)
        ]
        self._parameters = merged_parameters
        self._gates.extend(mapped_gates)
        self._measurements.extend(mapped_measurements)
        self._bound_parameter_values = None
        self._control_depth = max(self._control_depth, other._control_depth)
        return self

    def inverse(self) -> Circuit:
        """Return an independent circuit that reverses this unitary circuit."""
        if self._measurements:
            _raise_builder_error(
                "Cannot invert a circuit with terminal measurement.",
                code="DIGITAL_CIRCUIT_INVERSE_MEASUREMENT_UNSUPPORTED",
                object_path="circuit.measurements",
                suggestion="Invert the unitary circuit before adding measurement.",
            )
        inverse = self._new_transformed_circuit()
        for index, gate in enumerate(reversed(self._gates)):
            gate_name, parameters = _inverse_gate(gate.name, gate.parameters)
            inverse._gates.append(
                _copy_declared_gate(
                    gate,
                    gate_id=f"gate.{index}.{gate_name}",
                    name=gate_name,
                    parameters=parameters,
                    metadata={
                        **gate.metadata,
                        "source_gate_id": gate.gate_id,
                        "transformation": "inverse",
                    },
                )
            )
        return inverse

    def repeat(self, count: int) -> Circuit:
        """Return an independent circuit repeated a bounded number of times."""
        if (
            isinstance(count, bool)
            or not isinstance(count, int)
            or count < 1
            or count > _MAX_REPEAT_COUNT
        ):
            _raise_builder_error(
                f"Digital circuit repeat count must be from 1 to {_MAX_REPEAT_COUNT}.",
                code="DIGITAL_CIRCUIT_REPEAT_COUNT_INVALID",
                object_path="circuit.repeat.count",
                suggestion=f"Pass an integer from 1 to {_MAX_REPEAT_COUNT}.",
                metadata={"repeat_count": count},
            )
        if self._measurements and count > 1:
            _raise_builder_error(
                "Cannot repeat a circuit with terminal measurement more than once.",
                code="DIGITAL_CIRCUIT_REPEAT_MEASUREMENT_UNSUPPORTED",
                object_path="circuit.measurements",
                suggestion="Repeat the unitary circuit before adding measurement.",
                metadata={"repeat_count": count},
            )
        repeated = self._new_transformed_circuit()
        for repetition_index in range(count):
            for gate in self._gates:
                gate_id = f"gate.{len(repeated._gates)}.{gate.name}"
                repeated._gates.append(
                    _copy_declared_gate(
                        gate,
                        gate_id=gate_id,
                        metadata={
                            **gate.metadata,
                            "source_gate_id": gate.gate_id,
                            "transformation": "repeat",
                            "repetition_index": repetition_index,
                        },
                    )
                )
        if count == 1:
            repeated._measurements = [
                DigitalMeasurementIR(
                    measurement_id=f"measurement.{index}",
                    targets=measurement.targets,
                    key=measurement.key,
                    basis=measurement.basis,
                    schema_version=measurement.schema_version,
                    metadata={
                        **measurement.metadata,
                        "source_measurement_id": measurement.measurement_id,
                        "transformation": "repeat",
                        "repetition_index": 0,
                    },
                )
                for index, measurement in enumerate(self._measurements)
            ]
        return repeated

    def controlled(self, new_control: str) -> Circuit:
        """Return a capability-bounded controlled form of this circuit."""
        if not isinstance(new_control, str) or not new_control:
            _raise_builder_error(
                "Digital controlled qubit name must be a non-empty string.",
                code="DIGITAL_CIRCUIT_CONTROLLED_QUBIT_INVALID",
                object_path="circuit.controlled.new_control",
                suggestion="Pass a non-empty logical qubit name.",
                metadata={"new_control": str(new_control)},
            )
        if new_control in self._qubits:
            _raise_builder_error(
                f"Digital control qubit '{new_control}' already exists.",
                code="DIGITAL_CIRCUIT_CONTROLLED_QUBIT_CONFLICT",
                object_path="circuit.controlled.new_control",
                suggestion="Choose a new logical qubit name.",
                metadata={"new_control": new_control},
            )
        if self._measurements:
            _raise_builder_error(
                "Cannot control a circuit with terminal measurement.",
                code="DIGITAL_CIRCUIT_CONTROLLED_MEASUREMENT_UNSUPPORTED",
                object_path="circuit.measurements",
                suggestion="Create the controlled circuit before adding measurement.",
            )
        if self._control_depth:
            _raise_builder_error(
                "Nested circuit-level controlled transformation is unsupported.",
                code="DIGITAL_CIRCUIT_CONTROLLED_NESTED_UNSUPPORTED",
                object_path="circuit.controlled",
                suggestion="Apply controlled() only to an original source circuit.",
                metadata={"control_depth": self._control_depth},
            )
        unsupported = tuple(
            sorted(
                {
                    gate.name
                    for gate in self._gates
                    if gate.name not in _CONTROLLED_GATE_NAMES
                }
            )
        )
        if unsupported:
            _raise_builder_error(
                "Digital circuit contains gates without controlled capability: "
                + ", ".join(unsupported),
                code="DIGITAL_CIRCUIT_CONTROLLED_GATE_UNSUPPORTED",
                object_path="circuit.gates",
                suggestion="Use only i, x, y, z, and cx before controlled().",
                metadata={"unsupported_gate_names": list(unsupported)},
            )
        controlled = Circuit(
            (new_control, *self._qubits),
            program_id=self._program_id,
            metadata=self._metadata,
        )
        controlled._parameters = list(self._parameters)
        controlled._bound_parameter_values = (
            None
            if self._bound_parameter_values is None
            else dict(self._bound_parameter_values)
        )
        controlled._control_depth = 1
        for index, gate in enumerate(self._gates):
            gate_name = _CONTROLLED_GATE_NAMES[gate.name]
            targets = (
                gate.targets
                if gate.name == "i"
                else (new_control, *gate.targets)
            )
            controlled._gates.append(
                GateIR(
                    gate_id=f"gate.{index}.{gate_name}",
                    name=gate_name,
                    targets=targets,
                    parameters={},
                    schema_version=gate.schema_version,
                    metadata={
                        **gate.metadata,
                        "source_gate_id": gate.gate_id,
                        "transformation": "controlled",
                        "control_qubit": new_control,
                    },
                )
            )
        return controlled

    def i(self, qubit: QubitRef) -> Circuit:
        """Append an identity gate."""
        return self._append_one_qubit("i", qubit)

    def x(self, qubit: QubitRef) -> Circuit:
        """Append a Pauli-X gate."""
        return self._append_one_qubit("x", qubit)

    def y(self, qubit: QubitRef) -> Circuit:
        """Append a Pauli-Y gate."""
        return self._append_one_qubit("y", qubit)

    def z(self, qubit: QubitRef) -> Circuit:
        """Append a Pauli-Z gate."""
        return self._append_one_qubit("z", qubit)

    def h(self, qubit: QubitRef) -> Circuit:
        """Append a Hadamard gate."""
        return self._append_one_qubit("h", qubit)

    def s(self, qubit: QubitRef) -> Circuit:
        """Append an S phase gate."""
        return self._append_one_qubit("s", qubit)

    def sdg(self, qubit: QubitRef) -> Circuit:
        """Append an S-dagger gate."""
        return self._append_one_qubit("sdg", qubit)

    def t(self, qubit: QubitRef) -> Circuit:
        """Append a T phase gate."""
        return self._append_one_qubit("t", qubit)

    def tdg(self, qubit: QubitRef) -> Circuit:
        """Append a T-dagger gate."""
        return self._append_one_qubit("tdg", qubit)

    def rx(self, theta: DigitalValue, qubit: QubitRef) -> Circuit:
        """Append RX(theta), using the familiar angle-then-qubit order."""
        return self._append_rotation("rx", theta, qubit)

    def ry(self, theta: DigitalValue, qubit: QubitRef) -> Circuit:
        """Append RY(theta), using the familiar angle-then-qubit order."""
        return self._append_rotation("ry", theta, qubit)

    def rz(self, theta: DigitalValue, qubit: QubitRef) -> Circuit:
        """Append RZ(theta), using the familiar angle-then-qubit order."""
        return self._append_rotation("rz", theta, qubit)

    def p(self, theta: DigitalValue, qubit: QubitRef) -> Circuit:
        """Append a single-qubit phase gate."""
        return self._append_rotation("p", theta, qubit)

    def u(
        self,
        theta: DigitalValue,
        phi: DigitalValue,
        lam: DigitalValue,
        qubit: QubitRef,
    ) -> Circuit:
        """Append U(theta, phi, lambda)."""
        self._ensure_gate_can_be_added("u")
        target = self._resolve_qubit(qubit)
        parameters = {
            "theta": self._normalize_gate_parameter(theta, "u", "theta"),
            "phi": self._normalize_gate_parameter(phi, "u", "phi"),
            "lambda": self._normalize_gate_parameter(lam, "u", "lambda"),
        }
        self._append_parameter_aware_gate("u", (target,), parameters)
        return self

    def cx(self, control: QubitRef, target: QubitRef) -> Circuit:
        """Append a controlled-X gate."""
        return self._append_two_qubit("cx", control, target)

    def cy(self, control: QubitRef, target: QubitRef) -> Circuit:
        """Append a controlled-Y gate."""
        return self._append_two_qubit("cy", control, target)

    def cz(self, control: QubitRef, target: QubitRef) -> Circuit:
        """Append a controlled-Z gate."""
        return self._append_two_qubit("cz", control, target)

    def swap(self, left: QubitRef, right: QubitRef) -> Circuit:
        """Append a SWAP gate."""
        return self._append_two_qubit("swap", left, right)

    def ccx(
        self,
        control0: QubitRef,
        control1: QubitRef,
        target: QubitRef,
    ) -> Circuit:
        """Append a controlled-controlled-X gate."""
        self._ensure_gate_can_be_added("ccx")
        targets = self._resolve_distinct_qubits(
            (control0, control1, target),
            gate_name="ccx",
        )
        self._gates.append(
            GateIR.ccx(*targets, gate_id=self._next_gate_id("ccx"))
        )
        return self

    def measure(
        self,
        qubits: QubitRef | Sequence[QubitRef],
        *,
        key: str | None = None,
    ) -> Circuit:
        """Append a terminal computational-basis measurement."""
        targets = self._normalize_measurement_targets(qubits)
        measurement_index = len(self._measurements)
        measurement_key = f"m{measurement_index}" if key is None else str(key)
        if not measurement_key:
            _raise_builder_error(
                "Digital measurement key must not be empty.",
                code="DIGITAL_CIRCUIT_MEASUREMENT_KEY_EMPTY",
                object_path="circuit.measurements",
                suggestion="Pass a non-empty key such as 'm' or omit key.",
            )
        if measurement_key in {
            measurement.key for measurement in self._measurements
        }:
            _raise_builder_error(
                f"Digital measurement key '{measurement_key}' is already used.",
                code="DIGITAL_CIRCUIT_MEASUREMENT_KEY_DUPLICATE",
                object_path="circuit.measurements",
                suggestion="Use a unique key for each measurement register.",
                metadata={"measurement_key": measurement_key},
            )
        self._measurements.append(
            DigitalMeasurementIR.measure(
                targets,
                key=measurement_key,
                measurement_id=f"measurement.{measurement_index}",
            )
        )
        return self

    def measure_all(self, *, key: str = "m") -> Circuit:
        """Measure every logical qubit in stable circuit order."""
        return self.measure(self._qubits, key=key)

    def to_program(self) -> DigitalProgramIR:
        """Return the native DigitalProgramIR represented by this builder."""
        self._require_bound()
        return build_digital_program(
            program_id=self._program_id,
            qubits=self._qubits,
            gates=self.gates,
            measurements=self._measurements,
            metadata=self._metadata,
        )

    def to_ir(self) -> DigitalProgramIR:
        """Alias to_program() for consistency with other user builders."""
        return self.to_program()

    def validate(self) -> tuple[DiagnosticsIR, ...]:
        """Validate the current circuit using native digital IR diagnostics."""
        if not self.is_bound:
            names = sorted(self._referenced_parameter_names())
            return (
                DiagnosticsIR(
                    diagnostic_id="digital.circuit.parameters.unbound",
                    stage="validation",
                    severity="error",
                    code="DIGITAL_CIRCUIT_PARAMETERS_UNBOUND",
                    message=(
                        "Digital circuit parameters must be bound before lowering "
                        "or execution."
                    ),
                    object_path="circuit.parameters",
                    suggestion="Call circuit.bind({...}) with every required value.",
                    metadata={"parameter_names": names},
                ),
            )
        return self.to_program().validate_ir_only()

    def run(
        self,
        *,
        shots: int = 1000,
        seed: int | None = None,
        return_probabilities: bool = False,
    ) -> ResultIR:
        """Run this circuit on the offline local state-vector simulator."""
        from cascaqit.native_ir.models import SimulatorConfigIR
        from cascaqit.simulators.digital import LocalDigitalSimulator

        return LocalDigitalSimulator(seed=seed).run(
            self.to_program(),
            config=SimulatorConfigIR(
                shots=shots,
                seed=seed,
                return_probabilities=return_probabilities,
            ),
        )

    def _append_one_qubit(self, gate_name: str, qubit: QubitRef) -> Circuit:
        self._ensure_gate_can_be_added(gate_name)
        target = self._resolve_qubit(qubit)
        helper = getattr(GateIR, gate_name)
        self._gates.append(
            helper(target, gate_id=self._next_gate_id(gate_name))
        )
        return self

    def _append_rotation(
        self,
        gate_name: str,
        theta: DigitalValue,
        qubit: QubitRef,
    ) -> Circuit:
        self._ensure_gate_can_be_added(gate_name)
        target = self._resolve_qubit(qubit)
        parameter = self._normalize_gate_parameter(theta, gate_name, "theta")
        self._append_parameter_aware_gate(
            cast(DigitalGateName, gate_name),
            (target,),
            {"theta": parameter},
        )
        return self

    def _normalize_gate_parameter(
        self,
        value: DigitalValue,
        gate_name: str,
        parameter_name: str,
    ) -> DigitalValue:
        if isinstance(value, Parameter):
            declared = {
                parameter.name: parameter for parameter in self._parameters
            }.get(value.name)
            if declared != value:
                self._raise_unknown_parameter_reference(value.name, gate_name)
            return value
        if isinstance(value, Expression):
            unknown = tuple(
                sorted(
                    set(value.dependencies)
                    - {parameter.name for parameter in self._parameters}
                )
            )
            if unknown:
                self._raise_unknown_parameter_reference(unknown[0], gate_name)
            return value
        return _finite_parameter(
            value,
            gate_name=gate_name,
            parameter_name=parameter_name,
        )

    def _append_parameter_aware_gate(
        self,
        gate_name: DigitalGateName,
        targets: tuple[str, ...],
        parameters: dict[str, DigitalValue],
    ) -> None:
        gate_id = self._next_gate_id(gate_name)
        if any(
            isinstance(value, (Parameter, Expression))
            for value in parameters.values()
        ):
            self._gates.append(
                _ParameterizedGate(
                    gate_id=gate_id,
                    name=gate_name,
                    targets=targets,
                    parameters=dict(parameters),
                )
            )
            return
        self._gates.append(
            GateIR(
                gate_id=gate_id,
                name=gate_name,
                targets=targets,
                parameters={
                    name: float(cast(Union[int, float], value))
                    for name, value in parameters.items()
                },
            )
        )

    def _referenced_parameter_names(self) -> set[str]:
        names: set[str] = set()
        for gate in self._gates:
            if not isinstance(gate, _ParameterizedGate):
                continue
            for value in gate.parameters.values():
                if isinstance(value, Parameter):
                    names.add(value.name)
                elif isinstance(value, Expression):
                    names.update(value.dependencies)
        return names

    def _bind_gate(
        self,
        gate: GateIR | _ParameterizedGate,
        values: Mapping[str, float],
    ) -> GateIR:
        if isinstance(gate, GateIR):
            return gate
        try:
            parameters = {
                name: _resolve_gate_parameter(value, values)
                for name, value in gate.parameters.items()
            }
        except (ArithmeticError, TypeError, ValueError, OverflowError) as exc:
            _raise_builder_error(
                f"Digital gate '{gate.name}' parameter evaluation failed: {exc}",
                code="DIGITAL_CIRCUIT_BIND_EVALUATION_FAILED",
                object_path=f"circuit.gates.{gate.name}.parameters",
                suggestion="Fix the expression or bind values and try again.",
                metadata={"gate_name": gate.name},
            )
        return GateIR(
            gate_id=gate.gate_id,
            name=gate.name,
            targets=gate.targets,
            parameters=parameters,
            controls=gate.controls,
            schema_version=gate.schema_version,
            metadata=dict(gate.metadata),
        )

    def _raise_unknown_parameter_reference(
        self,
        parameter_name: str,
        gate_name: str,
    ) -> None:
        _raise_builder_error(
            f"Digital gate '{gate_name}' references undeclared parameter "
            f"'{parameter_name}'.",
            code="DIGITAL_CIRCUIT_PARAMETER_UNKNOWN",
            object_path=f"circuit.gates.{gate_name}.parameters",
            suggestion="Declare the parameter with circuit.parameter() first.",
            metadata={
                "gate_name": gate_name,
                "parameter_name": parameter_name,
            },
        )

    def _normalize_append_targets(
        self,
        qubits: QubitRef | Sequence[QubitRef],
        gate_name: str,
        arity: int,
    ) -> tuple[str, ...]:
        if isinstance(qubits, (int, str)):
            items: tuple[QubitRef, ...] = (qubits,)
        else:
            items = tuple(qubits)
        if len(items) != arity:
            _raise_builder_error(
                f"Gate '{gate_name}' requires {arity} qubit operand(s).",
                code="DIGITAL_CIRCUIT_APPEND_ARITY_INVALID",
                object_path=f"circuit.gates.{gate_name}.targets",
                suggestion=f"Pass exactly {arity} qubit operand(s).",
                metadata={
                    "gate_name": gate_name,
                    "expected_arity": arity,
                    "actual_arity": len(items),
                },
            )
        if arity == 1:
            return (self._resolve_qubit(items[0]),)
        return self._resolve_distinct_qubits(items, gate_name=gate_name)

    def _normalize_compose_mapping(
        self,
        other: Circuit,
        qubit_map: Mapping[QubitRef, QubitRef] | None,
    ) -> dict[str, str]:
        if qubit_map is None:
            missing = tuple(
                qubit for qubit in other._qubits if qubit not in self._qubits
            )
            if missing:
                _raise_builder_error(
                    "Digital compose requires an explicit complete qubit mapping.",
                    code="DIGITAL_CIRCUIT_COMPOSE_MAPPING_INCOMPLETE",
                    object_path="circuit.compose.qubit_map",
                    suggestion="Map every source qubit to one receiver qubit.",
                    metadata={"missing_source_qubits": list(missing)},
                )
            return {qubit: qubit for qubit in other._qubits}
        if not isinstance(qubit_map, Mapping):
            _raise_builder_error(
                "Digital compose qubit_map must be a mapping.",
                code="DIGITAL_CIRCUIT_COMPOSE_MAPPING_INVALID",
                object_path="circuit.compose.qubit_map",
                suggestion="Pass a complete source-to-receiver qubit mapping.",
            )
        normalized: dict[str, str] = {}
        for source, target in qubit_map.items():
            source_name = other._resolve_qubit(source)
            if source_name in normalized:
                _raise_builder_error(
                    f"Source qubit '{source_name}' is mapped more than once.",
                    code="DIGITAL_CIRCUIT_COMPOSE_MAPPING_DUPLICATE",
                    object_path="circuit.compose.qubit_map",
                    suggestion="Map every source qubit exactly once.",
                )
            normalized[source_name] = self._resolve_qubit(target)
        missing = tuple(
            qubit for qubit in other._qubits if qubit not in normalized
        )
        if missing or len(normalized) != len(other._qubits):
            _raise_builder_error(
                "Digital compose qubit_map must cover every source qubit.",
                code="DIGITAL_CIRCUIT_COMPOSE_MAPPING_INCOMPLETE",
                object_path="circuit.compose.qubit_map",
                suggestion="Map every source qubit exactly once.",
                metadata={"missing_source_qubits": list(missing)},
            )
        if len(set(normalized.values())) != len(normalized):
            _raise_builder_error(
                "Digital compose targets must be unique.",
                code="DIGITAL_CIRCUIT_COMPOSE_TARGET_DUPLICATE",
                object_path="circuit.compose.qubit_map",
                suggestion="Map source qubits to distinct receiver qubits.",
                metadata={"target_qubits": list(normalized.values())},
            )
        return normalized

    def _require_bound(self) -> None:
        if self.is_bound:
            return
        names = sorted(self._referenced_parameter_names())
        _raise_builder_error(
            "Digital circuit parameters must be bound before lowering or execution.",
            code="DIGITAL_CIRCUIT_PARAMETERS_UNBOUND",
            object_path="circuit.parameters",
            suggestion="Call circuit.bind({...}) with every required value.",
            metadata={"parameter_names": names},
        )

    def _append_two_qubit(
        self,
        gate_name: str,
        first: QubitRef,
        second: QubitRef,
    ) -> Circuit:
        self._ensure_gate_can_be_added(gate_name)
        targets = self._resolve_distinct_qubits(
            (first, second),
            gate_name=gate_name,
        )
        helper = getattr(GateIR, gate_name)
        self._gates.append(
            helper(*targets, gate_id=self._next_gate_id(gate_name))
        )
        return self

    def _resolve_qubit(self, qubit: QubitRef) -> str:
        if isinstance(qubit, bool):
            _raise_unknown_qubit(qubit, self._qubits)
        if isinstance(qubit, int):
            if qubit < 0 or qubit >= len(self._qubits):
                _raise_builder_error(
                    f"Qubit index {qubit} is outside the circuit range.",
                    code="DIGITAL_CIRCUIT_QUBIT_INDEX_OUT_OF_RANGE",
                    object_path=f"circuit.qubits[{qubit}]",
                    suggestion=(
                        f"Use an index from 0 to {len(self._qubits) - 1} "
                        "or pass a known qubit name."
                    ),
                    metadata={
                        "qubit_index": qubit,
                        "qubit_count": len(self._qubits),
                    },
                )
            return self._qubits[qubit]
        name = str(qubit)
        if name not in self._qubits:
            _raise_unknown_qubit(name, self._qubits)
        return name

    def _resolve_distinct_qubits(
        self,
        qubits: Sequence[QubitRef],
        *,
        gate_name: str,
    ) -> tuple[str, ...]:
        targets = tuple(self._resolve_qubit(qubit) for qubit in qubits)
        if len(set(targets)) != len(targets):
            _raise_builder_error(
                f"Gate '{gate_name}' requires distinct qubits.",
                code="DIGITAL_CIRCUIT_GATE_TARGET_DUPLICATE",
                object_path=f"circuit.gates.{gate_name}.targets",
                suggestion="Pass a different logical qubit for each gate operand.",
                metadata={"gate_name": gate_name, "targets": list(targets)},
            )
        return targets

    def _normalize_measurement_targets(
        self,
        qubits: QubitRef | Sequence[QubitRef],
    ) -> tuple[str, ...]:
        if isinstance(qubits, (int, str)):
            items: tuple[QubitRef, ...] = (qubits,)
        else:
            items = tuple(qubits)
        if not items:
            _raise_builder_error(
                "Digital measurement requires at least one qubit.",
                code="DIGITAL_CIRCUIT_MEASUREMENT_TARGET_EMPTY",
                object_path="circuit.measurements",
                suggestion="Pass one qubit or call measure_all().",
            )
        targets = tuple(self._resolve_qubit(qubit) for qubit in items)
        if len(set(targets)) != len(targets):
            _raise_builder_error(
                "Digital measurement targets must be unique.",
                code="DIGITAL_CIRCUIT_MEASUREMENT_TARGET_DUPLICATE",
                object_path="circuit.measurements",
                suggestion="List each measured qubit once.",
                metadata={"targets": list(targets)},
            )
        return targets

    def _ensure_gate_can_be_added(self, gate_name: str) -> None:
        if self._measurements:
            _raise_builder_error(
                f"Cannot append gate '{gate_name}' after terminal measurement.",
                code="DIGITAL_CIRCUIT_GATE_AFTER_MEASUREMENT",
                object_path="circuit.gates",
                suggestion=(
                    "Add all gates before measure() or measure_all(); "
                    "mid-circuit measurement is not supported."
                ),
                metadata={"gate_name": gate_name},
            )

    def _next_gate_id(self, gate_name: str) -> str:
        return f"gate.{len(self._gates)}.{gate_name}"

    def _new_transformed_circuit(self) -> Circuit:
        transformed = Circuit(
            self._qubits,
            program_id=self._program_id,
            metadata=self._metadata,
        )
        transformed._parameters = list(self._parameters)
        transformed._bound_parameter_values = (
            None
            if self._bound_parameter_values is None
            else dict(self._bound_parameter_values)
        )
        transformed._control_depth = self._control_depth
        return transformed


def _inverse_gate(
    gate_name: DigitalGateName,
    parameters: Mapping[str, DigitalValue],
) -> tuple[DigitalGateName, dict[str, DigitalValue]]:
    if gate_name in _SELF_INVERSE_GATES:
        return gate_name, dict(parameters)
    paired_name = _PAIRED_INVERSE_GATES.get(gate_name)
    if paired_name is not None:
        return paired_name, dict(parameters)
    if gate_name in _ANGLE_INVERSE_GATES:
        return gate_name, {"theta": _negate_parameter(parameters["theta"])}
    if gate_name == "u":
        return (
            "u",
            {
                "theta": _negate_parameter(parameters["theta"]),
                "phi": _negate_parameter(parameters["lambda"]),
                "lambda": _negate_parameter(parameters["phi"]),
            },
        )
    _raise_builder_error(
        f"Digital gate '{gate_name}' cannot be inverted.",
        code="DIGITAL_CIRCUIT_INVERSE_GATE_UNSUPPORTED",
        object_path=f"circuit.gates.{gate_name}",
        suggestion="Use only gates with a defined inverse transformation.",
        metadata={"gate_name": gate_name},
    )


def _negate_parameter(value: DigitalValue) -> DigitalValue:
    if isinstance(value, (Parameter, Expression)):
        return -value
    return -float(value)


def _copy_declared_gate(
    gate: GateIR | _ParameterizedGate,
    *,
    gate_id: str,
    name: DigitalGateName | None = None,
    parameters: Mapping[str, DigitalValue] | None = None,
    metadata: Mapping[str, Any] | None = None,
) -> GateIR | _ParameterizedGate:
    gate_name = gate.name if name is None else name
    gate_parameters = dict(gate.parameters if parameters is None else parameters)
    gate_metadata = dict(gate.metadata if metadata is None else metadata)
    if isinstance(gate, _ParameterizedGate):
        return _ParameterizedGate(
            gate_id=gate_id,
            name=gate_name,
            targets=gate.targets,
            parameters=gate_parameters,
            controls=gate.controls,
            schema_version=gate.schema_version,
            metadata=gate_metadata,
        )
    return GateIR(
        gate_id=gate_id,
        name=gate_name,
        targets=gate.targets,
        parameters={
            key: float(cast(Union[int, float], value))
            for key, value in gate_parameters.items()
        },
        controls=gate.controls,
        schema_version=gate.schema_version,
        metadata=gate_metadata,
    )


def _restore_structural_value(
    value: object,
    definitions: Mapping[str, Parameter],
) -> DigitalValue:
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return value
    if not isinstance(value, dict):
        raise TypeError("Circuit structural gate value is invalid.")
    if "node_type" in value:
        return Expression.from_dict(value)
    if "name" in value:
        parameter = Parameter.from_dict(value)
        declared = definitions.get(parameter.name)
        if declared != parameter:
            raise ValueError(
                f"Circuit structural parameter '{parameter.name}' is inconsistent."
            )
        return declared
    raise TypeError("Circuit structural gate value has an unknown shape.")


def _normalize_qubits(qubits: int | Sequence[str]) -> tuple[str, ...]:
    if isinstance(qubits, bool):
        qubits = 0
    if isinstance(qubits, int):
        if qubits <= 0:
            _raise_builder_error(
                "Digital circuit qubit count must be greater than zero.",
                code="DIGITAL_CIRCUIT_QUBIT_COUNT_INVALID",
                object_path="circuit.qubits",
                suggestion="Pass a positive qubit count such as Circuit(2).",
                metadata={"qubit_count": qubits},
            )
        return tuple(f"q{index}" for index in range(qubits))
    names: tuple[str, ...]
    if isinstance(qubits, str):
        names = (qubits,)
    else:
        names = tuple(str(qubit) for qubit in qubits)
    if not names or any(not name for name in names):
        _raise_builder_error(
            "Digital circuit qubit names must be non-empty.",
            code="DIGITAL_CIRCUIT_QUBIT_NAME_INVALID",
            object_path="circuit.qubits",
            suggestion="Pass one or more non-empty qubit names.",
        )
    if len(set(names)) != len(names):
        _raise_builder_error(
            "Digital circuit qubit names must be unique.",
            code="DIGITAL_CIRCUIT_QUBIT_DUPLICATE",
            object_path="circuit.qubits",
            suggestion="Rename duplicate logical qubits before adding gates.",
            metadata={"qubits": list(names)},
        )
    return names


def _finite_parameter(
    value: float,
    *,
    gate_name: str,
    parameter_name: str,
) -> float:
    if isinstance(value, bool):
        numeric_value = math.nan
    else:
        try:
            numeric_value = float(value)
        except (TypeError, ValueError):
            numeric_value = math.nan
    if not math.isfinite(numeric_value):
        _raise_builder_error(
            f"Gate '{gate_name}' parameter '{parameter_name}' must be finite.",
            code="DIGITAL_CIRCUIT_PARAMETER_INVALID",
            object_path=f"circuit.gates.{gate_name}.{parameter_name}",
            suggestion="Pass a finite numeric angle in radians.",
            metadata={
                "gate_name": gate_name,
                "parameter_name": parameter_name,
            },
        )
    return numeric_value


def _resolve_gate_parameter(
    value: DigitalValue,
    bindings: Mapping[str, float],
) -> float:
    if isinstance(value, Parameter):
        return value.evaluate(bindings)
    if isinstance(value, Expression):
        return value.evaluate(bindings)
    return _finite_parameter(
        value,
        gate_name="bound",
        parameter_name="value",
    )


def _raise_unknown_qubit(qubit: object, known_qubits: tuple[str, ...]) -> None:
    _raise_builder_error(
        f"Unknown digital circuit qubit: {qubit!r}.",
        code="DIGITAL_CIRCUIT_QUBIT_UNKNOWN",
        object_path="circuit.qubits",
        suggestion=f"Use one of the declared qubits: {', '.join(known_qubits)}.",
        metadata={"qubit": str(qubit), "known_qubits": list(known_qubits)},
    )


def _raise_builder_error(
    message: str,
    *,
    code: str,
    object_path: str,
    suggestion: str,
    metadata: dict[str, Any] | None = None,
) -> NoReturn:
    raise ProgramValidationError(
        message,
        code=code,
        object_path=object_path,
        suggestion=suggestion,
        metadata={
            "reason_category": "digital_builder",
            **({} if metadata is None else metadata),
        },
    )
