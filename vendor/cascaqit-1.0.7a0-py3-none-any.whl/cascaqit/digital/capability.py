"""Side-effect-free Digital gate and restricted OpenQASM capability matrix."""

from __future__ import annotations

import json
from collections.abc import Iterable
from dataclasses import dataclass, field
from typing import Any, Literal

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.native_ir.base import IRMixin, canonicalize
from cascaqit.native_ir.models import SCHEMA_VERSION

__all__ = [
    "DigitalGateCapabilityEntryIR",
    "DigitalGateCapabilityMatrixIR",
    "DigitalGateCapabilityStatus",
    "build_digital_gate_capability_matrix",
]

DigitalGateCapabilityStatus = Literal[
    "supported",
    "lowered",
    "blocked",
    "unsupported",
]

_GATE_ORDER: tuple[str, ...] = (
    "i",
    "x",
    "y",
    "z",
    "h",
    "s",
    "sdg",
    "t",
    "tdg",
    "rx",
    "ry",
    "rz",
    "p",
    "u",
    "cx",
    "cy",
    "cz",
    "swap",
    "ccx",
)
_V0_27_OPENQASM_GATES = frozenset(
    {
        "i",
        "x",
        "y",
        "z",
        "h",
        "s",
        "sdg",
        "t",
        "tdg",
        "rx",
        "ry",
        "rz",
        "p",
        "cx",
        "cz",
    }
)
_CURRENT_OPENQASM_IMPORT_EXPANSION_GATES = frozenset({"u", "cy"})
_CURRENT_OPENQASM_EXPORT_EXPANSION_GATES = frozenset({"u", "cy"})
_CURRENT_OPENQASM_EXPORT_LOWERED_GATES = frozenset({"swap"})
_V0_28_DIRECT_OPENQASM_TARGETS = frozenset({"u", "cy"})
_V0_28_LOWERED_OPENQASM_TARGETS = frozenset({"swap"})
_V0_28_BLOCKED_OPENQASM_TARGETS = frozenset({"ccx"})
_PARAMETERS: dict[str, tuple[str, ...]] = {
    "rx": ("theta",),
    "ry": ("theta",),
    "rz": ("theta",),
    "p": ("theta",),
    "u": ("theta", "phi", "lambda"),
}
_ARITY: dict[str, int] = {
    "i": 1,
    "x": 1,
    "y": 1,
    "z": 1,
    "h": 1,
    "s": 1,
    "sdg": 1,
    "t": 1,
    "tdg": 1,
    "rx": 1,
    "ry": 1,
    "rz": 1,
    "p": 1,
    "u": 1,
    "cx": 2,
    "cy": 2,
    "cz": 2,
    "swap": 2,
    "ccx": 3,
}


@dataclass(frozen=True)
class DigitalGateCapabilityEntryIR(IRMixin):
    """Capability row for one digital gate."""

    gate: str
    arity: int
    parameter_names: tuple[str, ...]
    ir_status: DigitalGateCapabilityStatus
    simulator_status: DigitalGateCapabilityStatus
    compile_package_status: DigitalGateCapabilityStatus
    current_openqasm_import_status: DigitalGateCapabilityStatus
    current_openqasm_export_status: DigitalGateCapabilityStatus
    v0_28_openqasm_import_target: DigitalGateCapabilityStatus
    v0_28_openqasm_export_target: DigitalGateCapabilityStatus
    lowering_strategy: str | None = None
    diagnostics: tuple[DiagnosticsIR, ...] = ()
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize nested payloads."""
        object.__setattr__(
            self,
            "parameter_names",
            tuple(str(name) for name in self.parameter_names),
        )
        object.__setattr__(
            self,
            "diagnostics",
            tuple(
                diagnostic
                if isinstance(diagnostic, DiagnosticsIR)
                else DiagnosticsIR.from_dict(diagnostic)
                for diagnostic in self.diagnostics
            ),
        )
        object.__setattr__(self, "metadata", canonicalize(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DigitalGateCapabilityEntryIR:
        """Build a matrix row from a JSON-compatible dictionary."""
        return cls(
            gate=str(data["gate"]),
            arity=int(data["arity"]),
            parameter_names=tuple(
                str(name) for name in data.get("parameter_names", ())
            ),
            ir_status=data["ir_status"],
            simulator_status=data["simulator_status"],
            compile_package_status=data["compile_package_status"],
            current_openqasm_import_status=data["current_openqasm_import_status"],
            current_openqasm_export_status=data["current_openqasm_export_status"],
            v0_28_openqasm_import_target=data["v0_28_openqasm_import_target"],
            v0_28_openqasm_export_target=data["v0_28_openqasm_export_target"],
            lowering_strategy=data.get("lowering_strategy"),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(item)
                for item in data.get("diagnostics", ())
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> DigitalGateCapabilityEntryIR:
        """Build a matrix row from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("DigitalGateCapabilityEntryIR JSON must be an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class DigitalGateCapabilityMatrixIR(IRMixin):
    """Side-effect-free matrix for digital gate support boundaries."""

    matrix_id: str
    phase: str
    entries: tuple[DigitalGateCapabilityEntryIR, ...]
    status_counts: dict[str, dict[str, int]]
    diagnostics: tuple[DiagnosticsIR, ...] = ()
    metadata_only: bool = True
    simulator_invoked: bool = False
    compiler_invoked: bool = False
    execution_package_created: bool = False
    backend_called: bool = False
    cloud_called: bool = False
    external_sdk_imported: bool = False
    cascaqit_compat_required: bool = False
    network_accessed: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize matrix payload and enforce boundary flags."""
        if not self.metadata_only:
            raise ValueError("DigitalGateCapabilityMatrixIR must be metadata-only.")
        if self.simulator_invoked:
            raise ValueError("Digital gate capability matrix must not run simulators.")
        if self.compiler_invoked:
            raise ValueError("Digital gate capability matrix must not run compilers.")
        if self.execution_package_created:
            raise ValueError("Digital gate capability matrix must not create packages.")
        if self.backend_called or self.cloud_called:
            raise ValueError("Digital gate capability matrix must not call backends.")
        if self.external_sdk_imported:
            raise ValueError("Digital gate capability matrix must not import SDKs.")
        if self.cascaqit_compat_required:
            raise ValueError("Digital gate capability matrix must not require compat.")
        if self.network_accessed:
            raise ValueError("Digital gate capability matrix cannot access networks.")
        object.__setattr__(
            self,
            "entries",
            tuple(
                entry
                if isinstance(entry, DigitalGateCapabilityEntryIR)
                else DigitalGateCapabilityEntryIR.from_dict(entry)
                for entry in self.entries
            ),
        )
        object.__setattr__(self, "status_counts", canonicalize(self.status_counts))
        object.__setattr__(
            self,
            "diagnostics",
            tuple(
                diagnostic
                if isinstance(diagnostic, DiagnosticsIR)
                else DiagnosticsIR.from_dict(diagnostic)
                for diagnostic in self.diagnostics
            ),
        )
        object.__setattr__(self, "metadata", canonicalize(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DigitalGateCapabilityMatrixIR:
        """Build a matrix from a JSON-compatible dictionary."""
        return cls(
            matrix_id=str(data["matrix_id"]),
            phase=str(data.get("phase", "215")),
            entries=tuple(
                DigitalGateCapabilityEntryIR.from_dict(item)
                for item in data.get("entries", ())
            ),
            status_counts=dict(data.get("status_counts", {})),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(item)
                for item in data.get("diagnostics", ())
            ),
            metadata_only=bool(data.get("metadata_only", True)),
            simulator_invoked=bool(data.get("simulator_invoked", False)),
            compiler_invoked=bool(data.get("compiler_invoked", False)),
            execution_package_created=bool(
                data.get("execution_package_created", False)
            ),
            backend_called=bool(data.get("backend_called", False)),
            cloud_called=bool(data.get("cloud_called", False)),
            external_sdk_imported=bool(data.get("external_sdk_imported", False)),
            cascaqit_compat_required=bool(
                data.get("cascaqit_compat_required", False)
            ),
            network_accessed=bool(data.get("network_accessed", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> DigitalGateCapabilityMatrixIR:
        """Build a matrix from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("DigitalGateCapabilityMatrixIR JSON must be an object.")
        return cls.from_dict(data)

    def by_gate(self) -> dict[str, DigitalGateCapabilityEntryIR]:
        """Return matrix entries keyed by gate name."""
        return {entry.gate: entry for entry in self.entries}


def build_digital_gate_capability_matrix(
    *,
    matrix_id: str = "digital_gate_capability_matrix.v0_28.phase215",
    gates: Iterable[str] | None = None,
) -> DigitalGateCapabilityMatrixIR:
    """Build the Digital gate capability matrix."""
    gate_names = tuple(_GATE_ORDER if gates is None else gates)
    entries = tuple(_entry_for_gate(gate) for gate in gate_names)
    diagnostics = _matrix_diagnostics(entries)
    return DigitalGateCapabilityMatrixIR(
        matrix_id=matrix_id,
        phase="215",
        entries=entries,
        status_counts=_status_counts(entries),
        diagnostics=diagnostics,
        metadata={
            "scope": "v0_28_restricted_digital_gate_interop_maturation",
            "gate_count": len(entries),
            "current_openqasm_subset": sorted(_V0_27_OPENQASM_GATES),
            "v0_28_direct_openqasm_targets": sorted(
                _V0_28_DIRECT_OPENQASM_TARGETS
            ),
            "v0_28_lowered_openqasm_targets": sorted(
                _V0_28_LOWERED_OPENQASM_TARGETS
            ),
            "v0_28_blocked_openqasm_targets": sorted(
                _V0_28_BLOCKED_OPENQASM_TARGETS
            ),
            "hardware_execution_claimed": False,
            "cloud_execution_claimed": False,
            "cascaqit_compat_dependency": False,
        },
    )


def _entry_for_gate(gate: str) -> DigitalGateCapabilityEntryIR:
    if gate not in _ARITY:
        return DigitalGateCapabilityEntryIR(
            gate=gate,
            arity=0,
            parameter_names=(),
            ir_status="unsupported",
            simulator_status="unsupported",
            compile_package_status="unsupported",
            current_openqasm_import_status="unsupported",
            current_openqasm_export_status="unsupported",
            v0_28_openqasm_import_target="unsupported",
            v0_28_openqasm_export_target="unsupported",
            diagnostics=(
                _diagnostic(
                    gate=gate,
                    code="DIGITAL_GATE_MATRIX_GATE_UNKNOWN",
                    severity="error",
                    message="Gate is outside the CASCAQit digital gate matrix.",
                    category="unknown_gate",
                ),
            ),
            metadata={
                "known_gate": False,
                "diagnostic_boundary": "unsupported_gate",
                "hardware_execution_claimed": False,
            },
        )
    current_import: DigitalGateCapabilityStatus = (
        "supported"
        if gate in _V0_27_OPENQASM_GATES
        or gate in _CURRENT_OPENQASM_IMPORT_EXPANSION_GATES
        else "blocked"
    )
    if (
        gate in _V0_27_OPENQASM_GATES
        or gate in _CURRENT_OPENQASM_EXPORT_EXPANSION_GATES
    ):
        current_export: DigitalGateCapabilityStatus = "supported"
    elif gate in _CURRENT_OPENQASM_EXPORT_LOWERED_GATES:
        current_export = "lowered"
    else:
        current_export = "blocked"
    target_status, lowering_strategy = _v0_28_openqasm_target(gate)
    diagnostics = _entry_diagnostics(
        gate=gate,
        current_openqasm_export=current_export,
        target_status=target_status,
        lowering_strategy=lowering_strategy,
    )
    return DigitalGateCapabilityEntryIR(
        gate=gate,
        arity=_ARITY[gate],
        parameter_names=_PARAMETERS.get(gate, ()),
        ir_status="supported",
        simulator_status="supported",
        compile_package_status="supported",
        current_openqasm_import_status=current_import,
        current_openqasm_export_status=current_export,
        v0_28_openqasm_import_target=target_status,
        v0_28_openqasm_export_target=target_status,
        lowering_strategy=lowering_strategy,
        diagnostics=diagnostics,
        metadata={
            "known_gate": True,
            "hardware_execution_claimed": False,
            "cloud_execution_claimed": False,
            "local_mock_only": True,
            "target_calibration_required_for_live_execution": True,
            "diagnostic_boundary": _diagnostic_boundary(
                target_status,
                current_export=current_export,
            ),
        },
    )


def _v0_28_openqasm_target(
    gate: str,
) -> tuple[DigitalGateCapabilityStatus, str | None]:
    if gate in _V0_27_OPENQASM_GATES or gate in _V0_28_DIRECT_OPENQASM_TARGETS:
        return "supported", "direct_openqasm_stdgate"
    if gate in _V0_28_LOWERED_OPENQASM_TARGETS:
        return "lowered", "swap_to_three_cx"
    if gate in _V0_28_BLOCKED_OPENQASM_TARGETS:
        return "blocked", "blocked_until_stable_toffoli_lowering"
    return "unsupported", None


def _entry_diagnostics(
    *,
    gate: str,
    current_openqasm_export: DigitalGateCapabilityStatus,
    target_status: DigitalGateCapabilityStatus,
    lowering_strategy: str | None,
) -> tuple[DiagnosticsIR, ...]:
    diagnostics: list[DiagnosticsIR] = []
    if current_openqasm_export == "blocked" and target_status == "supported":
        diagnostics.append(
            _diagnostic(
                gate=gate,
                code="DIGITAL_GATE_OPENQASM_EXPANSION_PLANNED",
                severity="info",
                message=(
                    "Gate is supported by digital IR and local simulation; "
                    "direct restricted OpenQASM export remains planned."
                ),
                category="v0_28_direct_openqasm_target",
            )
        )
    if target_status == "lowered" and current_openqasm_export != "lowered":
        diagnostics.append(
            _diagnostic(
                gate=gate,
                code="DIGITAL_GATE_OPENQASM_LOWERING_PLANNED",
                severity="info",
                message=(
                    "Gate is supported by digital IR and local simulation; "
                    "explicit OpenQASM lowering metadata remains planned."
                ),
                category="v0_28_lowering_target",
                metadata={"lowering_strategy": lowering_strategy},
            )
        )
    if current_openqasm_export == "lowered":
        diagnostics.append(
            _diagnostic(
                gate=gate,
                code="DIGITAL_GATE_OPENQASM_LOWERING_ACTIVE",
                severity="info",
                message=(
                    "Gate is exported through explicit restricted OpenQASM "
                    "lowering metadata."
                ),
                category="current_lowered_openqasm_export",
                metadata={"lowering_strategy": lowering_strategy},
            )
        )
    if target_status == "blocked":
        diagnostics.append(
            _diagnostic(
                gate=gate,
                code="DIGITAL_GATE_OPENQASM_REMAINS_BLOCKED",
                severity="warning",
                message=(
                    "Gate remains blocked for restricted OpenQASM import/export "
                    "until a stable lowering and source-map policy is added."
                ),
                category="v0_28_blocked_target",
                metadata={"lowering_strategy": lowering_strategy},
            )
        )
    return tuple(diagnostics)


def _diagnostic_boundary(
    target_status: DigitalGateCapabilityStatus,
    *,
    current_export: DigitalGateCapabilityStatus,
) -> str:
    if target_status == "blocked":
        return "target_blocked_gate"
    if current_export == "lowered" or target_status == "lowered":
        return "lowered_gate"
    if target_status == "unsupported":
        return "unsupported_gate"
    return "supported_gate"


def _matrix_diagnostics(
    entries: tuple[DigitalGateCapabilityEntryIR, ...],
) -> tuple[DiagnosticsIR, ...]:
    blocked = tuple(
        entry.gate
        for entry in entries
        if entry.v0_28_openqasm_export_target == "blocked"
    )
    lowered = tuple(
        entry.gate
        for entry in entries
        if entry.v0_28_openqasm_export_target == "lowered"
    )
    return (
        DiagnosticsIR(
            diagnostic_id="digital.gate_capability_matrix.ready",
            stage="validation",
            severity="info",
            code="DIGITAL_GATE_CAPABILITY_MATRIX_READY",
            message="Digital gate capability matrix was built without side effects.",
            object_path="digital_gate_capability_matrix",
            metadata={
                "blocked_v0_28_openqasm_export_targets": list(blocked),
                "lowered_v0_28_openqasm_export_targets": list(lowered),
                "metadata_only": True,
            },
        ),
    )


def _status_counts(
    entries: tuple[DigitalGateCapabilityEntryIR, ...],
) -> dict[str, dict[str, int]]:
    fields = (
        "ir_status",
        "simulator_status",
        "compile_package_status",
        "current_openqasm_import_status",
        "current_openqasm_export_status",
        "v0_28_openqasm_import_target",
        "v0_28_openqasm_export_target",
    )
    counts: dict[str, dict[str, int]] = {}
    for field_name in fields:
        field_counts: dict[str, int] = {}
        for entry in entries:
            status = str(getattr(entry, field_name))
            field_counts[status] = field_counts.get(status, 0) + 1
        counts[field_name] = dict(sorted(field_counts.items()))
    return counts


def _diagnostic(
    *,
    gate: str,
    code: str,
    severity: Literal["info", "warning", "error"],
    message: str,
    category: str,
    metadata: dict[str, Any] | None = None,
) -> DiagnosticsIR:
    payload = {
        "gate": gate,
        "reason_category": category,
        "hardware_execution_claimed": False,
        "cloud_execution_claimed": False,
        "cascaqit_compat_required": False,
    }
    if metadata:
        payload.update(metadata)
    return DiagnosticsIR(
        diagnostic_id=f"digital.gate_matrix.{gate}.{code.lower()}",
        stage="validation",
        severity=severity,
        code=code,
        message=message,
        object_path=f"digital_gate_capability_matrix.entries.{gate}",
        suggestion="Use the matrix status fields before extending OpenQASM support.",
        metadata=payload,
    )
