"""Digital IR-only API contracts."""

from cascaqit.digital.capability import (
    DigitalGateCapabilityEntryIR,
    DigitalGateCapabilityMatrixIR,
    DigitalGateCapabilityStatus,
    build_digital_gate_capability_matrix,
)
from cascaqit.digital.circuit import Circuit, GateParameterOccurrence
from cascaqit.digital.models import (
    CircuitIR,
    DigitalMeasurementIR,
    DigitalMeasurementRegisterSummaryIR,
    DigitalProgramIR,
    GateIR,
    build_digital_measurement_register_summary,
    build_digital_program,
    diagnose_digital_execution_support,
)
from cascaqit.digital.package_api import (
    DigitalPackageAPIEntryIR,
    DigitalPackageAPIInventoryIR,
    DigitalPackageAPIStability,
    DigitalPackageAPISurface,
    build_digital_package_api_inventory,
)
from cascaqit.digital.package_ownership import (
    DigitalPackageOwnershipGuardIR,
    DigitalPackageOwnershipStatus,
    build_digital_package_ownership_guard,
)
from cascaqit.digital.projection import (
    DigitalMeasurementProjectionIR,
    DigitalMeasurementProjectionRegisterIR,
    DigitalMeasurementProjectionSummaryIR,
    build_digital_measurement_projection_summary,
    read_digital_measurement_projection,
)

__all__ = [
    "Circuit",
    "CircuitIR",
    "DigitalGateCapabilityEntryIR",
    "DigitalGateCapabilityMatrixIR",
    "DigitalGateCapabilityStatus",
    "DigitalMeasurementIR",
    "DigitalMeasurementProjectionIR",
    "DigitalMeasurementProjectionRegisterIR",
    "DigitalMeasurementProjectionSummaryIR",
    "DigitalMeasurementRegisterSummaryIR",
    "DigitalPackageAPIEntryIR",
    "DigitalPackageAPIInventoryIR",
    "DigitalPackageAPIStability",
    "DigitalPackageAPISurface",
    "DigitalPackageOwnershipGuardIR",
    "DigitalPackageOwnershipStatus",
    "DigitalProgramIR",
    "GateIR",
    "GateParameterOccurrence",
    "build_digital_gate_capability_matrix",
    "build_digital_measurement_register_summary",
    "build_digital_measurement_projection_summary",
    "build_digital_package_api_inventory",
    "build_digital_package_ownership_guard",
    "build_digital_program",
    "diagnose_digital_execution_support",
    "read_digital_measurement_projection",
]
