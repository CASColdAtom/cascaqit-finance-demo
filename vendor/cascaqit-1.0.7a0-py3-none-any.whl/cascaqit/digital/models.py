"""Digital static-circuit API models."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Literal

from cascaqit.diagnostics import DiagnosticsIR, with_diagnostic_taxonomy
from cascaqit.native_ir.base import IRMixin
from cascaqit.native_ir.models import SCHEMA_VERSION

__all__ = [
    "CircuitIR",
    "DigitalMeasurementIR",
    "DigitalMeasurementRegisterSummaryIR",
    "DigitalProgramIR",
    "GateIR",
    "build_digital_measurement_register_summary",
    "build_digital_program",
    "diagnose_digital_execution_support",
]

DigitalGateName = Literal[
    "i",
    "x",
    "y",
    "z",
    "h",
    "s",
    "sdg",
    "t",
    "tdg",
    "rx",
    "ry",
    "rz",
    "p",
    "u",
    "cx",
    "cy",
    "cz",
    "swap",
    "ccx",
]
DigitalMeasurementBasis = Literal["computational", "z"]
DigitalValidationMode = Literal["ir_only"]

_SUPPORTED_GATES: frozenset[str] = frozenset(
    {
        "i",
        "x",
        "y",
        "z",
        "h",
        "s",
        "sdg",
        "t",
        "tdg",
        "rx",
        "ry",
        "rz",
        "p",
        "u",
        "cx",
        "cy",
        "cz",
        "swap",
        "ccx",
    }
)
_SINGLE_QUBIT_GATES = frozenset(
    {"i", "x", "y", "z", "h", "s", "sdg", "t", "tdg"}
)
_ROTATION_GATES = frozenset({"rx", "ry", "rz", "p"})
_TWO_QUBIT_GATES = frozenset({"cx", "cy", "cz", "swap"})
_THREE_QUBIT_GATES = frozenset({"ccx"})


@dataclass(frozen=True)
class GateIR(IRMixin):
    """Single digital gate operation."""

    gate_id: str
    name: DigitalGateName
    targets: tuple[str, ...]
    parameters: dict[str, float] = field(default_factory=dict)
    controls: tuple[str, ...] = ()
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def i(
        cls,
        qubit: str,
        *,
        gate_id: str = "gate.i",
        metadata: dict[str, Any] | None = None,
    ) -> GateIR:
        """Build an identity gate."""
        return _one_qubit_gate(cls, "i", qubit, gate_id=gate_id, metadata=metadata)

    @classmethod
    def x(
        cls,
        qubit: str,
        *,
        gate_id: str = "gate.x",
        metadata: dict[str, Any] | None = None,
    ) -> GateIR:
        """Build a Pauli-X gate."""
        return _one_qubit_gate(cls, "x", qubit, gate_id=gate_id, metadata=metadata)

    @classmethod
    def y(
        cls,
        qubit: str,
        *,
        gate_id: str = "gate.y",
        metadata: dict[str, Any] | None = None,
    ) -> GateIR:
        """Build a Pauli-Y gate."""
        return _one_qubit_gate(cls, "y", qubit, gate_id=gate_id, metadata=metadata)

    @classmethod
    def z(
        cls,
        qubit: str,
        *,
        gate_id: str = "gate.z",
        metadata: dict[str, Any] | None = None,
    ) -> GateIR:
        """Build a Pauli-Z gate."""
        return _one_qubit_gate(cls, "z", qubit, gate_id=gate_id, metadata=metadata)

    @classmethod
    def h(
        cls,
        qubit: str,
        *,
        gate_id: str = "gate.h",
        metadata: dict[str, Any] | None = None,
    ) -> GateIR:
        """Build a Hadamard gate."""
        return _one_qubit_gate(cls, "h", qubit, gate_id=gate_id, metadata=metadata)

    @classmethod
    def s(
        cls,
        qubit: str,
        *,
        gate_id: str = "gate.s",
        metadata: dict[str, Any] | None = None,
    ) -> GateIR:
        """Build an S phase gate."""
        return _one_qubit_gate(cls, "s", qubit, gate_id=gate_id, metadata=metadata)

    @classmethod
    def sdg(
        cls,
        qubit: str,
        *,
        gate_id: str = "gate.sdg",
        metadata: dict[str, Any] | None = None,
    ) -> GateIR:
        """Build an S-dagger phase gate."""
        return _one_qubit_gate(cls, "sdg", qubit, gate_id=gate_id, metadata=metadata)

    @classmethod
    def t(
        cls,
        qubit: str,
        *,
        gate_id: str = "gate.t",
        metadata: dict[str, Any] | None = None,
    ) -> GateIR:
        """Build a T phase gate."""
        return _one_qubit_gate(cls, "t", qubit, gate_id=gate_id, metadata=metadata)

    @classmethod
    def tdg(
        cls,
        qubit: str,
        *,
        gate_id: str = "gate.tdg",
        metadata: dict[str, Any] | None = None,
    ) -> GateIR:
        """Build a T-dagger phase gate."""
        return _one_qubit_gate(cls, "tdg", qubit, gate_id=gate_id, metadata=metadata)

    @classmethod
    def rx(
        cls,
        qubit: str,
        theta: float,
        *,
        gate_id: str = "gate.rx",
        metadata: dict[str, Any] | None = None,
    ) -> GateIR:
        """Build an RX rotation gate."""
        return _rotation_gate(
            cls,
            "rx",
            qubit,
            theta,
            gate_id=gate_id,
            metadata=metadata,
        )

    @classmethod
    def ry(
        cls,
        qubit: str,
        theta: float,
        *,
        gate_id: str = "gate.ry",
        metadata: dict[str, Any] | None = None,
    ) -> GateIR:
        """Build an RY rotation gate."""
        return _rotation_gate(
            cls,
            "ry",
            qubit,
            theta,
            gate_id=gate_id,
            metadata=metadata,
        )

    @classmethod
    def rz(
        cls,
        qubit: str,
        theta: float,
        *,
        gate_id: str = "gate.rz",
        metadata: dict[str, Any] | None = None,
    ) -> GateIR:
        """Build an RZ rotation gate."""
        return _rotation_gate(
            cls,
            "rz",
            qubit,
            theta,
            gate_id=gate_id,
            metadata=metadata,
        )

    @classmethod
    def p(
        cls,
        qubit: str,
        theta: float,
        *,
        gate_id: str = "gate.p",
        metadata: dict[str, Any] | None = None,
    ) -> GateIR:
        """Build a single-qubit phase gate."""
        return _rotation_gate(
            cls,
            "p",
            qubit,
            theta,
            gate_id=gate_id,
            metadata=metadata,
        )

    @classmethod
    def u(
        cls,
        qubit: str,
        theta: float,
        phi: float,
        lam: float,
        *,
        gate_id: str = "gate.u",
        metadata: dict[str, Any] | None = None,
    ) -> GateIR:
        """Build a generic U(theta, phi, lambda) single-qubit gate."""
        return cls(
            gate_id=gate_id,
            name="u",
            targets=(str(qubit),),
            parameters={
                "theta": float(theta),
                "phi": float(phi),
                "lambda": float(lam),
            },
            metadata={} if metadata is None else dict(metadata),
        )

    @classmethod
    def cx(
        cls,
        control: str,
        target: str,
        *,
        gate_id: str = "gate.cx",
        metadata: dict[str, Any] | None = None,
    ) -> GateIR:
        """Build a controlled-X gate."""
        return _two_qubit_gate(
            cls,
            "cx",
            control,
            target,
            gate_id=gate_id,
            metadata=metadata,
        )

    @classmethod
    def cy(
        cls,
        control: str,
        target: str,
        *,
        gate_id: str = "gate.cy",
        metadata: dict[str, Any] | None = None,
    ) -> GateIR:
        """Build a controlled-Y gate."""
        return _two_qubit_gate(
            cls,
            "cy",
            control,
            target,
            gate_id=gate_id,
            metadata=metadata,
        )

    @classmethod
    def cz(
        cls,
        control: str,
        target: str,
        *,
        gate_id: str = "gate.cz",
        metadata: dict[str, Any] | None = None,
    ) -> GateIR:
        """Build a CZ gate."""
        return _two_qubit_gate(
            cls,
            "cz",
            control,
            target,
            gate_id=gate_id,
            metadata=metadata,
        )

    @classmethod
    def swap(
        cls,
        left: str,
        right: str,
        *,
        gate_id: str = "gate.swap",
        metadata: dict[str, Any] | None = None,
    ) -> GateIR:
        """Build a SWAP gate."""
        return _two_qubit_gate(
            cls,
            "swap",
            left,
            right,
            gate_id=gate_id,
            metadata=metadata,
        )

    @classmethod
    def ccx(
        cls,
        control0: str,
        control1: str,
        target: str,
        *,
        gate_id: str = "gate.ccx",
        metadata: dict[str, Any] | None = None,
    ) -> GateIR:
        """Build a Toffoli / controlled-controlled-X gate."""
        return cls(
            gate_id=gate_id,
            name="ccx",
            targets=(str(control0), str(control1), str(target)),
            metadata={} if metadata is None else dict(metadata),
        )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> GateIR:
        """Build a gate from a JSON-compatible dictionary."""
        return cls(
            gate_id=str(data["gate_id"]),
            name=data["name"],
            targets=tuple(str(target) for target in data["targets"]),
            parameters={
                str(name): float(value)
                for name, value in data.get("parameters", {}).items()
            },
            controls=tuple(str(control) for control in data.get("controls", ())),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> GateIR:
        """Build a gate from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("GateIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class DigitalMeasurementIR(IRMixin):
    """Digital measurement operation."""

    measurement_id: str
    targets: tuple[str, ...]
    key: str
    basis: DigitalMeasurementBasis = "computational"
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def measure(
        cls,
        targets: tuple[str, ...] | list[str],
        *,
        key: str = "m",
        measurement_id: str = "measurement.m",
        basis: DigitalMeasurementBasis = "computational",
        metadata: dict[str, Any] | None = None,
    ) -> DigitalMeasurementIR:
        """Build a terminal computational-basis measurement."""
        return cls(
            measurement_id=measurement_id,
            targets=tuple(str(target) for target in targets),
            key=key,
            basis=basis,
            metadata={} if metadata is None else dict(metadata),
        )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DigitalMeasurementIR:
        """Build a digital measurement from a dictionary."""
        return cls(
            measurement_id=str(data["measurement_id"]),
            targets=tuple(str(target) for target in data["targets"]),
            key=str(data["key"]),
            basis=data.get("basis", "computational"),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> DigitalMeasurementIR:
        """Build a digital measurement from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("DigitalMeasurementIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class CircuitIR(IRMixin):
    """Linear digital circuit IR."""

    circuit_id: str
    qubits: tuple[str, ...]
    gates: tuple[GateIR, ...] = ()
    measurements: tuple[DigitalMeasurementIR, ...] = ()
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CircuitIR:
        """Build a circuit from a JSON-compatible dictionary."""
        return cls(
            circuit_id=str(data["circuit_id"]),
            qubits=tuple(str(qubit) for qubit in data["qubits"]),
            gates=tuple(GateIR.from_dict(gate) for gate in data.get("gates", ())),
            measurements=tuple(
                DigitalMeasurementIR.from_dict(measurement)
                for measurement in data.get("measurements", ())
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> CircuitIR:
        """Build a circuit from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("CircuitIR JSON must contain an object.")
        return cls.from_dict(data)

    def validate_ir_only(self) -> tuple[DiagnosticsIR, ...]:
        """Validate digital IR shape without claiming execution support."""
        diagnostics: list[DiagnosticsIR] = []
        qubits = set(self.qubits)
        if len(qubits) != len(self.qubits):
            diagnostics.append(
                _digital_diagnostic(
                    code="DIGITAL_DUPLICATE_QUBIT",
                    message="Digital circuit qubit identifiers must be unique.",
                    object_path="circuit.qubits",
                    severity="error",
                    reason_category="digital_qubit_reference",
                    suggestion=(
                        "Rename duplicate entries in circuit.qubits before adding "
                        "gates or measurements."
                    ),
                ),
            )
        for index, gate in enumerate(self.gates):
            diagnostics.extend(_validate_gate(gate, index, qubits))
        for index, measurement in enumerate(self.measurements):
            diagnostics.extend(_validate_measurement(measurement, index, qubits))
        if not diagnostics:
            diagnostics.append(
                DiagnosticsIR(
                    diagnostic_id="digital.ir.valid",
                    stage="validation",
                    severity="info",
                    code="DIGITAL_IR_VALID",
                    message="Digital circuit is valid as IR-only data.",
                    object_path="circuit",
                    metadata={"validation_mode": "ir_only"},
                )
            )
        return tuple(diagnostics)


@dataclass(frozen=True)
class DigitalProgramIR(IRMixin):
    """Digital program wrapper for static-circuit workflows."""

    program_id: str
    circuit: CircuitIR
    schema_version: str = SCHEMA_VERSION
    program_type: Literal["digital"] = "digital"
    validation_mode: DigitalValidationMode = "ir_only"
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DigitalProgramIR:
        """Build a digital program from a JSON-compatible dictionary."""
        return cls(
            program_id=str(data["program_id"]),
            circuit=CircuitIR.from_dict(data["circuit"]),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            program_type=data.get("program_type", "digital"),
            validation_mode=data.get("validation_mode", "ir_only"),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> DigitalProgramIR:
        """Build a digital program from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("DigitalProgramIR JSON must contain an object.")
        return cls.from_dict(data)

    def validate_ir_only(self) -> tuple[DiagnosticsIR, ...]:
        """Validate the program as digital IR-only data."""
        return self.circuit.validate_ir_only()


@dataclass(frozen=True)
class DigitalMeasurementRegisterSummaryIR(IRMixin):
    """Named measurement/register summary for digital result mapping."""

    summary_id: str
    program_id: str
    qubit_order: tuple[str, ...]
    bit_order: dict[str, Any]
    measurement_mapping: dict[str, Any]
    registers: tuple[dict[str, Any], ...]
    diagnostics: tuple[DiagnosticsIR, ...] = ()
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DigitalMeasurementRegisterSummaryIR:
        """Build a measurement/register summary from a dictionary."""
        return cls(
            summary_id=str(data["summary_id"]),
            program_id=str(data["program_id"]),
            qubit_order=tuple(str(qubit) for qubit in data["qubit_order"]),
            bit_order=dict(data["bit_order"]),
            measurement_mapping=dict(data["measurement_mapping"]),
            registers=tuple(dict(register) for register in data["registers"]),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(diagnostic)
                for diagnostic in data.get("diagnostics", ())
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> DigitalMeasurementRegisterSummaryIR:
        """Build a measurement/register summary from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError(
                "DigitalMeasurementRegisterSummaryIR JSON must contain an object."
            )
        return cls.from_dict(data)


def build_digital_program(
    *,
    program_id: str,
    qubits: tuple[str, ...] | list[str],
    gates: tuple[GateIR, ...] | list[GateIR] = (),
    measurements: tuple[DigitalMeasurementIR, ...] | list[DigitalMeasurementIR] = (),
    circuit_id: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> DigitalProgramIR:
    """Build a digital static-circuit program IR."""
    circuit = CircuitIR(
        circuit_id=program_id if circuit_id is None else circuit_id,
        qubits=tuple(str(qubit) for qubit in qubits),
        gates=tuple(gates),
        measurements=tuple(measurements),
    )
    return DigitalProgramIR(
        program_id=program_id,
        circuit=circuit,
        metadata={} if metadata is None else dict(metadata),
    )


def build_digital_measurement_register_summary(
    program: DigitalProgramIR,
    *,
    summary_id: str | None = None,
) -> DigitalMeasurementRegisterSummaryIR:
    """Summarize named digital measurements without claiming backend support."""
    qubit_order = tuple(program.circuit.qubits)
    bit_index_by_qubit = {qubit: index for index, qubit in enumerate(qubit_order)}
    registers = tuple(
        {
            "measurement_id": measurement.measurement_id,
            "key": measurement.key,
            "basis": measurement.basis,
            "targets": list(measurement.targets),
            "target_bit_indices": [
                bit_index_by_qubit[target]
                for target in measurement.targets
                if target in bit_index_by_qubit
            ],
            "bitstring_index": "left_to_right_matches_qubit_order",
            "terminal_gate_index": len(program.circuit.gates),
        }
        for measurement in program.circuit.measurements
    )
    key_counts = _string_counts(
        measurement.key for measurement in program.circuit.measurements
    )
    duplicate_keys = sorted(key for key, count in key_counts.items() if count > 1)
    measured_targets = tuple(
        target
        for measurement in program.circuit.measurements
        for target in measurement.targets
    )
    repeated_targets = sorted(
        target
        for target, count in _string_counts(measured_targets).items()
        if count > 1
    )
    uncovered_qubits = tuple(
        qubit for qubit in qubit_order if qubit not in set(measured_targets)
    )
    diagnostics = [
        diagnostic
        for diagnostic in program.validate_ir_only()
        if diagnostic.severity != "info"
    ]
    if duplicate_keys:
        diagnostics.append(
            _digital_diagnostic(
                code="DIGITAL_MEASUREMENT_KEY_DUPLICATE",
                message="Digital measurement keys should be unique for result mapping.",
                object_path="circuit.measurements",
                severity="warning",
                metadata={"duplicate_keys": duplicate_keys},
            )
        )
    return DigitalMeasurementRegisterSummaryIR(
        summary_id=(
            f"measurement_register_summary.{program.program_id}"
            if summary_id is None
            else summary_id
        ),
        program_id=program.program_id,
        qubit_order=qubit_order,
        bit_order={
            "convention": "digital_qubit_order",
            "qubit_order": list(qubit_order),
            "bitstring_index": "left_to_right_matches_qubit_order",
        },
        measurement_mapping={
            "basis": "computational",
            "readout_kind": "digital_computational",
            "measurement_count": len(program.circuit.measurements),
            "bitstring_index": "left_to_right_matches_qubit_order",
            "measurements": list(registers),
        },
        registers=registers,
        diagnostics=tuple(diagnostics),
        metadata={
            "register_count": len(registers),
            "measurement_count": len(program.circuit.measurements),
            "duplicate_keys": duplicate_keys,
            "repeated_targets": repeated_targets,
            "uncovered_qubits": list(uncovered_qubits),
            "support_boundaries": _digital_support_boundaries(),
            "summary_kind": "digital_measurement_register_summary",
            "metadata_only": True,
        },
    )


def diagnose_digital_execution_support(
    program: DigitalProgramIR,
    *,
    capability: str = "execution",
) -> tuple[DiagnosticsIR, ...]:
    """Return diagnostics that digital execution is currently unsupported."""
    validation = program.validate_ir_only()
    blocking = [
        diagnostic
        for diagnostic in validation
        if diagnostic.severity in {"warning", "error"}
    ]
    if blocking:
        return tuple(blocking)
    code = {
        "backend": "DIGITAL_BACKEND_UNSUPPORTED",
        "execution": "DIGITAL_EXECUTION_UNSUPPORTED",
        "simulation": "DIGITAL_SIMULATION_SUPPORTED_LOCAL_BASELINE",
    }.get(capability, "DIGITAL_CAPABILITY_UNSUPPORTED")
    severity: Literal["info", "warning"] = (
        "info" if capability == "simulation" else "warning"
    )
    message = (
        "Digital programs are supported by the local small state-vector "
        "simulation baseline in this release."
        if capability == "simulation"
        else (
            "Digital programs are supported as serializable IR only for this "
            f"capability; {capability} is not implemented in this release."
        )
    )
    suggestion = (
        "Use LocalDigitalSimulator for small offline deterministic simulation."
        if capability == "simulation"
        else (
            "Use LocalDigitalSimulator for small offline simulation, or keep this "
            "DigitalProgramIR as an architecture-level contract."
        )
    )
    return (
        DiagnosticsIR(
            diagnostic_id=f"digital.{code.lower()}",
            stage="validation",
            severity=severity,
            code=code,
            message=message,
            object_path="digital_program",
            suggestion=suggestion,
            metadata={
                "program_id": program.program_id,
                "capability": capability,
                "validation_mode": program.validation_mode,
                "local_simulator": "LocalDigitalSimulator",
                "unsupported_reason_categories": _digital_unsupported_categories(
                    capability
                ),
                "support_boundaries": _digital_support_boundaries(),
                "gate_support": _digital_gate_support_summary(program),
                "measurement_summary": (
                    build_digital_measurement_register_summary(program)
                    .to_dict()
                    .get("metadata", {})
                ),
            },
        ),
    )


def _validate_gate(
    gate: GateIR,
    index: int,
    qubits: set[str],
) -> tuple[DiagnosticsIR, ...]:
    diagnostics: list[DiagnosticsIR] = []
    object_path = f"circuit.gates[{index}]"
    if gate.name not in _SUPPORTED_GATES:
        diagnostics.append(
            _digital_diagnostic(
                code="DIGITAL_GATE_UNSUPPORTED",
                message="Digital gate is not part of the static circuit gate set.",
                object_path=f"{object_path}.name",
                metadata={"gate_name": gate.name},
                reason_category="digital_gate_shape",
                suggestion=(
                    "Use a supported GateIR helper such as GateIR.h, GateIR.rx, "
                    "GateIR.cx, or keep unsupported operations outside "
                    "DigitalProgramIR."
                ),
            )
        )
    unknown_targets = [target for target in gate.targets if target not in qubits]
    if unknown_targets:
        diagnostics.append(
            _digital_diagnostic(
                code="DIGITAL_UNKNOWN_QUBIT",
                message="Digital gate references qubits that are not in the circuit.",
                object_path=f"{object_path}.targets",
                severity="error",
                metadata={"unknown_targets": unknown_targets},
                reason_category="digital_qubit_reference",
                suggestion=(
                    "Add the missing qubit identifiers to circuit.qubits or change "
                    "the gate targets to existing qubits."
                ),
            )
        )
    if len(set(gate.targets)) != len(gate.targets):
        diagnostics.append(
            _digital_diagnostic(
                code="DIGITAL_GATE_TARGET_DUPLICATE",
                message="Digital gate targets must be unique.",
                object_path=f"{object_path}.targets",
                severity="error",
                metadata={"gate_name": gate.name},
                reason_category="digital_gate_target",
                suggestion=(
                    "Use distinct target qubits for this gate; encode control and "
                    "target roles in the ordered targets tuple."
                ),
            )
        )
    if gate.controls:
        diagnostics.append(
            _digital_diagnostic(
                code="DIGITAL_GATE_CONTROLS_UNSUPPORTED",
                message=(
                    "Digital standard gates encode controls in targets; the "
                    "controls field is reserved."
                ),
                object_path=f"{object_path}.controls",
                severity="error",
                metadata={"gate_name": gate.name},
                reason_category="digital_gate_control",
                suggestion=(
                    "Use the standard helper for controlled gates, for example "
                    "GateIR.cx(control, target), instead of the controls field."
                ),
            )
        )
    diagnostics.extend(_validate_gate_shape(gate, object_path))
    return tuple(diagnostics)


def _digital_support_boundaries() -> dict[str, Any]:
    return {
        "local_simulator_supported": True,
        "local_mock_backend_supported": True,
        "simulator_support_implies_hardware_support": False,
        "hanyuan_live_digital_execution": "unsupported",
        "cloud_compile": "blocked",
        "hardware_payload_emitted": False,
        "cascaqit_compat_dependency": False,
    }


def _digital_unsupported_categories(capability: str) -> list[str]:
    categories = {"backend", "target", "calibration"}
    if capability not in {"simulation", "execution", "backend"}:
        categories.add("capability")
    if capability != "simulation":
        categories.add("live_hardware")
    return sorted(categories)


def _digital_gate_support_summary(program: DigitalProgramIR) -> dict[str, Any]:
    gates = []
    for index, gate in enumerate(program.circuit.gates):
        expected = _gate_contract(gate.name)
        gates.append(
            {
                "gate_id": gate.gate_id,
                "gate": gate.name,
                "source_path": f"circuit.gates[{index}]",
                "targets": list(gate.targets),
                "controls": list(gate.controls),
                "parameters": sorted(gate.parameters),
                "canonical_gate_set": gate.name in _SUPPORTED_GATES,
                "arity": {
                    "expected": None if expected is None else expected["arity"],
                    "actual": len(gate.targets),
                    "supported_by_ir": (
                        expected is not None and expected["arity"] == len(gate.targets)
                    ),
                },
                "controls_supported": not gate.controls,
                "target_binding": "requires_compile_target_snapshot",
                "calibration_binding": "requires_compile_calibration_snapshot",
                "local_simulator_baseline": gate.name in _SUPPORTED_GATES,
                "live_hardware_claimed": False,
            }
        )
    return {
        "gate_count": len(gates),
        "gates": gates,
        "diagnostic_categories": [
            "arity",
            "control",
            "target",
            "calibration",
            "backend",
        ],
    }


def _gate_contract(gate_name: str) -> dict[str, Any] | None:
    if gate_name in _SINGLE_QUBIT_GATES:
        return {"arity": 1, "parameters": []}
    if gate_name in _ROTATION_GATES:
        return {"arity": 1, "parameters": ["theta"]}
    if gate_name == "u":
        return {"arity": 1, "parameters": ["lambda", "phi", "theta"]}
    if gate_name in _TWO_QUBIT_GATES:
        return {"arity": 2, "parameters": []}
    if gate_name in _THREE_QUBIT_GATES:
        return {"arity": 3, "parameters": []}
    return None


def _string_counts(values: Any) -> dict[str, int]:
    counts: dict[str, int] = {}
    for value in values:
        text = str(value)
        counts[text] = counts.get(text, 0) + 1
    return counts


def _validate_gate_shape(gate: GateIR, object_path: str) -> tuple[DiagnosticsIR, ...]:
    if gate.name in _SINGLE_QUBIT_GATES:
        return _expect_shape(
            gate,
            object_path=object_path,
            arity=1,
            required_parameters=frozenset(),
            message=f"{gate.name.upper()} gates require one target and no parameters.",
        )
    if gate.name in _ROTATION_GATES:
        return _expect_shape(
            gate,
            object_path=object_path,
            arity=1,
            required_parameters=frozenset({"theta"}),
            message=(
                f"{gate.name.upper()} gates require one target and a theta "
                "parameter."
            ),
        )
    if gate.name == "u":
        return _expect_shape(
            gate,
            object_path=object_path,
            arity=1,
            required_parameters=frozenset({"theta", "phi", "lambda"}),
            message=(
                "U gates require one target and theta, phi, lambda parameters."
            ),
        )
    if gate.name in _TWO_QUBIT_GATES:
        return _expect_shape(
            gate,
            object_path=object_path,
            arity=2,
            required_parameters=frozenset(),
            message=(
                f"{gate.name.upper()} gates require two targets and no parameters."
            ),
        )
    if gate.name in _THREE_QUBIT_GATES:
        return _expect_shape(
            gate,
            object_path=object_path,
            arity=3,
            required_parameters=frozenset(),
            message="CCX gates require three targets and no parameters.",
        )
    return ()


def _expect_shape(
    gate: GateIR,
    *,
    object_path: str,
    arity: int,
    required_parameters: frozenset[str],
    message: str,
) -> tuple[DiagnosticsIR, ...]:
    actual_parameters = frozenset(gate.parameters)
    diagnostics: list[DiagnosticsIR] = []
    if len(gate.targets) != arity:
        diagnostics.append(
            _digital_diagnostic(
                code="DIGITAL_GATE_SHAPE_INVALID",
                message=message,
                object_path=object_path,
                severity="error",
                metadata={
                    "gate_name": gate.name,
                    "expected_arity": arity,
                    "actual_arity": len(gate.targets),
                },
                reason_category="digital_gate_shape",
                suggestion=(
                    "Rebuild this gate with the matching GateIR helper so the "
                    "target count matches the gate contract."
                ),
            )
        )
    if actual_parameters != required_parameters:
        diagnostics.append(
            _digital_diagnostic(
                code="DIGITAL_GATE_PARAMETER_INVALID",
                message=message,
                object_path=f"{object_path}.parameters",
                severity="error",
                metadata={
                    "gate_name": gate.name,
                    "required_parameters": sorted(required_parameters),
                    "actual_parameters": sorted(actual_parameters),
                },
                reason_category="digital_gate_parameter",
                suggestion=(
                    "Use the matching GateIR helper so required parameters are "
                    "created with canonical names."
                ),
            )
        )
    return tuple(diagnostics)


def _validate_measurement(
    measurement: DigitalMeasurementIR,
    index: int,
    qubits: set[str],
) -> tuple[DiagnosticsIR, ...]:
    unknown_targets = [
        target for target in measurement.targets if target not in qubits
    ]
    diagnostics: list[DiagnosticsIR] = []
    if unknown_targets:
        diagnostics.append(
            _digital_diagnostic(
                code="DIGITAL_UNKNOWN_QUBIT",
                message="Digital measurement references qubits not in the circuit.",
                object_path=f"circuit.measurements[{index}].targets",
                severity="error",
                metadata={"unknown_targets": unknown_targets},
                reason_category="digital_qubit_reference",
                suggestion=(
                    "Add the missing qubit identifiers to circuit.qubits or change "
                    "the measurement targets to existing qubits."
                ),
            )
        )
    if len(set(measurement.targets)) != len(measurement.targets):
        diagnostics.append(
            _digital_diagnostic(
                code="DIGITAL_MEASUREMENT_TARGET_DUPLICATE",
                message="Digital measurement targets must be unique.",
                object_path=f"circuit.measurements[{index}].targets",
                severity="error",
                reason_category="digital_measurement_target",
                suggestion="Use each qubit at most once in a single measurement.",
            )
        )
    if not measurement.key:
        diagnostics.append(
            _digital_diagnostic(
                code="DIGITAL_MEASUREMENT_KEY_EMPTY",
                message="Digital measurement key must not be empty.",
                object_path=f"circuit.measurements[{index}].key",
                severity="error",
                reason_category="digital_measurement_key",
                suggestion=(
                    "Set a non-empty measurement key, for example "
                    "DigitalMeasurementIR.measure((\"q0\",), key=\"m\")."
                ),
            )
        )
    return tuple(diagnostics)


def _one_qubit_gate(
    cls: type[GateIR],
    name: DigitalGateName,
    qubit: str,
    *,
    gate_id: str,
    metadata: dict[str, Any] | None,
) -> GateIR:
    return cls(
        gate_id=gate_id,
        name=name,
        targets=(str(qubit),),
        metadata={} if metadata is None else dict(metadata),
    )


def _rotation_gate(
    cls: type[GateIR],
    name: DigitalGateName,
    qubit: str,
    theta: float,
    *,
    gate_id: str,
    metadata: dict[str, Any] | None,
) -> GateIR:
    return cls(
        gate_id=gate_id,
        name=name,
        targets=(str(qubit),),
        parameters={"theta": float(theta)},
        metadata={} if metadata is None else dict(metadata),
    )


def _two_qubit_gate(
    cls: type[GateIR],
    name: DigitalGateName,
    left: str,
    right: str,
    *,
    gate_id: str,
    metadata: dict[str, Any] | None,
) -> GateIR:
    return cls(
        gate_id=gate_id,
        name=name,
        targets=(str(left), str(right)),
        metadata={} if metadata is None else dict(metadata),
    )


def _digital_diagnostic(
    *,
    code: str,
    message: str,
    object_path: str,
    severity: Literal["info", "warning", "error"] = "warning",
    metadata: dict[str, Any] | None = None,
    reason_category: str = "digital",
    suggestion: str | None = None,
) -> DiagnosticsIR:
    payload = {} if metadata is None else dict(metadata)
    if code.startswith("DIGITAL_GATE_"):
        payload.setdefault(
            "expected_shape",
            {
                "gate_name": payload.get("gate_name"),
                "expected_arity": payload.get("expected_arity"),
                "required_parameters": payload.get("required_parameters"),
            },
        )
    return with_diagnostic_taxonomy(
        DiagnosticsIR(
            diagnostic_id=f"digital.{code.lower()}",
            stage="validation",
            severity=severity,
            code=code,
            message=message,
            object_path=object_path,
            suggestion=(
                "Fix the DigitalProgramIR shape before using it as a contract."
                if suggestion is None
                else suggestion
            ),
            metadata=payload,
        ),
        reason_category=reason_category,
        taxonomy_stage="validation",
        action="fix_digital_program_ir_shape",
    )
