"""Digital package ownership guard contracts."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Literal

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.digital.package_api import (
    DigitalPackageAPIInventoryIR,
    build_digital_package_api_inventory,
)
from cascaqit.native_ir.base import IRMixin, canonicalize
from cascaqit.native_ir.models import SCHEMA_VERSION

__all__ = [
    "DigitalPackageOwnershipGuardIR",
    "DigitalPackageOwnershipStatus",
    "build_digital_package_ownership_guard",
]

DigitalPackageOwnershipStatus = Literal["guarded", "blocked"]

_ROOT_CORE_HELPERS = ("Circuit",)
_PACKAGE_STABLE_HELPERS = (
    "CircuitIR",
    "GateIR",
    "DigitalMeasurementIR",
    "DigitalProgramIR",
    "build_digital_program",
    "diagnose_digital_execution_support",
    "read_digital_measurement_projection",
)
_PACKAGE_PROJECTION_HELPERS = (
    "DigitalMeasurementProjectionSummaryIR",
    "build_digital_measurement_projection_summary",
)
_PACKAGE_CAPABILITY_HELPERS = (
    "DigitalGateCapabilityMatrixIR",
    "build_digital_gate_capability_matrix",
)
_NON_DIGITAL_OWNER_HELPERS = (
    "DigitalLocalAcceptanceMatrixIR",
    "DigitalDiagnosticsConsistencyGuardIR",
    "DigitalAcceptanceFactSourceGuardIR",
    "OpenQASM3BoundaryAcceptanceIR",
    "build_openqasm3_boundary_acceptance",
    "render_openqasm3_subset",
)


@dataclass(frozen=True)
class DigitalPackageOwnershipGuardIR(IRMixin):
    """Metadata-only guard for digital package API ownership."""

    guard_id: str
    status: DigitalPackageOwnershipStatus
    owner_package: str
    root_core_helpers: tuple[str, ...]
    package_owner_helpers: tuple[str, ...]
    non_owner_helpers: tuple[str, ...]
    root_core_checks: dict[str, bool]
    package_owner_checks: dict[str, bool]
    non_owner_checks: dict[str, bool]
    projection_guidance_checks: dict[str, bool]
    diagnostics: tuple[DiagnosticsIR, ...]
    diagnostic_codes: tuple[str, ...]
    fact_source: str = "DigitalPackageAPIInventoryIR/cascaqit.digital.__all__"
    derived_view: bool = True
    metadata_only: bool = True
    simulator_invoked: bool = False
    compiler_invoked: bool = False
    execution_package_created: bool = False
    backend_called: bool = False
    cloud_called: bool = False
    network_accessed: bool = False
    credential_accessed: bool = False
    object_store_accessed: bool = False
    artifact_bytes_read: bool = False
    hardware_payload_bytes_read: bool = False
    cascaqit_compat_required: bool = False
    live_digital_hardware_supported: bool = False
    full_openqasm_supported: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize guard payload and enforce no-live ownership boundaries."""
        if not self.guard_id:
            raise ValueError("guard_id is required.")
        if self.owner_package != "cascaqit.digital":
            raise ValueError("Digital package ownership must stay in digital.")
        if not self.derived_view:
            raise ValueError("Digital package ownership guard must be a view.")
        if not self.metadata_only:
            raise ValueError("Digital package ownership guard must be metadata-only.")
        if self.simulator_invoked:
            raise ValueError("Digital package ownership must not run simulators.")
        if self.compiler_invoked:
            raise ValueError("Digital package ownership must not run compilers.")
        if self.execution_package_created:
            raise ValueError("Digital package ownership must not create packages.")
        if self.backend_called or self.cloud_called:
            raise ValueError("Digital package ownership must not call backends.")
        if self.network_accessed:
            raise ValueError("Digital package ownership must not use network.")
        if self.credential_accessed:
            raise ValueError("Digital package ownership must not read credentials.")
        if self.object_store_accessed:
            raise ValueError("Digital package ownership must not access object stores.")
        if self.artifact_bytes_read:
            raise ValueError("Digital package ownership must not read artifact bytes.")
        if self.hardware_payload_bytes_read:
            raise ValueError(
                "Digital package ownership must not read hardware payload bytes."
            )
        if self.cascaqit_compat_required:
            raise ValueError("Digital package ownership must not require compat.")
        if self.live_digital_hardware_supported:
            raise ValueError("Digital package ownership cannot claim live hardware.")
        if self.full_openqasm_supported:
            raise ValueError("Digital package ownership cannot claim full OpenQASM.")

        object.__setattr__(
            self,
            "root_core_helpers",
            tuple(str(name) for name in self.root_core_helpers),
        )
        object.__setattr__(
            self,
            "package_owner_helpers",
            tuple(str(name) for name in self.package_owner_helpers),
        )
        object.__setattr__(
            self,
            "non_owner_helpers",
            tuple(str(name) for name in self.non_owner_helpers),
        )
        object.__setattr__(
            self,
            "root_core_checks",
            {str(key): bool(value) for key, value in self.root_core_checks.items()},
        )
        object.__setattr__(
            self,
            "package_owner_checks",
            {
                str(key): bool(value)
                for key, value in self.package_owner_checks.items()
            },
        )
        object.__setattr__(
            self,
            "non_owner_checks",
            {str(key): bool(value) for key, value in self.non_owner_checks.items()},
        )
        object.__setattr__(
            self,
            "projection_guidance_checks",
            {
                str(key): bool(value)
                for key, value in self.projection_guidance_checks.items()
            },
        )
        object.__setattr__(
            self,
            "diagnostics",
            tuple(
                item if isinstance(item, DiagnosticsIR)
                else DiagnosticsIR.from_dict(item)
                for item in self.diagnostics
            ),
        )
        object.__setattr__(
            self,
            "diagnostic_codes",
            tuple(sorted(str(code) for code in self.diagnostic_codes)),
        )
        object.__setattr__(self, "metadata", canonicalize(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DigitalPackageOwnershipGuardIR:
        """Build a digital package ownership guard from a dictionary."""
        return cls(
            guard_id=str(data["guard_id"]),
            status=data["status"],
            owner_package=str(data["owner_package"]),
            root_core_helpers=tuple(str(name) for name in data["root_core_helpers"]),
            package_owner_helpers=tuple(
                str(name) for name in data["package_owner_helpers"]
            ),
            non_owner_helpers=tuple(str(name) for name in data["non_owner_helpers"]),
            root_core_checks=dict(data["root_core_checks"]),
            package_owner_checks=dict(data["package_owner_checks"]),
            non_owner_checks=dict(data["non_owner_checks"]),
            projection_guidance_checks=dict(data["projection_guidance_checks"]),
            diagnostics=tuple(
                item if isinstance(item, DiagnosticsIR)
                else DiagnosticsIR.from_dict(item)
                for item in data.get("diagnostics", ())
            ),
            diagnostic_codes=tuple(str(code) for code in data["diagnostic_codes"]),
            fact_source=str(
                data.get(
                    "fact_source",
                    "DigitalPackageAPIInventoryIR/cascaqit.digital.__all__",
                )
            ),
            derived_view=bool(data.get("derived_view", True)),
            metadata_only=bool(data.get("metadata_only", True)),
            simulator_invoked=bool(data.get("simulator_invoked", False)),
            compiler_invoked=bool(data.get("compiler_invoked", False)),
            execution_package_created=bool(
                data.get("execution_package_created", False)
            ),
            backend_called=bool(data.get("backend_called", False)),
            cloud_called=bool(data.get("cloud_called", False)),
            network_accessed=bool(data.get("network_accessed", False)),
            credential_accessed=bool(data.get("credential_accessed", False)),
            object_store_accessed=bool(data.get("object_store_accessed", False)),
            artifact_bytes_read=bool(data.get("artifact_bytes_read", False)),
            hardware_payload_bytes_read=bool(
                data.get("hardware_payload_bytes_read", False)
            ),
            cascaqit_compat_required=bool(
                data.get("cascaqit_compat_required", False)
            ),
            live_digital_hardware_supported=bool(
                data.get("live_digital_hardware_supported", False)
            ),
            full_openqasm_supported=bool(
                data.get("full_openqasm_supported", False)
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> DigitalPackageOwnershipGuardIR:
        """Build a digital package ownership guard from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("DigitalPackageOwnershipGuardIR JSON must be an object.")
        return cls.from_dict(data)


def build_digital_package_ownership_guard(
    *,
    inventory: DigitalPackageAPIInventoryIR | None = None,
    digital_exports: tuple[str, ...] | None = None,
    root_exports: tuple[str, ...] = (),
    guard_id: str = "digital_package_ownership.v1_06.phase938",
    metadata: dict[str, Any] | None = None,
) -> DigitalPackageOwnershipGuardIR:
    """Build a metadata-only guard for digital package API ownership."""
    inventory = inventory or build_digital_package_api_inventory()
    if not isinstance(inventory, DigitalPackageAPIInventoryIR):
        raise TypeError("inventory must be DigitalPackageAPIInventoryIR or None.")

    if digital_exports is None:
        digital_exports = tuple(
            entry.name
            for entry in inventory.entries_for_owner("cascaqit.digital")
        )

    root_core_checks = {
        f"root_stable.{name}": name in inventory.root_stable_subset
        and name in digital_exports
        and name in root_exports
        for name in _ROOT_CORE_HELPERS
    }
    package_owner_helpers = (
        _PACKAGE_STABLE_HELPERS
        + _PACKAGE_PROJECTION_HELPERS
        + _PACKAGE_CAPABILITY_HELPERS
    )
    package_owner_checks = {
        f"digital_package_owner.{name}": (
            inventory.entry_by_name(name).owner_package == "cascaqit.digital"
            and name in digital_exports
            and name not in inventory.root_stable_subset
        )
        for name in package_owner_helpers
    }
    non_owner_checks = {
        f"not_digital_owner.{name}": (
            inventory.entry_by_name(name).owner_package != "cascaqit.digital"
            and name not in digital_exports
        )
        for name in _NON_DIGITAL_OWNER_HELPERS
    }
    projection_guidance_checks = {
        f"projection_package_import.{name}": (
            "from cascaqit.digital import"
            in inventory.entry_by_name(name).metadata["recommended_import"]
        )
        for name in _PACKAGE_PROJECTION_HELPERS
    }
    diagnostics = _ownership_diagnostics(
        root_core_checks=root_core_checks,
        package_owner_checks=package_owner_checks,
        non_owner_checks=non_owner_checks,
        projection_guidance_checks=projection_guidance_checks,
    )
    return DigitalPackageOwnershipGuardIR(
        guard_id=guard_id,
        status="guarded" if not diagnostics else "blocked",
        owner_package="cascaqit.digital",
        root_core_helpers=_ROOT_CORE_HELPERS,
        package_owner_helpers=package_owner_helpers,
        non_owner_helpers=_NON_DIGITAL_OWNER_HELPERS,
        root_core_checks=root_core_checks,
        package_owner_checks=package_owner_checks,
        non_owner_checks=non_owner_checks,
        projection_guidance_checks=projection_guidance_checks,
        diagnostics=diagnostics,
        diagnostic_codes=tuple(diagnostic.code for diagnostic in diagnostics),
        metadata={
            "builder": "build_digital_package_ownership_guard",
            "inventory_hash": inventory.stable_hash(),
            "projection_helpers_are_package_owner": True,
            "digital_package_owns_openqasm_boundary": False,
            "digital_package_owns_consistency_guards": False,
            "root_export_growth_required": False,
            "cascaqit_compat_dependency": False,
            **({} if metadata is None else metadata),
        },
    )


def _ownership_diagnostics(
    *,
    root_core_checks: dict[str, bool],
    package_owner_checks: dict[str, bool],
    non_owner_checks: dict[str, bool],
    projection_guidance_checks: dict[str, bool],
) -> tuple[DiagnosticsIR, ...]:
    diagnostics: list[DiagnosticsIR] = []
    for group, checks, code in (
        ("root_core", root_core_checks, "DIGITAL_PACKAGE_ROOT_CORE_DRIFT"),
        (
            "package_owner",
            package_owner_checks,
            "DIGITAL_PACKAGE_OWNER_EXPORT_DRIFT",
        ),
        ("non_owner", non_owner_checks, "DIGITAL_PACKAGE_NON_OWNER_DRIFT"),
        (
            "projection_guidance",
            projection_guidance_checks,
            "DIGITAL_PACKAGE_PROJECTION_GUIDANCE_DRIFT",
        ),
    ):
        for name, passed in checks.items():
            if not passed:
                diagnostics.append(_diagnostic(group=group, name=name, code=code))
    return tuple(diagnostics)


def _diagnostic(
    *,
    group: str,
    name: str,
    code: str,
) -> DiagnosticsIR:
    return DiagnosticsIR(
        diagnostic_id=f"digital_package_ownership.{group}.{name}",
        stage="validation",
        severity="error",
        code=code,
        message="Digital package ownership guard detected API ownership drift.",
        object_path=f"{group}_checks.{name}",
        metadata={"group": group, "check": name, "metadata_only": True},
    )
