"""Digital package API inventory contracts.

This module is metadata-only. It records the current digital-related import
ownership across root, ``cascaqit.digital``, ``cascaqit.consistency``, and
``cascaqit.interop`` without importing optional external SDKs or invoking any
compiler, simulator, backend, cloud, or network path.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Literal

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.native_ir.base import IRMixin, canonicalize
from cascaqit.native_ir.models import SCHEMA_VERSION

__all__ = [
    "DigitalPackageAPIEntryIR",
    "DigitalPackageAPIInventoryIR",
    "DigitalPackageAPIStability",
    "DigitalPackageAPISurface",
    "build_digital_package_api_inventory",
]

DigitalPackageAPIStability = Literal["stable", "experimental"]
DigitalPackageAPISurface = Literal[
    "root_stable",
    "owner_package_stable",
    "owner_package_experimental",
]

_ROOT_STABLE_ENTRYPOINTS: tuple[tuple[str, str], ...] = (
    ("Circuit", "User-facing fluent static digital circuit builder."),
)

_DIGITAL_OWNER_STABLE_ENTRYPOINTS: tuple[tuple[str, str], ...] = (
    ("CircuitIR", "Digital circuit container for native digital programs."),
    ("DigitalMeasurementIR", "Digital measurement declaration."),
    ("DigitalProgramIR", "Native digital program IR."),
    (
        "GateParameterOccurrence",
        "Structured view of one declared Circuit gate parameter.",
    ),
    ("GateIR", "Native digital gate operation."),
    ("build_digital_program", "Native digital program builder."),
    (
        "diagnose_digital_execution_support",
        "Local digital execution support diagnostics.",
    ),
    (
        "read_digital_measurement_projection",
        "Read-only local result measurement projection helper.",
    ),
)

_DIGITAL_OWNER_ENTRYPOINTS: tuple[tuple[str, str], ...] = (
    (
        "DigitalMeasurementProjectionSummaryIR",
        "Derived local result measurement projection summary.",
    ),
    (
        "build_digital_measurement_projection_summary",
        "Build derived local measurement projection evidence.",
    ),
    (
        "DigitalGateCapabilityMatrixIR",
        "Metadata-only native digital gate capability matrix.",
    ),
    (
        "build_digital_gate_capability_matrix",
        "Build digital gate capability evidence without side effects.",
    ),
)

_CONSISTENCY_OWNER_ENTRYPOINTS: tuple[tuple[str, str], ...] = (
    (
        "DigitalLocalAcceptanceMatrixIR",
        "Derived local digital acceptance matrix.",
    ),
    (
        "build_digital_local_acceptance_matrix",
        "Build local digital acceptance evidence.",
    ),
    (
        "DigitalDiagnosticsConsistencyGuardIR",
        "Derived diagnostics consistency guard.",
    ),
    (
        "build_digital_diagnostics_consistency_guard",
        "Build diagnostics consistency guard evidence.",
    ),
    (
        "DigitalAcceptanceFactSourceGuardIR",
        "Derived acceptance fact-source boundary guard.",
    ),
    (
        "build_digital_acceptance_fact_source_guard",
        "Build acceptance fact-source boundary guard evidence.",
    ),
)

_INTEROP_OWNER_ENTRYPOINTS: tuple[tuple[str, str], ...] = (
    (
        "render_openqasm3_subset",
        "Restricted OpenQASM 3 export renderer.",
    ),
    (
        "OpenQASM3BoundaryAcceptanceIR",
        "Derived restricted OpenQASM boundary acceptance view.",
    ),
    (
        "build_openqasm3_boundary_acceptance",
        "Build restricted OpenQASM boundary acceptance evidence.",
    ),
)

_DERIVED_EVIDENCE_HELPERS = frozenset(
    {
        "DigitalMeasurementProjectionSummaryIR",
        "build_digital_measurement_projection_summary",
        "DigitalGateCapabilityMatrixIR",
        "build_digital_gate_capability_matrix",
        "DigitalLocalAcceptanceMatrixIR",
        "build_digital_local_acceptance_matrix",
        "DigitalDiagnosticsConsistencyGuardIR",
        "build_digital_diagnostics_consistency_guard",
        "DigitalAcceptanceFactSourceGuardIR",
        "build_digital_acceptance_fact_source_guard",
        "OpenQASM3BoundaryAcceptanceIR",
        "build_openqasm3_boundary_acceptance",
    }
)


@dataclass(frozen=True)
class DigitalPackageAPIEntryIR(IRMixin):
    """One digital-related package API ownership entry."""

    name: str
    owner_package: str
    import_path: str
    surface: DigitalPackageAPISurface
    stability: DigitalPackageAPIStability
    role: str
    description: str
    root_exported: bool
    metadata_only: bool
    derived_evidence: bool
    fact_source: bool
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize payload and enforce owner/root consistency."""
        if not self.name:
            raise ValueError("Digital package API entry name is required.")
        if not self.owner_package.startswith("cascaqit."):
            raise ValueError("Digital package API entry must use a CASCAQit package.")
        expected_import_path = f"{self.owner_package}.{self.name}"
        if self.import_path != expected_import_path:
            raise ValueError(
                "Digital package API import_path must match owner_package.name."
            )
        if self.surface == "root_stable" and not self.root_exported:
            raise ValueError("Root-stable digital API entries must be root exported.")
        if self.surface != "root_stable" and self.root_exported:
            raise ValueError("Owner package entries must not be marked root stable.")
        if self.derived_evidence and self.fact_source:
            raise ValueError("Derived evidence helpers cannot be fact sources.")
        object.__setattr__(self, "metadata", canonicalize(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DigitalPackageAPIEntryIR:
        """Build an API inventory entry from a JSON-compatible dictionary."""
        return cls(
            name=str(data["name"]),
            owner_package=str(data["owner_package"]),
            import_path=str(data["import_path"]),
            surface=data["surface"],
            stability=data["stability"],
            role=str(data["role"]),
            description=str(data["description"]),
            root_exported=bool(data["root_exported"]),
            metadata_only=bool(data["metadata_only"]),
            derived_evidence=bool(data["derived_evidence"]),
            fact_source=bool(data["fact_source"]),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> DigitalPackageAPIEntryIR:
        """Build an API inventory entry from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("DigitalPackageAPIEntryIR JSON must be an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class DigitalPackageAPIInventoryIR(IRMixin):
    """Metadata-only inventory for digital package API ownership."""

    inventory_id: str
    phase: str
    entries: tuple[DigitalPackageAPIEntryIR, ...]
    root_stable_subset: tuple[str, ...]
    owner_packages: tuple[str, ...]
    experimental_derived_helpers: tuple[str, ...]
    diagnostics: tuple[DiagnosticsIR, ...] = ()
    metadata_only: bool = True
    simulator_invoked: bool = False
    compiler_invoked: bool = False
    execution_package_created: bool = False
    backend_called: bool = False
    cloud_called: bool = False
    network_accessed: bool = False
    credential_accessed: bool = False
    object_store_accessed: bool = False
    artifact_bytes_read: bool = False
    hardware_payload_bytes_read: bool = False
    signed_url_issued: bool = False
    cascaqit_compat_required: bool = False
    live_hardware_ready: bool = False
    live_cloud_ready: bool = False
    full_openqasm_supported: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize inventory payload and enforce no-live/no-compat boundaries."""
        if not self.inventory_id:
            raise ValueError("inventory_id is required.")
        if not self.metadata_only:
            raise ValueError("Digital package API inventory must be metadata-only.")
        if self.simulator_invoked:
            raise ValueError("Digital package API inventory must not run simulators.")
        if self.compiler_invoked:
            raise ValueError("Digital package API inventory must not run compilers.")
        if self.execution_package_created:
            raise ValueError("Digital package API inventory must not create packages.")
        if self.backend_called or self.cloud_called:
            raise ValueError("Digital package API inventory must not call backends.")
        if self.network_accessed:
            raise ValueError("Digital package API inventory must not use network.")
        if self.credential_accessed:
            raise ValueError("Digital package API inventory must not read credentials.")
        if self.object_store_accessed:
            raise ValueError(
                "Digital package API inventory must not access object stores."
            )
        if self.artifact_bytes_read:
            raise ValueError(
                "Digital package API inventory must not read artifact bytes."
            )
        if self.hardware_payload_bytes_read:
            raise ValueError(
                "Digital package API inventory must not read hardware payload bytes."
            )
        if self.signed_url_issued:
            raise ValueError("Digital package API inventory must not issue URLs.")
        if self.cascaqit_compat_required:
            raise ValueError("Digital package API inventory must not require compat.")
        if self.live_hardware_ready:
            raise ValueError(
                "Digital package API inventory cannot claim live hardware."
            )
        if self.live_cloud_ready:
            raise ValueError("Digital package API inventory cannot claim live cloud.")
        if self.full_openqasm_supported:
            raise ValueError(
                "Digital package API inventory cannot claim full OpenQASM."
            )

        entries = tuple(
            entry
            if isinstance(entry, DigitalPackageAPIEntryIR)
            else DigitalPackageAPIEntryIR.from_dict(entry)
            for entry in self.entries
        )
        object.__setattr__(self, "entries", entries)
        object.__setattr__(
            self,
            "root_stable_subset",
            tuple(str(name) for name in self.root_stable_subset),
        )
        object.__setattr__(
            self,
            "owner_packages",
            tuple(str(package) for package in self.owner_packages),
        )
        object.__setattr__(
            self,
            "experimental_derived_helpers",
            tuple(str(name) for name in self.experimental_derived_helpers),
        )
        object.__setattr__(
            self,
            "diagnostics",
            tuple(
                diagnostic
                if isinstance(diagnostic, DiagnosticsIR)
                else DiagnosticsIR.from_dict(diagnostic)
                for diagnostic in self.diagnostics
            ),
        )
        object.__setattr__(self, "metadata", canonicalize(self.metadata))

        entry_names = {entry.name for entry in entries}
        root_entries = {
            entry.name
            for entry in entries
            if entry.surface == "root_stable" and entry.root_exported
        }
        if set(self.root_stable_subset) != root_entries:
            raise ValueError("root_stable_subset must match root-stable entries.")
        if not set(self.experimental_derived_helpers).issubset(entry_names):
            raise ValueError("experimental_derived_helpers contains unknown entries.")
        for name in self.experimental_derived_helpers:
            entry = self.entry_by_name(name)
            if not entry.derived_evidence or entry.fact_source:
                raise ValueError(
                    "experimental_derived_helpers must contain derived "
                    "non-fact entries."
                )
            if entry.surface == "root_stable":
                raise ValueError(
                    "experimental derived helpers must not be root-stable entries."
                )
        if tuple(sorted({entry.owner_package for entry in entries})) != (
            self.owner_packages
        ):
            raise ValueError("owner_packages must match inventory entries.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DigitalPackageAPIInventoryIR:
        """Build an API inventory from a JSON-compatible dictionary."""
        return cls(
            inventory_id=str(data["inventory_id"]),
            phase=str(data.get("phase", "936")),
            entries=tuple(
                DigitalPackageAPIEntryIR.from_dict(item)
                for item in data.get("entries", ())
            ),
            root_stable_subset=tuple(
                str(name) for name in data.get("root_stable_subset", ())
            ),
            owner_packages=tuple(
                str(package) for package in data.get("owner_packages", ())
            ),
            experimental_derived_helpers=tuple(
                str(name) for name in data.get("experimental_derived_helpers", ())
            ),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(item)
                for item in data.get("diagnostics", ())
            ),
            metadata_only=bool(data.get("metadata_only", True)),
            simulator_invoked=bool(data.get("simulator_invoked", False)),
            compiler_invoked=bool(data.get("compiler_invoked", False)),
            execution_package_created=bool(
                data.get("execution_package_created", False)
            ),
            backend_called=bool(data.get("backend_called", False)),
            cloud_called=bool(data.get("cloud_called", False)),
            network_accessed=bool(data.get("network_accessed", False)),
            credential_accessed=bool(data.get("credential_accessed", False)),
            object_store_accessed=bool(data.get("object_store_accessed", False)),
            artifact_bytes_read=bool(data.get("artifact_bytes_read", False)),
            hardware_payload_bytes_read=bool(
                data.get("hardware_payload_bytes_read", False)
            ),
            signed_url_issued=bool(data.get("signed_url_issued", False)),
            cascaqit_compat_required=bool(
                data.get("cascaqit_compat_required", False)
            ),
            live_hardware_ready=bool(data.get("live_hardware_ready", False)),
            live_cloud_ready=bool(data.get("live_cloud_ready", False)),
            full_openqasm_supported=bool(data.get("full_openqasm_supported", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> DigitalPackageAPIInventoryIR:
        """Build an API inventory from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("DigitalPackageAPIInventoryIR JSON must be an object.")
        return cls.from_dict(data)

    def entry_by_name(self, name: str) -> DigitalPackageAPIEntryIR:
        """Return one inventory entry by exported name."""
        for entry in self.entries:
            if entry.name == name:
                return entry
        raise KeyError(f"Unknown digital package API entry: {name!r}")

    def entries_for_owner(
        self,
        owner_package: str,
    ) -> tuple[DigitalPackageAPIEntryIR, ...]:
        """Return inventory entries owned by one package."""
        return tuple(
            entry for entry in self.entries if entry.owner_package == owner_package
        )


def build_digital_package_api_inventory(
    *,
    inventory_id: str = "digital_package_api_inventory.v1_06.phase936",
    metadata: dict[str, Any] | None = None,
) -> DigitalPackageAPIInventoryIR:
    """Build the Digital package API ownership inventory."""
    entries = (
        *_entries(
            owner_package="cascaqit.digital",
            surface="root_stable",
            stability="stable",
            role="digital_user_api",
            rows=_ROOT_STABLE_ENTRYPOINTS,
            root_exported=True,
            metadata_only=False,
            derived_evidence=False,
            fact_source=True,
        ),
        *_entries(
            owner_package="cascaqit.digital",
            surface="owner_package_stable",
            stability="stable",
            role="digital_advanced_api",
            rows=_DIGITAL_OWNER_STABLE_ENTRYPOINTS,
            root_exported=False,
            metadata_only=False,
            derived_evidence=False,
            fact_source=True,
        ),
        *_entries(
            owner_package="cascaqit.digital",
            surface="owner_package_experimental",
            stability="experimental",
            role="digital_derived_evidence",
            rows=_DIGITAL_OWNER_ENTRYPOINTS,
            root_exported=False,
            metadata_only=True,
            derived_evidence=True,
            fact_source=False,
        ),
        *_entries(
            owner_package="cascaqit.consistency",
            surface="owner_package_experimental",
            stability="experimental",
            role="digital_consistency_evidence",
            rows=_CONSISTENCY_OWNER_ENTRYPOINTS,
            root_exported=False,
            metadata_only=True,
            derived_evidence=True,
            fact_source=False,
        ),
        *_entries(
            owner_package="cascaqit.interop",
            surface="owner_package_experimental",
            stability="experimental",
            role="restricted_openqasm_boundary",
            rows=_INTEROP_OWNER_ENTRYPOINTS,
            root_exported=False,
            metadata_only=True,
            derived_evidence=True,
            fact_source=False,
        ),
    )
    root_stable_subset = tuple(
        entry.name for entry in entries if entry.surface == "root_stable"
    )
    owner_packages = tuple(sorted({entry.owner_package for entry in entries}))
    experimental_derived_helpers = tuple(
        entry.name
        for entry in entries
        if entry.name in _DERIVED_EVIDENCE_HELPERS
    )
    return DigitalPackageAPIInventoryIR(
        inventory_id=inventory_id,
        phase="936",
        entries=entries,
        root_stable_subset=root_stable_subset,
        owner_packages=owner_packages,
        experimental_derived_helpers=experimental_derived_helpers,
        diagnostics=(
            DiagnosticsIR(
                diagnostic_id="digital.package_api_inventory.ready",
                stage="validation",
                severity="info",
                code="DIGITAL_PACKAGE_API_INVENTORY_READY",
                message=(
                    "Digital package API inventory was built without runtime, "
                    "backend, cloud, network, or compatibility-layer side effects."
                ),
                object_path="digital_package_api_inventory",
                metadata={
                    "metadata_only": True,
                    "root_stable_count": len(root_stable_subset),
                    "owner_package_count": len(owner_packages),
                    "experimental_derived_helper_count": len(
                        experimental_derived_helpers
                    ),
                },
            ),
        ),
        metadata={
            "scope": "v1_06_digital_package_api_consolidation",
            "root_exports_growth": False,
            "package_imports_are_owner_boundaries": True,
            "cascaqit_compat_dependency": False,
            "live_hardware_execution_claimed": False,
            "cloud_execution_claimed": False,
            **(metadata or {}),
        },
    )


def _entries(
    *,
    owner_package: str,
    surface: DigitalPackageAPISurface,
    stability: DigitalPackageAPIStability,
    role: str,
    rows: tuple[tuple[str, str], ...],
    root_exported: bool,
    metadata_only: bool,
    derived_evidence: bool,
    fact_source: bool,
) -> tuple[DigitalPackageAPIEntryIR, ...]:
    return tuple(
        DigitalPackageAPIEntryIR(
            name=name,
            owner_package=owner_package,
            import_path=f"{owner_package}.{name}",
            surface=surface,
            stability=stability,
            role=role,
            description=description,
            root_exported=root_exported,
            metadata_only=metadata_only,
            derived_evidence=derived_evidence and name in _DERIVED_EVIDENCE_HELPERS,
            fact_source=fact_source,
            metadata={
                "recommended_import": (
                    f"from {owner_package} import {name}"
                    if surface != "root_stable"
                    else f"from cascaqit import {name}"
                ),
                "root_export_growth_required": False,
            },
        )
        for name, description in rows
    )
