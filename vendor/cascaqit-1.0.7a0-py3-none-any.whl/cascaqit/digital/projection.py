"""Read-only helpers for local digital measurement projection metadata."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any

from cascaqit.native_ir.base import IRMixin, canonicalize
from cascaqit.native_ir.models import SCHEMA_VERSION
from cascaqit.results import ResultIR

__all__ = [
    "DigitalMeasurementProjectionIR",
    "DigitalMeasurementProjectionRegisterIR",
    "DigitalMeasurementProjectionSummaryIR",
    "build_digital_measurement_projection_summary",
    "read_digital_measurement_projection",
]


@dataclass(frozen=True)
class DigitalMeasurementProjectionRegisterIR(IRMixin):
    """Read-only view of one projected digital measurement register."""

    measurement_id: str
    key: str
    basis: str
    targets: tuple[str, ...]
    target_bit_indices: tuple[int, ...]
    probabilities: dict[str, float]
    counts: dict[str, int]
    samples: tuple[str, ...]
    bitstring_index: str = "left_to_right_matches_qubit_order"
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize nested values for deterministic read-only serialization."""
        object.__setattr__(self, "targets", tuple(str(item) for item in self.targets))
        object.__setattr__(
            self,
            "target_bit_indices",
            tuple(int(index) for index in self.target_bit_indices),
        )
        object.__setattr__(
            self,
            "probabilities",
            {str(key): float(value) for key, value in self.probabilities.items()},
        )
        object.__setattr__(
            self,
            "counts",
            {str(key): int(value) for key, value in self.counts.items()},
        )
        object.__setattr__(self, "samples", tuple(str(item) for item in self.samples))
        object.__setattr__(self, "metadata", canonicalize(self.metadata))

    @classmethod
    def from_dict(
        cls,
        data: dict[str, Any],
    ) -> DigitalMeasurementProjectionRegisterIR:
        """Build a projected register view from JSON-compatible metadata."""
        if not isinstance(data, dict):
            raise TypeError("projection register must be a dictionary.")
        return cls(
            measurement_id=str(data["measurement_id"]),
            key=str(data["key"]),
            basis=str(data["basis"]),
            targets=tuple(str(target) for target in data.get("targets", ())),
            target_bit_indices=tuple(
                int(index) for index in data.get("target_bit_indices", ())
            ),
            bitstring_index=str(
                data.get("bitstring_index", "left_to_right_matches_qubit_order")
            ),
            probabilities={
                str(key): float(value)
                for key, value in dict(data.get("probabilities", {})).items()
            },
            counts={
                str(key): int(value)
                for key, value in dict(data.get("counts", {})).items()
            },
            samples=tuple(str(sample) for sample in data.get("samples", ())),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> DigitalMeasurementProjectionRegisterIR:
        """Build a projected register view from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError(
                "DigitalMeasurementProjectionRegisterIR JSON must contain an object."
            )
        return cls.from_dict(data)


@dataclass(frozen=True)
class DigitalMeasurementProjectionIR(IRMixin):
    """Read-only view over local digital measurement projection metadata."""

    projection_id: str
    result_id: str
    program_hash: str
    projection_kind: str
    measurement_mapping: dict[str, Any]
    registers: tuple[DigitalMeasurementProjectionRegisterIR, ...]
    duplicate_keys: tuple[str, ...] = ()
    repeated_targets: tuple[str, ...] = ()
    uncovered_qubits: tuple[str, ...] = ()
    metadata_only: bool = True
    counts_are_full_bitstrings: bool = True
    samples_are_full_bitstrings: bool = True
    hardware_execution: bool = False
    cloud_execution: bool = False
    hanyuan_live_digital_execution: str = "unsupported"
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize payloads and enforce local metadata-only boundaries."""
        if not self.metadata_only:
            raise ValueError("Digital measurement projection must be metadata-only.")
        if not self.counts_are_full_bitstrings:
            raise ValueError("Top-level ResultIR counts must remain full bitstrings.")
        if not self.samples_are_full_bitstrings:
            raise ValueError("Top-level ResultIR samples must remain full bitstrings.")
        if self.hardware_execution:
            raise ValueError("Projection reader cannot claim hardware execution.")
        if self.cloud_execution:
            raise ValueError("Projection reader cannot claim cloud execution.")
        if self.hanyuan_live_digital_execution != "unsupported":
            raise ValueError("Hanyuan live digital execution must remain unsupported.")
        object.__setattr__(
            self,
            "measurement_mapping",
            canonicalize(self.measurement_mapping),
        )
        object.__setattr__(
            self,
            "registers",
            tuple(
                register
                if isinstance(register, DigitalMeasurementProjectionRegisterIR)
                else DigitalMeasurementProjectionRegisterIR.from_dict(register)
                for register in self.registers
            ),
        )
        object.__setattr__(
            self,
            "duplicate_keys",
            tuple(str(item) for item in self.duplicate_keys),
        )
        object.__setattr__(
            self,
            "repeated_targets",
            tuple(str(item) for item in self.repeated_targets),
        )
        object.__setattr__(
            self,
            "uncovered_qubits",
            tuple(str(item) for item in self.uncovered_qubits),
        )
        object.__setattr__(self, "metadata", canonicalize(self.metadata))

    @property
    def register_keys(self) -> tuple[str, ...]:
        """Return projected measurement keys in register order."""
        return tuple(register.key for register in self.registers)

    def register_by_key(self, key: str) -> DigitalMeasurementProjectionRegisterIR:
        """Return the only projected register matching a measurement key."""
        matches = tuple(register for register in self.registers if register.key == key)
        if not matches:
            raise KeyError(f"Unknown digital measurement projection key: {key!r}")
        if len(matches) > 1:
            raise ValueError(
                "Projection key is ambiguous because duplicate measurement keys "
                f"exist: {key!r}"
            )
        return matches[0]

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DigitalMeasurementProjectionIR:
        """Build a projection view from JSON-compatible metadata."""
        if not isinstance(data, dict):
            raise TypeError("digital measurement projection must be a dictionary.")
        return cls(
            projection_id=str(data["projection_id"]),
            result_id=str(data["result_id"]),
            program_hash=str(data["program_hash"]),
            projection_kind=str(data["projection_kind"]),
            measurement_mapping=dict(data["measurement_mapping"]),
            registers=tuple(
                DigitalMeasurementProjectionRegisterIR.from_dict(register)
                for register in data.get("registers", ())
            ),
            duplicate_keys=tuple(str(item) for item in data.get("duplicate_keys", ())),
            repeated_targets=tuple(
                str(item) for item in data.get("repeated_targets", ())
            ),
            uncovered_qubits=tuple(
                str(item) for item in data.get("uncovered_qubits", ())
            ),
            metadata_only=bool(data.get("metadata_only", True)),
            counts_are_full_bitstrings=bool(
                data.get("counts_are_full_bitstrings", True)
            ),
            samples_are_full_bitstrings=bool(
                data.get("samples_are_full_bitstrings", True)
            ),
            hardware_execution=bool(data.get("hardware_execution", False)),
            cloud_execution=bool(data.get("cloud_execution", False)),
            hanyuan_live_digital_execution=str(
                data.get("hanyuan_live_digital_execution", "unsupported")
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> DigitalMeasurementProjectionIR:
        """Build a projection view from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError(
                "DigitalMeasurementProjectionIR JSON must contain an object."
            )
        return cls.from_dict(data)


def read_digital_measurement_projection(
    result: ResultIR,
    *,
    projection_id: str | None = None,
) -> DigitalMeasurementProjectionIR:
    """Read local digital measurement projection metadata without mutation.

    The helper does not recompute probabilities, reinterpret top-level
    `ResultIR.counts`, read artifacts, call backends, or imply hardware/cloud
    digital execution.
    """
    if not isinstance(result, ResultIR):
        raise TypeError("read_digital_measurement_projection accepts ResultIR.")
    raw_projection = result.metadata.get("measurement_projection")
    if raw_projection is None:
        raise ValueError("ResultIR does not contain measurement_projection metadata.")
    if not isinstance(raw_projection, dict):
        raise TypeError("measurement_projection metadata must be a dictionary.")
    data = dict(raw_projection)
    data["projection_id"] = projection_id or f"projection.{result.result_id}"
    data["result_id"] = result.result_id
    data["program_hash"] = result.program_hash
    data["metadata"] = {
        "source": "ResultIR.metadata.measurement_projection",
        "reader": "read_digital_measurement_projection",
        "top_level_counts_preserved": True,
        "top_level_samples_preserved": True,
        "metadata_only": True,
        "result_target_id": result.target_id,
        "result_shots": result.shots,
    }
    return DigitalMeasurementProjectionIR.from_dict(data)


@dataclass(frozen=True)
class DigitalMeasurementProjectionSummaryIR(IRMixin):
    """Stable summary of digital measurement projection evidence."""

    summary_id: str
    result_id: str
    program_hash: str
    register_count: int
    register_keys: tuple[str, ...]
    target_bit_indices_by_key: dict[str, tuple[int, ...]]
    probability_mass_by_key: dict[str, float]
    sample_count_by_key: dict[str, int]
    duplicate_keys: tuple[str, ...] = ()
    repeated_targets: tuple[str, ...] = ()
    uncovered_qubits: tuple[str, ...] = ()
    bitstring_index: str = "left_to_right_matches_qubit_order"
    top_level_counts_preserved: bool = True
    top_level_samples_preserved: bool = True
    metadata_only: bool = True
    hardware_execution: bool = False
    cloud_execution: bool = False
    full_openqasm_supported: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize summary payload and enforce local projection boundaries."""
        if not self.summary_id:
            raise ValueError("summary_id is required.")
        if not self.metadata_only:
            raise ValueError("Projection summary must be metadata-only.")
        if not self.top_level_counts_preserved:
            raise ValueError("Projection summary must preserve top-level counts.")
        if not self.top_level_samples_preserved:
            raise ValueError("Projection summary must preserve top-level samples.")
        if self.hardware_execution:
            raise ValueError("Projection summary must not claim hardware execution.")
        if self.cloud_execution:
            raise ValueError("Projection summary must not claim cloud execution.")
        if self.full_openqasm_supported:
            raise ValueError(
                "Projection summary must not claim full OpenQASM support."
            )
        object.__setattr__(
            self,
            "register_keys",
            tuple(str(key) for key in self.register_keys),
        )
        object.__setattr__(
            self,
            "target_bit_indices_by_key",
            {
                str(key): tuple(int(index) for index in value)
                for key, value in self.target_bit_indices_by_key.items()
            },
        )
        object.__setattr__(
            self,
            "probability_mass_by_key",
            {
                str(key): float(value)
                for key, value in self.probability_mass_by_key.items()
            },
        )
        object.__setattr__(
            self,
            "sample_count_by_key",
            {str(key): int(value) for key, value in self.sample_count_by_key.items()},
        )
        object.__setattr__(
            self,
            "duplicate_keys",
            tuple(str(item) for item in self.duplicate_keys),
        )
        object.__setattr__(
            self,
            "repeated_targets",
            tuple(str(item) for item in self.repeated_targets),
        )
        object.__setattr__(
            self,
            "uncovered_qubits",
            tuple(str(item) for item in self.uncovered_qubits),
        )
        object.__setattr__(self, "metadata", canonicalize(self.metadata))

    @property
    def has_ambiguous_keys(self) -> bool:
        """Whether duplicate measurement keys make key lookup ambiguous."""
        return bool(self.duplicate_keys)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DigitalMeasurementProjectionSummaryIR:
        """Build a projection summary from a dictionary."""
        if not isinstance(data, dict):
            raise TypeError("digital measurement projection summary must be a dict.")
        return cls(
            summary_id=str(data["summary_id"]),
            result_id=str(data["result_id"]),
            program_hash=str(data["program_hash"]),
            register_count=int(data["register_count"]),
            register_keys=tuple(str(key) for key in data.get("register_keys", ())),
            target_bit_indices_by_key={
                str(key): tuple(int(index) for index in value)
                for key, value in dict(
                    data.get("target_bit_indices_by_key", {})
                ).items()
            },
            probability_mass_by_key={
                str(key): float(value)
                for key, value in dict(data.get("probability_mass_by_key", {})).items()
            },
            sample_count_by_key={
                str(key): int(value)
                for key, value in dict(data.get("sample_count_by_key", {})).items()
            },
            duplicate_keys=tuple(str(item) for item in data.get("duplicate_keys", ())),
            repeated_targets=tuple(
                str(item) for item in data.get("repeated_targets", ())
            ),
            uncovered_qubits=tuple(
                str(item) for item in data.get("uncovered_qubits", ())
            ),
            bitstring_index=str(
                data.get("bitstring_index", "left_to_right_matches_qubit_order")
            ),
            top_level_counts_preserved=bool(
                data.get("top_level_counts_preserved", True)
            ),
            top_level_samples_preserved=bool(
                data.get("top_level_samples_preserved", True)
            ),
            metadata_only=bool(data.get("metadata_only", True)),
            hardware_execution=bool(data.get("hardware_execution", False)),
            cloud_execution=bool(data.get("cloud_execution", False)),
            full_openqasm_supported=bool(
                data.get("full_openqasm_supported", False)
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> DigitalMeasurementProjectionSummaryIR:
        """Build a projection summary from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError(
                "DigitalMeasurementProjectionSummaryIR JSON must contain an object."
            )
        return cls.from_dict(data)


def build_digital_measurement_projection_summary(
    result: ResultIR,
    *,
    summary_id: str | None = None,
) -> DigitalMeasurementProjectionSummaryIR:
    """Build a stable read-only summary for measurement projection evidence."""
    projection = read_digital_measurement_projection(result)
    target_bit_indices_by_key: dict[str, tuple[int, ...]] = {}
    probability_mass_by_key: dict[str, float] = {}
    sample_count_by_key: dict[str, int] = {}
    for register in projection.registers:
        target_bit_indices_by_key[register.key] = register.target_bit_indices
        probability_mass_by_key[register.key] = sum(register.probabilities.values())
        sample_count_by_key[register.key] = len(register.samples)
    return DigitalMeasurementProjectionSummaryIR(
        summary_id=summary_id or f"projection_summary.{result.result_id}",
        result_id=result.result_id,
        program_hash=result.program_hash,
        register_count=len(projection.registers),
        register_keys=projection.register_keys,
        target_bit_indices_by_key=target_bit_indices_by_key,
        probability_mass_by_key=probability_mass_by_key,
        sample_count_by_key=sample_count_by_key,
        duplicate_keys=projection.duplicate_keys,
        repeated_targets=projection.repeated_targets,
        uncovered_qubits=projection.uncovered_qubits,
        bitstring_index=(
            projection.registers[0].bitstring_index
            if projection.registers
            else "left_to_right_matches_qubit_order"
        ),
        metadata={
            "source": "DigitalMeasurementProjectionIR",
            "projection_id": projection.projection_id,
            "top_level_counts_preserved": True,
            "top_level_samples_preserved": True,
            "counts_are_full_bitstrings": projection.counts_are_full_bitstrings,
            "samples_are_full_bitstrings": projection.samples_are_full_bitstrings,
            "measurement_mapping": projection.measurement_mapping,
            "metadata_only": True,
            "hanyuan_live_digital_execution": projection.hanyuan_live_digital_execution,
        },
    )
