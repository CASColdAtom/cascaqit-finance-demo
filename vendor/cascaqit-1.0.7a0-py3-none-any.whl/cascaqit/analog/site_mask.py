"""User-facing constant and piecewise-constant Analog site masks."""

from __future__ import annotations

import json
import math
from bisect import bisect_right
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from typing import Any, Literal

from cascaqit.native_ir.base import IRMixin
from cascaqit.parameters.canonical import Parameter

__all__ = ["SiteMask"]


@dataclass(frozen=True)
class SiteMask(IRMixin):
    """A binary site selection that changes at explicit frame boundaries."""

    duration: float
    times: tuple[float, ...]
    active_site_ids: tuple[tuple[str, ...], ...]
    time_unit: str = "us"
    interpolation: Literal["step"] = "step"

    def __post_init__(self) -> None:
        duration = _finite_real(self.duration, "duration")
        if duration <= 0.0:
            raise ValueError("duration must be positive.")
        if not isinstance(self.times, tuple):
            raise TypeError("times must be a tuple.")
        if not self.times:
            raise ValueError("times must not be empty.")
        times = tuple(_finite_real(value, "times") for value in self.times)
        if times[0] != 0.0:
            raise ValueError("times must start at 0.0.")
        if any(right <= left for left, right in zip(times, times[1:])):
            raise ValueError("times must be strictly increasing.")
        if any(value >= duration for value in times):
            raise ValueError("frame times must be less than duration.")

        if not isinstance(self.active_site_ids, tuple):
            raise TypeError("active_site_ids must be a tuple.")
        if len(self.active_site_ids) != len(times):
            raise ValueError("active_site_ids must contain one frame per time.")
        normalized_frames: list[tuple[str, ...]] = []
        for frame in self.active_site_ids:
            if not isinstance(frame, tuple):
                raise TypeError("each active_site_ids frame must be a tuple.")
            if any(
                not isinstance(site_id, str) or not site_id.strip()
                for site_id in frame
            ):
                raise ValueError(
                    "active_site_ids frames must contain non-empty strings."
                )
            if len(set(frame)) != len(frame):
                raise ValueError("active_site_ids within each frame must be unique.")
            normalized_frames.append(tuple(sorted(frame)))
        if not any(normalized_frames):
            raise ValueError("site mask must contain at least one active site.")
        if self.time_unit != "us":
            raise ValueError("time_unit must be 'us'.")
        if self.interpolation != "step":
            raise ValueError("interpolation must be 'step'.")

        object.__setattr__(self, "duration", duration)
        object.__setattr__(self, "times", times)
        object.__setattr__(self, "active_site_ids", tuple(normalized_frames))

    @classmethod
    def constant(
        cls,
        site_ids: Iterable[str],
        *,
        duration: float,
    ) -> SiteMask:
        """Create one binary frame that remains active for the full duration."""
        return cls(
            duration=duration,
            times=(0.0,),
            active_site_ids=(_snapshot_site_ids(site_ids),),
        )

    @classmethod
    def piecewise(
        cls,
        *,
        duration: float,
        frames: Iterable[tuple[float, Iterable[str]]],
    ) -> SiteMask:
        """Create step frames from ``(start_time, active_sites)`` pairs."""
        if isinstance(frames, (str, bytes)) or not isinstance(frames, Iterable):
            raise TypeError("frames must be an iterable of frame pairs.")
        times: list[float] = []
        active_site_ids: list[tuple[str, ...]] = []
        for frame in frames:
            if not isinstance(frame, (tuple, list)) or len(frame) != 2:
                raise TypeError("each frame must be a pair of time and site ids.")
            time, site_ids = frame
            times.append(time)
            active_site_ids.append(_snapshot_site_ids(site_ids, allow_empty=True))
        return cls(
            duration=duration,
            times=tuple(times),
            active_site_ids=tuple(active_site_ids),
        )

    @property
    def frame_count(self) -> int:
        """Return the number of step frames."""
        return len(self.times)

    @property
    def is_dynamic(self) -> bool:
        """Return whether the selection changes after time zero."""
        return self.frame_count > 1

    @property
    def is_bound(self) -> bool:
        """Return true because frame time and topology are numeric in A24."""
        return True

    @property
    def referenced_parameter_names(self) -> tuple[str, ...]:
        """Return no parameter dependencies for numeric frame declarations."""
        return ()

    def validate_parameter_references(
        self,
        declarations: Mapping[str, Parameter],
    ) -> None:
        """Participate in the shared addressing contract without parameters."""
        del declarations

    def bind(self, values: Mapping[str, float]) -> SiteMask:
        """Return this immutable mask because A24 frame values are numeric."""
        del values
        return self

    def active_sites_at(self, time: float) -> tuple[str, ...]:
        """Return the active sites at one time using left-closed step frames."""
        sample = _sample_time(time, duration=self.duration)
        return self.active_site_ids[bisect_right(self.times, sample) - 1]

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SiteMask:
        """Restore a mask from a JSON-compatible dictionary."""
        if not isinstance(data, dict):
            raise TypeError("SiteMask data must be a dictionary.")
        times = data["times"]
        active_site_ids = data["active_site_ids"]
        if not isinstance(times, (list, tuple)):
            raise TypeError("times must be a JSON array.")
        if not isinstance(active_site_ids, (list, tuple)):
            raise TypeError("active_site_ids must be a JSON array.")
        if any(not isinstance(frame, (list, tuple)) for frame in active_site_ids):
            raise TypeError("active_site_ids frames must be JSON arrays.")
        return cls(
            duration=data["duration"],
            times=tuple(times),
            active_site_ids=tuple(tuple(frame) for frame in active_site_ids),
            time_unit=str(data.get("time_unit", "us")),
            interpolation=data.get("interpolation", "step"),
        )

    @classmethod
    def from_json(cls, text: str) -> SiteMask:
        """Restore a mask from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("SiteMask JSON must contain an object.")
        return cls.from_dict(data)


def _snapshot_site_ids(
    site_ids: Iterable[str],
    *,
    allow_empty: bool = False,
) -> tuple[str, ...]:
    if isinstance(site_ids, (str, bytes)) or not isinstance(site_ids, Iterable):
        raise TypeError("site_ids must be an iterable of site ids, not a string.")
    snapshot = tuple(site_ids)
    if not allow_empty and not snapshot:
        raise ValueError("site_ids must not be empty.")
    return snapshot


def _finite_real(value: object, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{name} must be a real number, not bool.")
    result = float(value)
    if not math.isfinite(result):
        raise ValueError(f"{name} must be finite.")
    return result


def _sample_time(value: object, *, duration: float) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError("time must be a real number, not bool.")
    sample = float(value)
    if not math.isfinite(sample) or not 0.0 <= sample <= duration:
        raise ValueError(f"time must be finite and in [0.0, {duration}].")
    return sample
