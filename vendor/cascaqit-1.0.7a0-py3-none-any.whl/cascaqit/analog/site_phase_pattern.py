"""Register-aligned local phase offsets for Analog Rabi control."""

from __future__ import annotations

import math
from collections.abc import Mapping
from dataclasses import dataclass
from typing import NoReturn, Union, cast

from cascaqit.native_ir import SitePhasePatternIR
from cascaqit.parameters.canonical import Expression, Parameter

__all__ = ["SitePhasePattern"]

AnalogSitePhase = Union[int, float, Parameter, Expression]


@dataclass(frozen=True)
class SitePhasePattern:
    """Immutable per-site phase offsets with deferred canonical binding."""

    site_ids: tuple[str, ...]
    offsets: tuple[AnalogSitePhase, ...]
    unit: str = "rad"

    def __post_init__(self) -> None:
        if not isinstance(self.site_ids, tuple):
            raise TypeError("site_ids must be a tuple.")
        if not self.site_ids:
            raise ValueError("site_ids must not be empty.")
        if any(
            not isinstance(site_id, str) or not site_id.strip()
            for site_id in self.site_ids
        ):
            raise ValueError("site_ids must contain non-empty strings.")
        if len(set(self.site_ids)) != len(self.site_ids):
            raise ValueError("site_ids must be unique.")
        if not isinstance(self.offsets, tuple):
            raise TypeError("offsets must be a tuple.")
        if len(self.offsets) != len(self.site_ids):
            raise ValueError("site_ids and offsets must have the same length.")
        if self.unit != "rad":
            raise ValueError("unit must be 'rad'.")

        normalized = tuple(_normalize_offset(value) for value in self.offsets)
        object.__setattr__(self, "offsets", normalized)
        if all(isinstance(value, float) for value in normalized):
            numeric_offsets = cast(tuple[float, ...], normalized)
            validated = SitePhasePatternIR(
                site_ids=self.site_ids,
                offsets=numeric_offsets,
            )
            object.__setattr__(self, "site_ids", validated.site_ids)
            object.__setattr__(self, "offsets", validated.offsets)

    @classmethod
    def from_mapping(
        cls,
        offsets: Mapping[str, AnalogSitePhase],
    ) -> SitePhasePattern:
        """Snapshot a mapping into deterministic site-id order."""
        if not isinstance(offsets, Mapping):
            raise TypeError("offsets must be a mapping from site id to phase.")
        items = tuple(offsets.items())
        if any(not isinstance(site_id, str) for site_id, _ in items):
            raise TypeError("site phase mapping keys must be strings.")
        ordered = tuple(sorted(items, key=lambda item: item[0]))
        return cls(
            site_ids=tuple(site_id for site_id, _ in ordered),
            offsets=tuple(value for _, value in ordered),
        )

    @classmethod
    def zeros(cls, site_ids: tuple[str, ...]) -> SitePhasePattern:
        """Create explicit zero offsets for a known register order."""
        return cls(site_ids=site_ids, offsets=(0.0,) * len(site_ids))

    @property
    def is_bound(self) -> bool:
        """Return whether every offset can cross the numeric IR boundary."""
        return all(isinstance(value, float) for value in self.offsets)

    @property
    def referenced_parameter_names(self) -> tuple[str, ...]:
        """Return unique canonical dependencies in stable order."""
        names: set[str] = set()
        for value in self.offsets:
            if isinstance(value, Parameter):
                names.add(value.name)
            elif isinstance(value, Expression):
                names.update(value.dependencies)
        return tuple(sorted(names))

    def validate_parameter_references(
        self,
        declarations: Mapping[str, Parameter],
    ) -> None:
        """Require program-owned radian parameters and expressions."""
        for value in self.offsets:
            if isinstance(value, Parameter):
                if declarations.get(value.name) is not value:
                    _raise_phase_pattern_error(
                        f"Site phase parameter '{value.name}' is not owned by this "
                        "program.",
                        code="AHS_SITE_PHASE_PARAMETER_FOREIGN",
                        parameter_name=value.name,
                    )
                if value.unit != "rad":
                    _raise_unit_mismatch(value.name, value.unit)
            elif isinstance(value, Expression):
                if value.unit != "rad":
                    _raise_unit_mismatch("expression", value.unit)
                for name in value.dependencies:
                    declaration = declarations.get(name)
                    if declaration is None:
                        _raise_phase_pattern_error(
                            f"Site phase expression references undeclared parameter "
                            f"'{name}'.",
                            code="AHS_SITE_PHASE_PARAMETER_UNKNOWN",
                            parameter_name=name,
                        )
                    if declaration.unit != "rad":
                        _raise_unit_mismatch(name, declaration.unit)

    def bind(self, values: Mapping[str, float]) -> SitePhasePattern:
        """Return an independent pattern whose offsets are numeric."""
        return SitePhasePattern(
            site_ids=self.site_ids,
            offsets=tuple(_resolve_offset(value, values) for value in self.offsets),
        )

    def to_ir(self) -> SitePhasePatternIR:
        """Return numeric Native IR, rejecting unresolved declaration values."""
        if not self.is_bound:
            _raise_phase_pattern_error(
                "Site phase parameters must be bound before IR export.",
                code="AHS_SITE_PHASE_PARAMETERS_UNBOUND",
                metadata={
                    "parameter_names": list(self.referenced_parameter_names),
                },
            )
        numeric_offsets = cast(tuple[float, ...], self.offsets)
        return SitePhasePatternIR(
            site_ids=self.site_ids,
            offsets=numeric_offsets,
        )


def _normalize_offset(value: AnalogSitePhase) -> AnalogSitePhase:
    if isinstance(value, (Parameter, Expression)):
        return value
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(
            "site phase offset must be a real number, Parameter, or Expression."
        )
    normalized = float(value)
    if not math.isfinite(normalized):
        raise ValueError("site phase offsets must be finite.")
    return normalized


def _resolve_offset(
    value: AnalogSitePhase,
    values: Mapping[str, float],
) -> AnalogSitePhase:
    if isinstance(value, Parameter):
        return value.evaluate(values)
    if isinstance(value, Expression):
        return value.evaluate(values)
    return value


def _raise_unit_mismatch(name: str, actual_unit: str | None) -> NoReturn:
    _raise_phase_pattern_error(
        f"Site phase parameter '{name}' must use radians.",
        code="AHS_SITE_PHASE_PARAMETER_UNIT_MISMATCH",
        parameter_name=name,
        metadata={"actual_unit": actual_unit, "expected_unit": "rad"},
    )


def _raise_phase_pattern_error(
    message: str,
    *,
    code: str,
    parameter_name: str | None = None,
    metadata: dict[str, object] | None = None,
) -> NoReturn:
    from cascaqit.exceptions import ProgramValidationError

    raise ProgramValidationError(
        message,
        code=code,
        object_path="site_phase_pattern.offsets",
        suggestion=(
            "Use rad parameters declared by this AHSProgram, then bind every "
            "offset before exporting IR."
        ),
        metadata={
            **({} if parameter_name is None else {"parameter_name": parameter_name}),
            **({} if metadata is None else metadata),
        },
    )
