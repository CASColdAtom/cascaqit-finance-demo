"""User-facing AHS program builder."""

from __future__ import annotations

import math
from collections.abc import Mapping
from dataclasses import dataclass
from typing import TYPE_CHECKING, NoReturn, Union

from cascaqit.analog.register import AtomRegister
from cascaqit.analog.site_mask import SiteMask
from cascaqit.analog.site_pattern import SitePattern
from cascaqit.analog.site_phase_pattern import SitePhasePattern
from cascaqit.analog.waveform import Waveform
from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.discretization import DiscretizationPolicy, DiscretizationReport
from cascaqit.discretization import discretize_program as discretize_program_ir
from cascaqit.exceptions import ProgramValidationError
from cascaqit.native_ir.models import (
    HamiltonianIR,
    LocalDetuningIR,
    LocalRabiIR,
    MeasurementIR,
    ProgramIR,
    SiteAddressingIR,
    SitePhasePatternIR,
    WaveformIR,
)
from cascaqit.parameters.canonical import Expression, Parameter
from cascaqit.parameters.ir import ParameterSchemaIR
from cascaqit.targets import TargetSpec
from cascaqit.validation import validate_program

if TYPE_CHECKING:
    from cascaqit.results import ResultIR

__all__ = ["AHSProgram", "DiscretizedAHSProgram", "ValidatedAHSProgram"]

AnalogPhaseValue = Union[int, float, Parameter, Expression, Waveform]
SiteAddressing = Union[SitePattern, SiteMask]


@dataclass(frozen=True)
class ValidatedAHSProgram:
    """A validated ProgramIR plus diagnostics."""

    program_ir: ProgramIR
    diagnostics: tuple[DiagnosticsIR, ...]

    def discretize(
        self,
        target: TargetSpec,
        *,
        policy: DiscretizationPolicy = "nearest",
    ) -> tuple[DiscretizedAHSProgram, DiscretizationReport]:
        """Discretize the validated program for a target."""
        discretized_ir, report = discretize_program_ir(
            self.program_ir,
            target,
            policy=policy,
        )
        return DiscretizedAHSProgram(discretized_ir), report


@dataclass(frozen=True)
class DiscretizedAHSProgram:
    """A discretized ProgramIR wrapper."""

    program_ir: ProgramIR


@dataclass(frozen=True)
class _DriveTemplate:
    rabi: Waveform
    detuning: Waveform
    phase: AnalogPhaseValue


@dataclass(frozen=True)
class _LocalDetuningTemplate:
    waveform: Waveform
    pattern: SiteAddressing


@dataclass(frozen=True)
class _LocalRabiTemplate:
    rabi: Waveform
    phase: AnalogPhaseValue
    pattern: SiteAddressing
    phase_pattern: SitePhasePattern | None


class AHSProgram:
    """Mutable builder for a global drive and ordered addressed controls."""

    def __init__(
        self,
        register: AtomRegister,
        *,
        program_id: str = "program",
    ) -> None:
        self._register = register
        self._program_id = program_id
        self._drive: _DriveTemplate | None = None
        self._local_detuning_terms: list[_LocalDetuningTemplate] = []
        self._local_rabi_terms: list[_LocalRabiTemplate] = []
        self._measurements: list[MeasurementIR] = []
        self._parameters: list[Parameter] = []
        self._resolved_values: dict[str, float] = {}
        self._lifecycle_state = "draft"

    @property
    def parameters(self) -> tuple[Parameter, ...]:
        """Return declarations in stable declaration order."""
        return tuple(self._parameters)

    @property
    def is_bound(self) -> bool:
        """Return whether every control value can lower to numeric IR."""
        local_bound = all(
            term.waveform.is_bound and term.pattern.is_bound
            for term in self._local_detuning_terms
        )
        local_rabi_bound = all(
            term.rabi.is_bound
            and _phase_is_bound(term.phase)
            and term.pattern.is_bound
            and (term.phase_pattern is None or term.phase_pattern.is_bound)
            for term in self._local_rabi_terms
        )
        if self._drive is None:
            return local_bound and local_rabi_bound
        phase = self._drive.phase
        return (
            local_bound
            and local_rabi_bound
            and self._drive.rabi.is_bound
            and self._drive.detuning.is_bound
            and (
                phase.is_bound
                if isinstance(phase, Waveform)
                else not isinstance(phase, (Parameter, Expression))
            )
        )

    def drive(
        self,
        *,
        rabi: Waveform,
        detuning: Waveform,
        phase: AnalogPhaseValue,
    ) -> AHSProgram:
        """Set the global Rabi, detuning, and phase terms."""
        if not isinstance(rabi, Waveform) or not isinstance(detuning, Waveform):
            raise TypeError("rabi and detuning must be Waveform values.")
        declarations = {parameter.name: parameter for parameter in self._parameters}
        rabi.validate_parameter_references(declarations)
        detuning.validate_parameter_references(declarations)
        _validate_phase(phase, declarations)
        self._drive = _DriveTemplate(rabi=rabi, detuning=detuning, phase=phase)
        return self

    def local_detuning(
        self,
        *,
        waveform: Waveform,
        pattern: SiteAddressing,
    ) -> AHSProgram:
        """Append a local detuning waveform in deterministic declaration order."""
        if not isinstance(waveform, Waveform):
            raise TypeError("waveform must be Waveform.")
        if not isinstance(pattern, (SitePattern, SiteMask)):
            raise TypeError("pattern must be SitePattern or SiteMask.")
        declarations = {parameter.name: parameter for parameter in self._parameters}
        waveform.validate_parameter_references(declarations)
        pattern.validate_parameter_references(declarations)
        self._local_detuning_terms.append(
            _LocalDetuningTemplate(waveform=waveform, pattern=pattern)
        )
        return self

    def local_rabi(
        self,
        *,
        rabi: Waveform,
        phase: AnalogPhaseValue,
        pattern: SiteAddressing,
        phase_pattern: SitePhasePattern | None = None,
    ) -> AHSProgram:
        """Append an addressed Rabi drive in deterministic declaration order."""
        if not isinstance(rabi, Waveform):
            raise TypeError("rabi must be Waveform.")
        if not isinstance(pattern, (SitePattern, SiteMask)):
            raise TypeError("pattern must be SitePattern or SiteMask.")
        if phase_pattern is not None and not isinstance(
            phase_pattern,
            SitePhasePattern,
        ):
            raise TypeError("phase_pattern must be SitePhasePattern or None.")
        declarations = {parameter.name: parameter for parameter in self._parameters}
        rabi.validate_parameter_references(declarations)
        _validate_phase(phase, declarations)
        pattern.validate_parameter_references(declarations)
        if phase_pattern is not None:
            phase_pattern.validate_parameter_references(declarations)
        self._local_rabi_terms.append(
            _LocalRabiTemplate(
                rabi=rabi,
                phase=phase,
                pattern=pattern,
                phase_pattern=phase_pattern,
            )
        )
        return self

    def parameter(
        self,
        name: str,
        *,
        unit: str | None = "rad/us",
        lower_bound: float | None = None,
        upper_bound: float | None = None,
        default: float | None = None,
    ) -> Parameter:
        """Declare one float parameter owned by this program."""
        if any(parameter.name == name for parameter in self._parameters):
            _raise_program_error(
                f"Analog parameter '{name}' is already declared.",
                code="AHS_PROGRAM_PARAMETER_DUPLICATE",
                object_path=f"program.parameters.{name}",
                suggestion="Use the existing parameter or choose a unique name.",
                metadata={"parameter_name": name},
            )
        try:
            if unit not in {"rad/us", "rad", None}:
                raise ValueError(
                    "Analog parameter unit must be 'rad/us', 'rad', or None."
                )
            parameter = Parameter(
                name=name,
                unit=unit,
                lower_bound=lower_bound,
                upper_bound=upper_bound,
                default=default,
            )
        except (TypeError, ValueError) as exc:
            _raise_program_error(
                f"Analog parameter '{name}' is invalid: {exc}",
                code="AHS_PROGRAM_PARAMETER_DECLARATION_INVALID",
                object_path=f"program.parameters.{name}",
                suggestion="Use a unique name, supported unit, and finite bounds.",
                metadata={"parameter_name": str(name)},
            )
        self._parameters.append(parameter)
        return parameter

    def bind(self, values: Mapping[str, float]) -> AHSProgram:
        """Return an independent program with every control value resolved."""
        if not isinstance(values, Mapping):
            _raise_program_error(
                "Analog parameter bindings must be a mapping.",
                code="AHS_PROGRAM_BIND_VALUES_INVALID",
                object_path="program.parameters",
                suggestion="Pass a mapping such as {'omega': 2.0}.",
            )
        provided = {str(name): value for name, value in values.items()}
        declarations = {parameter.name: parameter for parameter in self._parameters}
        unknown = tuple(sorted(set(provided) - set(declarations)))
        if unknown:
            _raise_program_error(
                "Unknown Analog parameter bindings: " + ", ".join(unknown),
                code="AHS_PROGRAM_BIND_UNKNOWN",
                object_path="program.parameters",
                suggestion="Remove unknown values or declare those parameters.",
                metadata={"unknown_parameters": list(unknown)},
            )
        referenced = self._referenced_parameter_names()
        missing = tuple(
            name
            for name in referenced
            if name not in provided and declarations[name].default is None
        )
        if missing:
            _raise_program_error(
                "Missing Analog parameter bindings: " + ", ".join(missing),
                code="AHS_PROGRAM_BIND_MISSING",
                object_path="program.parameters",
                suggestion="Bind every referenced parameter without a default.",
                metadata={"missing_parameters": list(missing)},
            )
        resolved: dict[str, float] = {}
        for name in sorted(set(provided) | set(referenced)):
            try:
                resolved[name] = declarations[name].evaluate(provided)
            except (TypeError, ValueError) as exc:
                _raise_program_error(
                    f"Analog parameter '{name}' is invalid: {exc}",
                    code="AHS_PROGRAM_BIND_VALUE_INVALID",
                    object_path=f"program.parameters.{name}",
                    suggestion="Pass a finite value within the declared bounds.",
                    metadata={"parameter_name": name},
                )
        bound = AHSProgram(self._register, program_id=self._program_id)
        bound._parameters = list(self._parameters)
        bound._measurements = list(self._measurements)
        bound._resolved_values = resolved
        bound._lifecycle_state = "bound"
        if self._drive is not None:
            try:
                phase = _bind_phase(self._drive.phase, resolved)
                bound._drive = _DriveTemplate(
                    rabi=self._drive.rabi.bind(resolved),
                    detuning=self._drive.detuning.bind(resolved),
                    phase=phase,
                )
            except (ArithmeticError, KeyError, TypeError, ValueError) as exc:
                _raise_program_error(
                    f"Analog parameter expression evaluation failed: {exc}",
                    code="AHS_PROGRAM_BIND_EVALUATION_FAILED",
                    object_path="program.hamiltonian",
                    suggestion="Fix the expression or binding values and try again.",
                )
        try:
            bound._local_detuning_terms = [
                _LocalDetuningTemplate(
                    waveform=term.waveform.bind(resolved),
                    pattern=term.pattern.bind(resolved),
                )
                for term in self._local_detuning_terms
            ]
        except (ArithmeticError, KeyError, TypeError, ValueError) as exc:
            _raise_program_error(
                f"Analog parameter expression evaluation failed: {exc}",
                code="AHS_PROGRAM_BIND_EVALUATION_FAILED",
                object_path="program.hamiltonian.local_detuning_terms",
                suggestion="Fix the expression or binding values and try again.",
            )
        try:
            bound._local_rabi_terms = [
                _LocalRabiTemplate(
                    rabi=term.rabi.bind(resolved),
                    phase=_bind_phase(term.phase, resolved),
                    pattern=term.pattern.bind(resolved),
                    phase_pattern=(
                        None
                        if term.phase_pattern is None
                        else term.phase_pattern.bind(resolved)
                    ),
                )
                for term in self._local_rabi_terms
            ]
        except (ArithmeticError, KeyError, TypeError, ValueError) as exc:
            _raise_program_error(
                f"Analog parameter expression evaluation failed: {exc}",
                code="AHS_PROGRAM_BIND_EVALUATION_FAILED",
                object_path="program.hamiltonian.local_rabi_terms",
                suggestion="Fix the expression or binding values and try again.",
            )
        return bound

    def measure(
        self,
        *,
        basis: str = "ground_rydberg",
        measurement_id: str = "m0",
    ) -> AHSProgram:
        """Append a terminal measurement."""
        self._measurements.append(
            MeasurementIR(measurement_id=measurement_id, basis=basis)
        )
        return self

    def to_ir(self) -> ProgramIR:
        """Build numeric ProgramIR from a static or bound program."""
        return self._build_ir(require_measurement=True)

    def _to_hybrid_block_ir(self) -> ProgramIR:
        """Build an Analog block IR closed by Hybrid's terminal measurement."""
        # A HybridProgram owns the only terminal measurement. The Hamiltonian,
        # parameter, and numeric lowering path remains identical to standalone
        # AHS; only the standalone completeness check differs.
        return self._build_ir(require_measurement=False)

    def _build_ir(self, *, require_measurement: bool) -> ProgramIR:
        """Build the shared numeric IR for standalone or Hybrid ownership."""
        self._require_complete(require_measurement=require_measurement)
        assert self._drive is not None
        legacy_draft = not self.is_bound and self._is_legacy_draft()
        if not self.is_bound and not legacy_draft:
            _raise_program_error(
                "Analog program parameters must be bound before IR export.",
                code="AHS_PROGRAM_PARAMETERS_UNBOUND",
                object_path="program.parameters",
                suggestion="Call program.bind({...}) with every required value.",
                metadata={"parameter_names": list(self._referenced_parameter_names())},
            )
        phase = self._drive.phase
        numeric_phase = _phase_ir(phase, legacy_draft=legacy_draft)
        local_detuning_terms = tuple(
            self._local_detuning_ir(
                template,
                index=index,
                legacy_draft=legacy_draft,
            )
            for index, template in enumerate(self._local_detuning_terms)
        )
        local_rabi_terms = tuple(
            self._local_rabi_ir(
                template,
                index=index,
                legacy_draft=legacy_draft,
            )
            for index, template in enumerate(self._local_rabi_terms)
        )
        return ProgramIR(
            program_id=self._program_id,
            register=self._register.to_ir(),
            hamiltonian=HamiltonianIR(
                rabi=(
                    self._drive.rabi._to_declaration_ir()
                    if legacy_draft
                    else self._drive.rabi.to_ir()
                ),
                detuning=(
                    self._drive.detuning._to_declaration_ir()
                    if legacy_draft
                    else self._drive.detuning.to_ir()
                ),
                phase=numeric_phase,
                local_detuning_terms=local_detuning_terms,
                local_rabi_terms=local_rabi_terms,
            ),
            measurements=tuple(self._measurements),
            lifecycle_state=self._lifecycle_state,  # type: ignore[arg-type]
            parameters=dict(self._resolved_values),
            parameter_schema=_parameter_schema(self._parameters),
        )

    def bind_parameters(self, values: Mapping[str, float]) -> ProgramIR:
        """Strict compatibility entry returning a bound numeric ProgramIR."""
        return self.bind(values).to_ir()

    def validate(
        self,
        target: TargetSpec,
        *,
        shots: int,
    ) -> ValidatedAHSProgram:
        """Validate the numeric program against a target."""
        program_ir = self.to_ir()
        return ValidatedAHSProgram(
            program_ir=program_ir,
            diagnostics=validate_program(program_ir, target, shots=shots),
        )

    def run(
        self,
        *,
        shots: int = 1000,
        seed: int | None = None,
        target: TargetSpec | None = None,
        time_steps: int = 400,
        return_probabilities: bool = True,
    ) -> ResultIR:
        """Run this program through the offline local AHS simulator."""
        from cascaqit.native_ir.models import SimulatorConfigIR
        from cascaqit.simulators.local_ahs import LocalAhsSimulator

        if target is not None and not isinstance(target, TargetSpec):
            raise TypeError("target must be TargetSpec or None.")
        return LocalAhsSimulator(
            target=target,
            seed=seed,
            time_steps=time_steps,
        ).run(
            self.to_ir(),
            config=SimulatorConfigIR(
                shots=shots,
                seed=seed,
                return_probabilities=return_probabilities,
            ),
        )

    def _referenced_parameter_names(self) -> tuple[str, ...]:
        names: set[str] = set()
        if self._drive is not None:
            names.update(self._drive.rabi.referenced_parameter_names)
            names.update(self._drive.detuning.referenced_parameter_names)
            phase = self._drive.phase
            if isinstance(phase, Waveform):
                names.update(phase.referenced_parameter_names)
            elif isinstance(phase, Parameter):
                names.add(phase.name)
            elif isinstance(phase, Expression):
                names.update(phase.dependencies)
        for detuning_term in self._local_detuning_terms:
            names.update(detuning_term.waveform.referenced_parameter_names)
            names.update(detuning_term.pattern.referenced_parameter_names)
        for rabi_term in self._local_rabi_terms:
            names.update(rabi_term.rabi.referenced_parameter_names)
            names.update(rabi_term.pattern.referenced_parameter_names)
            if rabi_term.phase_pattern is not None:
                names.update(rabi_term.phase_pattern.referenced_parameter_names)
            phase = rabi_term.phase
            if isinstance(phase, Waveform):
                names.update(phase.referenced_parameter_names)
            elif isinstance(phase, Parameter):
                names.add(phase.name)
            elif isinstance(phase, Expression):
                names.update(phase.dependencies)
        return tuple(sorted(names))

    def _is_legacy_draft(self) -> bool:
        if self._drive is None:
            return False
        # ProgramIR has no symbolic pattern-weight slot. Unlike the legacy
        # waveform reference, an unresolved pattern must never cross into IR.
        if any(
            not term.pattern.is_bound for term in self._local_detuning_terms
        ) or any(
            not term.pattern.is_bound
            or (term.phase_pattern is not None and not term.phase_pattern.is_bound)
            for term in self._local_rabi_terms
        ):
            return False
        waveforms = [self._drive.rabi, self._drive.detuning]
        waveforms.extend(term.waveform for term in self._local_detuning_terms)
        for term in self._local_rabi_terms:
            waveforms.append(term.rabi)
            local_phase = term.phase
            if isinstance(local_phase, Waveform):
                waveforms.append(local_phase)
            elif isinstance(local_phase, (Parameter, Expression)):
                # Legacy draft export can preserve waveform expressions, but
                # ProgramIR has no symbolic scalar phase slot.
                return False
        if any(
            not item.is_bound and not item.is_parameter_reference for item in waveforms
        ):
            return False
        phase = self._drive.phase
        if isinstance(phase, Waveform):
            return phase.is_bound or phase.is_parameter_reference
        return not isinstance(phase, (Parameter, Expression))

    def _local_detuning_ir(
        self,
        template: _LocalDetuningTemplate,
        *,
        index: int,
        legacy_draft: bool,
    ) -> LocalDetuningIR:
        assert self._drive is not None
        path = f"program.hamiltonian.local_detuning_terms[{index}]"
        waveform = template.waveform.waveform_ir
        global_detuning = self._drive.detuning.waveform_ir
        if (
            waveform.value_unit != "rad/us"
            or waveform.value_unit != global_detuning.value_unit
        ):
            _raise_program_error(
                "Local and global detuning value units must both be 'rad/us'.",
                code="AHS_LOCAL_DETUNING_VALUE_UNIT_MISMATCH",
                object_path=f"{path}.waveform.value_unit",
                suggestion="Use value_unit='rad/us' for both detuning waveforms.",
                metadata={
                    "global_value_unit": global_detuning.value_unit,
                    "local_value_unit": waveform.value_unit,
                },
            )
        if (
            waveform.time_unit != "us"
            or waveform.time_unit != global_detuning.time_unit
        ):
            _raise_program_error(
                "Local and global detuning time units must both be 'us'.",
                code="AHS_LOCAL_DETUNING_TIME_UNIT_MISMATCH",
                object_path=f"{path}.waveform.time_unit",
                suggestion="Use time_unit='us' for both detuning waveforms.",
                metadata={
                    "global_time_unit": global_detuning.time_unit,
                    "local_time_unit": waveform.time_unit,
                },
            )
        global_duration = max(
            self._drive.rabi.waveform_ir.duration,
            global_detuning.duration,
        )
        if waveform.duration != global_duration:
            _raise_program_error(
                "Local detuning duration must equal the global program duration.",
                code="AHS_LOCAL_DETUNING_DURATION_MISMATCH",
                object_path=f"{path}.waveform.duration",
                suggestion="Use one duration for the global and local controls.",
                metadata={
                    "global_duration": global_duration,
                    "local_duration": waveform.duration,
                },
            )

        active_site_ids = self._register.to_ir().active_site_ids
        projected_addressing = _project_site_addressing(
            template.pattern,
            active_site_ids,
            duration=global_duration,
            control_label="Local detuning",
            code="AHS_LOCAL_DETUNING_PATTERN_MISMATCH",
            duration_code="AHS_LOCAL_DETUNING_ADDRESSING_DURATION_MISMATCH",
            object_path=f"{path}.pattern",
        )
        return LocalDetuningIR(
            waveform=(
                template.waveform._to_declaration_ir()
                if legacy_draft
                else template.waveform.to_ir()
            ),
            addressing=projected_addressing,
        )

    def _local_rabi_ir(
        self,
        template: _LocalRabiTemplate,
        *,
        index: int,
        legacy_draft: bool,
    ) -> LocalRabiIR:
        assert self._drive is not None
        path = f"program.hamiltonian.local_rabi_terms[{index}]"
        rabi = template.rabi.waveform_ir
        global_rabi = self._drive.rabi.waveform_ir
        if rabi.value_unit != "rad/us" or rabi.value_unit != global_rabi.value_unit:
            _raise_program_error(
                "Local and global Rabi value units must both be 'rad/us'.",
                code="AHS_LOCAL_RABI_VALUE_UNIT_MISMATCH",
                object_path=f"{path}.rabi.value_unit",
                suggestion="Use value_unit='rad/us' for both Rabi waveforms.",
            )
        global_duration = max(
            self._drive.rabi.waveform_ir.duration,
            self._drive.detuning.waveform_ir.duration,
        )
        if rabi.time_unit != "us" or rabi.time_unit != global_rabi.time_unit:
            _raise_program_error(
                "Local and global Rabi time units must both be 'us'.",
                code="AHS_LOCAL_RABI_TIME_UNIT_MISMATCH",
                object_path=f"{path}.rabi.time_unit",
                suggestion="Use time_unit='us' for both Rabi waveforms.",
            )
        if rabi.duration != global_duration:
            _raise_program_error(
                "Local Rabi duration must equal the global program duration.",
                code="AHS_LOCAL_RABI_DURATION_MISMATCH",
                object_path=f"{path}.rabi.duration",
                suggestion="Use one duration for global and local controls.",
            )
        phase_ir = _phase_ir(template.phase, legacy_draft=legacy_draft)
        if isinstance(phase_ir, WaveformIR) and phase_ir.duration != global_duration:
            _raise_program_error(
                "Local Rabi phase duration must equal the global program duration.",
                code="AHS_LOCAL_RABI_PHASE_DURATION_MISMATCH",
                object_path=f"{path}.phase.duration",
                suggestion="Use one duration for Rabi amplitude and phase.",
            )
        active_site_ids = self._register.to_ir().active_site_ids
        projected_addressing = _project_site_addressing(
            template.pattern,
            active_site_ids,
            duration=global_duration,
            control_label="Local Rabi",
            code="AHS_LOCAL_RABI_PATTERN_MISMATCH",
            duration_code="AHS_LOCAL_RABI_ADDRESSING_DURATION_MISMATCH",
            object_path=f"{path}.pattern",
        )
        projected_phase_pattern = _project_site_phase_pattern(
            template.phase_pattern,
            active_site_ids,
            object_path=f"{path}.phase_pattern",
        )
        return LocalRabiIR(
            rabi=(
                template.rabi._to_declaration_ir()
                if legacy_draft
                else template.rabi.to_ir()
            ),
            phase=phase_ir,
            addressing=projected_addressing,
            phase_pattern=projected_phase_pattern,
        )

    def _require_complete(self, *, require_measurement: bool) -> None:
        if self._drive is None:
            _raise_program_error(
                "drive() must be called before to_ir().",
                code="AHS_PROGRAM_DRIVE_MISSING",
                object_path="program.hamiltonian",
                suggestion="Call program.drive(...) before exporting ProgramIR.",
                metadata={"program_id": self._program_id},
            )
        if require_measurement and not self._measurements:
            _raise_program_error(
                "measure() must be called before to_ir().",
                code="AHS_PROGRAM_MEASUREMENT_MISSING",
                object_path="program.measurements",
                suggestion="Call program.measure(...) before exporting ProgramIR.",
                metadata={"program_id": self._program_id},
            )


def _parameter_schema(parameters: list[Parameter]) -> ParameterSchemaIR:
    return ParameterSchemaIR.from_parameters(parameters)


def _project_site_addressing(
    addressing: SiteAddressing,
    active_site_ids: tuple[str, ...],
    *,
    duration: float,
    control_label: str,
    code: str,
    duration_code: str,
    object_path: str,
) -> SiteAddressingIR:
    """Lower every public addressing value into register-aligned step frames."""
    if isinstance(addressing, SiteMask):
        if addressing.duration != duration:
            _raise_program_error(
                f"{control_label} mask duration must match the control duration.",
                code=duration_code,
                object_path=f"{object_path}.duration",
                suggestion=(
                    "Use the same duration for the SiteMask and local control."
                ),
                metadata={
                    "control_duration": duration,
                    "addressing_duration": addressing.duration,
                },
            )
        active = set(active_site_ids)
        extra = tuple(
            sorted(
                {
                    site_id
                    for frame in addressing.active_site_ids
                    for site_id in frame
                    if site_id not in active
                }
            )
        )
        if extra:
            frame_indices = [
                index
                for index, frame in enumerate(addressing.active_site_ids)
                if any(site_id in extra for site_id in frame)
            ]
            _raise_program_error(
                f"{control_label} mask may select only active register sites.",
                code=code,
                object_path=object_path,
                suggestion="Select one or more active site ids from this register.",
                metadata={
                    "missing_site_ids": [],
                    "extra_site_ids": list(extra),
                    "active_site_ids": list(active_site_ids),
                    "frame_indices": frame_indices,
                    "addressing_kind": "site_mask",
                },
            )
        return SiteAddressingIR(
            site_ids=active_site_ids,
            times=addressing.times,
            weights=tuple(
                tuple(
                    1.0 if site_id in set(frame) else 0.0
                    for site_id in active_site_ids
                )
                for frame in addressing.active_site_ids
            ),
            duration=duration,
            source_kind="site_mask",
        )

    numeric_pattern = addressing.to_ir()
    pattern_by_id = dict(zip(numeric_pattern.site_ids, numeric_pattern.weights))
    missing = tuple(sorted(set(active_site_ids) - set(pattern_by_id)))
    extra = tuple(sorted(set(pattern_by_id) - set(active_site_ids)))
    if missing or extra or len(active_site_ids) != len(pattern_by_id):
        _raise_program_error(
            f"{control_label} pattern must cover every active register site exactly.",
            code=code,
            object_path=object_path,
            suggestion="Provide one weight for each filled site and no other sites.",
            metadata={
                "missing_site_ids": list(missing),
                "extra_site_ids": list(extra),
                "active_site_ids": list(active_site_ids),
                "addressing_kind": "site_pattern",
            },
        )
    return SiteAddressingIR(
        site_ids=active_site_ids,
        times=(0.0,),
        weights=(
            tuple(pattern_by_id[site_id] for site_id in active_site_ids),
        ),
        duration=duration,
        source_kind="site_pattern",
    )


def _project_site_phase_pattern(
    pattern: SitePhasePattern | None,
    active_site_ids: tuple[str, ...],
    *,
    object_path: str,
) -> SitePhasePatternIR:
    """Lower optional user offsets into one explicit register-aligned pattern."""
    if pattern is None:
        return SitePhasePatternIR.zeros(active_site_ids)

    numeric_pattern = pattern.to_ir()
    offsets_by_id = dict(zip(numeric_pattern.site_ids, numeric_pattern.offsets))
    missing = tuple(sorted(set(active_site_ids) - set(offsets_by_id)))
    extra = tuple(sorted(set(offsets_by_id) - set(active_site_ids)))
    if missing or extra or len(active_site_ids) != len(offsets_by_id):
        _raise_program_error(
            "Local Rabi phase pattern must cover every active register site exactly.",
            code="AHS_LOCAL_RABI_PHASE_PATTERN_MISMATCH",
            object_path=object_path,
            suggestion="Provide one radian offset for each active site and no others.",
            metadata={
                "missing_site_ids": list(missing),
                "extra_site_ids": list(extra),
                "active_site_ids": list(active_site_ids),
            },
        )
    return SitePhasePatternIR(
        site_ids=active_site_ids,
        offsets=tuple(offsets_by_id[site_id] for site_id in active_site_ids),
    )


def _validate_phase(
    phase: AnalogPhaseValue,
    declarations: Mapping[str, Parameter],
) -> None:
    if isinstance(phase, Waveform):
        phase.validate_parameter_references(declarations)
        if phase.waveform_ir.value_unit != "rad":
            _raise_program_error(
                "Phase waveform value unit must be 'rad'.",
                code="AHS_PROGRAM_PHASE_UNIT_MISMATCH",
                object_path="program.hamiltonian.phase",
                suggestion="Use value_unit='rad' for phase waveforms.",
            )
        return
    if isinstance(phase, Parameter):
        if declarations.get(phase.name) is not phase:
            _raise_foreign_phase(phase.name)
        if phase.unit != "rad":
            _raise_phase_unit(phase.name, phase.unit)
        return
    if isinstance(phase, Expression):
        if phase.unit != "rad":
            _raise_phase_unit("expression", phase.unit)
        for name in phase.dependencies:
            declaration = declarations.get(name)
            if declaration is None or declaration.unit != "rad":
                _raise_foreign_phase(name)
        return
    _finite_float(phase, "phase")


def _bind_phase(
    phase: AnalogPhaseValue,
    values: Mapping[str, float],
) -> Waveform | float:
    if isinstance(phase, Waveform):
        return phase.bind(values)
    if isinstance(phase, Parameter):
        return phase.evaluate(values)
    if isinstance(phase, Expression):
        return phase.evaluate(values)
    return _finite_float(phase, "phase")


def _phase_is_bound(phase: AnalogPhaseValue) -> bool:
    if isinstance(phase, Waveform):
        return phase.is_bound
    return not isinstance(phase, (Parameter, Expression))


def _phase_ir(
    phase: AnalogPhaseValue,
    *,
    legacy_draft: bool,
) -> WaveformIR | float:
    if isinstance(phase, Waveform):
        return phase._to_declaration_ir() if legacy_draft else phase.to_ir()
    return _finite_float(phase, "phase")


def _finite_float(value: object, field_name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{field_name} must be a real number and not bool.")
    normalized = float(value)
    if not math.isfinite(normalized):
        raise ValueError(f"{field_name} must be finite.")
    return normalized


def _raise_foreign_phase(name: str) -> None:
    _raise_program_error(
        f"Phase references undeclared or foreign parameter '{name}'.",
        code="AHS_PROGRAM_PHASE_PARAMETER_FOREIGN",
        object_path="program.hamiltonian.phase",
        suggestion="Use a rad parameter declared by this AHSProgram.",
    )


def _raise_phase_unit(name: str, unit: str | None) -> None:
    _raise_program_error(
        f"Phase parameter '{name}' uses unsupported unit '{unit}'.",
        code="AHS_PROGRAM_PHASE_UNIT_MISMATCH",
        object_path="program.hamiltonian.phase",
        suggestion="Use a parameter with unit='rad'.",
    )


def _raise_bound_value(name: str) -> None:
    _raise_program_error(
        f"Analog parameter '{name}' is outside its bounds.",
        code="AHS_PROGRAM_BIND_VALUE_INVALID",
        object_path=f"program.parameters.{name}",
        suggestion="Pass a finite value within the declared bounds.",
    )


def _raise_program_error(
    message: str,
    *,
    code: str,
    object_path: str,
    suggestion: str,
    metadata: dict[str, object] | None = None,
) -> NoReturn:
    raise ProgramValidationError(
        message,
        code=code,
        object_path=object_path,
        suggestion=suggestion,
        metadata={} if metadata is None else metadata,
    )
