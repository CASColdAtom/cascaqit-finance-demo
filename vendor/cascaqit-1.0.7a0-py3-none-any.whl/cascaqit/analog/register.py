"""User-facing atom register builders."""

from __future__ import annotations

import math
from dataclasses import dataclass, field, replace
from typing import Any

from cascaqit.native_ir.models import (
    AtomRegisterIR,
    RegisterLifecycleIR,
    RegisterLifecycleStage,
    RegisterSiteIR,
    RegisterSiteStatus,
)

__all__ = ["AtomRegister"]


@dataclass(frozen=True)
class AtomRegister:
    """Convenience builder for two-dimensional neutral-atom registers."""

    sites: tuple[RegisterSiteIR, ...]
    snapshot_id: str = "register.planned"
    lifecycle_stage: RegisterLifecycleStage = "planned"
    previous_snapshot_hash: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def line(
        cls,
        *,
        count: int,
        spacing: float,
        origin: tuple[float, float] = (0.0, 0.0),
    ) -> AtomRegister:
        """Create a one-dimensional row of atom sites."""
        if count <= 0:
            raise ValueError("count must be positive.")
        cls._validate_spacing(spacing, name="spacing")
        sites = tuple(
            RegisterSiteIR(
                site_id=f"q{index}",
                atom_id=f"q{index}",
                position=(origin[0] + index * spacing, origin[1]),
            )
            for index in range(count)
        )
        return cls(sites=sites)

    @classmethod
    def square(
        cls,
        *,
        side: int,
        spacing: float,
        origin: tuple[float, float] = (0.0, 0.0),
    ) -> AtomRegister:
        """Create a row-major square register."""
        if side <= 0:
            raise ValueError("side must be positive.")
        return cls.rectangular(
            rows=side,
            columns=side,
            spacing_x=spacing,
            spacing_y=spacing,
            origin=origin,
        )

    @classmethod
    def rectangular(
        cls,
        *,
        rows: int,
        columns: int,
        spacing_x: float,
        spacing_y: float | None = None,
        origin: tuple[float, float] = (0.0, 0.0),
    ) -> AtomRegister:
        """Create a row-major rectangular register."""
        if rows <= 0 or columns <= 0:
            raise ValueError("rows and columns must be positive.")
        cls._validate_spacing(spacing_x, name="spacing_x")
        actual_spacing_y = spacing_x if spacing_y is None else spacing_y
        cls._validate_spacing(actual_spacing_y, name="spacing_y")
        sites: list[RegisterSiteIR] = []
        for row in range(rows):
            for column in range(columns):
                index = row * columns + column
                sites.append(
                    RegisterSiteIR(
                        site_id=f"q{index}",
                        atom_id=f"q{index}",
                        position=(
                            origin[0] + column * spacing_x,
                            origin[1] + row * actual_spacing_y,
                        ),
                    )
                )
        return cls(sites=tuple(sites))

    @classmethod
    def triangular(
        cls,
        *,
        rows: int,
        spacing: float,
        origin: tuple[float, float] = (0.0, 0.0),
    ) -> AtomRegister:
        """Create rows of one, two, and then successively more sites."""
        if rows <= 0:
            raise ValueError("rows must be positive.")
        cls._validate_spacing(spacing, name="spacing")
        vertical_spacing = math.sqrt(3.0) * spacing / 2.0
        sites: list[RegisterSiteIR] = []
        index = 0
        for row in range(rows):
            for column in range(row + 1):
                sites.append(
                    RegisterSiteIR(
                        site_id=f"q{index}",
                        atom_id=f"q{index}",
                        position=(
                            origin[0] + column * spacing,
                            origin[1] + row * vertical_spacing,
                        ),
                    )
                )
                index += 1
        return cls(sites=tuple(sites))

    @classmethod
    def custom(
        cls,
        positions: tuple[tuple[float, float], ...],
        *,
        site_ids: tuple[str, ...] | None = None,
        atom_ids: tuple[str, ...] | None = None,
        target_site_ids: frozenset[str] | None = None,
    ) -> AtomRegister:
        """Create a register from explicit coordinates and optional identities."""
        positions = tuple(positions)
        if not positions:
            raise ValueError("positions must not be empty.")
        actual_site_ids = site_ids or tuple(
            f"q{index}" for index in range(len(positions))
        )
        actual_atom_ids = atom_ids or actual_site_ids
        if len(actual_site_ids) != len(positions):
            raise ValueError("site_ids must have the same length as positions.")
        if len(actual_atom_ids) != len(positions):
            raise ValueError("atom_ids must have the same length as positions.")
        targets = (
            set(actual_site_ids)
            if target_site_ids is None
            else set(target_site_ids)
        )
        unknown_targets = targets.difference(actual_site_ids)
        if unknown_targets:
            raise ValueError(
                "target_site_ids contains unknown ids: "
                f"{sorted(unknown_targets)!r}."
            )
        return cls(
            sites=tuple(
                RegisterSiteIR(
                    site_id=site_id,
                    position=position,
                    atom_id=atom_id,
                    is_target=site_id in targets,
                )
                for site_id, atom_id, position in zip(
                    actual_site_ids,
                    actual_atom_ids,
                    positions,
                )
            )
        )

    def with_site_status(
        self,
        site_id: str,
        *,
        status: RegisterSiteStatus,
        lifecycle_stage: RegisterLifecycleStage,
        snapshot_id: str,
        atom_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> AtomRegister:
        """Return the next immutable snapshot after changing one site status."""
        matches = tuple(
            index
            for index, site in enumerate(self.sites)
            if site.site_id == site_id
        )
        if not matches:
            raise ValueError(f"Unknown register site_id {site_id!r}.")
        current_site = self.sites[matches[0]]
        if status == "filled":
            next_atom_id = current_site.atom_id if atom_id is None else atom_id
        elif status in ("vacant", "loading_failed"):
            if atom_id is not None:
                raise ValueError(f"{status} sites must not define atom_id.")
            next_atom_id = None
        else:
            next_atom_id = current_site.atom_id if atom_id is None else atom_id
        next_site = replace(
            current_site,
            status=status,
            atom_id=next_atom_id,
            metadata=current_site.metadata if metadata is None else dict(metadata),
        )
        next_sites = list(self.sites)
        next_sites[matches[0]] = next_site
        previous = self.to_ir()
        next_register = replace(
            self,
            sites=tuple(next_sites),
            snapshot_id=snapshot_id,
            lifecycle_stage=lifecycle_stage,
            previous_snapshot_hash=previous.stable_hash(),
        )
        # Validate the transition immediately instead of deferring it to a later bundle.
        RegisterLifecycleIR(
            lifecycle_id=f"transition.{snapshot_id}",
            snapshots=(previous, next_register.to_ir()),
        )
        return next_register

    def to_ir(self) -> AtomRegisterIR:
        """Return the register as an AtomRegisterIR."""
        return AtomRegisterIR(
            sites=self.sites,
            snapshot_id=self.snapshot_id,
            lifecycle_stage=self.lifecycle_stage,
            previous_snapshot_hash=self.previous_snapshot_hash,
            metadata=dict(self.metadata),
        )

    @staticmethod
    def _validate_spacing(value: float, *, name: str) -> None:
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise TypeError(f"{name} must be numeric.")
        if not math.isfinite(float(value)) or value <= 0:
            raise ValueError(f"{name} must be finite and positive.")
