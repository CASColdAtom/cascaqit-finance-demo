"""User-facing numeric or parameter-aware Analog site patterns."""

from __future__ import annotations

import math
from collections.abc import Mapping
from dataclasses import dataclass
from typing import NoReturn, Union, cast

from cascaqit.native_ir import SitePatternIR
from cascaqit.parameters.canonical import Expression, Parameter

__all__ = ["SitePattern"]

AnalogSiteWeight = Union[int, float, Parameter, Expression]


@dataclass(frozen=True)
class SitePattern:
    """Immutable dimensionless site weights with deferred parameter binding."""

    site_ids: tuple[str, ...]
    weights: tuple[AnalogSiteWeight, ...]

    def __post_init__(self) -> None:
        if not isinstance(self.site_ids, tuple):
            raise TypeError("site_ids must be a tuple.")
        if not self.site_ids:
            raise ValueError("site_ids must not be empty.")
        if any(
            not isinstance(site_id, str) or not site_id.strip()
            for site_id in self.site_ids
        ):
            raise ValueError("site_ids must contain non-empty strings.")
        if len(set(self.site_ids)) != len(self.site_ids):
            raise ValueError("site_ids must be unique.")
        if not isinstance(self.weights, tuple):
            raise TypeError("weights must be a tuple.")
        if len(self.weights) != len(self.site_ids):
            raise ValueError("site_ids and weights must have the same length.")

        normalized = tuple(_normalize_weight(value) for value in self.weights)
        object.__setattr__(self, "weights", normalized)
        if all(isinstance(value, float) for value in normalized):
            # Native IR remains the single authority for the physical [0, 1]
            # domain and the non-zero-pattern invariant after binding.
            numeric_weights = cast(tuple[float, ...], normalized)
            validated = SitePatternIR(
                site_ids=self.site_ids,
                weights=numeric_weights,
            )
            object.__setattr__(self, "site_ids", validated.site_ids)
            object.__setattr__(self, "weights", validated.weights)

    @property
    def is_bound(self) -> bool:
        """Return whether every weight can cross the numeric Native IR boundary."""
        return all(isinstance(value, float) for value in self.weights)

    @property
    def referenced_parameter_names(self) -> tuple[str, ...]:
        """Return unique canonical parameter dependencies in stable order."""
        names: set[str] = set()
        for value in self.weights:
            if isinstance(value, Parameter):
                names.add(value.name)
            elif isinstance(value, Expression):
                names.update(value.dependencies)
        return tuple(sorted(names))

    @classmethod
    def from_mapping(
        cls,
        weights: Mapping[str, AnalogSiteWeight],
    ) -> SitePattern:
        """Snapshot a mapping into deterministic site-id order."""
        if not isinstance(weights, Mapping):
            raise TypeError("weights must be a mapping from site id to weight.")
        items = tuple(weights.items())
        if any(not isinstance(site_id, str) for site_id, _ in items):
            raise TypeError("site pattern mapping keys must be strings.")
        ordered = tuple(sorted(items, key=lambda item: item[0]))
        return cls(
            site_ids=tuple(site_id for site_id, _ in ordered),
            weights=tuple(weight for _, weight in ordered),
        )

    def validate_parameter_references(
        self,
        declarations: Mapping[str, Parameter],
    ) -> None:
        """Require program-owned, dimensionless parameters and expressions."""
        for value in self.weights:
            if isinstance(value, Parameter):
                if declarations.get(value.name) is not value:
                    _raise_pattern_error(
                        f"Site pattern parameter '{value.name}' is not owned by "
                        "this program.",
                        code="AHS_SITE_PATTERN_PARAMETER_FOREIGN",
                        parameter_name=value.name,
                    )
                if value.unit is not None:
                    _raise_unit_mismatch(value.name, value.unit)
            elif isinstance(value, Expression):
                if value.unit is not None:
                    _raise_unit_mismatch("expression", value.unit)
                for name in value.dependencies:
                    if declarations.get(name) is None:
                        _raise_pattern_error(
                            (
                                "Site pattern expression references undeclared "
                                f"parameter '{name}'."
                            ),
                            code="AHS_SITE_PATTERN_PARAMETER_UNKNOWN",
                            parameter_name=name,
                        )

    def bind(self, values: Mapping[str, float]) -> SitePattern:
        """Return an independent pattern whose weights are numeric."""
        return SitePattern(
            site_ids=self.site_ids,
            weights=tuple(_resolve_weight(value, values) for value in self.weights),
        )

    def to_ir(self) -> SitePatternIR:
        """Return numeric Native IR, rejecting unresolved declaration values."""
        if not self.is_bound:
            _raise_pattern_error(
                "Analog site pattern parameters must be bound before IR export.",
                code="AHS_SITE_PATTERN_PARAMETERS_UNBOUND",
                metadata={
                    "parameter_names": list(self.referenced_parameter_names),
                },
            )
        # is_bound proves every value is a normalized float.
        numeric_weights = cast(tuple[float, ...], self.weights)
        return SitePatternIR(site_ids=self.site_ids, weights=numeric_weights)


def _normalize_weight(value: AnalogSiteWeight) -> AnalogSiteWeight:
    if isinstance(value, (Parameter, Expression)):
        return value
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(
            "site pattern weight must be a real number, Parameter, or Expression."
        )
    normalized = float(value)
    if not math.isfinite(normalized):
        raise ValueError("site pattern weights must be finite.")
    if not 0.0 <= normalized <= 1.0:
        raise ValueError("site pattern weights must be between 0 and 1.")
    return normalized


def _resolve_weight(
    value: AnalogSiteWeight,
    values: Mapping[str, float],
) -> AnalogSiteWeight:
    if isinstance(value, Parameter):
        return value.evaluate(values)
    if isinstance(value, Expression):
        return value.evaluate(values)
    return value


def _raise_unit_mismatch(name: str, actual_unit: str | None) -> NoReturn:
    _raise_pattern_error(
        f"Site pattern parameter '{name}' must be dimensionless.",
        code="AHS_SITE_PATTERN_PARAMETER_UNIT_MISMATCH",
        parameter_name=name,
        metadata={"actual_unit": actual_unit, "expected_unit": None},
    )


def _raise_pattern_error(
    message: str,
    *,
    code: str,
    parameter_name: str | None = None,
    metadata: dict[str, object] | None = None,
) -> NoReturn:
    from cascaqit.exceptions import ProgramValidationError

    raise ProgramValidationError(
        message,
        code=code,
        object_path="site_pattern.weights",
        suggestion=(
            "Use dimensionless parameters declared by this AHSProgram, then bind "
            "every weight before exporting IR."
        ),
        metadata={
            **({} if parameter_name is None else {"parameter_name": parameter_name}),
            **({} if metadata is None else metadata),
        },
    )
