"""User-facing waveform builders for Analog AHS programs."""

from __future__ import annotations

import math
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, replace
from typing import Literal, NoReturn, Union

from cascaqit.native_ir.models import WaveformIR, WaveformKind
from cascaqit.parameters.canonical import Expression, Parameter

__all__ = ["Waveform"]

AnalogWaveformValue = Union[int, float, Parameter, Expression]


@dataclass(frozen=True)
class Waveform:
    """A numeric or parameter-aware Analog control waveform."""

    waveform_ir: WaveformIR
    _value_templates: tuple[AnalogWaveformValue, ...] | None = None

    @property
    def is_bound(self) -> bool:
        """Return whether every waveform value is numeric."""
        return self._value_templates is None and self.waveform_ir.values is not None

    @property
    def is_parameter_reference(self) -> bool:
        """Return whether the declaration stores a canonical expression."""
        return _value_expression(self.waveform_ir) is not None

    @property
    def referenced_parameter_names(self) -> tuple[str, ...]:
        """Return parameter names referenced by this waveform."""
        expression = _value_expression(self.waveform_ir)
        if expression is not None:
            return expression.dependencies
        names: set[str] = set()
        for value in self._value_templates or ():
            if isinstance(value, Parameter):
                names.add(value.name)
            elif isinstance(value, Expression):
                names.update(value.dependencies)
        return tuple(sorted(names))

    @classmethod
    def constant(
        cls,
        value: AnalogWaveformValue,
        *,
        duration: float,
        waveform_id: str = "waveform",
        value_unit: str = "rad/us",
    ) -> Waveform:
        """Create a constant waveform."""
        return cls._from_values(
            kind="constant",
            values=(value,),
            duration=duration,
            times=None,
            waveform_id=waveform_id,
            value_unit=value_unit,
        )

    @classmethod
    def parameter(
        cls,
        name: str,
        *,
        duration: float,
        waveform_id: str = "waveform",
        value_unit: str = "rad/us",
        scale: float = 1.0,
        offset: float = 0.0,
    ) -> Waveform:
        """Create a constant waveform backed by a canonical expression."""
        parameter = Parameter(name, unit=value_unit)
        expression = parameter * _finite_float(scale, "scale")
        if offset:
            expression = expression + _finite_float(offset, "offset")
        return cls(
            WaveformIR(
                waveform_id=waveform_id,
                kind="constant",
                value_unit=value_unit,
                duration=duration,
                times=None,
                values=None,
                parameters={
                    "value_expression": expression,
                },
            )
        )

    @classmethod
    def linear(
        cls,
        start: AnalogWaveformValue,
        stop: AnalogWaveformValue,
        *,
        duration: float,
        waveform_id: str = "waveform",
        value_unit: str = "rad/us",
    ) -> Waveform:
        """Create a linear waveform over the given duration."""
        return cls._from_values(
            kind="linear",
            values=(start, stop),
            duration=duration,
            times=(0.0, float(duration)),
            waveform_id=waveform_id,
            value_unit=value_unit,
        )

    @classmethod
    def piecewise_linear(
        cls,
        *,
        times: Sequence[float],
        values: Sequence[AnalogWaveformValue],
        waveform_id: str = "waveform",
        value_unit: str = "rad/us",
    ) -> Waveform:
        """Create a piecewise-linear waveform."""
        return cls._piecewise(
            kind="piecewise_linear",
            times=times,
            values=values,
            waveform_id=waveform_id,
            value_unit=value_unit,
        )

    @classmethod
    def piecewise_constant(
        cls,
        *,
        times: Sequence[float],
        values: Sequence[AnalogWaveformValue],
        waveform_id: str = "waveform",
        value_unit: str = "rad/us",
    ) -> Waveform:
        """Create a piecewise-constant waveform."""
        return cls._piecewise(
            kind="piecewise_constant",
            times=times,
            values=values,
            waveform_id=waveform_id,
            value_unit=value_unit,
        )

    @classmethod
    def interpolated(
        cls,
        *,
        times: Sequence[float],
        values: Sequence[AnalogWaveformValue],
        waveform_id: str = "waveform",
        value_unit: str = "rad/us",
    ) -> Waveform:
        """Create a shape-preserving PCHIP waveform through sampled points.

        PCHIP avoids the overshoot of an unconstrained cubic spline while retaining
        a smooth first derivative inside each interval. The samples must cover the
        complete waveform domain from zero through the final duration.
        """
        normalized_times = _interpolation_times(times)
        waveform = cls._piecewise(
            kind="interpolated",
            times=normalized_times,
            values=values,
            waveform_id=waveform_id,
            value_unit=value_unit,
        )
        return replace(
            waveform,
            waveform_ir=replace(
                waveform.waveform_ir,
                metadata={
                    **waveform.waveform_ir.metadata,
                    "interpolation_method": "pchip",
                },
            ),
        )

    @classmethod
    def _piecewise(
        cls,
        *,
        kind: WaveformKind,
        times: Sequence[float],
        values: Sequence[AnalogWaveformValue],
        waveform_id: str,
        value_unit: str,
    ) -> Waveform:
        if not times:
            raise ValueError("times must not be empty.")
        if len(times) != len(values):
            raise ValueError("times and values must have the same length.")
        normalized_times = tuple(float(time) for time in times)
        return cls._from_values(
            kind=kind,
            values=tuple(values),
            duration=normalized_times[-1],
            times=normalized_times,
            waveform_id=waveform_id,
            value_unit=value_unit,
        )

    @classmethod
    def _from_values(
        cls,
        *,
        kind: WaveformKind,
        values: tuple[AnalogWaveformValue, ...],
        duration: float,
        times: tuple[float, ...] | None,
        waveform_id: str,
        value_unit: str,
    ) -> Waveform:
        normalized = tuple(_normalize_template(value, value_unit) for value in values)
        symbolic = any(
            isinstance(value, (Parameter, Expression))
            for value in normalized
        )
        numeric_values = (
            None
            if symbolic
            else tuple(_finite_float(value, "waveform value") for value in normalized)
        )
        return cls(
            WaveformIR(
                waveform_id=waveform_id,
                kind=kind,
                value_unit=value_unit,
                duration=float(duration),
                times=times,
                values=numeric_values,
            ),
            normalized if symbolic else None,
        )

    def validate_parameter_references(
        self,
        declarations: Mapping[str, Parameter],
    ) -> None:
        """Require references to match declarations and waveform units."""
        stored_expression = _value_expression(self.waveform_ir)
        if stored_expression is not None:
            for name in stored_expression.dependencies:
                declaration = declarations.get(name)
                if declaration is None:
                    _raise_waveform_error(
                        f"Waveform references undeclared parameter '{name}'.",
                        code="AHS_WAVEFORM_PARAMETER_UNKNOWN",
                        waveform=self,
                        parameter_name=name,
                    )
                if declaration.unit != self.waveform_ir.value_unit:
                    _raise_unit_mismatch(self, declaration.name, declaration.unit)
            return
        for value in self._value_templates or ():
            if isinstance(value, Parameter):
                declaration = declarations.get(value.name)
                if declaration is not value:
                    _raise_waveform_error(
                        (
                            f"Waveform parameter '{value.name}' is not owned by "
                            "this program."
                        ),
                        code="AHS_WAVEFORM_PARAMETER_FOREIGN",
                        waveform=self,
                        parameter_name=value.name,
                    )
            elif isinstance(value, Expression):
                for name in value.dependencies:
                    declaration = declarations.get(name)
                    if declaration is None:
                        _raise_waveform_error(
                            (
                                "Waveform expression references undeclared parameter "
                                f"'{name}'."
                            ),
                            code="AHS_WAVEFORM_PARAMETER_UNKNOWN",
                            waveform=self,
                            parameter_name=name,
                        )
                    if declaration.unit != value.unit:
                        _raise_unit_mismatch(self, name, declaration.unit)

    def bind(self, values: Mapping[str, float]) -> Waveform:
        """Return an independent waveform with all values resolved."""
        stored_expression = _value_expression(self.waveform_ir)
        if stored_expression is not None:
            bound_value = _finite_float(stored_expression.evaluate(values), "value")
            return Waveform(
                replace(
                    self.waveform_ir,
                    values=(bound_value,),
                    parameters={
                        **self.waveform_ir.parameters,
                        "bound_parameters": list(stored_expression.dependencies),
                        "bound_value": bound_value,
                    },
                )
            )
        if self._value_templates is None:
            return Waveform(WaveformIR.from_dict(self.waveform_ir.to_dict()))
        resolved = tuple(
            _resolve_value(value, values) for value in self._value_templates
        )
        return Waveform(
            replace(
                self.waveform_ir,
                values=resolved,
                metadata={
                    **self.waveform_ir.metadata,
                    "bound_expression_count": sum(
                        isinstance(value, Expression)
                        for value in self._value_templates
                    ),
                },
            )
        )

    def concat(
        self,
        *others: Waveform,
        waveform_id: str | None = None,
        max_points: int = 1024,
    ) -> Waveform:
        """Return a deterministic serial composition within one waveform family."""
        if not others:
            _raise_concat_error(
                "Waveform concat requires at least one following segment.",
                code="AHS_WAVEFORM_CONCAT_EMPTY",
                waveform=self,
            )
        if isinstance(max_points, bool) or not isinstance(max_points, int):
            raise TypeError("max_points must be an integer.")
        if not 2 <= max_points <= 1024:
            raise ValueError("max_points must be between 2 and 1024.")
        segments = (self, *others)
        if any(not isinstance(item, Waveform) for item in segments):
            raise TypeError("Waveform concat accepts only Waveform segments.")
        # PCHIP slopes depend on adjacent samples. Re-fitting concatenated samples
        # would silently change each source curve, so composition stays explicit.
        if any(item.waveform_ir.kind == "interpolated" for item in segments):
            _raise_concat_error(
                "Interpolated waveforms cannot be concatenated without re-fitting.",
                code="AHS_WAVEFORM_CONCAT_INTERPOLATED_UNSUPPORTED",
                waveform=self,
                suggestion=(
                    "Build one interpolated waveform over the complete time domain."
                ),
            )
        family = _waveform_family(self.waveform_ir.kind)
        for segment in segments:
            if _waveform_family(segment.waveform_ir.kind) != family:
                _raise_concat_error(
                    "Waveform concat requires one compatible kind family.",
                    code="AHS_WAVEFORM_CONCAT_FAMILY_MISMATCH",
                    waveform=self,
                )
            if segment.waveform_ir.value_unit != self.waveform_ir.value_unit:
                _raise_concat_error(
                    "Waveform concat value units must match.",
                    code="AHS_WAVEFORM_CONCAT_VALUE_UNIT_MISMATCH",
                    waveform=self,
                )
            if segment.waveform_ir.time_unit != self.waveform_ir.time_unit:
                _raise_concat_error(
                    "Waveform concat time units must match.",
                    code="AHS_WAVEFORM_CONCAT_TIME_UNIT_MISMATCH",
                    waveform=self,
                )
            duration = segment.waveform_ir.duration
            if not math.isfinite(duration) or duration <= 0.0:
                _raise_concat_error(
                    "Waveform concat segment durations must be finite and positive.",
                    code="AHS_WAVEFORM_CONCAT_DURATION_INVALID",
                    waveform=segment,
                )
            if segment.is_parameter_reference:
                _raise_concat_error(
                    "Legacy waveform references must be bound before concat.",
                    code="AHS_WAVEFORM_CONCAT_LEGACY_UNBOUND",
                    waveform=segment,
                )
        result_id = (
            f"{self.waveform_ir.waveform_id}.concat"
            if waveform_id is None
            else waveform_id
        )
        if not isinstance(result_id, str) or not result_id.strip():
            raise ValueError("waveform_id must be a non-empty string.")
        times, values = _concat_points(segments, family=family)
        if len(times) > max_points:
            _raise_concat_error(
                "Waveform concat result exceeds max_points.",
                code="AHS_WAVEFORM_CONCAT_POINT_LIMIT_EXCEEDED",
                waveform=self,
                metadata={"actual_points": len(times), "max_points": max_points},
            )
        result = Waveform._from_values(
            kind=(
                "piecewise_constant"
                if family == "constant"
                else "piecewise_linear"
            ),
            values=values,
            duration=times[-1],
            times=times,
            waveform_id=result_id,
            value_unit=self.waveform_ir.value_unit,
        )
        return replace(
            result,
            waveform_ir=replace(
                result.waveform_ir,
                time_unit=self.waveform_ir.time_unit,
                metadata={
                    **result.waveform_ir.metadata,
                    "concat_source_ids": [
                        item.waveform_ir.waveform_id for item in segments
                    ],
                    "concat_family": family,
                },
            ),
        )

    def to_ir(self) -> WaveformIR:
        """Return a numeric WaveformIR, rejecting unresolved values."""
        if not self.is_bound:
            _raise_waveform_error(
                "Analog waveform parameters must be bound before IR export.",
                code="AHS_WAVEFORM_PARAMETERS_UNBOUND",
                waveform=self,
            )
        return WaveformIR.from_dict(self.waveform_ir.to_dict())

    def _to_declaration_ir(self) -> WaveformIR:
        """Return legacy draft IR without admitting typed expression objects."""
        if not self.is_bound and not self.is_parameter_reference:
            _raise_waveform_error(
                "Typed Analog waveform parameters require explicit binding.",
                code="AHS_WAVEFORM_PARAMETERS_UNBOUND",
                waveform=self,
            )
        return WaveformIR.from_dict(self.waveform_ir.to_dict())


def _normalize_template(
    value: AnalogWaveformValue,
    value_unit: str,
) -> AnalogWaveformValue:
    if isinstance(value, (Parameter, Expression)):
        if value.unit != value_unit:
            raise ValueError(
                f"Analog value unit {value.unit!r} does not match waveform unit "
                f"{value_unit!r}."
            )
        return value
    return _finite_float(value, "waveform value")


def _waveform_family(kind: WaveformKind) -> Literal["constant", "linear"]:
    return "constant" if kind in {"constant", "piecewise_constant"} else "linear"


def _interpolation_times(times: Sequence[float]) -> tuple[float, ...]:
    """Normalize the interpolation domain before SciPy ever sees the samples."""
    if len(times) < 2:
        raise ValueError("interpolated waveform requires at least two time samples.")
    normalized = tuple(_finite_float(value, "waveform time") for value in times)
    if normalized[0] != 0.0:
        raise ValueError("interpolated waveform times must start at 0.0.")
    if any(right <= left for left, right in zip(normalized, normalized[1:])):
        raise ValueError("interpolated waveform times must be strictly increasing.")
    return normalized


def _concat_points(
    segments: tuple[Waveform, ...],
    *,
    family: Literal["constant", "linear"],
) -> tuple[tuple[float, ...], tuple[AnalogWaveformValue, ...]]:
    times: list[float] = []
    values: list[AnalogWaveformValue] = []
    offset = 0.0
    for index, segment in enumerate(segments):
        local_times, local_values = _segment_points(segment)
        shifted = tuple(offset + value for value in local_times)
        if index == 0:
            times.extend(shifted)
            values.extend(local_values)
        elif family == "constant":
            times.pop()
            values.pop()
            times.extend(shifted)
            values.extend(local_values)
        else:
            if not _same_template_value(values[-1], local_values[0]):
                _raise_concat_error(
                    "Linear waveform segments must be continuous at the seam.",
                    code="AHS_WAVEFORM_CONCAT_LINEAR_SEAM_MISMATCH",
                    waveform=segment,
                )
            times.extend(shifted[1:])
            values.extend(local_values[1:])
        offset += segment.waveform_ir.duration
    return tuple(times), tuple(values)


def _segment_points(
    waveform: Waveform,
) -> tuple[tuple[float, ...], tuple[AnalogWaveformValue, ...]]:
    templates = waveform._value_templates
    values: tuple[AnalogWaveformValue, ...]
    if templates is not None:
        values = templates
    elif waveform.waveform_ir.values is not None:
        values = waveform.waveform_ir.values
    else:
        raise AssertionError("concat accepted an unresolved legacy reference.")
    if waveform.waveform_ir.times is not None:
        return waveform.waveform_ir.times, values
    value = values[0]
    return (0.0, waveform.waveform_ir.duration), (value, value)


def _same_template_value(
    left: AnalogWaveformValue,
    right: AnalogWaveformValue,
) -> bool:
    return left == right


def _resolve_value(value: AnalogWaveformValue, values: Mapping[str, float]) -> float:
    if isinstance(value, Parameter):
        return value.evaluate(values)
    if isinstance(value, Expression):
        return value.evaluate(values)
    return _finite_float(value, "waveform value")


def _value_expression(waveform: WaveformIR) -> Expression | None:
    expression = waveform.parameters.get("value_expression")
    if isinstance(expression, Expression):
        return expression
    if isinstance(expression, dict):
        return Expression.from_dict(expression)
    return None


def _finite_float(value: object, field_name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{field_name} must be a real number and not bool.")
    normalized = float(value)
    if not math.isfinite(normalized):
        raise ValueError(f"{field_name} must be finite.")
    return normalized


def _raise_unit_mismatch(
    waveform: Waveform,
    parameter_name: str,
    actual_unit: str | None,
) -> None:
    _raise_waveform_error(
        f"Parameter '{parameter_name}' unit does not match waveform value unit.",
        code="AHS_WAVEFORM_PARAMETER_UNIT_MISMATCH",
        waveform=waveform,
        parameter_name=parameter_name,
        metadata={
            "actual_unit": actual_unit,
            "expected_unit": waveform.waveform_ir.value_unit,
        },
    )


def _raise_waveform_error(
    message: str,
    *,
    code: str,
    waveform: Waveform,
    parameter_name: str | None = None,
    metadata: dict[str, object] | None = None,
) -> NoReturn:
    from cascaqit.exceptions import ProgramValidationError

    raise ProgramValidationError(
        message,
        code=code,
        object_path=f"waveforms.{waveform.waveform_ir.waveform_id}.values",
        suggestion=(
            "Declare matching Analog parameters and bind every referenced value."
        ),
        metadata={
            "waveform_id": waveform.waveform_ir.waveform_id,
            **({} if parameter_name is None else {"parameter_name": parameter_name}),
            **({} if metadata is None else metadata),
        },
    )


def _raise_concat_error(
    message: str,
    *,
    code: str,
    waveform: Waveform,
    suggestion: str = (
        "Use compatible, finite waveform segments within the point limit."
    ),
    metadata: dict[str, object] | None = None,
) -> NoReturn:
    from cascaqit.exceptions import ProgramValidationError

    raise ProgramValidationError(
        message,
        code=code,
        object_path=f"waveforms.{waveform.waveform_ir.waveform_id}.concat",
        suggestion=suggestion,
        metadata={
            "waveform_id": waveform.waveform_ir.waveform_id,
            **({} if metadata is None else metadata),
        },
    )
