"""Shared serialization and hashing helpers for native IR objects."""

from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping
from dataclasses import fields, is_dataclass
from enum import Enum
from typing import Any

__all__ = ["IRMixin", "canonicalize", "stable_json"]


def canonicalize(value: Any) -> Any:
    """Convert supported Python objects into deterministic JSON values.

    Hashing and golden files need a stable representation that is independent
    of dataclass instances, enum objects, and dictionary insertion order.
    """
    return _canonicalize(value, use_ir_mixin=True)


def _canonicalize(value: Any, *, use_ir_mixin: bool) -> Any:
    """Convert a value while optionally honoring nested IR custom serializers."""
    if use_ir_mixin and isinstance(value, IRMixin):
        return value.to_dict()
    if isinstance(value, Enum):
        return value.value
    if is_dataclass(value):
        return {
            field.name: _canonicalize(getattr(value, field.name), use_ir_mixin=True)
            for field in fields(value)
        }
    if isinstance(value, Mapping):
        return {
            str(key): _canonicalize(value[key], use_ir_mixin=True)
            for key in sorted(value)
        }
    if isinstance(value, (list, tuple)):
        return [_canonicalize(item, use_ir_mixin=True) for item in value]
    return value


def stable_json(value: Any) -> str:
    """Serialize a supported object into stable compact JSON."""
    return json.dumps(
        canonicalize(value),
        ensure_ascii=True,
        separators=(",", ":"),
        sort_keys=True,
    )


class IRMixin:
    """Mixin for dataclass-based IR models."""

    def to_dict(self) -> dict[str, Any]:
        """Return a deterministic dictionary representation."""
        data = _canonicalize(self, use_ir_mixin=False)
        if not isinstance(data, dict):
            raise TypeError("IR object must serialize to a JSON object.")
        return data

    def to_json(self, *, indent: int | None = None) -> str:
        """Return the IR object encoded as JSON."""
        if indent is None:
            return stable_json(self)
        return json.dumps(
            self.to_dict(),
            ensure_ascii=True,
            indent=indent,
            sort_keys=True,
        )

    def stable_hash(self) -> str:
        """Return a SHA-256 hash of the canonical IR representation."""
        return hashlib.sha256(stable_json(self).encode("utf-8")).hexdigest()
