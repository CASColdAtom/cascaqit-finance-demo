"""Dataclass models for the CASCAQit MVP native IR.

The MVP models intentionally cover only the analog AHS path. Digital, hybrid,
cloud, and hardware execution models remain architecture-level reservations
until later phases.
"""

from __future__ import annotations

import copy
import json
import math
from bisect import bisect_right
from dataclasses import dataclass, field
from typing import Any, Literal

from cascaqit.native_ir.base import IRMixin
from cascaqit.parameters.canonical import Expression
from cascaqit.parameters.ir import ParameterSchemaIR

__all__ = [
    "ANALOG_BIT_ORDER_CONVENTION",
    "SCHEMA_VERSION",
    "UNSPECIFIED_BIT_ORDER_CONVENTION",
    "AtomRegisterIR",
    "HamiltonianIR",
    "LocalDetuningIR",
    "LocalRabiIR",
    "MeasurementIR",
    "OccupationEncoding",
    "ProgramIR",
    "RegisterLifecycleIR",
    "RegisterLifecycleStage",
    "RegisterSiteIR",
    "RegisterSiteStatus",
    "SimulatorConfigIR",
    "SiteAddressingIR",
    "SitePhasePatternIR",
    "SitePatternIR",
    "UnitConventions",
    "WaveformIR",
]

SCHEMA_VERSION = "0.1"
ANALOG_BIT_ORDER_CONVENTION = "active_register_order"
UNSPECIFIED_BIT_ORDER_CONVENTION = "unspecified"

LifecycleState = Literal["draft", "bound", "validated", "discretized"]
ProgramType = Literal["analog"]
WaveformKind = Literal[
    "constant",
    "linear",
    "piecewise_constant",
    "piecewise_linear",
    "interpolated",
]
SimulatorMethod = Literal["exact", "ode", "auto"]
SiteAddressingSourceKind = Literal["site_pattern", "site_mask"]
RegisterSiteStatus = Literal["filled", "vacant", "defect", "loading_failed"]
RegisterLifecycleStage = Literal[
    "planned",
    "loaded",
    "prepared",
    "post_execution",
]

_REGISTER_SITE_STATUS_ORDER = ("filled", "vacant", "defect", "loading_failed")
_REGISTER_SITE_STATUSES = frozenset(_REGISTER_SITE_STATUS_ORDER)
_REGISTER_LIFECYCLE_STAGES = (
    "planned",
    "loaded",
    "prepared",
    "post_execution",
)
_SHA256_CHARACTERS = frozenset("0123456789abcdef")


def _validate_serialized_keys(
    data: dict[str, Any],
    *,
    required: frozenset[str],
    object_name: str,
) -> None:
    """Reject missing and stale fields for clean-migrated register contracts."""
    missing = required.difference(data)
    if missing:
        raise KeyError(
            f"{object_name} is missing required field(s): {sorted(missing)!r}."
        )
    unexpected = set(data).difference(required)
    if unexpected:
        raise ValueError(
            f"{object_name} contains unexpected field(s): {sorted(unexpected)!r}."
        )


def _is_sha256(value: str) -> bool:
    return len(value) == 64 and all(
        character in _SHA256_CHARACTERS for character in value
    )


@dataclass(frozen=True)
class UnitConventions(IRMixin):
    """Physical unit conventions used by a ProgramIR."""

    coordinate: str = "um"
    time: str = "us"
    frequency: str = "rad/us"
    phase: str = "rad"

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> UnitConventions:
        """Build unit conventions from a JSON-compatible dictionary."""
        return cls(
            coordinate=str(data.get("coordinate", "um")),
            time=str(data.get("time", "us")),
            frequency=str(data.get("frequency", "rad/us")),
            phase=str(data.get("phase", "rad")),
        )


@dataclass(frozen=True)
class OccupationEncoding(IRMixin):
    """Mapping between physical states and bit values."""

    ground: int = 0
    rydberg: int = 1

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> OccupationEncoding:
        """Build occupation encoding from a JSON-compatible dictionary."""
        return cls(
            ground=int(data.get("ground", 0)),
            rydberg=int(data.get("rydberg", 1)),
        )


@dataclass(frozen=True)
class RegisterSiteIR(IRMixin):
    """A physical register site and its occupancy at one lifecycle snapshot."""

    site_id: str
    position: tuple[float, float]
    atom_id: str | None
    is_target: bool = True
    status: RegisterSiteStatus = "filled"
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not isinstance(self.site_id, str) or not self.site_id.strip():
            raise ValueError("site_id must be a non-empty string.")
        if (
            not isinstance(self.position, tuple)
            or len(self.position) != 2
            or any(
                isinstance(value, bool)
                or not isinstance(value, (int, float))
                or not math.isfinite(float(value))
                for value in self.position
            )
        ):
            raise ValueError("position must contain two finite numeric coordinates.")
        if not isinstance(self.is_target, bool):
            raise TypeError("is_target must be a bool.")
        if self.status not in _REGISTER_SITE_STATUSES:
            raise ValueError(f"Unsupported register site status {self.status!r}.")
        if self.atom_id is not None and (
            not isinstance(self.atom_id, str) or not self.atom_id.strip()
        ):
            raise ValueError("atom_id must be None or a non-empty string.")
        if not isinstance(self.metadata, dict):
            raise TypeError("metadata must be a dictionary.")

        if self.status == "filled" and self.atom_id is None:
            raise ValueError("filled sites must identify the loaded atom with atom_id.")
        if self.status in ("vacant", "loading_failed") and self.atom_id is not None:
            raise ValueError(f"{self.status} sites must not define atom_id.")
        if self.status == "defect":
            reason = self.metadata.get("reason")
            if not isinstance(reason, str) or not reason.strip():
                raise ValueError(
                    "defect sites must define a non-empty metadata reason."
                )
            contains_atom = self.metadata.get("contains_atom")
            if not isinstance(contains_atom, bool):
                raise ValueError(
                    "defect sites must define boolean metadata contains_atom."
                )
            if contains_atom != (self.atom_id is not None):
                raise ValueError(
                    "defect metadata contains_atom must match whether atom_id "
                    "is present."
                )

    @property
    def is_filled(self) -> bool:
        """Return whether this snapshot records a normally loaded atom."""
        return self.status == "filled"

    @property
    def is_active(self) -> bool:
        """Return whether the site participates in the quantum-state order."""
        return self.is_target and self.is_filled

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> RegisterSiteIR:
        """Build a register site from a JSON-compatible dictionary."""
        required = frozenset(
            {"site_id", "position", "atom_id", "is_target", "status", "metadata"}
        )
        _validate_serialized_keys(
            data,
            required=required,
            object_name="RegisterSiteIR",
        )
        position = data["position"]
        atom_id = data["atom_id"]
        return cls(
            site_id=str(data["site_id"]),
            position=(float(position[0]), float(position[1])),
            atom_id=None if atom_id is None else str(atom_id),
            is_target=data["is_target"],
            status=data["status"],
            metadata=dict(data["metadata"]),
        )


@dataclass(frozen=True)
class AtomRegisterIR(IRMixin):
    """One immutable register snapshot used by an analog program."""

    sites: tuple[RegisterSiteIR, ...]
    snapshot_id: str = "register.planned"
    lifecycle_stage: RegisterLifecycleStage = "planned"
    previous_snapshot_hash: str | None = None
    schema_version: str = SCHEMA_VERSION
    coordinate_unit: str = "um"
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not isinstance(self.sites, tuple):
            raise TypeError("sites must be a tuple.")
        if not self.sites:
            raise ValueError("sites must not be empty.")
        if any(not isinstance(site, RegisterSiteIR) for site in self.sites):
            raise TypeError("sites must contain only RegisterSiteIR values.")
        site_ids = tuple(site.site_id for site in self.sites)
        if len(set(site_ids)) != len(site_ids):
            raise ValueError("register site_id values must be unique.")
        atom_ids = tuple(
            site.atom_id for site in self.sites if site.atom_id is not None
        )
        if len(set(atom_ids)) != len(atom_ids):
            raise ValueError("register atom_id values must be unique when present.")
        if not isinstance(self.snapshot_id, str) or not self.snapshot_id.strip():
            raise ValueError("snapshot_id must be a non-empty string.")
        if self.lifecycle_stage not in _REGISTER_LIFECYCLE_STAGES:
            raise ValueError(
                f"Unsupported register lifecycle stage {self.lifecycle_stage!r}."
            )
        if self.previous_snapshot_hash is not None and (
            not isinstance(self.previous_snapshot_hash, str)
            or not _is_sha256(self.previous_snapshot_hash)
        ):
            raise ValueError("previous_snapshot_hash must be None or a SHA-256 hash.")
        if not isinstance(self.metadata, dict):
            raise TypeError("metadata must be a dictionary.")

    @property
    def active_sites(self) -> tuple[RegisterSiteIR, ...]:
        """Return filled target sites in the canonical quantum-state order."""
        return tuple(site for site in self.sites if site.is_active)

    @property
    def active_site_ids(self) -> tuple[str, ...]:
        """Return site ids participating in quantum-state evolution."""
        return tuple(site.site_id for site in self.active_sites)

    @property
    def active_atom_ids(self) -> tuple[str, ...]:
        """Return loaded atom ids participating in quantum-state evolution."""
        # RegisterSiteIR guarantees that every active site has an atom id.
        return tuple(
            site.atom_id for site in self.active_sites if site.atom_id is not None
        )

    @property
    def physical_site_ids(self) -> tuple[str, ...]:
        """Return every physical site id, including inactive layout positions."""
        return tuple(site.site_id for site in self.sites)

    @property
    def status_counts(self) -> dict[str, int]:
        """Count every physical site by lifecycle status."""
        return {
            status: sum(site.status == status for site in self.sites)
            for status in _REGISTER_SITE_STATUS_ORDER
        }

    def snapshot_evidence(self) -> dict[str, Any]:
        """Return compact physical-layout and logical-order evidence."""
        return {
            "snapshot_id": self.snapshot_id,
            "lifecycle_stage": self.lifecycle_stage,
            "snapshot_hash": self.stable_hash(),
            "previous_snapshot_hash": self.previous_snapshot_hash,
            "physical_site_count": len(self.sites),
            "active_site_count": len(self.active_sites),
            "physical_site_ids": list(self.physical_site_ids),
            "active_site_ids": list(self.active_site_ids),
            "active_atom_ids": list(self.active_atom_ids),
            "status_counts": self.status_counts,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> AtomRegisterIR:
        """Build an atom register from a JSON-compatible dictionary."""
        required = frozenset(
            {
                "sites",
                "snapshot_id",
                "lifecycle_stage",
                "previous_snapshot_hash",
                "schema_version",
                "coordinate_unit",
                "metadata",
            }
        )
        _validate_serialized_keys(
            data,
            required=required,
            object_name="AtomRegisterIR",
        )
        return cls(
            sites=tuple(RegisterSiteIR.from_dict(site) for site in data["sites"]),
            snapshot_id=str(data["snapshot_id"]),
            lifecycle_stage=data["lifecycle_stage"],
            previous_snapshot_hash=data["previous_snapshot_hash"],
            schema_version=str(data["schema_version"]),
            coordinate_unit=str(data["coordinate_unit"]),
            metadata=dict(data["metadata"]),
        )


@dataclass(frozen=True)
class RegisterLifecycleIR(IRMixin):
    """An ordered, hash-linked history of immutable register snapshots."""

    lifecycle_id: str
    snapshots: tuple[AtomRegisterIR, ...]
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not isinstance(self.lifecycle_id, str) or not self.lifecycle_id.strip():
            raise ValueError("lifecycle_id must be a non-empty string.")
        if not isinstance(self.snapshots, tuple):
            raise TypeError("snapshots must be a tuple.")
        if not self.snapshots:
            raise ValueError("snapshots must not be empty.")
        if any(not isinstance(snapshot, AtomRegisterIR) for snapshot in self.snapshots):
            raise TypeError("snapshots must contain only AtomRegisterIR values.")
        if not isinstance(self.metadata, dict):
            raise TypeError("metadata must be a dictionary.")

        topology = self._topology(self.snapshots[0])
        for index, snapshot in enumerate(self.snapshots[1:], start=1):
            previous = self.snapshots[index - 1]
            if self._topology(snapshot) != topology:
                raise ValueError("register snapshot topology must remain unchanged.")
            if snapshot.previous_snapshot_hash != previous.stable_hash():
                raise ValueError(
                    "register snapshot previous_snapshot_hash does not match "
                    "the preceding snapshot."
                )
            previous_stage = _REGISTER_LIFECYCLE_STAGES.index(
                previous.lifecycle_stage
            )
            current_stage = _REGISTER_LIFECYCLE_STAGES.index(
                snapshot.lifecycle_stage
            )
            if current_stage < previous_stage or current_stage > previous_stage + 1:
                raise ValueError(
                    "register lifecycle stage must stay unchanged or advance "
                    "by exactly one stage."
                )
            for old_site, new_site in zip(previous.sites, snapshot.sites):
                if old_site.status == "defect" and new_site.status == "filled":
                    raise ValueError(
                        "register site status transition from defect to filled "
                        "is not allowed."
                    )

    @staticmethod
    def _topology(
        snapshot: AtomRegisterIR,
    ) -> tuple[tuple[str, tuple[float, float], bool], ...]:
        return tuple(
            (site.site_id, site.position, site.is_target) for site in snapshot.sites
        )

    @property
    def active_site_ids(self) -> tuple[str, ...]:
        """Return active site ids from the final snapshot."""
        return tuple(
            site.site_id for site in self.snapshots[-1].sites if site.is_active
        )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> RegisterLifecycleIR:
        """Build a register lifecycle from a JSON-compatible dictionary."""
        required = frozenset(
            {"lifecycle_id", "snapshots", "schema_version", "metadata"}
        )
        _validate_serialized_keys(
            data,
            required=required,
            object_name="RegisterLifecycleIR",
        )
        return cls(
            lifecycle_id=str(data["lifecycle_id"]),
            snapshots=tuple(
                AtomRegisterIR.from_dict(snapshot) for snapshot in data["snapshots"]
            ),
            schema_version=str(data["schema_version"]),
            metadata=dict(data["metadata"]),
        )

    @classmethod
    def from_json(cls, text: str) -> RegisterLifecycleIR:
        """Build a register lifecycle from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("RegisterLifecycleIR JSON must encode an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class WaveformIR(IRMixin):
    """Waveform representation for AHS control fields."""

    waveform_id: str
    kind: WaveformKind
    value_unit: str
    duration: float
    times: tuple[float, ...] | None = None
    values: tuple[float, ...] | None = None
    schema_version: str = SCHEMA_VERSION
    time_unit: str = "us"
    parameters: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> WaveformIR:
        """Build a waveform from a JSON-compatible dictionary."""
        times = data.get("times")
        values = data.get("values")
        parameters = dict(data.get("parameters", {}))
        expression = parameters.get("value_expression")
        if isinstance(expression, dict):
            parameters["value_expression"] = Expression.from_dict(expression)
        return cls(
            waveform_id=str(data["waveform_id"]),
            kind=data["kind"],
            value_unit=str(data["value_unit"]),
            duration=float(data["duration"]),
            times=None if times is None else tuple(float(item) for item in times),
            values=None if values is None else tuple(float(item) for item in values),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            time_unit=str(data.get("time_unit", "us")),
            parameters=parameters,
            metadata=dict(data.get("metadata", {})),
        )


@dataclass(frozen=True)
class SitePatternIR(IRMixin):
    """Ordered dimensionless weights for every active register site."""

    site_ids: tuple[str, ...]
    weights: tuple[float, ...]
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not isinstance(self.site_ids, tuple):
            raise TypeError("site_ids must be a tuple.")
        if not self.site_ids:
            raise ValueError("site_ids must not be empty.")
        if any(
            not isinstance(site_id, str) or not site_id.strip()
            for site_id in self.site_ids
        ):
            raise ValueError("site_ids must contain non-empty strings.")
        if len(set(self.site_ids)) != len(self.site_ids):
            raise ValueError("site_ids must be unique.")
        if not isinstance(self.weights, tuple):
            raise TypeError("weights must be a tuple.")
        if len(self.weights) != len(self.site_ids):
            raise ValueError("site_ids and weights must have the same length.")

        normalized: list[float] = []
        for weight in self.weights:
            if isinstance(weight, bool) or not isinstance(weight, (int, float)):
                raise TypeError("weights must contain real numbers, not bool values.")
            numeric = float(weight)
            if not math.isfinite(numeric):
                raise ValueError("weights must contain finite values.")
            if not 0.0 <= numeric <= 1.0:
                raise ValueError("weights must be between 0 and 1.")
            normalized.append(numeric)
        if not any(weight > 0.0 for weight in normalized):
            raise ValueError("weights must contain at least one non-zero value.")
        if not isinstance(self.metadata, dict):
            raise TypeError("metadata must be a dictionary.")
        if not isinstance(self.schema_version, str) or not self.schema_version.strip():
            raise ValueError("schema_version must be a non-empty string.")
        object.__setattr__(self, "weights", tuple(normalized))
        object.__setattr__(self, "metadata", copy.deepcopy(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SitePatternIR:
        """Build a site pattern from a JSON-compatible dictionary."""
        if not isinstance(data, dict):
            raise TypeError("SitePatternIR data must be a dictionary.")
        site_ids = data["site_ids"]
        weights = data["weights"]
        if not isinstance(site_ids, (list, tuple)):
            raise TypeError("site_ids must be a JSON array.")
        if not isinstance(weights, (list, tuple)):
            raise TypeError("weights must be a JSON array.")
        return cls(
            site_ids=tuple(site_ids),
            weights=tuple(weights),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> SitePatternIR:
        """Build a site pattern from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("SitePatternIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class SitePhasePatternIR(IRMixin):
    """Numeric phase offsets aligned to active register site ids."""

    site_ids: tuple[str, ...]
    offsets: tuple[float, ...]
    schema_version: str = SCHEMA_VERSION
    unit: str = "rad"
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not isinstance(self.site_ids, tuple):
            raise TypeError("site_ids must be a tuple.")
        if not self.site_ids:
            raise ValueError("site_ids must not be empty.")
        if any(
            not isinstance(site_id, str) or not site_id.strip()
            for site_id in self.site_ids
        ):
            raise ValueError("site_ids must contain non-empty strings.")
        if len(set(self.site_ids)) != len(self.site_ids):
            raise ValueError("site_ids must be unique.")
        if not isinstance(self.offsets, tuple):
            raise TypeError("offsets must be a tuple.")
        if len(self.offsets) != len(self.site_ids):
            raise ValueError("site_ids and offsets must have the same length.")
        offsets = tuple(
            _finite_real_number(value, "offsets") for value in self.offsets
        )
        if self.unit != "rad":
            raise ValueError("unit must be 'rad'.")
        if not isinstance(self.metadata, dict):
            raise TypeError("metadata must be a dictionary.")
        if not isinstance(self.schema_version, str) or not self.schema_version.strip():
            raise ValueError("schema_version must be a non-empty string.")
        object.__setattr__(self, "offsets", offsets)
        object.__setattr__(self, "metadata", copy.deepcopy(self.metadata))

    @classmethod
    def zeros(cls, site_ids: tuple[str, ...]) -> SitePhasePatternIR:
        """Create an explicit zero-offset pattern for one register order."""
        return cls(site_ids=site_ids, offsets=(0.0,) * len(site_ids))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SitePhasePatternIR:
        """Build a phase pattern from a JSON-compatible dictionary."""
        if not isinstance(data, dict):
            raise TypeError("SitePhasePatternIR data must be a dictionary.")
        site_ids = data["site_ids"]
        offsets = data["offsets"]
        if not isinstance(site_ids, (list, tuple)):
            raise TypeError("site_ids must be a JSON array.")
        if not isinstance(offsets, (list, tuple)):
            raise TypeError("offsets must be a JSON array.")
        return cls(
            site_ids=tuple(site_ids),
            offsets=tuple(offsets),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            unit=str(data.get("unit", "rad")),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> SitePhasePatternIR:
        """Build a phase pattern from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("SitePhasePatternIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class SiteAddressingIR(IRMixin):
    """Register-aligned dense weights sampled from explicit step frames."""

    site_ids: tuple[str, ...]
    times: tuple[float, ...]
    weights: tuple[tuple[float, ...], ...]
    duration: float
    source_kind: SiteAddressingSourceKind
    schema_version: str = SCHEMA_VERSION
    time_unit: str = "us"
    interpolation: str = "step"
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not isinstance(self.site_ids, tuple):
            raise TypeError("site_ids must be a tuple.")
        if not self.site_ids:
            raise ValueError("site_ids must not be empty.")
        if any(
            not isinstance(site_id, str) or not site_id.strip()
            for site_id in self.site_ids
        ):
            raise ValueError("site_ids must contain non-empty strings.")
        if len(set(self.site_ids)) != len(self.site_ids):
            raise ValueError("site_ids must be unique.")

        duration = _finite_real_number(self.duration, "duration")
        if duration <= 0.0:
            raise ValueError("duration must be positive.")
        if not isinstance(self.times, tuple):
            raise TypeError("times must be a tuple.")
        if not self.times:
            raise ValueError("times must not be empty.")
        times = tuple(_finite_real_number(value, "times") for value in self.times)
        if times[0] != 0.0:
            raise ValueError("times must start at 0.0.")
        if any(right <= left for left, right in zip(times, times[1:])):
            raise ValueError("times must be strictly increasing.")
        if any(value >= duration for value in times):
            raise ValueError("frame times must be less than duration.")

        if not isinstance(self.weights, tuple):
            raise TypeError("weights must be a tuple.")
        if len(self.weights) != len(times):
            raise ValueError("weights must contain one weight frame per time.")
        normalized_frames: list[tuple[float, ...]] = []
        for frame in self.weights:
            if not isinstance(frame, tuple):
                raise TypeError("each weights frame must be a tuple.")
            if len(frame) != len(self.site_ids):
                raise ValueError("each frame must contain one weight per site.")
            normalized_frame: list[float] = []
            for weight in frame:
                numeric = _finite_real_number(weight, "weights")
                if not 0.0 <= numeric <= 1.0:
                    raise ValueError("weights must be between 0 and 1.")
                normalized_frame.append(numeric)
            normalized_frames.append(tuple(normalized_frame))
        if not any(weight > 0.0 for frame in normalized_frames for weight in frame):
            raise ValueError("weights must contain at least one non-zero value.")

        if self.source_kind not in {"site_pattern", "site_mask"}:
            raise ValueError("source_kind must be 'site_pattern' or 'site_mask'.")
        if self.source_kind == "site_pattern" and len(times) != 1:
            raise ValueError(
                "site_pattern addressing must contain a single static frame."
            )
        if self.source_kind == "site_mask" and any(
            weight not in {0.0, 1.0}
            for frame in normalized_frames
            for weight in frame
        ):
            raise ValueError("site_mask weights must be binary.")
        if self.time_unit != "us":
            raise ValueError("time_unit must be 'us'.")
        if self.interpolation != "step":
            raise ValueError("interpolation must be 'step'.")
        if not isinstance(self.metadata, dict):
            raise TypeError("metadata must be a dictionary.")
        if not isinstance(self.schema_version, str) or not self.schema_version.strip():
            raise ValueError("schema_version must be a non-empty string.")

        object.__setattr__(self, "duration", duration)
        object.__setattr__(self, "times", times)
        object.__setattr__(self, "weights", tuple(normalized_frames))
        object.__setattr__(self, "metadata", copy.deepcopy(self.metadata))

    @property
    def frame_count(self) -> int:
        """Return the number of dense addressing frames."""
        return len(self.times)

    @property
    def is_dynamic(self) -> bool:
        """Return whether weights change after time zero."""
        return self.frame_count > 1

    def weights_at(self, time: float) -> tuple[float, ...]:
        """Return register-aligned weights using left-closed step frames."""
        sample = _addressing_sample_time(time, duration=self.duration)
        return self.weights[bisect_right(self.times, sample) - 1]

    def active_site_ids_at(self, time: float) -> tuple[str, ...]:
        """Return sites with non-zero weight at one sample time."""
        return tuple(
            site_id
            for site_id, weight in zip(self.site_ids, self.weights_at(time))
            if weight > 0.0
        )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SiteAddressingIR:
        """Restore addressing from a JSON-compatible dictionary."""
        if not isinstance(data, dict):
            raise TypeError("SiteAddressingIR data must be a dictionary.")
        site_ids = data["site_ids"]
        times = data["times"]
        weights = data["weights"]
        if not isinstance(site_ids, (list, tuple)):
            raise TypeError("site_ids must be a JSON array.")
        if not isinstance(times, (list, tuple)):
            raise TypeError("times must be a JSON array.")
        if not isinstance(weights, (list, tuple)):
            raise TypeError("weights must be a JSON array.")
        if any(not isinstance(frame, (list, tuple)) for frame in weights):
            raise TypeError("weight frames must be JSON arrays.")
        return cls(
            site_ids=tuple(site_ids),
            times=tuple(times),
            weights=tuple(tuple(frame) for frame in weights),
            duration=data["duration"],
            source_kind=data["source_kind"],
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            time_unit=str(data.get("time_unit", "us")),
            interpolation=str(data.get("interpolation", "step")),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> SiteAddressingIR:
        """Restore addressing from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("SiteAddressingIR JSON must contain an object.")
        return cls.from_dict(data)


def _finite_real_number(value: object, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{name} must contain real numbers, not bool values.")
    result = float(value)
    if not math.isfinite(result):
        raise ValueError(f"{name} must contain finite values.")
    return result


def _addressing_sample_time(value: object, *, duration: float) -> float:
    sample = _finite_real_number(value, "time")
    if not 0.0 <= sample <= duration:
        raise ValueError(f"time must be finite and in [0.0, {duration}].")
    return sample


@dataclass(frozen=True)
class LocalDetuningIR(IRMixin):
    """One detuning waveform scaled by register-aligned addressing frames."""

    waveform: WaveformIR
    addressing: SiteAddressingIR
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not isinstance(self.waveform, WaveformIR):
            raise TypeError("waveform must be WaveformIR.")
        if not isinstance(self.addressing, SiteAddressingIR):
            raise TypeError("addressing must be SiteAddressingIR.")
        if self.waveform.value_unit != "rad/us":
            raise ValueError("local detuning waveform value_unit must be 'rad/us'.")
        if self.waveform.time_unit != "us":
            raise ValueError("local detuning waveform time_unit must be 'us'.")
        if not isinstance(self.metadata, dict):
            raise TypeError("metadata must be a dictionary.")
        if not isinstance(self.schema_version, str) or not self.schema_version.strip():
            raise ValueError("schema_version must be a non-empty string.")
        object.__setattr__(self, "metadata", copy.deepcopy(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> LocalDetuningIR:
        """Build local detuning from a JSON-compatible dictionary."""
        if not isinstance(data, dict):
            raise TypeError("LocalDetuningIR data must be a dictionary.")
        waveform = data["waveform"]
        addressing = data["addressing"]
        if not isinstance(waveform, dict):
            raise TypeError("LocalDetuningIR waveform must be an object.")
        if not isinstance(addressing, dict):
            raise TypeError("LocalDetuningIR addressing must be an object.")
        return cls(
            waveform=WaveformIR.from_dict(waveform),
            addressing=SiteAddressingIR.from_dict(addressing),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> LocalDetuningIR:
        """Build local detuning from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("LocalDetuningIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class LocalRabiIR(IRMixin):
    """One Rabi drive with shared phase and register-aligned addressing."""

    rabi: WaveformIR
    phase: WaveformIR | float
    addressing: SiteAddressingIR
    phase_pattern: SitePhasePatternIR
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not isinstance(self.rabi, WaveformIR):
            raise TypeError("rabi must be WaveformIR.")
        if not isinstance(self.addressing, SiteAddressingIR):
            raise TypeError("addressing must be SiteAddressingIR.")
        if not isinstance(self.phase_pattern, SitePhasePatternIR):
            raise TypeError("phase_pattern must be SitePhasePatternIR.")
        if self.phase_pattern.site_ids != self.addressing.site_ids:
            raise ValueError(
                "phase_pattern site_ids must match addressing site_ids exactly."
            )
        if self.rabi.value_unit != "rad/us":
            raise ValueError("local Rabi waveform value_unit must be 'rad/us'.")
        if self.rabi.time_unit != "us":
            raise ValueError("local Rabi waveform time_unit must be 'us'.")
        if isinstance(self.phase, WaveformIR):
            if self.phase.value_unit != "rad":
                raise ValueError("local Rabi phase value_unit must be 'rad'.")
            if self.phase.time_unit != "us":
                raise ValueError("local Rabi phase time_unit must be 'us'.")
            if self.phase.duration != self.rabi.duration:
                raise ValueError("local Rabi phase duration must match Rabi duration.")
        else:
            if isinstance(self.phase, bool) or not isinstance(
                self.phase,
                (int, float),
            ):
                raise TypeError("phase must be a real number or WaveformIR.")
            if not math.isfinite(float(self.phase)):
                raise ValueError("phase must be finite.")
            object.__setattr__(self, "phase", float(self.phase))
        if not isinstance(self.metadata, dict):
            raise TypeError("metadata must be a dictionary.")
        if not isinstance(self.schema_version, str) or not self.schema_version.strip():
            raise ValueError("schema_version must be a non-empty string.")
        object.__setattr__(self, "metadata", copy.deepcopy(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> LocalRabiIR:
        """Build local Rabi control from a JSON-compatible dictionary."""
        if not isinstance(data, dict):
            raise TypeError("LocalRabiIR data must be a dictionary.")
        rabi = data["rabi"]
        phase = data["phase"]
        addressing = data["addressing"]
        phase_pattern = data["phase_pattern"]
        if not isinstance(rabi, dict):
            raise TypeError("LocalRabiIR rabi must be an object.")
        if isinstance(phase, dict):
            phase = WaveformIR.from_dict(phase)
        if not isinstance(addressing, dict):
            raise TypeError("LocalRabiIR addressing must be an object.")
        if not isinstance(phase_pattern, dict):
            raise TypeError("LocalRabiIR phase_pattern must be an object.")
        return cls(
            rabi=WaveformIR.from_dict(rabi),
            phase=phase,
            addressing=SiteAddressingIR.from_dict(addressing),
            phase_pattern=SitePhasePatternIR.from_dict(phase_pattern),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> LocalRabiIR:
        """Build local Rabi control from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("LocalRabiIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class HamiltonianIR(IRMixin):
    """Rydberg Hamiltonian terms in deterministic declaration order."""

    rabi: WaveformIR
    detuning: WaveformIR
    phase: WaveformIR | float
    schema_version: str = SCHEMA_VERSION
    hamiltonian_type: str = "rydberg"
    species: str | None = None
    rydberg_state: str | None = None
    c6: float | None = None
    c6_unit: str | None = None
    local_detuning_terms: tuple[LocalDetuningIR, ...] = ()
    local_rabi_terms: tuple[LocalRabiIR, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not isinstance(self.local_detuning_terms, tuple) or any(
            not isinstance(term, LocalDetuningIR) for term in self.local_detuning_terms
        ):
            raise TypeError("local_detuning_terms must be a tuple of LocalDetuningIR.")
        if not isinstance(self.local_rabi_terms, tuple) or any(
            not isinstance(term, LocalRabiIR) for term in self.local_rabi_terms
        ):
            raise TypeError("local_rabi_terms must be a tuple of LocalRabiIR.")

    def to_dict(self) -> dict[str, Any]:
        """Return a dictionary that keeps Hamiltonian terms grouped."""
        data = super().to_dict()
        terms = {
            "rabi": data.pop("rabi"),
            "detuning": data.pop("detuning"),
            "phase": data.pop("phase"),
            "local_detuning_terms": data.pop("local_detuning_terms"),
            "local_rabi_terms": data.pop("local_rabi_terms"),
        }
        data["terms"] = terms
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> HamiltonianIR:
        """Build a Hamiltonian from the grouped MVP JSON shape."""
        terms = data["terms"]
        phase = terms["phase"]
        phase = WaveformIR.from_dict(phase) if isinstance(phase, dict) else float(phase)
        local_detuning_data = terms["local_detuning_terms"]
        local_rabi_data = terms["local_rabi_terms"]
        if not isinstance(local_detuning_data, list):
            raise TypeError("local_detuning_terms must be a JSON array.")
        if not isinstance(local_rabi_data, list):
            raise TypeError("local_rabi_terms must be a JSON array.")
        return cls(
            rabi=WaveformIR.from_dict(terms["rabi"]),
            detuning=WaveformIR.from_dict(terms["detuning"]),
            phase=phase,
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            hamiltonian_type=str(data.get("hamiltonian_type", "rydberg")),
            species=data.get("species"),
            rydberg_state=data.get("rydberg_state"),
            c6=data.get("c6"),
            c6_unit=data.get("c6_unit"),
            local_detuning_terms=tuple(
                LocalDetuningIR.from_dict(term) for term in local_detuning_data
            ),
            local_rabi_terms=tuple(
                LocalRabiIR.from_dict(term) for term in local_rabi_data
            ),
            metadata=dict(data.get("metadata", {})),
        )


@dataclass(frozen=True)
class MeasurementIR(IRMixin):
    """Terminal measurement configuration."""

    measurement_id: str
    basis: str = "ground_rydberg"
    targets: tuple[str, ...] | Literal["all"] = "all"
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> MeasurementIR:
        """Build a measurement configuration from a JSON-compatible dictionary."""
        targets = data.get("targets", "all")
        return cls(
            measurement_id=str(data["measurement_id"]),
            basis=str(data.get("basis", "ground_rydberg")),
            targets="all" if targets == "all" else tuple(str(item) for item in targets),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )


@dataclass(frozen=True)
class ProgramIR(IRMixin):
    """CASCAQit MVP native program IR."""

    program_id: str
    register: AtomRegisterIR
    hamiltonian: HamiltonianIR
    measurements: tuple[MeasurementIR, ...]
    schema_version: str = SCHEMA_VERSION
    program_type: ProgramType = "analog"
    lifecycle_state: LifecycleState = "draft"
    unit_conventions: UnitConventions = field(default_factory=UnitConventions)
    bit_ordering: dict[str, str] = field(
        default_factory=lambda: {"convention": ANALOG_BIT_ORDER_CONVENTION}
    )
    occupation_encoding: OccupationEncoding = field(default_factory=OccupationEncoding)
    parameters: dict[str, Any] = field(default_factory=dict)
    parameter_schema: ParameterSchemaIR = field(default_factory=ParameterSchemaIR)
    hashes: dict[str, str] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-compatible program representation.

        Empty parameter schemas are omitted so existing non-parameterized
        programs keep their v0.1 hashes. Parameterized programs still expose
        the schema explicitly.
        """
        data = super().to_dict()
        if not self.parameter_schema.parameters and not self.parameter_schema.metadata:
            data.pop("parameter_schema", None)
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ProgramIR:
        """Build a program IR from the MVP JSON representation."""
        return cls(
            program_id=str(data["program_id"]),
            register=AtomRegisterIR.from_dict(data["register"]),
            hamiltonian=HamiltonianIR.from_dict(data["hamiltonian"]),
            measurements=tuple(
                MeasurementIR.from_dict(measurement)
                for measurement in data["measurements"]
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            program_type=data.get("program_type", "analog"),
            lifecycle_state=data.get("lifecycle_state", "draft"),
            unit_conventions=UnitConventions.from_dict(
                data.get("unit_conventions", {})
            ),
            bit_ordering=dict(data.get("bit_ordering", {})),
            occupation_encoding=OccupationEncoding.from_dict(
                data.get("occupation_encoding", {})
            ),
            parameters=dict(data.get("parameters", {})),
            parameter_schema=ParameterSchemaIR.from_dict(
                data.get("parameter_schema", {})
            ),
            hashes=dict(data.get("hashes", {})),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> ProgramIR:
        """Build a program IR from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("ProgramIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class SimulatorConfigIR(IRMixin):
    """Simulator configuration for MVP local AHS simulation."""

    method: SimulatorMethod = "auto"
    shots: int = 1000
    seed: int | None = None
    return_probabilities: bool = True
    observables: tuple[str, ...] = ()
    tolerance: float = 1e-9
    max_hilbert_dim: int = 2**16
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SimulatorConfigIR:
        """Build simulator configuration from a JSON-compatible dictionary."""
        return cls(
            method=data.get("method", "auto"),
            shots=int(data.get("shots", 1000)),
            seed=data.get("seed"),
            return_probabilities=bool(data.get("return_probabilities", True)),
            observables=tuple(str(item) for item in data.get("observables", ())),
            tolerance=float(data.get("tolerance", 1e-9)),
            max_hilbert_dim=int(data.get("max_hilbert_dim", 2**16)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )
