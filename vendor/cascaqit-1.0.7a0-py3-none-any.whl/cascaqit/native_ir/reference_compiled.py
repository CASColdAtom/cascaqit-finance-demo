"""Public reference-compiler output contract."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Literal

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.native_ir.base import IRMixin
from cascaqit.native_ir.models import SCHEMA_VERSION
from cascaqit.parameters.ir import ParameterSchemaIR

__all__ = ["ReferenceCompiledProgramIR"]

ProgramType = Literal["analog", "digital"]
CompilationScope = Literal["public_reference"]

_PRIVATE_FACT_KEYS = frozenset(
    {
        "calibration_hash",
        "calibration_binding",
        "calibration_profile_id",
        "calibration_ref",
        "calibration_snapshot",
        "calibration_snapshot_hash",
        "calibration_status",
        "calibration_summary",
        "credential",
        "hardware_payload",
        "payload",
        "physical_atom_mapping",
        "physical_mapping",
        "physical_qubit_mapping",
        "private_endpoint",
        "production_schedule",
        "readout_calibration_hash",
        "secret",
    }
)


@dataclass(frozen=True)
class ReferenceCompiledProgramIR(IRMixin):
    """Deterministic public compile result without private hardware facts."""

    compiled_program_id: str
    source_program_hash: str
    discretized_program_hash: str
    target_id: str
    target_version: str
    target_snapshot_hash: str
    compiler_version: str
    compiler_options: dict[str, Any]
    optimization_level: int
    program_type: ProgramType
    compilation_scope: CompilationScope
    native_operation_set: tuple[dict[str, Any], ...]
    compiled_schedule: dict[str, Any]
    channel_schedule: dict[str, Any]
    measurement_schedule: dict[str, Any]
    parameter_schema: ParameterSchemaIR = field(default_factory=ParameterSchemaIR)
    bindable_parameters: tuple[str, ...] = ()
    mapping_info: dict[str, Any] = field(default_factory=dict)
    source_map: dict[str, Any] = field(default_factory=dict)
    resource_estimate: dict[str, Any] = field(default_factory=dict)
    unsupported_features: tuple[dict[str, Any], ...] = ()
    compile_cache_key: str = ""
    artifact_refs: tuple[dict[str, Any], ...] = ()
    diagnostics: tuple[DiagnosticsIR, ...] = ()
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Enforce the public reference boundary at construction time."""
        if self.compilation_scope != "public_reference":
            raise ValueError(
                "ReferenceCompiledProgramIR compilation_scope must be "
                "'public_reference'."
            )
        if self.optimization_level != 0:
            raise ValueError(
                "ReferenceCompiledProgramIR only supports optimization_level=0."
            )
        _reject_private_facts(self.to_dict(), path="reference_compiled_program")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ReferenceCompiledProgramIR:
        """Build a public reference compile result from a dictionary."""
        if not isinstance(data, dict):
            raise TypeError(
                "ReferenceCompiledProgramIR dictionary must contain an object."
            )
        # Validate the wire payload before selecting known fields so removed private
        # fields cannot be silently ignored during clean schema migration.
        _reject_private_facts(data, path="reference_compiled_program")
        return cls(
            compiled_program_id=str(data["compiled_program_id"]),
            source_program_hash=str(data["source_program_hash"]),
            discretized_program_hash=str(data["discretized_program_hash"]),
            target_id=str(data["target_id"]),
            target_version=str(data["target_version"]),
            target_snapshot_hash=str(data["target_snapshot_hash"]),
            compiler_version=str(data["compiler_version"]),
            compiler_options=dict(data["compiler_options"]),
            optimization_level=int(data["optimization_level"]),
            program_type=data.get("program_type", "analog"),
            compilation_scope=data["compilation_scope"],
            native_operation_set=tuple(
                dict(operation)
                for operation in data.get("native_operation_set", ())
            ),
            compiled_schedule=dict(data["compiled_schedule"]),
            channel_schedule=dict(data["channel_schedule"]),
            measurement_schedule=dict(data["measurement_schedule"]),
            parameter_schema=ParameterSchemaIR.from_dict(
                data.get("parameter_schema", {})
            ),
            bindable_parameters=tuple(
                str(parameter)
                for parameter in data.get("bindable_parameters", ())
            ),
            mapping_info=dict(data.get("mapping_info", {})),
            source_map=dict(data.get("source_map", {})),
            resource_estimate=dict(data.get("resource_estimate", {})),
            unsupported_features=tuple(
                dict(feature)
                for feature in data.get("unsupported_features", ())
            ),
            compile_cache_key=str(data.get("compile_cache_key", "")),
            artifact_refs=tuple(
                dict(artifact)
                for artifact in data.get("artifact_refs", ())
            ),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(diagnostic)
                for diagnostic in data.get("diagnostics", ())
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> ReferenceCompiledProgramIR:
        """Build a public reference compile result from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("ReferenceCompiledProgramIR JSON must contain an object.")
        return cls.from_dict(data)


def _reject_private_facts(value: Any, *, path: str) -> None:
    """Reject private hardware facts anywhere in the public compile payload."""
    if isinstance(value, dict):
        for key, nested in value.items():
            key_text = str(key)
            if key_text in _PRIVATE_FACT_KEYS:
                raise ValueError(
                    "ReferenceCompiledProgramIR cannot contain private fact "
                    f"{path}.{key_text}."
                )
            _reject_private_facts(nested, path=f"{path}.{key_text}")
    elif isinstance(value, (list, tuple)):
        for index, nested in enumerate(value):
            _reject_private_facts(nested, path=f"{path}[{index}]")
