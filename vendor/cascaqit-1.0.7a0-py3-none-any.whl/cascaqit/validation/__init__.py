"""Validation entry points for CASCAQit MVP ProgramIR objects."""

from __future__ import annotations

from cascaqit.validation.program import validate_program

__all__ = ["validate_program"]
