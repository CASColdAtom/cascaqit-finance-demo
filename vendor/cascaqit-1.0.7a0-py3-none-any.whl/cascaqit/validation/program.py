"""ProgramIR validation against MVP target specifications."""

from __future__ import annotations

import math
from collections.abc import Iterable
from typing import Any

from cascaqit.control import (
    ControlSystemIR,
    build_control_schedule,
    validate_control_schedule,
)
from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.native_ir.models import (
    ANALOG_BIT_ORDER_CONVENTION,
    LocalRabiIR,
    ProgramIR,
    SiteAddressingIR,
    WaveformIR,
)
from cascaqit.parameters.canonical import Expression
from cascaqit.targets import TargetSpec

__all__ = ["validate_program"]


def validate_program(
    program: ProgramIR,
    target: TargetSpec,
    *,
    shots: int,
) -> tuple[DiagnosticsIR, ...]:
    """Validate a ProgramIR against target limits and return diagnostics."""
    diagnostics: list[DiagnosticsIR] = []
    diagnostics.extend(_validate_parameters(program))
    diagnostics.extend(_validate_register(program, target))
    diagnostics.extend(_validate_waveform(program.hamiltonian.rabi, target, "rabi"))
    diagnostics.extend(
        _validate_waveform(program.hamiltonian.detuning, target, "detuning")
    )
    diagnostics.extend(_validate_local_detuning(program, target))
    diagnostics.extend(_validate_local_rabi(program, target))
    diagnostics.extend(_validate_phase(program, target))
    diagnostics.extend(_validate_measurements(program, target))
    diagnostics.extend(_validate_shots(shots, target))
    control_system = ControlSystemIR.from_target_spec(target)
    control_schedule = build_control_schedule(program, control_system)
    control_diagnostics = (
        *control_schedule.diagnostics,
        *validate_control_schedule(control_schedule, control_system, program),
    )
    # validate() returns blocking or unchecked facts. Passing evidence remains
    # available on the typed ControlScheduleIR without flooding normal runs.
    diagnostics.extend(
        diagnostic
        for diagnostic in control_diagnostics
        if diagnostic.severity == "error"
        or diagnostic.code == "CONTROL_CONSTRAINT_UNDECLARED"
        or diagnostic.code.endswith("_ANALYSIS_UNAVAILABLE")
    )
    return tuple(diagnostics)


def _validate_local_detuning(
    program: ProgramIR,
    target: TargetSpec,
) -> Iterable[DiagnosticsIR]:
    terms = program.hamiltonian.local_detuning_terms
    if not terms:
        return

    typed = target.typed_capabilities
    status = (
        typed.analog_status("local_detuning")
        if typed is not None
        else target.capabilities.get("local_detuning")
    )
    if status not in ("supported", "experimental"):
        yield _diagnostic(
            code="LOCAL_DETUNING_CAPABILITY_UNSUPPORTED",
            message=(
                f"Target {target.target_id!r} does not support local detuning "
                f"(status={status!r})."
            ),
            object_path="hamiltonian.terms.local_detuning_terms",
            suggestion="Use a target with supported or experimental local detuning.",
        )
    operation_supported = status in ("supported", "experimental")

    active_site_ids = program.register.active_site_ids
    global_detuning = program.hamiltonian.detuning
    global_duration = max(
        program.hamiltonian.rabi.duration,
        global_detuning.duration,
    )
    for index, term in enumerate(terms):
        path = f"hamiltonian.terms.local_detuning_terms[{index}]"
        pattern_site_ids = term.addressing.site_ids
        if set(pattern_site_ids) != set(active_site_ids) or len(
            pattern_site_ids
        ) != len(active_site_ids):
            yield _diagnostic(
                code="LOCAL_DETUNING_PATTERN_MISMATCH",
                message="Local detuning pattern does not match all active sites.",
                object_path=f"{path}.addressing.site_ids",
                suggestion="Provide exactly one pattern entry per active site.",
            )
        elif pattern_site_ids != active_site_ids:
            yield _diagnostic(
                code="LOCAL_DETUNING_PATTERN_ORDER_MISMATCH",
                message="Local detuning pattern order does not match register order.",
                object_path=f"{path}.addressing.site_ids",
                suggestion="Store pattern entries in active register order.",
            )
        waveform = term.waveform
        if waveform.duration != global_duration:
            yield _diagnostic(
                code="LOCAL_DETUNING_DURATION_MISMATCH",
                message=(
                    f"Local detuning duration {waveform.duration} does not match "
                    f"global duration {global_duration}."
                ),
                object_path=f"{path}.waveform.duration",
                suggestion="Use one duration for the global and local controls.",
            )
        if waveform.value_unit != global_detuning.value_unit:
            yield _diagnostic(
                code="LOCAL_DETUNING_VALUE_UNIT_MISMATCH",
                message="Local and global detuning value units do not match.",
                object_path=f"{path}.waveform.value_unit",
                suggestion="Use value_unit='rad/us' for both detuning waveforms.",
            )
        if waveform.time_unit != global_detuning.time_unit:
            yield _diagnostic(
                code="LOCAL_DETUNING_TIME_UNIT_MISMATCH",
                message="Local and global detuning time units do not match.",
                object_path=f"{path}.waveform.time_unit",
                suggestion="Use time_unit='us' for both detuning waveforms.",
            )
        yield from _validate_waveform(
            waveform, target, f"local_detuning_terms[{index}].waveform"
        )
        yield from _validate_site_addressing(
            term.addressing,
            target,
            operation="local_detuning",
            control_label="Local detuning",
            code_prefix="LOCAL_DETUNING",
            path=f"{path}.addressing",
            expected_duration=global_duration,
            operation_supported=operation_supported,
        )


def _validate_local_rabi(
    program: ProgramIR,
    target: TargetSpec,
) -> Iterable[DiagnosticsIR]:
    terms = program.hamiltonian.local_rabi_terms
    if not terms:
        return
    typed = target.typed_capabilities
    status = (
        typed.analog_status("local_rabi")
        if typed is not None
        else target.capabilities.get("local_rabi")
    )
    if status not in ("supported", "experimental"):
        yield _diagnostic(
            code="LOCAL_RABI_CAPABILITY_UNSUPPORTED",
            message=f"Target {target.target_id!r} does not support local Rabi.",
            object_path="hamiltonian.terms.local_rabi_terms",
            suggestion="Use a target with experimental local Rabi support.",
        )
    operation_supported = status in ("supported", "experimental")
    active_site_ids = program.register.active_site_ids
    global_duration = max(
        program.hamiltonian.rabi.duration,
        program.hamiltonian.detuning.duration,
    )
    for index, term in enumerate(terms):
        path = f"hamiltonian.terms.local_rabi_terms[{index}]"
        if term.addressing.site_ids != active_site_ids:
            yield _diagnostic(
                code="LOCAL_RABI_PATTERN_ORDER_MISMATCH",
                message="Local Rabi pattern must match active register order exactly.",
                object_path=f"{path}.addressing.site_ids",
                suggestion="Project the pattern through AHSProgram.local_rabi().",
            )
        if term.phase_pattern.site_ids != active_site_ids:
            yield _diagnostic(
                code="LOCAL_RABI_PHASE_PATTERN_ORDER_MISMATCH",
                message=(
                    "Local Rabi phase pattern must match active register order "
                    "exactly."
                ),
                object_path=f"{path}.phase_pattern.site_ids",
                suggestion="Project the phase pattern through AHSProgram.local_rabi().",
            )
        has_patterned_phase = any(
            offset != 0.0 for offset in term.phase_pattern.offsets
        )
        phase_pattern_status = target.capabilities.get(
            "local_rabi_phase_pattern",
            "unsupported",
        )
        if has_patterned_phase and phase_pattern_status not in (
            "supported",
            "experimental",
        ):
            yield _diagnostic(
                code="LOCAL_RABI_PHASE_PATTERN_UNSUPPORTED",
                message=(
                    f"Target {target.target_id!r} does not support local Rabi "
                    "phase patterns."
                ),
                object_path=f"{path}.phase_pattern",
                suggestion="Use a target with patterned local phase support.",
            )
        if term.rabi.duration != global_duration:
            yield _diagnostic(
                code="LOCAL_RABI_DURATION_MISMATCH",
                message="Local Rabi duration must match the global duration.",
                object_path=f"{path}.rabi.duration",
                suggestion="Use one duration for global and local controls.",
            )
        yield from _validate_waveform(
            term.rabi, target, f"local_rabi_terms[{index}].rabi"
        )
        if isinstance(term.phase, WaveformIR):
            if term.phase.duration != global_duration:
                yield _diagnostic(
                    code="LOCAL_RABI_PHASE_DURATION_MISMATCH",
                    message="Local Rabi phase duration must match global duration.",
                    object_path=f"{path}.phase.duration",
                    suggestion="Use one duration for amplitude and phase.",
                )
            yield from _validate_waveform(
                term.phase, target, f"local_rabi_terms[{index}].phase"
            )
        yield from _validate_site_phase_pattern(term, target, path=path)
        yield from _validate_site_addressing(
            term.addressing,
            target,
            operation="local_rabi",
            control_label="Local Rabi",
            code_prefix="LOCAL_RABI",
            path=f"{path}.addressing",
            expected_duration=global_duration,
            operation_supported=operation_supported,
        )


def _validate_site_addressing(
    addressing: SiteAddressingIR,
    target: TargetSpec,
    *,
    operation: str,
    control_label: str,
    code_prefix: str,
    path: str,
    expected_duration: float,
    operation_supported: bool,
) -> Iterable[DiagnosticsIR]:
    """Recheck serialized addressing invariants before allocation or compile."""
    duration = addressing.duration
    duration_valid = (
        isinstance(duration, (int, float))
        and not isinstance(duration, bool)
        and math.isfinite(float(duration))
        and float(duration) > 0.0
    )
    if not duration_valid or float(duration) != expected_duration:
        yield _diagnostic(
            code=f"{code_prefix}_ADDRESSING_DURATION_MISMATCH",
            message=(
                f"{control_label} addressing duration must match the control "
                "duration."
            ),
            object_path=f"{path}.duration",
            suggestion="Use one duration for the local waveform and addressing.",
            metadata={
                "addressing_duration": duration,
                "expected_duration": expected_duration,
            },
        )

    times = addressing.times
    times_valid = (
        isinstance(times, tuple)
        and bool(times)
        and all(
            isinstance(value, (int, float))
            and not isinstance(value, bool)
            and math.isfinite(float(value))
            for value in times
        )
    )
    numeric_times = tuple(float(value) for value in times) if times_valid else ()
    if (
        not times_valid
        or numeric_times[0] != 0.0
        or any(
            right <= left for left, right in zip(numeric_times, numeric_times[1:])
        )
        or not duration_valid
        or any(value < 0.0 or value >= float(duration) for value in numeric_times)
    ):
        yield _diagnostic(
            code=f"{code_prefix}_ADDRESSING_TIME_GRID_INVALID",
            message=f"{control_label} addressing frame times are invalid.",
            object_path=f"{path}.times",
            suggestion=(
                "Start at 0.0 and use strictly increasing frame times below "
                "the addressing duration."
            ),
            metadata={
                "duration": duration,
                "times": list(times) if isinstance(times, tuple) else times,
            },
        )

    weights = addressing.weights
    weights_valid = (
        isinstance(weights, tuple)
        and len(weights) == len(times)
        and all(
            isinstance(frame, tuple)
            and len(frame) == len(addressing.site_ids)
            and all(
                isinstance(weight, (int, float))
                and not isinstance(weight, bool)
                and math.isfinite(float(weight))
                and 0.0 <= float(weight) <= 1.0
                for weight in frame
            )
            for frame in weights
        )
        and any(float(weight) > 0.0 for frame in weights for weight in frame)
    )
    source_valid = addressing.source_kind in {"site_pattern", "site_mask"}
    if addressing.source_kind == "site_pattern":
        weights_valid = weights_valid and len(times) == 1
    elif addressing.source_kind == "site_mask":
        weights_valid = weights_valid and all(
            float(weight) in {0.0, 1.0}
            for frame in weights
            for weight in frame
        )
    if not source_valid or not weights_valid:
        yield _diagnostic(
            code=f"{code_prefix}_ADDRESSING_WEIGHTS_INVALID",
            message=f"{control_label} addressing weights are invalid.",
            object_path=f"{path}.weights",
            suggestion=(
                "Use one finite [0, 1] weight per site and frame; mask weights "
                "must be binary."
            ),
            metadata={
                "source_kind": addressing.source_kind,
                "frame_count": len(weights) if isinstance(weights, tuple) else None,
                "site_count": len(addressing.site_ids),
            },
        )

    if addressing.time_unit != target.time_unit or addressing.interpolation != "step":
        yield _diagnostic(
            code=f"{code_prefix}_ADDRESSING_SEMANTICS_UNSUPPORTED",
            message=f"{control_label} addressing units or interpolation are invalid.",
            object_path=path,
            suggestion="Use time_unit='us' and interpolation='step'.",
            metadata={
                "time_unit": addressing.time_unit,
                "interpolation": addressing.interpolation,
            },
        )

    required_addressing = _required_addressing_mode(addressing)
    supported_addressing, mask_interpolation = _target_addressing_modes(
        target,
        operation,
    )
    if operation_supported and (
        required_addressing not in supported_addressing
        or (
            addressing.source_kind == "site_mask"
            and mask_interpolation != addressing.interpolation
        )
    ):
        yield _diagnostic(
            code=f"{code_prefix}_ADDRESSING_CAPABILITY_UNSUPPORTED",
            message=(
                f"Target {target.target_id!r} does not support "
                f"{required_addressing!r} for {control_label.lower()}."
            ),
            object_path=path,
            suggestion="Use a target that declares the required addressing mode.",
            metadata={
                "required_addressing": required_addressing,
                "supported_addressing": list(supported_addressing),
                "required_interpolation": addressing.interpolation,
                "supported_interpolation": mask_interpolation,
            },
        )


def _required_addressing_mode(addressing: SiteAddressingIR) -> str:
    if addressing.source_kind == "site_pattern":
        return "site_pattern_static"
    return "site_mask_piecewise" if addressing.is_dynamic else "site_mask_static"


def _target_addressing_modes(
    target: TargetSpec,
    operation: str,
) -> tuple[tuple[str, ...], str | None]:
    typed = target.typed_capabilities
    if typed is not None:
        for capability in typed.analog_operations:
            if capability.operation == operation:
                interpolation = capability.metadata.get("mask_interpolation")
                return capability.addressing, (
                    str(interpolation) if interpolation is not None else None
                )
        return (), None
    raw_modes = target.capabilities.get(f"{operation}_addressing", ())
    modes = (
        tuple(str(item) for item in raw_modes)
        if isinstance(raw_modes, (list, tuple))
        else ()
    )
    interpolation = target.capabilities.get("mask_interpolation")
    return modes, str(interpolation) if interpolation is not None else None


def _validate_register(
    program: ProgramIR,
    target: TargetSpec,
) -> Iterable[DiagnosticsIR]:
    sites = program.register.active_sites
    convention = program.bit_ordering.get("convention")
    if convention != ANALOG_BIT_ORDER_CONVENTION:
        yield _diagnostic(
            code="ANALOG_BIT_ORDER_UNSUPPORTED",
            message=(
                "Analog execution currently requires active register declaration "
                "order."
            ),
            object_path="bit_ordering.convention",
            suggestion=(
                f"Use convention='{ANALOG_BIT_ORDER_CONVENTION}' and interpret "
                "bitstrings using the reported active atom order."
            ),
            metadata={
                "actual_convention": convention,
                "required_convention": ANALOG_BIT_ORDER_CONVENTION,
                "active_atom_ids": list(program.register.active_atom_ids),
            },
        )
    if not sites:
        yield _diagnostic(
            code="REGISTER_NO_ACTIVE_ATOMS",
            message="Register snapshot has no filled target sites to execute.",
            object_path="register.sites",
            suggestion="Use a snapshot with at least one filled target site.",
        )
    if len(sites) > target.max_atoms:
        yield _diagnostic(
            code="ATOM_COUNT_EXCEEDED",
            message=(
                f"Atom count {len(sites)} exceeds target maximum {target.max_atoms}."
            ),
            object_path="register.sites",
            suggestion="Reduce the number of filled atom sites.",
        )

    region = target.programmable_region
    for site in sites:
        x, y = site.position
        in_x_range = region.x_min <= x <= region.x_max
        in_y_range = region.y_min <= y <= region.y_max
        if not (in_x_range and in_y_range):
            yield _diagnostic(
                code="ATOM_OUT_OF_REGION",
                message=f"Atom {site.atom_id} is outside the programmable region.",
                object_path=f"register.sites[{site.site_id}].position",
                suggestion="Move the atom inside the target programmable region.",
            )

    for left_index, left in enumerate(sites):
        for right in sites[left_index + 1 :]:
            distance = math.dist(left.position, right.position)
            if distance < target.min_atom_spacing:
                yield _diagnostic(
                    code="ATOM_SPACING_TOO_SMALL",
                    message=(
                        f"Atoms {left.atom_id} and {right.atom_id} are separated by "
                        f"{distance}, below {target.min_atom_spacing}."
                    ),
                    object_path="register.sites",
                    suggestion="Increase atom spacing or remove one atom.",
                )


def _validate_waveform(
    waveform: WaveformIR,
    target: TargetSpec,
    field_name: str,
) -> Iterable[DiagnosticsIR]:
    if waveform.kind not in target.supported_waveforms:
        yield _diagnostic(
            code="WAVEFORM_KIND_UNSUPPORTED",
            message=f"Waveform kind {waveform.kind!r} is not supported.",
            object_path=f"hamiltonian.terms.{field_name}.kind",
            suggestion="Use a supported waveform kind.",
        )

    if waveform.kind == "interpolated":
        # Builder-created PCHIP waveforms already satisfy these invariants. Keep
        # the checks here as the trust boundary for hand-written or restored IR.
        if waveform.times is None:
            yield _diagnostic(
                code="WAVEFORM_INTERPOLATION_TIMES_REQUIRED",
                message=f"{field_name} interpolated waveform requires sample times.",
                object_path=f"hamiltonian.terms.{field_name}.times",
                suggestion="Provide finite samples from 0.0 through duration.",
            )
        elif len(waveform.times) < 2:
            yield _diagnostic(
                code="WAVEFORM_INTERPOLATION_POINT_COUNT_INVALID",
                message=(
                    f"{field_name} interpolated waveform requires at least two samples."
                ),
                object_path=f"hamiltonian.terms.{field_name}.times",
                suggestion="Provide at least two time/value samples.",
            )
        elif waveform.times[0] != 0.0:
            yield _diagnostic(
                code="WAVEFORM_INTERPOLATION_START_INVALID",
                message=f"{field_name} interpolated waveform must start at 0.0.",
                object_path=f"hamiltonian.terms.{field_name}.times[0]",
                suggestion="Set the first sample time to 0.0.",
            )
        if waveform.values is None:
            yield _diagnostic(
                code="WAVEFORM_INTERPOLATION_VALUES_REQUIRED",
                message=f"{field_name} interpolated waveform requires bound values.",
                object_path=f"hamiltonian.terms.{field_name}.values",
                suggestion="Bind every waveform sample before validation.",
            )

    min_duration, max_duration = _duration_range(target)
    if not (min_duration <= waveform.duration <= max_duration):
        yield _diagnostic(
            code="WAVEFORM_DURATION_OUT_OF_RANGE",
            message=(
                f"{field_name} duration {waveform.duration} is outside "
                f"[{min_duration}, {max_duration}]."
            ),
            object_path=f"hamiltonian.terms.{field_name}.duration",
            suggestion="Choose a duration within the target supported range.",
        )

    if waveform.times is not None:
        if len(waveform.times) == 0:
            yield _diagnostic(
                code="WAVEFORM_TIMES_EMPTY",
                message=f"{field_name} waveform times must not be empty.",
                object_path=f"hamiltonian.terms.{field_name}.times",
                suggestion=(
                    "Provide at least one time sample or use a constant waveform."
                ),
            )
        if waveform.values is not None and len(waveform.times) != len(waveform.values):
            yield _diagnostic(
                code="WAVEFORM_TIMES_VALUES_LENGTH_MISMATCH",
                message=f"{field_name} waveform times and values lengths differ.",
                object_path=f"hamiltonian.terms.{field_name}",
                suggestion="Provide the same number of time and value samples.",
            )
        if waveform.times and abs(waveform.times[-1] - waveform.duration) > 1e-12:
            yield _diagnostic(
                code="WAVEFORM_ENDPOINT_DURATION_MISMATCH",
                message=(
                    f"{field_name} final time {waveform.times[-1]} does not match "
                    f"duration {waveform.duration}."
                ),
                object_path=f"hamiltonian.terms.{field_name}.times",
                suggestion="Make the final waveform time equal to duration.",
            )
        for index, (left, right) in enumerate(zip(waveform.times, waveform.times[1:])):
            if right <= left:
                yield _diagnostic(
                    code="WAVEFORM_TIMES_NOT_MONOTONIC",
                    message=f"{field_name} waveform times are not strictly increasing.",
                    object_path=f"hamiltonian.terms.{field_name}.times[{index + 1}]",
                    suggestion="Sort waveform times in strictly increasing order.",
                )
                break

    if field_name == "rabi" or field_name.endswith(".rabi"):
        value_range = target.rabi_range
    elif field_name == "phase" or field_name.endswith(".phase"):
        value_range = target.phase_range
    else:
        value_range = target.detuning_range
    for value_index, value in enumerate(_waveform_values(waveform)):
        if not (value_range[0] <= value <= value_range[1]):
            yield _diagnostic(
                code="WAVEFORM_VALUE_OUT_OF_RANGE",
                message=(
                    f"{field_name} value {value} is outside "
                    f"[{value_range[0]}, {value_range[1]}]."
                ),
                object_path=f"hamiltonian.terms.{field_name}.values[{value_index}]",
                suggestion="Choose waveform values within the target supported range.",
            )


def _validate_phase(
    program: ProgramIR,
    target: TargetSpec,
) -> Iterable[DiagnosticsIR]:
    phase = program.hamiltonian.phase
    if isinstance(phase, WaveformIR):
        yield from _validate_waveform(phase, target, "phase")
        values = _waveform_values(phase)
    else:
        values = (phase,)

    for value_index, value in enumerate(values):
        if not (target.phase_range[0] <= value <= target.phase_range[1]):
            yield _diagnostic(
                code="PHASE_OUT_OF_RANGE",
                message=(
                    f"phase value {value} is outside "
                    f"[{target.phase_range[0]}, {target.phase_range[1]}]."
                ),
                object_path=f"hamiltonian.terms.phase.values[{value_index}]",
                suggestion="Choose phase values within the target supported range.",
            )


def _validate_site_phase_pattern(
    term: LocalRabiIR,
    target: TargetSpec,
    *,
    path: str,
) -> Iterable[DiagnosticsIR]:
    """Validate offsets and the resulting per-site phases without wrapping."""
    shared_values = (
        _waveform_values(term.phase)
        if isinstance(term.phase, WaveformIR)
        else (float(term.phase),)
    )
    lower, upper = target.phase_range
    for site_index, (site_id, offset) in enumerate(
        zip(term.phase_pattern.site_ids, term.phase_pattern.offsets)
    ):
        offset_path = f"{path}.phase_pattern.offsets[{site_index}]"
        if not lower <= offset <= upper:
            yield _diagnostic(
                code="LOCAL_RABI_PHASE_OFFSET_OUT_OF_RANGE",
                message=(
                    f"Local Rabi phase offset {offset} for site {site_id!r} is "
                    f"outside [{lower}, {upper}]."
                ),
                object_path=offset_path,
                suggestion="Choose a phase offset within the target range.",
            )
        for value_index, shared_phase in enumerate(shared_values):
            site_phase = shared_phase + offset
            if not lower <= site_phase <= upper:
                yield _diagnostic(
                    code="LOCAL_RABI_SITE_PHASE_OUT_OF_RANGE",
                    message=(
                        f"Local Rabi site phase {site_phase} for site {site_id!r} "
                        f"is outside [{lower}, {upper}]."
                    ),
                    object_path=(
                        f"{offset_path}.combined_with_shared_phase[{value_index}]"
                    ),
                    suggestion=(
                        "Adjust the shared phase or site offset; phases are not "
                        "wrapped automatically."
                    ),
                )


def _validate_measurements(
    program: ProgramIR,
    target: TargetSpec,
) -> Iterable[DiagnosticsIR]:
    active_atom_ids = program.register.active_atom_ids
    active_atom_set = set(active_atom_ids)
    for index, measurement in enumerate(program.measurements):
        if measurement.basis not in target.supported_measurement_basis:
            yield _diagnostic(
                code="MEASUREMENT_BASIS_UNSUPPORTED",
                message=f"Measurement basis {measurement.basis!r} is not supported.",
                object_path=f"measurements[{index}].basis",
                suggestion="Use a target-supported measurement basis.",
            )
        if measurement.targets == "all":
            continue
        targets = measurement.targets
        if not targets:
            yield _diagnostic(
                code="MEASUREMENT_TARGETS_EMPTY",
                message="Analog measurement targets must not be empty.",
                object_path=f"measurements[{index}].targets",
                suggestion="Use 'all' or list every active atom in register order.",
            )
            continue
        if len(set(targets)) != len(targets):
            yield _diagnostic(
                code="MEASUREMENT_TARGET_DUPLICATE",
                message="Analog measurement targets must be unique.",
                object_path=f"measurements[{index}].targets",
                suggestion="Remove duplicate atom ids.",
            )
        invalid_targets = tuple(
            target for target in targets if target not in active_atom_set
        )
        if invalid_targets:
            yield _diagnostic(
                code="MEASUREMENT_TARGET_INACTIVE",
                message="Analog measurement may target only filled target atoms.",
                object_path=f"measurements[{index}].targets",
                suggestion=(
                    "Measure active atom ids from the selected register snapshot."
                ),
                metadata={
                    "invalid_targets": list(invalid_targets),
                    "active_atom_ids": list(active_atom_ids),
                    "register_snapshot_id": program.register.snapshot_id,
                },
            )
        elif targets != active_atom_ids:
            yield _diagnostic(
                code="MEASUREMENT_TARGET_ORDER_UNSUPPORTED",
                message=(
                    "Analog terminal measurement must follow the complete active atom "
                    "order."
                ),
                object_path=f"measurements[{index}].targets",
                suggestion=(
                    "Use targets='all' or the active atom ids in register order."
                ),
                metadata={"active_atom_ids": list(active_atom_ids)},
            )


def _validate_shots(shots: int, target: TargetSpec) -> Iterable[DiagnosticsIR]:
    lower, upper = target.shots_range
    if not (lower <= shots <= upper):
        yield _diagnostic(
            code="SHOTS_OUT_OF_RANGE",
            message=f"shots {shots} is outside [{lower}, {upper}].",
            object_path="shots",
            suggestion="Choose a shot count within the target supported range.",
        )


def _waveform_values(waveform: WaveformIR) -> tuple[float, ...]:
    if waveform.values is not None:
        return waveform.values
    if "value" in waveform.parameters:
        return (float(waveform.parameters["value"]),)
    if "bound_value" in waveform.parameters:
        return (float(waveform.parameters["bound_value"]),)
    return ()


def _validate_parameters(program: ProgramIR) -> Iterable[DiagnosticsIR]:
    declarations = program.parameter_schema.parameters
    seen: set[str] = set()
    for parameter in declarations:
        if parameter.name in seen:
            yield _diagnostic(
                code="PARAMETER_DUPLICATE",
                message=f"Parameter {parameter.name!r} is declared more than once.",
                object_path="parameter_schema.parameters",
                suggestion="Use unique parameter names.",
            )
        seen.add(parameter.name)
        value = program.parameters.get(parameter.name, parameter.default)
        if parameter.default is None and parameter.expression is None and value is None:
            yield _diagnostic(
                code="PARAMETER_VALUE_MISSING",
                message=f"Required parameter {parameter.name!r} is not bound.",
                object_path=f"parameters.{parameter.name}",
                suggestion="Bind the parameter before validation or provide a default.",
            )
            continue
        if value is None:
            continue
        numeric_value = float(value)
        if parameter.lower_bound is not None and numeric_value < parameter.lower_bound:
            yield _diagnostic(
                code="PARAMETER_VALUE_OUT_OF_RANGE",
                message=(
                    f"Parameter {parameter.name!r} value {numeric_value} is below "
                    f"{parameter.lower_bound}."
                ),
                object_path=f"parameters.{parameter.name}",
                suggestion="Choose a value inside the declared parameter range.",
            )
        if parameter.upper_bound is not None and numeric_value > parameter.upper_bound:
            yield _diagnostic(
                code="PARAMETER_VALUE_OUT_OF_RANGE",
                message=(
                    f"Parameter {parameter.name!r} value {numeric_value} is above "
                    f"{parameter.upper_bound}."
                ),
                object_path=f"parameters.{parameter.name}",
                suggestion="Choose a value inside the declared parameter range.",
            )

    declared_names = {parameter.name for parameter in declarations}
    for path, name in _parameter_references(program):
        if name not in declared_names:
            yield _diagnostic(
                code="PARAMETER_REFERENCE_UNDECLARED",
                message=f"Waveform references undeclared parameter {name!r}.",
                object_path=path,
                suggestion="Declare the parameter in the program parameter schema.",
            )
            continue
        declaration = program.parameter_schema.by_name()[name]
        if name not in program.parameters and declaration.default is None:
            yield _diagnostic(
                code="PARAMETER_VALUE_MISSING",
                message=f"Waveform parameter {name!r} is not bound.",
                object_path=path,
                suggestion="Bind the parameter before target validation.",
            )


def _parameter_references(
    program: ProgramIR,
) -> Iterable[tuple[str, str]]:
    waveforms = (
        (
            "hamiltonian.terms.rabi.parameters.value_expression",
            program.hamiltonian.rabi,
        ),
        (
            "hamiltonian.terms.detuning.parameters.value_expression",
            program.hamiltonian.detuning,
        ),
    )
    for path, waveform in waveforms:
        expression = _value_expression(waveform)
        if expression is not None:
            yield from ((path, name) for name in expression.dependencies)
    for index, detuning_term in enumerate(program.hamiltonian.local_detuning_terms):
        expression = _value_expression(detuning_term.waveform)
        if expression is not None:
            yield from (
                (
                    f"hamiltonian.terms.local_detuning_terms[{index}].waveform.parameters.value_expression",
                    name,
                )
                for name in expression.dependencies
            )
    for index, rabi_term in enumerate(program.hamiltonian.local_rabi_terms):
        expression = _value_expression(rabi_term.rabi)
        if expression is not None:
            yield from (
                (
                    f"hamiltonian.terms.local_rabi_terms[{index}].rabi.parameters.value_expression",
                    name,
                )
                for name in expression.dependencies
            )
        if isinstance(rabi_term.phase, WaveformIR):
            expression = _value_expression(rabi_term.phase)
            if expression is not None:
                yield from (
                    (
                        f"hamiltonian.terms.local_rabi_terms[{index}].phase.parameters.value_expression",
                        name,
                    )
                    for name in expression.dependencies
                )
    phase = program.hamiltonian.phase
    if isinstance(phase, WaveformIR):
        expression = _value_expression(phase)
        if expression is not None:
            yield from (
                ("hamiltonian.terms.phase.parameters.value_expression", name)
                for name in expression.dependencies
            )


def _value_expression(waveform: WaveformIR) -> Expression | None:
    expression = waveform.parameters.get("value_expression")
    if isinstance(expression, Expression):
        return expression
    if isinstance(expression, dict):
        return Expression.from_dict(expression)
    return None


def _duration_range(target: TargetSpec) -> tuple[float, float]:
    value = target.metadata.get("duration_range", [0.0, float("inf")])
    return (float(value[0]), float(value[1]))


def _diagnostic(
    *,
    code: str,
    message: str,
    object_path: str,
    suggestion: str,
    metadata: dict[str, Any] | None = None,
) -> DiagnosticsIR:
    return DiagnosticsIR(
        diagnostic_id=f"validation.{code.lower()}",
        stage="validation",
        severity="error",
        code=code,
        message=message,
        object_path=object_path,
        suggestion=suggestion,
        metadata={} if metadata is None else metadata,
    )
