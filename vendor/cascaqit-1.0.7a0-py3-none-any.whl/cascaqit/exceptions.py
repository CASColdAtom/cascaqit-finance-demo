"""Stable SDK exception boundary for CASCAQit."""

from __future__ import annotations

import hashlib
from typing import Any

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.errors import (
    ErrorCategory,
    ErrorIR,
    ErrorSeverity,
    diagnostic_from_error,
)
from cascaqit.native_ir.base import stable_json
from cascaqit.readiness.audit import redact_audit_metadata

__all__ = [
    "BackendExecutionError",
    "CASCAQitConfigurationError",
    "CASCAQitError",
    "CASCAQitRuntimeError",
    "CASCAQitValueError",
    "CapabilityError",
    "ErrorCategory",
    "ErrorSeverity",
    "ProgramValidationError",
    "SerializationError",
    "error_from_exception",
]


class CASCAQitError(Exception):
    """Base class for structured CASCAQit SDK errors."""

    category: ErrorCategory = "unknown"
    severity: ErrorSeverity = "error"
    default_code = "CASCAQIT_ERROR"
    default_stage: str | None = None
    default_suggestion: str | None = None
    default_retryable = False

    def __init__(
        self,
        message: str,
        *,
        code: str | None = None,
        stage: str | None = None,
        object_path: str | None = None,
        suggestion: str | None = None,
        retryable: bool | None = None,
        error_id: str | None = None,
        trace_references: dict[str, Any] | None = None,
        source_hashes: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
        diagnostics: tuple[DiagnosticsIR, ...] = (),
        cause: BaseException | None = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.code = code or self.default_code
        self.stage = stage if stage is not None else self.default_stage
        self.object_path = object_path
        self.suggestion = (
            suggestion if suggestion is not None else self.default_suggestion
        )
        self.retryable = (
            retryable if retryable is not None else self.default_retryable
        )
        self.error_id = error_id or _default_error_id(self.category, self.code)
        self.trace_references = (
            {} if trace_references is None else dict(trace_references)
        )
        self.source_hashes = {} if source_hashes is None else dict(source_hashes)
        self.metadata = redact_audit_metadata({} if metadata is None else metadata)
        self.diagnostics = diagnostics
        self.cause = cause

    def to_error_ir(self) -> ErrorIR:
        """Return this exception as a structured ErrorIR."""
        metadata = {
            "builder": "CASCAQitError.to_error_ir",
            "exception_type": type(self).__name__,
            **self.metadata,
        }
        if self.cause is not None:
            metadata["cause_type"] = type(self.cause).__name__
            metadata["cause_message"] = str(self.cause)
        return ErrorIR(
            error_id=self.error_id,
            category=self.category,
            severity=self.severity,
            code=self.code,
            message=self.message,
            stage=self.stage,
            object_path=self.object_path,
            suggestion=self.suggestion,
            retryable=self.retryable,
            trace_references=self.trace_references,
            source_hashes=self.source_hashes,
            source={
                "source_kind": "CASCAQitError",
                "source_id": type(self).__name__,
                "source_hash": _source_hash(
                    {
                        "exception_type": type(self).__name__,
                        "code": self.code,
                        "message": self.message,
                    }
                ),
            },
            diagnostics=self.diagnostics,
            metadata=metadata,
        )

    def to_diagnostic(self) -> DiagnosticsIR:
        """Return this exception as a DiagnosticsIR projection."""
        return diagnostic_from_error(self.to_error_ir())


class CASCAQitValueError(ValueError, CASCAQitError):
    """CASCAQitError that remains catchable as ValueError."""

    __init__ = CASCAQitError.__init__


class CASCAQitRuntimeError(RuntimeError, CASCAQitError):
    """CASCAQitError that remains catchable as RuntimeError."""

    __init__ = CASCAQitError.__init__


class ProgramValidationError(CASCAQitValueError):
    """Program or payload validation failure."""

    category = "validation"
    default_code = "PROGRAM_VALIDATION_ERROR"
    default_stage = "validation"


class CASCAQitConfigurationError(CASCAQitValueError):
    """Configuration failure."""

    category = "configuration"
    default_code = "CONFIGURATION_ERROR"
    default_stage = "configuration"


class CapabilityError(CASCAQitValueError):
    """Unsupported capability or target feature."""

    category = "capability"
    default_code = "CAPABILITY_ERROR"
    default_stage = "validation"


class SerializationError(CASCAQitValueError):
    """Serialization or schema boundary failure."""

    category = "serialization"
    default_code = "SERIALIZATION_ERROR"
    default_stage = "serialization"


class BackendExecutionError(CASCAQitRuntimeError):
    """Backend, hardware adapter, or cloud execution failure."""

    category = "backend"
    default_code = "BACKEND_EXECUTION_ERROR"
    default_stage = "backend"
    default_retryable = False


def error_from_exception(
    exc: BaseException,
    *,
    code: str | None = None,
    category: ErrorCategory = "runtime",
    stage: str | None = "runtime",
    object_path: str | None = None,
    suggestion: str | None = None,
    retryable: bool = False,
    metadata: dict[str, Any] | None = None,
) -> ErrorIR:
    """Convert any exception into ErrorIR without changing raise behavior."""
    if isinstance(exc, CASCAQitError):
        return exc.to_error_ir()
    return ErrorIR(
        error_id=_default_error_id(category, code or type(exc).__name__.upper()),
        category=category,
        severity="error",
        code=code or type(exc).__name__.upper(),
        message=str(exc) or type(exc).__name__,
        stage=stage,
        object_path=object_path,
        suggestion=suggestion,
        retryable=retryable,
        source={
            "source_kind": "Exception",
            "source_id": type(exc).__name__,
            "source_hash": _source_hash(
                {
                    "exception_type": type(exc).__name__,
                    "message": str(exc) or type(exc).__name__,
                }
            ),
        },
        metadata={
            "builder": "error_from_exception",
            "exception_type": type(exc).__name__,
            **({} if metadata is None else metadata),
        },
    )


def _default_error_id(category: str, code: str) -> str:
    normalized = code.lower().replace("_", ".").replace(" ", ".")
    return f"error.{category}.{normalized}"


def _source_hash(payload: dict[str, Any]) -> str:
    return hashlib.sha256(stable_json(payload).encode("utf-8")).hexdigest()
