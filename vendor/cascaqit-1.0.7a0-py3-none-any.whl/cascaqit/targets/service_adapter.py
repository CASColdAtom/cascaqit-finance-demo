"""Offline target/calibration service adapter SPI placeholders."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Literal, Protocol

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.native_ir.base import IRMixin, canonicalize
from cascaqit.native_ir.models import SCHEMA_VERSION
from cascaqit.targets.models import CalibrationSnapshot, TargetSnapshot
from cascaqit.targets.registry import (
    CalibrationFreshnessIR,
    TargetCalibrationRegistry,
    TargetCalibrationSelectionIR,
)

__all__ = [
    "FixtureReplayTargetCalibrationServiceAdapter",
    "TargetCalibrationServiceAdapterProtocol",
    "TargetCalibrationServiceReadinessIR",
    "build_target_calibration_service_readiness",
]

TargetCalibrationServiceStatus = Literal[
    "offline_fixture",
    "ready",
    "unavailable",
]


class TargetCalibrationServiceAdapterProtocol(Protocol):
    """Future service SPI for target and calibration metadata snapshots."""

    def get_target_snapshot(
        self,
        *,
        target_id: str,
        target_version: str | None = None,
    ) -> TargetSnapshot:
        """Return an immutable target snapshot envelope."""

    def get_calibration_snapshot(
        self,
        *,
        target_id: str | None = None,
        calibration_profile_id: str | None = None,
    ) -> CalibrationSnapshot:
        """Return an immutable calibration snapshot envelope."""

    def select_pair(
        self,
        *,
        target_id: str,
        target_version: str | None = None,
        calibration_profile_id: str | None = None,
        checked_at: str | None = None,
    ) -> TargetCalibrationSelectionIR:
        """Return target/calibration selection diagnostics."""

    def readiness(
        self,
        *,
        target_id: str,
        target_version: str | None = None,
        calibration_profile_id: str | None = None,
        checked_at: str | None = None,
    ) -> TargetCalibrationServiceReadinessIR:
        """Return service readiness without remote access."""


@dataclass(frozen=True)
class TargetCalibrationServiceReadinessIR(IRMixin):
    """Public readiness report for target/calibration service adapters."""

    readiness_id: str
    service_name: str
    status: TargetCalibrationServiceStatus
    target_id: str
    compatible: bool
    diagnostics: tuple[DiagnosticsIR, ...]
    target_snapshot_hash: str | None = None
    calibration_snapshot_hash: str | None = None
    calibration_profile_id: str | None = None
    calibration_freshness: CalibrationFreshnessIR | None = None
    remote_fetch_enabled: bool = False
    network_accessed: bool = False
    snapshot_hash_verified: bool = False
    offline_fallback_used: bool = True
    raw_secret_loaded: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Enforce offline service adapter boundaries."""
        if self.remote_fetch_enabled:
            raise ValueError("Target/calibration service readiness is offline-only.")
        if self.network_accessed:
            raise ValueError("Target/calibration service readiness cannot use network.")
        if self.raw_secret_loaded:
            raise ValueError(
                "Target/calibration service readiness cannot load secrets."
            )
        object.__setattr__(
            self,
            "diagnostics",
            tuple(_diagnostic_from_any(item) for item in self.diagnostics),
        )
        if self.calibration_freshness is not None and not isinstance(
            self.calibration_freshness,
            CalibrationFreshnessIR,
        ):
            raise TypeError("calibration_freshness must be CalibrationFreshnessIR.")
        object.__setattr__(self, "metadata", _redact_mapping(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TargetCalibrationServiceReadinessIR:
        """Build target/calibration service readiness from a dictionary."""
        freshness_data = data.get("calibration_freshness")
        return cls(
            readiness_id=str(data["readiness_id"]),
            service_name=str(data["service_name"]),
            status=data["status"],
            target_id=str(data["target_id"]),
            compatible=bool(data["compatible"]),
            diagnostics=tuple(
                _diagnostic_from_any(item) for item in data.get("diagnostics", ())
            ),
            target_snapshot_hash=data.get("target_snapshot_hash"),
            calibration_snapshot_hash=data.get("calibration_snapshot_hash"),
            calibration_profile_id=data.get("calibration_profile_id"),
            calibration_freshness=None
            if freshness_data is None
            else CalibrationFreshnessIR.from_dict(freshness_data),
            remote_fetch_enabled=bool(data.get("remote_fetch_enabled", False)),
            network_accessed=bool(data.get("network_accessed", False)),
            snapshot_hash_verified=bool(data.get("snapshot_hash_verified", False)),
            offline_fallback_used=bool(data.get("offline_fallback_used", True)),
            raw_secret_loaded=bool(data.get("raw_secret_loaded", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> TargetCalibrationServiceReadinessIR:
        """Build target/calibration service readiness from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError(
                "TargetCalibrationServiceReadinessIR JSON must be an object."
            )
        return cls.from_dict(data)


class FixtureReplayTargetCalibrationServiceAdapter:
    """Offline adapter backed by TargetCalibrationRegistry fixtures."""

    def __init__(
        self,
        *,
        registry: TargetCalibrationRegistry,
        service_name: str = "fixture_replay_target_calibration_service",
        service_available: bool = True,
    ) -> None:
        self.registry = registry
        self.service_name = service_name
        self.service_available = service_available

    def get_target_snapshot(
        self,
        *,
        target_id: str,
        target_version: str | None = None,
    ) -> TargetSnapshot:
        """Return a target snapshot from local registry fixtures."""
        return self.registry.get_target(target_id, target_version=target_version)

    def get_calibration_snapshot(
        self,
        *,
        target_id: str | None = None,
        calibration_profile_id: str | None = None,
    ) -> CalibrationSnapshot:
        """Return a calibration snapshot from local registry fixtures."""
        return self.registry.get_calibration(
            target_id=target_id,
            calibration_profile_id=calibration_profile_id,
        )

    def select_pair(
        self,
        *,
        target_id: str,
        target_version: str | None = None,
        calibration_profile_id: str | None = None,
        checked_at: str | None = None,
    ) -> TargetCalibrationSelectionIR:
        """Return local registry selection diagnostics."""
        return self.registry.select_pair(
            target_id=target_id,
            target_version=target_version,
            calibration_profile_id=calibration_profile_id,
            checked_at=checked_at,
        )

    def readiness(
        self,
        *,
        target_id: str,
        target_version: str | None = None,
        calibration_profile_id: str | None = None,
        checked_at: str | None = None,
    ) -> TargetCalibrationServiceReadinessIR:
        """Return service readiness without remote fetch."""
        selection = self.select_pair(
            target_id=target_id,
            target_version=target_version,
            calibration_profile_id=calibration_profile_id,
            checked_at=checked_at,
        )
        return build_target_calibration_service_readiness(
            selection=selection,
            service_name=self.service_name,
            service_available=self.service_available,
            requested_target_id=target_id,
            requested_target_version=target_version,
            requested_calibration_profile_id=calibration_profile_id,
        )


def build_target_calibration_service_readiness(
    *,
    selection: TargetCalibrationSelectionIR,
    service_name: str = "fixture_replay_target_calibration_service",
    service_available: bool = True,
    requested_target_id: str | None = None,
    requested_target_version: str | None = None,
    requested_calibration_profile_id: str | None = None,
) -> TargetCalibrationServiceReadinessIR:
    """Build offline service readiness around a registry selection."""
    diagnostics = list(selection.diagnostics)
    if not service_available:
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"target_service.{service_name}.unavailable",
                code="TARGET_CALIBRATION_SERVICE_UNAVAILABLE",
                message=(
                    "Target/calibration service is unavailable; local fixture "
                    "fallback is required."
                ),
                object_path="target_calibration_service",
                severity="warning",
            )
        )
    diagnostics.append(
        _diagnostic(
            diagnostic_id=f"target_service.{service_name}.offline_fallback",
            code="TARGET_CALIBRATION_OFFLINE_FALLBACK_USED",
            message="Target/calibration metadata came from offline fixtures.",
            object_path="target_calibration_service.offline_fallback_used",
            severity="info",
        )
    )
    if selection.target is not None and not selection.target.verify_hash():
        diagnostics.append(
            _diagnostic(
                diagnostic_id=(
                    f"target_service.{selection.target.target_id}.target_hash"
                ),
                code="TARGET_SNAPSHOT_HASH_MISMATCH",
                message="Target snapshot hash does not match target spec.",
                object_path="target.target_snapshot_hash",
                severity="error",
            )
        )
    if selection.calibration is not None and not selection.calibration.verify_hash():
        diagnostics.append(
            _diagnostic(
                diagnostic_id=(
                    "target_service."
                    f"{selection.calibration.calibration_profile_id}."
                    "calibration_hash"
                ),
                code="CALIBRATION_SNAPSHOT_HASH_MISMATCH",
                message="Calibration snapshot hash does not match calibration facts.",
                object_path="calibration.calibration_snapshot_hash",
                severity="error",
            )
        )
    has_errors = any(diagnostic.severity == "error" for diagnostic in diagnostics)
    target = selection.target
    calibration = selection.calibration
    return TargetCalibrationServiceReadinessIR(
        readiness_id=(
            "target_calibration_service."
            f"{service_name}."
            f"{requested_target_id or (target.target_id if target else 'missing')}"
        ),
        service_name=service_name,
        status="offline_fixture" if service_available else "unavailable",
        target_id=requested_target_id or (target.target_id if target else "missing"),
        compatible=selection.compatible and service_available and not has_errors,
        diagnostics=tuple(diagnostics),
        target_snapshot_hash=None if target is None else target.target_snapshot_hash,
        calibration_snapshot_hash=None
        if calibration is None
        else calibration.calibration_snapshot_hash,
        calibration_profile_id=None
        if calibration is None
        else calibration.calibration_profile_id,
        calibration_freshness=selection.freshness,
        remote_fetch_enabled=False,
        network_accessed=False,
        snapshot_hash_verified=(
            target is not None
            and calibration is not None
            and target.verify_hash()
            and calibration.verify_hash()
        ),
        offline_fallback_used=True,
        raw_secret_loaded=False,
        metadata={
            "requested_target_version": requested_target_version,
            "requested_calibration_profile_id": (
                requested_calibration_profile_id
            ),
            "compiler_binding": "immutable_snapshot_hash",
            "remote_fetch": "not_implemented",
        },
    )


def _diagnostic(
    *,
    diagnostic_id: str,
    code: str,
    message: str,
    object_path: str,
    severity: Literal["info", "warning", "error"],
    metadata: dict[str, Any] | None = None,
) -> DiagnosticsIR:
    return DiagnosticsIR(
        diagnostic_id=diagnostic_id,
        stage="validation",
        severity=severity,
        code=code,
        message=message,
        object_path=object_path,
        metadata={} if metadata is None else _redact_mapping(metadata),
    )


def _diagnostic_from_any(value: Any) -> DiagnosticsIR:
    if isinstance(value, DiagnosticsIR):
        return value
    if isinstance(value, dict):
        return DiagnosticsIR.from_dict(value)
    raise TypeError("diagnostics must contain DiagnosticsIR values.")


_SECRET_KEY_MARKERS = (
    "access_key",
    "api_key",
    "apikey",
    "authorization",
    "credential",
    "password",
    "private_key",
    "secret",
    "token",
)


def _redact_mapping(value: dict[str, Any]) -> dict[str, Any]:
    redacted: dict[str, Any] = {}
    for key, item in canonicalize(value).items():
        if _is_secret_key(key):
            redacted[key] = "[REDACTED]"
        elif isinstance(item, dict):
            redacted[key] = _redact_mapping(item)
        else:
            redacted[key] = item
    return redacted


def _is_secret_key(key: str) -> bool:
    lowered = key.lower()
    return any(marker in lowered for marker in _SECRET_KEY_MARKERS)
