"""Local target and calibration registry draft."""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from typing import Any, Literal

from cascaqit.backends.config import BackendCapabilitiesIR, BackendKind
from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.native_ir.base import IRMixin
from cascaqit.native_ir.models import SCHEMA_VERSION
from cascaqit.targets.mock import MockNeutralAtomTarget
from cascaqit.targets.models import CalibrationSnapshot, TargetSnapshot

__all__ = [
    "CalibrationFreshnessIR",
    "TargetCalibrationRegistry",
    "TargetCalibrationSelectionIR",
]

FreshnessState = Literal["fresh", "stale", "unknown"]


@dataclass(frozen=True)
class CalibrationFreshnessIR(IRMixin):
    """Freshness check result for a calibration snapshot."""

    calibration_profile_id: str
    target_id: str
    state: FreshnessState
    checked_at: str | None = None
    valid_from: str | None = None
    valid_to: str | None = None
    schema_version: str = SCHEMA_VERSION
    diagnostics: tuple[DiagnosticsIR, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CalibrationFreshnessIR:
        """Build a freshness record from a JSON-compatible dictionary."""
        return cls(
            calibration_profile_id=str(data["calibration_profile_id"]),
            target_id=str(data["target_id"]),
            state=data["state"],
            checked_at=data.get("checked_at"),
            valid_from=data.get("valid_from"),
            valid_to=data.get("valid_to"),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(diagnostic)
                for diagnostic in data.get("diagnostics", ())
            ),
            metadata=dict(data.get("metadata", {})),
        )


@dataclass(frozen=True)
class TargetCalibrationSelectionIR(IRMixin):
    """Registry target/calibration selection result with diagnostics."""

    target: TargetSnapshot | None
    calibration: CalibrationSnapshot | None
    freshness: CalibrationFreshnessIR | None
    compatible: bool
    schema_version: str = SCHEMA_VERSION
    diagnostics: tuple[DiagnosticsIR, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TargetCalibrationSelectionIR:
        """Build a selection record from a JSON-compatible dictionary."""
        target_data = data.get("target")
        calibration_data = data.get("calibration")
        freshness_data = data.get("freshness")
        return cls(
            target=None
            if target_data is None
            else TargetSnapshot.from_dict(target_data),
            calibration=None
            if calibration_data is None
            else CalibrationSnapshot.from_dict(calibration_data),
            freshness=None
            if freshness_data is None
            else CalibrationFreshnessIR.from_dict(freshness_data),
            compatible=bool(data["compatible"]),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(diagnostic)
                for diagnostic in data.get("diagnostics", ())
            ),
            metadata=dict(data.get("metadata", {})),
        )

    def has_errors(self) -> bool:
        """Return whether selection diagnostics contain errors."""
        return any(diagnostic.severity == "error" for diagnostic in self.diagnostics)


@dataclass(frozen=True)
class TargetCalibrationRegistry:
    """In-memory lookup registry for target and calibration snapshots."""

    targets: tuple[TargetSnapshot, ...]
    calibrations: tuple[CalibrationSnapshot, ...]
    current_time: str = "2026-07-02T00:00:00Z"

    @classmethod
    def local_fixture(cls) -> TargetCalibrationRegistry:
        """Return a deterministic local fixture registry."""
        target = MockNeutralAtomTarget.v0_1().to_snapshot(
            snapshot_id="snapshot.mock",
            source="local_fixture",
            status="available",
            effective_at="2026-07-01T00:00:00Z",
        )
        calibration = CalibrationSnapshot.local_mock(
            target_id=target.target_id,
            calibration_profile_id="mock.calibration.local",
            metadata={
                "registry": "local_fixture",
                "target_snapshot_hash": target.target_snapshot_hash,
            },
        )
        return cls(targets=(target,), calibrations=(calibration,))

    @classmethod
    def multi_version_fixture(cls) -> TargetCalibrationRegistry:
        """Return deterministic multi-version target/calibration fixtures."""
        base = MockNeutralAtomTarget.v0_1()
        target_v0_1 = base.to_snapshot(
            snapshot_id="snapshot.mock.v0_1.active",
            source="local_fixture",
            status="available",
            effective_at="2026-07-01T00:00:00Z",
            metadata={"registry": "multi_version_fixture", "generation": "active"},
        )
        target_v0_0 = replace(
            target_v0_1,
            snapshot_id="snapshot.mock.v0_0.legacy",
            target_version="0.0",
            status="maintenance",
            effective_at="2026-06-01T00:00:00Z",
            expires_at="2026-07-01T00:00:00Z",
            metadata={"registry": "multi_version_fixture", "generation": "legacy"},
        )
        fresh = CalibrationSnapshot.local_mock(
            target_id=target_v0_1.target_id,
            calibration_profile_id="mock.calibration.fresh",
            metadata={
                "registry": "multi_version_fixture",
                "target_snapshot_hash": target_v0_1.target_snapshot_hash,
                "freshness_policy": "valid_window",
            },
        )
        fresh = replace(
            fresh,
            valid_from="2026-07-01T00:00:00Z",
            valid_to="2026-07-03T00:00:00Z",
        )
        stale = CalibrationSnapshot.local_mock(
            target_id=target_v0_1.target_id,
            calibration_profile_id="mock.calibration.stale",
            metadata={
                "registry": "multi_version_fixture",
                "target_snapshot_hash": target_v0_1.target_snapshot_hash,
                "freshness_policy": "valid_window",
            },
        )
        stale = replace(
            stale,
            valid_from="2026-06-01T00:00:00Z",
            valid_to="2026-06-15T00:00:00Z",
        )
        legacy = CalibrationSnapshot.local_mock(
            target_id=target_v0_0.target_id,
            calibration_profile_id="mock.calibration.legacy",
            metadata={
                "registry": "multi_version_fixture",
                "target_snapshot_hash": target_v0_0.target_snapshot_hash,
                "freshness_policy": "valid_window",
            },
        )
        legacy = replace(
            legacy,
            valid_from="2026-06-01T00:00:00Z",
            valid_to="2026-07-01T00:00:00Z",
        )
        incompatible = CalibrationSnapshot.local_mock(
            target_id=target_v0_1.target_id,
            calibration_profile_id="mock.calibration.incompatible",
            metadata={
                "registry": "multi_version_fixture",
                "target_snapshot_hash": "0" * 64,
                "freshness_policy": "valid_window",
            },
        )
        incompatible = replace(
            incompatible,
            valid_from="2026-07-01T00:00:00Z",
            valid_to="2026-07-03T00:00:00Z",
        )
        return cls(
            targets=(target_v0_1, target_v0_0),
            calibrations=(fresh, stale, legacy, incompatible),
            current_time="2026-07-02T00:00:00Z",
        )

    def get_target(
        self,
        target_id: str,
        *,
        target_version: str | None = None,
    ) -> TargetSnapshot:
        """Return a target snapshot by target id and optional version."""
        matches = [
            target
            for target in self.targets
            if target.target_id == target_id
            and (
                target_version is None
                or target.target_version == target_version
            )
        ]
        if not matches:
            suffix = "" if target_version is None else f" version {target_version}"
            raise KeyError(f"Unknown target_id: {target_id}{suffix}")
        return _latest_target(matches)

    def get_calibration(
        self,
        *,
        target_id: str | None = None,
        calibration_profile_id: str | None = None,
    ) -> CalibrationSnapshot:
        """Return a calibration snapshot by target and/or profile id."""
        matches = [
            calibration
            for calibration in self.calibrations
            if (target_id is None or calibration.target_id == target_id)
            and (
                calibration_profile_id is None
                or calibration.calibration_profile_id == calibration_profile_id
            )
        ]
        if not matches:
            raise KeyError(
                "Unknown calibration for "
                f"target_id={target_id!r}, "
                f"calibration_profile_id={calibration_profile_id!r}"
            )
        return _latest_calibration(matches)

    def latest_pair(
        self,
        *,
        target_id: str,
        target_version: str | None = None,
        calibration_profile_id: str | None = None,
    ) -> tuple[TargetSnapshot, CalibrationSnapshot]:
        """Return a target snapshot and matching calibration snapshot."""
        target = self.get_target(target_id, target_version=target_version)
        calibration = self.get_calibration(
            target_id=target.target_id,
            calibration_profile_id=calibration_profile_id,
        )
        return target, calibration

    def select_pair(
        self,
        *,
        target_id: str,
        target_version: str | None = None,
        calibration_profile_id: str | None = None,
        checked_at: str | None = None,
    ) -> TargetCalibrationSelectionIR:
        """Return a target/calibration pair with compatibility diagnostics."""
        diagnostics: list[DiagnosticsIR] = []
        target = _lookup_target(
            self.targets,
            target_id=target_id,
            target_version=target_version,
            diagnostics=diagnostics,
        )
        calibration = _lookup_calibration(
            self.calibrations,
            target_id=None if target is None else target.target_id,
            calibration_profile_id=calibration_profile_id,
            diagnostics=diagnostics,
        )
        freshness = None
        compatible = False
        if target is not None and calibration is not None:
            compatibility = self.check_compatibility(target, calibration)
            diagnostics.extend(compatibility.diagnostics)
            freshness = self.check_calibration_freshness(
                calibration,
                checked_at=checked_at,
            )
            diagnostics.extend(freshness.diagnostics)
            compatible = (
                compatibility.compatible
                and freshness.state == "fresh"
                and not any(
                    diagnostic.severity == "error" for diagnostic in diagnostics
                )
            )
        return TargetCalibrationSelectionIR(
            target=target,
            calibration=calibration,
            freshness=freshness,
            compatible=compatible,
            diagnostics=tuple(diagnostics)
            if diagnostics
            else (
                _diagnostic(
                    diagnostic_id=f"registry.{target_id}.selection_valid",
                    code="TARGET_CALIBRATION_SELECTION_VALID",
                    message="Target/calibration selection is valid.",
                    severity="info",
                    object_path="registry.selection",
                ),
            ),
            metadata={
                "registry": "TargetCalibrationRegistry",
                "checked_at": checked_at or self.current_time,
            },
        )

    def check_compatibility(
        self,
        target: TargetSnapshot,
        calibration: CalibrationSnapshot,
    ) -> TargetCalibrationSelectionIR:
        """Check whether a calibration snapshot is compatible with a target."""
        diagnostics: list[DiagnosticsIR] = []
        if calibration.target_id != target.target_id:
            diagnostics.append(
                _diagnostic(
                    diagnostic_id=(
                        f"registry.{target.target_id}."
                        f"{calibration.calibration_profile_id}.target"
                    ),
                    code="CALIBRATION_TARGET_INCOMPATIBLE",
                    message="Calibration target_id does not match target snapshot.",
                    severity="error",
                    object_path="calibration.target_id",
                    metadata={
                        "target_id": target.target_id,
                        "calibration_target_id": calibration.target_id,
                    },
                )
            )
        calibration_target_hash = calibration.metadata.get("target_snapshot_hash")
        if (
            calibration_target_hash is not None
            and calibration_target_hash != target.target_snapshot_hash
        ):
            diagnostics.append(
                _diagnostic(
                    diagnostic_id=(
                        f"registry.{target.target_id}."
                        f"{calibration.calibration_profile_id}.hash"
                    ),
                    code="CALIBRATION_TARGET_HASH_INCOMPATIBLE",
                    message=(
                        "Calibration target_snapshot_hash metadata does not "
                        "match target snapshot."
                    ),
                    severity="error",
                    object_path="calibration.metadata.target_snapshot_hash",
                    metadata={
                        "expected": target.target_snapshot_hash,
                        "actual": calibration_target_hash,
                    },
                )
            )
        if _contains_raw_secret_metadata(calibration.metadata):
            diagnostics.append(
                _diagnostic(
                    diagnostic_id=(
                        f"registry.{target.target_id}."
                        f"{calibration.calibration_profile_id}.secret"
                    ),
                    code="CALIBRATION_RAW_SECRET_METADATA",
                    message=(
                        "Calibration metadata appears to contain raw secret "
                        "material."
                    ),
                    severity="error",
                    object_path="calibration.metadata",
                    metadata={"calibration_profile_id": (
                        calibration.calibration_profile_id
                    )},
                )
            )
        if calibration.readout_summary is None:
            diagnostics.append(
                _diagnostic(
                    diagnostic_id=(
                        f"registry.{target.target_id}."
                        f"{calibration.calibration_profile_id}.readout_missing"
                    ),
                    code="CALIBRATION_READOUT_SUMMARY_MISSING",
                    message="Calibration has no structured readout summary.",
                    severity="warning",
                    object_path="calibration.readout_summary",
                )
            )
        else:
            target_readout = (
                None
                if target.target_spec.typed_capabilities is None
                else target.target_spec.typed_capabilities.readout
            )
            if target_readout is not None:
                missing_basis = tuple(
                    basis
                    for basis in target_readout.basis
                    if basis not in calibration.readout_summary.basis
                )
                if missing_basis:
                    diagnostics.append(
                        _diagnostic(
                            diagnostic_id=(
                                f"registry.{target.target_id}."
                                f"{calibration.calibration_profile_id}."
                                "readout_basis"
                            ),
                            code="CALIBRATION_READOUT_BASIS_MISMATCH",
                            message=(
                                "Calibration readout basis does not cover "
                                "target readout capability."
                            ),
                            severity="error",
                            object_path="calibration.readout_summary.basis",
                            metadata={"missing_basis": list(missing_basis)},
                        )
                    )
        if calibration.pulse_channel_summary is None:
            diagnostics.append(
                _diagnostic(
                    diagnostic_id=(
                        f"registry.{target.target_id}."
                        f"{calibration.calibration_profile_id}.pulse_missing"
                    ),
                    code="CALIBRATION_PULSE_CHANNEL_SUMMARY_MISSING",
                    message=(
                        "Calibration has no structured pulse/channel summary."
                    ),
                    severity="warning",
                    object_path="calibration.pulse_channel_summary",
                )
            )
        typed = target.target_spec.typed_capabilities
        if typed is not None and typed.digital_gates:
            calibrated_gates = {
                summary.gate
                for summary in calibration.digital_gate_calibrations
                if summary.status in ("supported", "experimental")
            }
            missing_digital_gates = tuple(
                capability.gate
                for capability in typed.digital_gates
                if capability.status in ("supported", "experimental")
                and capability.gate not in calibrated_gates
            )
            if missing_digital_gates:
                diagnostics.append(
                    _diagnostic(
                        diagnostic_id=(
                            f"registry.{target.target_id}."
                            f"{calibration.calibration_profile_id}."
                            "digital_gate_missing"
                        ),
                        code="CALIBRATION_DIGITAL_GATE_SUMMARY_MISSING",
                        message=(
                            "Calibration does not cover all target digital "
                            "gate capabilities."
                        ),
                        severity="warning",
                        object_path="calibration.digital_gate_calibrations",
                        metadata={"missing_gates": list(missing_digital_gates)},
                    )
                )
        if not diagnostics:
            diagnostics.append(
                _diagnostic(
                    diagnostic_id=(
                        f"registry.{target.target_id}."
                        f"{calibration.calibration_profile_id}.compatible"
                    ),
                    code="TARGET_CALIBRATION_COMPATIBLE",
                    message="Calibration is compatible with target snapshot.",
                    severity="info",
                    object_path="registry.compatibility",
                )
            )
        return TargetCalibrationSelectionIR(
            target=target,
            calibration=calibration,
            freshness=None,
            compatible=not any(
                diagnostic.severity == "error" for diagnostic in diagnostics
            ),
            diagnostics=tuple(diagnostics),
            metadata={"check": "compatibility"},
        )

    def check_calibration_freshness(
        self,
        calibration: CalibrationSnapshot,
        *,
        checked_at: str | None = None,
    ) -> CalibrationFreshnessIR:
        """Return whether calibration is fresh for a deterministic timestamp."""
        effective_checked_at = checked_at or self.current_time
        diagnostics: list[DiagnosticsIR] = []
        state: FreshnessState = "fresh"
        if calibration.valid_from is None and calibration.valid_to is None:
            state = "unknown"
            diagnostics.append(
                _diagnostic(
                    diagnostic_id=(
                        f"registry.{calibration.calibration_profile_id}."
                        "freshness_unknown"
                    ),
                    code="CALIBRATION_FRESHNESS_UNKNOWN",
                    message="Calibration has no validity window metadata.",
                    severity="warning",
                    object_path="calibration.valid_from",
                )
            )
        elif (
            calibration.valid_from is not None
            and effective_checked_at < calibration.valid_from
        ):
            state = "stale"
            diagnostics.append(
                _diagnostic(
                    diagnostic_id=(
                        f"registry.{calibration.calibration_profile_id}."
                        "not_yet_valid"
                    ),
                    code="CALIBRATION_NOT_YET_VALID",
                    message="Calibration is not yet valid at checked_at.",
                    severity="error",
                    object_path="calibration.valid_from",
                    metadata={"checked_at": effective_checked_at},
                )
            )
        elif (
            calibration.valid_to is not None
            and effective_checked_at > calibration.valid_to
        ):
            state = "stale"
            diagnostics.append(
                _diagnostic(
                    diagnostic_id=(
                        f"registry.{calibration.calibration_profile_id}.stale"
                    ),
                    code="CALIBRATION_STALE",
                    message="Calibration validity window has expired.",
                    severity="error",
                    object_path="calibration.valid_to",
                    metadata={"checked_at": effective_checked_at},
                )
            )
            diagnostics.append(
                _diagnostic(
                    diagnostic_id=(
                        f"registry.{calibration.calibration_profile_id}."
                        "fallback_policy"
                    ),
                    code="CALIBRATION_FALLBACK_POLICY_APPLIED",
                    message=(
                        "Calibration fallback policy was evaluated for stale "
                        "calibration."
                    ),
                    severity="warning",
                    object_path="calibration.fallback_policy",
                    metadata={
                        "fallback_policy": calibration.fallback_policy
                        or "unspecified",
                    },
                )
            )
        else:
            diagnostics.append(
                _diagnostic(
                    diagnostic_id=(
                        f"registry.{calibration.calibration_profile_id}.fresh"
                    ),
                    code="CALIBRATION_FRESH",
                    message="Calibration is fresh at checked_at.",
                    severity="info",
                    object_path="calibration",
                    metadata={"checked_at": effective_checked_at},
                )
            )
        return CalibrationFreshnessIR(
            calibration_profile_id=calibration.calibration_profile_id,
            target_id=calibration.target_id,
            state=state,
            checked_at=effective_checked_at,
            valid_from=calibration.valid_from,
            valid_to=calibration.valid_to,
            diagnostics=tuple(diagnostics),
            metadata={"check": "freshness"},
        )

    def capabilities_for_pair(
        self,
        *,
        backend_id: str,
        backend_kind: BackendKind,
        target_id: str,
        target_version: str | None = None,
        calibration_profile_id: str | None = None,
        supports_batch: bool = False,
        supports_cancel: bool = True,
        supports_artifacts: bool = True,
        max_batch_items: int | None = None,
    ) -> BackendCapabilitiesIR:
        """Build backend capabilities from a registry target/calibration pair."""
        selection = self.select_pair(
            target_id=target_id,
            target_version=target_version,
            calibration_profile_id=calibration_profile_id,
        )
        if selection.has_errors() or not selection.compatible:
            codes = ", ".join(
                diagnostic.code for diagnostic in selection.diagnostics
            )
            raise ValueError(
                "Cannot build backend capabilities from invalid "
                f"target/calibration selection: {codes}"
            )
        if selection.target is None or selection.calibration is None:
            raise ValueError("Registry selection did not include a target pair.")
        target = selection.target
        calibration = selection.calibration
        return BackendCapabilitiesIR(
            backend_id=backend_id,
            backend_kind=backend_kind,
            supported_program_types=("analog",),
            supported_workload_types=("single_job", "batch")
            if supports_batch
            else ("single_job",),
            supports_batch=supports_batch,
            supports_cancel=supports_cancel,
            supports_artifacts=supports_artifacts,
            max_shots=target.target_spec.shots_range[1],
            max_batch_items=max_batch_items,
            target_snapshot_hash=target.target_snapshot_hash,
            calibration_snapshot_hash=calibration.calibration_snapshot_hash,
            metadata={
                "registry": "TargetCalibrationRegistry",
                "target_id": target.target_id,
                "target_version": target.target_version,
                "calibration_profile_id": calibration.calibration_profile_id,
                "freshness": None
                if selection.freshness is None
                else selection.freshness.to_dict(),
            },
        )

    def verify_hashes(self) -> bool:
        """Return whether all registry snapshots have internally valid hashes."""
        return all(target.verify_hash() for target in self.targets) and all(
            calibration.verify_hash() for calibration in self.calibrations
        )

    def require_hash_consistency(self) -> None:
        """Raise if any registry snapshot has inconsistent hash metadata."""
        for target in self.targets:
            if not target.verify_hash():
                raise ValueError(
                    f"TargetSnapshot hash mismatch: {target.snapshot_id}"
                )
        for calibration in self.calibrations:
            if not calibration.verify_hash():
                raise ValueError(
                    "CalibrationSnapshot hash mismatch: "
                    f"{calibration.calibration_profile_id}"
                )


def _latest_target(targets: list[TargetSnapshot]) -> TargetSnapshot:
    """Return the most recent target by effective timestamp and id."""
    return sorted(
        targets,
        key=lambda target: (target.effective_at or "", target.snapshot_id),
        reverse=True,
    )[0]


def _latest_calibration(
    calibrations: list[CalibrationSnapshot],
) -> CalibrationSnapshot:
    """Return the most recent calibration by validity timestamp and profile."""
    return sorted(
        calibrations,
        key=lambda calibration: (
            calibration.valid_from or "",
            calibration.calibration_profile_id,
        ),
        reverse=True,
    )[0]


def _lookup_target(
    targets: tuple[TargetSnapshot, ...],
    *,
    target_id: str,
    target_version: str | None,
    diagnostics: list[DiagnosticsIR],
) -> TargetSnapshot | None:
    matches = [
        target
        for target in targets
        if target.target_id == target_id
        and (
            target_version is None
            or target.target_version == target_version
        )
    ]
    if matches:
        return _latest_target(matches)
    diagnostics.append(
        _diagnostic(
            diagnostic_id=f"registry.{target_id}.missing_target",
            code="TARGET_SNAPSHOT_MISSING",
            message="No target snapshot matches the requested target.",
            severity="error",
            object_path="target_id",
            metadata={"target_id": target_id, "target_version": target_version},
        )
    )
    return None


def _lookup_calibration(
    calibrations: tuple[CalibrationSnapshot, ...],
    *,
    target_id: str | None,
    calibration_profile_id: str | None,
    diagnostics: list[DiagnosticsIR],
) -> CalibrationSnapshot | None:
    matches = [
        calibration
        for calibration in calibrations
        if (target_id is None or calibration.target_id == target_id)
        and (
            calibration_profile_id is None
            or calibration.calibration_profile_id == calibration_profile_id
        )
    ]
    if matches:
        return _latest_calibration(matches)
    diagnostics.append(
        _diagnostic(
            diagnostic_id="registry.calibration.missing",
            code="CALIBRATION_SNAPSHOT_MISSING",
            message="No calibration snapshot matches the requested selection.",
            severity="error",
            object_path="calibration_profile_id",
            metadata={
                "target_id": target_id,
                "calibration_profile_id": calibration_profile_id,
            },
        )
    )
    return None


def _diagnostic(
    *,
    diagnostic_id: str,
    code: str,
    message: str,
    severity: Literal["info", "warning", "error"],
    object_path: str,
    metadata: dict[str, Any] | None = None,
) -> DiagnosticsIR:
    return DiagnosticsIR(
        diagnostic_id=diagnostic_id,
        stage="validation",
        severity=severity,
        code=code,
        message=message,
        object_path=object_path,
        metadata={} if metadata is None else metadata,
    )


def _contains_raw_secret_metadata(metadata: dict[str, Any]) -> bool:
    """Return whether metadata keys look like raw secret material."""
    suspicious = ("secret", "token", "password", "credential")
    for key, value in metadata.items():
        key_text = str(key).lower()
        if any(marker in key_text for marker in suspicious):
            return True
        if isinstance(value, dict) and _contains_raw_secret_metadata(value):
            return True
    return False
