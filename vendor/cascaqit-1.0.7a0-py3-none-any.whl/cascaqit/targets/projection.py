"""Target projection contracts for future ecosystem adapters.

The projections in this module are metadata-only summaries derived from
CASCAQit Target / Calibration facts. They do not construct Qiskit, OpenQASM,
analog DSL, hybrid runtime, hardware, cloud, or compatibility-layer objects.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Literal, cast

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.native_ir.base import IRMixin, canonicalize
from cascaqit.native_ir.models import ANALOG_BIT_ORDER_CONVENTION, SCHEMA_VERSION
from cascaqit.targets.models import (
    CalibrationSnapshot,
    CapabilityStatus,
    TargetSnapshot,
    TargetSpec,
)

__all__ = [
    "TargetProjectionConsumerConformanceIR",
    "TargetProjectionConsumerMatrixIR",
    "TargetProjectionCapabilityIR",
    "TargetProjectionFormat",
    "TargetProjectionIR",
    "build_target_projection_consumer_matrix",
    "project_target_capabilities",
    "build_target_projection_consumer_conformance",
]

TargetProjectionFormat = Literal[
    "qiskit_target",
    "openqasm_validator",
    "analog_constraints",
    "hybrid_constraints",
]
ProjectionCapabilityType = Literal[
    "program_type",
    "analog_operation",
    "digital_gate",
    "readout",
    "timing",
    "shot_limit",
    "measurement",
    "control_channel",
    "boundary",
]
ProjectionStatus = Literal["ready", "partial", "blocked"]
ConsumerConformanceStatus = Literal["ready", "blocked"]
ConsumerMatrixStatus = Literal["ready", "blocked"]


@dataclass(frozen=True)
class TargetProjectionCapabilityIR(IRMixin):
    """Single adapter-facing capability projected from CASCAQit target facts."""

    capability_id: str
    capability_type: ProjectionCapabilityType
    name: str
    status: CapabilityStatus
    operation_names: tuple[str, ...] = ()
    arity: int | None = None
    parameter_names: tuple[str, ...] = ()
    timing: dict[str, Any] = field(default_factory=dict)
    readout: dict[str, Any] = field(default_factory=dict)
    shot_limits: dict[str, Any] = field(default_factory=dict)
    bit_order: dict[str, Any] = field(default_factory=dict)
    measurement_constraints: dict[str, Any] = field(default_factory=dict)
    control_refs: tuple[str, ...] = ()
    calibration_refs: dict[str, Any] = field(default_factory=dict)
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize JSON-compatible nested payloads."""
        object.__setattr__(
            self,
            "operation_names",
            tuple(str(item) for item in self.operation_names),
        )
        object.__setattr__(
            self,
            "parameter_names",
            tuple(str(item) for item in self.parameter_names),
        )
        object.__setattr__(
            self,
            "control_refs",
            tuple(str(item) for item in self.control_refs),
        )
        object.__setattr__(self, "timing", canonicalize(self.timing))
        object.__setattr__(self, "readout", canonicalize(self.readout))
        object.__setattr__(self, "shot_limits", canonicalize(self.shot_limits))
        object.__setattr__(self, "bit_order", canonicalize(self.bit_order))
        object.__setattr__(
            self,
            "measurement_constraints",
            canonicalize(self.measurement_constraints),
        )
        object.__setattr__(
            self,
            "calibration_refs",
            canonicalize(self.calibration_refs),
        )
        object.__setattr__(self, "metadata", canonicalize(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TargetProjectionCapabilityIR:
        """Build a target projection capability from a dictionary."""
        return cls(
            capability_id=str(data["capability_id"]),
            capability_type=cast(ProjectionCapabilityType, data["capability_type"]),
            name=str(data["name"]),
            status=cast(CapabilityStatus, data["status"]),
            operation_names=tuple(
                str(item) for item in data.get("operation_names", ())
            ),
            arity=None if data.get("arity") is None else int(data["arity"]),
            parameter_names=tuple(
                str(item) for item in data.get("parameter_names", ())
            ),
            timing=dict(data.get("timing", {})),
            readout=dict(data.get("readout", {})),
            shot_limits=dict(data.get("shot_limits", {})),
            bit_order=dict(data.get("bit_order", {})),
            measurement_constraints=dict(data.get("measurement_constraints", {})),
            control_refs=tuple(str(item) for item in data.get("control_refs", ())),
            calibration_refs=dict(data.get("calibration_refs", {})),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )


@dataclass(frozen=True)
class TargetProjectionIR(IRMixin):
    """Adapter-facing target projection derived from CASCAQit target facts."""

    projection_id: str
    projection_format: TargetProjectionFormat
    status: ProjectionStatus
    target_id: str
    target_version: str
    target_snapshot_id: str
    target_snapshot_hash: str
    capabilities: tuple[TargetProjectionCapabilityIR, ...]
    timing: dict[str, Any]
    readout: dict[str, Any]
    shot_limits: dict[str, Any]
    bit_order: dict[str, Any]
    measurement_constraints: dict[str, Any]
    control_channels: tuple[dict[str, Any], ...]
    calibration_refs: dict[str, Any] = field(default_factory=dict)
    external_object_constructed: bool = False
    live_target_fetch_performed: bool = False
    live_calibration_fetch_performed: bool = False
    network_accessed: bool = False
    cascaqit_compat_required: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize projection payload and enforce metadata-only boundaries."""
        if self.external_object_constructed:
            raise ValueError("TargetProjectionIR must not construct external objects.")
        if self.live_target_fetch_performed:
            raise ValueError("TargetProjectionIR must not fetch live targets.")
        if self.live_calibration_fetch_performed:
            raise ValueError("TargetProjectionIR must not fetch live calibrations.")
        if self.network_accessed:
            raise ValueError("TargetProjectionIR must not access networks.")
        if self.cascaqit_compat_required:
            raise ValueError("TargetProjectionIR must not require cascaqit-compat.")
        object.__setattr__(
            self,
            "capabilities",
            tuple(
                capability
                if isinstance(capability, TargetProjectionCapabilityIR)
                else TargetProjectionCapabilityIR.from_dict(capability)
                for capability in self.capabilities
            ),
        )
        object.__setattr__(self, "timing", canonicalize(self.timing))
        object.__setattr__(self, "readout", canonicalize(self.readout))
        object.__setattr__(self, "shot_limits", canonicalize(self.shot_limits))
        object.__setattr__(self, "bit_order", canonicalize(self.bit_order))
        object.__setattr__(
            self,
            "measurement_constraints",
            canonicalize(self.measurement_constraints),
        )
        object.__setattr__(
            self,
            "control_channels",
            tuple(canonicalize(channel) for channel in self.control_channels),
        )
        object.__setattr__(
            self,
            "calibration_refs",
            canonicalize(self.calibration_refs),
        )
        object.__setattr__(self, "metadata", canonicalize(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TargetProjectionIR:
        """Build a target projection from a JSON-compatible dictionary."""
        return cls(
            projection_id=str(data["projection_id"]),
            projection_format=cast(TargetProjectionFormat, data["projection_format"]),
            status=cast(ProjectionStatus, data["status"]),
            target_id=str(data["target_id"]),
            target_version=str(data["target_version"]),
            target_snapshot_id=str(data["target_snapshot_id"]),
            target_snapshot_hash=str(data["target_snapshot_hash"]),
            capabilities=tuple(
                TargetProjectionCapabilityIR.from_dict(item)
                for item in data.get("capabilities", ())
            ),
            timing=dict(data["timing"]),
            readout=dict(data["readout"]),
            shot_limits=dict(data["shot_limits"]),
            bit_order=dict(data["bit_order"]),
            measurement_constraints=dict(data["measurement_constraints"]),
            control_channels=tuple(
                dict(item) for item in data.get("control_channels", ())
            ),
            calibration_refs=dict(data.get("calibration_refs", {})),
            external_object_constructed=bool(
                data.get("external_object_constructed", False)
            ),
            live_target_fetch_performed=bool(
                data.get("live_target_fetch_performed", False)
            ),
            live_calibration_fetch_performed=bool(
                data.get("live_calibration_fetch_performed", False)
            ),
            network_accessed=bool(data.get("network_accessed", False)),
            cascaqit_compat_required=bool(
                data.get("cascaqit_compat_required", False)
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> TargetProjectionIR:
        """Build a target projection from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("TargetProjectionIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class TargetProjectionConsumerConformanceIR(IRMixin):
    """Conformance report for consumers of TargetProjectionIR facts."""

    conformance_id: str
    consumer_format: TargetProjectionFormat
    status: ConsumerConformanceStatus
    projection_id: str
    projection_status: ProjectionStatus
    target_id: str
    target_version: str
    target_snapshot_id: str
    target_snapshot_hash: str
    calibration_refs: dict[str, Any]
    required_capability_ids: tuple[str, ...]
    consumed_capability_ids: tuple[str, ...]
    missing_capability_ids: tuple[str, ...] = ()
    consumer_expectations: tuple[dict[str, Any], ...] = ()
    diagnostics: tuple[DiagnosticsIR, ...] = ()
    metadata_only: bool = True
    projection_facts_authoritative: bool = True
    independent_capability_facts: bool = False
    external_object_constructed: bool = False
    live_target_fetch_performed: bool = False
    live_calibration_fetch_performed: bool = False
    network_accessed: bool = False
    cascaqit_compat_required: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize conformance payload and enforce consumer boundaries."""
        if self.status not in ("ready", "blocked"):
            raise ValueError(f"Unsupported consumer conformance status: {self.status}")
        if not self.metadata_only:
            raise ValueError(
                "TargetProjectionConsumerConformanceIR must be metadata-only."
            )
        if not self.projection_facts_authoritative:
            raise ValueError(
                "TargetProjectionConsumerConformanceIR requires projection facts "
                "to be authoritative."
            )
        if self.independent_capability_facts:
            raise ValueError(
                "TargetProjectionConsumerConformanceIR must not use independent "
                "capability facts."
            )
        if self.external_object_constructed:
            raise ValueError(
                "TargetProjectionConsumerConformanceIR must not construct "
                "external objects."
            )
        if self.live_target_fetch_performed:
            raise ValueError(
                "TargetProjectionConsumerConformanceIR must not fetch live targets."
            )
        if self.live_calibration_fetch_performed:
            raise ValueError(
                "TargetProjectionConsumerConformanceIR must not fetch live "
                "calibrations."
            )
        if self.network_accessed:
            raise ValueError(
                "TargetProjectionConsumerConformanceIR cannot access networks."
            )
        if self.cascaqit_compat_required:
            raise ValueError(
                "TargetProjectionConsumerConformanceIR must not require "
                "cascaqit-compat."
            )
        object.__setattr__(
            self,
            "calibration_refs",
            canonicalize(self.calibration_refs),
        )
        object.__setattr__(
            self,
            "required_capability_ids",
            tuple(sorted(str(item) for item in self.required_capability_ids)),
        )
        object.__setattr__(
            self,
            "consumed_capability_ids",
            tuple(sorted(str(item) for item in self.consumed_capability_ids)),
        )
        object.__setattr__(
            self,
            "missing_capability_ids",
            tuple(sorted(str(item) for item in self.missing_capability_ids)),
        )
        object.__setattr__(
            self,
            "consumer_expectations",
            tuple(canonicalize(item) for item in self.consumer_expectations),
        )
        object.__setattr__(
            self,
            "diagnostics",
            tuple(_diagnostic_from_any(item) for item in self.diagnostics),
        )
        object.__setattr__(self, "metadata", canonicalize(self.metadata))

    @classmethod
    def from_dict(
        cls,
        data: dict[str, Any],
    ) -> TargetProjectionConsumerConformanceIR:
        """Build consumer conformance from a JSON-compatible dictionary."""
        if not isinstance(data, dict):
            raise TypeError(
                "TargetProjectionConsumerConformanceIR dictionary must be an object."
            )
        return cls(
            conformance_id=str(data["conformance_id"]),
            consumer_format=cast(TargetProjectionFormat, data["consumer_format"]),
            status=cast(ConsumerConformanceStatus, data["status"]),
            projection_id=str(data["projection_id"]),
            projection_status=cast(ProjectionStatus, data["projection_status"]),
            target_id=str(data["target_id"]),
            target_version=str(data["target_version"]),
            target_snapshot_id=str(data["target_snapshot_id"]),
            target_snapshot_hash=str(data["target_snapshot_hash"]),
            calibration_refs=dict(data.get("calibration_refs", {})),
            required_capability_ids=tuple(
                str(item) for item in data.get("required_capability_ids", ())
            ),
            consumed_capability_ids=tuple(
                str(item) for item in data.get("consumed_capability_ids", ())
            ),
            missing_capability_ids=tuple(
                str(item) for item in data.get("missing_capability_ids", ())
            ),
            consumer_expectations=tuple(
                dict(item) for item in data.get("consumer_expectations", ())
            ),
            diagnostics=tuple(
                _diagnostic_from_any(item) for item in data.get("diagnostics", ())
            ),
            metadata_only=bool(data.get("metadata_only", True)),
            projection_facts_authoritative=bool(
                data.get("projection_facts_authoritative", True)
            ),
            independent_capability_facts=bool(
                data.get("independent_capability_facts", False)
            ),
            external_object_constructed=bool(
                data.get("external_object_constructed", False)
            ),
            live_target_fetch_performed=bool(
                data.get("live_target_fetch_performed", False)
            ),
            live_calibration_fetch_performed=bool(
                data.get("live_calibration_fetch_performed", False)
            ),
            network_accessed=bool(data.get("network_accessed", False)),
            cascaqit_compat_required=bool(
                data.get("cascaqit_compat_required", False)
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> TargetProjectionConsumerConformanceIR:
        """Build consumer conformance from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError(
                "TargetProjectionConsumerConformanceIR JSON must contain an object."
            )
        return cls.from_dict(data)


@dataclass(frozen=True)
class TargetProjectionConsumerMatrixIR(IRMixin):
    """Matrix proving consumers share authoritative TargetProjectionIR facts."""

    matrix_id: str
    status: ConsumerMatrixStatus
    target_id: str
    target_version: str
    target_snapshot_id: str
    target_snapshot_hash: str
    calibration_refs: dict[str, Any]
    consumer_formats: tuple[TargetProjectionFormat, ...]
    projection_ids: tuple[str, ...]
    conformances: tuple[TargetProjectionConsumerConformanceIR, ...]
    required_capability_summary: dict[str, Any]
    consumed_capability_summary: dict[str, Any]
    missing_capability_summary: dict[str, Any]
    diagnostics: tuple[DiagnosticsIR, ...] = ()
    metadata_only: bool = True
    projection_facts_authoritative: bool = True
    independent_capability_facts: bool = False
    external_object_constructed: bool = False
    live_target_fetch_performed: bool = False
    live_calibration_fetch_performed: bool = False
    network_accessed: bool = False
    cascaqit_compat_required: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize matrix payloads and enforce shared-facts boundaries."""
        if self.status not in ("ready", "blocked"):
            raise ValueError(f"Unsupported consumer matrix status: {self.status}")
        if not self.metadata_only:
            raise ValueError("TargetProjectionConsumerMatrixIR must be metadata-only.")
        if not self.projection_facts_authoritative:
            raise ValueError(
                "TargetProjectionConsumerMatrixIR requires projection facts to be "
                "authoritative."
            )
        if self.independent_capability_facts:
            raise ValueError(
                "TargetProjectionConsumerMatrixIR must not use independent "
                "capability facts."
            )
        if self.external_object_constructed:
            raise ValueError(
                "TargetProjectionConsumerMatrixIR must not construct external "
                "objects."
            )
        if self.live_target_fetch_performed:
            raise ValueError(
                "TargetProjectionConsumerMatrixIR must not fetch live targets."
            )
        if self.live_calibration_fetch_performed:
            raise ValueError(
                "TargetProjectionConsumerMatrixIR must not fetch live calibrations."
            )
        if self.network_accessed:
            raise ValueError("TargetProjectionConsumerMatrixIR cannot access networks.")
        if self.cascaqit_compat_required:
            raise ValueError(
                "TargetProjectionConsumerMatrixIR must not require cascaqit-compat."
            )
        object.__setattr__(
            self,
            "calibration_refs",
            canonicalize(self.calibration_refs),
        )
        object.__setattr__(
            self,
            "consumer_formats",
            tuple(
                cast(TargetProjectionFormat, str(item))
                for item in self.consumer_formats
            ),
        )
        object.__setattr__(
            self,
            "projection_ids",
            tuple(str(item) for item in self.projection_ids),
        )
        object.__setattr__(
            self,
            "conformances",
            tuple(
                item
                if isinstance(item, TargetProjectionConsumerConformanceIR)
                else TargetProjectionConsumerConformanceIR.from_dict(item)
                for item in self.conformances
            ),
        )
        object.__setattr__(
            self,
            "required_capability_summary",
            canonicalize(self.required_capability_summary),
        )
        object.__setattr__(
            self,
            "consumed_capability_summary",
            canonicalize(self.consumed_capability_summary),
        )
        object.__setattr__(
            self,
            "missing_capability_summary",
            canonicalize(self.missing_capability_summary),
        )
        object.__setattr__(
            self,
            "diagnostics",
            tuple(_diagnostic_from_any(item) for item in self.diagnostics),
        )
        object.__setattr__(self, "metadata", canonicalize(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TargetProjectionConsumerMatrixIR:
        """Build consumer matrix from a JSON-compatible dictionary."""
        if not isinstance(data, dict):
            raise TypeError(
                "TargetProjectionConsumerMatrixIR dictionary must be an object."
            )
        return cls(
            matrix_id=str(data["matrix_id"]),
            status=cast(ConsumerMatrixStatus, data["status"]),
            target_id=str(data["target_id"]),
            target_version=str(data["target_version"]),
            target_snapshot_id=str(data["target_snapshot_id"]),
            target_snapshot_hash=str(data["target_snapshot_hash"]),
            calibration_refs=dict(data.get("calibration_refs", {})),
            consumer_formats=tuple(
                cast(TargetProjectionFormat, item)
                for item in data.get("consumer_formats", ())
            ),
            projection_ids=tuple(str(item) for item in data.get("projection_ids", ())),
            conformances=tuple(
                TargetProjectionConsumerConformanceIR.from_dict(item)
                for item in data.get("conformances", ())
            ),
            required_capability_summary=dict(
                data.get("required_capability_summary", {})
            ),
            consumed_capability_summary=dict(
                data.get("consumed_capability_summary", {})
            ),
            missing_capability_summary=dict(
                data.get("missing_capability_summary", {})
            ),
            diagnostics=tuple(
                _diagnostic_from_any(item) for item in data.get("diagnostics", ())
            ),
            metadata_only=bool(data.get("metadata_only", True)),
            projection_facts_authoritative=bool(
                data.get("projection_facts_authoritative", True)
            ),
            independent_capability_facts=bool(
                data.get("independent_capability_facts", False)
            ),
            external_object_constructed=bool(
                data.get("external_object_constructed", False)
            ),
            live_target_fetch_performed=bool(
                data.get("live_target_fetch_performed", False)
            ),
            live_calibration_fetch_performed=bool(
                data.get("live_calibration_fetch_performed", False)
            ),
            network_accessed=bool(data.get("network_accessed", False)),
            cascaqit_compat_required=bool(
                data.get("cascaqit_compat_required", False)
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> TargetProjectionConsumerMatrixIR:
        """Build consumer matrix from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError(
                "TargetProjectionConsumerMatrixIR JSON must contain an object."
            )
        return cls.from_dict(data)


def project_target_capabilities(
    target_snapshot: TargetSnapshot,
    *,
    projection_format: TargetProjectionFormat,
    calibration_snapshot: CalibrationSnapshot | None = None,
    projection_id: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> TargetProjectionIR:
    """Project CASCAQit target facts into adapter-facing capabilities."""
    if not isinstance(target_snapshot, TargetSnapshot):
        raise TypeError("target_snapshot must be TargetSnapshot.")
    if calibration_snapshot is not None and not isinstance(
        calibration_snapshot,
        CalibrationSnapshot,
    ):
        raise TypeError("calibration_snapshot must be CalibrationSnapshot.")
    if (
        calibration_snapshot is not None
        and calibration_snapshot.target_id != target_snapshot.target_id
    ):
        raise ValueError("CalibrationSnapshot target_id must match TargetSnapshot.")
    target = target_snapshot.target_spec
    timing = _timing_summary(target)
    readout = _readout_summary(target)
    shot_limits = _shot_limits(target)
    bit_order = _bit_order_summary(projection_format)
    measurement_constraints = _measurement_constraints(target)
    control_channels = _control_channel_projection(target)
    calibration_refs = _calibration_refs(calibration_snapshot)
    capabilities = _projection_capabilities(
        target=target,
        projection_format=projection_format,
        timing=timing,
        readout=readout,
        shot_limits=shot_limits,
        bit_order=bit_order,
        measurement_constraints=measurement_constraints,
        calibration_refs=calibration_refs,
    )
    status = _projection_status(capabilities)
    return TargetProjectionIR(
        projection_id=projection_id
        or (
            f"target_projection.{target_snapshot.target_id}."
            f"{projection_format}.{target_snapshot.target_snapshot_hash[:12]}"
        ),
        projection_format=projection_format,
        status=status,
        target_id=target_snapshot.target_id,
        target_version=target_snapshot.target_version,
        target_snapshot_id=target_snapshot.snapshot_id,
        target_snapshot_hash=target_snapshot.target_snapshot_hash,
        capabilities=capabilities,
        timing=timing,
        readout=readout,
        shot_limits=shot_limits,
        bit_order=bit_order,
        measurement_constraints=measurement_constraints,
        control_channels=control_channels,
        calibration_refs=calibration_refs,
        external_object_constructed=False,
        live_target_fetch_performed=False,
        live_calibration_fetch_performed=False,
        network_accessed=False,
        cascaqit_compat_required=False,
        metadata={
            "builder": "project_target_capabilities",
            "metadata_only": True,
            "source_of_truth": "CASCAQit TargetSnapshot",
            "target_snapshot_hash": target_snapshot.target_snapshot_hash,
            "calibration_snapshot_hash": None
            if calibration_snapshot is None
            else calibration_snapshot.calibration_snapshot_hash,
            "external_framework_object": None,
            **({} if metadata is None else metadata),
        },
    )


def build_target_projection_consumer_conformance(
    projection: TargetProjectionIR,
    *,
    consumer_format: TargetProjectionFormat | None = None,
    required_capability_ids: tuple[str, ...] | None = None,
    conformance_id: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> TargetProjectionConsumerConformanceIR:
    """Check that a projection consumer uses only TargetProjectionIR facts."""
    if not isinstance(projection, TargetProjectionIR):
        raise TypeError("projection must be TargetProjectionIR.")
    consumer = consumer_format or projection.projection_format
    required = required_capability_ids or _consumer_required_capability_ids(consumer)
    consumed = _consumed_capability_ids(projection, required)
    missing = tuple(sorted(set(required) - set(consumed)))
    diagnostics = _consumer_conformance_diagnostics(
        projection=projection,
        consumer_format=consumer,
        missing_capability_ids=missing,
    )
    status: ConsumerConformanceStatus = "blocked" if diagnostics else "ready"
    return TargetProjectionConsumerConformanceIR(
        conformance_id=conformance_id
        or f"target_projection_consumer.{projection.projection_id}.{consumer}",
        consumer_format=consumer,
        status=status,
        projection_id=projection.projection_id,
        projection_status=projection.status,
        target_id=projection.target_id,
        target_version=projection.target_version,
        target_snapshot_id=projection.target_snapshot_id,
        target_snapshot_hash=projection.target_snapshot_hash,
        calibration_refs=projection.calibration_refs,
        required_capability_ids=required,
        consumed_capability_ids=consumed,
        missing_capability_ids=missing,
        consumer_expectations=_consumer_expectations(
            projection=projection,
            consumer_format=consumer,
            required_capability_ids=required,
        ),
        diagnostics=diagnostics,
        metadata_only=True,
        projection_facts_authoritative=True,
        independent_capability_facts=False,
        external_object_constructed=False,
        live_target_fetch_performed=False,
        live_calibration_fetch_performed=False,
        network_accessed=False,
        cascaqit_compat_required=False,
        metadata={
            "builder": "build_target_projection_consumer_conformance",
            "metadata_only": True,
            "source_of_truth": "TargetProjectionIR",
            "projection_id": projection.projection_id,
            "target_snapshot_hash": projection.target_snapshot_hash,
            "calibration_snapshot_hash": projection.calibration_refs.get(
                "calibration_snapshot_hash"
            ),
            "projection_facts_authoritative": True,
            "independent_capability_facts": False,
            "external_object_constructed": False,
            "live_target_fetch_performed": False,
            "live_calibration_fetch_performed": False,
            "network_accessed": False,
            "cascaqit_compat_required": False,
            **({} if metadata is None else metadata),
        },
    )


def build_target_projection_consumer_matrix(
    projections: tuple[TargetProjectionIR, ...],
    *,
    consumer_formats: tuple[TargetProjectionFormat, ...] | None = None,
    required_capability_overrides: dict[
        TargetProjectionFormat,
        tuple[str, ...],
    ] | None = None,
    matrix_id: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> TargetProjectionConsumerMatrixIR:
    """Build a matrix proving consumers share TargetProjectionIR facts."""
    if not projections:
        raise ValueError("At least one TargetProjectionIR is required.")
    for projection in projections:
        if not isinstance(projection, TargetProjectionIR):
            raise TypeError("projections must contain TargetProjectionIR.")
    formats = consumer_formats or tuple(
        projection.projection_format for projection in projections
    )
    projection_by_format = {
        projection.projection_format: projection for projection in projections
    }
    missing_projection_formats = tuple(
        consumer_format
        for consumer_format in formats
        if consumer_format not in projection_by_format
    )
    if missing_projection_formats:
        raise ValueError("consumer_formats must have matching projections.")
    conformances = tuple(
        build_target_projection_consumer_conformance(
            projection_by_format[consumer_format],
            consumer_format=consumer_format,
            required_capability_ids=None
            if required_capability_overrides is None
            else required_capability_overrides.get(consumer_format),
            conformance_id=(
                f"target_projection_consumer_matrix."
                f"{projection_by_format[consumer_format].projection_id}."
                f"{consumer_format}"
            ),
        )
        for consumer_format in formats
    )
    _validate_matrix_shared_facts(projections)
    diagnostics = _consumer_matrix_diagnostics(conformances)
    status: ConsumerMatrixStatus = (
        "blocked"
        if diagnostics or any(item.status == "blocked" for item in conformances)
        else "ready"
    )
    first = projections[0]
    return TargetProjectionConsumerMatrixIR(
        matrix_id=matrix_id
        or f"target_projection_consumer_matrix.{first.target_snapshot_hash[:12]}",
        status=status,
        target_id=first.target_id,
        target_version=first.target_version,
        target_snapshot_id=first.target_snapshot_id,
        target_snapshot_hash=first.target_snapshot_hash,
        calibration_refs=first.calibration_refs,
        consumer_formats=formats,
        projection_ids=tuple(projection.projection_id for projection in projections),
        conformances=conformances,
        required_capability_summary=_matrix_capability_summary(
            conformances,
            field_name="required_capability_ids",
        ),
        consumed_capability_summary=_matrix_capability_summary(
            conformances,
            field_name="consumed_capability_ids",
        ),
        missing_capability_summary=_matrix_capability_summary(
            conformances,
            field_name="missing_capability_ids",
        ),
        diagnostics=diagnostics,
        metadata_only=True,
        projection_facts_authoritative=True,
        independent_capability_facts=False,
        external_object_constructed=False,
        live_target_fetch_performed=False,
        live_calibration_fetch_performed=False,
        network_accessed=False,
        cascaqit_compat_required=False,
        metadata={
            "builder": "build_target_projection_consumer_matrix",
            "metadata_only": True,
            "source_of_truth": "TargetProjectionIR",
            "consumer_count": len(conformances),
            "consumer_formats": list(formats),
            "projection_ids": [projection.projection_id for projection in projections],
            "target_snapshot_hash": first.target_snapshot_hash,
            "calibration_snapshot_hash": first.calibration_refs.get(
                "calibration_snapshot_hash"
            ),
            "projection_facts_authoritative": True,
            "independent_capability_facts": False,
            "external_object_constructed": False,
            "live_target_fetch_performed": False,
            "live_calibration_fetch_performed": False,
            "network_accessed": False,
            "cascaqit_compat_required": False,
            **({} if metadata is None else metadata),
        },
    )


def _projection_capabilities(
    *,
    target: TargetSpec,
    projection_format: TargetProjectionFormat,
    timing: dict[str, Any],
    readout: dict[str, Any],
    shot_limits: dict[str, Any],
    bit_order: dict[str, Any],
    measurement_constraints: dict[str, Any],
    calibration_refs: dict[str, Any],
) -> tuple[TargetProjectionCapabilityIR, ...]:
    capabilities: list[TargetProjectionCapabilityIR] = []
    typed = target.typed_capabilities
    for program_type in _supported_program_types(target):
        capabilities.append(
            TargetProjectionCapabilityIR(
                capability_id=f"program_type.{program_type}",
                capability_type="program_type",
                name=program_type,
                status="supported",
                operation_names=(program_type,),
                metadata={"projection_format": projection_format},
            )
        )
    if typed is not None:
        for operation in typed.analog_operations:
            capabilities.append(
                TargetProjectionCapabilityIR(
                    capability_id=f"analog_operation.{operation.operation}",
                    capability_type="analog_operation",
                    name=operation.operation,
                    status=operation.status,
                    operation_names=(operation.operation,),
                    timing=timing,
                    control_refs=operation.channel_refs,
                    calibration_refs=calibration_refs,
                    metadata={
                        "projection_format": projection_format,
                        "addressing": list(operation.addressing),
                        "fields": list(operation.fields),
                        **operation.metadata,
                    },
                )
            )
        for gate in typed.digital_gates:
            capabilities.append(
                TargetProjectionCapabilityIR(
                    capability_id=f"digital_gate.{gate.gate}",
                    capability_type="digital_gate",
                    name=gate.gate,
                    status=gate.status,
                    operation_names=(gate.gate,),
                    arity=gate.arity,
                    parameter_names=gate.parameter_names,
                    timing={
                        "duration": gate.duration,
                        "duration_unit": gate.duration_unit,
                    },
                    bit_order=bit_order,
                    control_refs=gate.channel_refs,
                    calibration_refs=_digital_gate_calibration_refs(
                        calibration_refs,
                        gate.gate,
                    ),
                    metadata={
                        "projection_format": projection_format,
                        "native": gate.native,
                        **gate.metadata,
                    },
                )
            )
        if typed.readout is not None:
            capabilities.append(
                TargetProjectionCapabilityIR(
                    capability_id="readout.native",
                    capability_type="readout",
                    name="readout",
                    status=typed.readout.status,
                    operation_names=("measure",),
                    readout=readout,
                    shot_limits=shot_limits,
                    bit_order=bit_order,
                    measurement_constraints=measurement_constraints,
                    control_refs=typed.readout.channel_refs,
                    calibration_refs=calibration_refs,
                    metadata={"projection_format": projection_format},
                )
            )
    else:
        capabilities.extend(_legacy_capabilities(target, projection_format))
    capabilities.extend(
        (
            TargetProjectionCapabilityIR(
                capability_id="timing.native",
                capability_type="timing",
                name="timing",
                status="supported",
                timing=timing,
                metadata={"projection_format": projection_format},
            ),
            TargetProjectionCapabilityIR(
                capability_id="shot_limit.native",
                capability_type="shot_limit",
                name="shots",
                status="supported",
                shot_limits=shot_limits,
                metadata={"projection_format": projection_format},
            ),
            TargetProjectionCapabilityIR(
                capability_id="measurement.terminal",
                capability_type="measurement",
                name="terminal_measurement",
                status="supported",
                operation_names=("measure",),
                bit_order=bit_order,
                measurement_constraints=measurement_constraints,
                metadata={"projection_format": projection_format},
            ),
        )
    )
    capabilities.extend(_format_boundary_capabilities(projection_format, target))
    return tuple(capabilities)


def _legacy_capabilities(
    target: TargetSpec,
    projection_format: TargetProjectionFormat,
) -> tuple[TargetProjectionCapabilityIR, ...]:
    capabilities: list[TargetProjectionCapabilityIR] = []
    for key, raw_status in sorted(target.capabilities.items()):
        if key == "supported_program_types":
            continue
        status = _status_from_capability_value(raw_status)
        capabilities.append(
            TargetProjectionCapabilityIR(
                capability_id=f"legacy.{key}",
                capability_type="boundary",
                name=key,
                status=status,
                operation_names=(key,),
                metadata={
                    "projection_format": projection_format,
                    "source": "TargetSpec.capabilities",
                    "raw_status": raw_status,
                },
            )
        )
    return tuple(capabilities)


def _format_boundary_capabilities(
    projection_format: TargetProjectionFormat,
    target: TargetSpec,
) -> tuple[TargetProjectionCapabilityIR, ...]:
    if projection_format == "qiskit_target":
        return (
            TargetProjectionCapabilityIR(
                capability_id="boundary.qiskit_external_object",
                capability_type="boundary",
                name="qiskit_target_object_construction",
                status="unsupported",
                metadata={
                    "reason": "Native SDK exposes projection facts only.",
                    "external_object_constructed": False,
                },
            ),
        )
    if projection_format == "openqasm_validator":
        return (
            TargetProjectionCapabilityIR(
                capability_id="boundary.openqasm_dynamic_circuits",
                capability_type="boundary",
                name="dynamic_circuit_validation",
                status=_status_from_capability_value(
                    target.capabilities.get("mid_circuit_measurement", "unsupported")
                ),
                operation_names=("mid_circuit_measurement",),
                measurement_constraints=_measurement_constraints(target),
            ),
        )
    if projection_format == "analog_constraints":
        return (
            TargetProjectionCapabilityIR(
                capability_id="boundary.analog_geometry",
                capability_type="boundary",
                name="programmable_geometry",
                status="supported",
                metadata={
                    "max_atoms": target.max_atoms,
                    "programmable_region": target.programmable_region.to_dict(),
                    "min_atom_spacing": target.min_atom_spacing,
                    "coordinate_unit": target.coordinate_unit,
                },
            ),
        )
    return (
        TargetProjectionCapabilityIR(
            capability_id="boundary.hybrid_backend_execution",
            capability_type="boundary",
            name="hybrid_backend_execution",
            status="unsupported",
            metadata={
                "hybrid_ir": target.capabilities.get("hybrid_block", "unknown"),
                "reason": "Hybrid backend execution remains reserved.",
            },
        ),
    )


def _projection_status(
    capabilities: tuple[TargetProjectionCapabilityIR, ...],
) -> ProjectionStatus:
    if all(capability.status == "unsupported" for capability in capabilities):
        return "blocked"
    if any(
        capability.status in {"unsupported", "ir_only", "experimental"}
        for capability in capabilities
    ):
        return "partial"
    return "ready"


def _consumer_required_capability_ids(
    consumer_format: TargetProjectionFormat,
) -> tuple[str, ...]:
    common = (
        "timing.native",
        "shot_limit.native",
        "measurement.terminal",
        "readout.native",
    )
    if consumer_format == "qiskit_target":
        return (
            *common,
            "program_type.digital",
            "digital_gate.h",
            "digital_gate.cx",
            "boundary.qiskit_external_object",
        )
    if consumer_format == "openqasm_validator":
        return (
            *common,
            "program_type.digital",
            "digital_gate.h",
            "digital_gate.cx",
            "boundary.openqasm_dynamic_circuits",
        )
    if consumer_format == "analog_constraints":
        return (
            *common,
            "program_type.analog",
            "analog_operation.global_rydberg_drive",
            "boundary.analog_geometry",
        )
    return (
        *common,
        "boundary.hybrid_backend_execution",
    )


def _consumed_capability_ids(
    projection: TargetProjectionIR,
    required_capability_ids: tuple[str, ...],
) -> tuple[str, ...]:
    available = {capability.capability_id for capability in projection.capabilities}
    return tuple(sorted(item for item in required_capability_ids if item in available))


def _consumer_expectations(
    *,
    projection: TargetProjectionIR,
    consumer_format: TargetProjectionFormat,
    required_capability_ids: tuple[str, ...],
) -> tuple[dict[str, Any], ...]:
    by_id = {
        capability.capability_id: capability
        for capability in projection.capabilities
    }
    expectations = []
    for capability_id in required_capability_ids:
        capability = by_id.get(capability_id)
        expectations.append(
            {
                "consumer_format": consumer_format,
                "capability_id": capability_id,
                "present": capability is not None,
                "status": None if capability is None else capability.status,
                "source_path": f"TargetProjectionIR.capabilities[{capability_id}]",
                "target_snapshot_hash": projection.target_snapshot_hash,
                "calibration_refs": _expectation_calibration_refs(capability),
                "projection_facts_authoritative": True,
                "independent_capability_facts": False,
                "external_object_constructed": False,
            }
        )
    expectations.extend(
        (
            {
                "consumer_format": consumer_format,
                "capability_id": "projection.timing",
                "present": bool(projection.timing),
                "status": "available" if projection.timing else "missing",
                "source_path": "TargetProjectionIR.timing",
                "target_snapshot_hash": projection.target_snapshot_hash,
                "projection_facts_authoritative": True,
                "independent_capability_facts": False,
                "external_object_constructed": False,
            },
            {
                "consumer_format": consumer_format,
                "capability_id": "projection.calibration_refs",
                "present": bool(projection.calibration_refs),
                "status": "available" if projection.calibration_refs else "missing",
                "source_path": "TargetProjectionIR.calibration_refs",
                "target_snapshot_hash": projection.target_snapshot_hash,
                "calibration_refs": projection.calibration_refs,
                "projection_facts_authoritative": True,
                "independent_capability_facts": False,
                "external_object_constructed": False,
            },
        )
    )
    return tuple(expectations)


def _expectation_calibration_refs(
    capability: TargetProjectionCapabilityIR | None,
) -> dict[str, Any]:
    if capability is None:
        return {}
    return dict(capability.calibration_refs)


def _consumer_conformance_diagnostics(
    *,
    projection: TargetProjectionIR,
    consumer_format: TargetProjectionFormat,
    missing_capability_ids: tuple[str, ...],
) -> tuple[DiagnosticsIR, ...]:
    diagnostics: list[DiagnosticsIR] = []
    if missing_capability_ids:
        diagnostics.append(
            _consumer_diagnostic(
                diagnostic_id=(
                    f"target_projection_consumer.{consumer_format}.missing_capabilities"
                ),
                code="TARGET_PROJECTION_CONSUMER_MISSING_CAPABILITY",
                message=(
                    "Projection consumer is missing required TargetProjectionIR "
                    "capability facts."
                ),
                object_path="TargetProjectionIR.capabilities",
                suggestion=(
                    "Regenerate TargetProjectionIR from CASCAQit TargetSnapshot "
                    "and CalibrationSnapshot facts; do not invent consumer-local "
                    "capabilities."
                ),
                metadata={
                    "consumer_format": consumer_format,
                    "missing_capability_ids": missing_capability_ids,
                    "target_snapshot_hash": projection.target_snapshot_hash,
                    "reason_category": "missing_projection_fact",
                    "action": "block_consumer",
                },
            )
        )
    return tuple(diagnostics)


def _validate_matrix_shared_facts(
    projections: tuple[TargetProjectionIR, ...],
) -> None:
    first = projections[0]
    for projection in projections[1:]:
        if projection.target_id != first.target_id:
            raise ValueError("All projections must share target_id.")
        if projection.target_snapshot_hash != first.target_snapshot_hash:
            raise ValueError("All projections must share target_snapshot_hash.")
        if projection.calibration_refs != first.calibration_refs:
            raise ValueError("All projections must share calibration_refs.")
        if projection.external_object_constructed:
            raise ValueError("Matrix projections must not construct external objects.")
        if projection.live_target_fetch_performed:
            raise ValueError("Matrix projections must not fetch live targets.")
        if projection.live_calibration_fetch_performed:
            raise ValueError("Matrix projections must not fetch live calibrations.")
        if projection.network_accessed:
            raise ValueError("Matrix projections cannot access networks.")
        if projection.cascaqit_compat_required:
            raise ValueError("Matrix projections must not require cascaqit-compat.")


def _matrix_capability_summary(
    conformances: tuple[TargetProjectionConsumerConformanceIR, ...],
    *,
    field_name: Literal[
        "required_capability_ids",
        "consumed_capability_ids",
        "missing_capability_ids",
    ],
) -> dict[str, Any]:
    by_consumer = {
        conformance.consumer_format: list(getattr(conformance, field_name))
        for conformance in conformances
    }
    union = sorted(
        {
            capability_id
            for conformance in conformances
            for capability_id in getattr(conformance, field_name)
        }
    )
    return {
        "by_consumer": by_consumer,
        "union": union,
        "count": len(union),
        "metadata_only": True,
        "projection_facts_authoritative": True,
        "independent_capability_facts": False,
        "external_object_constructed": False,
    }


def _consumer_matrix_diagnostics(
    conformances: tuple[TargetProjectionConsumerConformanceIR, ...],
) -> tuple[DiagnosticsIR, ...]:
    diagnostics: list[DiagnosticsIR] = []
    missing_by_consumer = {
        conformance.consumer_format: conformance.missing_capability_ids
        for conformance in conformances
        if conformance.missing_capability_ids
    }
    if missing_by_consumer:
        diagnostics.append(
            _consumer_diagnostic(
                diagnostic_id="target_projection_consumer_matrix.missing_capabilities",
                code="TARGET_PROJECTION_CONSUMER_MATRIX_MISSING_CAPABILITY",
                message=(
                    "One or more projection consumers are missing required "
                    "TargetProjectionIR capability facts."
                ),
                object_path="TargetProjectionConsumerMatrixIR.conformances",
                suggestion=(
                    "Regenerate projections from the same CASCAQit target facts "
                    "or remove unsupported consumer requirements."
                ),
                metadata={
                    "missing_by_consumer": {
                        consumer: list(items)
                        for consumer, items in missing_by_consumer.items()
                    },
                    "reason_category": "missing_projection_fact",
                    "action": "block_matrix",
                },
            )
        )
    return tuple(diagnostics)


def _consumer_diagnostic(
    *,
    diagnostic_id: str,
    code: str,
    message: str,
    object_path: str,
    suggestion: str,
    metadata: dict[str, Any],
) -> DiagnosticsIR:
    return DiagnosticsIR(
        diagnostic_id=diagnostic_id,
        stage="validation",
        severity="error",
        code=code,
        message=message,
        object_path=object_path,
        suggestion=suggestion,
        metadata={
            "taxonomy_stage": "target_projection_consumer",
            "actionable": True,
            **metadata,
        },
    )


def _supported_program_types(target: TargetSpec) -> tuple[str, ...]:
    typed = target.typed_capabilities
    if typed is not None and typed.supported_program_types:
        return typed.supported_program_types
    raw = target.capabilities.get("supported_program_types", ())
    return tuple(str(item) for item in raw)


def _timing_summary(target: TargetSpec) -> dict[str, Any]:
    typed = target.typed_capabilities
    timing = None if typed is None else typed.timing
    return {
        "time_resolution": target.time_resolution
        if timing is None
        else timing.time_resolution,
        "min_duration": None if timing is None else timing.min_duration,
        "max_duration": None if timing is None else timing.max_duration,
        "alignment": None if timing is None else timing.alignment,
        "duration_unit": target.time_unit if timing is None else timing.duration_unit,
        "target_time_unit": target.time_unit,
    }


def _readout_summary(target: TargetSpec) -> dict[str, Any]:
    typed = target.typed_capabilities
    readout = None if typed is None else typed.readout
    return {
        "basis": list(
            target.supported_measurement_basis if readout is None else readout.basis
        ),
        "status": "supported" if readout is None else readout.status,
        "readout_modes": [] if readout is None else list(readout.readout_modes),
        "supports_shot_counts": True
        if readout is None
        else readout.supports_shot_counts,
        "supports_per_shot_memory": False
        if readout is None
        else readout.supports_per_shot_memory,
    }


def _shot_limits(target: TargetSpec) -> dict[str, Any]:
    return {
        "min_shots": target.shots_range[0],
        "max_shots": target.shots_range[1],
    }


def _bit_order_summary(projection_format: TargetProjectionFormat) -> dict[str, Any]:
    return {
        "analog": {
            "convention": ANALOG_BIT_ORDER_CONVENTION,
            "atom_order_source": "active_register_declaration_order",
            "bitstring_index": "left_to_right_matches_atom_order",
        },
        "digital": {
            "convention": "digital_qubit_order",
            "qubit_order_source": "program_defined",
            "bitstring_index": "left_to_right_matches_qubit_order",
        },
        "projection_format": projection_format,
    }


def _measurement_constraints(target: TargetSpec) -> dict[str, Any]:
    readout = _readout_summary(target)
    return {
        "terminal_measurement_required": True,
        "mid_circuit_measurement": target.capabilities.get(
            "mid_circuit_measurement",
            "unsupported",
        ),
        "supported_basis": list(target.supported_measurement_basis),
        "supports_shot_counts": readout["supports_shot_counts"],
        "supports_per_shot_memory": readout["supports_per_shot_memory"],
    }


def _control_channel_projection(target: TargetSpec) -> tuple[dict[str, Any], ...]:
    global_addressing = {
        "mode_id": "addressing.global",
        "mode": "global",
        "scope": "all_active_sites",
        "supports_site_mask": False,
        "supports_time_dependence": True,
    }
    return (
        {
            "channel_id": "rydberg.rabi.global",
            "channel_type": "rydberg_rabi",
            "addressing": global_addressing,
            "supported_operations": ["global_rydberg_drive"],
            "value_unit": target.frequency_unit,
            "time_unit": target.time_unit,
            "value_range": list(target.rabi_range),
            "resolution": target.amplitude_resolution,
        },
        {
            "channel_id": "rydberg.detuning.global",
            "channel_type": "rydberg_detuning",
            "addressing": global_addressing,
            "supported_operations": ["global_rydberg_drive"],
            "value_unit": target.frequency_unit,
            "time_unit": target.time_unit,
            "value_range": list(target.detuning_range),
            "resolution": target.detuning_resolution,
        },
        {
            "channel_id": "rydberg.phase.global",
            "channel_type": "rydberg_phase",
            "addressing": global_addressing,
            "supported_operations": ["global_rydberg_drive"],
            "value_unit": "rad",
            "time_unit": target.time_unit,
            "value_range": list(target.phase_range),
            "resolution": target.phase_resolution,
        },
    )


def _calibration_refs(
    calibration_snapshot: CalibrationSnapshot | None,
) -> dict[str, Any]:
    if calibration_snapshot is None:
        return {"calibration_attached": False}
    return {
        "calibration_attached": True,
        "calibration_profile_id": calibration_snapshot.calibration_profile_id,
        "calibration_snapshot_hash": calibration_snapshot.calibration_snapshot_hash,
        "target_id": calibration_snapshot.target_id,
        "readout_config_hash": calibration_snapshot.readout_config_hash,
        "pulse_param_hash": calibration_snapshot.pulse_param_hash,
        "channel_map_hash": calibration_snapshot.channel_map_hash,
        "digital_gate_calibrations": {
            gate.gate: {
                "status": gate.status,
                "duration": gate.duration,
                "duration_unit": gate.duration_unit,
                "error_rate": gate.error_rate,
                "calibration_ref": gate.calibration_ref,
                "calibration_hash": gate.calibration_hash,
            }
            for gate in calibration_snapshot.digital_gate_calibrations
        },
    }


def _digital_gate_calibration_refs(
    calibration_refs: dict[str, Any],
    gate: str,
) -> dict[str, Any]:
    gate_refs = dict(calibration_refs.get("digital_gate_calibrations", {}))
    if gate not in gate_refs:
        return {
            "calibration_attached": calibration_refs.get(
                "calibration_attached",
                False,
            ),
            "gate_calibration_attached": False,
        }
    return {
        "calibration_attached": calibration_refs.get("calibration_attached", False),
        "gate_calibration_attached": True,
        "gate": gate,
        **dict(gate_refs[gate]),
    }


def _status_from_capability_value(value: Any) -> CapabilityStatus:
    text = str(value)
    if text == "supported":
        return "supported"
    if text == "ir_only":
        return "ir_only"
    if text == "experimental":
        return "experimental"
    if text == "deprecated":
        return "deprecated"
    return "unsupported"


def _diagnostic_from_any(item: DiagnosticsIR | dict[str, Any]) -> DiagnosticsIR:
    if isinstance(item, DiagnosticsIR):
        return item
    if isinstance(item, dict):
        return DiagnosticsIR.from_dict(item)
    raise TypeError("diagnostics must contain DiagnosticsIR or dictionaries.")
