"""Target specification models for the CASCAQit MVP."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Literal

from cascaqit.control.types import ChannelType, validate_channel_type
from cascaqit.native_ir.base import IRMixin
from cascaqit.native_ir.models import SCHEMA_VERSION, UnitConventions, WaveformKind

__all__ = [
    "AnalogOperationCapability",
    "CalibrationSnapshot",
    "ChannelCrosstalkCapability",
    "ChannelTimingCapability",
    "DigitalGateCalibrationSummary",
    "PulseChannelCalibrationSummary",
    "ReadoutCalibrationSummary",
    "CapabilityStatus",
    "DigitalGateCapability",
    "ProgrammableRegion",
    "ReadoutCapability",
    "TargetCapabilityProfile",
    "TargetSnapshot",
    "TargetSpec",
    "TimingCapability",
]

TargetStatus = Literal["available", "offline", "maintenance", "unknown"]
CapabilityStatus = Literal[
    "supported",
    "unsupported",
    "ir_only",
    "experimental",
    "deprecated",
]
CrosstalkOverlapPolicy = Literal[
    "allowed",
    "forbidden",
    "calibration_required",
]


@dataclass(frozen=True)
class AnalogOperationCapability(IRMixin):
    """Typed capability for an analog native operation."""

    operation: str
    status: CapabilityStatus
    channel_type: ChannelType | None = None
    addressing: tuple[str, ...] = ()
    fields: tuple[str, ...] = ()
    channel_refs: tuple[str, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        object.__setattr__(self, "status", _capability_status(self.status))
        if self.channel_type is not None:
            object.__setattr__(
                self,
                "channel_type",
                validate_channel_type(self.channel_type),
            )

    def to_dict(self) -> dict[str, Any]:
        """Omit the optional channel type for legacy target hash stability."""
        data = super().to_dict()
        if self.channel_type is None:
            data.pop("channel_type")
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> AnalogOperationCapability:
        """Build an analog operation capability from a dictionary."""
        return cls(
            operation=str(data["operation"]),
            status=_capability_status(data["status"]),
            channel_type=(
                None
                if data.get("channel_type") is None
                else validate_channel_type(data["channel_type"])
            ),
            addressing=tuple(str(item) for item in data.get("addressing", ())),
            fields=tuple(str(item) for item in data.get("fields", ())),
            channel_refs=tuple(str(item) for item in data.get("channel_refs", ())),
            metadata=dict(data.get("metadata", {})),
        )


@dataclass(frozen=True)
class DigitalGateCapability(IRMixin):
    """Typed capability for a digital gate family."""

    gate: str
    status: CapabilityStatus
    arity: int
    native: bool = False
    parameter_names: tuple[str, ...] = ()
    duration: float | None = None
    duration_unit: str = "us"
    channel_refs: tuple[str, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DigitalGateCapability:
        """Build a digital gate capability from a dictionary."""
        return cls(
            gate=str(data["gate"]),
            status=_capability_status(data["status"]),
            arity=int(data["arity"]),
            native=bool(data.get("native", False)),
            parameter_names=tuple(
                str(item) for item in data.get("parameter_names", ())
            ),
            duration=None
            if data.get("duration") is None
            else float(data["duration"]),
            duration_unit=str(data.get("duration_unit", "us")),
            channel_refs=tuple(str(item) for item in data.get("channel_refs", ())),
            metadata=dict(data.get("metadata", {})),
        )


@dataclass(frozen=True)
class ReadoutCapability(IRMixin):
    """Typed target readout capability summary."""

    basis: tuple[str, ...]
    status: CapabilityStatus
    readout_modes: tuple[str, ...] = ()
    supports_shot_counts: bool = True
    supports_per_shot_memory: bool = False
    channel_refs: tuple[str, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ReadoutCapability:
        """Build a readout capability from a dictionary."""
        return cls(
            basis=tuple(str(item) for item in data["basis"]),
            status=_capability_status(data["status"]),
            readout_modes=tuple(str(item) for item in data.get("readout_modes", ())),
            supports_shot_counts=bool(data.get("supports_shot_counts", True)),
            supports_per_shot_memory=bool(
                data.get("supports_per_shot_memory", False)
            ),
            channel_refs=tuple(str(item) for item in data.get("channel_refs", ())),
            metadata=dict(data.get("metadata", {})),
        )


@dataclass(frozen=True)
class TimingCapability(IRMixin):
    """Typed timing and alignment capability summary."""

    time_resolution: float
    min_duration: float | None = None
    max_duration: float | None = None
    alignment: float | None = None
    duration_unit: str = "us"
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TimingCapability:
        """Build a timing capability from a dictionary."""
        return cls(
            time_resolution=float(data["time_resolution"]),
            min_duration=None
            if data.get("min_duration") is None
            else float(data["min_duration"]),
            max_duration=None
            if data.get("max_duration") is None
            else float(data["max_duration"]),
            alignment=None
            if data.get("alignment") is None
            else float(data["alignment"]),
            duration_unit=str(data.get("duration_unit", "us")),
            metadata=dict(data.get("metadata", {})),
        )


@dataclass(frozen=True)
class ChannelTimingCapability(IRMixin):
    """Target-owned timing and signal limits for one control channel."""

    channel_id: str
    concurrency_group: str | None = None
    max_concurrent_operations: int | None = None
    mutually_exclusive_channel_ids: tuple[str, ...] = ()
    bandwidth_limit: float | None = None
    bandwidth_unit: str | None = None
    max_slew_rate: float | None = None
    slew_rate_unit: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.channel_id:
            raise ValueError("channel_id must not be empty.")
        if (
            self.max_concurrent_operations is not None
            and self.max_concurrent_operations <= 0
        ):
            raise ValueError("max_concurrent_operations must be positive.")
        _validate_optional_positive_limit(
            self.bandwidth_limit,
            self.bandwidth_unit,
            value_name="bandwidth_limit",
            unit_name="bandwidth_unit",
        )
        _validate_optional_positive_limit(
            self.max_slew_rate,
            self.slew_rate_unit,
            value_name="max_slew_rate",
            unit_name="slew_rate_unit",
        )
        if self.channel_id in self.mutually_exclusive_channel_ids:
            raise ValueError("A channel cannot be mutually exclusive with itself.")
        if len(set(self.mutually_exclusive_channel_ids)) != len(
            self.mutually_exclusive_channel_ids
        ):
            raise ValueError("mutually_exclusive_channel_ids must be unique.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ChannelTimingCapability:
        """Build channel timing facts from their current JSON shape."""
        return cls(
            channel_id=str(data["channel_id"]),
            concurrency_group=data["concurrency_group"],
            max_concurrent_operations=None
            if data["max_concurrent_operations"] is None
            else int(data["max_concurrent_operations"]),
            mutually_exclusive_channel_ids=tuple(
                str(item) for item in data["mutually_exclusive_channel_ids"]
            ),
            bandwidth_limit=None
            if data["bandwidth_limit"] is None
            else float(data["bandwidth_limit"]),
            bandwidth_unit=data["bandwidth_unit"],
            max_slew_rate=None
            if data["max_slew_rate"] is None
            else float(data["max_slew_rate"]),
            slew_rate_unit=data["slew_rate_unit"],
            metadata=dict(data["metadata"]),
        )


@dataclass(frozen=True)
class ChannelCrosstalkCapability(IRMixin):
    """Target-owned overlap policy for a pair of control channels."""

    left_channel_id: str
    right_channel_id: str
    overlap_policy: CrosstalkOverlapPolicy
    max_overlap_duration: float | None = None
    time_unit: str = "us"
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.left_channel_id or not self.right_channel_id:
            raise ValueError("Crosstalk channel ids must not be empty.")
        if self.left_channel_id == self.right_channel_id:
            raise ValueError("Crosstalk facts require two different channels.")
        if self.overlap_policy not in {
            "allowed",
            "forbidden",
            "calibration_required",
        }:
            raise ValueError(f"Unsupported overlap policy: {self.overlap_policy!r}.")
        if self.max_overlap_duration is not None:
            if self.max_overlap_duration <= 0:
                raise ValueError("max_overlap_duration must be positive.")
            if self.overlap_policy != "allowed":
                raise ValueError(
                    f"{self.overlap_policy} crosstalk cannot declare a numeric "
                    "max_overlap_duration."
                )
        if not self.time_unit:
            raise ValueError("time_unit must not be empty.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ChannelCrosstalkCapability:
        """Build channel-pair crosstalk facts from their current JSON shape."""
        return cls(
            left_channel_id=str(data["left_channel_id"]),
            right_channel_id=str(data["right_channel_id"]),
            overlap_policy=data["overlap_policy"],
            max_overlap_duration=None
            if data["max_overlap_duration"] is None
            else float(data["max_overlap_duration"]),
            time_unit=str(data["time_unit"]),
            metadata=dict(data["metadata"]),
        )


@dataclass(frozen=True)
class TargetCapabilityProfile(IRMixin):
    """Compiler-facing typed target capability profile."""

    analog_operations: tuple[AnalogOperationCapability, ...] = ()
    digital_gates: tuple[DigitalGateCapability, ...] = ()
    readout: ReadoutCapability | None = None
    timing: TimingCapability | None = None
    control_timing: tuple[ChannelTimingCapability, ...] = ()
    control_crosstalk: tuple[ChannelCrosstalkCapability, ...] = ()
    supported_program_types: tuple[str, ...] = ()
    control_refs: tuple[str, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        timing_channels = [item.channel_id for item in self.control_timing]
        if len(timing_channels) != len(set(timing_channels)):
            raise ValueError("control_timing channel ids must be unique.")
        pair_keys = [
            frozenset((item.left_channel_id, item.right_channel_id))
            for item in self.control_crosstalk
        ]
        if len(pair_keys) != len(set(pair_keys)):
            raise ValueError("control_crosstalk channel pairs must be unique.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TargetCapabilityProfile:
        """Build a typed target capability profile from a dictionary."""
        readout_data = data.get("readout")
        timing_data = data.get("timing")
        return cls(
            analog_operations=tuple(
                AnalogOperationCapability.from_dict(item)
                for item in data.get("analog_operations", ())
            ),
            digital_gates=tuple(
                DigitalGateCapability.from_dict(item)
                for item in data.get("digital_gates", ())
            ),
            readout=None
            if readout_data is None
            else ReadoutCapability.from_dict(readout_data),
            timing=None
            if timing_data is None
            else TimingCapability.from_dict(timing_data),
            control_timing=tuple(
                ChannelTimingCapability.from_dict(item)
                for item in data["control_timing"]
            ),
            control_crosstalk=tuple(
                ChannelCrosstalkCapability.from_dict(item)
                for item in data["control_crosstalk"]
            ),
            supported_program_types=tuple(
                str(item) for item in data.get("supported_program_types", ())
            ),
            control_refs=tuple(str(item) for item in data.get("control_refs", ())),
            metadata=dict(data.get("metadata", {})),
        )

    def analog_status(self, operation: str) -> CapabilityStatus | None:
        """Return the support status for an analog operation, if declared."""
        for capability in self.analog_operations:
            if capability.operation == operation:
                return capability.status
        return None

    def digital_gate_status(self, gate: str) -> CapabilityStatus | None:
        """Return the support status for a digital gate, if declared."""
        for capability in self.digital_gates:
            if capability.gate == gate:
                return capability.status
        return None


def _validate_optional_positive_limit(
    value: float | None,
    unit: str | None,
    *,
    value_name: str,
    unit_name: str,
) -> None:
    """Keep optional physical values and their units present as one fact."""
    if (value is None) != (unit is None):
        raise ValueError(f"{value_name} and {unit_name} must be provided together.")
    if value is not None and value <= 0:
        raise ValueError(f"{value_name} must be positive.")
    if unit is not None and not unit:
        raise ValueError(f"{unit_name} must not be empty.")


@dataclass(frozen=True)
class ProgrammableRegion(IRMixin):
    """Rectangular two-dimensional programmable atom placement region."""

    x_min: float
    x_max: float
    y_min: float
    y_max: float

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ProgrammableRegion:
        """Build a programmable region from a JSON-compatible dictionary."""
        return cls(
            x_min=float(data["x_min"]),
            x_max=float(data["x_max"]),
            y_min=float(data["y_min"]),
            y_max=float(data["y_max"]),
        )


@dataclass(frozen=True)
class TargetSpec(IRMixin):
    """Static target capability snapshot used by validation and discretization."""

    target_id: str
    target_name: str
    max_atoms: int
    programmable_region: ProgrammableRegion
    min_atom_spacing: float
    time_resolution: float
    rabi_range: tuple[float, float]
    detuning_range: tuple[float, float]
    phase_range: tuple[float, float]
    amplitude_resolution: float
    detuning_resolution: float
    phase_resolution: float
    supported_waveforms: tuple[WaveformKind, ...]
    supported_measurement_basis: tuple[str, ...]
    shots_range: tuple[int, int]
    schema_version: str = SCHEMA_VERSION
    coordinate_unit: str = "um"
    time_unit: str = "us"
    frequency_unit: str = "rad/us"
    capabilities: dict[str, Any] = field(default_factory=dict)
    typed_capabilities: TargetCapabilityProfile | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TargetSpec:
        """Build a target specification from the MVP JSON representation."""
        return cls(
            target_id=str(data["target_id"]),
            target_name=str(data["target_name"]),
            max_atoms=int(data["max_atoms"]),
            programmable_region=ProgrammableRegion.from_dict(
                data["programmable_region"]
            ),
            min_atom_spacing=float(data["min_atom_spacing"]),
            time_resolution=float(data["time_resolution"]),
            rabi_range=_float_pair(data["rabi_range"]),
            detuning_range=_float_pair(data["detuning_range"]),
            phase_range=_float_pair(data["phase_range"]),
            amplitude_resolution=float(data["amplitude_resolution"]),
            detuning_resolution=float(data["detuning_resolution"]),
            phase_resolution=float(data["phase_resolution"]),
            supported_waveforms=tuple(data["supported_waveforms"]),
            supported_measurement_basis=tuple(
                str(item) for item in data["supported_measurement_basis"]
            ),
            shots_range=_int_pair(data["shots_range"]),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            coordinate_unit=str(data.get("coordinate_unit", "um")),
            time_unit=str(data.get("time_unit", "us")),
            frequency_unit=str(data.get("frequency_unit", "rad/us")),
            capabilities=dict(data.get("capabilities", {})),
            typed_capabilities=None
            if data.get("typed_capabilities") is None
            else TargetCapabilityProfile.from_dict(data["typed_capabilities"]),
            metadata=dict(data.get("metadata", {})),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-compatible target spec, omitting absent typed facts."""
        data = super().to_dict()
        if self.typed_capabilities is None:
            data.pop("typed_capabilities", None)
        return data

    @classmethod
    def from_json(cls, text: str) -> TargetSpec:
        """Build a target specification from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("TargetSpec JSON must contain an object.")
        return cls.from_dict(data)

    def to_snapshot(
        self,
        *,
        snapshot_id: str | None = None,
        status: TargetStatus = "available",
        source: str = "local",
        effective_at: str | None = None,
        expires_at: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> TargetSnapshot:
        """Return an immutable target snapshot wrapper for this target spec."""
        target_hash = self.stable_hash()
        return TargetSnapshot(
            snapshot_id=snapshot_id or f"{self.target_id}.snapshot.{target_hash[:12]}",
            target_id=self.target_id,
            target_version=self.schema_version,
            target_spec=self,
            target_snapshot_hash=target_hash,
            status=status,
            source=source,
            effective_at=effective_at,
            expires_at=expires_at,
            unit_conventions=UnitConventions(
                coordinate=self.coordinate_unit,
                time=self.time_unit,
                frequency=self.frequency_unit,
                phase="rad",
            ),
            metadata={} if metadata is None else metadata,
        )


@dataclass(frozen=True)
class TargetSnapshot(IRMixin):
    """Immutable target capability snapshot used by compile and execution paths."""

    snapshot_id: str
    target_id: str
    target_version: str
    target_spec: TargetSpec
    target_snapshot_hash: str
    status: TargetStatus = "available"
    source: str = "local"
    effective_at: str | None = None
    expires_at: str | None = None
    schema_version: str = SCHEMA_VERSION
    unit_conventions: UnitConventions = field(default_factory=UnitConventions)
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TargetSnapshot:
        """Build a target snapshot from a JSON-compatible dictionary."""
        return cls(
            snapshot_id=str(data["snapshot_id"]),
            target_id=str(data["target_id"]),
            target_version=str(data["target_version"]),
            target_spec=TargetSpec.from_dict(data["target_spec"]),
            target_snapshot_hash=str(data["target_snapshot_hash"]),
            status=data.get("status", "unknown"),
            source=str(data.get("source", "local")),
            effective_at=data.get("effective_at"),
            expires_at=data.get("expires_at"),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            unit_conventions=UnitConventions.from_dict(
                data.get("unit_conventions", {})
            ),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> TargetSnapshot:
        """Build a target snapshot from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("TargetSnapshot JSON must contain an object.")
        return cls.from_dict(data)

    def verify_hash(self) -> bool:
        """Return whether the embedded target spec matches the snapshot hash."""
        return self.target_snapshot_hash == self.target_spec.stable_hash()


@dataclass(frozen=True)
class ReadoutCalibrationSummary(IRMixin):
    """Structured readout calibration summary without raw calibration data."""

    basis: tuple[str, ...]
    readout_config_hash: str
    confusion_matrix_ref: str | None = None
    confusion_matrix_hash: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ReadoutCalibrationSummary:
        """Build a readout calibration summary from a dictionary."""
        return cls(
            basis=tuple(str(item) for item in data["basis"]),
            readout_config_hash=str(data["readout_config_hash"]),
            confusion_matrix_ref=data.get("confusion_matrix_ref"),
            confusion_matrix_hash=data.get("confusion_matrix_hash"),
            metadata=dict(data.get("metadata", {})),
        )


@dataclass(frozen=True)
class PulseChannelCalibrationSummary(IRMixin):
    """Structured pulse/channel calibration references."""

    pulse_param_hash: str
    channel_map_hash: str
    rabi_calibration_ref: str | None = None
    rabi_calibration_hash: str | None = None
    detuning_calibration_ref: str | None = None
    detuning_calibration_hash: str | None = None
    phase_calibration_ref: str | None = None
    phase_calibration_hash: str | None = None
    valid_from: str | None = None
    valid_to: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PulseChannelCalibrationSummary:
        """Build a pulse/channel calibration summary from a dictionary."""
        return cls(
            pulse_param_hash=str(data["pulse_param_hash"]),
            channel_map_hash=str(data["channel_map_hash"]),
            rabi_calibration_ref=data.get("rabi_calibration_ref"),
            rabi_calibration_hash=data.get("rabi_calibration_hash"),
            detuning_calibration_ref=data.get("detuning_calibration_ref"),
            detuning_calibration_hash=data.get("detuning_calibration_hash"),
            phase_calibration_ref=data.get("phase_calibration_ref"),
            phase_calibration_hash=data.get("phase_calibration_hash"),
            valid_from=data.get("valid_from"),
            valid_to=data.get("valid_to"),
            metadata=dict(data.get("metadata", {})),
        )


@dataclass(frozen=True)
class DigitalGateCalibrationSummary(IRMixin):
    """Structured digital gate calibration summary."""

    gate: str
    status: CapabilityStatus
    qubits: tuple[str, ...] = ()
    duration: float | None = None
    duration_unit: str = "us"
    error_rate: float | None = None
    calibration_ref: str | None = None
    calibration_hash: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DigitalGateCalibrationSummary:
        """Build a digital gate calibration summary from a dictionary."""
        return cls(
            gate=str(data["gate"]),
            status=_capability_status(data["status"]),
            qubits=tuple(str(item) for item in data.get("qubits", ())),
            duration=None
            if data.get("duration") is None
            else float(data["duration"]),
            duration_unit=str(data.get("duration_unit", "us")),
            error_rate=None
            if data.get("error_rate") is None
            else float(data["error_rate"]),
            calibration_ref=data.get("calibration_ref"),
            calibration_hash=data.get("calibration_hash"),
            metadata=dict(data.get("metadata", {})),
        )


@dataclass(frozen=True)
class CalibrationSnapshot(IRMixin):
    """Immutable calibration snapshot reference for future hardware execution."""

    calibration_profile_id: str
    calibration_snapshot_hash: str
    target_id: str
    valid_from: str | None = None
    valid_to: str | None = None
    source: str = "local"
    qubit_atom_mapping_hash: str | None = None
    readout_config_hash: str | None = None
    pulse_param_hash: str | None = None
    channel_map_hash: str | None = None
    readout_summary: ReadoutCalibrationSummary | None = None
    pulse_channel_summary: PulseChannelCalibrationSummary | None = None
    digital_gate_calibrations: tuple[DigitalGateCalibrationSummary, ...] = ()
    fallback_policy: str | None = None
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CalibrationSnapshot:
        """Build a calibration snapshot from a JSON-compatible dictionary."""
        return cls(
            calibration_profile_id=str(data["calibration_profile_id"]),
            calibration_snapshot_hash=str(data["calibration_snapshot_hash"]),
            target_id=str(data["target_id"]),
            valid_from=data.get("valid_from"),
            valid_to=data.get("valid_to"),
            source=str(data.get("source", "local")),
            qubit_atom_mapping_hash=data.get("qubit_atom_mapping_hash"),
            readout_config_hash=data.get("readout_config_hash"),
            pulse_param_hash=data.get("pulse_param_hash"),
            channel_map_hash=data.get("channel_map_hash"),
            readout_summary=None
            if data.get("readout_summary") is None
            else ReadoutCalibrationSummary.from_dict(data["readout_summary"]),
            pulse_channel_summary=None
            if data.get("pulse_channel_summary") is None
            else PulseChannelCalibrationSummary.from_dict(
                data["pulse_channel_summary"]
            ),
            digital_gate_calibrations=tuple(
                DigitalGateCalibrationSummary.from_dict(item)
                for item in data.get("digital_gate_calibrations", ())
            ),
            fallback_policy=data.get("fallback_policy"),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return a calibration snapshot, omitting absent structured facts."""
        data = super().to_dict()
        if self.readout_summary is None:
            data.pop("readout_summary", None)
        if self.pulse_channel_summary is None:
            data.pop("pulse_channel_summary", None)
        if not self.digital_gate_calibrations:
            data.pop("digital_gate_calibrations", None)
        if self.fallback_policy is None:
            data.pop("fallback_policy", None)
        return data

    @classmethod
    def from_json(cls, text: str) -> CalibrationSnapshot:
        """Build a calibration snapshot from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("CalibrationSnapshot JSON must contain an object.")
        return cls.from_dict(data)

    @classmethod
    def local_mock(
        cls,
        *,
        target_id: str,
        calibration_profile_id: str = "mock.calibration.local",
        metadata: dict[str, Any] | None = None,
    ) -> CalibrationSnapshot:
        """Return a deterministic local mock calibration snapshot."""
        payload = {
            "calibration_profile_id": calibration_profile_id,
            "target_id": target_id,
            "source": "local_mock",
            "metadata": {} if metadata is None else metadata,
        }
        snapshot_hash = IRMixinStableHash.hash_dict(payload)
        return cls(
            calibration_profile_id=calibration_profile_id,
            calibration_snapshot_hash=snapshot_hash,
            target_id=target_id,
            source="local_mock",
            metadata={} if metadata is None else metadata,
        )

    @classmethod
    def structured_local_mock(
        cls,
        *,
        target_id: str,
        calibration_profile_id: str = "mock.calibration.structured",
        target_snapshot_hash: str | None = None,
        valid_from: str | None = "2026-07-01T00:00:00Z",
        valid_to: str | None = "2026-07-03T00:00:00Z",
        metadata: dict[str, Any] | None = None,
    ) -> CalibrationSnapshot:
        """Return a deterministic structured local mock calibration snapshot."""
        readout_hash = IRMixinStableHash.hash_dict(
            {
                "kind": "readout_config",
                "target_id": target_id,
                "calibration_profile_id": calibration_profile_id,
            }
        )
        confusion_hash = IRMixinStableHash.hash_dict(
            {
                "kind": "readout_confusion_matrix",
                "target_id": target_id,
                "calibration_profile_id": calibration_profile_id,
            }
        )
        pulse_hash = IRMixinStableHash.hash_dict(
            {
                "kind": "pulse_params",
                "target_id": target_id,
                "calibration_profile_id": calibration_profile_id,
            }
        )
        channel_hash = IRMixinStableHash.hash_dict(
            {
                "kind": "channel_map",
                "target_id": target_id,
                "calibration_profile_id": calibration_profile_id,
            }
        )
        readout = ReadoutCalibrationSummary(
            basis=("ground_rydberg", "computational"),
            readout_config_hash=readout_hash,
            confusion_matrix_ref=(
                f"{calibration_profile_id}.readout_confusion_matrix"
            ),
            confusion_matrix_hash=confusion_hash,
            metadata={"summary_kind": "local_mock"},
        )
        pulse = PulseChannelCalibrationSummary(
            pulse_param_hash=pulse_hash,
            channel_map_hash=channel_hash,
            rabi_calibration_ref=f"{calibration_profile_id}.rabi",
            rabi_calibration_hash=IRMixinStableHash.hash_dict(
                {"kind": "rabi", "calibration_profile_id": calibration_profile_id}
            ),
            detuning_calibration_ref=f"{calibration_profile_id}.detuning",
            detuning_calibration_hash=IRMixinStableHash.hash_dict(
                {
                    "kind": "detuning",
                    "calibration_profile_id": calibration_profile_id,
                }
            ),
            phase_calibration_ref=f"{calibration_profile_id}.phase",
            phase_calibration_hash=IRMixinStableHash.hash_dict(
                {"kind": "phase", "calibration_profile_id": calibration_profile_id}
            ),
            valid_from=valid_from,
            valid_to=valid_to,
            metadata={"summary_kind": "local_mock"},
        )
        digital_gates = tuple(
            DigitalGateCalibrationSummary(
                gate=gate,
                status="supported",
                qubits=(),
                duration=1.0,
                duration_unit="gate_index",
                error_rate=0.0,
                calibration_ref=f"{calibration_profile_id}.digital.{gate}",
                calibration_hash=IRMixinStableHash.hash_dict(
                    {
                        "kind": "digital_gate",
                        "gate": gate,
                        "calibration_profile_id": calibration_profile_id,
                    }
                ),
                metadata={"summary_kind": "local_mock"},
            )
            for gate in ("h", "x", "rx", "rz", "cx")
        )
        effective_metadata = {} if metadata is None else dict(metadata)
        if target_snapshot_hash is not None:
            effective_metadata["target_snapshot_hash"] = target_snapshot_hash
        payload = _structured_calibration_hash_payload(
            calibration_profile_id=calibration_profile_id,
            target_id=target_id,
            valid_from=valid_from,
            valid_to=valid_to,
            readout=readout,
            pulse=pulse,
            digital_gates=digital_gates,
            fallback_policy="block_on_stale",
            metadata=effective_metadata,
        )
        snapshot_hash = IRMixinStableHash.hash_dict(payload)
        return cls(
            calibration_profile_id=calibration_profile_id,
            calibration_snapshot_hash=snapshot_hash,
            target_id=target_id,
            valid_from=valid_from,
            valid_to=valid_to,
            source="local_structured_mock",
            readout_config_hash=readout_hash,
            pulse_param_hash=pulse_hash,
            channel_map_hash=channel_hash,
            readout_summary=readout,
            pulse_channel_summary=pulse,
            digital_gate_calibrations=digital_gates,
            fallback_policy="block_on_stale",
            metadata=effective_metadata,
        )

    def verify_hash(self) -> bool:
        """Return whether this local calibration snapshot hash is consistent."""
        if self.source == "local_mock":
            expected = CalibrationSnapshot.local_mock(
                target_id=self.target_id,
                calibration_profile_id=self.calibration_profile_id,
                metadata=self.metadata,
            ).calibration_snapshot_hash
            return self.calibration_snapshot_hash == expected
        if self.source == "local_structured_mock":
            payload = _structured_calibration_hash_payload(
                calibration_profile_id=self.calibration_profile_id,
                target_id=self.target_id,
                valid_from=self.valid_from,
                valid_to=self.valid_to,
                readout=self.readout_summary,
                pulse=self.pulse_channel_summary,
                digital_gates=self.digital_gate_calibrations,
                fallback_policy=self.fallback_policy,
                metadata=self.metadata,
            )
            return self.calibration_snapshot_hash == IRMixinStableHash.hash_dict(
                payload
            )
        return True


class IRMixinStableHash:
    """Small helper for hashing ad hoc snapshot payloads."""

    @staticmethod
    def hash_dict(data: dict[str, Any]) -> str:
        """Return a stable SHA-256 hash for a JSON-compatible dictionary."""
        import hashlib

        from cascaqit.native_ir.base import stable_json

        return hashlib.sha256(stable_json(data).encode("utf-8")).hexdigest()


def _float_pair(value: Any) -> tuple[float, float]:
    """Convert a two-item JSON array into a float pair."""
    return (float(value[0]), float(value[1]))


def _int_pair(value: Any) -> tuple[int, int]:
    """Convert a two-item JSON array into an int pair."""
    return (int(value[0]), int(value[1]))


def _capability_status(value: Any) -> CapabilityStatus:
    """Normalize and validate a target capability support status."""
    status = str(value)
    if status not in (
        "supported",
        "unsupported",
        "ir_only",
        "experimental",
        "deprecated",
    ):
        raise ValueError(f"Unsupported capability status: {status}")
    return status  # type: ignore[return-value]


def _structured_calibration_hash_payload(
    *,
    calibration_profile_id: str,
    target_id: str,
    valid_from: str | None,
    valid_to: str | None,
    readout: ReadoutCalibrationSummary | None,
    pulse: PulseChannelCalibrationSummary | None,
    digital_gates: tuple[DigitalGateCalibrationSummary, ...],
    fallback_policy: str | None,
    metadata: dict[str, Any],
) -> dict[str, Any]:
    """Return the stable payload used for structured local calibration hashes."""
    return {
        "calibration_profile_id": calibration_profile_id,
        "target_id": target_id,
        "source": "local_structured_mock",
        "valid_from": valid_from,
        "valid_to": valid_to,
        "readout_summary": None if readout is None else readout.to_dict(),
        "pulse_channel_summary": None if pulse is None else pulse.to_dict(),
        "digital_gate_calibrations": [
            gate.to_dict() for gate in digital_gates
        ],
        "fallback_policy": fallback_policy,
        "metadata": metadata,
    }
