"""Target models and factories for CASCAQit MVP execution and validation."""

from __future__ import annotations

from cascaqit.targets.mock import MockNeutralAtomTarget
from cascaqit.targets.models import (
    AnalogOperationCapability,
    CalibrationSnapshot,
    ChannelCrosstalkCapability,
    ChannelTimingCapability,
    DigitalGateCalibrationSummary,
    DigitalGateCapability,
    ProgrammableRegion,
    PulseChannelCalibrationSummary,
    ReadoutCalibrationSummary,
    ReadoutCapability,
    TargetCapabilityProfile,
    TargetSnapshot,
    TargetSpec,
    TimingCapability,
)
from cascaqit.targets.projection import (
    TargetProjectionCapabilityIR,
    TargetProjectionConsumerConformanceIR,
    TargetProjectionConsumerMatrixIR,
    TargetProjectionFormat,
    TargetProjectionIR,
    build_target_projection_consumer_conformance,
    build_target_projection_consumer_matrix,
    project_target_capabilities,
)
from cascaqit.targets.registry import (
    CalibrationFreshnessIR,
    TargetCalibrationRegistry,
    TargetCalibrationSelectionIR,
)
from cascaqit.targets.service_adapter import (
    FixtureReplayTargetCalibrationServiceAdapter,
    TargetCalibrationServiceAdapterProtocol,
    TargetCalibrationServiceReadinessIR,
    build_target_calibration_service_readiness,
)

__all__ = [
    "AnalogOperationCapability",
    "CalibrationSnapshot",
    "CalibrationFreshnessIR",
    "ChannelCrosstalkCapability",
    "ChannelTimingCapability",
    "DigitalGateCalibrationSummary",
    "FixtureReplayTargetCalibrationServiceAdapter",
    "DigitalGateCapability",
    "MockNeutralAtomTarget",
    "ProgrammableRegion",
    "PulseChannelCalibrationSummary",
    "ReadoutCalibrationSummary",
    "ReadoutCapability",
    "TargetCapabilityProfile",
    "TargetCalibrationRegistry",
    "TargetCalibrationSelectionIR",
    "TargetCalibrationServiceAdapterProtocol",
    "TargetCalibrationServiceReadinessIR",
    "TargetProjectionCapabilityIR",
    "TargetProjectionConsumerConformanceIR",
    "TargetProjectionConsumerMatrixIR",
    "TargetProjectionFormat",
    "TargetProjectionIR",
    "TargetSnapshot",
    "TargetSpec",
    "TimingCapability",
    "build_target_calibration_service_readiness",
    "build_target_projection_consumer_conformance",
    "build_target_projection_consumer_matrix",
    "project_target_capabilities",
]
