"""Legacy report namespace retained without hardware package contracts.

Use :func:`cascaqit.visualize` for current standard experiment reports.
"""

__all__: list[str] = []
