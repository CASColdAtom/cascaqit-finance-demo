"""Public hardware-submission contracts."""

from __future__ import annotations

import hashlib
import json
import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from datetime import datetime
from types import MappingProxyType
from typing import Any, Literal, cast
from urllib.parse import parse_qsl, urlsplit

from cascaqit.native_ir import ReferenceCompiledProgramIR
from cascaqit.native_ir.base import IRMixin, stable_json
from cascaqit.parameters import ParameterBindIR
from cascaqit.results import ArtifactRefIR

__all__ = [
    "HardwareSubmissionBuilder",
    "HardwareSubmissionIR",
]

HARDWARE_SUBMISSION_SCHEMA_ID = "cascaqit.hardware_submission"
HARDWARE_SUBMISSION_SCHEMA_VERSION = "1.0"

ProgramKind = Literal["analog", "digital"]
ResultField = Literal[
    "counts",
    "samples",
    "probabilities",
    "diagnostics",
    "run_trace",
    "artifact_refs",
]

_RESULT_FIELD_ORDER: tuple[ResultField, ...] = (
    "counts",
    "samples",
    "probabilities",
    "diagnostics",
    "run_trace",
    "artifact_refs",
)
_DEFAULT_RESULT_FIELDS: tuple[ResultField, ...] = (
    "counts",
    "diagnostics",
    "run_trace",
)
_RESULT_FIELDS = frozenset(_RESULT_FIELD_ORDER)
_SUBMISSION_ARTIFACT_KINDS = frozenset({"target_snapshot", "other"})
_IDENTIFIER_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$")
_SHA256_PATTERN = re.compile(r"^[0-9a-f]{64}$")
_CREATED_AT_FORMAT = "%Y-%m-%dT%H:%M:%SZ"

_PRIVATE_FACT_KEYS = frozenset(
    {
        "api_key",
        "authorization",
        "calibration",
        "calibration_hash",
        "calibration_snapshot",
        "calibration_snapshot_hash",
        "channel_allocation",
        "compiled_program",
        "credential",
        "credentials",
        "endpoint",
        "execution_package",
        "hardware_payload",
        "password",
        "payload",
        "physical_atom_mapping",
        "physical_mapping",
        "physical_qubit_mapping",
        "private_endpoint",
        "private_key",
        "production_schedule",
        "readout_calibration_hash",
        "secret",
        "token",
    }
)

_SUBMISSION_FIELDS = frozenset(
    {
        "submission_id",
        "source_program_hash",
        "reference_compiled_program_hash",
        "requested_target_id",
        "requested_target_version",
        "requested_target_snapshot_hash",
        "program_kind",
        "parameter_bind",
        "shots",
        "measurement_basis",
        "logical_order",
        "bit_order",
        "requested_result_fields",
        "idempotency_key",
        "trace_id",
        "artifact_refs",
        "created_at",
        "checksum",
        "schema_id",
        "schema_version",
        "live_opt_in",
    }
)
_PARAMETER_BIND_FIELDS = frozenset(
    {
        "parameter_bind_id",
        "parameter_schema_hash",
        "values",
        "parameter_bind_hash",
        "compile_required",
        "metadata",
        "schema_version",
    }
)
_ARTIFACT_REF_FIELDS = frozenset(
    {
        "artifact_id",
        "artifact_kind",
        "storage_uri",
        "checksum",
        "size_bytes",
        "content_type",
        "retention_policy",
        "created_at",
        "expires_at",
        "schema_version",
        "metadata",
    }
)


@dataclass(frozen=True)
class HardwareSubmissionIR(IRMixin):
    """Tamper-evident public request for a private hardware compiler service."""

    submission_id: str
    source_program_hash: str
    reference_compiled_program_hash: str | None
    requested_target_id: str
    requested_target_version: str
    requested_target_snapshot_hash: str
    program_kind: ProgramKind
    parameter_bind: ParameterBindIR
    shots: int
    measurement_basis: str
    logical_order: tuple[str, ...]
    bit_order: Mapping[str, str]
    requested_result_fields: tuple[ResultField, ...]
    idempotency_key: str
    trace_id: str
    artifact_refs: tuple[ArtifactRefIR, ...]
    created_at: str
    checksum: str = ""
    schema_id: str = HARDWARE_SUBMISSION_SCHEMA_ID
    schema_version: str = HARDWARE_SUBMISSION_SCHEMA_VERSION
    live_opt_in: Literal[False] = False

    def __post_init__(self) -> None:
        """Normalize public facts, enforce the boundary, and verify checksum."""
        _require_identifier(self.submission_id, "submission_id")
        _require_hash(self.source_program_hash, "source_program_hash")
        if self.reference_compiled_program_hash is not None:
            _require_hash(
                self.reference_compiled_program_hash,
                "reference_compiled_program_hash",
            )
        _require_identifier(self.requested_target_id, "requested_target_id")
        _require_non_empty(
            self.requested_target_version,
            "requested_target_version",
        )
        _require_hash(
            self.requested_target_snapshot_hash,
            "requested_target_snapshot_hash",
        )
        if self.program_kind not in ("analog", "digital"):
            raise ValueError("program_kind must be 'analog' or 'digital'.")
        _validate_parameter_bind(self.parameter_bind)
        if isinstance(self.shots, bool) or not isinstance(self.shots, int):
            raise TypeError("shots must be an integer.")
        if self.shots <= 0:
            raise ValueError("shots must be positive.")
        _require_non_empty(self.measurement_basis, "measurement_basis")

        logical_order = _normalize_logical_order(self.logical_order)
        bit_order = _normalize_bit_order(self.bit_order, self.program_kind)
        result_fields = _normalize_result_fields(self.requested_result_fields)
        artifact_refs = _normalize_artifact_refs(self.artifact_refs)
        object.__setattr__(self, "logical_order", logical_order)
        object.__setattr__(self, "bit_order", bit_order)
        object.__setattr__(self, "requested_result_fields", result_fields)
        object.__setattr__(self, "artifact_refs", artifact_refs)

        _require_identifier(self.idempotency_key, "idempotency_key")
        _require_identifier(self.trace_id, "trace_id")
        _require_created_at(self.created_at)
        if self.schema_id != HARDWARE_SUBMISSION_SCHEMA_ID:
            raise ValueError(
                "schema_id must be " f"{HARDWARE_SUBMISSION_SCHEMA_ID!r}."
            )
        if self.schema_version != HARDWARE_SUBMISSION_SCHEMA_VERSION:
            raise ValueError(
                "schema_version must be "
                f"{HARDWARE_SUBMISSION_SCHEMA_VERSION!r}."
            )
        if self.live_opt_in is not False:
            raise ValueError("live_opt_in must remain false for this contract.")

        # Check the normalized object so alternate input ordering cannot change the
        # checksum for an otherwise identical submission.
        _reject_private_facts(self.to_dict(), path="hardware_submission")
        if not self.checksum:
            object.__setattr__(self, "checksum", self.compute_checksum())
            return
        _require_hash(self.checksum, "checksum")
        if self.checksum != self.compute_checksum():
            raise ValueError("HardwareSubmissionIR checksum mismatch.")

    def compute_checksum(self) -> str:
        """Return SHA-256 over every serialized field except checksum itself."""
        payload = self.to_dict()
        payload["checksum"] = ""
        return hashlib.sha256(stable_json(payload).encode("utf-8")).hexdigest()

    def verify_checksum(self) -> bool:
        """Return whether the embedded checksum covers the current request."""
        return self.checksum == self.compute_checksum()

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> HardwareSubmissionIR:
        """Build a submission from its strict current wire representation."""
        if not isinstance(data, Mapping):
            raise TypeError("HardwareSubmissionIR dictionary must contain an object.")
        _reject_private_facts(data, path="hardware_submission")
        _validate_exact_fields(
            data,
            expected=_SUBMISSION_FIELDS,
            object_name="HardwareSubmissionIR",
        )
        parameter_bind_data = _require_mapping(
            data["parameter_bind"],
            "parameter_bind",
        )
        _validate_exact_fields(
            parameter_bind_data,
            expected=_PARAMETER_BIND_FIELDS,
            object_name="HardwareSubmissionIR.parameter_bind",
        )
        artifact_data = data["artifact_refs"]
        if not isinstance(artifact_data, (list, tuple)):
            raise TypeError("artifact_refs must be an array.")
        for index, item in enumerate(artifact_data):
            artifact_mapping = _require_mapping(
                item,
                f"artifact_refs[{index}]",
            )
            _validate_exact_fields(
                artifact_mapping,
                expected=_ARTIFACT_REF_FIELDS,
                object_name=f"HardwareSubmissionIR.artifact_refs[{index}]",
            )

        reference_hash = data["reference_compiled_program_hash"]
        return cls(
            submission_id=data["submission_id"],
            source_program_hash=data["source_program_hash"],
            reference_compiled_program_hash=(
                None if reference_hash is None else reference_hash
            ),
            requested_target_id=data["requested_target_id"],
            requested_target_version=data["requested_target_version"],
            requested_target_snapshot_hash=data["requested_target_snapshot_hash"],
            program_kind=data["program_kind"],
            parameter_bind=ParameterBindIR.from_dict(parameter_bind_data),
            shots=data["shots"],
            measurement_basis=data["measurement_basis"],
            logical_order=tuple(
                _require_array(data["logical_order"], "logical_order")
            ),
            bit_order=_require_mapping(data["bit_order"], "bit_order"),
            requested_result_fields=tuple(
                _require_array(
                    data["requested_result_fields"],
                    "requested_result_fields",
                )
            ),
            idempotency_key=data["idempotency_key"],
            trace_id=data["trace_id"],
            artifact_refs=tuple(
                ArtifactRefIR.from_dict(dict(_require_mapping(item, "artifact_ref")))
                for item in artifact_data
            ),
            created_at=data["created_at"],
            checksum=data["checksum"],
            schema_id=data["schema_id"],
            schema_version=data["schema_version"],
            live_opt_in=data["live_opt_in"],
        )

    @classmethod
    def from_json(cls, text: str) -> HardwareSubmissionIR:
        """Build a submission from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("HardwareSubmissionIR JSON must contain an object.")
        return cls.from_dict(data)


class HardwareSubmissionBuilder:
    """Build a public submission from a validated reference compile result."""

    @staticmethod
    def build(
        reference_compiled: ReferenceCompiledProgramIR,
        *,
        submission_id: str,
        shots: int,
        created_at: str,
        parameter_bind: ParameterBindIR | None = None,
        requested_result_fields: Sequence[ResultField] = _DEFAULT_RESULT_FIELDS,
        idempotency_key: str | None = None,
        trace_id: str | None = None,
        artifact_refs: Sequence[ArtifactRefIR] = (),
    ) -> HardwareSubmissionIR:
        """Build an offline request without calibration or execution payloads."""
        if not isinstance(reference_compiled, ReferenceCompiledProgramIR):
            raise TypeError(
                "reference_compiled must be ReferenceCompiledProgramIR."
            )
        if reference_compiled.unsupported_features:
            raise ValueError(
                "Reference compile contains unsupported features and cannot be "
                "submitted."
            )
        resolved_bind = _resolve_parameter_bind(
            reference_compiled,
            submission_id=submission_id,
            parameter_bind=parameter_bind,
        )
        measurement_basis, logical_order, bit_order = _measurement_contract(
            reference_compiled
        )
        normalized_results = _normalize_result_fields(requested_result_fields)
        normalized_artifacts = _normalize_artifact_refs(artifact_refs)
        reference_hash = reference_compiled.stable_hash()

        semantic_request = {
            "source_program_hash": reference_compiled.source_program_hash,
            "reference_compiled_program_hash": reference_hash,
            "requested_target_id": reference_compiled.target_id,
            "requested_target_version": reference_compiled.target_version,
            "requested_target_snapshot_hash": (
                reference_compiled.target_snapshot_hash
            ),
            "program_kind": reference_compiled.program_type,
            "parameter_bind_hash": resolved_bind.parameter_bind_hash,
            "shots": shots,
            "measurement_basis": measurement_basis,
            "logical_order": logical_order,
            "bit_order": bit_order,
            "requested_result_fields": normalized_results,
            "artifact_refs": normalized_artifacts,
            "live_opt_in": False,
        }
        derived_idempotency_key = (
            "idem."
            + hashlib.sha256(stable_json(semantic_request).encode("utf-8")).hexdigest()
        )
        resolved_idempotency_key = (
            derived_idempotency_key
            if idempotency_key is None
            else idempotency_key
        )

        return HardwareSubmissionIR(
            submission_id=submission_id,
            source_program_hash=reference_compiled.source_program_hash,
            reference_compiled_program_hash=reference_hash,
            requested_target_id=reference_compiled.target_id,
            requested_target_version=reference_compiled.target_version,
            requested_target_snapshot_hash=(
                reference_compiled.target_snapshot_hash
            ),
            program_kind=reference_compiled.program_type,
            parameter_bind=resolved_bind,
            shots=shots,
            measurement_basis=measurement_basis,
            logical_order=logical_order,
            bit_order=bit_order,
            requested_result_fields=normalized_results,
            idempotency_key=resolved_idempotency_key,
            trace_id=(f"trace.{submission_id}" if trace_id is None else trace_id),
            artifact_refs=normalized_artifacts,
            created_at=created_at,
        )


def _resolve_parameter_bind(
    compiled: ReferenceCompiledProgramIR,
    *,
    submission_id: str,
    parameter_bind: ParameterBindIR | None,
) -> ParameterBindIR:
    schema = compiled.parameter_schema
    if parameter_bind is None:
        if schema.parameters:
            raise ValueError(
                "parameter_bind is required for a parameterized reference compile."
            )
        return ParameterBindIR.create(
            parameter_bind_id=f"bind.{submission_id}",
            parameter_schema=schema,
            values={},
        )
    if not isinstance(parameter_bind, ParameterBindIR):
        raise TypeError("parameter_bind must be ParameterBindIR or None.")
    issues = parameter_bind.validate_against(schema)
    if issues:
        raise ValueError(
            "Invalid ParameterBindIR for reference compile: " + ", ".join(issues)
        )
    return parameter_bind


def _measurement_contract(
    compiled: ReferenceCompiledProgramIR,
) -> tuple[str, tuple[str, ...], Mapping[str, str]]:
    schedule = compiled.measurement_schedule
    raw_measurements = schedule.get("measurements")
    if (
        not isinstance(raw_measurements, (list, tuple))
        or len(raw_measurements) != 1
        or schedule.get("measurement_count") != 1
    ):
        raise ValueError(
            "Hardware submission requires exactly one terminal measurement."
        )
    measurement = _require_mapping(raw_measurements[0], "measurement")
    basis = measurement.get("basis", schedule.get("basis"))
    _require_non_empty(basis, "measurement basis")
    schedule_basis = schedule.get("basis")
    if schedule_basis is not None and schedule_basis != basis:
        raise ValueError("Measurement basis disagrees with its compiled schedule.")

    order_key = "atom_order" if compiled.program_type == "analog" else "qubit_order"
    raw_order = compiled.mapping_info.get(order_key)
    if not isinstance(raw_order, (list, tuple)) or not raw_order:
        raise ValueError("Reference compile must define a non-empty logical order.")
    logical_order = _normalize_logical_order(tuple(raw_order))
    targets = measurement.get("targets")
    if not isinstance(targets, (list, tuple)) or tuple(targets) != logical_order:
        raise ValueError(
            "Terminal measurement targets must match the compiled logical order."
        )

    expected_convention, expected_index = _expected_bit_order(compiled.program_type)
    convention = compiled.mapping_info.get("bit_order_version")
    bitstring_index = schedule.get(
        "bitstring_index",
        compiled.mapping_info.get("bitstring_index"),
    )
    if convention != expected_convention or bitstring_index != expected_index:
        raise ValueError(
            "Reference compile bit order does not match its program kind."
        )
    return basis, logical_order, MappingProxyType(
        {
            "bitstring_index": expected_index,
            "convention": expected_convention,
        }
    )


def _normalize_logical_order(value: object) -> tuple[str, ...]:
    if not isinstance(value, (list, tuple)):
        raise TypeError("logical_order must be an array.")
    logical_order = tuple(value)
    if not logical_order:
        raise ValueError("logical_order must not be empty.")
    if any(not isinstance(item, str) or not item.strip() for item in logical_order):
        raise ValueError("logical_order must contain non-empty strings.")
    if len(set(logical_order)) != len(logical_order):
        raise ValueError("logical_order values must be unique.")
    return logical_order


def _normalize_bit_order(
    value: object,
    program_kind: ProgramKind,
) -> Mapping[str, str]:
    mapping = _require_mapping(value, "bit_order")
    _validate_exact_fields(
        mapping,
        expected=frozenset({"convention", "bitstring_index"}),
        object_name="bit_order",
    )
    expected_convention, expected_index = _expected_bit_order(program_kind)
    if (
        mapping["convention"] != expected_convention
        or mapping["bitstring_index"] != expected_index
    ):
        raise ValueError("bit_order must match program_kind.")
    return MappingProxyType(
        {
            "bitstring_index": expected_index,
            "convention": expected_convention,
        }
    )


def _expected_bit_order(program_kind: ProgramKind) -> tuple[str, str]:
    if program_kind == "analog":
        return (
            "active_register_order",
            "left_to_right_matches_atom_order",
        )
    return (
        "digital_qubit_order",
        "left_to_right_matches_qubit_order",
    )


def _normalize_result_fields(value: object) -> tuple[ResultField, ...]:
    if not isinstance(value, (list, tuple)):
        raise TypeError("requested_result_fields must be an array.")
    raw_fields = tuple(value)
    if not raw_fields:
        raise ValueError("requested_result_fields must not be empty.")
    if any(
        not isinstance(item, str) or item not in _RESULT_FIELDS
        for item in raw_fields
    ):
        raise ValueError("requested_result_fields contains an unsupported field.")
    if len(set(raw_fields)) != len(raw_fields):
        raise ValueError("requested_result_fields must not contain duplicates.")
    if "counts" not in raw_fields:
        raise ValueError("requested_result_fields must include counts.")
    selected = set(raw_fields)
    return tuple(item for item in _RESULT_FIELD_ORDER if item in selected)


def _normalize_artifact_refs(value: object) -> tuple[ArtifactRefIR, ...]:
    if not isinstance(value, (list, tuple)):
        raise TypeError("artifact_refs must be an array.")
    refs = tuple(value)
    if any(not isinstance(item, ArtifactRefIR) for item in refs):
        raise TypeError("artifact_refs must contain ArtifactRefIR values.")
    typed_refs = cast(tuple[ArtifactRefIR, ...], refs)
    artifact_ids = tuple(item.artifact_id for item in typed_refs)
    if len(set(artifact_ids)) != len(artifact_ids):
        raise ValueError("artifact_refs artifact_id values must be unique.")
    for artifact in typed_refs:
        _require_identifier(artifact.artifact_id, "artifact_refs.artifact_id")
        if artifact.artifact_kind not in _SUBMISSION_ARTIFACT_KINDS:
            raise ValueError(
                "artifact_refs artifact_kind must be target_snapshot or other."
            )
        _require_non_empty(artifact.storage_uri, "artifact_refs.storage_uri")
        _reject_uri_credentials(artifact.storage_uri)
        _require_hash(artifact.checksum, "artifact_refs.checksum")
        if isinstance(artifact.size_bytes, bool) or not isinstance(
            artifact.size_bytes,
            int,
        ):
            raise TypeError("artifact_refs.size_bytes must be an integer.")
        if artifact.size_bytes < 0:
            raise ValueError("artifact_refs.size_bytes must not be negative.")
        _require_non_empty(artifact.content_type, "artifact_refs.content_type")
        _require_non_empty(
            artifact.retention_policy,
            "artifact_refs.retention_policy",
        )
    return tuple(sorted(typed_refs, key=lambda item: item.artifact_id))


def _validate_parameter_bind(value: object) -> None:
    if not isinstance(value, ParameterBindIR):
        raise TypeError("parameter_bind must be ParameterBindIR.")
    if not value.verify_hash():
        raise ValueError("parameter_bind_hash does not match parameter bind values.")


def _validate_exact_fields(
    data: Mapping[str, Any],
    *,
    expected: frozenset[str],
    object_name: str,
) -> None:
    missing = expected.difference(data)
    if missing:
        raise KeyError(
            f"{object_name} is missing required field(s): {sorted(missing)!r}."
        )
    unexpected = set(data).difference(expected)
    if unexpected:
        raise ValueError(
            f"{object_name} contains unexpected field(s): {sorted(unexpected)!r}."
        )


def _reject_private_facts(value: object, *, path: str) -> None:
    """Reject private compiler, transport, calibration, and secret fields."""
    if isinstance(value, Mapping):
        for key, nested in value.items():
            key_text = str(key)
            if _is_private_fact_key(key_text):
                raise ValueError(
                    "HardwareSubmissionIR cannot contain private fact "
                    f"{path}.{key_text}."
                )
            _reject_private_facts(nested, path=f"{path}.{key_text}")
    elif isinstance(value, (list, tuple)):
        for index, nested in enumerate(value):
            _reject_private_facts(nested, path=f"{path}[{index}]")


def _is_private_fact_key(value: str) -> bool:
    normalized = value.strip().lower().replace("-", "_")
    if normalized in _PRIVATE_FACT_KEYS:
        return True
    return (
        "calibration" in normalized
        or "payload" in normalized
        or "credential" in normalized
        or "api_key" in normalized
        or "authorization" in normalized
        or normalized.startswith("secret_")
        or normalized.endswith("_secret")
        or normalized.startswith("token_")
        or normalized.endswith("_token")
        or normalized.endswith("_signature")
        or normalized.startswith("physical_mapping")
        or normalized.startswith("private_endpoint")
        or normalized.startswith("production_schedule")
        or normalized.startswith("execution_package")
    )


def _reject_uri_credentials(storage_uri: str) -> None:
    parsed = urlsplit(storage_uri)
    if parsed.username is not None or parsed.password is not None:
        raise ValueError("artifact_refs.storage_uri must not contain credentials.")
    for key, _value in parse_qsl(parsed.query, keep_blank_values=True):
        if _is_private_fact_key(key):
            raise ValueError(
                "artifact_refs.storage_uri must not contain credential query fields."
            )


def _require_mapping(value: object, field_name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{field_name} must be an object.")
    return value


def _require_array(value: object, field_name: str) -> list[Any] | tuple[Any, ...]:
    if not isinstance(value, (list, tuple)):
        raise TypeError(f"{field_name} must be an array.")
    return value


def _require_non_empty(value: object, field_name: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field_name} must be a non-empty string.")


def _require_identifier(value: object, field_name: str) -> None:
    if not isinstance(value, str) or _IDENTIFIER_PATTERN.fullmatch(value) is None:
        raise ValueError(
            f"{field_name} must be a 1-128 character public identifier."
        )


def _require_hash(value: object, field_name: str) -> None:
    if not isinstance(value, str) or _SHA256_PATTERN.fullmatch(value) is None:
        raise ValueError(f"{field_name} must be a lowercase SHA-256 hex digest.")


def _require_created_at(value: object) -> None:
    if not isinstance(value, str):
        raise TypeError("created_at must be an RFC 3339 UTC string.")
    try:
        datetime.strptime(value, _CREATED_AT_FORMAT)
    except ValueError as error:
        raise ValueError(
            "created_at must use canonical RFC 3339 UTC seconds "
            "(YYYY-MM-DDTHH:MM:SSZ)."
        ) from error
