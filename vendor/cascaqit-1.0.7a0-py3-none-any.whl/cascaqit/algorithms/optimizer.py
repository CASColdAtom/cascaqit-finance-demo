"""Shared SciPy optimization loop for executable variational algorithms."""

from __future__ import annotations

import math
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from typing import Literal, cast

import numpy as np
from numpy.typing import NDArray
from scipy.optimize import OptimizeResult, minimize  # type: ignore[import-untyped]

from cascaqit.algorithms.execution import ParameterValues, normalize_parameter_values
from cascaqit.algorithms.gradient import (
    ObjectiveGradientIR,
    build_parameter_shift_plan,
)
from cascaqit.algorithms.models import (
    AnsatzSpecIR,
    ObjectiveEvaluationIR,
    OptimizationStartIR,
    OptimizerConfig,
    OptimizerTerminationIR,
    PauliHamiltonian,
    VariationalResult,
)
from cascaqit.algorithms.noisy_execution import validate_noisy_variational_request
from cascaqit.algorithms.sampling import execute_final_sampling
from cascaqit.digital import Circuit
from cascaqit.problems import OptimizationProblem
from cascaqit.simulators import LocalBackend, NoiseModel, SimulationOptions

AlgorithmKind = Literal["qaoa", "vqe", "qaa"]
ObjectiveEvaluator = Callable[..., ObjectiveEvaluationIR]
GradientEvaluator = Callable[..., ObjectiveGradientIR]
CircuitBuilder = Callable[[], Circuit]
ScalarObjective = Callable[[tuple[float, ...], int], float]
ScalarGradient = Callable[[tuple[float, ...], int], tuple[float, ...]]

__all__ = [
    "ScalarOptimizationOutcome",
    "OptimizationStartPlan",
    "aggregate_optimizer_termination",
    "build_optimization_start_plans",
    "run_scalar_optimization",
    "run_variational_optimization",
    "seeded_initial_point",
]


@dataclass(frozen=True)
class ScalarOptimizationOutcome:
    """Normalized SciPy result shared by algorithm and Problem workflows."""

    initial_parameters: tuple[float, ...]
    final_parameters: tuple[float, ...]
    final_objective: float
    objective_values: tuple[float, ...]
    best_evaluation_index: int
    termination: OptimizerTerminationIR
    gradient_values: tuple[tuple[float, ...], ...] = ()


@dataclass(frozen=True)
class OptimizationStartPlan:
    """Resolved deterministic initial point for one optimizer start."""

    start_index: int
    seed: int
    initialization: Literal["random", "explicit", "layerwise", "schema_default"]
    parameters: tuple[float, ...]


class _OptimizationBudgetExhausted(Exception):
    """Internal control signal raised before a callback can exceed its budget."""

    def __init__(
        self,
        reason: Literal[
            "max_evaluations",
            "max_gradient_evaluations",
            "max_backend_executions",
        ],
    ) -> None:
        super().__init__(reason)
        self.reason = reason


def build_optimization_start_plans(
    *,
    algorithm_kind: AlgorithmKind,
    layers: int,
    parameter_names: tuple[str, ...],
    optimizer: OptimizerConfig,
    initial_parameters: ParameterValues | None,
    seed: int,
    default_initial_parameters: tuple[float, ...] | None = None,
) -> tuple[OptimizationStartPlan, ...]:
    """Resolve every start before the first Backend evaluation.

    Start zero preserves a caller-supplied, layer-wise, or schema-default point.
    Remaining starts are independent seeded points over the declared domain. This
    keeps retries reproducible and makes the total Backend budget explicit as
    ``starts * per-start budget``.
    """
    if algorithm_kind not in {"qaoa", "vqe", "qaa"}:
        raise ValueError(f"Unsupported algorithm kind: {algorithm_kind!r}.")
    if not isinstance(layers, int) or isinstance(layers, bool) or layers <= 0:
        raise ValueError("layers must be a positive integer.")
    if not isinstance(optimizer, OptimizerConfig):
        raise TypeError("optimizer must be OptimizerConfig.")
    if not isinstance(seed, int) or isinstance(seed, bool) or seed < 0:
        raise ValueError("seed must be a non-negative integer.")
    if not parameter_names or len(parameter_names) != len(set(parameter_names)):
        raise ValueError("parameter_names must be non-empty and unique.")
    _validate_bounds(optimizer, parameter_names)

    first: tuple[float, ...] | None = None
    first_kind: Literal["random", "explicit", "layerwise", "schema_default"]
    if optimizer.initialization == "layerwise":
        if initial_parameters is None:
            raise ValueError(
                "layerwise initialization requires initial parameters."
            )
        if not isinstance(initial_parameters, Mapping):
            raise TypeError("layerwise initial_parameters must be a parameter mapping.")
        if algorithm_kind == "qaa":
            raise ValueError("layerwise initialization is not available for QAA.")
        if algorithm_kind == "qaoa":
            first = _qaoa_layerwise_initial_point(
                layers=layers,
                parameter_names=parameter_names,
                previous_parameters=initial_parameters,
            )
        else:
            # VQE 的层结构由 Ansatz 契约拥有。优化器只校验调用方已经迁移好的
            # 当前层完整参数，不再从 RY/RZ 名称反推 qubit、层数或旋转轴。
            normalized = normalize_parameter_values(initial_parameters, parameter_names)
            first = tuple(normalized[name] for name in parameter_names)
        first_kind = "layerwise"
    elif initial_parameters is not None:
        normalized = normalize_parameter_values(initial_parameters, parameter_names)
        first = tuple(normalized[name] for name in parameter_names)
        first_kind = "explicit"
    elif default_initial_parameters is not None:
        first = tuple(float(value) for value in default_initial_parameters)
        if len(first) != len(parameter_names):
            raise ValueError("default_initial_parameters must match parameter_names.")
        first_kind = "schema_default"
    else:
        first_kind = "random"

    plans: list[OptimizationStartPlan] = []
    for start_index in range(optimizer.starts):
        start_seed = _optimization_start_seed(seed, start_index)
        if start_index == 0 and first is not None:
            point = first
            initialization = first_kind
        else:
            point = seeded_initial_point(
                algorithm_kind=algorithm_kind,
                layers=layers,
                parameter_count=len(parameter_names),
                seed=start_seed,
                bounds=optimizer.bounds,
            )
            initialization = "random"
        _validate_initial_point(
            point,
            parameter_names=parameter_names,
            bounds=optimizer.bounds,
        )
        plans.append(
            OptimizationStartPlan(
                start_index=start_index,
                seed=start_seed,
                initialization=initialization,
                parameters=point,
            )
        )
    return tuple(plans)


def aggregate_optimizer_termination(
    starts: tuple[OptimizationStartIR, ...],
    *,
    selected_start_index: int,
) -> OptimizerTerminationIR:
    """Build one total-budget termination summary from per-start evidence."""
    if not starts:
        raise ValueError("starts must not be empty.")
    if (
        not isinstance(selected_start_index, int)
        or isinstance(selected_start_index, bool)
        or not 0 <= selected_start_index < len(starts)
    ):
        raise ValueError("selected_start_index is outside starts.")
    selected = starts[selected_start_index].termination
    if len(starts) == 1:
        return selected
    nit_values = tuple(item.termination.nit for item in starts)
    return OptimizerTerminationIR(
        method=selected.method,
        success=selected.success,
        status=selected.status,
        message=(
            f"Completed {len(starts)} optimizer starts; selected start "
            f"{selected_start_index}. {selected.message}"
        ),
        nfev=sum(item.evaluation_count for item in starts),
        njev=sum(item.gradient_count for item in starts),
        backend_execution_count=sum(
            item.backend_execution_count or 0 for item in starts
        ),
        nit=(
            None
            if any(value is None for value in nit_values)
            else sum(value for value in nit_values if value is not None)
        ),
        reason=selected.reason,
    )


def run_scalar_optimization(
    *,
    parameter_names: tuple[str, ...],
    objective: ScalarObjective,
    optimizer: OptimizerConfig,
    initial_parameters: tuple[float, ...],
    gradient: ScalarGradient | None = None,
    gradient_backend_execution_count: int = 0,
) -> ScalarOptimizationOutcome:
    """Run one SciPy minimization while retaining every objective evaluation.

    Callers own the domain-specific evaluation evidence. This function owns only
    parameter-shape validation, SciPy option translation, termination semantics,
    and the stable rule used to select the lowest observed objective. It always
    executes exactly one supplied initial point; higher-level owners expand
    ``OptimizerConfig.starts`` before calling it.
    """
    if not parameter_names or any(
        not isinstance(name, str) or not name.strip() for name in parameter_names
    ):
        raise ValueError("parameter_names must contain non-empty strings.")
    if len(parameter_names) != len(set(parameter_names)):
        raise ValueError("parameter_names must be unique.")
    if not callable(objective):
        raise TypeError("objective must be callable.")
    if not isinstance(optimizer, OptimizerConfig):
        raise TypeError("optimizer must be OptimizerConfig.")
    if optimizer.gradient is None:
        if gradient is not None:
            raise ValueError("gradient callback requires optimizer GradientConfig.")
    elif not callable(gradient):
        raise ValueError("gradient optimizer requires a gradient callback.")
    if (
        not isinstance(gradient_backend_execution_count, int)
        or isinstance(gradient_backend_execution_count, bool)
        or gradient_backend_execution_count < 0
    ):
        raise ValueError(
            "gradient_backend_execution_count must be a non-negative integer."
        )
    if optimizer.gradient is not None and gradient_backend_execution_count <= 0:
        raise ValueError(
            "gradient optimizer requires a positive Backend cost per gradient."
        )
    if len(initial_parameters) != len(parameter_names):
        raise ValueError("initial parameters must match parameter_names.")
    point = tuple(float(value) for value in initial_parameters)
    if any(not math.isfinite(value) for value in point):
        raise ValueError("initial parameters must be finite.")

    _validate_bounds(optimizer, parameter_names)
    _validate_cobyla_budget(optimizer, parameter_count=len(parameter_names))
    if (
        optimizer.gradient is not None
        and optimizer.max_backend_executions is not None
        and optimizer.max_backend_executions
        < 1 + gradient_backend_execution_count
    ):
        raise ValueError(
            "max_backend_executions must cover the initial objective and one "
            "complete gradient."
        )
    for index, (value, bound) in enumerate(zip(point, optimizer.bounds)):
        lower, upper = bound
        if not lower <= value <= upper:
            raise ValueError(
                f"initial parameter '{parameter_names[index]}' is outside optimizer "
                "bounds."
            )

    objective_values: list[float] = []
    objective_points: list[tuple[float, ...]] = []
    gradient_values: list[tuple[float, ...]] = []
    callback_error: Exception | None = None

    def backend_execution_count() -> int:
        return len(objective_values) + (
            len(gradient_values) * gradient_backend_execution_count
        )

    def scipy_objective(values: NDArray[np.float64]) -> float:
        nonlocal callback_error
        if callback_error is not None:
            return float(np.finfo(np.float64).max / 4.0)
        try:
            if (
                optimizer.method == "L-BFGS-B"
                and optimizer.max_evaluations is not None
                and len(objective_values) >= optimizer.max_evaluations
            ):
                raise _OptimizationBudgetExhausted("max_evaluations")
            if (
                optimizer.max_backend_executions is not None
                and backend_execution_count() + 1
                > optimizer.max_backend_executions
            ):
                raise _OptimizationBudgetExhausted("max_backend_executions")
            raw = tuple(float(value) for value in values)
            if any(not math.isfinite(value) for value in raw):
                raise ValueError("optimizer parameters must remain finite.")
            # Legacy COBYLA treats bounds as inequality constraints and may probe
            # outside them while building its initial simplex. Projecting the point
            # keeps strict Parameter domains executable while preserving one real
            # domain evaluation for every SciPy function evaluation.
            normalized = _project_to_bounds(raw, optimizer.bounds)
            value = float(objective(normalized, len(objective_values)))
            if not math.isfinite(value):
                raise ValueError("objective must return a finite value.")
            objective_values.append(value)
            objective_points.append(normalized)
            return value
        except Exception as error:
            # SciPy 1.13's Fortran COBYLA callback cannot safely propagate Python
            # exceptions through F2PY. Defer the original exception until minimize
            # returns; subsequent callbacks receive a finite sentinel and perform no
            # additional domain work.
            callback_error = error
            return float(np.finfo(np.float64).max / 4.0)

    def scipy_gradient(values: NDArray[np.float64]) -> NDArray[np.float64]:
        nonlocal callback_error
        if callback_error is not None:
            return np.zeros(len(parameter_names), dtype=np.float64)
        try:
            assert optimizer.gradient is not None
            assert gradient is not None
            if (
                optimizer.gradient.max_evaluations is not None
                and len(gradient_values) >= optimizer.gradient.max_evaluations
            ):
                raise _OptimizationBudgetExhausted("max_gradient_evaluations")
            if (
                optimizer.max_backend_executions is not None
                and backend_execution_count() + gradient_backend_execution_count
                > optimizer.max_backend_executions
            ):
                raise _OptimizationBudgetExhausted("max_backend_executions")
            raw = tuple(float(value) for value in values)
            if any(not math.isfinite(value) for value in raw):
                raise ValueError("optimizer parameters must remain finite.")
            normalized = _project_to_bounds(raw, optimizer.bounds)
            computed = tuple(
                float(value) for value in gradient(normalized, len(gradient_values))
            )
            if len(computed) != len(parameter_names):
                raise ValueError("gradient must match the optimizer parameter count.")
            if any(not math.isfinite(value) for value in computed):
                raise ValueError("gradient must contain only finite values.")
            gradient_values.append(computed)
            return np.asarray(computed, dtype=np.float64)
        except Exception as error:
            callback_error = error
            return np.zeros(len(parameter_names), dtype=np.float64)

    scipy_options, cobyla_limit_reason = _scipy_options(optimizer)
    scipy_result = minimize(
        scipy_objective,
        np.asarray(point, dtype=np.float64),
        method=optimizer.method,
        jac=scipy_gradient if optimizer.gradient is not None else None,
        bounds=optimizer.bounds or None,
        tol=optimizer.tolerance,
        options=scipy_options,
    )
    if callback_error is not None and not isinstance(
        callback_error,
        _OptimizationBudgetExhausted,
    ):
        raise callback_error
    nfev = len(objective_values)
    njev = len(gradient_values)
    if callback_error is None and int(scipy_result.nfev) != nfev:
        raise RuntimeError("SciPy nfev does not match the recorded objective history.")
    scipy_njev = int(scipy_result.get("njev", 0))
    if callback_error is None and scipy_njev != njev:
        raise RuntimeError("SciPy njev does not match the recorded gradient history.")
    if not objective_values:
        raise RuntimeError("SciPy completed without evaluating the objective.")
    best_index = min(
        range(len(objective_values)),
        key=lambda index: (objective_values[index], index),
    )
    backend_count = backend_execution_count()
    if isinstance(callback_error, _OptimizationBudgetExhausted):
        final_parameters = objective_points[-1]
        final_objective = objective_values[-1]
        termination = OptimizerTerminationIR(
            method=optimizer.method,
            success=False,
            status=1,
            message=f"CASCAQit stopped at {callback_error.reason}.",
            nfev=nfev,
            njev=njev,
            backend_execution_count=backend_count,
            nit=None,
            reason=callback_error.reason,
        )
    else:
        final_parameters = _project_to_bounds(
            tuple(float(value) for value in scipy_result.x),
            optimizer.bounds,
        )
        final_objective = float(scipy_result.fun)
        termination = _termination(
            scipy_result,
            config=optimizer,
            nfev=nfev,
            njev=njev,
            backend_execution_count=backend_count,
            cobyla_limit_reason=cobyla_limit_reason,
        )
    return ScalarOptimizationOutcome(
        initial_parameters=point,
        final_parameters=final_parameters,
        final_objective=final_objective,
        objective_values=tuple(objective_values),
        best_evaluation_index=best_index,
        termination=termination,
        gradient_values=tuple(gradient_values),
    )


def _project_to_bounds(
    values: tuple[float, ...],
    bounds: tuple[tuple[float, float], ...],
) -> tuple[float, ...]:
    """Project one SciPy point onto the declared closed parameter domain."""
    if not bounds:
        return values
    return tuple(
        min(max(value, lower), upper) for value, (lower, upper) in zip(values, bounds)
    )


def run_variational_optimization(
    *,
    algorithm_kind: AlgorithmKind,
    algorithm_id: str,
    layers: int,
    parameter_names: tuple[str, ...],
    hamiltonian: PauliHamiltonian,
    ansatz: AnsatzSpecIR,
    evaluator: ObjectiveEvaluator,
    circuit_builder: CircuitBuilder,
    gradient_evaluator: GradientEvaluator | None = None,
    problem: OptimizationProblem | None = None,
    mis_penalty: float = 2.0,
    mwis_penalty: float | None = None,
    backend: LocalBackend | None = None,
    optimizer: OptimizerConfig | None = None,
    initial_parameters: ParameterValues | None = None,
    algorithm_run_id: str | None = None,
    final_shots: int = 2048,
    noise: NoiseModel | None = None,
    options: SimulationOptions | None = None,
) -> VariationalResult:
    """Optimize real objectives, then sample the minimum-observed parameters.

    The returned history is the source of truth for the observed minimum. SciPy's
    final point is retained as termination metadata because some methods return a
    point that is not the minimum point observed during the complete callback history.
    Final sampling is a separate Job and never changes SciPy nfev or objective history.
    """
    if algorithm_kind not in {"qaoa", "vqe"}:
        raise ValueError(f"Unsupported algorithm kind: {algorithm_kind!r}.")
    variational_kind = cast(Literal["qaoa", "vqe"], algorithm_kind)
    if not isinstance(algorithm_id, str) or not algorithm_id.strip():
        raise ValueError("algorithm_id must be a non-empty string.")
    if not isinstance(layers, int) or isinstance(layers, bool) or layers <= 0:
        raise ValueError("layers must be a positive integer.")
    if not isinstance(hamiltonian, PauliHamiltonian):
        raise TypeError("hamiltonian must be PauliHamiltonian.")
    if not isinstance(ansatz, AnsatzSpecIR):
        raise TypeError("ansatz must be AnsatzSpecIR.")
    if ansatz.parameter_names != parameter_names:
        raise ValueError("parameter_names must match the ansatz declaration.")
    if ansatz.logical_order != hamiltonian.logical_order:
        raise ValueError("ansatz and Hamiltonian logical order must match.")
    if not callable(evaluator):
        raise TypeError("evaluator must be callable.")
    if not callable(circuit_builder):
        raise TypeError("circuit_builder must be callable.")
    if (
        not isinstance(final_shots, int)
        or isinstance(final_shots, bool)
        or final_shots <= 0
    ):
        raise ValueError("final_shots must be a positive integer.")

    config = OptimizerConfig() if optimizer is None else optimizer
    if not isinstance(config, OptimizerConfig):
        raise TypeError("optimizer must be OptimizerConfig or None.")
    if backend is not None and not isinstance(backend, LocalBackend):
        raise TypeError("backend must be LocalBackend or None.")
    if noise is not None and not isinstance(noise, NoiseModel):
        raise TypeError("noise must be NoiseModel or None.")
    if options is not None and not isinstance(options, SimulationOptions):
        raise TypeError("options must be SimulationOptions or None.")
    run_id = algorithm_id if algorithm_run_id is None else algorithm_run_id
    if not isinstance(run_id, str) or not run_id.strip() or run_id != run_id.strip():
        raise ValueError("algorithm_run_id must be a non-empty trimmed string.")

    resolved_seed = _resolve_seed(config, backend)
    plans = build_optimization_start_plans(
        algorithm_kind=variational_kind,
        layers=layers,
        parameter_names=parameter_names,
        optimizer=config,
        initial_parameters=initial_parameters,
        seed=resolved_seed,
    )
    execution_backend = backend or LocalBackend(seed=resolved_seed)
    optimization_circuit = circuit_builder()
    if not isinstance(optimization_circuit, Circuit):
        raise TypeError("circuit_builder must return Circuit.")
    if noise is not None:
        # 优化器级预检保证 readout-only、trajectory 和资源不支持等配置在
        # SciPy 发起第一个 objective callback 前确定性失败。
        validate_noisy_variational_request(
            optimization_circuit,
            noise=noise,
            options=options,
            backend=execution_backend,
            seed=resolved_seed,
        )
    gradient_plan = None
    if config.gradient is not None:
        if not callable(gradient_evaluator):
            raise ValueError("gradient optimizer requires a gradient evaluator.")
        # Build the complete plan before the first objective Job. This also fixes
        # the per-gradient Backend cost used by every start's atomic budget check.
        gradient_plan = build_parameter_shift_plan(
            optimization_circuit,
            hamiltonian,
            config=config.gradient,
        )
    history: list[ObjectiveEvaluationIR] = []
    gradient_history: list[ObjectiveGradientIR] = []
    start_results: list[OptimizationStartIR] = []
    for plan in plans:
        evaluation_start_index = len(history)
        gradient_start_index = len(gradient_history)

        def objective(
            values: tuple[float, ...],
            evaluation_index: int,
            *,
            _offset: int = evaluation_start_index,
            _seed: int = plan.seed,
        ) -> float:
            # Each callback owns a unique global index, Backend Job and ResultIR.
            evaluation = evaluator(
                values,
                backend=execution_backend,
                evaluation_index=_offset + evaluation_index,
                algorithm_run_id=run_id,
                seed=_seed,
                noise=noise,
                options=options,
            )
            history.append(evaluation)
            return evaluation.energy

        def gradient(
            values: tuple[float, ...],
            gradient_index: int,
            *,
            _offset: int = gradient_start_index,
            _seed: int = plan.seed,
        ) -> tuple[float, ...]:
            assert gradient_evaluator is not None
            assert config.gradient is not None
            assert gradient_plan is not None
            computed = gradient_evaluator(
                values,
                backend=execution_backend,
                gradient_index=_offset + gradient_index,
                algorithm_run_id=run_id,
                seed=_seed,
                config=config.gradient,
                noise=noise,
                options=options,
            )
            if computed.plan_hash != gradient_plan.plan_hash:
                raise RuntimeError(
                    "gradient callback plan changed during optimization."
                )
            if (
                computed.backend_execution_count
                != gradient_plan.expected_backend_execution_count
            ):
                raise RuntimeError(
                    "gradient Backend cost does not match the planned cost."
                )
            gradient_history.append(computed)
            return tuple(computed.gradient[name] for name in parameter_names)

        outcome = run_scalar_optimization(
            parameter_names=parameter_names,
            objective=objective,
            optimizer=config,
            initial_parameters=plan.parameters,
            gradient=gradient if config.gradient is not None else None,
            gradient_backend_execution_count=(
                0
                if gradient_plan is None
                else gradient_plan.expected_backend_execution_count
            ),
        )
        if outcome.termination.nfev != len(history) - evaluation_start_index:
            raise RuntimeError(
                "SciPy nfev does not match its Backend evaluation history."
            )
        global_best_index = evaluation_start_index + outcome.best_evaluation_index
        if outcome.termination.njev != len(gradient_history) - gradient_start_index:
            raise RuntimeError(
                "SciPy njev does not match its Backend gradient history."
            )
        start_results.append(
            OptimizationStartIR(
                start_index=plan.start_index,
                seed=plan.seed,
                initialization=plan.initialization,
                evaluation_start_index=evaluation_start_index,
                evaluation_count=outcome.termination.nfev,
                best_evaluation_index=global_best_index,
                initial_parameters=dict(
                    zip(parameter_names, outcome.initial_parameters)
                ),
                final_parameters=dict(zip(parameter_names, outcome.final_parameters)),
                final_objective=outcome.final_objective,
                best_objective=history[global_best_index].energy,
                termination=outcome.termination,
                gradient_start_index=gradient_start_index,
                gradient_count=outcome.termination.njev,
                backend_execution_count=outcome.termination.backend_execution_count,
            )
        )

    best_evaluation_index = min(
        range(len(history)),
        key=lambda index: (history[index].energy, index),
    )
    selected_start_index = next(
        item.start_index
        for item in start_results
        if item.best_evaluation_index == best_evaluation_index
    )
    starts = tuple(start_results)
    termination = aggregate_optimizer_termination(
        starts,
        selected_start_index=selected_start_index,
    )
    selected_start = starts[selected_start_index]
    sampling = execute_final_sampling(
        circuit=optimization_circuit,
        best_evaluation=history[best_evaluation_index],
        backend=execution_backend,
        algorithm_run_id=run_id,
        shots=final_shots,
        seed=selected_start.seed,
        problem=problem,
        mis_penalty=mis_penalty,
        mwis_penalty=mwis_penalty,
        noise=noise,
        options=options,
    )
    return VariationalResult(
        algorithm_run_id=run_id,
        algorithm_kind=variational_kind,
        hamiltonian=hamiltonian,
        ansatz=ansatz,
        optimizer=config,
        evaluations=tuple(history),
        best_evaluation_index=best_evaluation_index,
        termination=termination,
        gradients=tuple(gradient_history),
        optimization_starts=starts,
        selected_start_index=selected_start_index,
        final_result=sampling.result,
        most_probable_candidate=sampling.most_probable_candidate,
        best_observed_candidate=sampling.best_observed_candidate,
        baseline=sampling.baseline,
        problem_id=hamiltonian.source_problem_id,
        problem_hash=hamiltonian.source_problem_hash,
        metadata={
            "algorithm_id": algorithm_id,
            "resolved_seed": resolved_seed,
            "initial_parameters": tuple(selected_start.initial_parameters.values()),
            "scipy_final_parameters": tuple(selected_start.final_parameters.values()),
            "scipy_final_energy": selected_start.final_objective,
            "start_count": len(starts),
            "selected_start_index": selected_start_index,
            "backend_result_ids": tuple(item.result_id for item in history),
            "objective_estimator": history[0].execution_evidence.estimator_kind.value,
            "objective_simulation_method": history[
                0
            ].execution_evidence.simulation_plan.method_selected,
            "objective_noise_model_hash": (
                None if noise is None else noise.stable_hash()
            ),
            **sampling.metadata,
        },
    )


def _validate_bounds(
    config: OptimizerConfig,
    parameter_names: tuple[str, ...],
) -> None:
    if config.bounds and len(config.bounds) != len(parameter_names):
        raise ValueError("optimizer bounds must match ansatz parameter count.")


def _validate_cobyla_budget(
    config: OptimizerConfig,
    *,
    parameter_count: int,
) -> None:
    """Reject a budget too small to initialize COBYLA consistently."""
    if config.method != "COBYLA":
        return
    limit, _ = _cobyla_limit(config)
    minimum = parameter_count + 2
    if limit < minimum:
        raise ValueError(
            "COBYLA objective evaluation budget must be at least "
            f"parameter_count + 2 ({minimum}); received {limit}."
        )


def _resolve_seed(config: OptimizerConfig, backend: LocalBackend | None) -> int:
    if config.seed is not None:
        return config.seed
    if backend is not None and backend.seed is not None:
        return backend.seed
    return 0


def _validate_initial_point(
    point: tuple[float, ...],
    *,
    parameter_names: tuple[str, ...],
    bounds: tuple[tuple[float, float], ...],
) -> None:
    if len(point) != len(parameter_names):
        raise ValueError("initial parameters must match parameter_names.")
    if any(not math.isfinite(value) for value in point):
        raise ValueError("initial parameters must be finite.")
    for index, (value, bound) in enumerate(zip(point, bounds)):
        lower, upper = bound
        if not lower <= value <= upper:
            raise ValueError(
                f"initial parameter '{parameter_names[index]}' is outside optimizer "
                "bounds."
            )


def _optimization_start_seed(seed: int, start_index: int) -> int:
    """Keep start zero backward-compatible and derive every later seed."""
    if start_index == 0:
        return seed
    sequence = np.random.SeedSequence((seed, 2_000_003, start_index))
    return int(sequence.generate_state(1, dtype=np.uint32)[0])


def _qaoa_layerwise_initial_point(
    *,
    layers: int,
    parameter_names: tuple[str, ...],
    previous_parameters: Mapping[str, float],
) -> tuple[float, ...]:
    """Interpolate exactly one shallower canonical QAOA parameter set."""
    if layers <= 1:
        raise ValueError("layerwise initialization requires target layers > 1.")
    previous = _finite_previous_parameters(previous_parameters)
    previous_layers = layers - 1

    expected_target = tuple(f"gamma_{index}" for index in range(layers)) + tuple(
        f"beta_{index}" for index in range(layers)
    )
    expected_previous = tuple(
        f"gamma_{index}" for index in range(previous_layers)
    ) + tuple(f"beta_{index}" for index in range(previous_layers))
    if parameter_names != expected_target:
        raise ValueError(
            "layerwise QAOA requires canonical gamma/beta parameter names."
        )
    if set(previous) != set(expected_previous):
        raise ValueError("layerwise QAOA requires exactly the p-1 layer parameters.")
    old_positions = np.linspace(0.0, 1.0, previous_layers)
    new_positions = np.linspace(0.0, 1.0, layers)
    gammas = np.interp(
        new_positions,
        old_positions,
        [previous[f"gamma_{index}"] for index in range(previous_layers)],
    )
    betas = np.interp(
        new_positions,
        old_positions,
        [previous[f"beta_{index}"] for index in range(previous_layers)],
    )
    values = {
        **{f"gamma_{index}": float(value) for index, value in enumerate(gammas)},
        **{f"beta_{index}": float(value) for index, value in enumerate(betas)},
    }
    return tuple(values[name] for name in parameter_names)


def _finite_previous_parameters(
    values: Mapping[str, float],
) -> dict[str, float]:
    normalized: dict[str, float] = {}
    for name, value in values.items():
        if not isinstance(name, str) or not name.strip():
            raise ValueError("previous parameter names must be non-empty strings.")
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            raise TypeError(f"previous parameter '{name}' must be a real number.")
        normalized_value = float(value)
        if not math.isfinite(normalized_value):
            raise ValueError(f"previous parameter '{name}' must be finite.")
        normalized[name] = normalized_value
    return normalized


def seeded_initial_point(
    *,
    algorithm_kind: AlgorithmKind,
    layers: int,
    parameter_count: int,
    seed: int,
    bounds: tuple[tuple[float, float], ...],
) -> tuple[float, ...]:
    # Include the frozen algorithm shape in the seed stream so changing the
    # algorithm or p-layer count cannot silently reuse an unrelated initial point.
    kind_offset = 0 if algorithm_kind == "qaoa" else 1_000_003
    sequence = np.random.SeedSequence((seed, kind_offset, layers, parameter_count))
    rng = np.random.default_rng(sequence)
    if bounds:
        # Explicit user bounds are also the initialization domain; this keeps an
        # omitted initial point useful even for narrow, problem-specific ranges.
        values = np.asarray(
            [rng.uniform(lower, upper) for lower, upper in bounds],
            dtype=np.float64,
        )
    elif algorithm_kind == "qaoa":
        gamma_count = layers
        gammas = rng.uniform(-math.pi, math.pi, size=gamma_count)
        betas = rng.uniform(-math.pi / 2.0, math.pi / 2.0, size=gamma_count)
        values = np.concatenate((gammas, betas))
    elif algorithm_kind == "vqe":
        values = rng.uniform(-math.pi, math.pi, size=parameter_count)
    else:
        raise ValueError("QAA seeded initialization requires explicit bounds.")
    return tuple(float(value) for value in values)


def _scipy_options(
    config: OptimizerConfig,
) -> tuple[dict[str, bool | int | float], Literal["max_iterations", "max_evaluations"]]:
    options = dict(config.options)
    cobyla_limit_reason: Literal["max_iterations", "max_evaluations"] = "max_iterations"
    if config.method == "COBYLA":
        # SciPy COBYLA names its function-evaluation budget `maxiter` across
        # both the legacy Fortran and current PRIMA implementations.
        limit, cobyla_limit_reason = _cobyla_limit(config)
        options["maxiter"] = limit
    elif config.method == "L-BFGS-B":
        options["maxiter"] = config.max_iterations
        if config.max_evaluations is not None:
            options["maxfun"] = config.max_evaluations
    else:
        options["maxiter"] = config.max_iterations
        if config.max_evaluations is not None:
            options["maxfev"] = config.max_evaluations
    return options, cobyla_limit_reason


def _cobyla_limit(
    config: OptimizerConfig,
) -> tuple[int, Literal["max_iterations", "max_evaluations"]]:
    """Return COBYLA's effective evaluation limit and public reason."""
    if (
        config.max_evaluations is not None
        and config.max_evaluations <= config.max_iterations
    ):
        return config.max_evaluations, "max_evaluations"
    return config.max_iterations, "max_iterations"


def _termination(
    result: OptimizeResult,
    *,
    config: OptimizerConfig,
    nfev: int,
    njev: int = 0,
    backend_execution_count: int | None = None,
    cobyla_limit_reason: Literal["max_iterations", "max_evaluations"],
) -> OptimizerTerminationIR:
    success = bool(result.success)
    nit_value = result.get("nit")
    nit = None if nit_value is None else int(nit_value)
    if success:
        reason: Literal[
            "completed",
            "max_iterations",
            "max_evaluations",
            "max_gradient_evaluations",
            "max_backend_executions",
            "failed",
        ] = "completed"
    elif config.method == "COBYLA":
        evaluation_limit, _ = _cobyla_limit(config)
        reason = cobyla_limit_reason if nfev >= evaluation_limit else "failed"
    elif config.max_evaluations is not None and nfev >= config.max_evaluations:
        reason = "max_evaluations"
    elif nit is not None and nit >= config.max_iterations:
        reason = "max_iterations"
    else:
        reason = "failed"
    return OptimizerTerminationIR(
        method=config.method,
        success=success,
        status=int(result.status),
        message=str(result.message),
        nfev=nfev,
        njev=njev,
        backend_execution_count=backend_execution_count,
        nit=nit,
        reason=reason,
    )
