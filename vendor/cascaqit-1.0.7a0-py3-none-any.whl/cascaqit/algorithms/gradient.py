"""Parameter-shift planning and auditable gradient result contracts."""

from __future__ import annotations

import hashlib
import json
import math
import re
from collections.abc import Mapping
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Any, Literal, NoReturn, cast

from cascaqit.algorithms.execution import (
    ParameterValues,
    execute_objective_evaluation,
    normalize_parameter_values,
)
from cascaqit.algorithms.models import (
    ObjectiveEvaluationIR,
    PauliHamiltonian,
)
from cascaqit.algorithms.noisy_execution import validate_noisy_variational_request
from cascaqit.digital import Circuit, GateParameterOccurrence
from cascaqit.exceptions import CapabilityError
from cascaqit.native_ir.base import IRMixin, stable_json
from cascaqit.parameters import ParameterBindIR, ParameterSchemaIR
from cascaqit.parameters.canonical import Expression, Parameter
from cascaqit.simulators import LocalBackend, NoiseModel, SimulationOptions

__all__ = [
    "GradientConfig",
    "ObjectiveGradientIR",
    "ParameterShiftOccurrenceIR",
    "ParameterShiftPlanIR",
    "ShiftPairEvaluationIR",
    "build_parameter_shift_plan",
    "execute_parameter_shift_gradient",
]

GRADIENT_SCHEMA_VERSION = "cascaqit.algorithms.gradient.v1"
_DIGEST_PATTERN = re.compile(r"[0-9a-f]{64}")
_TOLERANCE = 1e-12
_STANDARD_SHIFT = math.pi / 2.0
_STANDARD_PREFACTOR = 0.5


@dataclass(frozen=True)
class GradientConfig(IRMixin):
    """Configuration for the first exact, noiseless gradient method."""

    method: Literal["parameter_shift"] = "parameter_shift"
    shift: float = _STANDARD_SHIFT
    prefactor: float = _STANDARD_PREFACTOR
    max_evaluations: int | None = None
    schema_version: str = GRADIENT_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.method != "parameter_shift":
            raise ValueError("gradient method must be parameter_shift.")
        shift = _finite_float(self.shift, "shift")
        prefactor = _finite_float(self.prefactor, "prefactor")
        if not math.isclose(shift, _STANDARD_SHIFT, rel_tol=0.0, abs_tol=1e-15):
            raise ValueError("parameter-shift shift must equal pi/2.")
        if not math.isclose(
            prefactor,
            _STANDARD_PREFACTOR,
            rel_tol=0.0,
            abs_tol=1e-15,
        ):
            raise ValueError("parameter-shift prefactor must equal 0.5.")
        if self.max_evaluations is not None and (
            not isinstance(self.max_evaluations, int)
            or isinstance(self.max_evaluations, bool)
            or self.max_evaluations <= 0
        ):
            raise ValueError("max_evaluations must be a positive integer or None.")
        object.__setattr__(self, "shift", shift)
        object.__setattr__(self, "prefactor", prefactor)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> GradientConfig:
        """Restore gradient configuration from JSON-compatible data."""
        return cls(
            method=data.get("method", "parameter_shift"),
            shift=data.get("shift", _STANDARD_SHIFT),
            prefactor=data.get("prefactor", _STANDARD_PREFACTOR),
            max_evaluations=data.get("max_evaluations"),
            schema_version=str(data.get("schema_version", GRADIENT_SCHEMA_VERSION)),
        )

    @classmethod
    def from_json(cls, text: str) -> GradientConfig:
        """Restore gradient configuration from JSON text."""
        return cls.from_dict(_json_object(text, "GradientConfig"))


@dataclass(frozen=True)
class ParameterShiftOccurrenceIR(IRMixin):
    """One supported gate occurrence and its two shifted Circuit identities."""

    occurrence_id: str
    gate_index: int
    gate_id: str
    gate_name: Literal["rx", "ry", "rz"]
    targets: tuple[str, ...]
    parameter_name: Literal["theta"]
    affine_offset: float
    coefficients: Mapping[str, float]
    positive_circuit_hash: str
    negative_circuit_hash: str
    schema_version: str = GRADIENT_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_text(self.occurrence_id, "occurrence_id")
        _require_non_negative_int(self.gate_index, "gate_index")
        _require_text(self.gate_id, "gate_id")
        if self.gate_name not in {"rx", "ry", "rz"}:
            raise ValueError("gradient occurrence gate_name must be rx, ry, or rz.")
        targets = tuple(str(target) for target in self.targets)
        if len(targets) != 1 or not targets[0]:
            raise ValueError("gradient occurrence must contain one target.")
        object.__setattr__(self, "targets", targets)
        if self.parameter_name != "theta":
            raise ValueError("gradient occurrence parameter_name must be theta.")
        object.__setattr__(
            self,
            "affine_offset",
            _finite_float(self.affine_offset, "affine_offset"),
        )
        coefficients = _finite_mapping(self.coefficients, "coefficients")
        if not coefficients:
            raise ValueError("gradient occurrence coefficients must not be empty.")
        object.__setattr__(self, "coefficients", coefficients)
        _require_digest(self.positive_circuit_hash, "positive_circuit_hash")
        _require_digest(self.negative_circuit_hash, "negative_circuit_hash")
        if self.positive_circuit_hash == self.negative_circuit_hash:
            raise ValueError("positive and negative Circuit hashes must differ.")

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ParameterShiftOccurrenceIR:
        """Restore one planned occurrence from JSON-compatible data."""
        return cls(
            occurrence_id=data["occurrence_id"],
            gate_index=data["gate_index"],
            gate_id=data["gate_id"],
            gate_name=data["gate_name"],
            targets=tuple(_sequence(data["targets"], "targets")),
            parameter_name=data["parameter_name"],
            affine_offset=data["affine_offset"],
            coefficients=_mapping(data["coefficients"], "coefficients"),
            positive_circuit_hash=data["positive_circuit_hash"],
            negative_circuit_hash=data["negative_circuit_hash"],
            schema_version=str(data.get("schema_version", GRADIENT_SCHEMA_VERSION)),
        )


@dataclass(frozen=True)
class ParameterShiftPlanIR(IRMixin):
    """Complete side-effect-free parameter-shift execution plan."""

    source_circuit_hash: str
    hamiltonian_hash: str
    logical_order: tuple[str, ...]
    parameter_names: tuple[str, ...]
    occurrences: tuple[ParameterShiftOccurrenceIR, ...]
    shift: float = _STANDARD_SHIFT
    prefactor: float = _STANDARD_PREFACTOR
    expected_backend_execution_count: int = 0
    plan_hash: str = ""
    method: Literal["parameter_shift"] = "parameter_shift"
    schema_version: str = GRADIENT_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_digest(self.source_circuit_hash, "source_circuit_hash")
        _require_digest(self.hamiltonian_hash, "hamiltonian_hash")
        logical_order = _unique_text_tuple(self.logical_order, "logical_order")
        parameter_names = _unique_text_tuple(self.parameter_names, "parameter_names")
        object.__setattr__(self, "logical_order", logical_order)
        object.__setattr__(self, "parameter_names", parameter_names)
        occurrences = tuple(self.occurrences)
        if not occurrences or any(
            not isinstance(item, ParameterShiftOccurrenceIR) for item in occurrences
        ):
            raise ValueError("occurrences must contain planned parameter shifts.")
        occurrence_ids = tuple(item.occurrence_id for item in occurrences)
        if len(occurrence_ids) != len(set(occurrence_ids)):
            raise ValueError("gradient occurrence ids must be unique.")
        if tuple(item.gate_index for item in occurrences) != tuple(
            sorted(item.gate_index for item in occurrences)
        ):
            raise ValueError("gradient occurrences must follow Circuit gate order.")
        for occurrence in occurrences:
            if not set(occurrence.coefficients).issubset(parameter_names):
                raise ValueError("occurrence coefficients contain unknown parameters.")
        covered = {
            name for occurrence in occurrences for name in occurrence.coefficients
        }
        if covered != set(parameter_names):
            raise ValueError(
                "every plan parameter must have an occurrence coefficient."
            )
        object.__setattr__(self, "occurrences", occurrences)
        if self.method != "parameter_shift":
            raise ValueError("gradient plan method must be parameter_shift.")
        GradientConfig(method=self.method, shift=self.shift, prefactor=self.prefactor)
        expected_count = 2 * len(occurrences)
        if self.expected_backend_execution_count != expected_count:
            raise ValueError(
                "expected_backend_execution_count must equal two per occurrence."
            )
        if not self.plan_hash:
            object.__setattr__(self, "plan_hash", self.compute_plan_hash())
        else:
            _require_digest(self.plan_hash, "plan_hash")
            if not self.verify_hash():
                raise ValueError("plan_hash does not match the gradient plan.")

    def compute_plan_hash(self) -> str:
        """Hash all executable plan facts except the embedded hash itself."""
        return hashlib.sha256(
            stable_json(self._hash_payload()).encode("utf-8")
        ).hexdigest()

    def verify_hash(self) -> bool:
        """Return whether the embedded plan hash matches current facts."""
        return self.plan_hash == self.compute_plan_hash()

    def _hash_payload(self) -> dict[str, Any]:
        return {
            "source_circuit_hash": self.source_circuit_hash,
            "hamiltonian_hash": self.hamiltonian_hash,
            "logical_order": self.logical_order,
            "parameter_names": self.parameter_names,
            "occurrences": self.occurrences,
            "shift": self.shift,
            "prefactor": self.prefactor,
            "expected_backend_execution_count": self.expected_backend_execution_count,
            "method": self.method,
            "schema_version": self.schema_version,
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ParameterShiftPlanIR:
        """Restore and verify a plan from JSON-compatible data."""
        return cls(
            source_circuit_hash=data["source_circuit_hash"],
            hamiltonian_hash=data["hamiltonian_hash"],
            logical_order=tuple(_sequence(data["logical_order"], "logical_order")),
            parameter_names=tuple(
                _sequence(data["parameter_names"], "parameter_names")
            ),
            occurrences=tuple(
                ParameterShiftOccurrenceIR.from_dict(_mapping(item, "occurrence"))
                for item in _sequence(data["occurrences"], "occurrences")
            ),
            shift=data["shift"],
            prefactor=data["prefactor"],
            expected_backend_execution_count=data["expected_backend_execution_count"],
            plan_hash=data["plan_hash"],
            method=data.get("method", "parameter_shift"),
            schema_version=str(data.get("schema_version", GRADIENT_SCHEMA_VERSION)),
        )

    @classmethod
    def from_json(cls, text: str) -> ParameterShiftPlanIR:
        """Restore and verify a plan from JSON text."""
        return cls.from_dict(_json_object(text, "ParameterShiftPlanIR"))


@dataclass(frozen=True)
class ShiftPairEvaluationIR(IRMixin):
    """Positive and negative Objective evaluations for one occurrence."""

    occurrence_id: str
    positive_circuit_hash: str
    negative_circuit_hash: str
    positive_evaluation: ObjectiveEvaluationIR
    negative_evaluation: ObjectiveEvaluationIR
    energy_difference: float
    prefactor: float
    gate_derivative: float
    backend_execution_count: int = 2
    schema_version: str = GRADIENT_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_text(self.occurrence_id, "occurrence_id")
        _require_digest(self.positive_circuit_hash, "positive_circuit_hash")
        _require_digest(self.negative_circuit_hash, "negative_circuit_hash")
        if not isinstance(
            self.positive_evaluation, ObjectiveEvaluationIR
        ) or not isinstance(
            self.negative_evaluation,
            ObjectiveEvaluationIR,
        ):
            raise TypeError("shift pair evaluations must be ObjectiveEvaluationIR.")
        if (
            self.positive_evaluation.hamiltonian_hash
            != self.negative_evaluation.hamiltonian_hash
        ):
            raise ValueError("shift pair Hamiltonian hashes must match.")
        _require_matching_execution_context(
            (self.positive_evaluation, self.negative_evaluation)
        )
        difference = self.positive_evaluation.energy - self.negative_evaluation.energy
        if not math.isclose(
            _finite_float(self.energy_difference, "energy_difference"),
            difference,
            rel_tol=0.0,
            abs_tol=_TOLERANCE,
        ):
            raise ValueError(
                "energy_difference must match positive minus negative energy."
            )
        prefactor = _finite_float(self.prefactor, "prefactor")
        derivative = prefactor * difference
        if not math.isclose(
            _finite_float(self.gate_derivative, "gate_derivative"),
            derivative,
            rel_tol=0.0,
            abs_tol=_TOLERANCE,
        ):
            raise ValueError(
                "gate_derivative must equal prefactor * energy_difference."
            )
        if self.backend_execution_count != 2:
            raise ValueError("each shift pair must record two Backend executions.")
        object.__setattr__(self, "energy_difference", difference)
        object.__setattr__(self, "prefactor", prefactor)
        object.__setattr__(self, "gate_derivative", derivative)

    @classmethod
    def create(
        cls,
        *,
        occurrence: ParameterShiftOccurrenceIR,
        positive_evaluation: ObjectiveEvaluationIR,
        negative_evaluation: ObjectiveEvaluationIR,
        prefactor: float,
    ) -> ShiftPairEvaluationIR:
        """Build one pair while deriving all arithmetic fields."""
        difference = positive_evaluation.energy - negative_evaluation.energy
        return cls(
            occurrence_id=occurrence.occurrence_id,
            positive_circuit_hash=occurrence.positive_circuit_hash,
            negative_circuit_hash=occurrence.negative_circuit_hash,
            positive_evaluation=positive_evaluation,
            negative_evaluation=negative_evaluation,
            energy_difference=difference,
            prefactor=prefactor,
            gate_derivative=prefactor * difference,
        )

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ShiftPairEvaluationIR:
        """Restore and verify one shift pair."""
        return cls(
            occurrence_id=data["occurrence_id"],
            positive_circuit_hash=data["positive_circuit_hash"],
            negative_circuit_hash=data["negative_circuit_hash"],
            positive_evaluation=ObjectiveEvaluationIR.from_dict(
                _mapping(data["positive_evaluation"], "positive_evaluation")
            ),
            negative_evaluation=ObjectiveEvaluationIR.from_dict(
                _mapping(data["negative_evaluation"], "negative_evaluation")
            ),
            energy_difference=data["energy_difference"],
            prefactor=data["prefactor"],
            gate_derivative=data["gate_derivative"],
            backend_execution_count=data.get("backend_execution_count", 2),
            schema_version=str(data.get("schema_version", GRADIENT_SCHEMA_VERSION)),
        )


@dataclass(frozen=True)
class ObjectiveGradientIR(IRMixin):
    """Self-contained objective gradient reconstructed from shift pairs."""

    gradient_id: str
    gradient_index: int
    plan: ParameterShiftPlanIR
    plan_hash: str
    parameter_bind: ParameterBindIR
    shift_pairs: tuple[ShiftPairEvaluationIR, ...]
    parameter_contributions: Mapping[str, Mapping[str, float]]
    gradient: Mapping[str, float]
    l2_norm: float
    backend_execution_count: int
    gradient_hash: str = ""
    metadata: Mapping[str, Any] = field(default_factory=dict)
    schema_version: str = GRADIENT_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_text(self.gradient_id, "gradient_id")
        _require_non_negative_int(self.gradient_index, "gradient_index")
        if (
            not isinstance(self.plan, ParameterShiftPlanIR)
            or not self.plan.verify_hash()
        ):
            raise ValueError("plan must be a verified ParameterShiftPlanIR.")
        if self.plan_hash != self.plan.plan_hash:
            raise ValueError("plan_hash must match the embedded gradient plan.")
        if (
            not isinstance(self.parameter_bind, ParameterBindIR)
            or not self.parameter_bind.verify_hash()
        ):
            raise ValueError("parameter_bind must contain a verified hash.")
        if set(self.parameter_bind.values) != set(self.plan.parameter_names):
            raise ValueError("parameter_bind values must match plan parameter_names.")
        pairs = tuple(self.shift_pairs)
        if tuple(pair.occurrence_id for pair in pairs) != tuple(
            occurrence.occurrence_id for occurrence in self.plan.occurrences
        ):
            raise ValueError("shift_pairs must match plan occurrence order.")
        # 每个正负 pair 自己校验一次，同一梯度再跨 pair 校验一次。这样从 JSON
        # 恢复时，替换任意一次 shift 的 NoiseModel、options 或 estimator 都会失败。
        _require_matching_execution_context(
            tuple(
                evaluation
                for pair in pairs
                for evaluation in (
                    pair.positive_evaluation,
                    pair.negative_evaluation,
                )
            )
        )
        expected_contributions: dict[str, dict[str, float]] = {
            name: {} for name in self.plan.parameter_names
        }
        for occurrence, pair in zip(self.plan.occurrences, pairs):
            if (
                pair.positive_circuit_hash != occurrence.positive_circuit_hash
                or pair.negative_circuit_hash != occurrence.negative_circuit_hash
            ):
                raise ValueError("shift pair Circuit hashes must match the plan.")
            if pair.prefactor != self.plan.prefactor:
                raise ValueError("shift pair prefactor must match the plan.")
            for evaluation in (pair.positive_evaluation, pair.negative_evaluation):
                if evaluation.hamiltonian_hash != self.plan.hamiltonian_hash:
                    raise ValueError(
                        "shift evaluation Hamiltonian hash must match plan."
                    )
                if (
                    evaluation.parameter_bind.parameter_schema_hash
                    != self.parameter_bind.parameter_schema_hash
                ):
                    raise ValueError(
                        "shift evaluation parameter schema must match gradient bind."
                    )
                if dict(evaluation.parameter_bind.values) != dict(
                    self.parameter_bind.values
                ):
                    raise ValueError(
                        "shift evaluation parameter values must match gradient bind."
                    )
            for name, coefficient in occurrence.coefficients.items():
                expected_contributions[name][occurrence.occurrence_id] = (
                    coefficient * pair.gate_derivative
                )
        contributions = _nested_finite_mapping(
            self.parameter_contributions,
            "parameter_contributions",
        )
        _require_nested_close(contributions, expected_contributions)
        expected_gradient = {
            name: sum(expected_contributions[name].values())
            for name in self.plan.parameter_names
        }
        gradient = _finite_mapping(self.gradient, "gradient")
        _require_mapping_close(gradient, expected_gradient, "gradient")
        norm = math.sqrt(sum(value * value for value in expected_gradient.values()))
        if not math.isclose(
            _finite_float(self.l2_norm, "l2_norm"),
            norm,
            rel_tol=0.0,
            abs_tol=_TOLERANCE,
        ):
            raise ValueError("l2_norm must match reconstructed gradient components.")
        expected_count = sum(pair.backend_execution_count for pair in pairs)
        if (
            self.backend_execution_count != expected_count
            or expected_count != self.plan.expected_backend_execution_count
        ):
            raise ValueError("backend_execution_count must match shift pairs and plan.")
        object.__setattr__(self, "shift_pairs", pairs)
        object.__setattr__(self, "parameter_contributions", contributions)
        object.__setattr__(self, "gradient", gradient)
        object.__setattr__(self, "l2_norm", norm)
        object.__setattr__(self, "metadata", _freeze_mapping(self.metadata))
        if not self.gradient_hash:
            object.__setattr__(self, "gradient_hash", self.compute_gradient_hash())
        else:
            _require_digest(self.gradient_hash, "gradient_hash")
            if not self.verify_hash():
                raise ValueError("gradient_hash does not match gradient result facts.")

    @classmethod
    def create(
        cls,
        *,
        gradient_id: str,
        gradient_index: int,
        plan: ParameterShiftPlanIR,
        parameter_bind: ParameterBindIR,
        shift_pairs: tuple[ShiftPairEvaluationIR, ...],
        metadata: Mapping[str, Any] | None = None,
    ) -> ObjectiveGradientIR:
        """Derive contributions, components, norm, cost, and result hash."""
        pairs_by_id = {pair.occurrence_id: pair for pair in shift_pairs}
        contributions: dict[str, dict[str, float]] = {
            name: {} for name in plan.parameter_names
        }
        for occurrence in plan.occurrences:
            pair = pairs_by_id.get(occurrence.occurrence_id)
            if pair is None:
                raise ValueError("shift_pairs are missing a planned occurrence.")
            for name, coefficient in occurrence.coefficients.items():
                contributions[name][occurrence.occurrence_id] = (
                    coefficient * pair.gate_derivative
                )
        gradient = {
            name: sum(contributions[name].values()) for name in plan.parameter_names
        }
        return cls(
            gradient_id=gradient_id,
            gradient_index=gradient_index,
            plan=plan,
            plan_hash=plan.plan_hash,
            parameter_bind=parameter_bind,
            shift_pairs=shift_pairs,
            parameter_contributions=contributions,
            gradient=gradient,
            l2_norm=math.sqrt(sum(value * value for value in gradient.values())),
            backend_execution_count=sum(
                pair.backend_execution_count for pair in shift_pairs
            ),
            metadata={} if metadata is None else metadata,
        )

    def compute_gradient_hash(self) -> str:
        """Hash all saved gradient evidence except the embedded hash itself."""
        return hashlib.sha256(
            stable_json(self._hash_payload()).encode("utf-8")
        ).hexdigest()

    def verify_hash(self) -> bool:
        """Return whether the embedded gradient hash matches saved evidence."""
        return self.gradient_hash == self.compute_gradient_hash()

    def _hash_payload(self) -> dict[str, Any]:
        return {
            "gradient_id": self.gradient_id,
            "gradient_index": self.gradient_index,
            "plan": self.plan,
            "plan_hash": self.plan_hash,
            "parameter_bind": self.parameter_bind,
            "shift_pairs": self.shift_pairs,
            "parameter_contributions": self.parameter_contributions,
            "gradient": self.gradient,
            "l2_norm": self.l2_norm,
            "backend_execution_count": self.backend_execution_count,
            "metadata": self.metadata,
            "schema_version": self.schema_version,
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ObjectiveGradientIR:
        """Restore and fully recompute a gradient result."""
        return cls(
            gradient_id=data["gradient_id"],
            gradient_index=data["gradient_index"],
            plan=ParameterShiftPlanIR.from_dict(_mapping(data["plan"], "plan")),
            plan_hash=data["plan_hash"],
            parameter_bind=ParameterBindIR.from_dict(
                _mapping(data["parameter_bind"], "parameter_bind")
            ),
            shift_pairs=tuple(
                ShiftPairEvaluationIR.from_dict(_mapping(item, "shift_pair"))
                for item in _sequence(data["shift_pairs"], "shift_pairs")
            ),
            parameter_contributions=_mapping(
                data["parameter_contributions"],
                "parameter_contributions",
            ),
            gradient=_mapping(data["gradient"], "gradient"),
            l2_norm=data["l2_norm"],
            backend_execution_count=data["backend_execution_count"],
            gradient_hash=data["gradient_hash"],
            metadata=_mapping(data.get("metadata", {}), "metadata"),
            schema_version=str(data.get("schema_version", GRADIENT_SCHEMA_VERSION)),
        )

    @classmethod
    def from_json(cls, text: str) -> ObjectiveGradientIR:
        """Restore and fully recompute a gradient result from JSON."""
        return cls.from_dict(_json_object(text, "ObjectiveGradientIR"))


def build_parameter_shift_plan(
    circuit: Circuit,
    hamiltonian: PauliHamiltonian,
    *,
    config: GradientConfig | None = None,
) -> ParameterShiftPlanIR:
    """Validate every parameter occurrence and build a Backend-free plan."""
    if not isinstance(circuit, Circuit):
        raise TypeError("circuit must be Circuit.")
    if not isinstance(hamiltonian, PauliHamiltonian):
        raise TypeError("hamiltonian must be PauliHamiltonian.")
    selected_config = GradientConfig() if config is None else config
    if not isinstance(selected_config, GradientConfig):
        raise TypeError("config must be GradientConfig or None.")
    if circuit.qubits != hamiltonian.logical_order:
        _raise_capability(
            "Circuit qubits must match Hamiltonian logical_order.",
            code="GRADIENT_LOGICAL_ORDER_MISMATCH",
            metadata={
                "circuit_qubits": list(circuit.qubits),
                "hamiltonian_logical_order": list(hamiltonian.logical_order),
            },
        )
    parameter_names = tuple(parameter.name for parameter in circuit.parameters)
    if not parameter_names:
        _raise_capability(
            "Gradient planning requires at least one Circuit parameter.",
            code="GRADIENT_PARAMETER_EMPTY",
        )

    planned: list[ParameterShiftOccurrenceIR] = []
    for occurrence in circuit.parameter_occurrences():
        dependencies = _occurrence_dependencies(occurrence)
        if not set(dependencies).intersection(parameter_names):
            continue
        if not occurrence.supported or occurrence.affine_form is None:
            _raise_capability(
                "Circuit contains a parameter occurrence unsupported by gradients.",
                code="GRADIENT_OCCURRENCE_UNSUPPORTED",
                metadata={
                    "occurrence_id": occurrence.occurrence_id,
                    "gate_name": occurrence.gate_name,
                    "parameter_name": occurrence.parameter_name,
                    "unsupported_reason": occurrence.unsupported_reason,
                },
            )
        form = occurrence.affine_form
        assert form is not None
        positive = circuit.shift_parameter_occurrence(
            occurrence.occurrence_id,
            selected_config.shift,
        )
        negative = circuit.shift_parameter_occurrence(
            occurrence.occurrence_id,
            -selected_config.shift,
        )
        planned.append(
            ParameterShiftOccurrenceIR(
                occurrence_id=occurrence.occurrence_id,
                gate_index=occurrence.gate_index,
                gate_id=occurrence.gate_id,
                gate_name=cast(
                    Literal["rx", "ry", "rz"],
                    occurrence.gate_name,
                ),
                targets=occurrence.targets,
                parameter_name="theta",
                affine_offset=form.offset,
                coefficients=form.coefficients,
                positive_circuit_hash=positive.structural_hash(),
                negative_circuit_hash=negative.structural_hash(),
            )
        )
    covered = {name for item in planned for name in item.coefficients}
    missing = tuple(name for name in parameter_names if name not in covered)
    if missing:
        _raise_capability(
            "Every Circuit parameter must affect a supported gradient occurrence.",
            code="GRADIENT_PARAMETER_UNUSED",
            metadata={"parameter_names": list(missing)},
        )
    return ParameterShiftPlanIR(
        source_circuit_hash=circuit.structural_hash(),
        hamiltonian_hash=hamiltonian.stable_hash(),
        logical_order=hamiltonian.logical_order,
        parameter_names=parameter_names,
        occurrences=tuple(planned),
        shift=selected_config.shift,
        prefactor=selected_config.prefactor,
        expected_backend_execution_count=2 * len(planned),
    )


def execute_parameter_shift_gradient(
    *,
    algorithm_kind: Literal["qaoa", "vqe"],
    algorithm_id: str,
    algorithm_run_id: str | None,
    gradient_index: int,
    circuit: Circuit,
    parameter_names: tuple[str, ...],
    parameters: ParameterValues,
    hamiltonian: PauliHamiltonian,
    backend: LocalBackend | None,
    seed: int | None,
    config: GradientConfig | None = None,
    noise: NoiseModel | None = None,
    options: SimulationOptions | None = None,
) -> ObjectiveGradientIR:
    """执行一次 ideal 或 exact-density noisy occurrence-level 梯度。"""
    if algorithm_kind not in {"qaoa", "vqe"}:
        raise ValueError("algorithm_kind must be qaoa or vqe.")
    _require_text(algorithm_id, "algorithm_id")
    _require_non_negative_int(gradient_index, "gradient_index")
    run_id = algorithm_id if algorithm_run_id is None else algorithm_run_id
    _require_text(run_id, "algorithm_run_id")
    if backend is not None and not isinstance(backend, LocalBackend):
        raise TypeError("backend must be LocalBackend or None.")
    if not isinstance(circuit, Circuit):
        raise TypeError("circuit must be Circuit.")
    if not isinstance(hamiltonian, PauliHamiltonian):
        raise TypeError("hamiltonian must be PauliHamiltonian.")
    if not isinstance(parameter_names, tuple) or any(
        not isinstance(name, str) for name in parameter_names
    ):
        raise TypeError("parameter_names must be a tuple of strings.")

    declared_names = tuple(parameter.name for parameter in circuit.parameters)
    if declared_names != parameter_names:
        raise ValueError("Circuit parameter order must match the ansatz declaration.")
    values = normalize_parameter_values(parameters, parameter_names)
    plan = build_parameter_shift_plan(circuit, hamiltonian, config=config)

    # 构造并核对全部正负线路后才允许提交第一个 Job，避免计划漂移或不支持
    # occurrence 产生部分梯度证据。
    occurrences_by_id = {
        occurrence.occurrence_id: occurrence
        for occurrence in circuit.parameter_occurrences()
    }
    shifted_circuits: list[tuple[Circuit, Circuit]] = []
    for planned in plan.occurrences:
        if planned.occurrence_id not in occurrences_by_id:
            raise ValueError("gradient plan contains an unknown Circuit occurrence.")
        positive = circuit.shift_parameter_occurrence(
            planned.occurrence_id,
            plan.shift,
        )
        negative = circuit.shift_parameter_occurrence(
            planned.occurrence_id,
            -plan.shift,
        )
        if (
            positive.structural_hash() != planned.positive_circuit_hash
            or negative.structural_hash() != planned.negative_circuit_hash
        ):
            raise ValueError("shifted Circuit hashes do not match the gradient plan.")
        shifted_circuits.append((positive, negative))

    selected_backend = LocalBackend(seed=seed) if backend is None else backend
    if noise is not None:
        # 完整 shift 计划已经构造并核对，但此时尚未提交任何 Job。用未绑定源线路
        # 预检即可冻结方法与资源选择；所有 shift 线路保持相同 qubit/gate 结构。
        validate_noisy_variational_request(
            circuit,
            noise=noise,
            options=options,
            backend=selected_backend,
            seed=seed,
        )
    gradient_run_id = f"{run_id}.gradient.{gradient_index:06d}"
    parameter_schema = ParameterSchemaIR.from_parameters(circuit.parameters)
    parameter_bind = ParameterBindIR.create(
        parameter_bind_id=f"{gradient_run_id}.bind",
        parameter_schema=parameter_schema,
        values=values,
        metadata={
            "algorithm": algorithm_kind,
            "algorithm_id": algorithm_id,
            "algorithm_run_id": run_id,
            "gradient_index": gradient_index,
        },
    )

    # evaluation_index 使用全局稳定偏移；gradient_run_id 再提供独立命名空间，
    # 因而同一梯度内的 Job、Result 和 Objective identity 均不冲突。
    evaluation_base = gradient_index * plan.expected_backend_execution_count
    shift_pairs: list[ShiftPairEvaluationIR] = []
    for occurrence_index, (planned, shifted) in enumerate(
        zip(plan.occurrences, shifted_circuits)
    ):
        positive_index = evaluation_base + 2 * occurrence_index
        negative_index = positive_index + 1
        positive, negative = shifted
        positive_evaluation = execute_objective_evaluation(
            algorithm_kind=algorithm_kind,
            algorithm_id=algorithm_id,
            algorithm_run_id=gradient_run_id,
            evaluation_index=positive_index,
            circuit=positive,
            parameter_names=parameter_names,
            parameters=values,
            hamiltonian=hamiltonian,
            backend=selected_backend,
            seed=seed,
            noise=noise,
            options=options,
        )
        negative_evaluation = execute_objective_evaluation(
            algorithm_kind=algorithm_kind,
            algorithm_id=algorithm_id,
            algorithm_run_id=gradient_run_id,
            evaluation_index=negative_index,
            circuit=negative,
            parameter_names=parameter_names,
            parameters=values,
            hamiltonian=hamiltonian,
            backend=selected_backend,
            seed=seed,
            noise=noise,
            options=options,
        )
        shift_pairs.append(
            ShiftPairEvaluationIR.create(
                occurrence=planned,
                positive_evaluation=positive_evaluation,
                negative_evaluation=negative_evaluation,
                prefactor=plan.prefactor,
            )
        )

    gradient = ObjectiveGradientIR.create(
        gradient_id=gradient_run_id,
        gradient_index=gradient_index,
        plan=plan,
        parameter_bind=parameter_bind,
        shift_pairs=tuple(shift_pairs),
        metadata={
            "algorithm": algorithm_kind,
            "algorithm_id": algorithm_id,
            "algorithm_run_id": run_id,
            "gradient_index": gradient_index,
            "shift_pair_count": len(shift_pairs),
            "backend_execution_count": plan.expected_backend_execution_count,
            "seed": seed,
            "estimator": shift_pairs[
                0
            ].positive_evaluation.execution_evidence.estimator_kind.value,
            "simulation_method": shift_pairs[
                0
            ].positive_evaluation.execution_evidence.simulation_plan.method_selected,
            "noise_model_hash": None if noise is None else noise.stable_hash(),
        },
    )
    return gradient


def _require_matching_execution_context(
    evaluations: tuple[ObjectiveEvaluationIR, ...],
) -> None:
    """校验一组 shift objective 使用相同的物理与估计上下文。"""
    if not evaluations:
        raise ValueError("gradient execution context requires evaluations.")
    expected = _execution_context(evaluations[0])
    for evaluation in evaluations[1:]:
        if _execution_context(evaluation) != expected:
            raise ValueError(
                "shift evaluations must share NoiseModel, requested options, "
                "simulation method, and estimator."
            )


def _execution_context(evaluation: ObjectiveEvaluationIR) -> tuple[object, ...]:
    evidence = evaluation.execution_evidence
    return (
        None if evidence.noise_model is None else evidence.noise_model.stable_hash(),
        None
        if evidence.requested_options is None
        else evidence.requested_options.stable_hash(),
        evidence.simulation_plan.method_selected,
        evidence.estimator_kind,
        evidence.source_kind,
    )


def _occurrence_dependencies(occurrence: GateParameterOccurrence) -> tuple[str, ...]:
    value = occurrence.parameter_value
    if isinstance(value, Parameter):
        return (value.name,)
    if isinstance(value, Expression):
        return value.dependencies
    return ()


def _raise_capability(
    message: str,
    *,
    code: str,
    metadata: Mapping[str, Any] | None = None,
) -> NoReturn:
    raise CapabilityError(
        message,
        code=code,
        object_path="algorithms.gradient.plan",
        suggestion="Use symbolic affine RX, RY, or RZ parameters only.",
        metadata={} if metadata is None else dict(metadata),
    )


def _finite_float(value: object, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{name} must be a real number.")
    normalized = float(value)
    if not math.isfinite(normalized):
        raise ValueError(f"{name} must be finite.")
    return normalized


def _finite_mapping(value: object, name: str) -> Mapping[str, float]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{name} must be a mapping.")
    normalized: dict[str, float] = {}
    for raw_key, raw_value in value.items():
        key = str(raw_key)
        _require_text(key, f"{name} key")
        normalized[key] = _finite_float(raw_value, f"{name}[{key}]")
    return MappingProxyType(normalized)


def _nested_finite_mapping(
    value: object,
    name: str,
) -> Mapping[str, Mapping[str, float]]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{name} must be a mapping.")
    return MappingProxyType(
        {
            str(key): _finite_mapping(item, f"{name}[{key}]")
            for key, item in value.items()
        }
    )


def _freeze_mapping(value: Mapping[str, Any]) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError("metadata must be a mapping.")
    return MappingProxyType(
        {str(key): _freeze_value(item) for key, item in sorted(value.items())}
    )


def _freeze_value(value: Any) -> Any:
    if isinstance(value, Mapping):
        return _freeze_mapping(value)
    if isinstance(value, (list, tuple)):
        return tuple(_freeze_value(item) for item in value)
    return value


def _require_mapping_close(
    actual: Mapping[str, float],
    expected: Mapping[str, float],
    name: str,
) -> None:
    if set(actual) != set(expected) or any(
        not math.isclose(actual[key], expected[key], rel_tol=0.0, abs_tol=_TOLERANCE)
        for key in expected
    ):
        raise ValueError(f"{name} does not match reconstructed values.")


def _require_nested_close(
    actual: Mapping[str, Mapping[str, float]],
    expected: Mapping[str, Mapping[str, float]],
) -> None:
    if set(actual) != set(expected):
        raise ValueError("parameter_contributions keys do not match plan parameters.")
    for name in expected:
        _require_mapping_close(
            actual[name],
            expected[name],
            f"parameter_contributions[{name}]",
        )


def _unique_text_tuple(value: object, name: str) -> tuple[str, ...]:
    values = tuple(str(item) for item in _sequence(value, name))
    if not values:
        raise ValueError(f"{name} must not be empty.")
    for item in values:
        _require_text(item, name)
    if len(values) != len(set(values)):
        raise ValueError(f"{name} values must be unique.")
    return values


def _require_text(value: object, name: str) -> None:
    if not isinstance(value, str) or not value.strip() or value != value.strip():
        raise ValueError(f"{name} must be a non-empty trimmed string.")


def _require_digest(value: object, name: str) -> None:
    if not isinstance(value, str) or _DIGEST_PATTERN.fullmatch(value) is None:
        raise ValueError(f"{name} must be a lowercase SHA-256 digest.")


def _require_non_negative_int(value: object, name: str) -> None:
    if not isinstance(value, int) or isinstance(value, bool) or value < 0:
        raise ValueError(f"{name} must be a non-negative integer.")


def _mapping(value: object, name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{name} must be an object.")
    return value


def _sequence(value: object, name: str) -> tuple[Any, ...]:
    if not isinstance(value, (list, tuple)):
        raise TypeError(f"{name} must be an array.")
    return tuple(value)


def _json_object(text: str, name: str) -> Mapping[str, Any]:
    data = json.loads(text)
    if not isinstance(data, dict):
        raise TypeError(f"{name} JSON must contain an object.")
    return data
