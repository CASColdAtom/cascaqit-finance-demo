"""Executable VQE ansatz and single-objective evaluation."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Union

from cascaqit.algorithms.ansatz import (
    BuiltAnsatz,
    HardwareEfficientAnsatz,
    build_vqe_ansatz,
)
from cascaqit.algorithms.execution import (
    ParameterValues,
    execute_objective_evaluation,
)
from cascaqit.algorithms.gradient import (
    GradientConfig,
    ObjectiveGradientIR,
    execute_parameter_shift_gradient,
)
from cascaqit.algorithms.models import (
    AnsatzSpecIR,
    ObjectiveEvaluationIR,
    OptimizerConfig,
    PauliHamiltonian,
    VariationalResult,
)
from cascaqit.algorithms.optimizer import run_variational_optimization
from cascaqit.algorithms.problem_projection import problem_to_pauli_hamiltonian
from cascaqit.digital import Circuit
from cascaqit.parameters import ParameterSchemaIR
from cascaqit.problems import IsingModelIR, QUBOProblemIR
from cascaqit.simulators import LocalBackend, NoiseModel, SimulationOptions

__all__ = ["VQE"]

VQEInput = Union[PauliHamiltonian, QUBOProblemIR, IsingModelIR]


@dataclass(frozen=True)
class VQE:
    """Build and evaluate a hardware-efficient or explicit Circuit ansatz."""

    operator: VQEInput
    layers: int = 1
    ansatz: HardwareEfficientAnsatz | Circuit | None = None
    algorithm_id: str | None = None
    _hamiltonian: PauliHamiltonian = field(init=False, repr=False)
    _built_ansatz: BuiltAnsatz = field(init=False, repr=False)

    def __post_init__(self) -> None:
        if (
            not isinstance(self.layers, int)
            or isinstance(self.layers, bool)
            or self.layers <= 0
        ):
            raise ValueError("layers must be a positive integer.")
        if isinstance(self.operator, PauliHamiltonian):
            hamiltonian = self.operator
        elif isinstance(self.operator, (QUBOProblemIR, IsingModelIR)):
            hamiltonian = problem_to_pauli_hamiltonian(self.operator)
        else:
            raise TypeError(
                "operator must be PauliHamiltonian, QUBOProblemIR, or IsingModelIR."
            )
        algorithm_id = self.algorithm_id or f"vqe.{hamiltonian.hamiltonian_id}"
        if (
            not isinstance(algorithm_id, str)
            or not algorithm_id.strip()
            or algorithm_id != algorithm_id.strip()
        ):
            raise ValueError("algorithm_id must be a non-empty trimmed string.")
        object.__setattr__(self, "algorithm_id", algorithm_id)
        object.__setattr__(self, "_hamiltonian", hamiltonian)
        built = build_vqe_ansatz(
            logical_order=hamiltonian.logical_order,
            layers=self.layers,
            algorithm_id=algorithm_id,
            hamiltonian_hash=hamiltonian.stable_hash(),
            ansatz=self.ansatz,
        )
        object.__setattr__(self, "_built_ansatz", built)
        if isinstance(self.ansatz, Circuit):
            object.__setattr__(self, "ansatz", built.fresh_circuit())

    @property
    def hamiltonian(self) -> PauliHamiltonian:
        """Return the weighted Pauli Hamiltonian evaluated by VQE."""
        return self._hamiltonian

    @property
    def parameter_names(self) -> tuple[str, ...]:
        """Return custom or default ansatz parameters in declaration order."""
        return self._built_ansatz.spec.parameter_names

    def build_circuit(self) -> Circuit:
        """Build a fresh parameterized VQE Circuit."""
        return self._built_ansatz.fresh_circuit()

    def ansatz_spec(self) -> AnsatzSpecIR:
        """Return the stable VQE ansatz declaration."""
        return self._built_ansatz.spec

    def parameter_schema(self) -> ParameterSchemaIR:
        """Return the canonical schema declared by the VQE Circuit."""
        return self._built_ansatz.parameter_schema

    def evaluate(
        self,
        parameters: ParameterValues,
        *,
        backend: LocalBackend | None = None,
        evaluation_index: int = 0,
        algorithm_run_id: str | None = None,
        seed: int | None = None,
        noise: NoiseModel | None = None,
        options: SimulationOptions | None = None,
    ) -> ObjectiveEvaluationIR:
        """通过一个 LocalBackend Job 执行 ideal 或 density-noisy VQE objective。"""
        return execute_objective_evaluation(
            algorithm_kind="vqe",
            algorithm_id=str(self.algorithm_id),
            algorithm_run_id=algorithm_run_id,
            evaluation_index=evaluation_index,
            circuit=self.build_circuit(),
            parameter_names=self.parameter_names,
            parameters=parameters,
            hamiltonian=self.hamiltonian,
            backend=backend,
            seed=seed,
            noise=noise,
            options=options,
        )

    def gradient(
        self,
        parameters: ParameterValues,
        *,
        backend: LocalBackend | None = None,
        gradient_index: int = 0,
        algorithm_run_id: str | None = None,
        seed: int | None = None,
        config: GradientConfig | None = None,
        noise: NoiseModel | None = None,
        options: SimulationOptions | None = None,
    ) -> ObjectiveGradientIR:
        """Execute the exact parameter-shift gradient of one VQE objective."""
        return execute_parameter_shift_gradient(
            algorithm_kind="vqe",
            algorithm_id=str(self.algorithm_id),
            algorithm_run_id=algorithm_run_id,
            gradient_index=gradient_index,
            circuit=self.build_circuit(),
            parameter_names=self.parameter_names,
            parameters=parameters,
            hamiltonian=self.hamiltonian,
            backend=backend,
            seed=seed,
            config=config,
            noise=noise,
            options=options,
        )

    def run(
        self,
        *,
        backend: LocalBackend | None = None,
        optimizer: OptimizerConfig | None = None,
        initial_parameters: ParameterValues | None = None,
        algorithm_run_id: str | None = None,
        final_shots: int = 2048,
        noise: NoiseModel | None = None,
        options: SimulationOptions | None = None,
    ) -> VariationalResult:
        """Optimize VQE and final-sample the minimum observed parameters."""
        return run_variational_optimization(
            algorithm_kind="vqe",
            algorithm_id=str(self.algorithm_id),
            layers=self.layers,
            parameter_names=self.parameter_names,
            hamiltonian=self.hamiltonian,
            ansatz=self.ansatz_spec(),
            evaluator=self.evaluate,
            circuit_builder=self.build_circuit,
            gradient_evaluator=self.gradient,
            problem=(
                self.operator
                if isinstance(self.operator, (QUBOProblemIR, IsingModelIR))
                else None
            ),
            backend=backend,
            optimizer=optimizer,
            initial_parameters=initial_parameters,
            algorithm_run_id=algorithm_run_id,
            final_shots=final_shots,
            noise=noise,
            options=options,
        )
