"""Executable variational algorithm contracts and workflows."""

from cascaqit.algorithms.ansatz import (
    BuiltAnsatz,
    HardwareEfficientAnsatz,
    build_vqe_ansatz,
    transfer_vqe_parameters,
)
from cascaqit.algorithms.gradient import (
    GradientConfig,
    ObjectiveGradientIR,
    ParameterShiftOccurrenceIR,
    ParameterShiftPlanIR,
    ShiftPairEvaluationIR,
    build_parameter_shift_plan,
    execute_parameter_shift_gradient,
)
from cascaqit.algorithms.models import (
    ALGORITHM_SCHEMA_VERSION,
    AlgorithmCandidateIR,
    AnsatzSpecIR,
    ClassicalBaselineIR,
    HamiltonianContributionIR,
    HamiltonianTerm,
    ObjectiveEvaluationIR,
    OptimizationStartIR,
    OptimizerConfig,
    OptimizerTerminationIR,
    PauliHamiltonian,
    VariationalResult,
)
from cascaqit.algorithms.noisy_execution import ObjectiveExecutionEvidenceIR
from cascaqit.algorithms.problem_projection import (
    bounded_exhaustive_baseline,
    decode_problem_candidate,
    evaluate_pauli_hamiltonian_bitstring,
    ising_to_pauli_hamiltonian,
    problem_to_pauli_hamiltonian,
    qubo_to_pauli_hamiltonian,
)
from cascaqit.algorithms.qaoa import QAOA
from cascaqit.algorithms.sampling import select_problem_candidates
from cascaqit.algorithms.vqe import VQE

__all__ = [
    "ALGORITHM_SCHEMA_VERSION",
    "AlgorithmCandidateIR",
    "AnsatzSpecIR",
    "BuiltAnsatz",
    "ClassicalBaselineIR",
    "GradientConfig",
    "HamiltonianContributionIR",
    "HamiltonianTerm",
    "HardwareEfficientAnsatz",
    "ObjectiveEvaluationIR",
    "ObjectiveExecutionEvidenceIR",
    "ObjectiveGradientIR",
    "OptimizationStartIR",
    "OptimizerConfig",
    "OptimizerTerminationIR",
    "PauliHamiltonian",
    "ParameterShiftOccurrenceIR",
    "ParameterShiftPlanIR",
    "QAOA",
    "ShiftPairEvaluationIR",
    "VariationalResult",
    "VQE",
    "bounded_exhaustive_baseline",
    "build_parameter_shift_plan",
    "build_vqe_ansatz",
    "decode_problem_candidate",
    "evaluate_pauli_hamiltonian_bitstring",
    "execute_parameter_shift_gradient",
    "ising_to_pauli_hamiltonian",
    "problem_to_pauli_hamiltonian",
    "qubo_to_pauli_hamiltonian",
    "select_problem_candidates",
    "transfer_vqe_parameters",
]
