"""Shared single-point execution for variational algorithms."""

from __future__ import annotations

import math
from collections.abc import Iterable, Mapping
from typing import Any, Literal, Union

from cascaqit.algorithms.models import (
    HamiltonianContributionIR,
    ObjectiveEvaluationIR,
    PauliHamiltonian,
)
from cascaqit.algorithms.noisy_execution import (
    build_objective_execution_evidence,
    validate_noisy_variational_request,
)
from cascaqit.digital import Circuit
from cascaqit.parameters import ParameterBindIR, ParameterSchemaIR
from cascaqit.simulators import LocalBackend, NoiseModel, SimulationOptions

ParameterValues = Union[Mapping[str, float], Iterable[float]]


def execute_objective_evaluation(
    *,
    algorithm_kind: Literal["qaoa", "vqe"],
    algorithm_id: str,
    algorithm_run_id: str | None,
    evaluation_index: int,
    circuit: Circuit,
    parameter_names: tuple[str, ...],
    parameters: ParameterValues,
    hamiltonian: PauliHamiltonian,
    backend: LocalBackend | None,
    seed: int | None,
    noise: NoiseModel | None = None,
    options: SimulationOptions | None = None,
) -> ObjectiveEvaluationIR:
    """绑定参数，并通过一个 Backend Job 执行 ideal 或 density-noisy objective。"""
    if (
        not isinstance(evaluation_index, int)
        or isinstance(evaluation_index, bool)
        or evaluation_index < 0
    ):
        raise ValueError("evaluation_index must be a non-negative integer.")
    if backend is None:
        backend = LocalBackend(seed=seed)
    elif not isinstance(backend, LocalBackend):
        raise TypeError("backend must be LocalBackend or None.")
    run_id = algorithm_id if algorithm_run_id is None else algorithm_run_id
    if not isinstance(run_id, str) or not run_id.strip() or run_id != run_id.strip():
        raise ValueError("algorithm_run_id must be a non-empty trimmed string.")
    declared_names = tuple(parameter.name for parameter in circuit.parameters)
    if declared_names != parameter_names:
        raise ValueError("Circuit parameter order must match the ansatz declaration.")

    values = normalize_parameter_values(parameters, parameter_names)
    # ResultIR ids are derived from the executed program id. A unique execution
    # snapshot prevents repeated optimizer callbacks from collapsing onto the
    # same Result identity while preserving the ansatz gates and Parameters.
    execution_circuit = Circuit(
        circuit.qubits,
        program_id=f"program.{run_id}.evaluation.{evaluation_index:06d}",
        metadata={
            "ansatz_program_id": circuit.program_id,
            "algorithm_run_id": run_id,
            "evaluation_index": evaluation_index,
        },
    ).compose(circuit)
    planned_noisy_execution = None
    if noise is not None:
        # 预检在 bind 和 Backend 提交前完成。它既阻止 trajectory/readout-only
        # 语义，也冻结真实执行必须复现的 density SimulationPlan。
        planned_noisy_execution = validate_noisy_variational_request(
            execution_circuit,
            noise=noise,
            options=options,
            backend=backend,
            seed=seed,
        )
    schema = ParameterSchemaIR.from_parameters(execution_circuit.parameters)
    parameter_bind = ParameterBindIR.create(
        parameter_bind_id=f"{run_id}.bind.{evaluation_index:06d}",
        parameter_schema=schema,
        values=values,
        metadata={
            "algorithm": algorithm_kind,
            "algorithm_id": algorithm_id,
            "evaluation_index": evaluation_index,
        },
    )
    bound = execution_circuit.bind(values)
    job = backend.run(
        bound,
        # 物理噪声路径会把 Circuit 包装成带终端测量的 HybridProgram，运行时
        # 要求正 shots。这个单 shot 只满足生命周期契约；能量仍来自测量前的
        # exact-density Observable，不读取 count。
        shots=1 if noise is not None else 0,
        seed=seed,
        job_id=f"{run_id}.evaluation.{evaluation_index:06d}",
        observables=hamiltonian.observable_set(),
        noise=noise,
        options=options,
    )
    result = job.result()
    batch = result.observable_batch
    if batch is None:
        raise RuntimeError(
            "Variational objective execution did not return Observable evidence."
        )
    contributions = tuple(
        HamiltonianContributionIR(
            term_id=term.term_id,
            observable_name=term.observable.name,
            coefficient=term.coefficient,
            expectation=item.expectation,
            contribution=term.coefficient * item.expectation,
        )
        for term, item in zip(hamiltonian.terms, batch.items)
    )
    energy = hamiltonian.constant + sum(item.contribution for item in contributions)
    usage = result.resource_usage()
    wall_time = 0.0 if usage is None else usage.wall_time_seconds
    status = job.status()
    execution_evidence = build_objective_execution_evidence(
        result=result,
        observable_batch=batch,
        noise=noise,
        options=options,
        requested_seed=seed,
        backend_id=status.backend_id,
        backend_job_id=status.job_id,
    )
    if (
        planned_noisy_execution is not None
        and execution_evidence.simulation_plan.stable_hash()
        != planned_noisy_execution.stable_hash()
    ):
        raise RuntimeError(
            "Noisy objective SimulationPlan changed between preflight and execution."
        )
    return ObjectiveEvaluationIR(
        evaluation_id=f"{run_id}.evaluation.{evaluation_index:06d}",
        evaluation_index=evaluation_index,
        parameter_bind=parameter_bind,
        hamiltonian_hash=hamiltonian.stable_hash(),
        constant=hamiltonian.constant,
        contributions=contributions,
        energy=energy,
        observable_batch=batch,
        execution_evidence=execution_evidence,
        result_id=result.result_id,
        result_hash=result.stable_hash(),
        wall_time_seconds=wall_time,
        cache_hit=False,
        metadata={
            "algorithm": algorithm_kind,
            "algorithm_id": algorithm_id,
            "algorithm_run_id": run_id,
            "backend_id": status.backend_id,
            "backend_job_id": status.job_id,
            "backend_execution_count": status.execution_count,
            "program_hash": result.program_hash,
            "ansatz_program_id": circuit.program_id,
            "execution_program_id": execution_circuit.program_id,
            "observable_set_hash": batch.observable_set_hash,
            "observable_source_hash": batch.source_hash,
            "estimator": execution_evidence.estimator_kind.value,
            "execution_evidence_hash": execution_evidence.evidence_hash,
            "noise_model_hash": (
                None if noise is None else noise.stable_hash()
            ),
        },
    )


def normalize_parameter_values(
    parameters: ParameterValues,
    names: tuple[str, ...],
) -> dict[str, float]:
    """Normalize mapping or iterable values into stable ansatz order."""
    if isinstance(parameters, Mapping):
        values: dict[str, Any] = {
            str(name): value for name, value in parameters.items()
        }
        if set(values) != set(names):
            missing = sorted(set(names) - set(values))
            unknown = sorted(set(values) - set(names))
            raise ValueError(
                "Parameter names do not match the ansatz; "
                f"missing={missing}, unknown={unknown}."
            )
        ordered = {name: values[name] for name in names}
    else:
        if isinstance(parameters, (str, bytes)):
            raise TypeError("parameters must be a mapping or numeric iterable.")
        try:
            sequence = tuple(parameters)
        except TypeError as exc:
            raise TypeError(
                "parameters must be a mapping or numeric iterable."
            ) from exc
        if len(sequence) != len(names):
            raise ValueError(
                f"Ansatz requires {len(names)} parameters, got {len(sequence)}."
            )
        ordered = dict(zip(names, sequence))
    normalized: dict[str, float] = {}
    for name, value in ordered.items():
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            raise TypeError(f"Parameter '{name}' must be a real number.")
        number = float(value)
        if not math.isfinite(number):
            raise ValueError(f"Parameter '{name}' must be finite.")
        normalized[name] = number
    return normalized
