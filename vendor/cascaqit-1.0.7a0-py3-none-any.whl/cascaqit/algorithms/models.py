"""Typed contracts for executable variational algorithm workflows."""

from __future__ import annotations

import json
import math
import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import TYPE_CHECKING, Any, Literal

from cascaqit.native_ir.base import IRMixin
from cascaqit.observables import Observable, ObservableBatchResultIR, ObservableSet
from cascaqit.parameters import ParameterBindIR
from cascaqit.results import ResultIR

if TYPE_CHECKING:
    from cascaqit.algorithms.gradient import (
        GradientConfig,
        ObjectiveGradientIR,
        ParameterShiftPlanIR,
    )
    from cascaqit.algorithms.noisy_execution import ObjectiveExecutionEvidenceIR

__all__ = [
    "ALGORITHM_SCHEMA_VERSION",
    "AlgorithmCandidateIR",
    "AnsatzSpecIR",
    "ClassicalBaselineIR",
    "HamiltonianContributionIR",
    "HamiltonianTerm",
    "ObjectiveEvaluationIR",
    "OptimizationStartIR",
    "OptimizerConfig",
    "OptimizerTerminationIR",
    "PauliHamiltonian",
    "VariationalResult",
]

ALGORITHM_SCHEMA_VERSION = "cascaqit.algorithms.v3"
AlgorithmKind = Literal["qaoa", "vqe"]
LayerTransferKind = Literal["append_last_layer", "unsupported"]
OptimizerMethod = Literal["COBYLA", "Nelder-Mead", "Powell", "L-BFGS-B"]
InitializationStrategy = Literal["random", "layerwise"]
BaselineStatus = Literal["available", "unavailable"]
_DIGEST_PATTERN = re.compile(r"[0-9a-f]{64}")
_ENERGY_TOLERANCE = 1e-12
_OPTIMIZER_METHODS = frozenset({"COBYLA", "Nelder-Mead", "Powell", "L-BFGS-B"})
_MANAGED_SCIPY_OPTIONS = frozenset({"maxiter", "maxfev", "maxfun"})
_ALGORITHM_KINDS = frozenset({"qaoa", "vqe"})


@dataclass(frozen=True)
class HamiltonianTerm(IRMixin):
    """One non-zero weighted Pauli product in a Hamiltonian."""

    term_id: str
    coefficient: float
    observable: Observable
    schema_version: str = ALGORITHM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_text(self.term_id, "term_id")
        object.__setattr__(
            self,
            "coefficient",
            _finite_float(self.coefficient, "coefficient"),
        )
        if self.coefficient == 0.0:
            raise ValueError("Hamiltonian term coefficient must be non-zero.")
        if not isinstance(self.observable, Observable):
            raise TypeError("observable must be Observable.")

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> HamiltonianTerm:
        """Build a Hamiltonian term from JSON-compatible data."""
        return cls(
            term_id=data["term_id"],
            coefficient=data["coefficient"],
            observable=Observable.from_dict(_mapping(data["observable"], "observable")),
            schema_version=str(data.get("schema_version", ALGORITHM_SCHEMA_VERSION)),
        )


@dataclass(frozen=True)
class PauliHamiltonian(IRMixin):
    """An ordered weighted sum evaluated through one ObservableSet batch."""

    hamiltonian_id: str
    terms: tuple[HamiltonianTerm, ...]
    constant: float = 0.0
    logical_order: tuple[str, ...] = ()
    source_problem_id: str | None = None
    source_problem_hash: str | None = None
    metadata: Mapping[str, Any] = field(default_factory=dict)
    schema_version: str = ALGORITHM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_text(self.hamiltonian_id, "hamiltonian_id")
        if not isinstance(self.terms, tuple):
            object.__setattr__(self, "terms", tuple(self.terms))
        if not self.terms:
            raise ValueError("PauliHamiltonian terms must not be empty.")
        if any(not isinstance(term, HamiltonianTerm) for term in self.terms):
            raise TypeError("terms must contain HamiltonianTerm values.")
        term_ids = tuple(term.term_id for term in self.terms)
        if len(term_ids) != len(set(term_ids)):
            raise ValueError("Hamiltonian term_id values must be unique.")
        observable_names = tuple(term.observable.name for term in self.terms)
        if len(observable_names) != len(set(observable_names)):
            raise ValueError("Hamiltonian observable names must be unique.")
        observable_hashes = tuple(term.observable.stable_hash() for term in self.terms)
        if len(observable_hashes) != len(set(observable_hashes)):
            raise ValueError(
                "Hamiltonian Pauli products must be normalized and unique."
            )
        object.__setattr__(self, "constant", _finite_float(self.constant, "constant"))
        object.__setattr__(self, "logical_order", tuple(self.logical_order))
        _require_unique_text(self.logical_order, "logical_order", allow_empty=False)
        targets = {target for term in self.terms for target in term.observable.targets}
        if self.logical_order and not targets.issubset(set(self.logical_order)):
            raise ValueError("Hamiltonian terms contain targets outside logical_order.")
        if (self.source_problem_id is None) != (self.source_problem_hash is None):
            raise ValueError(
                "source_problem_id and source_problem_hash must be provided together."
            )
        if self.source_problem_id is not None:
            _require_text(self.source_problem_id, "source_problem_id")
            _require_digest(self.source_problem_hash, "source_problem_hash")
        object.__setattr__(self, "metadata", _freeze_mapping(self.metadata))

    def observable_set(self) -> ObservableSet:
        """Return the one ordered batch declaration for all weighted terms."""
        return ObservableSet(term.observable for term in self.terms)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> PauliHamiltonian:
        """Build a Hamiltonian from JSON-compatible data."""
        raw_terms = data.get("terms", ())
        if not isinstance(raw_terms, (list, tuple)):
            raise TypeError("Hamiltonian terms must be an array.")
        raw_order = data.get("logical_order", ())
        if not isinstance(raw_order, (list, tuple)):
            raise TypeError("logical_order must be an array.")
        return cls(
            hamiltonian_id=data["hamiltonian_id"],
            terms=tuple(
                HamiltonianTerm.from_dict(_mapping(item, "term")) for item in raw_terms
            ),
            constant=data.get("constant", 0.0),
            logical_order=tuple(raw_order),
            source_problem_id=data.get("source_problem_id"),
            source_problem_hash=data.get("source_problem_hash"),
            metadata=_mapping(data.get("metadata", {}), "metadata"),
            schema_version=str(data.get("schema_version", ALGORITHM_SCHEMA_VERSION)),
        )

    @classmethod
    def from_json(cls, text: str) -> PauliHamiltonian:
        """Build a Hamiltonian from JSON text."""
        return cls.from_dict(_json_object(text, "PauliHamiltonian"))


@dataclass(frozen=True)
class OptimizerConfig(IRMixin):
    """Deterministic configuration accepted by the executable SciPy adapter."""

    method: OptimizerMethod = "COBYLA"
    max_iterations: int = 80
    max_evaluations: int | None = None
    max_backend_executions: int | None = None
    starts: int = 1
    initialization: InitializationStrategy = "random"
    tolerance: float = 1e-6
    seed: int | None = None
    bounds: tuple[tuple[float, float], ...] = ()
    options: Mapping[str, bool | int | float] = field(default_factory=dict)
    gradient: GradientConfig | None = None
    schema_version: str = ALGORITHM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.method not in _OPTIMIZER_METHODS:
            raise ValueError(f"Unsupported optimizer method: {self.method!r}.")
        _require_positive_int(self.max_iterations, "max_iterations")
        if self.max_evaluations is not None:
            _require_positive_int(self.max_evaluations, "max_evaluations")
        if self.max_backend_executions is not None:
            _require_positive_int(
                self.max_backend_executions,
                "max_backend_executions",
            )
        _require_positive_int(self.starts, "starts")
        if self.initialization not in {"random", "layerwise"}:
            raise ValueError(
                f"Unsupported initialization strategy: {self.initialization!r}."
            )
        tolerance = _finite_float(self.tolerance, "tolerance")
        if tolerance <= 0.0:
            raise ValueError("tolerance must be positive.")
        object.__setattr__(self, "tolerance", tolerance)
        if self.seed is not None and (
            not isinstance(self.seed, int)
            or isinstance(self.seed, bool)
            or self.seed < 0
        ):
            raise ValueError("seed must be a non-negative integer or None.")
        if not isinstance(self.bounds, tuple):
            object.__setattr__(self, "bounds", tuple(self.bounds))
        normalized_bounds: list[tuple[float, float]] = []
        for index, bound in enumerate(self.bounds):
            if not isinstance(bound, (list, tuple)) or len(bound) != 2:
                raise TypeError(f"bounds[{index}] must contain lower and upper values.")
            lower = _finite_float(bound[0], f"bounds[{index}].lower")
            upper = _finite_float(bound[1], f"bounds[{index}].upper")
            if lower >= upper:
                raise ValueError(f"bounds[{index}] lower must be less than upper.")
            normalized_bounds.append((lower, upper))
        object.__setattr__(self, "bounds", tuple(normalized_bounds))
        normalized_options: dict[str, bool | int | float] = {}
        for name, value in self.options.items():
            _require_text(name, "option name")
            if name in _MANAGED_SCIPY_OPTIONS:
                raise ValueError(
                    f"options[{name}] is managed by max_iterations or max_evaluations."
                )
            if isinstance(value, (bool, int)):
                normalized_options[name] = value
            else:
                normalized_options[name] = _finite_float(value, f"options[{name}]")
        object.__setattr__(self, "options", MappingProxyType(normalized_options))
        from cascaqit.algorithms.gradient import GradientConfig

        if self.method == "L-BFGS-B":
            if not isinstance(self.gradient, GradientConfig):
                raise ValueError("L-BFGS-B requires a GradientConfig.")
        elif self.gradient is not None:
            raise ValueError(f"{self.method} does not accept a gradient configuration.")

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> OptimizerConfig:
        """Build optimizer configuration from JSON-compatible data."""
        from cascaqit.algorithms.gradient import GradientConfig

        raw_bounds = data.get("bounds", ())
        if not isinstance(raw_bounds, (list, tuple)):
            raise TypeError("bounds must be an array.")
        return cls(
            method=data.get("method", "COBYLA"),
            max_iterations=data.get("max_iterations", 80),
            max_evaluations=data.get("max_evaluations"),
            max_backend_executions=data.get("max_backend_executions"),
            starts=data.get("starts", 1),
            initialization=data.get("initialization", "random"),
            tolerance=data.get("tolerance", 1e-6),
            seed=data.get("seed"),
            bounds=tuple(raw_bounds),
            options=_mapping(data.get("options", {}), "options"),
            gradient=(
                None
                if data.get("gradient") is None
                else GradientConfig.from_dict(_mapping(data["gradient"], "gradient"))
            ),
            schema_version=str(data.get("schema_version", ALGORITHM_SCHEMA_VERSION)),
        )

    @classmethod
    def from_json(cls, text: str) -> OptimizerConfig:
        """Build optimizer configuration from JSON text."""
        return cls.from_dict(_json_object(text, "OptimizerConfig"))


@dataclass(frozen=True)
class AnsatzSpecIR(IRMixin):
    """Stable parameter and qubit layout of one variational ansatz."""

    ansatz_id: str
    ansatz_kind: Literal["qaoa", "hardware_efficient", "custom"]
    layers: int
    logical_order: tuple[str, ...]
    parameter_names: tuple[str, ...]
    circuit_hash: str | None = None
    definition: Mapping[str, Any] = field(default_factory=dict)
    required_gates: tuple[str, ...] = ()
    layer_transfer: LayerTransferKind = "unsupported"
    metadata: Mapping[str, Any] = field(default_factory=dict)
    schema_version: str = ALGORITHM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_text(self.ansatz_id, "ansatz_id")
        if self.ansatz_kind not in {"qaoa", "hardware_efficient", "custom"}:
            raise ValueError(f"Unsupported ansatz_kind: {self.ansatz_kind!r}.")
        _require_positive_int(self.layers, "layers")
        object.__setattr__(self, "logical_order", tuple(self.logical_order))
        object.__setattr__(self, "parameter_names", tuple(self.parameter_names))
        _require_unique_text(self.logical_order, "logical_order", allow_empty=False)
        _require_unique_text(self.parameter_names, "parameter_names", allow_empty=False)
        if self.circuit_hash is not None:
            _require_digest(self.circuit_hash, "circuit_hash")
        object.__setattr__(self, "definition", _freeze_mapping(self.definition))
        object.__setattr__(self, "required_gates", tuple(self.required_gates))
        _require_unique_text(self.required_gates, "required_gates", allow_empty=True)
        if self.layer_transfer not in {"append_last_layer", "unsupported"}:
            raise ValueError(
                f"Unsupported layer_transfer: {self.layer_transfer!r}."
            )
        if self.ansatz_kind == "custom" and self.layer_transfer != "unsupported":
            raise ValueError("Custom ansatz layer transfer must be unsupported.")
        object.__setattr__(self, "metadata", _freeze_mapping(self.metadata))

    @property
    def spec_hash(self) -> str:
        """Return the stable hash of all declared ansatz facts."""
        return self.stable_hash()

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> AnsatzSpecIR:
        """Build an ansatz specification from JSON-compatible data."""
        return cls(
            ansatz_id=data["ansatz_id"],
            ansatz_kind=data["ansatz_kind"],
            layers=data["layers"],
            logical_order=tuple(_sequence(data["logical_order"], "logical_order")),
            parameter_names=tuple(
                _sequence(data["parameter_names"], "parameter_names")
            ),
            circuit_hash=data.get("circuit_hash"),
            definition=_mapping(data.get("definition", {}), "definition"),
            required_gates=tuple(
                _sequence(data.get("required_gates", ()), "required_gates")
            ),
            layer_transfer=data.get("layer_transfer", "unsupported"),
            metadata=_mapping(data.get("metadata", {}), "metadata"),
            schema_version=str(data.get("schema_version", ALGORITHM_SCHEMA_VERSION)),
        )


@dataclass(frozen=True)
class HamiltonianContributionIR(IRMixin):
    """Auditable weighted contribution from one Observable batch item."""

    term_id: str
    observable_name: str
    coefficient: float
    expectation: float
    contribution: float
    schema_version: str = ALGORITHM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_text(self.term_id, "term_id")
        _require_text(self.observable_name, "observable_name")
        coefficient = _finite_float(self.coefficient, "coefficient")
        expectation = _finite_float(self.expectation, "expectation")
        contribution = _finite_float(self.contribution, "contribution")
        if not -1.0 - _ENERGY_TOLERANCE <= expectation <= 1.0 + _ENERGY_TOLERANCE:
            raise ValueError("expectation must be within the Pauli range [-1, 1].")
        if not math.isclose(
            contribution,
            coefficient * expectation,
            rel_tol=0.0,
            abs_tol=_ENERGY_TOLERANCE,
        ):
            raise ValueError("contribution must equal coefficient * expectation.")
        object.__setattr__(self, "coefficient", coefficient)
        object.__setattr__(self, "expectation", expectation)
        object.__setattr__(self, "contribution", contribution)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> HamiltonianContributionIR:
        """Build one contribution from JSON-compatible data."""
        return cls(
            term_id=data["term_id"],
            observable_name=data["observable_name"],
            coefficient=data["coefficient"],
            expectation=data["expectation"],
            contribution=data["contribution"],
            schema_version=str(data.get("schema_version", ALGORITHM_SCHEMA_VERSION)),
        )


@dataclass(frozen=True)
class ObjectiveEvaluationIR(IRMixin):
    """One real Backend objective evaluation and its weighted evidence."""

    evaluation_id: str
    evaluation_index: int
    parameter_bind: ParameterBindIR
    hamiltonian_hash: str
    constant: float
    contributions: tuple[HamiltonianContributionIR, ...]
    energy: float
    observable_batch: ObservableBatchResultIR
    execution_evidence: ObjectiveExecutionEvidenceIR
    result_id: str
    result_hash: str
    wall_time_seconds: float
    cache_hit: bool = False
    metadata: Mapping[str, Any] = field(default_factory=dict)
    schema_version: str = ALGORITHM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_text(self.evaluation_id, "evaluation_id")
        if (
            not isinstance(self.evaluation_index, int)
            or isinstance(self.evaluation_index, bool)
            or self.evaluation_index < 0
        ):
            raise ValueError("evaluation_index must be a non-negative integer.")
        if not isinstance(self.parameter_bind, ParameterBindIR):
            raise TypeError("parameter_bind must be ParameterBindIR.")
        if not self.parameter_bind.verify_hash():
            raise ValueError("parameter_bind_hash does not match parameter values.")
        _require_digest(self.hamiltonian_hash, "hamiltonian_hash")
        constant = _finite_float(self.constant, "constant")
        if not isinstance(self.contributions, tuple):
            object.__setattr__(self, "contributions", tuple(self.contributions))
        if not self.contributions:
            raise ValueError("contributions must not be empty.")
        if any(
            not isinstance(item, HamiltonianContributionIR)
            for item in self.contributions
        ):
            raise TypeError("contributions must contain HamiltonianContributionIR.")
        term_ids = tuple(item.term_id for item in self.contributions)
        if len(term_ids) != len(set(term_ids)):
            raise ValueError("contribution term_id values must be unique.")
        if not isinstance(self.observable_batch, ObservableBatchResultIR):
            raise TypeError("observable_batch must be ObservableBatchResultIR.")
        from cascaqit.algorithms.noisy_execution import ObjectiveExecutionEvidenceIR

        if not isinstance(self.execution_evidence, ObjectiveExecutionEvidenceIR):
            raise TypeError(
                "execution_evidence must be ObjectiveExecutionEvidenceIR."
            )
        contribution_names = tuple(item.observable_name for item in self.contributions)
        batch_names = tuple(item.name for item in self.observable_batch.items)
        if contribution_names != batch_names:
            raise ValueError(
                "contributions must match Observable batch declaration order."
            )
        for contribution, observed in zip(
            self.contributions,
            self.observable_batch.items,
        ):
            if not math.isclose(
                contribution.expectation,
                observed.expectation,
                rel_tol=0.0,
                abs_tol=_ENERGY_TOLERANCE,
            ):
                raise ValueError(
                    "contribution expectation must match Observable batch evidence."
                )
        energy = _finite_float(self.energy, "energy")
        reconstructed = constant + sum(item.contribution for item in self.contributions)
        if not math.isclose(
            energy,
            reconstructed,
            rel_tol=0.0,
            abs_tol=_ENERGY_TOLERANCE,
        ):
            raise ValueError("energy must equal constant plus weighted contributions.")
        _require_text(self.result_id, "result_id")
        _require_digest(self.result_hash, "result_hash")
        if self.execution_evidence.result_id != self.result_id:
            raise ValueError("execution evidence result_id must match evaluation.")
        if self.execution_evidence.result_hash != self.result_hash:
            raise ValueError("execution evidence result_hash must match evaluation.")
        if self.execution_evidence.estimator_kind != self.observable_batch.items[
            0
        ].estimator_kind:
            raise ValueError(
                "execution evidence estimator must match Observable batch."
            )
        if self.execution_evidence.source_kind != self.observable_batch.source_kind:
            raise ValueError("execution evidence source must match Observable batch.")
        batch_sample_counts = {
            item.sample_count for item in self.observable_batch.items
        }
        if batch_sample_counts != {self.execution_evidence.sample_count}:
            raise ValueError(
                "execution evidence sample_count must match Observable batch."
            )
        batch_errors = {
            item.name: item.standard_error for item in self.observable_batch.items
        }
        if dict(self.execution_evidence.observable_standard_errors) != batch_errors:
            raise ValueError(
                "execution evidence standard errors must match Observable batch."
            )
        wall = _finite_float(self.wall_time_seconds, "wall_time_seconds")
        if wall < 0.0:
            raise ValueError("wall_time_seconds must be non-negative.")
        if self.cache_hit is not False:
            raise ValueError("a21 objective evaluations must not be cached.")
        object.__setattr__(self, "constant", constant)
        object.__setattr__(self, "energy", energy)
        object.__setattr__(self, "wall_time_seconds", wall)
        object.__setattr__(self, "metadata", _freeze_mapping(self.metadata))

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ObjectiveEvaluationIR:
        """Build one objective evaluation from JSON-compatible data."""
        raw_contributions = data.get("contributions", ())
        if not isinstance(raw_contributions, (list, tuple)):
            raise TypeError("contributions must be an array.")
        return cls(
            evaluation_id=data["evaluation_id"],
            evaluation_index=data["evaluation_index"],
            parameter_bind=ParameterBindIR.from_dict(
                _mapping(data["parameter_bind"], "parameter_bind")
            ),
            hamiltonian_hash=data["hamiltonian_hash"],
            constant=data["constant"],
            contributions=tuple(
                HamiltonianContributionIR.from_dict(_mapping(item, "contribution"))
                for item in raw_contributions
            ),
            energy=data["energy"],
            observable_batch=ObservableBatchResultIR.from_dict(
                _mapping(data["observable_batch"], "observable_batch")
            ),
            execution_evidence=_objective_execution_evidence_from_dict(
                _mapping(data["execution_evidence"], "execution_evidence")
            ),
            result_id=data["result_id"],
            result_hash=data["result_hash"],
            wall_time_seconds=data["wall_time_seconds"],
            cache_hit=data.get("cache_hit", False),
            metadata=_mapping(data.get("metadata", {}), "metadata"),
            schema_version=str(data.get("schema_version", ALGORITHM_SCHEMA_VERSION)),
        )


def _objective_execution_evidence_from_dict(
    data: Mapping[str, Any],
) -> ObjectiveExecutionEvidenceIR:
    from cascaqit.algorithms.noisy_execution import ObjectiveExecutionEvidenceIR

    return ObjectiveExecutionEvidenceIR.from_dict(data)


@dataclass(frozen=True)
class OptimizerTerminationIR(IRMixin):
    """Optimizer termination facts plus a stable CASCAQit reason."""

    method: OptimizerMethod
    success: bool
    status: int
    message: str
    nfev: int
    nit: int | None
    reason: Literal[
        "completed",
        "max_iterations",
        "max_evaluations",
        "max_gradient_evaluations",
        "max_backend_executions",
        "failed",
    ]
    njev: int = 0
    backend_execution_count: int | None = None
    schema_version: str = ALGORITHM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.method not in _OPTIMIZER_METHODS:
            raise ValueError(f"Unsupported optimizer method: {self.method!r}.")
        if not isinstance(self.success, bool):
            raise TypeError("success must be bool.")
        if not isinstance(self.status, int) or isinstance(self.status, bool):
            raise TypeError("status must be int.")
        _require_text(self.message, "message")
        _require_positive_int(self.nfev, "nfev")
        _require_non_negative_int(self.njev, "njev")
        if self.nit is not None and (
            not isinstance(self.nit, int) or isinstance(self.nit, bool) or self.nit < 0
        ):
            raise ValueError("nit must be a non-negative integer or None.")
        if self.reason not in {
            "completed",
            "max_iterations",
            "max_evaluations",
            "max_gradient_evaluations",
            "max_backend_executions",
            "failed",
        }:
            raise ValueError(f"Unsupported termination reason: {self.reason!r}.")
        if self.success != (self.reason == "completed"):
            raise ValueError("success is true exactly when reason is completed.")
        backend_count = (
            self.nfev
            if self.backend_execution_count is None
            else self.backend_execution_count
        )
        _require_positive_int(backend_count, "backend_execution_count")
        if backend_count < self.nfev:
            raise ValueError("backend_execution_count must not be less than nfev.")
        object.__setattr__(self, "backend_execution_count", backend_count)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> OptimizerTerminationIR:
        """Build termination evidence from JSON-compatible data."""
        return cls(
            method=data["method"],
            success=data["success"],
            status=data["status"],
            message=data["message"],
            nfev=data["nfev"],
            nit=data.get("nit"),
            reason=data["reason"],
            njev=data.get("njev", 0),
            backend_execution_count=data.get("backend_execution_count"),
            schema_version=str(data.get("schema_version", ALGORITHM_SCHEMA_VERSION)),
        )


@dataclass(frozen=True)
class OptimizationStartIR(IRMixin):
    """One optimizer start and the exact slice of evaluations it owns."""

    start_index: int
    seed: int
    initialization: Literal["random", "explicit", "layerwise", "schema_default"]
    evaluation_start_index: int
    evaluation_count: int
    best_evaluation_index: int
    initial_parameters: Mapping[str, float]
    final_parameters: Mapping[str, float]
    final_objective: float
    best_objective: float
    termination: OptimizerTerminationIR
    gradient_start_index: int = 0
    gradient_count: int = 0
    backend_execution_count: int | None = None
    schema_version: str = ALGORITHM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_non_negative_int(self.start_index, "start_index")
        _require_non_negative_int(self.seed, "seed")
        if self.initialization not in {
            "random",
            "explicit",
            "layerwise",
            "schema_default",
        }:
            raise ValueError(
                f"Unsupported start initialization: {self.initialization!r}."
            )
        _require_non_negative_int(
            self.evaluation_start_index,
            "evaluation_start_index",
        )
        _require_positive_int(self.evaluation_count, "evaluation_count")
        if (
            not isinstance(self.best_evaluation_index, int)
            or isinstance(self.best_evaluation_index, bool)
            or not self.evaluation_start_index
            <= self.best_evaluation_index
            < self.evaluation_start_index + self.evaluation_count
        ):
            raise ValueError(
                "best_evaluation_index must belong to this optimization start."
            )
        initial = _finite_parameter_mapping(
            self.initial_parameters,
            "initial_parameters",
        )
        final = _finite_parameter_mapping(
            self.final_parameters,
            "final_parameters",
        )
        if not initial or initial.keys() != final.keys():
            raise ValueError(
                "initial_parameters and final_parameters must share non-empty keys."
            )
        object.__setattr__(self, "initial_parameters", initial)
        object.__setattr__(self, "final_parameters", final)
        object.__setattr__(
            self,
            "final_objective",
            _finite_float(self.final_objective, "final_objective"),
        )
        object.__setattr__(
            self,
            "best_objective",
            _finite_float(self.best_objective, "best_objective"),
        )
        if not isinstance(self.termination, OptimizerTerminationIR):
            raise TypeError("termination must be OptimizerTerminationIR.")
        if self.termination.nfev != self.evaluation_count:
            raise ValueError("termination nfev must match evaluation_count.")
        _require_non_negative_int(self.gradient_start_index, "gradient_start_index")
        _require_non_negative_int(self.gradient_count, "gradient_count")
        if self.termination.njev != self.gradient_count:
            raise ValueError("termination njev must match gradient_count.")
        backend_count = (
            self.termination.backend_execution_count
            if self.backend_execution_count is None
            else self.backend_execution_count
        )
        assert backend_count is not None
        _require_positive_int(backend_count, "backend_execution_count")
        if backend_count != self.termination.backend_execution_count:
            raise ValueError(
                "start backend_execution_count must match termination evidence."
            )
        object.__setattr__(self, "backend_execution_count", backend_count)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> OptimizationStartIR:
        """Restore one optimizer-start summary from JSON-compatible data."""
        return cls(
            start_index=data["start_index"],
            seed=data["seed"],
            initialization=data["initialization"],
            evaluation_start_index=data["evaluation_start_index"],
            evaluation_count=data["evaluation_count"],
            best_evaluation_index=data["best_evaluation_index"],
            initial_parameters=_mapping(
                data["initial_parameters"], "initial_parameters"
            ),
            final_parameters=_mapping(data["final_parameters"], "final_parameters"),
            final_objective=data["final_objective"],
            best_objective=data["best_objective"],
            termination=OptimizerTerminationIR.from_dict(
                _mapping(data["termination"], "termination")
            ),
            gradient_start_index=data.get("gradient_start_index", 0),
            gradient_count=data.get("gradient_count", 0),
            backend_execution_count=data.get("backend_execution_count"),
            schema_version=str(data.get("schema_version", ALGORITHM_SCHEMA_VERSION)),
        )


@dataclass(frozen=True)
class AlgorithmCandidateIR(IRMixin):
    """One sampled problem candidate without an optimality claim."""

    bitstring: str
    objective_value: float
    probability: float | None
    count: int | None
    feasible: bool | None
    decoded: Mapping[str, Any] = field(default_factory=dict)
    optimality_claim: Literal["not_claimed"] = "not_claimed"
    schema_version: str = ALGORITHM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if not self.bitstring or set(self.bitstring) - {"0", "1"}:
            raise ValueError("bitstring must contain only 0 and 1.")
        object.__setattr__(
            self,
            "objective_value",
            _finite_float(self.objective_value, "objective_value"),
        )
        if self.probability is not None:
            probability = _finite_float(self.probability, "probability")
            if not 0.0 <= probability <= 1.0:
                raise ValueError("probability must be within [0, 1].")
            object.__setattr__(self, "probability", probability)
        if self.count is not None and (
            not isinstance(self.count, int)
            or isinstance(self.count, bool)
            or self.count < 0
        ):
            raise ValueError("count must be a non-negative integer or None.")
        if self.feasible is not None and not isinstance(self.feasible, bool):
            raise TypeError("feasible must be bool or None.")
        if self.optimality_claim != "not_claimed":
            raise ValueError("Algorithm candidates cannot claim optimality.")
        object.__setattr__(self, "decoded", _freeze_mapping(self.decoded))

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> AlgorithmCandidateIR:
        """Build a sampled candidate from JSON-compatible data."""
        return cls(
            bitstring=data["bitstring"],
            objective_value=data["objective_value"],
            probability=data.get("probability"),
            count=data.get("count"),
            feasible=data.get("feasible"),
            decoded=_mapping(data.get("decoded", {}), "decoded"),
            optimality_claim=data.get("optimality_claim", "not_claimed"),
            schema_version=str(data.get("schema_version", ALGORITHM_SCHEMA_VERSION)),
        )


@dataclass(frozen=True)
class ClassicalBaselineIR(IRMixin):
    """Bounded classical reference, or an explicit unavailable reason."""

    status: BaselineStatus
    method: Literal["bounded_exhaustive"]
    variable_count: int
    limit: int
    objective_value: float | None = None
    bitstring: str | None = None
    unavailable_reason: str | None = None
    schema_version: str = ALGORITHM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.status not in {"available", "unavailable"}:
            raise ValueError(f"Unsupported baseline status: {self.status!r}.")
        if self.method != "bounded_exhaustive":
            raise ValueError("method must be bounded_exhaustive.")
        _require_non_negative_int(self.variable_count, "variable_count")
        _require_positive_int(self.limit, "limit")
        if self.status == "available":
            if self.variable_count > self.limit:
                raise ValueError("available baseline cannot exceed its variable limit.")
            if self.objective_value is None or self.bitstring is None:
                raise ValueError("available baseline requires objective and bitstring.")
            object.__setattr__(
                self,
                "objective_value",
                _finite_float(self.objective_value, "objective_value"),
            )
            if len(self.bitstring) != self.variable_count or set(self.bitstring) - {
                "0",
                "1",
            }:
                raise ValueError("baseline bitstring must match variable_count.")
            if self.unavailable_reason is not None:
                raise ValueError("available baseline cannot have unavailable_reason.")
        else:
            if self.objective_value is not None or self.bitstring is not None:
                raise ValueError("unavailable baseline cannot contain a solution.")
            _require_text(self.unavailable_reason, "unavailable_reason")

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ClassicalBaselineIR:
        """Build baseline evidence from JSON-compatible data."""
        return cls(
            status=data["status"],
            method=data["method"],
            variable_count=data["variable_count"],
            limit=data["limit"],
            objective_value=data.get("objective_value"),
            bitstring=data.get("bitstring"),
            unavailable_reason=data.get("unavailable_reason"),
            schema_version=str(data.get("schema_version", ALGORITHM_SCHEMA_VERSION)),
        )


@dataclass(frozen=True)
class VariationalResult(IRMixin):
    """Workflow result that references, but never replaces, Backend ResultIR facts."""

    algorithm_run_id: str
    algorithm_kind: AlgorithmKind
    hamiltonian: PauliHamiltonian
    ansatz: AnsatzSpecIR
    optimizer: OptimizerConfig
    evaluations: tuple[ObjectiveEvaluationIR, ...]
    best_evaluation_index: int
    termination: OptimizerTerminationIR
    gradients: tuple[ObjectiveGradientIR, ...] = ()
    optimization_starts: tuple[OptimizationStartIR, ...] = ()
    selected_start_index: int | None = None
    final_result: ResultIR | None = None
    most_probable_candidate: AlgorithmCandidateIR | None = None
    best_observed_candidate: AlgorithmCandidateIR | None = None
    baseline: ClassicalBaselineIR | None = None
    problem_id: str | None = None
    problem_hash: str | None = None
    optimality_claim: Literal["not_claimed"] = "not_claimed"
    metadata: Mapping[str, Any] = field(default_factory=dict)
    schema_version: str = ALGORITHM_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_text(self.algorithm_run_id, "algorithm_run_id")
        if self.algorithm_kind not in _ALGORITHM_KINDS:
            raise ValueError(f"Unsupported algorithm_kind: {self.algorithm_kind!r}.")
        if not isinstance(self.hamiltonian, PauliHamiltonian):
            raise TypeError("hamiltonian must be PauliHamiltonian.")
        if not isinstance(self.ansatz, AnsatzSpecIR):
            raise TypeError("ansatz must be AnsatzSpecIR.")
        if self.ansatz.logical_order != self.hamiltonian.logical_order:
            raise ValueError(
                "ansatz logical_order must match Hamiltonian logical_order."
            )
        if self.algorithm_kind == "qaoa" and self.ansatz.ansatz_kind != "qaoa":
            raise ValueError("QAOA result requires a QAOA ansatz.")
        if self.algorithm_kind == "vqe" and self.ansatz.ansatz_kind == "qaoa":
            raise ValueError("VQE result cannot use a QAOA ansatz contract.")
        if not isinstance(self.optimizer, OptimizerConfig):
            raise TypeError("optimizer must be OptimizerConfig.")
        if self.optimizer.bounds and len(self.optimizer.bounds) != len(
            self.ansatz.parameter_names
        ):
            raise ValueError("optimizer bounds must match ansatz parameter count.")
        if not isinstance(self.evaluations, tuple):
            object.__setattr__(self, "evaluations", tuple(self.evaluations))
        if not self.evaluations:
            raise ValueError("evaluations must not be empty.")
        if any(
            not isinstance(item, ObjectiveEvaluationIR) for item in self.evaluations
        ):
            raise TypeError("evaluations must contain ObjectiveEvaluationIR values.")
        indices = tuple(item.evaluation_index for item in self.evaluations)
        if indices != tuple(range(len(self.evaluations))):
            raise ValueError("evaluation indices must be contiguous and zero-based.")
        for attribute in ("evaluation_id", "result_id"):
            values = tuple(getattr(item, attribute) for item in self.evaluations)
            if len(values) != len(set(values)):
                raise ValueError(f"evaluation {attribute} values must be unique.")
        hamiltonian_hash = self.hamiltonian.stable_hash()
        if any(item.hamiltonian_hash != hamiltonian_hash for item in self.evaluations):
            raise ValueError("all evaluations must reference the result Hamiltonian.")
        expected_terms = tuple(
            (term.term_id, term.observable.name, term.coefficient)
            for term in self.hamiltonian.terms
        )
        expected_parameter_names = set(self.ansatz.parameter_names)
        expected_observable_set_hash = self.hamiltonian.observable_set().stable_hash()
        objective_execution_context = _objective_execution_context(
            self.evaluations[0]
        )
        for evaluation in self.evaluations:
            actual_terms = tuple(
                (item.term_id, item.observable_name, item.coefficient)
                for item in evaluation.contributions
            )
            if actual_terms != expected_terms:
                raise ValueError(
                    "evaluation contributions must match Hamiltonian term order."
                )
            if evaluation.constant != self.hamiltonian.constant:
                raise ValueError("evaluation constant must match Hamiltonian constant.")
            if (
                evaluation.observable_batch.observable_set_hash
                != expected_observable_set_hash
            ):
                raise ValueError(
                    "evaluation Observable batch must match the Hamiltonian."
                )
            if set(evaluation.parameter_bind.values) != expected_parameter_names:
                raise ValueError(
                    "evaluation parameters must match ansatz parameter names."
                )
            if _objective_execution_context(evaluation) != objective_execution_context:
                raise ValueError(
                    "all evaluations must share NoiseModel, requested options, "
                    "simulation method, and estimator."
                )
        if not isinstance(self.best_evaluation_index, int) or isinstance(
            self.best_evaluation_index, bool
        ):
            raise TypeError("best_evaluation_index must be int.")
        if not 0 <= self.best_evaluation_index < len(self.evaluations):
            raise ValueError("best_evaluation_index is outside evaluations.")
        expected_best = min(
            self.evaluations,
            key=lambda item: (item.energy, item.evaluation_index),
        ).evaluation_index
        if self.best_evaluation_index != expected_best:
            raise ValueError(
                "best_evaluation_index must select minimum observed energy."
            )
        if not isinstance(self.termination, OptimizerTerminationIR):
            raise TypeError("termination must be OptimizerTerminationIR.")
        if self.termination.method != self.optimizer.method:
            raise ValueError("termination method must match optimizer method.")
        if self.termination.nfev != len(self.evaluations):
            raise ValueError("termination nfev must match evaluation count.")
        from cascaqit.algorithms.gradient import ObjectiveGradientIR

        if not isinstance(self.gradients, tuple):
            object.__setattr__(self, "gradients", tuple(self.gradients))
        if any(not isinstance(item, ObjectiveGradientIR) for item in self.gradients):
            raise TypeError("gradients must contain ObjectiveGradientIR values.")
        gradient_indices = tuple(item.gradient_index for item in self.gradients)
        if gradient_indices != tuple(range(len(self.gradients))):
            raise ValueError("gradient indices must be contiguous and zero-based.")
        if len({item.gradient_id for item in self.gradients}) != len(self.gradients):
            raise ValueError("gradient ids must be unique.")
        if self.gradients:
            first_plan_hash = self.gradients[0].plan_hash
            for gradient in self.gradients:
                if gradient.plan_hash != first_plan_hash:
                    raise ValueError(
                        "all gradients must share one parameter-shift plan."
                    )
                if gradient.plan.hamiltonian_hash != hamiltonian_hash:
                    raise ValueError(
                        "gradient plan must reference the result Hamiltonian."
                    )
                if gradient.plan.parameter_names != self.ansatz.parameter_names:
                    raise ValueError(
                        "gradient parameters must match the result ansatz."
                    )
                for pair in gradient.shift_pairs:
                    for evaluation in (
                        pair.positive_evaluation,
                        pair.negative_evaluation,
                    ):
                        if (
                            _objective_execution_context(evaluation)
                            != objective_execution_context
                        ):
                            raise ValueError(
                                "gradient execution context must match objective "
                                "execution context."
                            )
        if self.optimizer.gradient is None and self.gradients:
            raise ValueError(
                "gradient history requires optimizer gradient configuration."
            )
        if self.optimizer.gradient is not None and not self.gradients:
            raise ValueError("gradient optimizer result requires gradient history.")
        if self.termination.njev != len(self.gradients):
            raise ValueError("termination njev must match gradient count.")
        expected_backend_count = len(self.evaluations) + sum(
            item.backend_execution_count for item in self.gradients
        )
        if self.termination.backend_execution_count != expected_backend_count:
            raise ValueError(
                "termination backend_execution_count must match objective and "
                "gradient evidence."
            )
        if not isinstance(self.optimization_starts, tuple):
            object.__setattr__(
                self,
                "optimization_starts",
                tuple(self.optimization_starts),
            )
        if any(
            not isinstance(item, OptimizationStartIR)
            for item in self.optimization_starts
        ):
            raise TypeError(
                "optimization_starts must contain OptimizationStartIR values."
            )
        if self.optimization_starts:
            if len(self.optimization_starts) != self.optimizer.starts:
                raise ValueError("optimization_starts must match optimizer starts.")
            if tuple(item.start_index for item in self.optimization_starts) != tuple(
                range(len(self.optimization_starts))
            ):
                raise ValueError(
                    "optimization start indices must be contiguous and zero-based."
                )
            expected_evaluation_start = 0
            expected_gradient_start = 0
            for start in self.optimization_starts:
                if start.evaluation_start_index != expected_evaluation_start:
                    raise ValueError(
                        "optimization starts must cover contiguous evaluation slices."
                    )
                expected_evaluation_start += start.evaluation_count
                if start.gradient_start_index != expected_gradient_start:
                    raise ValueError(
                        "optimization starts must cover contiguous gradient slices."
                    )
                expected_gradient_start += start.gradient_count
                if self.evaluations[start.best_evaluation_index].energy != (
                    start.best_objective
                ):
                    raise ValueError(
                        "start best_objective must match its best evaluation."
                    )
            if expected_evaluation_start != len(self.evaluations):
                raise ValueError(
                    "optimization starts must cover every evaluation exactly once."
                )
            if expected_gradient_start != len(self.gradients):
                raise ValueError(
                    "optimization starts must cover every gradient exactly once."
                )
            if sum(
                item.backend_execution_count
                if item.backend_execution_count is not None
                else 0
                for item in self.optimization_starts
            ) != self.termination.backend_execution_count:
                raise ValueError(
                    "optimization start Backend costs must match termination evidence."
                )
            if (
                not isinstance(self.selected_start_index, int)
                or isinstance(self.selected_start_index, bool)
                or not 0 <= self.selected_start_index < len(self.optimization_starts)
            ):
                raise ValueError("selected_start_index is outside optimization_starts.")
            selected_start = self.optimization_starts[self.selected_start_index]
            if selected_start.best_evaluation_index != self.best_evaluation_index:
                raise ValueError("selected start must own the global best evaluation.")
        elif self.selected_start_index is not None:
            raise ValueError("selected_start_index requires optimization_starts.")
        if self.final_result is not None and not isinstance(
            self.final_result, ResultIR
        ):
            raise TypeError("final_result must be ResultIR or None.")
        if self.final_result is not None:
            if self.final_result.result_id in {
                item.result_id for item in self.evaluations
            }:
                raise ValueError(
                    "final_result must be distinct from objective Result evidence."
                )
            if self.final_result.shots <= 0 or not self.final_result.counts:
                raise ValueError("final_result must contain sampled counts.")
            if sum(self.final_result.counts.values()) != self.final_result.shots:
                raise ValueError("final_result counts must sum to shots.")
        for name, candidate in (
            ("most_probable_candidate", self.most_probable_candidate),
            ("best_observed_candidate", self.best_observed_candidate),
        ):
            if candidate is not None and not isinstance(
                candidate, AlgorithmCandidateIR
            ):
                raise TypeError(f"{name} must be AlgorithmCandidateIR or None.")
            if candidate is not None and self.final_result is None:
                raise ValueError(f"{name} requires final_result evidence.")
            if candidate is not None and self.problem_id is None:
                raise ValueError(f"{name} requires problem provenance.")
            if candidate is not None:
                assert self.final_result is not None
                expected_count = self.final_result.counts.get(candidate.bitstring)
                if expected_count is None or expected_count != candidate.count:
                    raise ValueError(f"{name} count must match final_result counts.")
                expected_probability = expected_count / self.final_result.shots
                if candidate.probability is None or not math.isclose(
                    candidate.probability,
                    expected_probability,
                    rel_tol=0.0,
                    abs_tol=_ENERGY_TOLERANCE,
                ):
                    raise ValueError(
                        f"{name} probability must match final_result counts."
                    )
        if self.most_probable_candidate is not None:
            assert self.final_result is not None
            largest_count = max(self.final_result.counts.values())
            expected_most = min(
                bitstring
                for bitstring, count in self.final_result.counts.items()
                if count == largest_count
            )
            if self.most_probable_candidate.bitstring != expected_most:
                raise ValueError(
                    "most_probable_candidate must use count and bitstring tie-break."
                )
        if self.baseline is not None and not isinstance(
            self.baseline, ClassicalBaselineIR
        ):
            raise TypeError("baseline must be ClassicalBaselineIR or None.")
        if self.baseline is not None and self.problem_id is None:
            raise ValueError("baseline requires problem provenance.")
        if (self.problem_id is None) != (self.problem_hash is None):
            raise ValueError("problem_id and problem_hash must be provided together.")
        if self.problem_id is not None:
            _require_text(self.problem_id, "problem_id")
            _require_digest(self.problem_hash, "problem_hash")
            if self.hamiltonian.source_problem_id != self.problem_id:
                raise ValueError("problem_id must match Hamiltonian provenance.")
            if self.hamiltonian.source_problem_hash != self.problem_hash:
                raise ValueError("problem_hash must match Hamiltonian provenance.")
        if self.optimality_claim != "not_claimed":
            raise ValueError("VariationalResult cannot claim global optimality.")
        metadata = _freeze_mapping(self.metadata)
        if self.final_result is not None:
            final_sampling = metadata.get("final_sampling")
            if not isinstance(final_sampling, Mapping):
                raise ValueError("final_result requires final_sampling metadata.")
            if final_sampling.get("result_id") != self.final_result.result_id:
                raise ValueError("final_sampling result_id must match final_result.")
            if final_sampling.get("result_hash") != self.final_result.stable_hash():
                raise ValueError("final_sampling result_hash must match final_result.")
            if (
                final_sampling.get("source_evaluation_id")
                != self.best_evaluation.evaluation_id
            ):
                raise ValueError(
                    "final_sampling must reference the best observed evaluation."
                )
            _validate_final_sampling_execution_context(
                self.final_result,
                final_sampling,
                self.best_evaluation,
            )
        object.__setattr__(self, "metadata", metadata)

    @property
    def best_evaluation(self) -> ObjectiveEvaluationIR:
        """Return the minimum observed objective evaluation."""
        return self.evaluations[self.best_evaluation_index]

    @property
    def gradient_plan(self) -> ParameterShiftPlanIR | None:
        """Return the shared gradient plan, when gradient optimization was used."""
        return None if not self.gradients else self.gradients[0].plan

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> VariationalResult:
        """Build a variational result from JSON-compatible data."""
        from cascaqit.algorithms.gradient import ObjectiveGradientIR

        raw_evaluations = data.get("evaluations", ())
        if not isinstance(raw_evaluations, (list, tuple)):
            raise TypeError("evaluations must be an array.")
        raw_final = data.get("final_result")
        raw_most = data.get("most_probable_candidate")
        raw_best = data.get("best_observed_candidate")
        raw_baseline = data.get("baseline")
        return cls(
            algorithm_run_id=data["algorithm_run_id"],
            algorithm_kind=data["algorithm_kind"],
            hamiltonian=PauliHamiltonian.from_dict(
                _mapping(data["hamiltonian"], "hamiltonian")
            ),
            ansatz=AnsatzSpecIR.from_dict(_mapping(data["ansatz"], "ansatz")),
            optimizer=OptimizerConfig.from_dict(
                _mapping(data["optimizer"], "optimizer")
            ),
            evaluations=tuple(
                ObjectiveEvaluationIR.from_dict(_mapping(item, "evaluation"))
                for item in raw_evaluations
            ),
            best_evaluation_index=data["best_evaluation_index"],
            termination=OptimizerTerminationIR.from_dict(
                _mapping(data["termination"], "termination")
            ),
            gradients=tuple(
                ObjectiveGradientIR.from_dict(_mapping(item, "gradient"))
                for item in data.get("gradients", ())
            ),
            optimization_starts=tuple(
                OptimizationStartIR.from_dict(_mapping(item, "optimization_start"))
                for item in data.get("optimization_starts", ())
            ),
            selected_start_index=data.get("selected_start_index"),
            final_result=None
            if raw_final is None
            else ResultIR.from_dict(dict(_mapping(raw_final, "final_result"))),
            most_probable_candidate=None
            if raw_most is None
            else AlgorithmCandidateIR.from_dict(
                _mapping(raw_most, "most_probable_candidate")
            ),
            best_observed_candidate=None
            if raw_best is None
            else AlgorithmCandidateIR.from_dict(
                _mapping(raw_best, "best_observed_candidate")
            ),
            baseline=None
            if raw_baseline is None
            else ClassicalBaselineIR.from_dict(_mapping(raw_baseline, "baseline")),
            problem_id=data.get("problem_id"),
            problem_hash=data.get("problem_hash"),
            optimality_claim=data.get("optimality_claim", "not_claimed"),
            metadata=_mapping(data.get("metadata", {}), "metadata"),
            schema_version=str(data.get("schema_version", ALGORITHM_SCHEMA_VERSION)),
        )

    @classmethod
    def from_json(cls, text: str) -> VariationalResult:
        """Build a variational result from JSON text."""
        return cls.from_dict(_json_object(text, "VariationalResult"))


def _objective_execution_context(
    evaluation: ObjectiveEvaluationIR,
) -> tuple[object, ...]:
    """返回用于同一次优化交叉校验的 objective 执行上下文。"""
    evidence = evaluation.execution_evidence
    return (
        None if evidence.noise_model is None else evidence.noise_model.stable_hash(),
        None
        if evidence.requested_options is None
        else evidence.requested_options.stable_hash(),
        evidence.simulation_plan.method_selected,
        evidence.estimator_kind,
        evidence.source_kind,
    )


def _validate_final_sampling_execution_context(
    final_result: ResultIR,
    final_sampling: Mapping[str, Any],
    best_evaluation: ObjectiveEvaluationIR,
) -> None:
    """从保存 metadata 重建 final sampling 的数值与噪声来源事实。"""
    from cascaqit.simulators import (
        NoiseModel,
        NoiseReport,
        SimulationExecutionPlan,
        SimulationOptions,
    )

    source = best_evaluation.execution_evidence
    if final_sampling.get("shots") != final_result.shots:
        raise ValueError("final_sampling shots must match final Result.")
    if final_sampling.get("backend_execution_count") != 1:
        raise ValueError("final_sampling must record exactly one Backend execution.")
    if final_sampling.get("backend_id") != final_result.metadata.get("backend_id"):
        raise ValueError("final_sampling backend id must match final Result.")
    backend_job_id = final_sampling.get("backend_job_id")
    if not isinstance(backend_job_id, str) or not backend_job_id.strip():
        raise ValueError("final_sampling backend job id must be non-empty.")
    if final_sampling.get("source_execution_evidence_hash") != source.evidence_hash:
        raise ValueError(
            "final_sampling source evidence hash must match the best evaluation."
        )
    if final_sampling.get("seed") != source.effective_seed:
        raise ValueError("final_sampling seed must match the best evaluation seed.")

    raw_noise = final_sampling.get("noise_model")
    final_noise = (
        None
        if raw_noise is None
        else NoiseModel.from_dict(dict(_mapping(raw_noise, "final noise_model")))
    )
    final_noise_hash = None if final_noise is None else final_noise.stable_hash()
    if final_sampling.get("noise_model_hash") != final_noise_hash:
        raise ValueError("final_sampling NoiseModel hash does not match its facts.")
    source_noise_hash = (
        None if source.noise_model is None else source.noise_model.stable_hash()
    )
    if final_noise_hash != source_noise_hash:
        raise ValueError("final sampling NoiseModel must match objective evidence.")

    raw_options = final_sampling.get("requested_options")
    final_options = (
        None
        if raw_options is None
        else SimulationOptions.from_dict(
            dict(_mapping(raw_options, "final requested_options"))
        )
    )
    final_options_hash = (
        None if final_options is None else final_options.stable_hash()
    )
    if final_sampling.get("requested_options_hash") != final_options_hash:
        raise ValueError(
            "final_sampling requested options hash does not match its facts."
        )
    source_options_hash = (
        None
        if source.requested_options is None
        else source.requested_options.stable_hash()
    )
    if final_options_hash != source_options_hash:
        raise ValueError("final sampling options must match objective evidence.")

    final_plan = SimulationExecutionPlan.from_dict(
        dict(_mapping(final_sampling.get("simulation_plan"), "final simulation_plan"))
    )
    if final_sampling.get("simulation_plan_hash") != final_plan.stable_hash():
        raise ValueError("final_sampling SimulationPlan hash does not match its facts.")
    result_plan = SimulationExecutionPlan.from_dict(
        dict(
            _mapping(
                final_result.metadata.get("simulation_plan"),
                "final Result simulation_plan",
            )
        )
    )
    if final_result.metadata.get("simulation_plan_hash") != result_plan.stable_hash():
        raise ValueError("final Result SimulationPlan hash does not match its facts.")
    if final_plan != result_plan:
        raise ValueError(
            "final_sampling SimulationPlan must match final Result metadata."
        )
    source_plan = source.simulation_plan
    if _simulation_plan_context(final_plan) != _simulation_plan_context(source_plan):
        raise ValueError(
            "final sampling plan context must match objective execution context."
        )

    raw_report = final_sampling.get("noise_report")
    final_report = (
        None
        if raw_report is None
        else NoiseReport.from_dict(_mapping(raw_report, "final noise_report"))
    )
    final_report_hash = (
        None if final_report is None else final_report.stable_hash()
    )
    if final_sampling.get("noise_report_hash") != final_report_hash:
        raise ValueError("final_sampling NoiseReport hash does not match its facts.")
    expected_mode = "noisy" if final_noise is not None else "ideal"
    if final_sampling.get("execution_mode") != expected_mode:
        raise ValueError("final_sampling execution_mode does not match NoiseModel.")

    result_report_data = final_result.metadata.get("noise_report")
    if final_noise is None:
        if final_report is not None or result_report_data is not None:
            raise ValueError("ideal final sampling cannot contain NoiseReport.")
        if final_result.metadata.get("noise_model_hash") is not None:
            raise ValueError("ideal final Result cannot contain NoiseModel hash.")
        return
    if final_report is None or not isinstance(result_report_data, Mapping):
        raise ValueError("noisy final sampling requires NoiseReport evidence.")
    result_report = NoiseReport.from_dict(result_report_data)
    if final_report != result_report:
        raise ValueError("final_sampling NoiseReport must match final Result metadata.")
    if final_result.metadata.get("noise_report_hash") != result_report.stable_hash():
        raise ValueError("final Result NoiseReport hash does not match its facts.")
    if final_result.metadata.get("noise_model_hash") != final_noise_hash:
        raise ValueError("final Result NoiseModel hash does not match final sampling.")
    if (
        final_report.noise_model_id != final_noise.noise_model_id
        or final_report.noise_model_hash != final_noise_hash
        or final_report.method != final_plan.method_selected
    ):
        raise ValueError(
            "final NoiseReport model and method must match final sampling context."
        )


def _simulation_plan_context(plan: object) -> Mapping[str, Any]:
    """比较冻结的数值语义，排除每次规划都可变化的主机资源快照。"""
    from cascaqit.simulators import SimulationExecutionPlan

    if not isinstance(plan, SimulationExecutionPlan):
        raise TypeError("plan must be SimulationExecutionPlan.")
    return {
        "program_kind": plan.program_kind,
        "logical_sites": plan.logical_sites,
        "noisy": plan.noisy,
        "method_requested": plan.method_requested,
        "method_selected": plan.method_selected,
        "integrator_requested": plan.integrator_requested,
        "integrator_selected": plan.integrator_selected,
        "state_representation": plan.state_representation,
        "device": plan.device,
        "dtype": plan.dtype,
        "hilbert_dimension": plan.hilbert_dimension,
        "workers": plan.workers,
        "trajectories": plan.trajectories,
        "rtol": plan.rtol,
        "atol": plan.atol,
        "max_steps": plan.max_steps,
        "seed": plan.seed,
        "options_hash": plan.options_hash,
    }


def _finite_float(value: object, name: str) -> float:
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        raise TypeError(f"{name} must be a real number.")
    normalized = float(value)
    if not math.isfinite(normalized):
        raise ValueError(f"{name} must be finite.")
    return normalized


def _finite_parameter_mapping(
    value: object,
    name: str,
) -> Mapping[str, float]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{name} must be a mapping.")
    normalized: dict[str, float] = {}
    for parameter_name, parameter_value in value.items():
        _require_text(parameter_name, f"{name} key")
        normalized[str(parameter_name)] = _finite_float(
            parameter_value,
            f"{name}[{parameter_name}]",
        )
    return MappingProxyType(normalized)


def _require_text(value: object, name: str) -> None:
    if not isinstance(value, str) or not value.strip() or value != value.strip():
        raise ValueError(f"{name} must be a non-empty trimmed string.")


def _require_digest(value: object, name: str) -> None:
    if not isinstance(value, str) or _DIGEST_PATTERN.fullmatch(value) is None:
        raise ValueError(f"{name} must be a lowercase SHA-256 digest.")


def _require_positive_int(value: object, name: str) -> None:
    if not isinstance(value, int) or isinstance(value, bool) or value <= 0:
        raise ValueError(f"{name} must be a positive integer.")


def _require_non_negative_int(value: object, name: str) -> None:
    if not isinstance(value, int) or isinstance(value, bool) or value < 0:
        raise ValueError(f"{name} must be a non-negative integer.")


def _require_unique_text(
    values: Sequence[object],
    name: str,
    *,
    allow_empty: bool = True,
) -> None:
    if not allow_empty and not values:
        raise ValueError(f"{name} must not be empty.")
    for value in values:
        _require_text(value, name)
    if len(values) != len(set(values)):
        raise ValueError(f"{name} values must be unique.")


def _mapping(value: object, name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{name} must be an object.")
    return value


def _sequence(value: object, name: str) -> Sequence[Any]:
    if not isinstance(value, (list, tuple)):
        raise TypeError(f"{name} must be an array.")
    return value


def _freeze_mapping(value: Mapping[str, Any]) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError("metadata must be a mapping.")
    return MappingProxyType(
        {str(key): _freeze_value(item) for key, item in value.items()}
    )


def _freeze_value(value: Any) -> Any:
    if isinstance(value, Mapping):
        return _freeze_mapping(value)
    if isinstance(value, (list, tuple)):
        return tuple(_freeze_value(item) for item in value)
    return value


def _json_object(text: str, name: str) -> Mapping[str, Any]:
    data = json.loads(text)
    if not isinstance(data, dict):
        raise TypeError(f"{name} JSON must contain an object.")
    return data
