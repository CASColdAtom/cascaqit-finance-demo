"""Problem projection, classical energy, decode, and bounded baseline helpers."""

from __future__ import annotations

import math

import numpy as np
from numpy.typing import NDArray

from cascaqit.algorithms.models import (
    AlgorithmCandidateIR,
    ClassicalBaselineIR,
    HamiltonianTerm,
    PauliHamiltonian,
)
from cascaqit.observables import PauliBasis, PauliZ, PauliZZ
from cascaqit.problems import (
    GraphProblemIR,
    IsingModelIR,
    MISInstance,
    MWISProblemIR,
    OptimizationProblem,
    QUBOProblemIR,
    evaluate_ising_bitstring,
    evaluate_mwis_bitstring,
    evaluate_qubo_bitstring,
    mis_to_qubo,
    mwis_to_qubo,
    resolve_mwis_penalty,
)

__all__ = [
    "bounded_exhaustive_baseline",
    "decode_problem_candidate",
    "evaluate_pauli_hamiltonian_bitstring",
    "ising_to_pauli_hamiltonian",
    "problem_to_pauli_hamiltonian",
    "qubo_to_pauli_hamiltonian",
]

_DEFAULT_MIS_PENALTY = 2.0
_DEFAULT_BASELINE_LIMIT = 20
_MAX_BASELINE_LIMIT = 20
_DEFAULT_BASELINE_CHUNK_SIZE = 65_536
_MAX_BASELINE_CHUNK_SIZE = 262_144


def qubo_to_pauli_hamiltonian(
    problem: QUBOProblemIR,
    *,
    hamiltonian_id: str | None = None,
) -> PauliHamiltonian:
    """Project a QUBO objective into a diagonal weighted Pauli Hamiltonian."""
    if not isinstance(problem, QUBOProblemIR):
        raise TypeError("qubo_to_pauli_hamiltonian requires QUBOProblemIR.")
    _require_valid_problem(problem, "QUBO")
    ising = problem.to_ising_model()
    source_id, source_hash, source_type = _source_problem_identity(
        problem,
        default_type="qubo",
    )
    return _ising_terms_to_hamiltonian(
        ising,
        hamiltonian_id=hamiltonian_id or f"hamiltonian.{source_id}",
        source_problem_id=source_id,
        source_problem_hash=source_hash,
        metadata={
            "source_problem_type": source_type,
            "projection_path": "qubo_to_ising_to_pauli",
            "binary_to_spin_convention": "x = (1 + s) / 2",
            "spin_to_pauli_convention": "s = -Z",
            "source_qubo_id": problem.problem_id,
            "source_qubo_hash": problem.stable_hash(),
        },
    )


def ising_to_pauli_hamiltonian(
    problem: IsingModelIR,
    *,
    hamiltonian_id: str | None = None,
) -> PauliHamiltonian:
    """Project Ising spins into computational-basis Pauli operators."""
    if not isinstance(problem, IsingModelIR):
        raise TypeError("ising_to_pauli_hamiltonian requires IsingModelIR.")
    _require_valid_problem(problem, "Ising")
    source_id, source_hash, source_type = _source_problem_identity(
        problem,
        default_type="ising",
    )
    return _ising_terms_to_hamiltonian(
        problem,
        hamiltonian_id=hamiltonian_id or f"hamiltonian.{source_id}",
        source_problem_id=source_id,
        source_problem_hash=source_hash,
        metadata={
            "source_problem_type": source_type,
            "projection_path": "ising_to_pauli",
            "spin_to_pauli_convention": "s = -Z",
            "source_ising_id": problem.problem_id,
            "source_ising_hash": problem.stable_hash(),
        },
    )


def problem_to_pauli_hamiltonian(
    problem: OptimizationProblem,
    *,
    mis_penalty: float = _DEFAULT_MIS_PENALTY,
    mwis_penalty: float | None = None,
    hamiltonian_id: str | None = None,
) -> PauliHamiltonian:
    """Project one supported problem into the canonical algorithm Hamiltonian."""
    if isinstance(problem, QUBOProblemIR):
        return qubo_to_pauli_hamiltonian(
            problem,
            hamiltonian_id=hamiltonian_id,
        )
    if isinstance(problem, IsingModelIR):
        return ising_to_pauli_hamiltonian(
            problem,
            hamiltonian_id=hamiltonian_id,
        )
    if isinstance(problem, MWISProblemIR):
        return qubo_to_pauli_hamiltonian(
            mwis_to_qubo(problem, penalty=mwis_penalty),
            hamiltonian_id=hamiltonian_id,
        )
    instance = _mis_instance(problem)
    return qubo_to_pauli_hamiltonian(
        mis_to_qubo(instance, penalty=mis_penalty),
        hamiltonian_id=hamiltonian_id,
    )


def evaluate_pauli_hamiltonian_bitstring(
    hamiltonian: PauliHamiltonian,
    bitstring: str,
) -> float:
    """Evaluate an I/Z Hamiltonian eigenvalue in computational basis."""
    if not isinstance(hamiltonian, PauliHamiltonian):
        raise TypeError("hamiltonian must be PauliHamiltonian.")
    bits = _bit_values(bitstring, hamiltonian.logical_order)
    energy = hamiltonian.constant
    for term in hamiltonian.terms:
        eigenvalue = 1
        for factor in term.observable.terms:
            if factor.basis is PauliBasis.I:
                continue
            if factor.basis is not PauliBasis.Z:
                raise ValueError(
                    "Classical bitstring evaluation supports only Pauli I/Z terms."
                )
            eigenvalue *= 1 if bits[factor.target] == 0 else -1
        energy += term.coefficient * eigenvalue
    return float(energy)


def decode_problem_candidate(
    problem: OptimizationProblem,
    bitstring: str,
    *,
    probability: float | None = None,
    count: int | None = None,
    mis_penalty: float = _DEFAULT_MIS_PENALTY,
    mwis_penalty: float | None = None,
) -> AlgorithmCandidateIR:
    """Decode one measured bitstring without adding an optimality claim."""
    if isinstance(problem, QUBOProblemIR):
        bits = _bit_values(bitstring, problem.variables)
        return AlgorithmCandidateIR(
            bitstring=bitstring,
            objective_value=evaluate_qubo_bitstring(problem, bitstring),
            probability=probability,
            count=count,
            feasible=None,
            decoded={
                "problem_type": "qubo",
                "variable_order": problem.variables,
                "binary_values": bits,
            },
        )
    if isinstance(problem, IsingModelIR):
        bits = _bit_values(bitstring, problem.spins)
        return AlgorithmCandidateIR(
            bitstring=bitstring,
            objective_value=evaluate_ising_bitstring(problem, bitstring),
            probability=probability,
            count=count,
            feasible=None,
            decoded={
                "problem_type": "ising",
                "variable_order": problem.spins,
                "spin_values": {name: 2 * bit - 1 for name, bit in bits.items()},
            },
        )
    if isinstance(problem, MWISProblemIR):
        _require_valid_problem(problem, "MWIS")
        bits = _bit_values(bitstring, problem.nodes)
        penalty = resolve_mwis_penalty(problem, penalty=mwis_penalty)
        selected = tuple(node for node, bit in bits.items() if bit == 1)
        selected_set = set(selected)
        violations = tuple(
            edge
            for edge in problem.edges
            if edge[0] in selected_set and edge[1] in selected_set
        )
        selected_weight = sum(
            weight for node, weight in problem.node_weights if node in selected_set
        )
        penalty_energy = penalty * len(violations)
        return AlgorithmCandidateIR(
            bitstring=bitstring,
            objective_value=evaluate_mwis_bitstring(
                problem,
                bitstring,
                penalty=penalty,
            ),
            probability=probability,
            count=count,
            feasible=not violations,
            decoded={
                "problem_type": "mwis",
                "variable_order": problem.nodes,
                "selected_nodes": selected,
                "selected_weight": selected_weight,
                "is_independent": not violations,
                "violating_edges": violations,
                "violation_count": len(violations),
                "business_objective": -selected_weight,
                "penalty_energy": penalty_energy,
                "penalty": penalty,
            },
        )
    instance = _mis_instance(problem)
    bits = _bit_values(bitstring, instance.node_order())
    qubo = mis_to_qubo(instance, penalty=mis_penalty)
    selected = tuple(node for node, bit in bits.items() if bit == 1)
    selected_set = set(selected)
    violations = tuple(
        edge
        for edge in instance.edges
        if edge[0] in selected_set and edge[1] in selected_set
    )
    return AlgorithmCandidateIR(
        bitstring=bitstring,
        objective_value=evaluate_qubo_bitstring(qubo, bitstring),
        probability=probability,
        count=count,
        feasible=not violations,
        decoded={
            "problem_type": "mis",
            "variable_order": instance.node_order(),
            "selected_nodes": selected,
            "size": len(selected),
            "is_independent": not violations,
            "violating_edges": violations,
            "penalty": qubo.metadata["mis_penalty"],
        },
    )


def bounded_exhaustive_baseline(
    problem: OptimizationProblem,
    *,
    limit: int = _DEFAULT_BASELINE_LIMIT,
    chunk_size: int = _DEFAULT_BASELINE_CHUNK_SIZE,
    mis_penalty: float = _DEFAULT_MIS_PENALTY,
    mwis_penalty: float | None = None,
) -> ClassicalBaselineIR:
    """Find an exact small-problem baseline with bounded NumPy chunks."""
    _positive_int(limit, "limit")
    if limit > _MAX_BASELINE_LIMIT:
        raise ValueError(f"limit must not exceed {_MAX_BASELINE_LIMIT}.")
    _positive_int(chunk_size, "chunk_size")
    if chunk_size > _MAX_BASELINE_CHUNK_SIZE:
        raise ValueError(f"chunk_size must not exceed {_MAX_BASELINE_CHUNK_SIZE}.")
    objective = _baseline_objective(
        problem,
        mis_penalty=mis_penalty,
        mwis_penalty=mwis_penalty,
    )
    variable_count = len(objective.variables)
    if variable_count > limit:
        return ClassicalBaselineIR(
            status="unavailable",
            method="bounded_exhaustive",
            variable_count=variable_count,
            limit=limit,
            unavailable_reason=(
                f"variable_count {variable_count} exceeds limit {limit}."
            ),
        )

    linear, quadratic = _qubo_arrays(objective)
    total = 1 << variable_count
    shifts = np.arange(variable_count - 1, -1, -1, dtype=np.uint64)
    best_energy = math.inf
    best_index = 0
    for start in range(0, total, chunk_size):
        stop = min(start + chunk_size, total)
        indices = np.arange(start, stop, dtype=np.uint64)
        bits = ((indices[:, None] >> shifts) & 1).astype(np.float64)
        energies = np.full(stop - start, objective.offset, dtype=np.float64)
        # Element-wise reduction avoids platform BLAS variability for this
        # small, highly rectangular binary matrix.
        energies += np.sum(bits * linear, axis=1)
        for left, right, coefficient in quadratic:
            energies += coefficient * bits[:, left] * bits[:, right]
        local_index = int(np.argmin(energies))
        local_energy = float(energies[local_index])
        if local_energy < best_energy:
            best_energy = local_energy
            best_index = start + local_index
    return ClassicalBaselineIR(
        status="available",
        method="bounded_exhaustive",
        variable_count=variable_count,
        limit=limit,
        objective_value=best_energy,
        bitstring=format(best_index, f"0{variable_count}b"),
    )


def _ising_terms_to_hamiltonian(
    problem: IsingModelIR,
    *,
    hamiltonian_id: str,
    source_problem_id: str,
    source_problem_hash: str,
    metadata: dict[str, object],
) -> PauliHamiltonian:
    # computational |0> has Z=+1 while the existing Ising contract maps bit 0
    # to s=-1, so fields change sign and pair products do not.
    terms = tuple(
        HamiltonianTerm(
            term_id=f"field.{spin}",
            coefficient=-_finite(coefficient, "Ising field coefficient"),
            observable=PauliZ(spin),
        )
        for spin, coefficient in problem.fields
        if coefficient != 0.0
    ) + tuple(
        HamiltonianTerm(
            term_id=f"coupling.{left}.{right}",
            coefficient=_finite(coefficient, "Ising coupling coefficient"),
            observable=PauliZZ(left, right),
        )
        for left, right, coefficient in problem.couplings
        if coefficient != 0.0
    )
    if not terms:
        raise ValueError(
            "A variational Hamiltonian requires at least one non-constant term."
        )
    return PauliHamiltonian(
        hamiltonian_id=hamiltonian_id,
        terms=terms,
        constant=_finite(problem.offset, "Ising offset"),
        logical_order=problem.spins,
        source_problem_id=source_problem_id,
        source_problem_hash=source_problem_hash,
        metadata=metadata,
    )


def _mis_instance(problem: OptimizationProblem) -> MISInstance:
    if isinstance(problem, GraphProblemIR):
        _require_valid_problem(problem, "Graph")
        return problem.to_mis_instance()
    if isinstance(problem, MISInstance):
        _require_valid_problem(problem, "MIS")
        return problem
    raise TypeError(
        "supported problem types are GraphProblemIR, MISInstance, "
        "QUBOProblemIR, and IsingModelIR."
    )


def _baseline_objective(
    problem: OptimizationProblem,
    *,
    mis_penalty: float,
    mwis_penalty: float | None,
) -> QUBOProblemIR:
    if isinstance(problem, QUBOProblemIR):
        _require_valid_problem(problem, "QUBO")
        return problem
    if isinstance(problem, IsingModelIR):
        _require_valid_problem(problem, "Ising")
        # Convert s=2x-1 into a QUBO used only by the vectorized enumerator.
        linear = {spin: 2.0 * value for spin, value in problem.fields}
        quadratic = {
            (left, right): 4.0 * value for left, right, value in problem.couplings
        }
        for left, right, value in problem.couplings:
            linear[left] = linear.get(left, 0.0) - 2.0 * value
            linear[right] = linear.get(right, 0.0) - 2.0 * value
        offset = problem.offset - sum(value for _, value in problem.fields)
        offset += sum(value for _, _, value in problem.couplings)
        return QUBOProblemIR.from_terms(
            problem_id=f"qubo.baseline.{problem.problem_id}",
            variables=problem.spins,
            linear_terms=linear,
            quadratic_terms=quadratic,
            offset=offset,
        )
    if isinstance(problem, MWISProblemIR):
        return mwis_to_qubo(problem, penalty=mwis_penalty)
    return mis_to_qubo(_mis_instance(problem), penalty=mis_penalty)


def _qubo_arrays(
    problem: QUBOProblemIR,
) -> tuple[NDArray[np.float64], tuple[tuple[int, int, float], ...]]:
    positions = {name: index for index, name in enumerate(problem.variables)}
    linear = np.zeros(len(problem.variables), dtype=np.float64)
    for variable, coefficient in problem.linear_terms:
        linear[positions[variable]] += _finite(coefficient, "QUBO coefficient")
    quadratic = tuple(
        (
            positions[left],
            positions[right],
            _finite(coefficient, "QUBO coefficient"),
        )
        for left, right, coefficient in problem.quadratic_terms
    )
    return linear, quadratic


def _source_problem_identity(
    problem: QUBOProblemIR | IsingModelIR,
    *,
    default_type: str,
) -> tuple[str, str, str]:
    metadata = problem.metadata
    source_id = str(metadata.get("source_problem_id", problem.problem_id))
    source_hash = str(metadata.get("source_problem_hash", problem.stable_hash()))
    source_type = str(metadata.get("source_problem_type", default_type))
    return source_id, source_hash, source_type


def _require_valid_problem(
    problem: (
        GraphProblemIR
        | MISInstance
        | MWISProblemIR
        | QUBOProblemIR
        | IsingModelIR
    ),
    label: str,
) -> None:
    diagnostics = problem.validate()
    if diagnostics:
        codes = ", ".join(sorted({item.code for item in diagnostics}))
        raise ValueError(f"{label} problem validation failed: {codes}.")


def _bit_values(bitstring: str, order: tuple[str, ...]) -> dict[str, int]:
    if not isinstance(bitstring, str) or set(bitstring) - {"0", "1"}:
        raise ValueError("bitstring must contain only 0 and 1.")
    if len(bitstring) != len(order):
        raise ValueError("bitstring length must match the declared variable order.")
    return {name: int(bit) for name, bit in zip(order, bitstring)}


def _finite(value: object, name: str) -> float:
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        raise TypeError(f"{name} must be a real number.")
    normalized = float(value)
    if not math.isfinite(normalized):
        raise ValueError(f"{name} must be finite.")
    return normalized


def _positive_int(value: object, name: str) -> None:
    if not isinstance(value, int) or isinstance(value, bool) or value <= 0:
        raise ValueError(f"{name} must be a positive integer.")
