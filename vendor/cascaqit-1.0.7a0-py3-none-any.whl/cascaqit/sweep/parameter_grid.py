"""Deterministic parameter-grid sweep construction."""

from __future__ import annotations

import itertools
import json
from dataclasses import dataclass, field
from typing import Any

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.native_ir.base import IRMixin
from cascaqit.native_ir.models import SCHEMA_VERSION
from cascaqit.parameters.ir import ParameterBindIR, ParameterSchemaIR

__all__ = [
    "ParameterGrid",
    "ParameterSweepResult",
    "SweepResultSummaryIR",
    "build_sweep_result_summary",
]


@dataclass(frozen=True)
class ParameterSweepResult(IRMixin):
    """Result of expanding a sweep definition into parameter bind records."""

    sweep_id: str
    parameter_schema_hash: str
    binds: tuple[ParameterBindIR, ...]
    diagnostics: tuple[DiagnosticsIR, ...] = ()
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def has_errors(self) -> bool:
        """Return whether sweep expansion emitted error diagnostics."""
        return any(diagnostic.severity == "error" for diagnostic in self.diagnostics)


@dataclass(frozen=True)
class SweepResultSummaryIR(IRMixin):
    """Metadata-only summary for a sweep expansion and batch result."""

    summary_id: str
    sweep_id: str
    batch_id: str | None
    bind_count: int
    result_count: int
    created_count: int
    queued_count: int
    running_count: int
    completed_count: int
    partially_completed_count: int
    failed_count: int
    cancelled_count: int
    expired_count: int
    diagnostic_codes: tuple[str, ...]
    provenance_count: int = 0
    status: str = "unknown"
    metadata_only: bool = True
    artifact_bytes_read: bool = False
    backend_called_after_run: bool = False
    network_accessed: bool = False
    hardware_execution: bool = False
    cloud_execution: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SweepResultSummaryIR:
        """Build a sweep result summary from a dictionary."""
        return cls(
            summary_id=str(data["summary_id"]),
            sweep_id=str(data["sweep_id"]),
            batch_id=data.get("batch_id"),
            bind_count=int(data["bind_count"]),
            result_count=int(data["result_count"]),
            created_count=int(data["created_count"]),
            queued_count=int(data["queued_count"]),
            running_count=int(data["running_count"]),
            completed_count=int(data["completed_count"]),
            partially_completed_count=int(data["partially_completed_count"]),
            failed_count=int(data["failed_count"]),
            cancelled_count=int(data["cancelled_count"]),
            expired_count=int(data["expired_count"]),
            diagnostic_codes=tuple(
                str(code) for code in data.get("diagnostic_codes", ())
            ),
            provenance_count=int(data.get("provenance_count", 0)),
            status=str(data.get("status", "unknown")),
            metadata_only=bool(data.get("metadata_only", True)),
            artifact_bytes_read=bool(data.get("artifact_bytes_read", False)),
            backend_called_after_run=bool(
                data.get("backend_called_after_run", False)
            ),
            network_accessed=bool(data.get("network_accessed", False)),
            hardware_execution=bool(data.get("hardware_execution", False)),
            cloud_execution=bool(data.get("cloud_execution", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> SweepResultSummaryIR:
        """Build a sweep result summary from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("SweepResultSummaryIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class ParameterGrid(IRMixin):
    """A deterministic parameter sweep definition."""

    sweep_id: str
    parameter_schema: ParameterSchemaIR
    points: tuple[dict[str, float], ...]
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def explicit(
        cls,
        *,
        sweep_id: str,
        parameter_schema: ParameterSchemaIR,
        points: list[dict[str, float | int]] | tuple[dict[str, float | int], ...],
        metadata: dict[str, Any] | None = None,
    ) -> ParameterGrid:
        """Create a sweep from an explicit ordered list of bind points."""
        return cls(
            sweep_id=sweep_id,
            parameter_schema=parameter_schema,
            points=tuple(_normalize_point(point) for point in points),
            metadata={} if metadata is None else metadata,
        )

    @classmethod
    def cartesian(
        cls,
        *,
        sweep_id: str,
        parameter_schema: ParameterSchemaIR,
        grid: dict[str, list[float | int] | tuple[float | int, ...]],
        metadata: dict[str, Any] | None = None,
    ) -> ParameterGrid:
        """Create a sweep from a deterministic Cartesian product grid."""
        names = tuple(sorted(str(name) for name in grid))
        axes = tuple(tuple(float(value) for value in grid[name]) for name in names)
        points = tuple(
            {name: value for name, value in zip(names, values)}
            for values in itertools.product(*axes)
        )
        return cls(
            sweep_id=sweep_id,
            parameter_schema=parameter_schema,
            points=points,
            metadata={} if metadata is None else metadata,
        )

    def expand(self) -> ParameterSweepResult:
        """Expand this sweep into validated, duplicate-free bind records."""
        diagnostics: list[DiagnosticsIR] = []
        binds: list[ParameterBindIR] = []
        seen_bind_hashes: set[str] = set()
        duplicate_count = 0

        if not self.points:
            diagnostics.append(
                _diagnostic(
                    code="PARAMETER_SWEEP_EMPTY",
                    message="Parameter sweep does not contain any points.",
                    object_path="parameter_sweep.points",
                )
            )

        for index, point in enumerate(self.points):
            try:
                bind = ParameterBindIR.create(
                    parameter_bind_id=f"{self.sweep_id}.bind.{index:06d}",
                    parameter_schema=self.parameter_schema,
                    values=point,
                    metadata={
                        "sweep_id": self.sweep_id,
                        "sweep_index": index,
                        "sweep_source": self.metadata.get(
                            "source", "parameter_grid"
                        ),
                    },
                )
            except (ArithmeticError, TypeError, ValueError) as exc:
                diagnostics.append(
                    _diagnostic(
                        code=_bind_creation_code(exc),
                        message=f"Parameter sweep point is invalid: {exc}",
                        object_path=f"parameter_sweep.points[{index}]",
                        metadata={"sweep_index": index},
                    )
                )
                continue
            bind_diagnostics = bind.validate_against(self.parameter_schema)
            diagnostics.extend(
                _diagnostic(
                    code=code,
                    message="Canonical parameter bind validation failed.",
                    object_path=f"parameter_sweep.points[{index}]",
                )
                for code in bind_diagnostics
            )
            if bind.parameter_bind_hash in seen_bind_hashes:
                duplicate_count += 1
                diagnostics.append(
                    _diagnostic(
                        code="PARAMETER_SWEEP_DUPLICATE_POINT",
                        message="Parameter sweep contains a duplicate bind point.",
                        object_path=f"parameter_sweep.points[{index}]",
                        metadata={
                            "parameter_bind_hash": bind.parameter_bind_hash,
                            "sweep_index": index,
                        },
                    )
                )
                continue
            if bind_diagnostics:
                continue
            seen_bind_hashes.add(bind.parameter_bind_hash)
            binds.append(bind)

        return ParameterSweepResult(
            sweep_id=self.sweep_id,
            parameter_schema_hash=self.parameter_schema.stable_hash(),
            binds=tuple(binds),
            diagnostics=tuple(diagnostics),
            metadata={
                "point_count": len(self.points),
                "bind_count": len(binds),
                "duplicate_count": duplicate_count,
                "source": self.metadata.get("source", "parameter_grid"),
            },
        )


def build_sweep_result_summary(
    sweep_result: ParameterSweepResult,
    *,
    batch_result: Any | None = None,
    provenances: tuple[Any, ...] | list[Any] = (),
    summary_id: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> SweepResultSummaryIR:
    """Build a metadata-only summary for sweep and batch result evidence."""
    batch_summary = _batch_contract_summary(batch_result)
    boundary = _execution_boundary(batch_result)
    sweep_diagnostic_codes = [
        diagnostic.code for diagnostic in sweep_result.diagnostics
    ]
    batch_diagnostic_codes = list(batch_summary.get("diagnostic_codes", ()))
    diagnostic_codes = tuple(
        dict.fromkeys([*sweep_diagnostic_codes, *batch_diagnostic_codes])
    )
    bind_count = int(batch_summary.get("parameter_bind_count", len(sweep_result.binds)))
    result_count = int(batch_summary.get("result_count", 0))
    batch_id = None if batch_result is None else batch_result.batch_id

    return SweepResultSummaryIR(
        summary_id=summary_id or f"sweep_summary.{sweep_result.sweep_id}",
        sweep_id=sweep_result.sweep_id,
        batch_id=batch_id,
        bind_count=bind_count,
        result_count=result_count,
        created_count=0 if batch_result is None else batch_result.created_count,
        queued_count=0 if batch_result is None else batch_result.queued_count,
        running_count=0 if batch_result is None else batch_result.running_count,
        completed_count=0 if batch_result is None else batch_result.completed_count,
        partially_completed_count=(
            0 if batch_result is None else batch_result.partially_completed_count
        ),
        failed_count=0 if batch_result is None else batch_result.failed_count,
        cancelled_count=0 if batch_result is None else batch_result.cancelled_count,
        expired_count=0 if batch_result is None else batch_result.expired_count,
        diagnostic_codes=diagnostic_codes,
        provenance_count=len(tuple(provenances)),
        status="not_submitted" if batch_result is None else batch_result.status,
        metadata_only=bool(boundary.get("metadata_only", True)),
        artifact_bytes_read=bool(boundary.get("artifact_bytes_read", False)),
        backend_called_after_run=bool(boundary.get("backend_called_after_run", False)),
        network_accessed=bool(boundary.get("network_accessed", False)),
        hardware_execution=bool(boundary.get("hardware_execution", False)),
        cloud_execution=bool(boundary.get("cloud_execution", False)),
        metadata={
            "source": "sweep_result_summary",
            "parameter_schema_hash": sweep_result.parameter_schema_hash,
            "sweep_point_count": sweep_result.metadata.get("point_count"),
            "sweep_bind_count": sweep_result.metadata.get("bind_count"),
            "results_match_completed_count": batch_summary.get(
                "results_match_completed_count"
            ),
            "optimizer_result": False,
            "optimality_claim": "not_claimed",
            **({} if metadata is None else metadata),
        },
    )


def _normalize_point(point: dict[str, Any]) -> dict[str, float]:
    """Normalize a sweep point to deterministic float values."""
    return {str(name): float(point[name]) for name in sorted(point)}


def _batch_contract_summary(batch_result: Any | None) -> dict[str, Any]:
    if batch_result is None:
        return {}
    return dict(batch_result.metadata.get("contract_summary", {}))


def _execution_boundary(batch_result: Any | None) -> dict[str, Any]:
    if batch_result is None:
        return {
            "metadata_only": True,
            "artifact_bytes_read": False,
            "backend_called_after_run": False,
            "network_accessed": False,
            "hardware_execution": False,
            "cloud_execution": False,
        }
    return dict(batch_result.metadata.get("execution_boundary", {}))


def _diagnostic(
    *,
    code: str,
    message: str,
    object_path: str,
    metadata: dict[str, Any] | None = None,
) -> DiagnosticsIR:
    """Create a sweep expansion diagnostic."""
    return DiagnosticsIR(
        diagnostic_id=f"parameter_sweep.{code.lower()}",
        stage="validation",
        severity="error",
        code=code,
        message=message,
        object_path=object_path,
        metadata={} if metadata is None else metadata,
    )


def _bind_creation_code(exc: Exception) -> str:
    message = str(exc)
    if "unknown parameter" in message:
        return "PARAMETER_BIND_UNKNOWN_PARAMETER"
    if "required parameter" in message:
        return "PARAMETER_BIND_MISSING_REQUIRED"
    if "outside" in message:
        return "PARAMETER_BIND_VALUE_OUT_OF_RANGE"
    if "derived parameter" in message:
        return "PARAMETER_BIND_DERIVED_PARAMETER"
    if isinstance(exc, TypeError):
        return "PARAMETER_BIND_TYPE_ERROR"
    return "PARAMETER_BIND_INVALID"
