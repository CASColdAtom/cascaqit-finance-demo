"""Exact Digital-Analog-Digital lowering for optimization Problems."""

from __future__ import annotations

import math
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, Literal

from cascaqit.analog import AHSProgram, AtomRegister, SitePattern, Waveform
from cascaqit.compiler.problem_mapping import ProblemTermMappingIR
from cascaqit.digital import Circuit
from cascaqit.hybrid import HybridProgram
from cascaqit.parameters import Parameter, ParameterBindIR, ParameterSchemaIR
from cascaqit.parameters.canonical import ParameterScalar
from cascaqit.problems.analysis import ProblemAnalysisResult

__all__ = ["HybridDADLowerer", "HybridLoweringArtifacts"]

_MIN_ANALOG_GAMMA = 1e-12


@dataclass(frozen=True)
class HybridLoweringArtifacts:
    """Program, parameters, and conserved assignments produced by D-A-D lowering."""

    program: HybridProgram
    parameter_schema: ParameterSchemaIR
    parameter_bind: ParameterBindIR
    term_mapping: tuple[ProblemTermMappingIR, ...]


@dataclass(frozen=True)
class HybridDADLowerer:
    """Lower one feasible analysis to an exact commuting D-A-D program."""

    default_gamma: float = 0.4
    default_beta: float = 0.7

    def parameter_schema(self, layers: int = 1) -> ParameterSchemaIR:
        """Return canonical QAOA parameters for every D-A-D layer."""
        _require_positive_layers(layers)
        # 参数顺序与 Digital QAOA 保持一致，避免同一组参数在两种执行模式下
        # 产生不同的向量语义：先声明全部 cost 参数，再声明全部 mixer 参数。
        gammas = tuple(
            Parameter(
                f"gamma_{layer}",
                unit="rad",
                default=self.default_gamma,
                # gamma 同时决定 AHS 演化时长。零值或负值无法形成合法的
                # Analog block，因此在 canonical schema 中直接收紧边界。
                lower_bound=_MIN_ANALOG_GAMMA,
                compile_impact="recompile",
                metadata={
                    "controls": "analog_duration_and_digital_residual",
                    "layer": layer,
                    "non_positive_values": (
                        "unsupported_by_ahs_duration_contract"
                    ),
                },
            )
            for layer in range(layers)
        )
        betas = tuple(
            Parameter(
                f"beta_{layer}",
                unit="rad",
                default=self.default_beta,
                metadata={"controls": "digital_mixer", "layer": layer},
            )
            for layer in range(layers)
        )
        return ParameterSchemaIR(
            parameters=tuple(parameter.to_ir() for parameter in gammas + betas),
            metadata={
                "mode": "hybrid",
                "algorithm": "qaoa",
                "topology": "dad",
                "layers": layers,
            },
        )

    def lower(
        self,
        analysis: ProblemAnalysisResult,
        *,
        layers: int = 1,
    ) -> HybridLoweringArtifacts:
        """Build a default-bound D-A-D program from one shared mapping plan."""
        _require_positive_layers(layers)
        _require_feasible_analysis(analysis)
        term_mapping = self.term_mapping(analysis)
        if not any(
            abs(item.analog_coefficient) > analysis.mapping_plan.absolute_tolerance
            for item in term_mapping
        ):
            raise ValueError("Hybrid D-A-D requires a non-empty Analog contribution.")
        schema = self.parameter_schema(layers)
        parameter_bind = ParameterBindIR.create(
            parameter_bind_id=f"{analysis.analysis_id}.hybrid.default",
            parameter_schema=schema,
            values={},
            metadata={
                "mode": "hybrid",
                "algorithm": "qaoa",
                "topology": "dad",
                "layers": layers,
                "binding_role": "default_preview",
            },
        )
        program = self.build_program(
            analysis,
            term_mapping=term_mapping,
            values=parameter_bind.values,
            layers=layers,
        )
        return HybridLoweringArtifacts(
            program=program,
            parameter_schema=schema,
            parameter_bind=parameter_bind,
            term_mapping=term_mapping,
        )

    def bind(
        self,
        analysis: ProblemAnalysisResult,
        *,
        parameter_schema: ParameterSchemaIR,
        term_mapping: tuple[ProblemTermMappingIR, ...],
        values: Mapping[str, float],
        layers: int = 1,
    ) -> tuple[HybridProgram, ParameterBindIR]:
        """Validate parameters and rebuild every duration and gate angle."""
        _require_positive_layers(layers)
        parameter_bind = ParameterBindIR.create(
            parameter_bind_id=f"{analysis.analysis_id}.hybrid.bind",
            parameter_schema=parameter_schema,
            values=values,
            metadata={
                "mode": "hybrid",
                "algorithm": "qaoa",
                "topology": "dad",
                "layers": layers,
            },
        )
        program = self.build_program(
            analysis,
            term_mapping=term_mapping,
            values=parameter_bind.values,
            layers=layers,
        )
        return program, parameter_bind

    def term_mapping(
        self,
        analysis: ProblemAnalysisResult,
    ) -> tuple[ProblemTermMappingIR, ...]:
        """Split every logical and unintended physical term exactly."""
        _require_feasible_analysis(analysis)
        feasibility = analysis.mapping_plan.feasibility_for("hybrid")
        assert feasibility.energy_scale is not None
        energy_scale = feasibility.energy_scale
        detuning_kind = _detuning_implementation(feasibility.metadata)
        required_detuning = _required_detuning(feasibility.metadata)
        interactions = {
            (item.left, item.right): item
            for item in analysis.mapping_plan.interactions
            if item.reference_coefficient > 0.0
        }
        normalized_pairs = {
            pair: item.reference_coefficient / (4.0 * energy_scale)
            for pair, item in interactions.items()
        }
        pair_sum = {name: 0.0 for name in analysis.canonical_problem.logical_order}
        for (left, right), coefficient in normalized_pairs.items():
            pair_sum[left] += coefficient
            pair_sum[right] += coefficient
        detuning = (
            required_detuning
            if detuning_kind != "unsupported"
            else {name: 0.0 for name in pair_sum}
        )
        analog_z = {
            name: detuning.get(name, 0.0) / (2.0 * energy_scale) - pair_sum[name]
            for name in pair_sum
        }

        logical_z = {
            term.targets[0]: term
            for term in analysis.logical_hamiltonian.terms
            if term.operator == "z"
        }
        logical_pairs = {
            _pair_key(term.targets): term
            for term in analysis.logical_hamiltonian.terms
            if term.operator == "zz"
        }
        mappings: list[ProblemTermMappingIR] = []
        for term in analysis.logical_hamiltonian.terms:
            analog = (
                analog_z[term.targets[0]]
                if term.operator == "z"
                else normalized_pairs.get(_pair_key(term.targets), 0.0)
            )
            mappings.append(
                _term_mapping(
                    analysis,
                    logical_term_id=term.term_id,
                    source_term_ids=term.source_term_ids,
                    operator=term.operator,
                    targets=term.targets,
                    logical_coefficient=term.coefficient,
                    analog_coefficient=analog,
                    detuning_kind=detuning_kind,
                )
            )
        for name in analysis.canonical_problem.logical_order:
            if name in logical_z or math.isclose(
                analog_z[name],
                0.0,
                abs_tol=analysis.mapping_plan.absolute_tolerance,
            ):
                continue
            mappings.append(
                _term_mapping(
                    analysis,
                    logical_term_id=f"synthetic.z.{name}",
                    source_term_ids=(),
                    operator="z",
                    targets=(name,),
                    logical_coefficient=0.0,
                    analog_coefficient=analog_z[name],
                    detuning_kind=detuning_kind,
                )
            )
        for pair, coefficient in sorted(normalized_pairs.items()):
            if pair in logical_pairs:
                continue
            mappings.append(
                _term_mapping(
                    analysis,
                    logical_term_id=f"synthetic.zz.{pair[0]}.{pair[1]}",
                    source_term_ids=(),
                    operator="zz",
                    targets=pair,
                    logical_coefficient=0.0,
                    analog_coefficient=coefficient,
                    detuning_kind=detuning_kind,
                )
            )
        return tuple(mappings)

    def build_program(
        self,
        analysis: ProblemAnalysisResult,
        *,
        term_mapping: tuple[ProblemTermMappingIR, ...],
        values: Mapping[str, ParameterScalar],
        layers: int = 1,
    ) -> HybridProgram:
        """Build one fully numeric Native Hybrid program for a parameter bind."""
        _require_positive_layers(layers)
        _require_feasible_analysis(analysis)
        gammas = tuple(float(values[f"gamma_{layer}"]) for layer in range(layers))
        betas = tuple(float(values[f"beta_{layer}"]) for layer in range(layers))
        feasibility = analysis.mapping_plan.feasibility_for("hybrid")
        assert feasibility.energy_scale is not None
        logical_order = analysis.canonical_problem.logical_order

        prepare = Circuit(
            logical_order,
            program_id=f"program.{analysis.canonical_problem.problem_id}.dad.prepare",
            metadata={
                "role": "uniform_superposition",
                "topology": "dad",
                "layers": layers,
            },
        )
        for qubit in logical_order:
            prepare.h(qubit)
        parameter_values = {
            **{f"gamma_{layer}": gammas[layer] for layer in range(layers)},
            **{f"beta_{layer}": betas[layer] for layer in range(layers)},
        }
        program = HybridProgram(
            f"program.{analysis.canonical_problem.problem_id}.dad",
            metadata={
                "mode": "hybrid",
                "algorithm": "qaoa",
                "topology": "dad",
                "layers": layers,
                "analysis_hash": analysis.analysis_hash,
                "problem_hash": analysis.canonical_problem.problem_hash,
                "energy_scale": feasibility.energy_scale,
                "parameter_values": parameter_values,
                "local_reference": True,
                "hardware_executable": False,
            },
        )
        program = program.digital("prepare", prepare)

        # 每层先执行由 Analog 硬件承担的 cost contribution，再执行严格补齐
        # Hamiltonian 的 Digital residual 和 mixer。这样只制备一次初态，同时
        # 保持与标准 p 层 QAOA 完全相同的算符顺序。
        for layer, (gamma, beta) in enumerate(zip(gammas, betas)):
            duration = gamma / feasibility.energy_scale
            analog = _analog_cost_program(
                analysis,
                duration=duration,
                layer=layer,
            )
            residual = Circuit(
                logical_order,
                program_id=(
                    f"program.{analysis.canonical_problem.problem_id}.dad."
                    f"residual_mixer.{layer}"
                ),
                metadata={
                    "role": "cost_residual_and_mixer",
                    "topology": "dad",
                    "layer": layer,
                    f"gamma_{layer}": gamma,
                    f"beta_{layer}": beta,
                },
            )
            for item in term_mapping:
                coefficient = item.digital_coefficient
                if math.isclose(
                    coefficient,
                    0.0,
                    abs_tol=analysis.mapping_plan.absolute_tolerance,
                ):
                    continue
                angle = 2.0 * coefficient * gamma
                if item.operator == "z":
                    residual.rz(angle, item.targets[0])
                else:
                    left, right = item.targets
                    residual.cx(left, right).rz(angle, right).cx(left, right)
            for qubit in logical_order:
                residual.rx(2.0 * beta, qubit)
            program = program.analog(f"cost_{layer}", analog)
            program = program.digital(f"residual_mixer_{layer}", residual)

        program = program.measure_all(key="problem")
        compiled = program.compile()
        if compiled.plan is None:
            raise ValueError("Generated Hybrid D-A-D program failed compile preflight.")
        program.to_ir()
        return program


def _analog_cost_program(
    analysis: ProblemAnalysisResult,
    *,
    duration: float,
    layer: int,
) -> AHSProgram:
    feasibility = analysis.mapping_plan.feasibility_for("hybrid")
    detuning_kind = _detuning_implementation(feasibility.metadata)
    required = _required_detuning(feasibility.metadata)
    sites = analysis.mapping_plan.layout.sites
    logical_order = analysis.canonical_problem.logical_order
    by_name = {item.logical_id: item for item in sites}
    register = AtomRegister.custom(
        tuple(by_name[name].position for name in logical_order),
        site_ids=logical_order,
        atom_ids=logical_order,
    )
    global_detuning = (
        required[logical_order[0]] if detuning_kind == "analog_detuning_global" else 0.0
    )
    program = AHSProgram(
        register,
        program_id=(
            f"program.{analysis.canonical_problem.problem_id}.dad.cost.{layer}"
        ),
    ).drive(
        rabi=Waveform.constant(
            0.0,
            duration=duration,
            waveform_id=f"dad.cost.{layer}.rabi",
        ),
        detuning=Waveform.constant(
            global_detuning,
            duration=duration,
            waveform_id=f"dad.cost.{layer}.detuning.global",
        ),
        phase=0.0,
    )
    if detuning_kind == "analog_detuning_local":
        for name in logical_order:
            value = required[name]
            if math.isclose(
                value,
                0.0,
                abs_tol=analysis.mapping_plan.absolute_tolerance,
            ):
                continue
            program.local_detuning(
                waveform=Waveform.constant(
                    value,
                    duration=duration,
                    waveform_id=f"dad.cost.{layer}.detuning.{name}",
                ),
                pattern=SitePattern(
                    site_ids=logical_order,
                    weights=tuple(
                        1.0 if item == name else 0.0 for item in logical_order
                    ),
                ),
            )
    return program


def _term_mapping(
    analysis: ProblemAnalysisResult,
    *,
    logical_term_id: str,
    source_term_ids: tuple[str, ...],
    operator: Literal["z", "zz"],
    targets: tuple[str, ...],
    logical_coefficient: float,
    analog_coefficient: float,
    detuning_kind: str,
) -> ProblemTermMappingIR:
    digital = logical_coefficient - analog_coefficient
    tolerance = analysis.mapping_plan.absolute_tolerance
    analog_present = not math.isclose(analog_coefficient, 0.0, abs_tol=tolerance)
    digital_present = not math.isclose(digital, 0.0, abs_tol=tolerance)
    implementation: Literal[
        "digital_gate",
        "analog_detuning_global",
        "analog_detuning_local",
        "analog_interaction",
        "hybrid_split",
    ]
    if analog_present and digital_present:
        implementation = "hybrid_split"
    elif not analog_present:
        implementation = "digital_gate"
    elif operator == "zz":
        implementation = "analog_interaction"
    elif detuning_kind == "analog_detuning_global":
        implementation = "analog_detuning_global"
    elif detuning_kind == "analog_detuning_local":
        implementation = "analog_detuning_local"
    else:
        implementation = "hybrid_split"
    return ProblemTermMappingIR(
        mapping_id=f"mapping.hybrid.{logical_term_id}",
        logical_term_id=logical_term_id,
        source_term_ids=source_term_ids,
        operator=operator,
        targets=targets,
        logical_coefficient=logical_coefficient,
        analog_coefficient=analog_coefficient,
        digital_coefficient=digital,
        implementation=implementation,
        absolute_tolerance=analysis.mapping_plan.absolute_tolerance,
        relative_tolerance=analysis.mapping_plan.relative_tolerance,
    )


def _require_feasible_analysis(analysis: ProblemAnalysisResult) -> None:
    if not isinstance(analysis, ProblemAnalysisResult):
        raise TypeError("analysis must be ProblemAnalysisResult.")
    if not analysis.mapping_plan.feasibility_for("hybrid").feasible:
        raise ValueError("Hybrid lowering requires a feasible mapping plan.")


def _require_positive_layers(layers: int) -> None:
    """Reject values that cannot describe a finite QAOA layer sequence."""
    if not isinstance(layers, int) or isinstance(layers, bool) or layers <= 0:
        raise ValueError("layers must be a positive integer.")


def _detuning_implementation(metadata: dict[str, Any]) -> str:
    value = str(metadata.get("detuning_implementation", "unsupported"))
    if value not in {
        "analog_detuning_global",
        "analog_detuning_local",
        "unsupported",
    }:
        raise ValueError("Hybrid mapping has an invalid detuning implementation.")
    return value


def _required_detuning(metadata: dict[str, Any]) -> dict[str, float]:
    raw = metadata.get("required_detuning", {})
    if not isinstance(raw, dict):
        raise TypeError("required_detuning must be a dictionary.")
    return {str(name): float(value) for name, value in raw.items()}


def _pair_key(targets: tuple[str, ...]) -> tuple[str, str]:
    if len(targets) != 2:
        raise ValueError("A pair key requires exactly two targets.")
    left, right = sorted(targets)
    return left, right
