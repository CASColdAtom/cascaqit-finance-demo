"""Compiler skeleton for CASCAQit native programs."""

from __future__ import annotations

from importlib import import_module
from typing import Any

from cascaqit.compiler.cache import (
    CompileCacheKeyIR,
    CompileCacheReportIR,
    build_compile_cache_invalidation_report,
    build_compile_cache_key,
    build_compile_cache_report,
)
from cascaqit.compiler.pass_pipeline import (
    CompilerPassPipelineIR,
    CompilerPassRecordIR,
    build_compiler_pass_pipeline,
)
from cascaqit.compiler.pipeline import (
    COMPILER_VERSION,
    CompilerOptions,
    CompilerPipeline,
)
from cascaqit.compiler.problem import (
    LOGICAL_HAMILTONIAN_SCHEMA_VERSION,
    LogicalHamiltonianIR,
    LogicalHamiltonianTermIR,
    build_logical_hamiltonian,
)
from cascaqit.compiler.problem_mapping import (
    PROBLEM_MAPPING_SCHEMA_VERSION,
    ModeFeasibilityIR,
    ProblemLayoutIR,
    ProblemLayoutSiteIR,
    ProblemMappingPlanIR,
    ProblemMappingPlanner,
    ProblemTermMappingIR,
    ReferenceInteractionIR,
    TermImplementationCandidateIR,
)

_EXPORT_MODULES = {
    "QAAProtocolIR": "cascaqit.compiler.problem_analog",
}

__all__ = [
    "COMPILER_VERSION",
    "CompileCacheKeyIR",
    "CompileCacheReportIR",
    "CompilerOptions",
    "CompilerPassPipelineIR",
    "CompilerPassRecordIR",
    "CompilerPipeline",
    "LOGICAL_HAMILTONIAN_SCHEMA_VERSION",
    "LogicalHamiltonianIR",
    "LogicalHamiltonianTermIR",
    "ModeFeasibilityIR",
    "PROBLEM_MAPPING_SCHEMA_VERSION",
    "ProblemLayoutIR",
    "ProblemLayoutSiteIR",
    "ProblemMappingPlanIR",
    "ProblemMappingPlanner",
    "ProblemTermMappingIR",
    "QAAProtocolIR",
    "ReferenceInteractionIR",
    "TermImplementationCandidateIR",
    "build_compile_cache_invalidation_report",
    "build_compile_cache_key",
    "build_compile_cache_report",
    "build_compiler_pass_pipeline",
    "build_logical_hamiltonian",
]


def __getattr__(name: str) -> Any:
    """Lazily resolve compiler exports that depend on Problem analysis."""
    try:
        module_name = _EXPORT_MODULES[name]
    except KeyError as exc:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}") from exc
    value = getattr(import_module(module_name), name)
    globals()[name] = value
    return value
