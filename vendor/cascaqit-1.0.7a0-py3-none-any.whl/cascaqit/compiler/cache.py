"""Deterministic compile cache metadata contracts."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Literal

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.native_ir.base import IRMixin, canonicalize
from cascaqit.native_ir.models import SCHEMA_VERSION
from cascaqit.readiness.audit import redact_audit_metadata

__all__ = [
    "CompileCacheKeyIR",
    "CompileCacheReportIR",
    "build_compile_cache_key",
    "build_compile_cache_invalidation_report",
    "build_compile_cache_report",
]

CacheStatus = Literal["hit", "miss"]
_CACHE_STATUSES: tuple[CacheStatus, ...] = ("hit", "miss")


@dataclass(frozen=True)
class CompileCacheKeyIR(IRMixin):
    """Stable compile cache key payload and digest."""

    cache_key: str
    source_program_hash: str
    discretized_program_hash: str
    target_snapshot_hash: str
    compiler_version: str
    compiler_options_hash: str
    parameter_schema_hash: str
    bit_order_version: str
    optimization_level: int
    frontend: str = "cascaqit_native"
    key_schema_version: str = "compile_cache_key.v2"
    metadata_only: bool = True
    remote_cache_used: bool = False
    filesystem_cache_used: bool = False
    network_accessed: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize cache key fields and enforce offline boundaries."""
        if not self.metadata_only:
            raise ValueError("CompileCacheKeyIR must be metadata-only.")
        if self.remote_cache_used:
            raise ValueError("CompileCacheKeyIR must not use remote cache.")
        if self.filesystem_cache_used:
            raise ValueError("CompileCacheKeyIR must not use filesystem cache.")
        if self.network_accessed:
            raise ValueError("CompileCacheKeyIR cannot access networks.")
        object.__setattr__(self, "optimization_level", int(self.optimization_level))
        if self.optimization_level != 0:
            raise ValueError("Reference compile cache keys only support O0.")
        if self.key_schema_version != "compile_cache_key.v2":
            raise ValueError("CompileCacheKeyIR requires compile_cache_key.v2.")
        object.__setattr__(self, "metadata", redact_audit_metadata(self.metadata))

    @property
    def key_components(self) -> dict[str, Any]:
        """Return the public reference-semantics-sensitive key components."""
        return {
            "source_program_hash": self.source_program_hash,
            "discretized_program_hash": self.discretized_program_hash,
            "target_snapshot_hash": self.target_snapshot_hash,
            "compiler_version": self.compiler_version,
            "compiler_options_hash": self.compiler_options_hash,
            "parameter_schema_hash": self.parameter_schema_hash,
            "bit_order_version": self.bit_order_version,
            "optimization_level": self.optimization_level,
            "frontend": self.frontend,
            "key_schema_version": self.key_schema_version,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CompileCacheKeyIR:
        """Build cache key IR from a dictionary."""
        if not isinstance(data, dict):
            raise TypeError("CompileCacheKeyIR dictionary must be an object.")
        return cls(
            cache_key=str(data["cache_key"]),
            source_program_hash=str(data["source_program_hash"]),
            discretized_program_hash=str(data["discretized_program_hash"]),
            target_snapshot_hash=str(data["target_snapshot_hash"]),
            compiler_version=str(data["compiler_version"]),
            compiler_options_hash=str(data["compiler_options_hash"]),
            parameter_schema_hash=str(data["parameter_schema_hash"]),
            bit_order_version=str(data["bit_order_version"]),
            optimization_level=int(data["optimization_level"]),
            frontend=str(data.get("frontend", "cascaqit_native")),
            key_schema_version=str(
                data.get("key_schema_version", "compile_cache_key.v2")
            ),
            metadata_only=bool(data.get("metadata_only", True)),
            remote_cache_used=bool(data.get("remote_cache_used", False)),
            filesystem_cache_used=bool(data.get("filesystem_cache_used", False)),
            network_accessed=bool(data.get("network_accessed", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> CompileCacheKeyIR:
        """Build cache key IR from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("CompileCacheKeyIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class CompileCacheReportIR(IRMixin):
    """Metadata-only local compile cache lookup report."""

    report_id: str
    status: CacheStatus
    cache_key: str
    cache_key_ir: CompileCacheKeyIR
    matched_compiled_program_hash: str | None = None
    mismatch_reasons: tuple[str, ...] = ()
    invalidation_checks: tuple[dict[str, Any], ...] | None = None
    diagnostics: tuple[DiagnosticsIR, ...] | None = None
    metadata_only: bool = True
    cache_write_performed: bool = False
    remote_cache_used: bool = False
    filesystem_cache_used: bool = False
    network_accessed: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize cache report fields and enforce local metadata boundaries."""
        if self.status not in _CACHE_STATUSES:
            raise ValueError(f"Unsupported compile cache status: {self.status}")
        if not self.metadata_only:
            raise ValueError("CompileCacheReportIR must be metadata-only.")
        if self.cache_write_performed:
            raise ValueError("CompileCacheReportIR must not write cache entries.")
        if self.remote_cache_used:
            raise ValueError("CompileCacheReportIR must not use remote cache.")
        if self.filesystem_cache_used:
            raise ValueError("CompileCacheReportIR must not use filesystem cache.")
        if self.network_accessed:
            raise ValueError("CompileCacheReportIR cannot access networks.")
        key_ir = (
            self.cache_key_ir
            if isinstance(self.cache_key_ir, CompileCacheKeyIR)
            else CompileCacheKeyIR.from_dict(self.cache_key_ir)
        )
        if self.cache_key != key_ir.cache_key:
            raise ValueError("CompileCacheReportIR cache_key must match key IR.")
        object.__setattr__(self, "cache_key_ir", key_ir)
        object.__setattr__(
            self,
            "mismatch_reasons",
            tuple(sorted(str(reason) for reason in self.mismatch_reasons)),
        )
        object.__setattr__(
            self,
            "invalidation_checks",
            None
            if self.invalidation_checks is None
            else tuple(canonicalize(check) for check in self.invalidation_checks),
        )
        object.__setattr__(
            self,
            "diagnostics",
            None
            if self.diagnostics is None
            else tuple(_diagnostic_from_any(item) for item in self.diagnostics),
        )
        object.__setattr__(self, "metadata", redact_audit_metadata(self.metadata))

    def to_dict(self) -> dict[str, Any]:
        """Return report payload while preserving pre-invalidation compatibility."""
        data = super().to_dict()
        if self.invalidation_checks is None:
            data.pop("invalidation_checks", None)
        if self.diagnostics is None:
            data.pop("diagnostics", None)
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CompileCacheReportIR:
        """Build cache report IR from a dictionary."""
        if not isinstance(data, dict):
            raise TypeError("CompileCacheReportIR dictionary must be an object.")
        return cls(
            report_id=str(data["report_id"]),
            status=data["status"],
            cache_key=str(data["cache_key"]),
            cache_key_ir=CompileCacheKeyIR.from_dict(data["cache_key_ir"]),
            matched_compiled_program_hash=data.get("matched_compiled_program_hash"),
            mismatch_reasons=tuple(
                str(reason) for reason in data.get("mismatch_reasons", ())
            ),
            invalidation_checks=None
            if "invalidation_checks" not in data
            else tuple(dict(check) for check in data.get("invalidation_checks", ())),
            diagnostics=None
            if "diagnostics" not in data
            else tuple(
                _diagnostic_from_any(item) for item in data.get("diagnostics", ())
            ),
            metadata_only=bool(data.get("metadata_only", True)),
            cache_write_performed=bool(data.get("cache_write_performed", False)),
            remote_cache_used=bool(data.get("remote_cache_used", False)),
            filesystem_cache_used=bool(data.get("filesystem_cache_used", False)),
            network_accessed=bool(data.get("network_accessed", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> CompileCacheReportIR:
        """Build cache report IR from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("CompileCacheReportIR JSON must contain an object.")
        return cls.from_dict(data)


def build_compile_cache_key(
    *,
    source_program_hash: str,
    discretized_program_hash: str,
    target_snapshot_hash: str,
    compiler_version: str,
    compiler_options: dict[str, Any],
    optimization_level: int,
    parameter_schema_hash: str,
    bit_order_version: str,
    frontend: str = "cascaqit_native",
    metadata: dict[str, Any] | None = None,
) -> CompileCacheKeyIR:
    """Build a deterministic compile cache key without cache IO."""
    compiler_options_hash = _hash_dict(compiler_options)
    components = {
        "source_program_hash": source_program_hash,
        "discretized_program_hash": discretized_program_hash,
        "target_snapshot_hash": target_snapshot_hash,
        "compiler_version": compiler_version,
        "compiler_options_hash": compiler_options_hash,
        "optimization_level": int(optimization_level),
        "parameter_schema_hash": parameter_schema_hash,
        "bit_order_version": bit_order_version,
        "frontend": frontend,
        "key_schema_version": "compile_cache_key.v2",
    }
    return CompileCacheKeyIR(
        cache_key=_hash_dict(components),
        source_program_hash=source_program_hash,
        discretized_program_hash=discretized_program_hash,
        target_snapshot_hash=target_snapshot_hash,
        compiler_version=compiler_version,
        compiler_options_hash=compiler_options_hash,
        parameter_schema_hash=parameter_schema_hash,
        bit_order_version=bit_order_version,
        optimization_level=optimization_level,
        frontend=frontend,
        key_schema_version="compile_cache_key.v2",
        metadata_only=True,
        remote_cache_used=False,
        filesystem_cache_used=False,
        network_accessed=False,
        metadata={
            "builder": "build_compile_cache_key",
            "metadata_only": True,
            "compiler_options": canonicalize(compiler_options),
            **({} if metadata is None else metadata),
        },
    )


def build_compile_cache_report(
    cache_key_ir: CompileCacheKeyIR,
    *,
    cached_entries: dict[str, str] | None = None,
    report_id: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> CompileCacheReportIR:
    """Build a deterministic local cache lookup report without cache IO."""
    if not isinstance(cache_key_ir, CompileCacheKeyIR):
        raise TypeError("cache_key_ir must be CompileCacheKeyIR.")
    entries = {} if cached_entries is None else dict(cached_entries)
    matched_hash = entries.get(cache_key_ir.cache_key)
    return CompileCacheReportIR(
        report_id=report_id or f"compile_cache.{cache_key_ir.cache_key[:16]}",
        status="hit" if matched_hash else "miss",
        cache_key=cache_key_ir.cache_key,
        cache_key_ir=cache_key_ir,
        matched_compiled_program_hash=matched_hash,
        mismatch_reasons=()
        if matched_hash
        else ("cache_entry_absent",),
        invalidation_checks=None,
        diagnostics=None,
        metadata_only=True,
        cache_write_performed=False,
        remote_cache_used=False,
        filesystem_cache_used=False,
        network_accessed=False,
        metadata={
            "builder": "build_compile_cache_report",
            "metadata_only": True,
            "lookup_scope": "caller_supplied_local_metadata",
            "cache_entry_count": len(entries),
            **({} if metadata is None else metadata),
        },
    )


def build_compile_cache_invalidation_report(
    expected_cache_key_ir: CompileCacheKeyIR,
    candidate_cache_key_ir: CompileCacheKeyIR,
    *,
    matched_compiled_program_hash: str | None = None,
    report_id: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> CompileCacheReportIR:
    """Explain why a candidate cache key cannot satisfy an expected key."""
    if not isinstance(expected_cache_key_ir, CompileCacheKeyIR):
        raise TypeError("expected_cache_key_ir must be CompileCacheKeyIR.")
    if not isinstance(candidate_cache_key_ir, CompileCacheKeyIR):
        raise TypeError("candidate_cache_key_ir must be CompileCacheKeyIR.")
    checks = _cache_key_invalidation_checks(
        expected_cache_key_ir,
        candidate_cache_key_ir,
    )
    mismatch_reasons = tuple(
        str(check["reason"])
        for check in checks
        if not bool(check["passed"])
    )
    diagnostics = tuple(
        _diagnostic_from_invalidation_check(check)
        for check in checks
        if not bool(check["passed"])
    )
    return CompileCacheReportIR(
        report_id=(
            report_id
            or f"compile_cache.invalidate.{expected_cache_key_ir.cache_key[:16]}"
        ),
        status="hit" if not mismatch_reasons else "miss",
        cache_key=expected_cache_key_ir.cache_key,
        cache_key_ir=expected_cache_key_ir,
        matched_compiled_program_hash=(
            matched_compiled_program_hash if not mismatch_reasons else None
        ),
        mismatch_reasons=mismatch_reasons,
        invalidation_checks=checks,
        diagnostics=diagnostics,
        metadata_only=True,
        cache_write_performed=False,
        remote_cache_used=False,
        filesystem_cache_used=False,
        network_accessed=False,
        metadata={
            "builder": "build_compile_cache_invalidation_report",
            "metadata_only": True,
            "candidate_cache_key": candidate_cache_key_ir.cache_key,
            "candidate_key_schema_version": candidate_cache_key_ir.key_schema_version,
            "expected_key_schema_version": expected_cache_key_ir.key_schema_version,
            **({} if metadata is None else metadata),
        },
    )


def _cache_key_invalidation_checks(
    expected: CompileCacheKeyIR,
    candidate: CompileCacheKeyIR,
) -> tuple[dict[str, Any], ...]:
    fields = (
        "source_program_hash",
        "discretized_program_hash",
        "target_snapshot_hash",
        "compiler_version",
        "compiler_options_hash",
        "parameter_schema_hash",
        "bit_order_version",
        "optimization_level",
        "frontend",
        "key_schema_version",
    )
    return tuple(
        _cache_key_check(
            field_name,
            expected=getattr(expected, field_name),
            actual=getattr(candidate, field_name),
        )
        for field_name in fields
    )


def _cache_key_check(
    field_name: str,
    *,
    expected: Any,
    actual: Any,
) -> dict[str, Any]:
    return {
        "check_id": f"cache_key_{field_name}_matches",
        "field": field_name,
        "passed": expected == actual,
        "reason": f"{field_name}_mismatch",
        "code": _cache_key_mismatch_code(field_name),
        "message": f"Compile cache key field {field_name} does not match.",
        "object_path": f"compile_cache_key.{field_name}",
        "expected": expected,
        "actual": actual,
        "metadata_only": True,
    }


def _cache_key_mismatch_code(field_name: str) -> str:
    return f"COMPILE_CACHE_{field_name.upper()}_MISMATCH"


def _diagnostic_from_invalidation_check(check: dict[str, Any]) -> DiagnosticsIR:
    return DiagnosticsIR(
        diagnostic_id=f"compile_cache.invalidate.{check['field']}",
        stage="compilation",
        severity="warning",
        code=str(check["code"]),
        message=str(check["message"]),
        object_path=str(check["object_path"]),
        suggestion=(
            "Treat the cached compiled artifact as invalid for this compile "
            "request and rebuild from current inputs."
        ),
        metadata={
            "field": check["field"],
            "expected": check["expected"],
            "actual": check["actual"],
            "reason": check["reason"],
            "metadata_only": True,
            "remote_cache_used": False,
        },
    )


def _diagnostic_from_any(item: DiagnosticsIR | dict[str, Any]) -> DiagnosticsIR:
    if isinstance(item, DiagnosticsIR):
        return item
    if isinstance(item, dict):
        return DiagnosticsIR.from_dict(item)
    raise TypeError("diagnostics must contain DiagnosticsIR or dictionaries.")


def _hash_dict(payload: dict[str, Any]) -> str:
    import hashlib

    from cascaqit.native_ir.base import stable_json

    return hashlib.sha256(stable_json(payload).encode("utf-8")).hexdigest()
