"""Compiler pass pipeline metadata contracts."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Literal, cast

from cascaqit.native_ir.base import IRMixin, canonicalize
from cascaqit.native_ir.models import SCHEMA_VERSION
from cascaqit.readiness.audit import redact_audit_metadata

__all__ = [
    "CompilerPassPipelineIR",
    "CompilerPassRecordIR",
    "build_compiler_pass_pipeline",
]

PassStatus = Literal["ok", "warning", "blocked"]
_PASS_STATUSES: tuple[PassStatus, ...] = ("ok", "warning", "blocked")


@dataclass(frozen=True)
class CompilerPassRecordIR(IRMixin):
    """Metadata-only record for one deterministic compiler pass."""

    pass_index: int
    pass_name: str
    stage: str
    status: PassStatus
    reason_category: str
    input_hashes: dict[str, Any]
    output_hashes: dict[str, Any]
    diagnostic_codes: tuple[str, ...] = ()
    diagnostic_count: int = 0
    error_count: int = 0
    warning_count: int = 0
    metadata_only: bool = True
    backend_called: bool = False
    network_accessed: bool = False
    live_hardware_claimed: bool = False
    cloud_compile_used: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize nested payloads and enforce offline pass boundaries."""
        if self.status not in _PASS_STATUSES:
            raise ValueError(f"Unsupported compiler pass status: {self.status}")
        if not self.metadata_only:
            raise ValueError("CompilerPassRecordIR must be metadata-only.")
        if self.backend_called:
            raise ValueError("CompilerPassRecordIR must not call backends.")
        if self.network_accessed:
            raise ValueError("CompilerPassRecordIR cannot access networks.")
        if self.live_hardware_claimed:
            raise ValueError("CompilerPassRecordIR must not claim live hardware.")
        if self.cloud_compile_used:
            raise ValueError("CompilerPassRecordIR must not use cloud compile.")
        object.__setattr__(self, "pass_index", int(self.pass_index))
        object.__setattr__(
            self,
            "diagnostic_codes",
            tuple(sorted({str(code) for code in self.diagnostic_codes})),
        )
        object.__setattr__(self, "input_hashes", canonicalize(self.input_hashes))
        object.__setattr__(self, "output_hashes", canonicalize(self.output_hashes))
        object.__setattr__(self, "metadata", redact_audit_metadata(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CompilerPassRecordIR:
        """Build a pass record from a JSON-compatible dictionary."""
        if not isinstance(data, dict):
            raise TypeError("CompilerPassRecordIR dictionary must be an object.")
        return cls(
            pass_index=int(data["pass_index"]),
            pass_name=str(data["pass_name"]),
            stage=str(data.get("stage", "compilation")),
            status=cast(PassStatus, data["status"]),
            reason_category=str(data["reason_category"]),
            input_hashes=dict(data.get("input_hashes", {})),
            output_hashes=dict(data.get("output_hashes", {})),
            diagnostic_codes=tuple(
                str(code) for code in data.get("diagnostic_codes", ())
            ),
            diagnostic_count=int(data.get("diagnostic_count", 0)),
            error_count=int(data.get("error_count", 0)),
            warning_count=int(data.get("warning_count", 0)),
            metadata_only=bool(data.get("metadata_only", True)),
            backend_called=bool(data.get("backend_called", False)),
            network_accessed=bool(data.get("network_accessed", False)),
            live_hardware_claimed=bool(data.get("live_hardware_claimed", False)),
            cloud_compile_used=bool(data.get("cloud_compile_used", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> CompilerPassRecordIR:
        """Build a pass record from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("CompilerPassRecordIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class CompilerPassPipelineIR(IRMixin):
    """Metadata-only summary for an ordered compiler pass pipeline."""

    pipeline_id: str
    program_type: str
    compiler_version: str
    pass_count: int
    records: tuple[CompilerPassRecordIR, ...]
    status: PassStatus
    input_hashes: dict[str, Any]
    output_hashes: dict[str, Any]
    diagnostic_summary: dict[str, Any]
    metadata_only: bool = True
    backend_called: bool = False
    network_accessed: bool = False
    live_hardware_claimed: bool = False
    cloud_compile_used: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize pass records and enforce offline compiler boundaries."""
        if self.status not in _PASS_STATUSES:
            raise ValueError(f"Unsupported compiler pipeline status: {self.status}")
        if not self.metadata_only:
            raise ValueError("CompilerPassPipelineIR must be metadata-only.")
        if self.backend_called:
            raise ValueError("CompilerPassPipelineIR must not call backends.")
        if self.network_accessed:
            raise ValueError("CompilerPassPipelineIR cannot access networks.")
        if self.live_hardware_claimed:
            raise ValueError("CompilerPassPipelineIR must not claim live hardware.")
        if self.cloud_compile_used:
            raise ValueError("CompilerPassPipelineIR must not use cloud compile.")
        records = tuple(_record_from_any(record) for record in self.records)
        object.__setattr__(self, "records", records)
        object.__setattr__(self, "pass_count", int(self.pass_count))
        if self.pass_count != len(records):
            raise ValueError("CompilerPassPipelineIR pass_count must match records.")
        object.__setattr__(self, "input_hashes", canonicalize(self.input_hashes))
        object.__setattr__(self, "output_hashes", canonicalize(self.output_hashes))
        object.__setattr__(
            self,
            "diagnostic_summary",
            canonicalize(self.diagnostic_summary),
        )
        object.__setattr__(self, "metadata", redact_audit_metadata(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CompilerPassPipelineIR:
        """Build a pass pipeline from a JSON-compatible dictionary."""
        if not isinstance(data, dict):
            raise TypeError("CompilerPassPipelineIR dictionary must be an object.")
        return cls(
            pipeline_id=str(data["pipeline_id"]),
            program_type=str(data["program_type"]),
            compiler_version=str(data["compiler_version"]),
            pass_count=int(data["pass_count"]),
            records=tuple(
                _record_from_any(record) for record in data.get("records", ())
            ),
            status=cast(PassStatus, data["status"]),
            input_hashes=dict(data.get("input_hashes", {})),
            output_hashes=dict(data.get("output_hashes", {})),
            diagnostic_summary=dict(data["diagnostic_summary"]),
            metadata_only=bool(data.get("metadata_only", True)),
            backend_called=bool(data.get("backend_called", False)),
            network_accessed=bool(data.get("network_accessed", False)),
            live_hardware_claimed=bool(data.get("live_hardware_claimed", False)),
            cloud_compile_used=bool(data.get("cloud_compile_used", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> CompilerPassPipelineIR:
        """Build a pass pipeline from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("CompilerPassPipelineIR JSON must contain an object.")
        return cls.from_dict(data)


def build_compiler_pass_pipeline(
    pass_summaries: tuple[dict[str, Any], ...],
    *,
    pipeline_id: str,
    program_type: str,
    compiler_version: str,
    input_hashes: dict[str, Any],
    output_hashes: dict[str, Any],
    metadata: dict[str, Any] | None = None,
) -> CompilerPassPipelineIR:
    """Build an ordered, metadata-only compiler pass pipeline summary."""
    if not isinstance(pass_summaries, tuple):
        raise TypeError("pass_summaries must be a tuple of dictionaries.")
    if any(not isinstance(summary, dict) for summary in pass_summaries):
        raise TypeError("pass_summaries must contain dictionaries.")
    records = tuple(
        _record_from_summary(
            index,
            summary,
            pipeline_input_hashes=input_hashes,
            pipeline_output_hashes=output_hashes,
        )
        for index, summary in enumerate(pass_summaries)
    )
    return CompilerPassPipelineIR(
        pipeline_id=pipeline_id,
        program_type=program_type,
        compiler_version=compiler_version,
        pass_count=len(records),
        records=records,
        status=_pipeline_status(records),
        input_hashes=input_hashes,
        output_hashes=output_hashes,
        diagnostic_summary=_diagnostic_summary(records),
        metadata_only=True,
        backend_called=False,
        network_accessed=False,
        live_hardware_claimed=False,
        cloud_compile_used=False,
        metadata={
            "builder": "build_compiler_pass_pipeline",
            "metadata_only": True,
            **({} if metadata is None else metadata),
        },
    )


def _record_from_summary(
    index: int,
    summary: dict[str, Any],
    *,
    pipeline_input_hashes: dict[str, Any],
    pipeline_output_hashes: dict[str, Any],
) -> CompilerPassRecordIR:
    pass_name = str(summary["pass_name"])
    metadata = dict(summary.get("metadata", {}))
    return CompilerPassRecordIR(
        pass_index=index,
        pass_name=pass_name,
        stage=str(summary.get("stage", "compilation")),
        status=cast(PassStatus, summary["status"]),
        reason_category=str(summary["reason_category"]),
        input_hashes=_pass_input_hashes(
            pass_name,
            pipeline_input_hashes=pipeline_input_hashes,
            pipeline_output_hashes=pipeline_output_hashes,
        ),
        output_hashes=_pass_output_hashes(
            pass_name,
            pipeline_input_hashes=pipeline_input_hashes,
            pipeline_output_hashes=pipeline_output_hashes,
        ),
        diagnostic_codes=tuple(
            str(code) for code in summary.get("diagnostic_codes", ())
        ),
        diagnostic_count=int(summary.get("diagnostic_count", 0)),
        error_count=int(summary.get("error_count", 0)),
        warning_count=int(summary.get("warning_count", 0)),
        metadata_only=True,
        backend_called=False,
        network_accessed=False,
        live_hardware_claimed=False,
        cloud_compile_used=False,
        metadata={
            **metadata,
            "legacy_pass_summary": canonicalize(summary),
            "metadata_only": True,
        },
    )


def _pass_input_hashes(
    pass_name: str,
    *,
    pipeline_input_hashes: dict[str, Any],
    pipeline_output_hashes: dict[str, Any],
) -> dict[str, Any]:
    source = pipeline_input_hashes.get("source_program_hash")
    discretized = pipeline_output_hashes.get("discretized_program_hash")
    target = pipeline_input_hashes.get("target_snapshot_hash")
    compiled = pipeline_output_hashes.get("compiled_program_hash")
    common = {"source_program_hash": source}
    if pass_name == "validation":
        return common
    if pass_name == "discretization":
        return common
    if pass_name == "target_binding":
        return {**common, "discretized_program_hash": discretized}
    if pass_name in {"analog_lowering", "digital_lowering", "control_binding"}:
        return {
            **common,
            "discretized_program_hash": discretized,
            "target_snapshot_hash": target,
        }
    if pass_name in {"source_map", "resource_estimate", "backend_readiness"}:
        return {
            **common,
            "discretized_program_hash": discretized,
            "target_snapshot_hash": target,
            "compiled_program_hash": compiled,
        }
    return _canonical_dict(pipeline_input_hashes)


def _pass_output_hashes(
    pass_name: str,
    *,
    pipeline_input_hashes: dict[str, Any],
    pipeline_output_hashes: dict[str, Any],
) -> dict[str, Any]:
    source = pipeline_input_hashes.get("source_program_hash")
    discretized = pipeline_output_hashes.get("discretized_program_hash")
    target = pipeline_input_hashes.get("target_snapshot_hash")
    compiled = pipeline_output_hashes.get("compiled_program_hash")
    if pass_name == "validation":
        return {"validated_program_hash": source}
    if pass_name == "discretization":
        return {"discretized_program_hash": discretized}
    if pass_name == "target_binding":
        return {"target_snapshot_hash": target}
    if pass_name in {"analog_lowering", "digital_lowering", "control_binding"}:
        return {"compiled_program_hash": compiled}
    if pass_name == "source_map":
        return {
            "compiled_program_hash": compiled,
            "source_map_hash": pipeline_output_hashes.get("source_map_hash"),
        }
    if pass_name == "resource_estimate":
        return {
            "compiled_program_hash": compiled,
            "resource_estimate_hash": pipeline_output_hashes.get(
                "resource_estimate_hash"
            ),
        }
    if pass_name == "backend_readiness":
        return {
            "compiled_program_hash": compiled,
            "compile_cache_key": pipeline_output_hashes.get("compile_cache_key"),
        }
    return _canonical_dict(pipeline_output_hashes)


def _pipeline_status(records: tuple[CompilerPassRecordIR, ...]) -> PassStatus:
    if any(record.status == "blocked" for record in records):
        return "blocked"
    if any(record.status == "warning" for record in records):
        return "warning"
    return "ok"


def _diagnostic_summary(
    records: tuple[CompilerPassRecordIR, ...],
) -> dict[str, Any]:
    return {
        "diagnostic_count": sum(record.diagnostic_count for record in records),
        "error_count": sum(record.error_count for record in records),
        "warning_count": sum(record.warning_count for record in records),
        "blocked_passes": [
            record.pass_name for record in records if record.status == "blocked"
        ],
        "warning_passes": [
            record.pass_name for record in records if record.status == "warning"
        ],
        "codes": sorted(
            {code for record in records for code in record.diagnostic_codes}
        ),
        "metadata_only": True,
    }


def _record_from_any(
    item: CompilerPassRecordIR | dict[str, Any],
) -> CompilerPassRecordIR:
    if isinstance(item, CompilerPassRecordIR):
        return item
    if isinstance(item, dict):
        return CompilerPassRecordIR.from_dict(item)
    raise TypeError(
        "compiler pass records must be CompilerPassRecordIR or dictionaries."
    )


def _canonical_dict(value: dict[str, Any]) -> dict[str, Any]:
    canonical = canonicalize(value)
    if not isinstance(canonical, dict):
        raise TypeError("canonicalized compiler pass hashes must be dictionaries.")
    return canonical
