"""Logical Problem Hamiltonian contracts shared by mode-specific Lowerers."""

from __future__ import annotations

import json
import math
import re
from dataclasses import dataclass, field
from typing import Any, Literal

from cascaqit.algorithms.problem_projection import problem_to_pauli_hamiltonian
from cascaqit.native_ir.base import IRMixin
from cascaqit.problems.canonical import CanonicalProblemIR
from cascaqit.problems.optimization import OptimizationProblem

__all__ = [
    "LOGICAL_HAMILTONIAN_SCHEMA_VERSION",
    "LogicalHamiltonianIR",
    "LogicalHamiltonianTermIR",
    "build_logical_hamiltonian",
]

LOGICAL_HAMILTONIAN_SCHEMA_VERSION = "cascaqit.compiler.problem.hamiltonian.v1"
LogicalOperator = Literal["z", "zz"]
_DIGEST_PATTERN = re.compile(r"[0-9a-f]{64}")


@dataclass(frozen=True)
class LogicalHamiltonianTermIR(IRMixin):
    """One normalized Z or ZZ term with source Problem references."""

    term_id: str
    operator: LogicalOperator
    targets: tuple[str, ...]
    coefficient: float
    source_term_ids: tuple[str, ...]
    schema_version: str = LOGICAL_HAMILTONIAN_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_text(self.term_id, "term_id")
        if self.operator not in {"z", "zz"}:
            raise ValueError(f"Unsupported logical operator: {self.operator!r}.")
        object.__setattr__(self, "targets", tuple(self.targets))
        expected_targets = 1 if self.operator == "z" else 2
        if len(self.targets) != expected_targets or len(set(self.targets)) != len(
            self.targets
        ):
            raise ValueError(f"{self.operator} requires {expected_targets} target(s).")
        _require_unique_text(self.targets, "targets")
        object.__setattr__(
            self,
            "coefficient",
            _finite(self.coefficient, "coefficient"),
        )
        if self.coefficient == 0.0:
            raise ValueError("logical Hamiltonian terms must be non-zero.")
        object.__setattr__(self, "source_term_ids", tuple(self.source_term_ids))
        _require_unique_text(self.source_term_ids, "source_term_ids")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> LogicalHamiltonianTermIR:
        """Restore a logical Hamiltonian term from JSON-compatible data."""
        return cls(
            term_id=str(data["term_id"]),
            operator=data["operator"],
            targets=tuple(str(item) for item in data["targets"]),
            coefficient=float(data["coefficient"]),
            source_term_ids=tuple(str(item) for item in data["source_term_ids"]),
            schema_version=str(
                data.get("schema_version", LOGICAL_HAMILTONIAN_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class LogicalHamiltonianIR(IRMixin):
    """Mode-independent diagonal Hamiltonian derived from one canonical Problem."""

    hamiltonian_id: str
    source_problem_id: str
    source_problem_hash: str
    canonical_problem_hash: str
    pauli_hamiltonian_hash: str
    logical_order: tuple[str, ...]
    constant: float
    constant_source_term_ids: tuple[str, ...]
    terms: tuple[LogicalHamiltonianTermIR, ...]
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = LOGICAL_HAMILTONIAN_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_text(self.hamiltonian_id, "hamiltonian_id")
        _require_text(self.source_problem_id, "source_problem_id")
        _require_digest(self.source_problem_hash, "source_problem_hash")
        _require_digest(self.canonical_problem_hash, "canonical_problem_hash")
        _require_digest(self.pauli_hamiltonian_hash, "pauli_hamiltonian_hash")
        object.__setattr__(self, "logical_order", tuple(self.logical_order))
        _require_unique_text(self.logical_order, "logical_order")
        object.__setattr__(self, "constant", _finite(self.constant, "constant"))
        object.__setattr__(
            self,
            "constant_source_term_ids",
            tuple(self.constant_source_term_ids),
        )
        _require_unique_text(
            self.constant_source_term_ids,
            "constant_source_term_ids",
            allow_empty=True,
        )
        object.__setattr__(self, "terms", tuple(self.terms))
        if not self.terms:
            raise ValueError("LogicalHamiltonianIR terms must not be empty.")
        _require_unique_text(tuple(term.term_id for term in self.terms), "term ids")
        logical = set(self.logical_order)
        if any(target not in logical for term in self.terms for target in term.targets):
            raise ValueError("Hamiltonian terms contain targets outside logical_order.")
        if not isinstance(self.metadata, dict):
            raise TypeError("metadata must be a dictionary.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> LogicalHamiltonianIR:
        """Restore a logical Hamiltonian from JSON-compatible data."""
        return cls(
            hamiltonian_id=str(data["hamiltonian_id"]),
            source_problem_id=str(data["source_problem_id"]),
            source_problem_hash=str(data["source_problem_hash"]),
            canonical_problem_hash=str(data["canonical_problem_hash"]),
            pauli_hamiltonian_hash=str(data["pauli_hamiltonian_hash"]),
            logical_order=tuple(str(item) for item in data["logical_order"]),
            constant=float(data["constant"]),
            constant_source_term_ids=tuple(
                str(item) for item in data.get("constant_source_term_ids", ())
            ),
            terms=tuple(
                LogicalHamiltonianTermIR.from_dict(item)
                for item in data.get("terms", ())
            ),
            metadata=dict(data.get("metadata", {})),
            schema_version=str(
                data.get("schema_version", LOGICAL_HAMILTONIAN_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> LogicalHamiltonianIR:
        """Restore a logical Hamiltonian from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("LogicalHamiltonianIR JSON must contain an object.")
        return cls.from_dict(data)


def build_logical_hamiltonian(
    problem: OptimizationProblem,
    *,
    canonical: CanonicalProblemIR,
    mis_penalty: float = 2.0,
    mwis_penalty: float | None = None,
) -> LogicalHamiltonianIR:
    """Project through the existing Pauli path and add auditable source refs."""
    if not isinstance(canonical, CanonicalProblemIR):
        raise TypeError("canonical must be CanonicalProblemIR.")
    pauli = problem_to_pauli_hamiltonian(
        problem,
        mis_penalty=mis_penalty,
        mwis_penalty=mwis_penalty,
    )
    if pauli.logical_order != canonical.logical_order:
        raise ValueError("Pauli and canonical logical order do not match.")
    if pauli.source_problem_hash != canonical.problem_hash:
        raise ValueError("Pauli and canonical source problem hashes do not match.")

    terms = tuple(
        LogicalHamiltonianTermIR(
            term_id=term.term_id,
            operator="z" if len(term.observable.targets) == 1 else "zz",
            targets=term.observable.targets,
            coefficient=term.coefficient,
            source_term_ids=_source_refs(canonical, term.observable.targets),
        )
        for term in pauli.terms
    )
    return LogicalHamiltonianIR(
        hamiltonian_id=f"logical.{pauli.hamiltonian_id}",
        source_problem_id=canonical.problem_id,
        source_problem_hash=canonical.problem_hash,
        canonical_problem_hash=canonical.stable_hash(),
        pauli_hamiltonian_hash=pauli.stable_hash(),
        logical_order=canonical.logical_order,
        constant=pauli.constant,
        constant_source_term_ids=_constant_source_refs(canonical),
        terms=terms,
        metadata={
            "projection": "existing_problem_to_pauli_hamiltonian",
            "pauli_convention": "computational |0> has Z=+1; Ising s=-Z",
            "source_problem_type": canonical.problem_type,
        },
    )


def _source_refs(
    canonical: CanonicalProblemIR,
    targets: tuple[str, ...],
) -> tuple[str, ...]:
    if len(targets) == 2:
        target_set = frozenset(targets)
        for term in canonical.quadratic_terms:
            if frozenset((term.left, term.right)) == target_set:
                return term.source_term_ids
        raise ValueError(f"No canonical quadratic source for targets {targets!r}.")

    variable = targets[0]
    if canonical.variable_domain == "spin":
        return tuple(
            source
            for term in canonical.linear_terms
            if term.variable == variable
            for source in term.source_term_ids
        )
    # QUBO-to-Ising projection aggregates the source linear term and every
    # incident quadratic term into the resulting one-body Pauli-Z coefficient.
    refs = [
        source
        for term in canonical.linear_terms
        if term.variable == variable
        for source in term.source_term_ids
    ]
    refs.extend(
        source
        for term in canonical.quadratic_terms
        if variable in {term.left, term.right}
        for source in term.source_term_ids
    )
    if not refs:
        raise ValueError(f"No canonical linear source for target {variable!r}.")
    return tuple(sorted(set(refs)))


def _constant_source_refs(canonical: CanonicalProblemIR) -> tuple[str, ...]:
    refs = ["offset"]
    if canonical.variable_domain == "binary":
        refs.extend(
            source
            for term in canonical.linear_terms
            for source in term.source_term_ids
        )
        refs.extend(
            source
            for term in canonical.quadratic_terms
            for source in term.source_term_ids
        )
    return tuple(sorted(set(refs)))


def _require_text(value: object, name: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{name} must be a non-empty string.")


def _require_digest(value: object, name: str) -> None:
    if not isinstance(value, str) or _DIGEST_PATTERN.fullmatch(value) is None:
        raise ValueError(f"{name} must be a SHA-256 hash.")


def _require_unique_text(
    values: tuple[str, ...],
    name: str,
    *,
    allow_empty: bool = False,
) -> None:
    if not values and not allow_empty:
        raise ValueError(f"{name} must not be empty.")
    if any(not isinstance(value, str) or not value.strip() for value in values):
        raise ValueError(f"{name} must contain non-empty strings.")
    if len(values) != len(set(values)):
        raise ValueError(f"{name} must be unique.")


def _finite(value: object, name: str) -> float:
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        raise TypeError(f"{name} must be a real number.")
    normalized = float(value)
    if not math.isfinite(normalized):
        raise ValueError(f"{name} must be finite.")
    return normalized
