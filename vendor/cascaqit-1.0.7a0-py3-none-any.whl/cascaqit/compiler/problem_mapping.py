"""Target-aware layout and term-candidate planning for optimization Problems."""

from __future__ import annotations

import json
import math
import re
from dataclasses import dataclass, field
from typing import Any, Literal

from cascaqit.compiler.problem import LogicalHamiltonianIR
from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.native_ir.base import IRMixin
from cascaqit.problems.canonical import CanonicalProblemIR
from cascaqit.targets import TargetSpec

__all__ = [
    "PROBLEM_MAPPING_SCHEMA_VERSION",
    "ModeFeasibilityIR",
    "ProblemLayoutIR",
    "ProblemLayoutSiteIR",
    "ProblemMappingPlanIR",
    "ProblemMappingPlanner",
    "ProblemTermMappingIR",
    "ReferenceInteractionIR",
    "TermImplementationCandidateIR",
]

PROBLEM_MAPPING_SCHEMA_VERSION = "cascaqit.compiler.problem.mapping.v1"
ProblemMode = Literal["digital", "analog", "hybrid"]
ProblemAlgorithm = Literal["qaoa", "qaa"]
LayoutPolicy = Literal["provided", "deterministic_grid", "unavailable"]
CandidateImplementation = Literal[
    "digital_gate",
    "analog_detuning_global",
    "analog_detuning_local",
    "analog_interaction",
    "unsupported",
]
CandidateStatus = Literal["supported", "unsupported"]
TermMappingImplementation = Literal[
    "digital_gate",
    "analog_detuning_global",
    "analog_detuning_local",
    "analog_interaction",
    "hybrid_split",
]
_DIGEST_PATTERN = re.compile(r"[0-9a-f]{64}")
_SUPPORTED_STATUS = frozenset({"supported", "experimental", "ir_only"})


@dataclass(frozen=True)
class ProblemLayoutSiteIR(IRMixin):
    """One logical variable placed at one public reference atom site."""

    logical_id: str
    atom_id: str
    site_id: str
    position: tuple[float, float]
    schema_version: str = PROBLEM_MAPPING_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_text(self.logical_id, "logical_id")
        _require_text(self.atom_id, "atom_id")
        _require_text(self.site_id, "site_id")
        object.__setattr__(
            self,
            "position",
            (
                _finite(self.position[0], "position.x"),
                _finite(self.position[1], "position.y"),
            ),
        )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ProblemLayoutSiteIR:
        """Restore one reference layout site."""
        position = data["position"]
        return cls(
            logical_id=str(data["logical_id"]),
            atom_id=str(data["atom_id"]),
            site_id=str(data["site_id"]),
            position=(float(position[0]), float(position[1])),
            schema_version=str(
                data.get("schema_version", PROBLEM_MAPPING_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class ProblemLayoutIR(IRMixin):
    """Deterministic public reference layout and validation outcome."""

    layout_id: str
    layout_policy: LayoutPolicy
    sites: tuple[ProblemLayoutSiteIR, ...]
    valid: bool
    diagnostic_codes: tuple[str, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = PROBLEM_MAPPING_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_text(self.layout_id, "layout_id")
        if self.layout_policy not in {"provided", "deterministic_grid", "unavailable"}:
            raise ValueError(f"Unsupported layout_policy: {self.layout_policy!r}.")
        object.__setattr__(self, "sites", tuple(self.sites))
        _require_unique_text(
            tuple(item.logical_id for item in self.sites),
            "logical ids",
            allow_empty=True,
        )
        _require_unique_text(
            tuple(item.atom_id for item in self.sites), "atom ids", allow_empty=True
        )
        _require_unique_text(
            tuple(item.site_id for item in self.sites), "site ids", allow_empty=True
        )
        object.__setattr__(self, "diagnostic_codes", tuple(self.diagnostic_codes))
        _require_unique_text(
            self.diagnostic_codes, "diagnostic_codes", allow_empty=True
        )
        if self.valid and (not self.sites or self.diagnostic_codes):
            raise ValueError("A valid layout requires sites and no diagnostic codes.")
        if not isinstance(self.metadata, dict):
            raise TypeError("metadata must be a dictionary.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ProblemLayoutIR:
        """Restore a reference layout."""
        return cls(
            layout_id=str(data["layout_id"]),
            layout_policy=data["layout_policy"],
            sites=tuple(
                ProblemLayoutSiteIR.from_dict(item) for item in data.get("sites", ())
            ),
            valid=bool(data["valid"]),
            diagnostic_codes=tuple(
                str(item) for item in data.get("diagnostic_codes", ())
            ),
            metadata=dict(data.get("metadata", {})),
            schema_version=str(
                data.get("schema_version", PROBLEM_MAPPING_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class ReferenceInteractionIR(IRMixin):
    """One pair coefficient from the public local reference interaction model."""

    left: str
    right: str
    distance: float
    reference_coefficient: float
    model: Literal["truncated_blockade_r6"] = "truncated_blockade_r6"
    calibrated: bool = False
    schema_version: str = PROBLEM_MAPPING_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_text(self.left, "left")
        _require_text(self.right, "right")
        if self.left >= self.right:
            raise ValueError("interaction targets must use canonical order.")
        object.__setattr__(self, "distance", _finite(self.distance, "distance"))
        if self.distance <= 0.0:
            raise ValueError("interaction distance must be positive.")
        object.__setattr__(
            self,
            "reference_coefficient",
            _finite(self.reference_coefficient, "reference_coefficient"),
        )
        if self.reference_coefficient < 0.0:
            raise ValueError("reference interaction must be non-negative.")
        if self.model != "truncated_blockade_r6":
            raise ValueError(f"Unsupported interaction model: {self.model!r}.")
        if self.calibrated:
            raise ValueError("Public reference interactions are not calibrated facts.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ReferenceInteractionIR:
        """Restore one reference interaction."""
        return cls(
            left=str(data["left"]),
            right=str(data["right"]),
            distance=float(data["distance"]),
            reference_coefficient=float(data["reference_coefficient"]),
            model=data.get("model", "truncated_blockade_r6"),
            calibrated=bool(data.get("calibrated", False)),
            schema_version=str(
                data.get("schema_version", PROBLEM_MAPPING_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class TermImplementationCandidateIR(IRMixin):
    """One mode-specific implementation candidate for a logical term."""

    candidate_id: str
    term_id: str
    operator: Literal["z", "zz"]
    targets: tuple[str, ...]
    logical_coefficient: float
    implementation: CandidateImplementation
    status: CandidateStatus
    reference_coefficient: float | None = None
    diagnostic_codes: tuple[str, ...] = ()
    schema_version: str = PROBLEM_MAPPING_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_text(self.candidate_id, "candidate_id")
        _require_text(self.term_id, "term_id")
        if self.operator not in {"z", "zz"}:
            raise ValueError(f"Unsupported operator: {self.operator!r}.")
        object.__setattr__(self, "targets", tuple(self.targets))
        expected = 1 if self.operator == "z" else 2
        if len(self.targets) != expected:
            raise ValueError("candidate target count does not match operator.")
        object.__setattr__(
            self,
            "logical_coefficient",
            _finite(self.logical_coefficient, "logical_coefficient"),
        )
        if self.implementation not in {
            "digital_gate",
            "analog_detuning_global",
            "analog_detuning_local",
            "analog_interaction",
            "unsupported",
        }:
            raise ValueError(f"Unsupported implementation: {self.implementation!r}.")
        if self.status not in {"supported", "unsupported"}:
            raise ValueError(f"Unsupported candidate status: {self.status!r}.")
        if self.reference_coefficient is not None:
            object.__setattr__(
                self,
                "reference_coefficient",
                _finite(self.reference_coefficient, "reference_coefficient"),
            )
        object.__setattr__(self, "diagnostic_codes", tuple(self.diagnostic_codes))
        _require_unique_text(
            self.diagnostic_codes, "diagnostic_codes", allow_empty=True
        )
        if self.status == "supported" and self.diagnostic_codes:
            raise ValueError(
                "Supported candidates cannot contain blocking diagnostics."
            )
        if self.status == "unsupported" and not self.diagnostic_codes:
            raise ValueError("Unsupported candidates require a diagnostic code.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TermImplementationCandidateIR:
        """Restore a term implementation candidate."""
        return cls(
            candidate_id=str(data["candidate_id"]),
            term_id=str(data["term_id"]),
            operator=data["operator"],
            targets=tuple(str(item) for item in data["targets"]),
            logical_coefficient=float(data["logical_coefficient"]),
            implementation=data["implementation"],
            status=data["status"],
            reference_coefficient=(
                None
                if data.get("reference_coefficient") is None
                else float(data["reference_coefficient"])
            ),
            diagnostic_codes=tuple(
                str(item) for item in data.get("diagnostic_codes", ())
            ),
            schema_version=str(
                data.get("schema_version", PROBLEM_MAPPING_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class ProblemTermMappingIR(IRMixin):
    """Conserved logical coefficient split used by one compiled program."""

    mapping_id: str
    logical_term_id: str
    source_term_ids: tuple[str, ...]
    operator: Literal["z", "zz"]
    targets: tuple[str, ...]
    logical_coefficient: float
    analog_coefficient: float
    digital_coefficient: float
    implementation: TermMappingImplementation
    absolute_tolerance: float = 1e-8
    relative_tolerance: float = 0.05
    schema_version: str = PROBLEM_MAPPING_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_text(self.mapping_id, "mapping_id")
        _require_text(self.logical_term_id, "logical_term_id")
        object.__setattr__(self, "source_term_ids", tuple(self.source_term_ids))
        _require_unique_text(
            self.source_term_ids,
            "source_term_ids",
            allow_empty=True,
        )
        if self.operator not in {"z", "zz"}:
            raise ValueError(f"Unsupported operator: {self.operator!r}.")
        object.__setattr__(self, "targets", tuple(self.targets))
        expected_targets = 1 if self.operator == "z" else 2
        if len(self.targets) != expected_targets or len(set(self.targets)) != len(
            self.targets
        ):
            raise ValueError(
                f"{self.operator} term mapping requires {expected_targets} target(s)."
            )
        _require_unique_text(self.targets, "targets")
        for name in (
            "logical_coefficient",
            "analog_coefficient",
            "digital_coefficient",
        ):
            object.__setattr__(self, name, _finite(getattr(self, name), name))
        if self.implementation not in {
            "digital_gate",
            "analog_detuning_global",
            "analog_detuning_local",
            "analog_interaction",
            "hybrid_split",
        }:
            raise ValueError(f"Unsupported implementation: {self.implementation!r}.")
        object.__setattr__(
            self,
            "absolute_tolerance",
            _positive(self.absolute_tolerance, "absolute_tolerance"),
        )
        object.__setattr__(
            self,
            "relative_tolerance",
            _positive(self.relative_tolerance, "relative_tolerance"),
        )
        if not self.conserved:
            raise ValueError(
                "Analog and Digital coefficients do not conserve the term."
            )

    @property
    def conservation_error(self) -> float:
        """Return signed reconstructed-minus-logical coefficient error."""
        return (
            self.analog_coefficient
            + self.digital_coefficient
            - self.logical_coefficient
        )

    @property
    def conserved(self) -> bool:
        """Return whether the split reconstructs the logical coefficient."""
        return math.isclose(
            self.analog_coefficient + self.digital_coefficient,
            self.logical_coefficient,
            rel_tol=self.relative_tolerance,
            abs_tol=self.absolute_tolerance,
        )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ProblemTermMappingIR:
        """Restore one conserved compile-time term mapping."""
        return cls(
            mapping_id=str(data["mapping_id"]),
            logical_term_id=str(data["logical_term_id"]),
            source_term_ids=tuple(str(item) for item in data["source_term_ids"]),
            operator=data["operator"],
            targets=tuple(str(item) for item in data["targets"]),
            logical_coefficient=float(data["logical_coefficient"]),
            analog_coefficient=float(data["analog_coefficient"]),
            digital_coefficient=float(data["digital_coefficient"]),
            implementation=data["implementation"],
            absolute_tolerance=float(data.get("absolute_tolerance", 1e-8)),
            relative_tolerance=float(data.get("relative_tolerance", 0.05)),
            schema_version=str(
                data.get("schema_version", PROBLEM_MAPPING_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> ProblemTermMappingIR:
        """Restore one term mapping from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("ProblemTermMappingIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class ModeFeasibilityIR(IRMixin):
    """Feasibility and provisional term assignment for one mode/algorithm."""

    mode: ProblemMode
    algorithm: ProblemAlgorithm
    feasible: bool
    analog_term_ids: tuple[str, ...] = ()
    digital_term_ids: tuple[str, ...] = ()
    diagnostic_codes: tuple[str, ...] = ()
    energy_scale: float | None = None
    local_reference: bool = True
    hardware_executable: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = PROBLEM_MAPPING_SCHEMA_VERSION

    def __post_init__(self) -> None:
        valid = {
            "digital": "qaoa",
            "hybrid": "qaoa",
            "analog": "qaa",
        }
        if self.mode not in valid or self.algorithm != valid[self.mode]:
            raise ValueError("mode and algorithm do not form a supported combination.")
        object.__setattr__(self, "analog_term_ids", tuple(self.analog_term_ids))
        object.__setattr__(self, "digital_term_ids", tuple(self.digital_term_ids))
        object.__setattr__(self, "diagnostic_codes", tuple(self.diagnostic_codes))
        _require_unique_text(self.analog_term_ids, "analog_term_ids", allow_empty=True)
        _require_unique_text(
            self.digital_term_ids, "digital_term_ids", allow_empty=True
        )
        _require_unique_text(
            self.diagnostic_codes, "diagnostic_codes", allow_empty=True
        )
        if self.energy_scale is not None:
            object.__setattr__(
                self, "energy_scale", _finite(self.energy_scale, "energy_scale")
            )
            if self.energy_scale <= 0.0:
                raise ValueError("energy_scale must be positive.")
        if self.feasible and self.diagnostic_codes:
            raise ValueError("A feasible mode cannot contain blocking diagnostics.")
        if self.hardware_executable and self.local_reference:
            raise ValueError("A local reference result cannot be hardware executable.")
        if not isinstance(self.metadata, dict):
            raise TypeError("metadata must be a dictionary.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ModeFeasibilityIR:
        """Restore one mode feasibility result."""
        return cls(
            mode=data["mode"],
            algorithm=data["algorithm"],
            feasible=bool(data["feasible"]),
            analog_term_ids=tuple(
                str(item) for item in data.get("analog_term_ids", ())
            ),
            digital_term_ids=tuple(
                str(item) for item in data.get("digital_term_ids", ())
            ),
            diagnostic_codes=tuple(
                str(item) for item in data.get("diagnostic_codes", ())
            ),
            energy_scale=None
            if data.get("energy_scale") is None
            else float(data["energy_scale"]),
            local_reference=bool(data.get("local_reference", True)),
            hardware_executable=bool(data.get("hardware_executable", False)),
            metadata=dict(data.get("metadata", {})),
            schema_version=str(
                data.get("schema_version", PROBLEM_MAPPING_SCHEMA_VERSION)
            ),
        )


@dataclass(frozen=True)
class ProblemMappingPlanIR(IRMixin):
    """Shared Target-aware mapping facts consumed by all Problem Lowerers."""

    plan_id: str
    source_problem_hash: str
    canonical_problem_hash: str
    logical_hamiltonian_hash: str
    target_id: str
    target_hash: str
    layout: ProblemLayoutIR
    interactions: tuple[ReferenceInteractionIR, ...]
    term_candidates: tuple[TermImplementationCandidateIR, ...]
    feasibility: tuple[ModeFeasibilityIR, ...]
    diagnostics: tuple[DiagnosticsIR, ...]
    absolute_tolerance: float
    relative_tolerance: float
    resource_estimate: dict[str, int]
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = PROBLEM_MAPPING_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_text(self.plan_id, "plan_id")
        _require_digest(self.source_problem_hash, "source_problem_hash")
        _require_digest(self.canonical_problem_hash, "canonical_problem_hash")
        _require_digest(self.logical_hamiltonian_hash, "logical_hamiltonian_hash")
        _require_text(self.target_id, "target_id")
        _require_digest(self.target_hash, "target_hash")
        object.__setattr__(self, "interactions", tuple(self.interactions))
        object.__setattr__(self, "term_candidates", tuple(self.term_candidates))
        object.__setattr__(self, "feasibility", tuple(self.feasibility))
        object.__setattr__(self, "diagnostics", tuple(self.diagnostics))
        _require_unique_text(
            tuple(item.candidate_id for item in self.term_candidates),
            "candidate ids",
            allow_empty=True,
        )
        if tuple(item.mode for item in self.feasibility) != (
            "digital",
            "hybrid",
            "analog",
        ):
            raise ValueError("feasibility must use digital, hybrid, analog order.")
        object.__setattr__(
            self,
            "absolute_tolerance",
            _positive(self.absolute_tolerance, "absolute_tolerance"),
        )
        object.__setattr__(
            self,
            "relative_tolerance",
            _positive(self.relative_tolerance, "relative_tolerance"),
        )
        if not isinstance(self.resource_estimate, dict) or any(
            not isinstance(value, int) or isinstance(value, bool) or value < 0
            for value in self.resource_estimate.values()
        ):
            raise TypeError("resource_estimate values must be non-negative integers.")
        if not isinstance(self.metadata, dict):
            raise TypeError("metadata must be a dictionary.")

    def feasibility_for(self, mode: ProblemMode) -> ModeFeasibilityIR:
        """Return the one feasibility row for a mode."""
        for item in self.feasibility:
            if item.mode == mode:
                return item
        raise ValueError(f"Unknown problem compile mode: {mode!r}.")

    def interaction_for(self, left: str, right: str) -> ReferenceInteractionIR:
        """Return the canonical pair interaction."""
        expected = tuple(sorted((left, right)))
        for item in self.interactions:
            if (item.left, item.right) == expected:
                return item
        raise ValueError(f"No reference interaction for pair {expected!r}.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ProblemMappingPlanIR:
        """Restore a complete mapping plan."""
        return cls(
            plan_id=str(data["plan_id"]),
            source_problem_hash=str(data["source_problem_hash"]),
            canonical_problem_hash=str(data["canonical_problem_hash"]),
            logical_hamiltonian_hash=str(data["logical_hamiltonian_hash"]),
            target_id=str(data["target_id"]),
            target_hash=str(data["target_hash"]),
            layout=ProblemLayoutIR.from_dict(data["layout"]),
            interactions=tuple(
                ReferenceInteractionIR.from_dict(item)
                for item in data.get("interactions", ())
            ),
            term_candidates=tuple(
                TermImplementationCandidateIR.from_dict(item)
                for item in data.get("term_candidates", ())
            ),
            feasibility=tuple(
                ModeFeasibilityIR.from_dict(item)
                for item in data.get("feasibility", ())
            ),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(item) for item in data.get("diagnostics", ())
            ),
            absolute_tolerance=float(data["absolute_tolerance"]),
            relative_tolerance=float(data["relative_tolerance"]),
            resource_estimate={
                str(key): int(value) for key, value in data["resource_estimate"].items()
            },
            metadata=dict(data.get("metadata", {})),
            schema_version=str(
                data.get("schema_version", PROBLEM_MAPPING_SCHEMA_VERSION)
            ),
        )

    @classmethod
    def from_json(cls, text: str) -> ProblemMappingPlanIR:
        """Restore a mapping plan from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("ProblemMappingPlanIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class ProblemMappingPlanner:
    """Build deterministic public reference mapping facts for one Target."""

    absolute_tolerance: float = 1e-8
    relative_tolerance: float = 0.05

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "absolute_tolerance",
            _positive(self.absolute_tolerance, "absolute_tolerance"),
        )
        object.__setattr__(
            self,
            "relative_tolerance",
            _positive(self.relative_tolerance, "relative_tolerance"),
        )

    def plan(
        self,
        canonical: CanonicalProblemIR,
        logical: LogicalHamiltonianIR,
        *,
        target: TargetSpec,
    ) -> ProblemMappingPlanIR:
        """Analyze layout, interactions, term candidates, and mode feasibility."""
        if not isinstance(canonical, CanonicalProblemIR):
            raise TypeError("canonical must be CanonicalProblemIR.")
        if not isinstance(logical, LogicalHamiltonianIR):
            raise TypeError("logical must be LogicalHamiltonianIR.")
        if not isinstance(target, TargetSpec):
            raise TypeError("target must be TargetSpec.")
        if logical.source_problem_hash != canonical.problem_hash:
            raise ValueError("logical and canonical source hashes do not match.")
        if logical.canonical_problem_hash != canonical.stable_hash():
            raise ValueError("logical Hamiltonian does not reference canonical input.")

        budget_ok = len(canonical.logical_order) <= target.max_atoms
        layout = _build_layout(canonical, target=target, budget_ok=budget_ok)
        interactions = _reference_interactions(layout, target=target)
        digital_supported = _digital_qaoa_supported(target)
        local_detuning = _analog_operation_supported(target, "local_detuning")
        global_drive = _analog_operation_supported(target, "global_rydberg_drive")
        pair_scale = _reference_energy_scale(logical, interactions)
        detuning = _detuning_support(
            logical,
            interactions,
            target=target,
            energy_scale=pair_scale or 1.0,
            local_detuning=local_detuning,
            global_drive=global_drive,
            absolute_tolerance=self.absolute_tolerance,
        )
        qaa_initial_detuning = _qaa_initial_detuning(
            target,
            energy_scale=pair_scale or 1.0,
        )
        qaa_omega_limit = _qaa_omega_limit(target)
        candidates = _term_candidates(
            logical,
            interactions,
            digital_supported=digital_supported,
            detuning_implementation=detuning.implementation,
        )
        feasibility = (
            _digital_feasibility(
                logical,
                budget_ok=budget_ok,
                digital_supported=digital_supported,
            ),
            _hybrid_feasibility(
                logical,
                interactions,
                layout=layout,
                budget_ok=budget_ok,
                digital_supported=digital_supported,
                global_drive=global_drive,
                detuning=detuning,
                energy_scale=pair_scale or 1.0,
            ),
            _analog_feasibility(
                logical,
                interactions,
                layout=layout,
                budget_ok=budget_ok,
                global_drive=global_drive,
                detuning=detuning,
                energy_scale=pair_scale or 1.0,
                initial_detuning=qaa_initial_detuning,
                omega_limit=qaa_omega_limit,
                absolute_tolerance=self.absolute_tolerance,
                relative_tolerance=self.relative_tolerance,
            ),
        )
        diagnostics = _mapping_diagnostics(layout, feasibility)
        return ProblemMappingPlanIR(
            plan_id=f"mapping.{canonical.problem_id}.{target.target_id}",
            source_problem_hash=canonical.problem_hash,
            canonical_problem_hash=canonical.stable_hash(),
            logical_hamiltonian_hash=logical.stable_hash(),
            target_id=target.target_id,
            target_hash=target.stable_hash(),
            layout=layout,
            interactions=interactions,
            term_candidates=candidates,
            feasibility=feasibility,
            diagnostics=diagnostics,
            absolute_tolerance=self.absolute_tolerance,
            relative_tolerance=self.relative_tolerance,
            resource_estimate=_resource_estimate(logical),
            metadata={
                "reference_interaction_model": "truncated_blockade_r6",
                "reference_only": True,
                "calibrated": False,
                "blockade_radius": float(target.metadata.get("blockade_radius", 0.0)),
            },
        )


@dataclass(frozen=True)
class _DetuningSupport:
    implementation: Literal[
        "analog_detuning_global",
        "analog_detuning_local",
        "unsupported",
    ]
    required_values: tuple[tuple[str, float], ...]
    diagnostic_codes: tuple[str, ...]


def _build_layout(
    canonical: CanonicalProblemIR,
    *,
    target: TargetSpec,
    budget_ok: bool,
) -> ProblemLayoutIR:
    if not budget_ok:
        return ProblemLayoutIR(
            layout_id=f"layout.{canonical.problem_id}.unavailable",
            layout_policy="unavailable",
            sites=(),
            valid=False,
            diagnostic_codes=("PROBLEM_VARIABLE_BUDGET_EXCEEDED",),
            metadata={
                "logical_variables": len(canonical.logical_order),
                "target_max_atoms": target.max_atoms,
            },
        )
    hints = dict(canonical.layout_hints)
    if set(hints) == set(canonical.logical_order):
        positions = tuple((name, hints[name]) for name in canonical.logical_order)
        policy: LayoutPolicy = "provided"
    else:
        positions = _grid_positions(canonical.logical_order, target=target)
        policy = "deterministic_grid"
    sites = tuple(
        ProblemLayoutSiteIR(
            logical_id=name,
            atom_id=name,
            site_id=f"site.{index}.{name}",
            position=position,
        )
        for index, (name, position) in enumerate(positions)
    )
    codes = _layout_diagnostic_codes(sites, target=target)
    return ProblemLayoutIR(
        layout_id=f"layout.{canonical.problem_id}.{policy}",
        layout_policy=policy,
        sites=sites,
        valid=not codes,
        diagnostic_codes=codes,
        metadata={
            "coordinate_unit": target.coordinate_unit,
            "target_id": target.target_id,
            "partial_hints_ignored": bool(hints) and len(hints) != len(sites),
        },
    )


def _grid_positions(
    logical_order: tuple[str, ...],
    *,
    target: TargetSpec,
) -> tuple[tuple[str, tuple[float, float]], ...]:
    columns = max(1, math.ceil(math.sqrt(len(logical_order))))
    rows = math.ceil(len(logical_order) / columns)
    blockade = float(target.metadata.get("blockade_radius", 0.0))
    spacing = max(target.min_atom_spacing, 0.75 * blockade if blockade > 0 else 0.0)
    width = (columns - 1) * spacing
    height = (rows - 1) * spacing
    region = target.programmable_region
    x0 = (region.x_min + region.x_max - width) / 2.0
    y0 = (region.y_min + region.y_max - height) / 2.0
    return tuple(
        (
            name,
            (x0 + (index % columns) * spacing, y0 + (index // columns) * spacing),
        )
        for index, name in enumerate(logical_order)
    )


def _layout_diagnostic_codes(
    sites: tuple[ProblemLayoutSiteIR, ...],
    *,
    target: TargetSpec,
) -> tuple[str, ...]:
    region = target.programmable_region
    outside = any(
        not (
            region.x_min <= item.position[0] <= region.x_max
            and region.y_min <= item.position[1] <= region.y_max
        )
        for item in sites
    )
    too_close = any(
        math.dist(left.position, right.position) < target.min_atom_spacing - 1e-12
        for index, left in enumerate(sites)
        for right in sites[index + 1 :]
    )
    return ("PROBLEM_LAYOUT_UNEMBEDDABLE",) if outside or too_close else ()


def _reference_interactions(
    layout: ProblemLayoutIR,
    *,
    target: TargetSpec,
) -> tuple[ReferenceInteractionIR, ...]:
    blockade = float(target.metadata.get("blockade_radius", 0.0))
    interactions: list[ReferenceInteractionIR] = []
    for index, left in enumerate(layout.sites):
        for right in layout.sites[index + 1 :]:
            distance = math.dist(left.position, right.position)
            coefficient = (
                math.pi * (blockade / distance) ** 6
                if blockade > 0.0 and distance < blockade
                else 0.0
            )
            pair = tuple(sorted((left.logical_id, right.logical_id)))
            interactions.append(
                ReferenceInteractionIR(
                    left=pair[0],
                    right=pair[1],
                    distance=distance,
                    reference_coefficient=coefficient,
                )
            )
    return tuple(sorted(interactions, key=lambda item: (item.left, item.right)))


def _digital_qaoa_supported(target: TargetSpec) -> bool:
    typed = target.typed_capabilities
    if typed is None:
        return False
    return all(
        typed.digital_gate_status(gate) in _SUPPORTED_STATUS
        for gate in ("h", "rz", "cx", "rx")
    )


def _analog_operation_supported(target: TargetSpec, operation: str) -> bool:
    typed = target.typed_capabilities
    return typed is not None and typed.analog_status(operation) in _SUPPORTED_STATUS


def _reference_energy_scale(
    logical: LogicalHamiltonianIR,
    interactions: tuple[ReferenceInteractionIR, ...],
) -> float | None:
    by_pair = {(item.left, item.right): item for item in interactions}
    for term in logical.terms:
        if term.operator != "zz" or term.coefficient <= 0.0:
            continue
        interaction = by_pair.get(_pair_key(term.targets))
        if interaction is not None and interaction.reference_coefficient > 0.0:
            return interaction.reference_coefficient / (4.0 * term.coefficient)
    return None


def _qaa_initial_detuning(
    target: TargetSpec,
    *,
    energy_scale: float,
) -> float | None:
    """Choose a deterministic negative detuning for the easy all-ground state."""
    lower, upper = target.detuning_range
    if lower >= 0.0:
        return None
    candidate = max(lower, -max(1.0, energy_scale))
    return candidate if candidate <= upper and candidate < 0.0 else None


def _qaa_omega_limit(target: TargetSpec) -> float | None:
    """Return the positive Rabi ceiling available to a QAA protocol."""
    lower, upper = target.rabi_range
    return upper if upper > max(0.0, lower) else None


def _detuning_support(
    logical: LogicalHamiltonianIR,
    interactions: tuple[ReferenceInteractionIR, ...],
    *,
    target: TargetSpec,
    energy_scale: float,
    local_detuning: bool,
    global_drive: bool,
    absolute_tolerance: float,
) -> _DetuningSupport:
    z_by_target = {
        term.targets[0]: term.coefficient
        for term in logical.terms
        if term.operator == "z"
    }
    normalized_pair_sum = {name: 0.0 for name in logical.logical_order}
    for item in interactions:
        normalized = item.reference_coefficient / (4.0 * energy_scale)
        normalized_pair_sum[item.left] += normalized
        normalized_pair_sum[item.right] += normalized
    required = tuple(
        (
            name,
            2.0
            * energy_scale
            * (z_by_target.get(name, 0.0) + normalized_pair_sum[name]),
        )
        for name in logical.logical_order
    )
    lower, upper = target.detuning_range
    if any(
        value < lower - absolute_tolerance or value > upper + absolute_tolerance
        for _, value in required
    ):
        return _DetuningSupport(
            implementation="unsupported",
            required_values=required,
            diagnostic_codes=("PROBLEM_TARGET_CONTROL_UNSUPPORTED",),
        )
    if local_detuning:
        return _DetuningSupport(
            implementation="analog_detuning_local",
            required_values=required,
            diagnostic_codes=(),
        )
    values = tuple(value for _, value in required)
    if global_drive and values and max(values) - min(values) <= absolute_tolerance:
        return _DetuningSupport(
            implementation="analog_detuning_global",
            required_values=required,
            diagnostic_codes=(),
        )
    return _DetuningSupport(
        implementation="unsupported",
        required_values=required,
        diagnostic_codes=("PROBLEM_TARGET_CONTROL_UNSUPPORTED",),
    )


def _term_candidates(
    logical: LogicalHamiltonianIR,
    interactions: tuple[ReferenceInteractionIR, ...],
    *,
    digital_supported: bool,
    detuning_implementation: Literal[
        "analog_detuning_global",
        "analog_detuning_local",
        "unsupported",
    ],
) -> tuple[TermImplementationCandidateIR, ...]:
    by_pair = {(item.left, item.right): item for item in interactions}
    candidates: list[TermImplementationCandidateIR] = []
    for term in logical.terms:
        candidates.append(
            TermImplementationCandidateIR(
                candidate_id=f"candidate.{term.term_id}.digital",
                term_id=term.term_id,
                operator=term.operator,
                targets=term.targets,
                logical_coefficient=term.coefficient,
                implementation="digital_gate" if digital_supported else "unsupported",
                status="supported" if digital_supported else "unsupported",
                diagnostic_codes=()
                if digital_supported
                else ("PROBLEM_TARGET_CONTROL_UNSUPPORTED",),
            )
        )
        if term.operator == "z":
            supported = detuning_implementation != "unsupported"
            candidates.append(
                TermImplementationCandidateIR(
                    candidate_id=f"candidate.{term.term_id}.analog",
                    term_id=term.term_id,
                    operator=term.operator,
                    targets=term.targets,
                    logical_coefficient=term.coefficient,
                    implementation=detuning_implementation,
                    status="supported" if supported else "unsupported",
                    diagnostic_codes=()
                    if supported
                    else ("PROBLEM_TARGET_CONTROL_UNSUPPORTED",),
                )
            )
            continue
        interaction = by_pair.get(_pair_key(term.targets))
        positive = term.coefficient > 0.0
        active = interaction is not None and interaction.reference_coefficient > 0.0
        code = (
            "PROBLEM_COUPLING_SIGN_UNSUPPORTED"
            if not positive
            else "PROBLEM_COUPLING_TOLERANCE_EXCEEDED"
        )
        candidates.append(
            TermImplementationCandidateIR(
                candidate_id=f"candidate.{term.term_id}.analog",
                term_id=term.term_id,
                operator=term.operator,
                targets=term.targets,
                logical_coefficient=term.coefficient,
                implementation="analog_interaction"
                if positive and active
                else "unsupported",
                status="supported" if positive and active else "unsupported",
                reference_coefficient=(
                    None
                    if interaction is None
                    else interaction.reference_coefficient / 4.0
                ),
                diagnostic_codes=() if positive and active else (code,),
            )
        )
    return tuple(candidates)


def _digital_feasibility(
    logical: LogicalHamiltonianIR,
    *,
    budget_ok: bool,
    digital_supported: bool,
) -> ModeFeasibilityIR:
    codes: list[str] = []
    if not budget_ok:
        codes.append("PROBLEM_VARIABLE_BUDGET_EXCEEDED")
    if not digital_supported:
        codes.append("PROBLEM_TARGET_CONTROL_UNSUPPORTED")
    return ModeFeasibilityIR(
        mode="digital",
        algorithm="qaoa",
        feasible=not codes,
        digital_term_ids=tuple(term.term_id for term in logical.terms),
        diagnostic_codes=tuple(codes),
        energy_scale=1.0,
        metadata={"decomposition": "Z:RZ;ZZ:CX-RZ-CX"},
    )


def _hybrid_feasibility(
    logical: LogicalHamiltonianIR,
    interactions: tuple[ReferenceInteractionIR, ...],
    *,
    layout: ProblemLayoutIR,
    budget_ok: bool,
    digital_supported: bool,
    global_drive: bool,
    detuning: _DetuningSupport,
    energy_scale: float,
) -> ModeFeasibilityIR:
    codes: list[str] = []
    if not budget_ok:
        codes.append("PROBLEM_VARIABLE_BUDGET_EXCEEDED")
    if not layout.valid and "PROBLEM_VARIABLE_BUDGET_EXCEEDED" not in codes:
        codes.append("PROBLEM_LAYOUT_UNEMBEDDABLE")
    if not digital_supported or not global_drive:
        codes.append("PROBLEM_TARGET_CONTROL_UNSUPPORTED")
    by_pair = {(item.left, item.right): item for item in interactions}
    analog_ids: list[str] = []
    digital_ids: list[str] = []
    for term in logical.terms:
        if term.operator == "z" and detuning.implementation != "unsupported":
            analog_ids.append(term.term_id)
            continue
        if term.operator == "zz" and term.coefficient > 0.0:
            interaction = by_pair.get(_pair_key(term.targets))
            if interaction is not None and interaction.reference_coefficient > 0.0:
                analog_ids.append(term.term_id)
                normalized = interaction.reference_coefficient / (4.0 * energy_scale)
                if not math.isclose(
                    normalized, term.coefficient, rel_tol=1e-12, abs_tol=1e-12
                ):
                    digital_ids.append(term.term_id)
                continue
        digital_ids.append(term.term_id)
    if not analog_ids:
        codes.append("PROBLEM_DAD_STRUCTURE_INVALID")
    return ModeFeasibilityIR(
        mode="hybrid",
        algorithm="qaoa",
        feasible=not codes,
        analog_term_ids=tuple(analog_ids),
        digital_term_ids=tuple(digital_ids),
        diagnostic_codes=tuple(dict.fromkeys(codes)),
        energy_scale=energy_scale,
        metadata={
            "topology": "dad",
            "split": "exact_commuting_diagonal",
            "state_space": "local_logical_two_level_reference",
            "detuning_implementation": detuning.implementation,
            "required_detuning": dict(detuning.required_values),
        },
    )


def _analog_feasibility(
    logical: LogicalHamiltonianIR,
    interactions: tuple[ReferenceInteractionIR, ...],
    *,
    layout: ProblemLayoutIR,
    budget_ok: bool,
    global_drive: bool,
    detuning: _DetuningSupport,
    energy_scale: float,
    initial_detuning: float | None,
    omega_limit: float | None,
    absolute_tolerance: float,
    relative_tolerance: float,
) -> ModeFeasibilityIR:
    codes: list[str] = []
    if not budget_ok:
        codes.append("PROBLEM_VARIABLE_BUDGET_EXCEEDED")
    if not layout.valid and "PROBLEM_VARIABLE_BUDGET_EXCEEDED" not in codes:
        codes.append("PROBLEM_LAYOUT_UNEMBEDDABLE")
    if not global_drive or detuning.implementation == "unsupported":
        codes.extend(
            detuning.diagnostic_codes or ("PROBLEM_TARGET_CONTROL_UNSUPPORTED",)
        )
    if initial_detuning is None or omega_limit is None:
        codes.append("PROBLEM_TARGET_CONTROL_UNSUPPORTED")
    logical_pairs = {
        _pair_key(term.targets): term for term in logical.terms if term.operator == "zz"
    }
    interaction_pairs = {(item.left, item.right): item for item in interactions}
    for pair, term in logical_pairs.items():
        if term.coefficient < 0.0:
            codes.append("PROBLEM_COUPLING_SIGN_UNSUPPORTED")
            continue
        item = interaction_pairs.get(pair)
        normalized = (
            0.0 if item is None else item.reference_coefficient / (4.0 * energy_scale)
        )
        if not math.isclose(
            normalized,
            term.coefficient,
            rel_tol=relative_tolerance,
            abs_tol=absolute_tolerance,
        ):
            codes.append("PROBLEM_COUPLING_TOLERANCE_EXCEEDED")
    for pair, item in interaction_pairs.items():
        if pair in logical_pairs or item.reference_coefficient == 0.0:
            continue
        normalized = item.reference_coefficient / (4.0 * energy_scale)
        if abs(normalized) > absolute_tolerance:
            codes.append("PROBLEM_COUPLING_TOLERANCE_EXCEEDED")
    unique_codes = tuple(dict.fromkeys(codes))
    feasible = not unique_codes
    if not feasible and "PROBLEM_AHS_NOT_EXPRESSIBLE" not in unique_codes:
        unique_codes = (*unique_codes, "PROBLEM_AHS_NOT_EXPRESSIBLE")
    return ModeFeasibilityIR(
        mode="analog",
        algorithm="qaa",
        feasible=feasible,
        analog_term_ids=tuple(term.term_id for term in logical.terms)
        if feasible
        else (),
        diagnostic_codes=unique_codes,
        energy_scale=energy_scale,
        metadata={
            "protocol": "qaa",
            "complete_analog_coverage": feasible,
            "detuning_implementation": detuning.implementation,
            "required_detuning": dict(detuning.required_values),
            "initial_detuning": initial_detuning,
            "omega_limit": omega_limit,
        },
    )


def _mapping_diagnostics(
    layout: ProblemLayoutIR,
    feasibility: tuple[ModeFeasibilityIR, ...],
) -> tuple[DiagnosticsIR, ...]:
    modes_by_code: dict[str, list[str]] = {}
    for item in feasibility:
        for code in item.diagnostic_codes:
            modes_by_code.setdefault(code, []).append(item.mode)
    for code in layout.diagnostic_codes:
        modes_by_code.setdefault(code, []).extend(("analog", "hybrid"))
    messages = {
        "PROBLEM_VARIABLE_BUDGET_EXCEEDED": (
            "Problem variables exceed the Target atom budget."
        ),
        "PROBLEM_LAYOUT_UNEMBEDDABLE": (
            "Reference layout violates Target region or spacing limits."
        ),
        "PROBLEM_COUPLING_SIGN_UNSUPPORTED": (
            "Repulsive Rydberg interaction cannot express a negative ZZ coupling."
        ),
        "PROBLEM_COUPLING_TOLERANCE_EXCEEDED": (
            "Reference interaction does not match the logical coupling tolerance."
        ),
        "PROBLEM_TARGET_CONTROL_UNSUPPORTED": (
            "Target control capabilities cannot implement the requested mode."
        ),
        "PROBLEM_DAD_STRUCTURE_INVALID": (
            "Hybrid D-A-D requires a non-empty Analog Hamiltonian contribution."
        ),
        "PROBLEM_AHS_NOT_EXPRESSIBLE": (
            "The complete logical Hamiltonian is not expressible as Analog AHS."
        ),
    }
    return tuple(
        DiagnosticsIR(
            diagnostic_id=f"problem.mapping.{code.lower()}",
            stage="compilation",
            severity="error",
            code=code,
            message=messages[code],
            object_path="problem.mapping",
            metadata={"affected_modes": sorted(set(modes))},
        )
        for code, modes in sorted(modes_by_code.items())
    )


def _resource_estimate(logical: LogicalHamiltonianIR) -> dict[str, int]:
    z_terms = sum(term.operator == "z" for term in logical.terms)
    zz_terms = sum(term.operator == "zz" for term in logical.terms)
    variables = len(logical.logical_order)
    return {
        "logical_variables": variables,
        "logical_terms": len(logical.terms),
        "z_terms": z_terms,
        "zz_terms": zz_terms,
        "qaoa_layer_gate_estimate": variables * 2 + z_terms + zz_terms * 3,
        "state_vector_dimension": 1 << variables,
    }


def _pair_key(targets: tuple[str, ...]) -> tuple[str, str]:
    """Return a type-safe canonical key for a two-body term."""
    if len(targets) != 2:
        raise ValueError("A pair key requires exactly two targets.")
    left, right = sorted(targets)
    return left, right


def _require_text(value: object, name: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{name} must be a non-empty string.")


def _require_digest(value: object, name: str) -> None:
    if not isinstance(value, str) or _DIGEST_PATTERN.fullmatch(value) is None:
        raise ValueError(f"{name} must be a SHA-256 hash.")


def _require_unique_text(
    values: tuple[str, ...],
    name: str,
    *,
    allow_empty: bool = False,
) -> None:
    if not values and not allow_empty:
        raise ValueError(f"{name} must not be empty.")
    if any(not isinstance(value, str) or not value.strip() for value in values):
        raise ValueError(f"{name} must contain non-empty strings.")
    if len(values) != len(set(values)):
        raise ValueError(f"{name} must be unique.")


def _finite(value: object, name: str) -> float:
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        raise TypeError(f"{name} must be a real number.")
    normalized = float(value)
    if not math.isfinite(normalized):
        raise ValueError(f"{name} must be finite.")
    return normalized


def _positive(value: object, name: str) -> float:
    normalized = _finite(value, name)
    if normalized <= 0.0:
        raise ValueError(f"{name} must be positive.")
    return normalized
