"""Digital QAOA lowering from one shared Problem analysis."""

from __future__ import annotations

from dataclasses import dataclass

from cascaqit.algorithms import QAOA, AnsatzSpecIR, PauliHamiltonian
from cascaqit.compiler.problem_mapping import ProblemTermMappingIR
from cascaqit.digital import Circuit
from cascaqit.parameters import ParameterSchemaIR
from cascaqit.problems.analysis import ProblemAnalysisResult
from cascaqit.problems.optimization import OptimizationProblem

__all__ = ["DigitalLoweringArtifacts", "DigitalProblemLowerer"]


@dataclass(frozen=True)
class DigitalLoweringArtifacts:
    """Typed payload returned by the Digital Lowerer to ProblemCompiler."""

    program: Circuit
    hamiltonian: PauliHamiltonian
    ansatz: AnsatzSpecIR
    parameter_schema: ParameterSchemaIR
    term_mapping: tuple[ProblemTermMappingIR, ...]


@dataclass(frozen=True)
class DigitalProblemLowerer:
    """Reuse the existing QAOA implementation under the unified compiler."""

    def lower(
        self,
        problem: OptimizationProblem,
        *,
        analysis: ProblemAnalysisResult,
        layers: int,
        mis_penalty: float,
        mwis_penalty: float | None = None,
    ) -> DigitalLoweringArtifacts:
        """Build the canonical QAOA Circuit and exact Digital term mapping."""
        if not isinstance(analysis, ProblemAnalysisResult):
            raise TypeError("analysis must be ProblemAnalysisResult.")
        feasibility = analysis.mapping_plan.feasibility_for("digital")
        if not feasibility.feasible:
            raise ValueError("Digital lowering requires a feasible mapping plan.")

        qaoa = QAOA(
            problem,
            layers=layers,
            mis_penalty=mis_penalty,
            mwis_penalty=mwis_penalty,
        )
        if (
            qaoa.hamiltonian.stable_hash()
            != analysis.logical_hamiltonian.pauli_hamiltonian_hash
        ):
            raise ValueError("QAOA and shared analysis Hamiltonians do not match.")

        source = qaoa.build_circuit()
        # Compose the proven QAOA circuit into a fresh builder so unified
        # provenance is added without copying or changing gate mathematics.
        program = Circuit(
            source.qubits,
            program_id=source.program_id,
            metadata={
                "algorithm": "qaoa",
                "algorithm_id": qaoa.algorithm_id,
                "layers": layers,
                "analysis_hash": analysis.analysis_hash,
                "problem_hash": analysis.canonical_problem.problem_hash,
                "logical_hamiltonian_hash": (
                    analysis.logical_hamiltonian.stable_hash()
                ),
                "lowerer": "DigitalProblemLowerer",
                "cost_decomposition": "Z:RZ;ZZ:CX-RZ-CX",
                "mixer": "RX",
            },
        ).compose(source)
        return DigitalLoweringArtifacts(
            program=program,
            hamiltonian=qaoa.hamiltonian,
            ansatz=qaoa.ansatz_spec(),
            parameter_schema=ParameterSchemaIR.from_parameters(program.parameters),
            term_mapping=_digital_term_mapping(analysis),
        )


def _digital_term_mapping(
    analysis: ProblemAnalysisResult,
) -> tuple[ProblemTermMappingIR, ...]:
    """把共享逻辑 Hamiltonian 完整分配给 Digital gate 实现。"""
    # QAOA 与 VQE 的 Ansatz 不同，但两者执行的是同一个 Problem
    # Hamiltonian。逐项来源、系数守恒和误差容差必须由同一个函数生成，
    # 避免算法分支逐渐形成不一致的映射证据。
    return tuple(
        ProblemTermMappingIR(
            mapping_id=f"mapping.digital.{term.term_id}",
            logical_term_id=term.term_id,
            source_term_ids=term.source_term_ids,
            operator=term.operator,
            targets=term.targets,
            logical_coefficient=term.coefficient,
            analog_coefficient=0.0,
            digital_coefficient=term.coefficient,
            implementation="digital_gate",
            absolute_tolerance=analysis.mapping_plan.absolute_tolerance,
            relative_tolerance=analysis.mapping_plan.relative_tolerance,
        )
        for term in analysis.logical_hamiltonian.terms
    )
