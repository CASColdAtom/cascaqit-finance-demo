"""Quantum adiabatic lowering from shared optimization Problem analysis."""

from __future__ import annotations

import json
import math
from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import Any, Literal

from cascaqit.analog import AHSProgram, AtomRegister, SitePattern, Waveform
from cascaqit.compiler.problem_mapping import ProblemTermMappingIR
from cascaqit.exceptions import CapabilityError
from cascaqit.native_ir.base import IRMixin
from cascaqit.parameters import Parameter, ParameterBindIR, ParameterSchemaIR
from cascaqit.parameters.canonical import ParameterScalar
from cascaqit.problems.analysis import ProblemAnalysisResult
from cascaqit.targets import TargetSpec

__all__ = ["AnalogLoweringArtifacts", "AnalogProblemLowerer", "QAAProtocolIR"]

QAA_DETUNING_IMPLEMENTATIONS = {
    "analog_detuning_global",
    "analog_detuning_local",
}
QAA_PROTOCOL_SCHEMA_VERSION = "cascaqit.problem_qaa.v1"
_MIN_POSITIVE = 1e-12


@dataclass(frozen=True)
class QAAProtocolIR(IRMixin):
    """Concrete three-stage controls for one bound adiabatic program."""

    protocol_id: str
    anneal_time: float
    omega_max: float
    initial_detuning: float
    final_detuning: tuple[tuple[str, float], ...]
    energy_scale: float
    detuning_implementation: Literal[
        "analog_detuning_global",
        "analog_detuning_local",
    ]
    target_id: str
    target_hash: str
    ramp_fraction: float = 0.25
    phase: float = 0.0
    schedule: Literal["linear_three_stage"] = "linear_three_stage"
    local_reference: bool = True
    hardware_executable: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = QAA_PROTOCOL_SCHEMA_VERSION

    def __post_init__(self) -> None:
        for name in ("protocol_id", "target_id"):
            value = getattr(self, name)
            if not isinstance(value, str) or not value.strip():
                raise ValueError(f"{name} must be a non-empty string.")
        if len(self.target_hash) != 64 or any(
            character not in "0123456789abcdef" for character in self.target_hash
        ):
            raise ValueError("target_hash must be a lowercase SHA-256 digest.")
        for name in ("anneal_time", "omega_max", "energy_scale"):
            value = _finite(getattr(self, name), name)
            if value <= 0.0:
                raise ValueError(f"{name} must be positive.")
            object.__setattr__(self, name, value)
        initial = _finite(self.initial_detuning, "initial_detuning")
        if initial >= 0.0:
            raise ValueError("initial_detuning must be negative.")
        object.__setattr__(self, "initial_detuning", initial)
        final = tuple(
            (str(name), _finite(value, "final_detuning"))
            for name, value in self.final_detuning
        )
        if not final or len({name for name, _ in final}) != len(final):
            raise ValueError("final_detuning must contain unique logical ids.")
        object.__setattr__(self, "final_detuning", final)
        ramp = _finite(self.ramp_fraction, "ramp_fraction")
        if not 0.0 < ramp < 0.5:
            raise ValueError("ramp_fraction must be between zero and one half.")
        object.__setattr__(self, "ramp_fraction", ramp)
        object.__setattr__(self, "phase", _finite(self.phase, "phase"))
        if self.detuning_implementation not in QAA_DETUNING_IMPLEMENTATIONS:
            raise ValueError("Unsupported QAA detuning implementation.")
        if self.schedule != "linear_three_stage":
            raise ValueError("Unsupported QAA schedule.")
        if not self.local_reference or self.hardware_executable:
            raise ValueError("The public QAA protocol is local-reference only.")
        object.__setattr__(self, "metadata", dict(self.metadata))

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> QAAProtocolIR:
        """Restore a QAA protocol from serialized data."""
        return cls(
            protocol_id=str(data["protocol_id"]),
            anneal_time=float(data["anneal_time"]),
            omega_max=float(data["omega_max"]),
            initial_detuning=float(data["initial_detuning"]),
            final_detuning=tuple(
                (str(item[0]), float(item[1])) for item in data["final_detuning"]
            ),
            energy_scale=float(data["energy_scale"]),
            detuning_implementation=data["detuning_implementation"],
            target_id=str(data["target_id"]),
            target_hash=str(data["target_hash"]),
            ramp_fraction=float(data.get("ramp_fraction", 0.25)),
            phase=float(data.get("phase", 0.0)),
            schedule=data.get("schedule", "linear_three_stage"),
            local_reference=bool(data.get("local_reference", True)),
            hardware_executable=bool(data.get("hardware_executable", False)),
            metadata=dict(data.get("metadata", {})),
            schema_version=str(data.get("schema_version", QAA_PROTOCOL_SCHEMA_VERSION)),
        )

    @classmethod
    def from_json(cls, text: str) -> QAAProtocolIR:
        """Restore a QAA protocol from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("QAAProtocolIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class AnalogLoweringArtifacts:
    """Program, protocol, parameters, and mappings produced by QAA lowering."""

    program: AHSProgram
    protocol: QAAProtocolIR
    parameter_schema: ParameterSchemaIR
    parameter_bind: ParameterBindIR
    term_mapping: tuple[ProblemTermMappingIR, ...]


@dataclass(frozen=True)
class AnalogProblemLowerer:
    """Lower one fully Analog-expressible analysis to a QAA AHS program."""

    default_anneal_time: float = 1.0
    default_omega_max: float = 1.0
    ramp_fraction: float = 0.25

    def lower(
        self,
        analysis: ProblemAnalysisResult,
        *,
        target: TargetSpec,
    ) -> AnalogLoweringArtifacts:
        """Build the default-bound program after full Analog feasibility."""
        _require_feasible_analysis(analysis)
        if target.stable_hash() != analysis.mapping_plan.target_hash:
            raise ValueError("Target does not match the shared mapping plan.")
        schema = self.parameter_schema(analysis, target=target)
        parameter_bind = ParameterBindIR.create(
            parameter_bind_id=f"{analysis.analysis_id}.analog.default",
            parameter_schema=schema,
            values={},
            metadata={
                "mode": "analog",
                "algorithm": "qaa",
                "binding_role": "default_preview",
            },
        )
        term_mapping = self.term_mapping(analysis)
        program, protocol = self.build_program(
            analysis,
            target_id=target.target_id,
            target_hash=target.stable_hash(),
            values=parameter_bind.values,
        )
        _require_target_valid(program, target=target, analysis=analysis)
        return AnalogLoweringArtifacts(
            program=program,
            protocol=protocol,
            parameter_schema=schema,
            parameter_bind=parameter_bind,
            term_mapping=term_mapping,
        )

    def bind(
        self,
        analysis: ProblemAnalysisResult,
        *,
        parameter_schema: ParameterSchemaIR,
        term_mapping: tuple[ProblemTermMappingIR, ...],
        target_id: str,
        target_hash: str,
        target: TargetSpec,
        values: Mapping[str, float],
    ) -> tuple[AHSProgram, QAAProtocolIR, ParameterBindIR]:
        """Validate parameters and rebuild the complete control protocol."""
        _require_feasible_analysis(analysis)
        if target.stable_hash() != target_hash:
            raise ValueError("Target does not match the bound QAA protocol.")
        if any(not item.conserved for item in term_mapping):
            raise ValueError("Analog term mapping is not conserved.")
        parameter_bind = ParameterBindIR.create(
            parameter_bind_id=f"{analysis.analysis_id}.analog.bind",
            parameter_schema=parameter_schema,
            values=values,
            metadata={"mode": "analog", "algorithm": "qaa"},
        )
        program, protocol = self.build_program(
            analysis,
            target_id=target_id,
            target_hash=target_hash,
            values=parameter_bind.values,
        )
        _require_target_valid(program, target=target, analysis=analysis)
        return program, protocol, parameter_bind

    def parameter_schema(
        self,
        analysis: ProblemAnalysisResult,
        *,
        target: TargetSpec,
    ) -> ParameterSchemaIR:
        """Derive protocol bounds from Target timing and control ranges."""
        timing = target.typed_capabilities.timing if target.typed_capabilities else None
        minimum_time = max(
            _MIN_POSITIVE,
            0.0
            if timing is None or timing.min_duration is None
            else timing.min_duration,
        )
        maximum_time = (
            None
            if timing is None or timing.max_duration is None
            else timing.max_duration
        )
        default_time = max(self.default_anneal_time, minimum_time)
        if maximum_time is not None:
            default_time = min(default_time, maximum_time)
        omega_lower, omega_upper = target.rabi_range
        minimum_omega = max(_MIN_POSITIVE, omega_lower)
        if omega_upper <= minimum_omega:
            raise ValueError("Target does not provide a positive QAA Rabi range.")
        default_omega = min(
            max(self.default_omega_max, minimum_omega),
            omega_upper,
        )
        anneal_time = Parameter(
            "anneal_time",
            unit="us",
            default=default_time,
            lower_bound=minimum_time,
            upper_bound=maximum_time,
            compile_impact="recompile",
            metadata={"controls": "all_qaa_waveform_times"},
        )
        omega_max = Parameter(
            "omega_max",
            unit="rad/us",
            default=default_omega,
            lower_bound=minimum_omega,
            upper_bound=omega_upper,
            compile_impact="recompile",
            metadata={"controls": "global_qaa_rabi"},
        )
        return ParameterSchemaIR(
            parameters=(anneal_time.to_ir(), omega_max.to_ir()),
            metadata={
                "mode": "analog",
                "algorithm": "qaa",
                "schedule": "linear_three_stage",
                "target_id": target.target_id,
                "analysis_hash": analysis.analysis_hash,
            },
        )

    def term_mapping(
        self,
        analysis: ProblemAnalysisResult,
    ) -> tuple[ProblemTermMappingIR, ...]:
        """Assign every logical term wholly to the Analog Hamiltonian."""
        _require_feasible_analysis(analysis)
        feasibility = analysis.mapping_plan.feasibility_for("analog")
        implementation = _detuning_implementation(feasibility.metadata)
        return tuple(
            ProblemTermMappingIR(
                mapping_id=f"mapping.analog.{term.term_id}",
                logical_term_id=term.term_id,
                source_term_ids=term.source_term_ids,
                operator=term.operator,
                targets=term.targets,
                logical_coefficient=term.coefficient,
                analog_coefficient=term.coefficient,
                digital_coefficient=0.0,
                implementation=(
                    "analog_interaction" if term.operator == "zz" else implementation
                ),
                absolute_tolerance=analysis.mapping_plan.absolute_tolerance,
                relative_tolerance=analysis.mapping_plan.relative_tolerance,
            )
            for term in analysis.logical_hamiltonian.terms
        )

    def build_program(
        self,
        analysis: ProblemAnalysisResult,
        *,
        target_id: str,
        target_hash: str,
        values: Mapping[str, ParameterScalar],
    ) -> tuple[AHSProgram, QAAProtocolIR]:
        """Build a numeric AHS program whose final Hamiltonian matches analysis."""
        _require_feasible_analysis(analysis)
        anneal_time = float(values["anneal_time"])
        omega_max = float(values["omega_max"])
        feasibility = analysis.mapping_plan.feasibility_for("analog")
        assert feasibility.energy_scale is not None
        implementation = _detuning_implementation(feasibility.metadata)
        initial_detuning = _required_scalar(
            feasibility.metadata,
            "initial_detuning",
        )
        final_detuning = _required_detuning(feasibility.metadata)
        logical_order = analysis.canonical_problem.logical_order
        if tuple(final_detuning) != logical_order:
            raise ValueError("QAA final detuning order does not match logical order.")

        sites = {item.logical_id: item for item in analysis.mapping_plan.layout.sites}
        register = AtomRegister.custom(
            tuple(sites[name].position for name in logical_order),
            site_ids=logical_order,
            atom_ids=logical_order,
        )
        ramp_time = self.ramp_fraction * anneal_time
        rabi = Waveform.piecewise_linear(
            times=(0.0, ramp_time, anneal_time - ramp_time, anneal_time),
            values=(0.0, omega_max, omega_max, 0.0),
            waveform_id="qaa.rabi",
        )
        if implementation == "analog_detuning_global":
            terminal = final_detuning[logical_order[0]]
            detuning = Waveform.linear(
                initial_detuning,
                terminal,
                duration=anneal_time,
                waveform_id="qaa.detuning.global",
            )
        else:
            # A common negative offset prepares the all-ground state. Addressed
            # terms then grow from zero to the exact final site detunings.
            detuning = Waveform.linear(
                initial_detuning,
                0.0,
                duration=anneal_time,
                waveform_id="qaa.detuning.global",
            )
        program = AHSProgram(
            register,
            program_id=f"program.{analysis.canonical_problem.problem_id}.qaa",
        ).drive(rabi=rabi, detuning=detuning, phase=0.0)
        if implementation == "analog_detuning_local":
            _append_grouped_local_detuning(
                program,
                logical_order=logical_order,
                final_detuning=final_detuning,
                duration=anneal_time,
                tolerance=analysis.mapping_plan.absolute_tolerance,
            )
        program.measure(measurement_id="problem")
        protocol = QAAProtocolIR(
            protocol_id=f"protocol.{analysis.canonical_problem.problem_id}.qaa",
            anneal_time=anneal_time,
            omega_max=omega_max,
            initial_detuning=initial_detuning,
            final_detuning=tuple(final_detuning.items()),
            energy_scale=feasibility.energy_scale,
            detuning_implementation=implementation,
            target_id=target_id,
            target_hash=target_hash,
            ramp_fraction=self.ramp_fraction,
            metadata={
                "analysis_hash": analysis.analysis_hash,
                "problem_hash": analysis.canonical_problem.problem_hash,
                "final_hamiltonian": "normalized_logical_hamiltonian",
            },
        )
        program.to_ir()
        return program, protocol


def _append_grouped_local_detuning(
    program: AHSProgram,
    *,
    logical_order: tuple[str, ...],
    final_detuning: Mapping[str, float],
    duration: float,
    tolerance: float,
) -> None:
    """Represent arbitrary signed site detuning with at most two controls."""
    positive = max(
        0.0,
        max((final_detuning[name] for name in logical_order), default=0.0),
    )
    negative = min(
        0.0,
        min((final_detuning[name] for name in logical_order), default=0.0),
    )
    for label, amplitude in (("positive", positive), ("negative", negative)):
        if math.isclose(amplitude, 0.0, abs_tol=tolerance):
            continue
        weights = tuple(
            final_detuning[name] / amplitude
            if final_detuning[name] * amplitude > 0.0
            else 0.0
            for name in logical_order
        )
        program.local_detuning(
            waveform=Waveform.linear(
                0.0,
                amplitude,
                duration=duration,
                waveform_id=f"qaa.detuning.local.{label}",
            ),
            pattern=SitePattern(site_ids=logical_order, weights=weights),
        )


def _require_feasible_analysis(analysis: ProblemAnalysisResult) -> None:
    if not isinstance(analysis, ProblemAnalysisResult):
        raise TypeError("analysis must be ProblemAnalysisResult.")
    feasibility = analysis.mapping_plan.feasibility_for("analog")
    if not feasibility.feasible:
        raise ValueError("Analog lowering requires a feasible mapping plan.")
    if not feasibility.metadata.get("complete_analog_coverage", False):
        raise ValueError("Analog lowering requires complete Hamiltonian coverage.")


def _require_target_valid(
    program: AHSProgram,
    *,
    target: TargetSpec,
    analysis: ProblemAnalysisResult,
) -> None:
    errors = tuple(
        item
        for item in program.validate(target, shots=1).diagnostics
        if item.severity == "error"
    )
    if not errors:
        return
    raise CapabilityError(
        "Generated QAA controls are not executable on the selected Target.",
        code=errors[0].code,
        stage="compilation",
        object_path="problem.compile.analog.controls",
        source_hashes={
            "analysis_hash": analysis.analysis_hash,
            "problem_hash": analysis.canonical_problem.problem_hash,
            "target_hash": target.stable_hash(),
        },
        metadata={"diagnostic_codes": [item.code for item in errors]},
        diagnostics=errors,
    )


def _detuning_implementation(
    metadata: Mapping[str, Any],
) -> Literal["analog_detuning_global", "analog_detuning_local"]:
    value = str(metadata.get("detuning_implementation", "unsupported"))
    if value == "analog_detuning_global":
        return "analog_detuning_global"
    if value == "analog_detuning_local":
        return "analog_detuning_local"
    raise ValueError("Analog mapping has no supported detuning implementation.")


def _required_detuning(metadata: Mapping[str, Any]) -> dict[str, float]:
    raw = metadata.get("required_detuning")
    if not isinstance(raw, dict):
        raise TypeError("required_detuning must be a dictionary.")
    return {
        str(name): _finite(value, "required_detuning") for name, value in raw.items()
    }


def _required_scalar(metadata: Mapping[str, Any], name: str) -> float:
    value = metadata.get(name)
    if value is None:
        raise ValueError(f"Analog mapping metadata is missing {name}.")
    return _finite(value, name)


def _finite(value: object, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{name} must be a real number.")
    numeric = float(value)
    if not math.isfinite(numeric):
        raise ValueError(f"{name} must be finite.")
    return numeric
