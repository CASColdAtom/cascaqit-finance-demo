"""Deterministic public reference compiler for native programs."""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field, replace
from typing import Any, cast

from cascaqit.compiler.cache import (
    CompileCacheKeyIR,
    build_compile_cache_key,
    build_compile_cache_report,
)
from cascaqit.compiler.pass_pipeline import build_compiler_pass_pipeline
from cascaqit.control import (
    ControlScheduleIR,
    ControlSystemIR,
    build_control_schedule,
    diagnose_control_support,
    validate_control_schedule,
)
from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.digital import DigitalProgramIR, GateIR
from cascaqit.discretization import DiscretizationPolicy, discretize_program
from cascaqit.exceptions import ProgramValidationError
from cascaqit.native_ir.base import IRMixin, stable_json
from cascaqit.native_ir.models import (
    ANALOG_BIT_ORDER_CONVENTION,
    ProgramIR,
    SiteAddressingIR,
    WaveformIR,
)
from cascaqit.native_ir.reference_compiled import ReferenceCompiledProgramIR
from cascaqit.parameters.ir import ParameterSchemaIR
from cascaqit.targets import (
    DigitalGateCapability,
    TargetSnapshot,
    TargetSpec,
)

__all__ = ["COMPILER_VERSION", "CompilerOptions", "CompilerPipeline"]

COMPILER_VERSION = "cascaqit-compiler-skeleton.0"


@dataclass(frozen=True)
class CompilerOptions(IRMixin):
    """Options that affect compiler output and compile cache keys."""

    optimization_level: int = 0
    discretization_policy: DiscretizationPolicy = "nearest"
    lowering: str = "analog_draft"
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Reject optimization levels that have no implemented semantics."""
        object.__setattr__(self, "optimization_level", int(self.optimization_level))
        if self.optimization_level != 0:
            raise ValueError("Public reference compilation only supports O0.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CompilerOptions:
        """Build compiler options from a JSON-compatible dictionary."""
        policy = str(data.get("discretization_policy", "nearest"))
        if policy not in ("nearest", "floor", "ceil", "strict"):
            raise ValueError(f"Unsupported discretization policy: {policy}")
        return cls(
            optimization_level=int(data.get("optimization_level", 0)),
            discretization_policy=cast(DiscretizationPolicy, policy),
            lowering=str(data.get("lowering", "analog_draft")),
            metadata=dict(data.get("metadata", {})),
        )


class CompilerPipeline:
    """Minimal compiler pipeline for deterministic analog draft lowering."""

    def __init__(
        self,
        *,
        compiler_version: str = COMPILER_VERSION,
        options: CompilerOptions | None = None,
    ) -> None:
        self.compiler_version = compiler_version
        self.options = CompilerOptions() if options is None else options

    def compile(
        self,
        program: ProgramIR | DigitalProgramIR,
        *,
        target_snapshot: TargetSnapshot,
    ) -> ReferenceCompiledProgramIR:
        """Compile a native program using only public target facts."""
        if isinstance(program, DigitalProgramIR):
            return self._compile_digital(
                program,
                target_snapshot=target_snapshot,
            )
        if not isinstance(program, ProgramIR):
            raise TypeError(
                "CompilerPipeline.compile accepts ProgramIR or DigitalProgramIR."
            )
        return self._compile_analog(
            program,
            target_snapshot=target_snapshot,
        )

    def _compile_analog(
        self,
        program: ProgramIR,
        *,
        target_snapshot: TargetSnapshot,
    ) -> ReferenceCompiledProgramIR:
        """Compile an analog program into a public reference result."""
        source_program_hash = program.stable_hash()
        discretized_program = self._ensure_discretized(program, target_snapshot)
        control_system = ControlSystemIR.from_target_spec(target_snapshot.target_spec)
        control_schedule = _compiler_control_schedule(
            discretized_program,
            control_system,
        )
        diagnostics = tuple(
            self._diagnostics(
                discretized_program,
                target_snapshot,
                control_system=control_system,
                control_schedule=control_schedule,
            )
        )
        source_map = _source_map(discretized_program, control_system)
        unsupported_features = tuple(
            _unsupported_features(
                discretized_program,
                control_system=control_system,
                target_spec=target_snapshot.target_spec,
            )
        )
        resource_estimate = _resource_estimate(discretized_program)
        compiler_passes = _analog_compiler_passes(
            diagnostics,
            program=discretized_program,
            target_snapshot=target_snapshot,
            control_system=control_system,
            source_map=source_map,
            resource_estimate=resource_estimate,
        )
        parameter_schema_hash = discretized_program.parameter_schema.stable_hash()
        discretized_program_hash = discretized_program.stable_hash()
        compile_cache_key_ir = self._compile_cache_key_ir(
            source_program_hash=source_program_hash,
            discretized_program_hash=discretized_program_hash,
            target_snapshot=target_snapshot,
            parameter_schema_hash=parameter_schema_hash,
            bit_order_version=self._bit_order_version(discretized_program),
        )
        compile_cache_report = build_compile_cache_report(
            compile_cache_key_ir,
            report_id=f"compile_cache.{discretized_program.program_id}",
            metadata={
                "compiled_program_id": f"compiled.{discretized_program.program_id}"
            },
        )
        pass_pipeline = _build_compiler_pass_pipeline_metadata(
            compiler_passes,
            pipeline_id=f"compiler.pipeline.{discretized_program.program_id}",
            program_type="analog",
            compiler_version=self.compiler_version,
            source_program_hash=source_program_hash,
            discretized_program_hash=discretized_program_hash,
            target_snapshot=target_snapshot,
            parameter_schema_hash=parameter_schema_hash,
            compiler_options=self.options.to_dict(),
            source_map=source_map,
            resource_estimate=resource_estimate,
            compile_cache_key=compile_cache_key_ir.cache_key,
            metadata={
                "compiled_program_id": f"compiled.{discretized_program.program_id}",
                "compiled_program_hash_status": "excluded_to_avoid_metadata_recursion",
            },
        )

        return ReferenceCompiledProgramIR(
            compiled_program_id=f"compiled.{discretized_program.program_id}",
            source_program_hash=source_program_hash,
            discretized_program_hash=discretized_program_hash,
            target_id=target_snapshot.target_id,
            target_version=target_snapshot.target_version,
            target_snapshot_hash=target_snapshot.target_snapshot_hash,
            compiler_version=self.compiler_version,
            compiler_options=self.options.to_dict(),
            optimization_level=self.options.optimization_level,
            program_type=discretized_program.program_type,
            compilation_scope="public_reference",
            native_operation_set=_native_operation_set(discretized_program),
            compiled_schedule=_compiled_schedule(
                discretized_program,
                control_schedule=control_schedule,
            ),
            channel_schedule=_channel_schedule(discretized_program, control_system),
            measurement_schedule=_measurement_schedule(discretized_program),
            parameter_schema=discretized_program.parameter_schema,
            bindable_parameters=tuple(
                parameter.name
                for parameter in discretized_program.parameter_schema.parameters
            ),
            mapping_info=_mapping_info(discretized_program),
            source_map=source_map,
            resource_estimate=resource_estimate,
            unsupported_features=unsupported_features,
            compile_cache_key=compile_cache_key_ir.cache_key,
            artifact_refs=(),
            diagnostics=diagnostics,
            metadata={
                "lowering": self.options.lowering,
                "parameter_schema_hash": parameter_schema_hash,
                "compile_cache_key_ir": compile_cache_key_ir.to_dict(),
                "compile_cache_report": compile_cache_report.to_dict(),
                "source_lifecycle_state": program.lifecycle_state,
                "discretized_lifecycle_state": discretized_program.lifecycle_state,
                "control_system_id": control_system.control_system_id,
                **_compiler_control_schedule_metadata(control_schedule),
                "control_binding": "target_derived_control_system_ir",
                "production_channel_allocation_performed": False,
                "compiler_passes": list(compiler_passes),
                "compiler_pass_pipeline": pass_pipeline,
                "compiler_diagnostic_taxonomy": (
                    _compiler_diagnostic_taxonomy(diagnostics)
                ),
                "compiler_pipeline_contract": _compiler_pipeline_contract(
                    program_type="analog",
                    hardware_payload_emitted=False,
                ),
            },
        )

    def _compile_digital(
        self,
        program: DigitalProgramIR,
        *,
        target_snapshot: TargetSnapshot,
    ) -> ReferenceCompiledProgramIR:
        """Compile a digital program into a public reference result."""
        source_program_hash = program.stable_hash()
        lowering = _digital_lowering_analysis(
            program,
            target_snapshot,
            compiler_version=self.compiler_version,
        )
        diagnostics = tuple(lowering["diagnostics"])
        source_map = _digital_source_map(program)
        resource_estimate = _digital_resource_estimate(program)
        compiler_passes = _digital_compiler_passes(
            diagnostics,
            program=program,
            target_snapshot=target_snapshot,
            lowering=lowering,
            source_map=source_map,
            resource_estimate=resource_estimate,
        )
        parameter_schema = ParameterSchemaIR()
        parameter_schema_hash = parameter_schema.stable_hash()
        bit_order_version = "digital_qubit_order"
        discretized_program_hash = source_program_hash
        compile_cache_key_ir = self._compile_cache_key_ir(
            source_program_hash=source_program_hash,
            discretized_program_hash=discretized_program_hash,
            target_snapshot=target_snapshot,
            parameter_schema_hash=parameter_schema_hash,
            bit_order_version=bit_order_version,
        )
        compile_cache_report = build_compile_cache_report(
            compile_cache_key_ir,
            report_id=f"compile_cache.{program.program_id}",
            metadata={"compiled_program_id": f"compiled.{program.program_id}"},
        )
        pass_pipeline = _build_compiler_pass_pipeline_metadata(
            compiler_passes,
            pipeline_id=f"compiler.pipeline.{program.program_id}",
            program_type="digital",
            compiler_version=self.compiler_version,
            source_program_hash=source_program_hash,
            discretized_program_hash=discretized_program_hash,
            target_snapshot=target_snapshot,
            parameter_schema_hash=parameter_schema_hash,
            compiler_options=self.options.to_dict(),
            source_map=source_map,
            resource_estimate=resource_estimate,
            compile_cache_key=compile_cache_key_ir.cache_key,
            metadata={
                "compiled_program_id": f"compiled.{program.program_id}",
                "compiled_program_hash_status": "excluded_to_avoid_metadata_recursion",
                "digital_discretization": "not_applicable",
            },
        )
        return ReferenceCompiledProgramIR(
            compiled_program_id=f"compiled.{program.program_id}",
            source_program_hash=source_program_hash,
            discretized_program_hash=discretized_program_hash,
            target_id=target_snapshot.target_id,
            target_version=target_snapshot.target_version,
            target_snapshot_hash=target_snapshot.target_snapshot_hash,
            compiler_version=self.compiler_version,
            compiler_options=self.options.to_dict(),
            optimization_level=self.options.optimization_level,
            program_type="digital",
            compilation_scope="public_reference",
            native_operation_set=tuple(lowering["operations"]),
            compiled_schedule=_digital_compiled_schedule(program),
            channel_schedule=_digital_channel_schedule(program),
            measurement_schedule=_digital_measurement_schedule(program),
            parameter_schema=parameter_schema,
            bindable_parameters=(),
            mapping_info=_digital_mapping_info(program),
            source_map=source_map,
            resource_estimate=resource_estimate,
            unsupported_features=tuple(lowering["unsupported_features"]),
            compile_cache_key=compile_cache_key_ir.cache_key,
            artifact_refs=(),
            diagnostics=diagnostics,
            metadata={
                "lowering": "digital_target_aware_static_gate_mock",
                "parameter_schema_hash": parameter_schema_hash,
                "compile_cache_key_ir": compile_cache_key_ir.to_dict(),
                "compile_cache_report": compile_cache_report.to_dict(),
                "source_lifecycle_state": "ir_only",
                "discretized_lifecycle_state": "not_applicable",
                "target_aware_lowering": lowering["checks_ran"],
                "digital_lowering": lowering["summary"],
                "mock_backend_only": True,
                "hardware_payload_emitted": False,
                "digital_live_hardware": "unsupported",
                "compiler_passes": compiler_passes,
                "compiler_pass_pipeline": pass_pipeline,
                "compiler_diagnostic_taxonomy": (
                    _compiler_diagnostic_taxonomy(diagnostics)
                ),
                "compiler_pipeline_contract": _compiler_pipeline_contract(
                    program_type="digital",
                    hardware_payload_emitted=False,
                ),
            },
        )

    def _ensure_discretized(
        self,
        program: ProgramIR,
        target_snapshot: TargetSnapshot,
    ) -> ProgramIR:
        """Return a discretized program without changing caller-owned objects."""
        if program.lifecycle_state == "discretized":
            return program
        discretized, report = discretize_program(
            program,
            target_snapshot.target_spec,
            policy=self.options.discretization_policy,
        )
        blocking = tuple(
            diagnostic
            for diagnostic in report.diagnostics
            if diagnostic.severity in {"error", "critical"}
        )
        if blocking:
            first = blocking[0]
            raise ProgramValidationError(
                "Reference compile blocked by discretization diagnostics.",
                code="COMPILER_DISCRETIZATION_BLOCKED",
                stage="discretization",
                object_path=first.object_path,
                suggestion=first.suggestion,
                diagnostics=blocking,
                metadata={
                    "discretization_policy": self.options.discretization_policy,
                    "diagnostic_codes": [item.code for item in blocking],
                },
            )
        return replace(discretized, lifecycle_state="discretized")

    def _compile_cache_key_ir(
        self,
        *,
        source_program_hash: str,
        discretized_program_hash: str,
        target_snapshot: TargetSnapshot,
        parameter_schema_hash: str,
        bit_order_version: str,
    ) -> CompileCacheKeyIR:
        """Return the deterministic compile cache key contract."""
        return build_compile_cache_key(
            source_program_hash=source_program_hash,
            discretized_program_hash=discretized_program_hash,
            target_snapshot_hash=target_snapshot.target_snapshot_hash,
            compiler_version=self.compiler_version,
            compiler_options=self.options.to_dict(),
            optimization_level=self.options.optimization_level,
            parameter_schema_hash=parameter_schema_hash,
            bit_order_version=bit_order_version,
            metadata={
                "target_id": target_snapshot.target_id,
                "target_version": target_snapshot.target_version,
            },
        )

    def _diagnostics(
        self,
        program: ProgramIR,
        target_snapshot: TargetSnapshot,
        *,
        control_system: ControlSystemIR,
        control_schedule: ControlScheduleIR,
    ) -> list[DiagnosticsIR]:
        diagnostics: list[DiagnosticsIR] = [
            DiagnosticsIR(
                diagnostic_id="compiler.analog_draft_lowering",
                stage="compilation",
                severity="info",
                code="COMPILER_ANALOG_DRAFT_LOWERING",
                message="Analog draft lowering completed offline.",
                object_path="program",
                metadata={
                    "compiler_version": self.compiler_version,
                    "target_id": target_snapshot.target_id,
                    "control_system_id": control_system.control_system_id,
                    "control_binding": "target_derived_control_system_ir",
                    "production_channel_allocation_performed": False,
                    "reason_category": "compiler",
                    "compiler_pass": "analog_lowering",
                    "live_hardware_claimed": False,
                    "hardware_payload_emitted": False,
                },
            )
        ]
        diagnostics.extend(_global_drive_control_diagnostics(control_system))
        diagnostics.extend(_local_detuning_control_diagnostics(program, control_system))
        diagnostics.extend(_local_rabi_control_diagnostics(program, control_system))
        diagnostics.extend(control_schedule.diagnostics)
        diagnostics.extend(
            _unsupported_diagnostics(
                program,
                control_system,
                target_spec=target_snapshot.target_spec,
            )
        )
        return diagnostics

    @staticmethod
    def _bit_order_version(program: ProgramIR) -> str:
        return str(program.bit_ordering.get("convention", "unknown"))


def _compiled_schedule(
    program: ProgramIR,
    *,
    control_schedule: ControlScheduleIR | None = None,
) -> dict[str, Any]:
    duration = _program_duration(program)
    global_duration = _global_drive_duration(program)
    segments = [
        {
            "segment_id": "segment.global_rydberg_drive.0",
            "start": 0.0,
            "stop": global_duration,
            "operation_id": "op.global_rydberg_drive",
        }
    ]
    for index, detuning_term in enumerate(
        program.hamiltonian.local_detuning_terms
    ):
        segments.append(
            {
                "segment_id": f"segment.local_detuning.{index}",
                "start": 0.0,
                "stop": global_duration,
                "operation_id": f"op.local_detuning.{index}",
                "additive_hamiltonian_term": True,
                "additive_to_operation_id": "op.global_rydberg_drive",
                "execution_scope": "local_simulator_only",
                "hardware_timing_claimed": False,
                "addressing_source_kind": detuning_term.addressing.source_kind,
                "addressing_times": list(detuning_term.addressing.times),
                "addressing_duration": detuning_term.addressing.duration,
                "addressing_frame_count": detuning_term.addressing.frame_count,
                "addressing_interpolation": detuning_term.addressing.interpolation,
                "addressing_hash": detuning_term.addressing.stable_hash(),
            }
        )
    for index, rabi_term in enumerate(program.hamiltonian.local_rabi_terms):
        # Local and global Rabi drives contribute to the same Hamiltonian over
        # the same logical interval; sequencing them would change the physics.
        segments.append(
            {
                "segment_id": f"segment.local_rabi.{index}",
                "start": 0.0,
                "stop": global_duration,
                "operation_id": f"op.local_rabi.{index}",
                "additive_hamiltonian_term": True,
                "additive_to_operation_id": "op.global_rydberg_drive",
                "execution_scope": "local_simulator_only",
                "hardware_timing_claimed": False,
                "addressing_source_kind": rabi_term.addressing.source_kind,
                "addressing_times": list(rabi_term.addressing.times),
                "addressing_duration": rabi_term.addressing.duration,
                "addressing_frame_count": rabi_term.addressing.frame_count,
                "addressing_interpolation": rabi_term.addressing.interpolation,
                "addressing_hash": rabi_term.addressing.stable_hash(),
                "phase_pattern_hash": rabi_term.phase_pattern.stable_hash(),
                "phase_pattern_unit": rabi_term.phase_pattern.unit,
                "phase_pattern_nonzero_offset_count": sum(
                    offset != 0.0 for offset in rabi_term.phase_pattern.offsets
                ),
            }
        )
    compiled_schedule = {
        "time_unit": program.unit_conventions.time,
        "duration": duration,
        "segments": segments,
    }
    if control_schedule is not None and _schedule_evidence_relevant(
        control_schedule
    ):
        compiled_schedule["control_schedule_ir"] = control_schedule.to_dict()
        compiled_schedule["control_schedule_hash"] = control_schedule.stable_hash()
    return compiled_schedule


def _compiler_control_schedule(
    program: ProgramIR,
    control_system: ControlSystemIR,
) -> ControlScheduleIR:
    """Return the public schedule evidence with compilation-stage diagnostics."""
    schedule = build_control_schedule(program, control_system)
    diagnostics = (
        *schedule.diagnostics,
        *validate_control_schedule(schedule, control_system, program),
    )
    return replace(
        schedule,
        diagnostics=tuple(
            replace(diagnostic, stage="compilation")
            for diagnostic in diagnostics
        ),
    )


def _compiler_control_schedule_metadata(
    schedule: ControlScheduleIR,
) -> dict[str, Any]:
    if not _schedule_evidence_relevant(schedule):
        return {}
    return {
        "control_schedule_hash": schedule.stable_hash(),
        "control_constraint_diagnostic_codes": [
            diagnostic.code for diagnostic in schedule.diagnostics
        ],
    }


def _schedule_evidence_relevant(schedule: ControlScheduleIR) -> bool:
    return bool(schedule.diagnostics) or any(
        operation.channel_id.endswith(".local")
        for operation in schedule.operations
    )


def _channel_schedule(
    program: ProgramIR,
    control_system: ControlSystemIR,
) -> dict[str, Any]:
    candidate_channel_ids = [
        channel.channel_id
        for channel in control_system.channels
        if "global_rydberg_drive" in channel.supported_operations
    ]
    channels: dict[str, Any] = {
        "global": {
            "channel_type": "rydberg_global",
            "operation_ids": ["op.global_rydberg_drive"],
            "fields": ["rabi", "detuning", "phase"],
            "frequency_unit": program.unit_conventions.frequency,
            "candidate_channel_ids": candidate_channel_ids,
            "source_path": "control_system.channels",
            "production_assigned": False,
        }
    }
    if program.hamiltonian.local_detuning_terms:
        detuning_addressing = [
            _addressing_schedule_entry(
                term.addressing,
                operation_id=f"op.local_detuning.{index}",
                program_path=(
                    f"hamiltonian.terms.local_detuning_terms[{index}].addressing"
                ),
            )
            for index, term in enumerate(program.hamiltonian.local_detuning_terms)
        ]
        local_candidate_channel_ids = [
            channel.channel_id
            for channel in control_system.channels
            if "local_detuning" in channel.supported_operations
            and channel.addressing.mode == "patterned"
        ]
        channels["local_detuning"] = {
            "channel_type": "rydberg_detuning",
            "addressing_mode": "patterned",
            "addressing_kind": _common_addressing_kind(detuning_addressing),
            "addressing_frame_count": sum(
                int(item["frame_count"]) for item in detuning_addressing
            ),
            "addressing_terms": detuning_addressing,
            "operation_ids": [
                f"op.local_detuning.{index}"
                for index in range(len(program.hamiltonian.local_detuning_terms))
            ],
            "fields": ["detuning", "site_addressing"],
            "frequency_unit": program.unit_conventions.frequency,
            "candidate_channel_ids": local_candidate_channel_ids,
            "source_path": "control_system.channels",
            "binding_status": (
                "reference_bound" if local_candidate_channel_ids else "blocked"
            ),
            "execution_scope": "local_simulator_only",
            "production_assigned": False,
            "hardware_channel_allocated": False,
        }
    if program.hamiltonian.local_rabi_terms:
        rabi_addressing = [
            _addressing_schedule_entry(
                term.addressing,
                operation_id=f"op.local_rabi.{index}",
                program_path=(
                    f"hamiltonian.terms.local_rabi_terms[{index}].addressing"
                ),
            )
            for index, term in enumerate(program.hamiltonian.local_rabi_terms)
        ]
        phase_patterns = [
            {
                "operation_id": f"op.local_rabi.{index}",
                "program_path": (
                    f"hamiltonian.terms.local_rabi_terms[{index}].phase_pattern"
                ),
                "site_ids": list(term.phase_pattern.site_ids),
                "offsets": list(term.phase_pattern.offsets),
                "unit": term.phase_pattern.unit,
                "phase_pattern_hash": term.phase_pattern.stable_hash(),
            }
            for index, term in enumerate(program.hamiltonian.local_rabi_terms)
        ]
        local_rabi_candidate_channel_ids = [
            channel.channel_id
            for channel in control_system.channels
            if "local_rabi" in channel.supported_operations
            and channel.addressing.mode == "patterned"
        ]
        channels["local_rabi"] = {
            "channel_type": "rydberg_rabi",
            "addressing_mode": "patterned",
            "addressing_kind": _common_addressing_kind(rabi_addressing),
            "addressing_frame_count": sum(
                int(item["frame_count"]) for item in rabi_addressing
            ),
            "addressing_terms": rabi_addressing,
            "phase_pattern_terms": phase_patterns,
            "operation_ids": [
                f"op.local_rabi.{index}"
                for index in range(len(program.hamiltonian.local_rabi_terms))
            ],
            "fields": ["rabi", "phase", "site_addressing", "phase_pattern"],
            "frequency_unit": program.unit_conventions.frequency,
            "phase_unit": program.unit_conventions.phase,
            "candidate_channel_ids": local_rabi_candidate_channel_ids,
            "source_path": "control_system.channels",
            "binding_status": (
                "reference_bound" if local_rabi_candidate_channel_ids else "blocked"
            ),
            "execution_scope": "local_simulator_only",
            "production_assigned": False,
            "hardware_channel_allocated": False,
        }
    return {
        "control_system_id": control_system.control_system_id,
        "allocation_mode": "compiler_control_binding_draft",
        "production_channel_allocation_performed": False,
        "channels": channels,
        "control_channels": {
            channel.channel_id: {
                "channel_type": channel.channel_type,
                "addressing_mode": channel.addressing.mode,
                "supported_operations": list(channel.supported_operations),
                "value_unit": channel.value_unit,
                "time_unit": channel.time_unit,
                "source_path": f"control_system.channels.{channel.channel_id}",
                "production_assigned": False,
            }
            for channel in control_system.channels
        },
    }


def _addressing_schedule_entry(
    addressing: SiteAddressingIR,
    *,
    operation_id: str,
    program_path: str,
) -> dict[str, Any]:
    """Return one lossless local-addressing schedule fact."""
    return {
        "operation_id": operation_id,
        "program_path": program_path,
        "site_ids": list(addressing.site_ids),
        "times": list(addressing.times),
        "weights": [list(frame) for frame in addressing.weights],
        "duration": addressing.duration,
        "time_unit": addressing.time_unit,
        "interpolation": addressing.interpolation,
        "source_kind": addressing.source_kind,
        "addressing_hash": addressing.stable_hash(),
        "frame_count": addressing.frame_count,
    }


def _common_addressing_kind(entries: list[dict[str, Any]]) -> str:
    kinds = {str(entry["source_kind"]) for entry in entries}
    return next(iter(kinds)) if len(kinds) == 1 else "mixed"


def _measurement_schedule(program: ProgramIR) -> dict[str, Any]:
    duration = _program_duration(program)
    active_atom_ids = program.register.active_atom_ids
    return {
        "measurement_count": len(program.measurements),
        "bitstring_index": "left_to_right_matches_atom_order",
        "measurements": [
            {
                "measurement_id": measurement.measurement_id,
                "basis": measurement.basis,
                "requested_targets": measurement.targets,
                "targets": list(
                    active_atom_ids
                    if measurement.targets == "all"
                    else measurement.targets
                ),
                "time": duration,
            }
            for measurement in program.measurements
        ]
    }


def _native_operation_set(program: ProgramIR) -> tuple[dict[str, Any], ...]:
    operations: tuple[dict[str, Any], ...] = (
        {
            "operation_id": "op.global_rydberg_drive",
            "operation_type": "global_rydberg_drive",
            "source_path": "hamiltonian.terms",
            "fields": {
                "rabi": _waveform_ref(program.hamiltonian.rabi),
                "detuning": _waveform_ref(program.hamiltonian.detuning),
                "phase": _phase_ref(program),
            },
        },
    )
    for index, detuning_term in enumerate(program.hamiltonian.local_detuning_terms):
        operations = (
            *operations,
            {
                "operation_id": f"op.local_detuning.{index}",
                "operation_type": "local_detuning",
                "source_path": f"hamiltonian.terms.local_detuning_terms[{index}]",
                "fields": {
                    "waveform": _waveform_ref(detuning_term.waveform),
                    "addressing": detuning_term.addressing.to_dict(),
                    "addressing_hash": detuning_term.addressing.stable_hash(),
                },
                "metadata": {
                    "execution_scope": "local_simulator_only",
                    "hardware_executable": False,
                },
            },
        )
    for index, rabi_term in enumerate(program.hamiltonian.local_rabi_terms):
        operations = (
            *operations,
            {
                "operation_id": f"op.local_rabi.{index}",
                "operation_type": "local_rabi",
                "source_path": f"hamiltonian.terms.local_rabi_terms[{index}]",
                "fields": {
                    "rabi": _waveform_ref(rabi_term.rabi),
                    "phase": (
                        _waveform_ref(rabi_term.phase)
                        if isinstance(rabi_term.phase, WaveformIR)
                        else rabi_term.phase
                    ),
                    "addressing": rabi_term.addressing.to_dict(),
                    "addressing_hash": rabi_term.addressing.stable_hash(),
                    "phase_pattern": rabi_term.phase_pattern.to_dict(),
                    "phase_pattern_hash": rabi_term.phase_pattern.stable_hash(),
                },
                "metadata": {
                    "execution_scope": "local_simulator_only",
                    "hardware_executable": False,
                },
            },
        )
    return operations


def _source_map(
    program: ProgramIR,
    control_system: ControlSystemIR,
) -> dict[str, Any]:
    source_map: dict[str, Any] = {
        "op.global_rydberg_drive": {
            "program_path": "hamiltonian.terms",
            "schedule_path": "compiled_schedule.segments[0]",
            "control_paths": [
                f"control_system.channels.{channel.channel_id}"
                for channel in control_system.channels
                if "global_rydberg_drive" in channel.supported_operations
            ],
        },
        "channel.global": {
            "program_path": "hamiltonian",
            "schedule_path": "channel_schedule.channels.global",
            "control_system_path": "channel_schedule.control_channels",
        },
        "control_system": {
            "target_path": "target_snapshot.target_spec",
            "control_system_id": control_system.control_system_id,
            "channel_paths": [
                f"channel_schedule.control_channels.{channel.channel_id}"
                for channel in control_system.channels
            ],
        },
        "measurements": [
            {
                "measurement_id": measurement.measurement_id,
                "program_path": f"measurements[{index}]",
                "schedule_path": f"measurement_schedule.measurements[{index}]",
            }
            for index, measurement in enumerate(program.measurements)
        ],
    }
    if program.hamiltonian.local_detuning_terms:
        local_control_paths = [
            f"channel_schedule.control_channels.{channel.channel_id}"
            for channel in control_system.channels
            if "local_detuning" in channel.supported_operations
            and channel.addressing.mode == "patterned"
        ]
        for index, detuning_term in enumerate(
            program.hamiltonian.local_detuning_terms
        ):
            operation_id = f"op.local_detuning.{index}"
            source_map[operation_id] = {
                "program_path": f"hamiltonian.terms.local_detuning_terms[{index}]",
                "schedule_path": (
                    f"compiled_schedule.segments["
                    f"{_schedule_segment_index(program, operation_id)}]"
                ),
                "channel_schedule_path": "channel_schedule.channels.local_detuning",
                "addressing_program_path": (
                    f"hamiltonian.terms.local_detuning_terms[{index}].addressing"
                ),
                "addressing_native_operation_path": (
                    f"native_operation_set[{1 + index}].fields.addressing"
                ),
                "addressing_channel_schedule_path": (
                    "channel_schedule.channels.local_detuning."
                    f"addressing_terms[{index}]"
                ),
                "addressing_hash": detuning_term.addressing.stable_hash(),
                "control_paths": [
                    f"control_system.channels.{channel.channel_id}"
                    for channel in control_system.channels
                    if "local_detuning" in channel.supported_operations
                    and channel.addressing.mode == "patterned"
                ],
            }
        source_map["channel.local_detuning"] = {
            "program_path": "hamiltonian.terms.local_detuning_terms",
            "schedule_path": "channel_schedule.channels.local_detuning",
            "control_system_paths": local_control_paths,
        }
    if program.hamiltonian.local_rabi_terms:
        local_rabi_control_paths = [
            f"channel_schedule.control_channels.{channel.channel_id}"
            for channel in control_system.channels
            if "local_rabi" in channel.supported_operations
            and channel.addressing.mode == "patterned"
        ]
        for index, rabi_term in enumerate(program.hamiltonian.local_rabi_terms):
            operation_id = f"op.local_rabi.{index}"
            source_map[operation_id] = {
                "program_path": f"hamiltonian.terms.local_rabi_terms[{index}]",
                "schedule_path": (
                    f"compiled_schedule.segments["
                    f"{_schedule_segment_index(program, operation_id)}]"
                ),
                "channel_schedule_path": "channel_schedule.channels.local_rabi",
                "addressing_program_path": (
                    f"hamiltonian.terms.local_rabi_terms[{index}].addressing"
                ),
                "addressing_native_operation_path": (
                    "native_operation_set["
                    f"{1 + len(program.hamiltonian.local_detuning_terms) + index}"
                    "].fields.addressing"
                ),
                "addressing_channel_schedule_path": (
                    "channel_schedule.channels.local_rabi."
                    f"addressing_terms[{index}]"
                ),
                "addressing_hash": rabi_term.addressing.stable_hash(),
                "phase_pattern_program_path": (
                    f"hamiltonian.terms.local_rabi_terms[{index}].phase_pattern"
                ),
                "phase_pattern_native_operation_path": (
                    "native_operation_set["
                    f"{1 + len(program.hamiltonian.local_detuning_terms) + index}"
                    "].fields.phase_pattern"
                ),
                "phase_pattern_channel_schedule_path": (
                    "channel_schedule.channels.local_rabi."
                    f"phase_pattern_terms[{index}]"
                ),
                "phase_pattern_hash": rabi_term.phase_pattern.stable_hash(),
                "control_paths": [
                    f"control_system.channels.{channel.channel_id}"
                    for channel in control_system.channels
                    if "local_rabi" in channel.supported_operations
                    and channel.addressing.mode == "patterned"
                ],
            }
        source_map["channel.local_rabi"] = {
            "program_path": "hamiltonian.terms.local_rabi_terms",
            "schedule_path": "channel_schedule.channels.local_rabi",
            "control_system_paths": local_rabi_control_paths,
        }
    return source_map


def _schedule_segment_index(program: ProgramIR, operation_id: str) -> int:
    """Return the canonical schedule index used by source-map references."""
    for index, segment in enumerate(_compiled_schedule(program)["segments"]):
        if segment["operation_id"] == operation_id:
            return index
    raise ValueError(f"Schedule operation {operation_id!r} is missing.")


def _mapping_info(program: ProgramIR) -> dict[str, Any]:
    register = program.register
    mapping_info: dict[str, Any] = {
        "atom_order": list(register.active_atom_ids),
        "active_site_order": list(register.active_site_ids),
        "physical_site_order": list(register.physical_site_ids),
        "register_snapshot": register.snapshot_evidence(),
        "bit_order_version": program.bit_ordering.get(
            "convention",
            ANALOG_BIT_ORDER_CONVENTION,
        ),
    }
    if program.hamiltonian.local_detuning_terms:
        active_site_order = list(program.register.active_site_ids)
        mapping_info["local_detuning_addressing"] = [
            {
                "site_ids": list(term.addressing.site_ids),
                "times": list(term.addressing.times),
                "weights": [list(frame) for frame in term.addressing.weights],
                "duration": term.addressing.duration,
                "time_unit": term.addressing.time_unit,
                "interpolation": term.addressing.interpolation,
                "addressing_hash": term.addressing.stable_hash(),
                "source_kind": term.addressing.source_kind,
                "active_register_site_order": active_site_order,
                "register_order_preserved": list(term.addressing.site_ids)
                == active_site_order,
            }
            for term in program.hamiltonian.local_detuning_terms
        ]
    if program.hamiltonian.local_rabi_terms:
        active_site_order = list(program.register.active_site_ids)
        mapping_info["local_rabi_addressing"] = [
            {
                "site_ids": list(term.addressing.site_ids),
                "times": list(term.addressing.times),
                "weights": [list(frame) for frame in term.addressing.weights],
                "duration": term.addressing.duration,
                "time_unit": term.addressing.time_unit,
                "interpolation": term.addressing.interpolation,
                "addressing_hash": term.addressing.stable_hash(),
                "source_kind": term.addressing.source_kind,
                "active_register_site_order": active_site_order,
                "register_order_preserved": list(term.addressing.site_ids)
                == active_site_order,
            }
            for term in program.hamiltonian.local_rabi_terms
        ]
        mapping_info["local_rabi_phase_patterns"] = [
            {
                "site_ids": list(term.phase_pattern.site_ids),
                "offsets": list(term.phase_pattern.offsets),
                "unit": term.phase_pattern.unit,
                "phase_pattern_hash": term.phase_pattern.stable_hash(),
                "active_register_site_order": active_site_order,
                "register_order_preserved": (
                    list(term.phase_pattern.site_ids) == active_site_order
                ),
            }
            for term in program.hamiltonian.local_rabi_terms
        ]
    return mapping_info


def _resource_estimate(program: ProgramIR) -> dict[str, Any]:
    register = program.register
    atom_count = len(register.active_sites)
    estimate = {
        "atom_count": atom_count,
        "physical_site_count": len(register.sites),
        "register_snapshot_id": register.snapshot_id,
        "register_snapshot_hash": register.stable_hash(),
        "register_status_counts": register.status_counts,
        "duration": _program_duration(program),
        "waveform_count": _waveform_count(program),
        "measurement_count": len(program.measurements),
        "estimated_hilbert_dimension": 2**atom_count,
    }
    detuning_terms = program.hamiltonian.local_detuning_terms
    if detuning_terms:
        estimate.update(
            {
                "local_detuning_term_count": len(detuning_terms),
                "local_detuning_waveform_count": len(detuning_terms),
                "local_detuning_addressing_count": len(detuning_terms),
                "local_detuning_addressing_frame_count": sum(
                    term.addressing.frame_count for term in detuning_terms
                ),
                "local_detuning_addressing_switch_count": sum(
                    term.addressing.frame_count - 1 for term in detuning_terms
                ),
                "patterned_site_count": max(
                    len(term.addressing.site_ids) for term in detuning_terms
                ),
            }
        )
    rabi_terms = program.hamiltonian.local_rabi_terms
    if rabi_terms:
        local_rabi_waveform_count = sum(
            1 + int(isinstance(term.phase, WaveformIR)) for term in rabi_terms
        )
        estimate.update(
            {
                "local_rabi_term_count": len(rabi_terms),
                "local_rabi_waveform_count": local_rabi_waveform_count,
                "local_rabi_addressing_count": len(rabi_terms),
                "local_rabi_addressing_frame_count": sum(
                    term.addressing.frame_count for term in rabi_terms
                ),
                "local_rabi_addressing_switch_count": sum(
                    term.addressing.frame_count - 1 for term in rabi_terms
                ),
                "local_rabi_phase_pattern_count": len(rabi_terms),
                "local_rabi_phase_offset_count": sum(
                    len(term.phase_pattern.offsets) for term in rabi_terms
                ),
                "local_rabi_nonzero_phase_offset_count": sum(
                    offset != 0.0
                    for term in rabi_terms
                    for offset in term.phase_pattern.offsets
                ),
                "patterned_site_count": max(
                    int(estimate.get("patterned_site_count", 0)),
                    max(len(term.addressing.site_ids) for term in rabi_terms),
                ),
            }
        )
    return estimate


def _analog_compiler_passes(
    diagnostics: tuple[DiagnosticsIR, ...],
    *,
    program: ProgramIR,
    target_snapshot: TargetSnapshot,
    control_system: ControlSystemIR,
    source_map: dict[str, Any],
    resource_estimate: dict[str, Any],
) -> tuple[dict[str, Any], ...]:
    return (
        _compiler_pass_summary(
            "validation",
            diagnostics,
            reason_category="validation",
            metadata={
                "program_id": program.program_id,
                "program_type": program.program_type,
                "lifecycle_state": program.lifecycle_state,
            },
        ),
        _compiler_pass_summary(
            "discretization",
            diagnostics,
            reason_category="discretization",
            metadata={
                "lifecycle_state": program.lifecycle_state,
                "time_unit": program.unit_conventions.time,
            },
        ),
        _compiler_pass_summary(
            "target_binding",
            diagnostics,
            reason_category="target",
            metadata={
                "target_id": target_snapshot.target_id,
                "target_version": target_snapshot.target_version,
                "control_system_id": control_system.control_system_id,
            },
        ),
        _compiler_pass_summary(
            "analog_lowering",
            diagnostics,
            reason_category="compiler",
            diagnostic_codes=("COMPILER_ANALOG_DRAFT_LOWERING",),
            metadata={
                "lowering_kind": "analog_draft",
                "native_operation_count": len(_native_operation_set(program)),
                "hardware_payload_emitted": False,
            },
        ),
        _compiler_pass_summary(
            "control_binding",
            diagnostics,
            reason_category="control",
            diagnostic_codes=(
                "COMPILER_LOCAL_DETUNING_REFERENCE_BOUND",
                "COMPILER_LOCAL_RABI_REFERENCE_BOUND",
                "CONTROL_REQUIREMENT_SUPPORTED",
                "CONTROL_CHANNEL_TYPE_UNSUPPORTED",
                "CONTROL_ADDRESSING_UNSUPPORTED",
                "CONTROL_OPERATION_UNSUPPORTED",
                "UNSUPPORTED_LOCAL_DETUNING",
                "UNSUPPORTED_LOCAL_RABI",
            ),
            metadata={
                "control_system_id": control_system.control_system_id,
                "production_channel_allocation_performed": False,
            },
        ),
        _compiler_pass_summary(
            "source_map",
            diagnostics,
            reason_category="compiler",
            metadata={
                "source_map_entries": len(source_map),
                **(
                    {
                        "local_detuning_source_entries": (
                            len(program.hamiltonian.local_detuning_terms) + 1
                        )
                    }
                    if program.hamiltonian.local_detuning_terms
                    else {}
                ),
                **(
                    {
                        "local_rabi_source_entries": (
                            len(program.hamiltonian.local_rabi_terms) + 1
                        )
                    }
                    if program.hamiltonian.local_rabi_terms
                    else {}
                ),
            },
        ),
        _compiler_pass_summary(
            "resource_estimate",
            diagnostics,
            reason_category="compiler",
            metadata={
                "atom_count": resource_estimate["atom_count"],
                "measurement_count": resource_estimate["measurement_count"],
                **(
                    {
                        "local_detuning_term_count": resource_estimate[
                            "local_detuning_term_count"
                        ],
                        "patterned_site_count": resource_estimate[
                            "patterned_site_count"
                        ],
                    }
                    if program.hamiltonian.local_detuning_terms
                    else {}
                ),
                **(
                    {
                        "local_rabi_term_count": resource_estimate[
                            "local_rabi_term_count"
                        ],
                        "patterned_site_count": resource_estimate[
                            "patterned_site_count"
                        ],
                    }
                    if program.hamiltonian.local_rabi_terms
                    else {}
                ),
            },
        ),
        _compiler_pass_summary(
            "backend_readiness",
            diagnostics,
            reason_category="backend",
            metadata={
                "backend_payload_status": "not_emitted",
                "live_hardware_claimed": False,
                "cloud_compile_used": False,
            },
        ),
    )


def _digital_compiler_passes(
    diagnostics: tuple[DiagnosticsIR, ...],
    *,
    program: DigitalProgramIR,
    target_snapshot: TargetSnapshot,
    lowering: dict[str, Any],
    source_map: dict[str, Any],
    resource_estimate: dict[str, Any],
) -> tuple[dict[str, Any], ...]:
    return (
        _compiler_pass_summary(
            "validation",
            diagnostics,
            reason_category="validation",
            metadata={
                "program_id": program.program_id,
                "program_type": "digital",
                "qubit_count": len(program.circuit.qubits),
            },
        ),
        _compiler_pass_summary(
            "discretization",
            diagnostics,
            reason_category="discretization",
            metadata={
                "status": "not_applicable",
                "reason": "digital_static_gate_ir_has_no_waveform_discretization",
            },
        ),
        _compiler_pass_summary(
            "target_binding",
            diagnostics,
            reason_category="target",
            diagnostic_codes=(
                "COMPILER_DIGITAL_TARGET_UNSUPPORTED",
                "COMPILER_DIGITAL_TARGET_UNDECLARED",
                "COMPILER_DIGITAL_GATE_TARGET_UNDECLARED",
                "COMPILER_DIGITAL_GATE_TARGET_UNSUPPORTED",
            ),
            metadata={
                "target_id": target_snapshot.target_id,
                "target_version": target_snapshot.target_version,
                "operation_count": len(lowering["operations"]),
            },
        ),
        _compiler_pass_summary(
            "digital_lowering",
            diagnostics,
            reason_category="compiler",
            diagnostic_codes=(
                "COMPILER_DIGITAL_GATE_DECOMPOSITION_PLANNED",
                "COMPILER_DIGITAL_TARGET_AWARE_LOWERING",
            ),
            metadata={
                "lowering_kind": "digital_target_aware_static_gate_mock",
                "backend_payload_status": lowering["summary"]["backend_payload_status"],
                "hardware_payload_emitted": False,
            },
        ),
        _compiler_pass_summary(
            "source_map",
            diagnostics,
            reason_category="compiler",
            metadata={"source_map_entries": len(source_map)},
        ),
        _compiler_pass_summary(
            "resource_estimate",
            diagnostics,
            reason_category="compiler",
            metadata={
                "qubit_count": resource_estimate["qubit_count"],
                "gate_count": resource_estimate["gate_count"],
                "measurement_count": resource_estimate["measurement_count"],
            },
        ),
        _compiler_pass_summary(
            "backend_readiness",
            diagnostics,
            reason_category="backend",
            diagnostic_codes=("COMPILER_DIGITAL_BACKEND_MOCK_ONLY",),
            metadata={
                "backend_payload_status": "mock_only",
                "mock_backend_only": True,
                "live_hardware_claimed": False,
                "cloud_compile_used": False,
            },
        ),
    )


def _compiler_pass_summary(
    pass_name: str,
    diagnostics: tuple[DiagnosticsIR, ...],
    *,
    reason_category: str,
    diagnostic_codes: tuple[str, ...] = (),
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    selected = _diagnostics_for_pass(
        diagnostics,
        pass_name=pass_name,
        reason_category=reason_category,
        diagnostic_codes=diagnostic_codes,
    )
    error_count = sum(1 for diagnostic in selected if diagnostic.severity == "error")
    warning_count = sum(
        1 for diagnostic in selected if diagnostic.severity == "warning"
    )
    status = "ok"
    if error_count:
        status = "blocked"
    elif warning_count:
        status = "warning"
    return {
        "pass_name": pass_name,
        "stage": "compilation",
        "status": status,
        "reason_category": reason_category,
        "diagnostic_codes": sorted({diagnostic.code for diagnostic in selected}),
        "diagnostic_count": len(selected),
        "error_count": error_count,
        "warning_count": warning_count,
        "metadata": {} if metadata is None else metadata,
    }


def _diagnostics_for_pass(
    diagnostics: tuple[DiagnosticsIR, ...],
    *,
    pass_name: str,
    reason_category: str,
    diagnostic_codes: tuple[str, ...],
) -> tuple[DiagnosticsIR, ...]:
    codes = set(diagnostic_codes)
    return tuple(
        diagnostic
        for diagnostic in diagnostics
        if diagnostic.code in codes
        or (
            str(diagnostic.metadata.get("reason_category", "")) == reason_category
            and str(diagnostic.metadata.get("compiler_pass", "")) == pass_name
        )
    )


def _compiler_diagnostic_taxonomy(
    diagnostics: tuple[DiagnosticsIR, ...],
) -> dict[str, Any]:
    by_reason_category = {
        category: 0
        for category in (
            "validation",
            "discretization",
            "target",
            "calibration",
            "control",
            "compiler",
            "backend",
        )
    }
    by_severity = {"info": 0, "warning": 0, "error": 0}
    for diagnostic in diagnostics:
        by_reason_category[_diagnostic_reason_category(diagnostic)] = (
            by_reason_category.get(_diagnostic_reason_category(diagnostic), 0) + 1
        )
        by_severity[diagnostic.severity] = by_severity.get(diagnostic.severity, 0) + 1
    return {
        "taxonomy_version": "compiler_diagnostic_taxonomy.v1",
        "diagnostic_count": len(diagnostics),
        "by_reason_category": by_reason_category,
        "by_severity": by_severity,
        "live_hardware_claimed": False,
        "cloud_compile_used": False,
    }


def _diagnostic_reason_category(diagnostic: DiagnosticsIR) -> str:
    category = diagnostic.metadata.get("reason_category")
    if isinstance(category, str) and category:
        return category
    if diagnostic.code.startswith("CONTROL_"):
        return "control"
    if diagnostic.code.startswith("COMPILER_CONTROL_"):
        return "control"
    if diagnostic.code == "UNSUPPORTED_LOCAL_DETUNING":
        return "control"
    if diagnostic.code.startswith("COMPILER_DIGITAL_BACKEND_"):
        return "backend"
    if "CALIBRATION" in diagnostic.code:
        return "calibration"
    if "TARGET" in diagnostic.code:
        return "target"
    return "compiler"


def _compiler_pipeline_contract(
    *,
    program_type: str,
    hardware_payload_emitted: bool,
) -> dict[str, Any]:
    return {
        "program_type": program_type,
        "cloud_compile_used": False,
        "live_hardware_claimed": False,
        "hardware_payload_emitted": hardware_payload_emitted,
        "execution_boundary": "offline_compiled_ir_only",
    }


def _build_compiler_pass_pipeline_metadata(
    compiler_passes: tuple[dict[str, Any], ...],
    *,
    pipeline_id: str,
    program_type: str,
    compiler_version: str,
    source_program_hash: str,
    discretized_program_hash: str,
    target_snapshot: TargetSnapshot,
    parameter_schema_hash: str,
    compiler_options: dict[str, Any],
    source_map: dict[str, Any],
    resource_estimate: dict[str, Any],
    compile_cache_key: str,
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build the metadata-only compiler pass pipeline contract."""
    return build_compiler_pass_pipeline(
        compiler_passes,
        pipeline_id=pipeline_id,
        program_type=program_type,
        compiler_version=compiler_version,
        input_hashes={
            "source_program_hash": source_program_hash,
            "target_snapshot_hash": target_snapshot.target_snapshot_hash,
            "parameter_schema_hash": parameter_schema_hash,
            "compiler_options_hash": _hash_dict(compiler_options),
        },
        output_hashes={
            "discretized_program_hash": discretized_program_hash,
            "compiled_program_hash": None,
            "source_map_hash": _hash_dict(source_map),
            "resource_estimate_hash": _hash_dict(resource_estimate),
            "compile_cache_key": compile_cache_key,
            "hardware_payload_hash": None,
            "cloud_compile_artifact_hash": None,
        },
        metadata={
            "contract_version": "compiler_pass_pipeline.v1",
            "metadata_only": True,
            "backend_called": False,
            "network_accessed": False,
            "live_hardware_claimed": False,
            "cloud_compile_used": False,
            "compiled_program_hash_reason": (
                "The pass pipeline is embedded in ReferenceCompiledProgramIR metadata; "
                "the final compiled hash is intentionally not self-referential."
            ),
            **({} if metadata is None else metadata),
        },
    ).to_dict()


def _unsupported_features(
    program: ProgramIR,
    *,
    control_system: ControlSystemIR,
    target_spec: TargetSpec,
) -> list[dict[str, Any]]:
    features: list[dict[str, Any]] = []
    if program.hamiltonian.local_detuning_terms:
        control_diagnostics = diagnose_control_support(
            control_system,
            required_channel_type="rydberg_detuning",
            required_addressing="patterned",
            required_operation="local_detuning",
        )
        if not _control_requirement_supported(control_diagnostics):
            features.append(
                {
                    "feature": "local_detuning",
                    "category": "target",
                    "path": "hamiltonian.terms.local_detuning_terms",
                    "message": (
                        "Local detuning is unsupported by the target-derived "
                        "control system."
                    ),
                    "control_system_id": control_system.control_system_id,
                    "required_channel_type": "rydberg_detuning",
                    "required_addressing": "patterned",
                    "required_operation": "local_detuning",
                    "control_diagnostics": [
                        diagnostic.to_dict() for diagnostic in control_diagnostics
                    ],
                }
            )
    if program.hamiltonian.local_rabi_terms:
        control_diagnostics = diagnose_control_support(
            control_system,
            required_channel_type="rydberg_rabi",
            required_addressing="patterned",
            required_operation="local_rabi",
        )
        if not _control_requirement_supported(control_diagnostics):
            features.append(
                {
                    "feature": "local_rabi",
                    "category": "target",
                    "path": "hamiltonian.terms.local_rabi_terms",
                    "message": (
                        "Local Rabi control is unsupported by the "
                        "target-derived control system."
                    ),
                    "control_system_id": control_system.control_system_id,
                    "required_channel_type": "rydberg_rabi",
                    "required_addressing": "patterned",
                    "required_operation": "local_rabi",
                    "control_diagnostics": [
                        diagnostic.to_dict() for diagnostic in control_diagnostics
                    ],
                }
            )
        has_patterned_phase = any(
            offset != 0.0
            for term in program.hamiltonian.local_rabi_terms
            for offset in term.phase_pattern.offsets
        )
        phase_pattern_status = target_spec.capabilities.get(
            "local_rabi_phase_pattern",
            "unsupported",
        )
        if (
            has_patterned_phase
            and _control_requirement_supported(control_diagnostics)
            and phase_pattern_status not in (
            "supported",
            "experimental",
            )
        ):
            features.append(
                {
                    "feature": "local_rabi_phase_pattern",
                    "category": "target",
                    "path": "hamiltonian.terms.local_rabi_terms.phase_pattern",
                    "message": (
                        "Local Rabi phase patterns are unsupported by the target."
                    ),
                    "control_system_id": control_system.control_system_id,
                    "required_operation": "local_rabi_phase_pattern",
                    "target_capability_status": phase_pattern_status,
                    "control_diagnostics": [],
                }
            )
    return features


def _unsupported_diagnostics(
    program: ProgramIR,
    control_system: ControlSystemIR,
    *,
    target_spec: TargetSpec,
) -> list[DiagnosticsIR]:
    features = _unsupported_features(
        program,
        control_system=control_system,
        target_spec=target_spec,
    )
    diagnostics = [
        DiagnosticsIR(
            diagnostic_id=f"compiler.unsupported.{feature['feature']}",
            stage="compilation",
            severity="error",
            code=f"UNSUPPORTED_{str(feature['feature']).upper()}",
            message=str(feature["message"]),
            object_path=str(feature["path"]),
            suggestion=(
                "Use controls supported by the target-derived ControlSystemIR "
                "or wait for local addressing lowering support."
            ),
            metadata={
                "category": feature["category"],
                "control_system_id": feature.get("control_system_id"),
                "required_channel_type": feature.get("required_channel_type"),
                "required_addressing": feature.get("required_addressing"),
                "required_operation": feature.get("required_operation"),
                "target_capability_status": feature.get(
                    "target_capability_status"
                ),
                "control_diagnostics": feature.get("control_diagnostics", ()),
                "reason_category": "control",
                "compiler_pass": "control_binding",
            },
        )
        for feature in features
    ]
    for feature in features:
        diagnostics.extend(
            DiagnosticsIR.from_dict(diagnostic)
            for diagnostic in feature.get("control_diagnostics", ())
        )
    return diagnostics


def _local_detuning_control_diagnostics(
    program: ProgramIR,
    control_system: ControlSystemIR,
) -> list[DiagnosticsIR]:
    if not program.hamiltonian.local_detuning_terms:
        return []
    control_diagnostics = diagnose_control_support(
        control_system,
        required_channel_type="rydberg_detuning",
        required_addressing="patterned",
        required_operation="local_detuning",
    )
    if not _control_requirement_supported(control_diagnostics):
        return []
    matching_channel_ids = control_diagnostics[0].metadata.get(
        "matching_channel_ids",
        [],
    )
    return [
        DiagnosticsIR(
            diagnostic_id="compiler.control.local_detuning_reference_bound",
            stage="compilation",
            severity="info",
            code="COMPILER_LOCAL_DETUNING_REFERENCE_BOUND",
            message=(
                "Typed local detuning was bound to an offline reference "
                "control channel."
            ),
            object_path="hamiltonian.terms.local_detuning_terms",
            metadata={
                "term_count": len(program.hamiltonian.local_detuning_terms),
                "control_system_id": control_system.control_system_id,
                "matching_channel_ids": matching_channel_ids,
                "execution_scope": "local_simulator_only",
                "hardware_payload_emitted": False,
                "production_channel_allocation_performed": False,
                "reason_category": "control",
                "compiler_pass": "control_binding",
            },
        ),
        *control_diagnostics,
    ]


def _local_rabi_control_diagnostics(
    program: ProgramIR,
    control_system: ControlSystemIR,
) -> list[DiagnosticsIR]:
    """Describe successful offline binding of a patterned Rabi drive."""
    if not program.hamiltonian.local_rabi_terms:
        return []
    control_diagnostics = diagnose_control_support(
        control_system,
        required_channel_type="rydberg_rabi",
        required_addressing="patterned",
        required_operation="local_rabi",
    )
    if not _control_requirement_supported(control_diagnostics):
        return []
    matching_channel_ids = control_diagnostics[0].metadata.get(
        "matching_channel_ids",
        [],
    )
    return [
        DiagnosticsIR(
            diagnostic_id="compiler.control.local_rabi_reference_bound",
            stage="compilation",
            severity="info",
            code="COMPILER_LOCAL_RABI_REFERENCE_BOUND",
            message=(
                "Typed local Rabi control was bound to an offline reference "
                "control channel."
            ),
            object_path="hamiltonian.terms.local_rabi_terms",
            metadata={
                "term_count": len(program.hamiltonian.local_rabi_terms),
                "control_system_id": control_system.control_system_id,
                "matching_channel_ids": matching_channel_ids,
                "execution_scope": "local_simulator_only",
                "hardware_payload_emitted": False,
                "production_channel_allocation_performed": False,
                "reason_category": "control",
                "compiler_pass": "control_binding",
            },
        ),
        *control_diagnostics,
    ]


def _control_requirement_supported(
    diagnostics: tuple[DiagnosticsIR, ...],
) -> bool:
    return any(
        item.code == "CONTROL_REQUIREMENT_SUPPORTED" and item.severity == "info"
        for item in diagnostics
    )


def _global_drive_control_diagnostics(
    control_system: ControlSystemIR,
) -> list[DiagnosticsIR]:
    control_diagnostics = tuple(
        diagnose_control_support(
            control_system,
            required_addressing="global",
            required_operation="global_rydberg_drive",
        )
    )
    matching_channel_ids = (
        control_diagnostics[0].metadata.get("matching_channel_ids", [])
        if control_diagnostics
        else []
    )
    return [
        DiagnosticsIR(
            diagnostic_id="compiler.control.global_rydberg_drive_bound",
            stage="compilation",
            severity="info",
            code="COMPILER_CONTROL_SYSTEM_BOUND",
            message=(
                "Target-derived ControlSystemIR was bound to analog draft "
                "lowering diagnostics."
            ),
            object_path="channel_schedule.control_channels",
            metadata={
                "control_system_id": control_system.control_system_id,
                "matching_channel_ids": matching_channel_ids,
                "production_channel_allocation_performed": False,
                "reason_category": "control",
                "compiler_pass": "control_binding",
            },
        ),
        *control_diagnostics,
    ]


def _global_drive_duration(program: ProgramIR) -> float:
    durations = [
        program.hamiltonian.rabi.duration,
        program.hamiltonian.detuning.duration,
    ]
    phase = program.hamiltonian.phase
    if isinstance(phase, WaveformIR):
        durations.append(phase.duration)
    return max(durations)


def _program_duration(program: ProgramIR) -> float:
    durations = [_global_drive_duration(program)]
    durations.extend(
        term.waveform.duration for term in program.hamiltonian.local_detuning_terms
    )
    for term in program.hamiltonian.local_rabi_terms:
        durations.append(term.rabi.duration)
        if isinstance(term.phase, WaveformIR):
            durations.append(term.phase.duration)
    return max(durations)


def _waveform_count(program: ProgramIR) -> int:
    count = 2
    if isinstance(program.hamiltonian.phase, WaveformIR):
        count += 1
    count += len(program.hamiltonian.local_detuning_terms)
    for term in program.hamiltonian.local_rabi_terms:
        count += 1
        if isinstance(term.phase, WaveformIR):
            count += 1
    return count


def _digital_compiled_schedule(program: DigitalProgramIR) -> dict[str, Any]:
    return {
        "schedule_kind": "digital_static_gate_sequence",
        "time_unit": "gate_index",
        "duration": len(program.circuit.gates),
        "gate_count": len(program.circuit.gates),
        "scheduler": "static_gate_index_order",
        "hardware_timing_claimed": False,
        "segments": [
            {
                "segment_id": f"segment.{gate.gate_id}",
                "start": index,
                "stop": index + 1,
                "operation_id": f"op.{gate.gate_id}",
                "gate": gate.name,
                "targets": list(gate.targets),
            }
            for index, gate in enumerate(program.circuit.gates)
        ],
    }


def _digital_channel_schedule(program: DigitalProgramIR) -> dict[str, Any]:
    return {
        "channels": {
            "digital_gate": {
                "channel_type": "digital_logical_gate",
                "operation_ids": [
                    f"op.{gate.gate_id}" for gate in program.circuit.gates
                ],
                "qubit_order": list(program.circuit.qubits),
                "allocation_mode": "local_mock_logical_gate_order",
                "hardware_channel_claimed": False,
            }
        },
        "allocation_mode": "local_mock_logical_gate_order",
        "hardware_channel_allocation_performed": False,
    }


def _digital_measurement_schedule(program: DigitalProgramIR) -> dict[str, Any]:
    return {
        "basis": "computational",
        "readout_kind": "digital_computational",
        "measurement_count": len(program.circuit.measurements),
        "bitstring_index": "left_to_right_matches_qubit_order",
        "measurements": [
            {
                "measurement_id": measurement.measurement_id,
                "basis": measurement.basis,
                "targets": list(measurement.targets),
                "key": measurement.key,
                "time": len(program.circuit.gates),
            }
            for measurement in program.circuit.measurements
        ],
    }


def _digital_native_operation_set(
    program: DigitalProgramIR,
    *,
    gate_capabilities: dict[str, DigitalGateCapability] | None = None,
) -> tuple[dict[str, Any], ...]:
    capabilities = {} if gate_capabilities is None else gate_capabilities
    return tuple(
        _digital_operation_entry(
            gate=gate,
            index=index,
            capability=capabilities.get(gate.name),
        )
        for index, gate in enumerate(program.circuit.gates)
    )


def _digital_operation_entry(
    *,
    gate: GateIR,
    index: int,
    capability: DigitalGateCapability | None,
) -> dict[str, Any]:
    if capability is None:
        target_status = "undeclared"
        target_native = False
        duration = None
        duration_unit = None
        channel_refs: tuple[str, ...] = ()
        lowering_kind = "unsupported"
    else:
        target_status = capability.status
        target_native = capability.native
        duration = capability.duration
        duration_unit = capability.duration_unit
        channel_refs = capability.channel_refs
        lowering_kind = (
            "target_native"
            if capability.native
            else "local_mock_standard_gate_decomposition"
        )
    entry = {
        "operation_id": f"op.{gate.gate_id}",
        "operation_type": "digital_gate",
        "gate": gate.name,
        "targets": list(gate.targets),
        "parameters": dict(gate.parameters),
        "source_path": f"circuit.gates[{index}]",
        "canonical_gate_set": "cascaqit_static_standard_v0",
        "target_support_status": target_status,
        "target_native": target_native,
        "lowering_kind": lowering_kind,
        "duration": duration,
        "duration_unit": duration_unit,
        "channel_refs": list(channel_refs),
    }
    if capability is not None:
        entry["target_arity"] = capability.arity
        entry["target_parameter_names"] = list(capability.parameter_names)
    return entry


def _digital_source_map(program: DigitalProgramIR) -> dict[str, Any]:
    return {
        f"op.{gate.gate_id}": {
            "program_path": f"circuit.gates[{index}]",
            "schedule_path": f"compiled_schedule.segments[{index}]",
        }
        for index, gate in enumerate(program.circuit.gates)
    } | {
        "measurements": [
            {
                "measurement_id": measurement.measurement_id,
                "program_path": f"circuit.measurements[{index}]",
                "schedule_path": f"measurement_schedule.measurements[{index}]",
            }
            for index, measurement in enumerate(program.circuit.measurements)
        ]
    }


def _digital_mapping_info(program: DigitalProgramIR) -> dict[str, Any]:
    return {
        "qubit_order": list(program.circuit.qubits),
        "bit_order_version": "digital_qubit_order",
        "bitstring_index": "left_to_right_matches_qubit_order",
    }


def _digital_resource_estimate(program: DigitalProgramIR) -> dict[str, Any]:
    qubit_count = len(program.circuit.qubits)
    return {
        "qubit_count": qubit_count,
        "gate_count": len(program.circuit.gates),
        "measurement_count": len(program.circuit.measurements),
        "estimated_hilbert_dimension": 2**qubit_count,
    }


def _digital_lowering_analysis(
    program: DigitalProgramIR,
    target_snapshot: TargetSnapshot,
    *,
    compiler_version: str,
) -> dict[str, Any]:
    gate_capabilities = _digital_gate_capabilities(target_snapshot)
    operations = _digital_native_operation_set(
        program,
        gate_capabilities=gate_capabilities,
    )
    unsupported_features = _digital_unsupported_features(
        program,
        target_snapshot,
        gate_capabilities=gate_capabilities,
    )
    diagnostics = _digital_diagnostics(
        program,
        target_snapshot,
        gate_capabilities=gate_capabilities,
        unsupported_features=unsupported_features,
        compiler_version=compiler_version,
    )
    return {
        "checks_ran": True,
        "operations": operations,
        "unsupported_features": tuple(unsupported_features),
        "diagnostics": tuple(diagnostics),
        "summary": _digital_lowering_summary(
            operations,
            target_snapshot,
            unsupported_features=unsupported_features,
            measurement_count=len(program.circuit.measurements),
        ),
    }


def _digital_gate_capabilities(
    target_snapshot: TargetSnapshot,
) -> dict[str, DigitalGateCapability]:
    typed = target_snapshot.target_spec.typed_capabilities
    if typed is None:
        return {}
    return {capability.gate: capability for capability in typed.digital_gates}


def _digital_unsupported_features(
    program: DigitalProgramIR,
    target_snapshot: TargetSnapshot,
    *,
    gate_capabilities: dict[str, DigitalGateCapability],
) -> list[dict[str, Any]]:
    features: list[dict[str, Any]] = []
    supported_program_types = _supported_program_types(target_snapshot)
    if supported_program_types and "digital" not in supported_program_types:
        features.append(
            {
                "feature": "digital_program_type",
                "category": "target",
                "path": (
                    "target_snapshot.target_spec.typed_capabilities."
                    "supported_program_types"
                ),
                "message": (
                    "Target snapshot does not advertise digital local-mock "
                    "program support."
                ),
                "target_id": target_snapshot.target_id,
                "supported_program_types": list(supported_program_types),
                "reason_category": "target",
            }
        )
    elif not supported_program_types:
        features.append(
            {
                "feature": "digital_program_type",
                "category": "target",
                "path": (
                    "target_snapshot.target_spec.typed_capabilities."
                    "supported_program_types"
                ),
                "message": "Target snapshot does not declare digital program support.",
                "target_id": target_snapshot.target_id,
                "supported_program_types": [],
                "reason_category": "target",
            }
        )

    for index, gate in enumerate(program.circuit.gates):
        capability = gate_capabilities.get(gate.name)
        if capability is None:
            features.append(
                _digital_gate_unsupported_feature(
                    gate,
                    index=index,
                    target_snapshot=target_snapshot,
                    reason="Gate is not declared in typed target digital gates.",
                    status="undeclared",
                )
            )
        elif capability.status != "supported":
            features.append(
                _digital_gate_unsupported_feature(
                    gate,
                    index=index,
                    target_snapshot=target_snapshot,
                    reason=f"Target declares gate status {capability.status!r}.",
                    status=capability.status,
                )
            )
    return features


def _digital_gate_unsupported_feature(
    gate: GateIR,
    *,
    index: int,
    target_snapshot: TargetSnapshot,
    reason: str,
    status: str,
) -> dict[str, Any]:
    return {
        "feature": f"digital_gate:{gate.name}",
        "category": "target",
        "path": f"circuit.gates[{index}].name",
        "message": reason,
        "gate": gate.name,
        "gate_id": gate.gate_id,
        "target_id": target_snapshot.target_id,
        "target_support_status": status,
        "reason_category": "target",
    }


def _digital_lowering_summary(
    operations: tuple[dict[str, Any], ...],
    target_snapshot: TargetSnapshot,
    *,
    unsupported_features: list[dict[str, Any]],
    measurement_count: int,
) -> dict[str, Any]:
    native_gates = sorted(
        {
            str(operation["gate"])
            for operation in operations
            if operation.get("target_native") is True
        }
    )
    decomposed_gates = sorted(
        {
            str(operation["gate"])
            for operation in operations
            if operation.get("target_native") is False
            and operation.get("target_support_status") == "supported"
        }
    )
    unsupported_gates = [
        {
            "gate": operation["gate"],
            "operation_id": operation["operation_id"],
            "reason_category": "target",
            "target_support_status": operation["target_support_status"],
        }
        for operation in operations
        if operation.get("target_support_status") != "supported"
    ]
    return {
        "target_id": target_snapshot.target_id,
        "operation_count": len(operations),
        "native_gates": native_gates,
        "decomposition_plan": {
            "kind": "local_mock_standard_gate_decomposition",
            "non_native_supported_gates": decomposed_gates,
            "hardware_native_payload": False,
        },
        "timing_summary": _digital_timing_summary(operations, target_snapshot),
        "unsupported_gates": unsupported_gates,
        "unsupported_feature_count": len(unsupported_features),
        "backend_payload_status": "mock_only",
        "execution_modes": {
            "local_simulator": "supported",
            "local_mock_backend": "supported",
            "hanyuan_live_digital": "unsupported",
            "cloud_compile": "blocked",
            "hardware_native_payload": "not_emitted",
        },
        "readout_plan": {
            "readout_kind": "digital_computational",
            "measurement_count": measurement_count,
            "hardware_readout_claimed": False,
        },
        "execution_boundary": {
            "local_simulator_supported": True,
            "mock_backend_only": True,
            "hanyuan_live_digital_execution": "unsupported",
            "hardware_payload_emitted": False,
            "cloud_compile_used": False,
            "simulator_support_implies_hardware_support": False,
        },
        "unsupported_reason_categories": sorted(
            {str(feature["reason_category"]) for feature in unsupported_features}
            | {"backend"}
        ),
    }


def _digital_timing_summary(
    operations: tuple[dict[str, Any], ...],
    target_snapshot: TargetSnapshot,
) -> dict[str, Any]:
    durations = [
        float(operation["duration"])
        for operation in operations
        if operation.get("duration") is not None
    ]
    units = sorted(
        {
            str(operation["duration_unit"])
            for operation in operations
            if operation.get("duration_unit") is not None
        }
    )
    typed = target_snapshot.target_spec.typed_capabilities
    timing = None if typed is None else typed.timing
    return {
        "source": "target_capability",
        "duration_unit": units[0] if len(units) == 1 else units,
        "total_duration": sum(durations) if durations else None,
        "per_operation": [
            {
                "operation_id": operation["operation_id"],
                "gate": operation["gate"],
                "duration": operation.get("duration"),
                "duration_unit": operation.get("duration_unit"),
                "channel_refs": operation.get("channel_refs", []),
            }
            for operation in operations
        ],
        "target_timing": None
        if timing is None
        else {
            "time_resolution": timing.time_resolution,
            "min_duration": timing.min_duration,
            "max_duration": timing.max_duration,
            "alignment": timing.alignment,
            "duration_unit": timing.duration_unit,
        },
    }


def _digital_diagnostics(
    program: DigitalProgramIR,
    target_snapshot: TargetSnapshot,
    *,
    gate_capabilities: dict[str, DigitalGateCapability],
    unsupported_features: list[dict[str, Any]],
    compiler_version: str,
) -> list[DiagnosticsIR]:
    diagnostics = [
        diagnostic
        for diagnostic in program.validate_ir_only()
        if diagnostic.severity != "info"
    ]
    supported_program_types = _supported_program_types(target_snapshot)
    if supported_program_types and "digital" not in supported_program_types:
        diagnostics.append(
            DiagnosticsIR(
                diagnostic_id="compiler.digital_target_program_type_unsupported",
                stage="compilation",
                severity="error",
                code="COMPILER_DIGITAL_TARGET_UNSUPPORTED",
                message=(
                    "Target snapshot does not advertise digital local-mock "
                    "program support."
                ),
                object_path="target_snapshot.target_spec.capabilities",
                suggestion=(
                    "Use a local mock target snapshot that includes digital in "
                    "supported_program_types."
                ),
                metadata={
                    "target_id": target_snapshot.target_id,
                    "supported_program_types": list(supported_program_types),
                    "reason_category": "target",
                    "compiler_pass": "target_binding",
                },
            )
        )
    elif not supported_program_types:
        diagnostics.append(
            DiagnosticsIR(
                diagnostic_id="compiler.digital_target_program_type_undeclared",
                stage="compilation",
                severity="error",
                code="COMPILER_DIGITAL_TARGET_UNDECLARED",
                message="Target snapshot does not declare digital program support.",
                object_path="target_snapshot.target_spec.typed_capabilities",
                suggestion="Use a target snapshot with explicit digital support.",
                metadata={
                    "target_id": target_snapshot.target_id,
                    "reason_category": "target",
                    "compiler_pass": "target_binding",
                },
            )
        )

    diagnostics.extend(
        _digital_gate_capability_diagnostics(
            program,
            target_snapshot,
            gate_capabilities=gate_capabilities,
        )
    )
    diagnostics.append(
        DiagnosticsIR(
            diagnostic_id="compiler.digital_backend_mock_only",
            stage="compilation",
            severity="info",
            code="COMPILER_DIGITAL_BACKEND_MOCK_ONLY",
            message=(
                "Digital lowering is packaged for local mock backend execution "
                "only; live hardware payload emission is disabled."
            ),
            object_path="compiled_program.metadata.digital_lowering",
            metadata={
                "target_id": target_snapshot.target_id,
                "mock_backend_only": True,
                "hardware_payload_emitted": False,
                "reason_category": "backend",
                "compiler_pass": "backend_readiness",
                "live_hardware_claimed": False,
            },
        )
    )
    if not any(diagnostic.severity == "error" for diagnostic in diagnostics):
        diagnostics.append(
            DiagnosticsIR(
                diagnostic_id="compiler.digital_target_aware_gate_lowering",
                stage="compilation",
                severity="info",
                code="COMPILER_DIGITAL_TARGET_AWARE_LOWERING",
                message=(
                    "Digital target-aware lowering diagnostics completed for "
                    "local mock execution."
                ),
                object_path="digital_program",
                metadata={
                    "compiler_version": compiler_version,
                    "target_id": target_snapshot.target_id,
                    "mock_backend_only": True,
                    "target_aware_lowering": True,
                    "unsupported_feature_count": len(unsupported_features),
                    "reason_category": "compiler",
                    "compiler_pass": "digital_lowering",
                    "live_hardware_claimed": False,
                    "hardware_payload_emitted": False,
                },
            )
        )
    return diagnostics


def _digital_gate_capability_diagnostics(
    program: DigitalProgramIR,
    target_snapshot: TargetSnapshot,
    *,
    gate_capabilities: dict[str, DigitalGateCapability],
) -> list[DiagnosticsIR]:
    diagnostics: list[DiagnosticsIR] = []
    for index, gate in enumerate(program.circuit.gates):
        capability = gate_capabilities.get(gate.name)
        if capability is None:
            diagnostics.append(
                DiagnosticsIR(
                    diagnostic_id=f"compiler.digital_gate_target_undeclared.{gate.gate_id}",
                    stage="compilation",
                    severity="error",
                    code="COMPILER_DIGITAL_GATE_TARGET_UNDECLARED",
                    message=(
                        "Digital gate is not declared by the typed target capability."
                    ),
                    object_path=f"circuit.gates[{index}].name",
                    suggestion=(
                        "Use a gate declared by the target, or add an explicit "
                        "target capability before lowering."
                    ),
                    metadata={
                        "target_id": target_snapshot.target_id,
                        "gate": gate.name,
                        "gate_id": gate.gate_id,
                        "reason_category": "target",
                        "compiler_pass": "target_binding",
                    },
                )
            )
        elif capability.status != "supported":
            diagnostics.append(
                DiagnosticsIR(
                    diagnostic_id=f"compiler.digital_gate_target_unsupported.{gate.gate_id}",
                    stage="compilation",
                    severity="error",
                    code="COMPILER_DIGITAL_GATE_TARGET_UNSUPPORTED",
                    message=(
                        "Digital gate is not supported by the typed target capability."
                    ),
                    object_path=f"circuit.gates[{index}].name",
                    suggestion=(
                        "Choose a target-supported gate or add decomposition support."
                    ),
                    metadata={
                        "target_id": target_snapshot.target_id,
                        "gate": gate.name,
                        "gate_id": gate.gate_id,
                        "target_support_status": capability.status,
                        "reason_category": "target",
                        "compiler_pass": "target_binding",
                    },
                )
            )
        elif not capability.native:
            diagnostics.append(
                DiagnosticsIR(
                    diagnostic_id=f"compiler.digital_gate_non_native.{gate.gate_id}",
                    stage="compilation",
                    severity="info",
                    code="COMPILER_DIGITAL_GATE_DECOMPOSITION_PLANNED",
                    message=(
                        "Digital gate is target-supported but non-native; local "
                        "mock standard-gate decomposition is recorded."
                    ),
                    object_path=f"circuit.gates[{index}]",
                    metadata={
                        "target_id": target_snapshot.target_id,
                        "gate": gate.name,
                        "gate_id": gate.gate_id,
                        "lowering_kind": "local_mock_standard_gate_decomposition",
                        "reason_category": "compiler",
                        "compiler_pass": "digital_lowering",
                    },
                )
            )
    return diagnostics


def _supported_program_types(target_snapshot: TargetSnapshot) -> tuple[str, ...]:
    """Return compiler-facing supported program types from typed capabilities."""
    typed = target_snapshot.target_spec.typed_capabilities
    if typed is not None and typed.supported_program_types:
        return typed.supported_program_types
    return tuple(
        str(item)
        for item in target_snapshot.target_spec.capabilities.get(
            "supported_program_types",
            (),
        )
    )


def _waveform_ref(waveform: WaveformIR) -> dict[str, Any]:
    return {
        "waveform_id": waveform.waveform_id,
        "kind": waveform.kind,
        "duration": waveform.duration,
        "time_unit": waveform.time_unit,
        "value_unit": waveform.value_unit,
    }


def _phase_ref(program: ProgramIR) -> dict[str, Any]:
    phase = program.hamiltonian.phase
    if isinstance(phase, WaveformIR):
        return _waveform_ref(phase)
    return {
        "kind": "constant_scalar",
        "value": phase,
        "value_unit": program.unit_conventions.phase,
    }


def _hash_dict(payload: dict[str, Any]) -> str:
    return hashlib.sha256(stable_json(payload).encode("utf-8")).hexdigest()
