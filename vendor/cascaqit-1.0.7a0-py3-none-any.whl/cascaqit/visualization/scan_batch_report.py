"""Standard experiment reports for parameter sweeps and batch summaries."""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from numbers import Real
from typing import Any, Literal

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.native_ir.base import canonicalize
from cascaqit.results import (
    BatchItemResultRefIR,
    BatchResultIR,
    ResultIR,
    simulation_solver_evidence_from_metadata,
)
from cascaqit.simulators import LocalHybridScanItemOutcome, LocalHybridScanJobResult
from cascaqit.visualization.experiment import (
    ExperimentReportIR,
    ExperimentSectionIR,
    unavailable_experiment_section,
)

__all__ = [
    "build_batch_experiment_report",
    "build_sweep_experiment_report",
]

_BATCH_ITEM_STATES = frozenset(
    (
        "created",
        "queued",
        "running",
        "completed",
        "partially_completed",
        "failed",
        "cancelled",
        "expired",
    )
)
_BATCH_STATES = _BATCH_ITEM_STATES


def build_sweep_experiment_report(
    source: LocalHybridScanJobResult,
    *,
    report_id: str | None = None,
    title: str | None = None,
) -> ExperimentReportIR:
    """Build a plot-ready sweep report from already completed scan facts."""
    if not isinstance(source, LocalHybridScanJobResult):
        raise TypeError("source must be LocalHybridScanJobResult.")
    source_before = source.to_dict()
    completed_results = tuple(
        result for item in source.items if (result := item.result) is not None
    )
    result_ids = tuple(result.result_id for result in completed_results)
    if len(set(result_ids)) != len(result_ids):
        raise ValueError("Sweep child result_id values must be unique.")

    source_ids = (source.job_id, *result_ids)
    if len(set(source_ids)) != len(source_ids):
        raise ValueError("Sweep aggregate and child source ids must be unique.")
    source_hashes = {
        source.job_id: source.stable_hash(),
        **{result.result_id: result.stable_hash() for result in completed_results},
    }
    sections = (
        _sweep_design_section(source),
        _diagnostic_section(
            diagnostics=source.diagnostics,
            source_path="LocalHybridScanJobResult.diagnostics",
        ),
        _sweep_plan_section(source),
        _sweep_execution_section(source),
        _sweep_state_reference_section(source),
        _sweep_measurement_section(source),
        _sweep_analysis_section(source),
    )
    report = ExperimentReportIR(
        report_id=report_id or f"experiment_report.sweep.{source.scan_id}",
        title=title or f"{source.scan_id} sweep experiment",
        profile="sweep",
        source_kind="LocalHybridScanJobResult",
        source_ids=source_ids,
        source_hashes=source_hashes,
        sections=sections,
        metadata={
            "aggregate_source_id": source.job_id,
            "child_result_ids": list(result_ids),
            "derived_view": True,
            "source_result_mutated": False,
            "artifact_bytes_read": False,
            "backend_called": False,
            "network_accessed": False,
        },
    )
    if source.to_dict() != source_before:
        raise ValueError("Sweep report construction mutated its source result.")
    return report


def build_batch_experiment_report(
    source: BatchResultIR,
    *,
    report_id: str | None = None,
    title: str | None = None,
) -> ExperimentReportIR:
    """Build a summary-first report without resolving child result artifacts."""
    items = _validated_batch_items(source)
    source_before = source.to_dict()
    sections = (
        _batch_design_section(source, items),
        _diagnostic_section(
            diagnostics=tuple(source.diagnostics)
            + tuple(item for entry in items for item in entry.diagnostics),
            source_path="BatchResultIR.diagnostics+items[*].diagnostics",
        ),
        _batch_plan_section(source),
        _batch_execution_section(source, items),
        _batch_reference_section(source, items),
        _batch_measurement_section(source, items),
        unavailable_experiment_section(
            section_id="experiment.analyze",
            stage="analyze",
            title="Observable trends",
            reason=(
                "BatchResultIR does not retain child observables; resolve child "
                "ResultIR sources before building observable trends."
            ),
        ),
    )
    report = ExperimentReportIR(
        report_id=report_id or f"experiment_report.batch.{source.batch_id}",
        title=title or f"{source.batch_id} batch experiment",
        profile="batch",
        source_kind="BatchResultIR",
        source_ids=(source.batch_result_id,),
        source_hashes={source.batch_result_id: source.stable_hash()},
        sections=sections,
        metadata={
            "aggregate_source_id": source.batch_result_id,
            "referenced_child_result_ids": [
                item.result_id for item in items if item.result_id is not None
            ],
            "child_result_hashes_available": False,
            "derived_view": True,
            "source_result_mutated": False,
            "artifact_bytes_read": False,
            "backend_called": False,
            "network_accessed": False,
        },
    )
    if source.to_dict() != source_before:
        raise ValueError("Batch report construction mutated its source result.")
    return report


def _sweep_design_section(source: LocalHybridScanJobResult) -> ExperimentSectionIR:
    parameter_names = sorted(
        {str(name) for item in source.items for name in item.bind_set.values}
    )
    axes = {
        name: _ordered_unique(
            [
                canonicalize(item.bind_set.values[name])
                for item in source.items
                if name in item.bind_set.values
            ]
        )
        for name in parameter_names
    }
    bindings = [
        {
            "scan_index": item.scan_index,
            "parameter_bind_id": item.bind_set.parameter_bind_id,
            "parameter_bind_hash": item.bind_set.parameter_bind_hash,
            "values": canonicalize(item.bind_set.values),
            "compile_required": item.bind_set.compile_required,
        }
        for item in source.items
    ]
    return ExperimentSectionIR(
        section_id="experiment.design",
        stage="design",
        title="Sweep parameters",
        status="available",
        payload={
            "scan_id": source.scan_id,
            "parameter_schema_hash": source.parameter_schema_hash,
            "parameter_scan_hash": source.parameter_scan_hash,
            "parameter_names": parameter_names,
            "parameter_axes": axes,
            "bind_count": len(bindings),
            "bindings": bindings,
        },
        source_paths=(
            "LocalHybridScanJobResult.scan_id",
            "LocalHybridScanJobResult.parameter_schema_hash",
            "LocalHybridScanJobResult.parameter_scan_hash",
            "LocalHybridScanJobResult.items[*].bind_set",
        ),
    )


def _sweep_plan_section(source: LocalHybridScanJobResult) -> ExperimentSectionIR:
    resource_plan = _optional_metadata_mapping(source.metadata, "scan_resource_plan")
    execution_config = _optional_metadata_mapping(
        source.metadata,
        "simulation_execution_config",
    )
    solver_evidence = simulation_solver_evidence_from_metadata(source.metadata)
    return ExperimentSectionIR(
        section_id="experiment.plan",
        stage="plan",
        title="Sweep resource plan",
        status="available",
        payload={
            "plan_hash": source.plan_hash,
            "failure_policy": source.status.failure_policy,
            "resource_plan": resource_plan,
            "execution_config": execution_config,
            "solver_evidence": (
                None if solver_evidence is None else solver_evidence.to_dict()
            ),
        },
        source_paths=tuple(
            [
                "LocalHybridScanJobResult.plan_hash",
                "LocalHybridScanJobResult.status.failure_policy",
            ]
            + (
                ["LocalHybridScanJobResult.metadata.scan_resource_plan"]
                if resource_plan is not None
                else []
            )
            + (
                ["LocalHybridScanJobResult.metadata.simulation_execution_config"]
                if execution_config is not None
                else []
            )
            + (
                ["LocalHybridScanJobResult.metadata.simulation_solver_evidence"]
                if solver_evidence is not None
                else []
            )
        ),
    )


def _sweep_execution_section(source: LocalHybridScanJobResult) -> ExperimentSectionIR:
    status = source.status
    resource_usage = _optional_metadata_mapping(
        source.metadata,
        "simulation_resource_usage",
    )
    return ExperimentSectionIR(
        section_id="experiment.execute",
        stage="execute",
        title="Sweep execution",
        status=_lifecycle_section_status(status.state),
        payload={
            "job_id": source.job_id,
            "scan_id": source.scan_id,
            "state": status.state,
            "failure_policy": status.failure_policy,
            "counts": {
                "total": status.total_items,
                "completed": status.completed_count,
                "failed": status.failed_count,
                "not_run": status.not_run_count,
                "cancelled": status.cancelled_count,
            },
            "backend": {
                "backend_id": status.backend_id,
                "backend_called": status.backend_called,
                "network_accessed": status.network_accessed,
                "execution_package_created": status.execution_package_created,
            },
            "resource_usage": resource_usage,
            "items": [
                {
                    "scan_index": item.scan_index,
                    "parameter_bind_id": item.bind_set.parameter_bind_id,
                    "state": item.state,
                    "job_id": item.job_id,
                    "bundle_id": item.bundle_id,
                    "diagnostic_codes": [
                        diagnostic.code for diagnostic in item.diagnostics
                    ],
                }
                for item in source.items
            ],
        },
        source_paths=tuple(
            [
                "LocalHybridScanJobResult.status",
                "LocalHybridScanJobResult.items[*].state",
                "LocalHybridScanJobResult.items[*].diagnostics",
            ]
            + (
                ["LocalHybridScanJobResult.metadata.simulation_resource_usage"]
                if resource_usage is not None
                else []
            )
        ),
        diagnostics=source.diagnostics,
    )


def _sweep_state_reference_section(
    source: LocalHybridScanJobResult,
) -> ExperimentSectionIR:
    items: list[dict[str, Any]] = []
    for item in source.items:
        result = item.result
        state_payload = None if result is None else _result_state_payload(result)
        items.append(
            {
                "scan_index": item.scan_index,
                "parameter_bind_id": item.bind_set.parameter_bind_id,
                "state": item.state,
                "result_id": None if result is None else result.result_id,
                "result_hash": None if result is None else result.stable_hash(),
                "trace_id": None if item.trace is None else item.trace.trace_id,
                "bundle_hash": item.bundle_hash,
                "references": (
                    None
                    if item.trace is None
                    else item.trace.references.to_dict()
                ),
                "state_and_noise": state_payload,
            }
        )
    return ExperimentSectionIR(
        section_id="experiment.state",
        stage="state",
        title="State, noise, and result references",
        status="available",
        payload={
            "aggregate_trace_id": source.trace.trace_id,
            "plan_hash": source.plan_hash,
            "items": items,
        },
        source_paths=(
            "LocalHybridScanJobResult.trace",
            "LocalHybridScanJobResult.items[*].trace.references",
            "LocalHybridScanJobResult.items[*].measurement_result.result",
        ),
    )


def _sweep_measurement_section(
    source: LocalHybridScanJobResult,
) -> ExperimentSectionIR:
    outcomes = sorted(
        {
            outcome
            for item in source.items
            if item.result is not None
            for outcome in (
                set(item.result.counts)
                | set(item.result.probabilities or {})
            )
        }
    )
    series = {
        outcome: [
            _sweep_outcome_point(item, outcome=outcome) for item in source.items
        ]
        for outcome in outcomes
    }
    return ExperimentSectionIR(
        section_id="experiment.measure",
        stage="measure",
        title="Measurement trends",
        status=(
            "available"
            if source.status.completed_count == source.status.total_items
            else _lifecycle_section_status(source.status.state)
        ),
        payload={
            "outcomes": outcomes,
            "series": series,
            "successful_point_count": source.status.completed_count,
            "missing_point_count": (
                source.status.total_items - source.status.completed_count
            ),
            "items": [
                _sweep_measurement_item(item) for item in source.items
            ],
        },
        source_paths=(
            "LocalHybridScanJobResult.items[*].bind_set.values",
            "LocalHybridScanJobResult.items[*].measurement_result.result.counts",
            "LocalHybridScanJobResult.items[*].measurement_result.result.probabilities",
        ),
    )


def _sweep_analysis_section(source: LocalHybridScanJobResult) -> ExperimentSectionIR:
    flattened = {
        item.scan_index: _flatten_numeric_observables(item.result)
        for item in source.items
        if item.result is not None
    }
    observable_names = sorted(
        {name for values in flattened.values() for name in values}
    )
    if not observable_names:
        return unavailable_experiment_section(
            section_id="experiment.analyze",
            stage="analyze",
            title="Observable trends",
            reason="Sweep child ResultIR values do not contain numeric observables.",
        )
    series = {
        name: [
            {
                "scan_index": item.scan_index,
                "parameter_bind_id": item.bind_set.parameter_bind_id,
                "parameters": canonicalize(item.bind_set.values),
                "state": item.state,
                "value": flattened.get(item.scan_index, {}).get(name),
                "statistics": _typed_observable_statistics(item.result, name),
            }
            for item in source.items
        ]
        for name in observable_names
    }
    return ExperimentSectionIR(
        section_id="experiment.analyze",
        stage="analyze",
        title="Observable trends",
        status=(
            "available" if source.status.completed_count == source.status.total_items
            else "warning"
        ),
        payload={
            "observable_names": observable_names,
            "series": series,
            "items": [
                {
                    "scan_index": item.scan_index,
                    "parameter_bind_id": item.bind_set.parameter_bind_id,
                    "state": item.state,
                    "observables": (
                        None
                        if item.result is None
                        else canonicalize(item.result.observables)
                    ),
                    "observable_batch": (
                        None
                        if item.result is None
                        or item.result.observable_batch is None
                        else item.result.observable_batch.to_dict()
                    ),
                }
                for item in source.items
            ],
        },
        source_paths=(
            "LocalHybridScanJobResult.items[*].measurement_result.result.observables",
            "LocalHybridScanJobResult.items[*].measurement_result.result.observable_batch",
        ),
    )


def _batch_design_section(
    source: BatchResultIR,
    items: tuple[BatchItemResultRefIR, ...],
) -> ExperimentSectionIR:
    return ExperimentSectionIR(
        section_id="experiment.design",
        stage="design",
        title="Batch inputs",
        status="available",
        payload={
            "batch_id": source.batch_id,
            "compiled_program_hash": source.compiled_program_hash,
            "item_count": len(items),
            "parameter_values_available": False,
            "parameter_values_unavailable_reason": (
                "BatchResultIR retains bind identities and hashes, not bind values."
            ),
            "parameter_binds": [
                {
                    "item_index": item.item_index,
                    "parameter_bind_id": item.parameter_bind_id,
                    "parameter_bind_hash": item.parameter_bind_hash,
                }
                for item in items
            ],
        },
        source_paths=(
            "BatchResultIR.batch_id",
            "BatchResultIR.compiled_program_hash",
            "BatchResultIR.items[*].parameter_bind_id",
            "BatchResultIR.items[*].parameter_bind_hash",
        ),
    )


def _batch_plan_section(source: BatchResultIR) -> ExperimentSectionIR:
    runtime = _optional_metadata_mapping(source.metadata, "runtime")
    contract_summary = _optional_metadata_mapping(
        source.metadata,
        "contract_summary",
    )
    return ExperimentSectionIR(
        section_id="experiment.plan",
        stage="plan",
        title="Batch plan",
        status="available",
        payload={
            "compiled_program_hash": source.compiled_program_hash,
            "backend_id": source.backend_id,
            "runtime": runtime,
            "contract_summary": contract_summary,
        },
        source_paths=tuple(
            [
                "BatchResultIR.compiled_program_hash",
                "BatchResultIR.backend_id",
            ]
            + (["BatchResultIR.metadata.runtime"] if runtime is not None else [])
            + (
                ["BatchResultIR.metadata.contract_summary"]
                if contract_summary is not None
                else []
            )
        ),
    )


def _batch_execution_section(
    source: BatchResultIR,
    items: tuple[BatchItemResultRefIR, ...],
) -> ExperimentSectionIR:
    return ExperimentSectionIR(
        section_id="experiment.execute",
        stage="execute",
        title="Batch execution",
        status=_lifecycle_section_status(source.status),
        payload={
            "batch_result_id": source.batch_result_id,
            "batch_id": source.batch_id,
            "state": source.status,
            "trace_id": source.trace_id,
            "backend_id": source.backend_id,
            "counts": {
                "total": source.total_items,
                "created": source.created_count,
                "queued": source.queued_count,
                "running": source.running_count,
                "completed": source.completed_count,
                "partially_completed": source.partially_completed_count,
                "failed": source.failed_count,
                "cancelled": source.cancelled_count,
                "expired": source.expired_count,
            },
            "items": [
                {
                    "item_index": item.item_index,
                    "parameter_bind_id": item.parameter_bind_id,
                    "status": item.status,
                    "backend_job_id": item.backend_job_id,
                    "execution_package_id": item.execution_package_id,
                    "diagnostic_codes": [
                        diagnostic.code for diagnostic in item.diagnostics
                    ],
                }
                for item in items
            ],
        },
        source_paths=(
            "BatchResultIR.status",
            "BatchResultIR.trace_id",
            "BatchResultIR.items[*].status",
            "BatchResultIR.items[*].diagnostics",
        ),
        diagnostics=source.diagnostics,
    )


def _batch_reference_section(
    source: BatchResultIR,
    items: tuple[BatchItemResultRefIR, ...],
) -> ExperimentSectionIR:
    return ExperimentSectionIR(
        section_id="experiment.state",
        stage="state",
        title="Item result references",
        status="available",
        payload={
            "aggregate": {
                "batch_result_id": source.batch_result_id,
                "compiled_program_hash": source.compiled_program_hash,
                "trace_id": source.trace_id,
            },
            "items": [
                {
                    "item_index": item.item_index,
                    "parameter_bind_id": item.parameter_bind_id,
                    "status": item.status,
                    "result_id": item.result_id,
                    "references": (
                        None if item.references is None else item.references.to_dict()
                    ),
                    "result_hash_available": False,
                }
                for item in items
            ],
            "child_state_data_available": False,
            "child_state_data_unavailable_reason": (
                "BatchResultIR stores child references rather than child state data."
            ),
        },
        source_paths=(
            "BatchResultIR.batch_result_id",
            "BatchResultIR.compiled_program_hash",
            "BatchResultIR.trace_id",
            "BatchResultIR.items[*].result_id",
            "BatchResultIR.items[*].references",
        ),
    )


def _batch_measurement_section(
    source: BatchResultIR,
    items: tuple[BatchItemResultRefIR, ...],
) -> ExperimentSectionIR:
    return ExperimentSectionIR(
        section_id="experiment.measure",
        stage="measure",
        title="Batch measurement summary",
        status=(
            "available"
            if source.status == "completed"
            else _lifecycle_section_status(source.status)
        ),
        payload={
            "aggregate_counts": dict(sorted(source.aggregate_counts.items())),
            "aggregate_counts_source": "BatchResultIR.aggregate_counts",
            "per_item_measurements_available": False,
            "per_item_measurements_unavailable_reason": (
                "BatchResultIR stores child result references, not child counts, "
                "probabilities, or observables."
            ),
            "items": [
                {
                    "item_index": item.item_index,
                    "parameter_bind_id": item.parameter_bind_id,
                    "status": item.status,
                    "result_id": item.result_id,
                    "measurement_available": False,
                }
                for item in items
            ],
        },
        source_paths=(
            "BatchResultIR.aggregate_counts",
            "BatchResultIR.items[*].result_id",
        ),
    )


def _diagnostic_section(
    *,
    diagnostics: tuple[DiagnosticsIR, ...],
    source_path: str,
) -> ExperimentSectionIR:
    status: Literal["available", "warning", "error"] = "available"
    if any(item.severity == "error" for item in diagnostics):
        status = "error"
    elif any(item.severity == "warning" for item in diagnostics):
        status = "warning"
    return ExperimentSectionIR(
        section_id="experiment.validate",
        stage="validate",
        title="Validation and diagnostics",
        status=status,
        payload={
            "diagnostic_count": len(diagnostics),
            "codes": [item.code for item in diagnostics],
            "by_severity": _count_values(item.severity for item in diagnostics),
            "by_stage": _count_values(item.stage for item in diagnostics),
        },
        source_paths=(source_path,),
        diagnostics=diagnostics,
    )


def _sweep_measurement_item(item: LocalHybridScanItemOutcome) -> dict[str, Any]:
    result = item.result
    return {
        "scan_index": item.scan_index,
        "parameter_bind_id": item.bind_set.parameter_bind_id,
        "parameters": canonicalize(item.bind_set.values),
        "state": item.state,
        "result_id": None if result is None else result.result_id,
        "shots": None if result is None else result.shots,
        "counts": None if result is None else dict(sorted(result.counts.items())),
        "probabilities": (
            None
            if result is None or result.probabilities is None
            else dict(sorted(result.probabilities.items()))
        ),
    }


def _sweep_outcome_point(
    item: LocalHybridScanItemOutcome,
    *,
    outcome: str,
) -> dict[str, Any]:
    result = item.result
    return {
        "scan_index": item.scan_index,
        "parameter_bind_id": item.bind_set.parameter_bind_id,
        "parameters": canonicalize(item.bind_set.values),
        "state": item.state,
        "result_id": None if result is None else result.result_id,
        "count": None if result is None else result.counts.get(outcome, 0),
        "probability": (
            None
            if result is None or result.probabilities is None
            else result.probabilities.get(outcome, 0.0)
        ),
    }


def _result_state_payload(result: ResultIR) -> dict[str, Any] | None:
    keys = ("simulation_state", "state_hash", "noise_report", "simulation_truthfulness")
    payload = {
        key: canonicalize(result.metadata[key])
        for key in keys
        if key in result.metadata
    }
    references = result.metadata.get("references")
    if isinstance(references, Mapping):
        payload["references"] = canonicalize(references)
    execution_config = result.execution_config()
    if execution_config is not None:
        payload["execution_config"] = execution_config.to_dict()
    solver_evidence = result.solver_evidence()
    if solver_evidence is not None:
        payload["solver_evidence"] = solver_evidence.to_dict()
    transitions = result.state_transitions()
    if transitions:
        payload["state_transitions"] = [item.to_dict() for item in transitions]
    return payload or None


def _flatten_numeric_observables(result: ResultIR) -> dict[str, float]:
    flattened: dict[str, float] = {}

    def visit(value: Any, path: str) -> None:
        if isinstance(value, Mapping):
            for key in sorted(value, key=str):
                child_path = f"{path}.{key}" if path else str(key)
                visit(value[key], child_path)
        elif isinstance(value, Real) and not isinstance(value, bool) and path:
            flattened[path] = float(value)

    visit(result.observables, "")
    if result.observable_batch is not None:
        for item in result.observable_batch.items:
            flattened[item.name] = item.expectation
    return flattened


def _typed_observable_statistics(
    result: ResultIR | None,
    name: str,
) -> dict[str, Any] | None:
    if result is None or result.observable_batch is None:
        return None
    for item in result.observable_batch.items:
        if item.name == name:
            return {
                "expectation": item.expectation,
                "variance": item.variance,
                "standard_error": item.standard_error,
                "sample_count": item.sample_count,
                "source_kind": item.source_kind.value,
                "source_hash": item.source_hash,
                "estimator_kind": item.estimator_kind.value,
            }
    return None


def _optional_metadata_mapping(
    metadata: Mapping[str, Any],
    key: str,
) -> dict[str, Any] | None:
    if key not in metadata:
        return None
    value = metadata[key]
    if not isinstance(value, Mapping):
        raise TypeError(f"metadata.{key} must be a mapping.")
    normalized = canonicalize(value)
    if not isinstance(normalized, dict):  # pragma: no cover - Mapping canonicalizes.
        raise TypeError(f"metadata.{key} must be a JSON-compatible mapping.")
    return normalized


def _validated_batch_items(
    source: BatchResultIR,
) -> tuple[BatchItemResultRefIR, ...]:
    if not isinstance(source, BatchResultIR):
        raise TypeError("source must be BatchResultIR.")
    for name, value in (
        ("batch_result_id", source.batch_result_id),
        ("batch_id", source.batch_id),
        ("backend_id", source.backend_id),
        ("trace_id", source.trace_id),
    ):
        _require_non_empty_string(value, field_name=f"BatchResultIR.{name}")
    _require_sha256(
        source.compiled_program_hash,
        field_name="BatchResultIR.compiled_program_hash",
    )
    if source.status not in _BATCH_STATES:
        raise ValueError(f"Unsupported BatchResultIR status: {source.status!r}.")
    if not isinstance(source.items, (tuple, list)) or any(
        not isinstance(item, BatchItemResultRefIR) for item in source.items
    ):
        raise TypeError("BatchResultIR.items must contain BatchItemResultRefIR values.")
    items = tuple(sorted(source.items, key=lambda item: item.item_index))
    if tuple(item.item_index for item in items) != tuple(range(len(items))):
        raise ValueError(
            "Batch item indexes must be unique, contiguous, and non-negative."
        )
    if len(items) != source.total_items:
        raise ValueError("Batch item count must match total_items.")

    count_fields = (
        source.total_items,
        source.created_count,
        source.queued_count,
        source.running_count,
        source.completed_count,
        source.partially_completed_count,
        source.failed_count,
        source.cancelled_count,
        source.expired_count,
    )
    if any(
        not isinstance(value, int) or isinstance(value, bool) or value < 0
        for value in count_fields
    ):
        raise ValueError("Batch lifecycle counts must be non-negative integers.")
    if sum(count_fields[1:]) != source.total_items:
        raise ValueError("Batch lifecycle counts must equal total_items.")

    item_counts = {
        state: sum(item.status == state for item in items)
        for state in _BATCH_ITEM_STATES
    }
    expected_counts = {
        "created": source.created_count,
        "queued": source.queued_count,
        "running": source.running_count,
        "completed": source.completed_count,
        "partially_completed": source.partially_completed_count,
        "failed": source.failed_count,
        "cancelled": source.cancelled_count,
        "expired": source.expired_count,
    }
    if item_counts != expected_counts:
        raise ValueError("Batch item states must match aggregate lifecycle counts.")
    expected_state = _aggregate_batch_state(expected_counts, total=len(items))
    if source.status != expected_state:
        raise ValueError("Batch aggregate status does not match its item states.")

    for item in items:
        _validate_batch_item(source, item)
    for field_name, values in (
        ("parameter_bind_id", [item.parameter_bind_id for item in items]),
        ("execution_package_id", [item.execution_package_id for item in items]),
        ("backend_job_id", [item.backend_job_id for item in items]),
        (
            "result_id",
            [item.result_id for item in items if item.result_id is not None],
        ),
    ):
        if len(set(values)) != len(values):
            raise ValueError(f"Batch item {field_name} values must be unique.")
    if any(
        not isinstance(key, str) or not key
        for key in source.aggregate_counts
    ):
        raise ValueError("Batch aggregate count keys must be non-empty strings.")
    if any(
        not isinstance(value, int) or isinstance(value, bool) or value < 0
        for value in source.aggregate_counts.values()
    ):
        raise ValueError("Batch aggregate counts must be non-negative integers.")
    if any(not isinstance(item, DiagnosticsIR) for item in source.diagnostics):
        raise TypeError("BatchResultIR diagnostics must contain DiagnosticsIR values.")
    return items


def _validate_batch_item(source: BatchResultIR, item: BatchItemResultRefIR) -> None:
    for name, value in (
        ("parameter_bind_id", item.parameter_bind_id),
        ("execution_package_id", item.execution_package_id),
        ("backend_job_id", item.backend_job_id),
    ):
        _require_non_empty_string(value, field_name=f"Batch item {name}")
    if item.parameter_bind_hash is not None:
        _require_sha256(
            item.parameter_bind_hash,
            field_name="Batch item parameter_bind_hash",
        )
    if item.status in {"completed", "partially_completed"}:
        if not isinstance(item.result_id, str) or not item.result_id.strip():
            raise ValueError("Completed batch items require a result_id.")
    elif item.result_id is not None:
        raise ValueError(
            "Only completed or partially completed batch items may reference "
            "a result_id."
        )
    if item.references is not None:
        if item.references.execution_package_id != item.execution_package_id:
            raise ValueError(
                "Batch item references must match execution_package_id."
            )
        compiled_hash = item.references.compiled_program_hash
        if compiled_hash is not None and compiled_hash != source.compiled_program_hash:
            raise ValueError(
                "Batch item references must match compiled_program_hash."
            )
    if any(not isinstance(value, DiagnosticsIR) for value in item.diagnostics):
        raise TypeError("Batch item diagnostics must contain DiagnosticsIR values.")


def _aggregate_batch_state(counts: Mapping[str, int], *, total: int) -> str:
    if total == 0:
        return "failed"
    completed = counts["completed"]
    partially_completed = counts["partially_completed"]
    failed = counts["failed"]
    cancelled = counts["cancelled"]
    expired = counts["expired"]
    terminal = completed + partially_completed + failed + cancelled + expired
    if partially_completed:
        return "partially_completed"
    if failed and failed < total:
        return "partially_completed"
    if failed == total:
        return "failed"
    if cancelled == total:
        return "cancelled"
    if expired == total:
        return "expired"
    if completed == total:
        return "completed"
    if terminal:
        return "partially_completed"
    if counts["running"]:
        return "running"
    if counts["queued"]:
        return "queued"
    if counts["created"]:
        return "created"
    return "failed"


def _lifecycle_section_status(
    state: str,
) -> Literal["available", "warning", "error"]:
    if state == "completed":
        return "available"
    if state == "failed":
        return "error"
    return "warning"


def _ordered_unique(values: list[Any]) -> list[Any]:
    unique: list[Any] = []
    for value in values:
        if value not in unique:
            unique.append(value)
    return unique


def _require_non_empty_string(value: object, *, field_name: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field_name} must be a non-empty string.")


def _require_sha256(value: object, *, field_name: str) -> None:
    if not isinstance(value, str) or len(value) != 64 or any(
        character not in "0123456789abcdef" for character in value
    ):
        raise ValueError(f"{field_name} must be a lowercase SHA-256 digest.")


def _count_values(values: Iterable[object]) -> dict[str, int]:
    counts: dict[str, int] = {}
    for value in values:
        key = str(value)
        counts[key] = counts.get(key, 0) + 1
    return {key: counts[key] for key in sorted(counts)}
