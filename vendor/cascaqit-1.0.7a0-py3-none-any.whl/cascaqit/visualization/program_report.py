"""Program-context sections for Digital and Analog experiment reports."""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import Any, Literal, Union

from cascaqit.analog import AHSProgram
from cascaqit.digital import Circuit, DigitalProgramIR
from cascaqit.hybrid import (
    AnalogBlockIR,
    DigitalBlockIR,
    HybridProgram,
    HybridProgramIR,
    MeasureBlockIR,
)
from cascaqit.native_ir.base import stable_json
from cascaqit.native_ir.models import ProgramIR
from cascaqit.visualization.experiment import ExperimentSectionIR
from cascaqit.visualization.models import (
    build_pulse_timeline,
    build_register_visualization,
)

__all__ = ["ProgramContextSource"]

ProgramContextSource = Union[
    Circuit,
    DigitalProgramIR,
    AHSProgram,
    ProgramIR,
    HybridProgram,
    HybridProgramIR,
]
ProgramContextProfile = Literal["digital", "analog", "hybrid"]


@dataclass(frozen=True)
class ProgramReportContext:
    """Normalized source identity plus the standard Design section."""

    program_id: str
    profile: ProgramContextProfile
    source_kind: str
    execution_hash: str
    source_hash: str
    section: ExperimentSectionIR
    plan_payload: dict[str, Any] | None
    plan_source_paths: tuple[str, ...]


def build_program_report_context(program: object) -> ProgramReportContext:
    """Normalize a supported builder or IR without executing the program."""
    if isinstance(program, Circuit):
        program_ir = program.to_ir()
        parameters = [parameter.to_ir().to_dict() for parameter in program.parameters]
        return _digital_context(
            program_ir,
            source_kind="Circuit",
            parameters=parameters,
        )
    if isinstance(program, DigitalProgramIR):
        return _digital_context(
            program,
            source_kind="DigitalProgramIR",
            parameters=[],
        )
    if isinstance(program, AHSProgram):
        return _analog_context(program.to_ir(), source_kind="AHSProgram")
    if isinstance(program, ProgramIR):
        return _analog_context(program, source_kind="ProgramIR")
    if isinstance(program, HybridProgram):
        return _hybrid_context(program)
    if isinstance(program, HybridProgramIR):
        return _hybrid_ir_context(program)
    raise TypeError(
        "program must be Circuit, DigitalProgramIR, AHSProgram, ProgramIR, "
        "HybridProgram, or HybridProgramIR."
    )


def _digital_context(
    program: DigitalProgramIR,
    *,
    source_kind: str,
    parameters: list[dict[str, object]],
) -> ProgramReportContext:
    circuit = program.circuit
    gates = [
        {
            "gate_id": gate.gate_id,
            "name": gate.name,
            "targets": list(gate.targets),
            "controls": list(gate.controls),
            "parameters": gate.parameters,
        }
        for gate in circuit.gates
    ]
    measurements = [measurement.to_dict() for measurement in circuit.measurements]
    payload = {
        "program_kind": "digital",
        "program_id": program.program_id,
        "program_hash": program.stable_hash(),
        "qubits": list(circuit.qubits),
        "qubit_count": len(circuit.qubits),
        "gates": gates,
        "gate_count": len(gates),
        "parameters": parameters,
        "parameter_count": len(parameters),
        "measurements": measurements,
        "measurement_count": len(measurements),
        "validation_mode": program.validation_mode,
    }
    section = ExperimentSectionIR(
        section_id="experiment.design",
        stage="design",
        title="Digital experiment design",
        status="available",
        payload=payload,
        source_paths=(
            f"{source_kind}.program_id",
            f"{source_kind}.circuit",
            f"{source_kind}.parameters",
        ),
    )
    return ProgramReportContext(
        program_id=program.program_id,
        profile="digital",
        source_kind=source_kind,
        execution_hash=program.stable_hash(),
        source_hash=_context_hash(payload),
        section=section,
        plan_payload=None,
        plan_source_paths=(),
    )


def _analog_context(
    program: ProgramIR,
    *,
    source_kind: str,
) -> ProgramReportContext:
    register = build_register_visualization(program)
    pulses = build_pulse_timeline(program)
    filled_sites = tuple(site for site in program.register.sites if site.is_active)
    parameters = program.parameter_schema.to_dict()
    payload = {
        "program_kind": "analog",
        "program_id": program.program_id,
        "program_hash": program.stable_hash(),
        "lifecycle_state": program.lifecycle_state,
        "register_visualization": register.to_dict(),
        "register_snapshot": program.register.snapshot_evidence(),
        "site_count": len(program.register.sites),
        "filled_site_count": len(filled_sites),
        "pulse_timeline": pulses.to_dict(),
        "site_addressing_timeline": _site_addressing_timeline(program),
        "site_phase_patterns": _site_phase_patterns(program),
        "global_control_count": 3,
        "local_detuning_count": len(program.hamiltonian.local_detuning_terms),
        "local_rabi_count": len(program.hamiltonian.local_rabi_terms),
        "parameters": parameters,
        "parameter_count": len(program.parameter_schema.parameters),
        "measurements": [measurement.to_dict() for measurement in program.measurements],
        "measurement_count": len(program.measurements),
    }
    section = ExperimentSectionIR(
        section_id="experiment.design",
        stage="design",
        title="Analog experiment design",
        status="available",
        payload=payload,
        source_paths=(
            f"{source_kind}.register",
            f"{source_kind}.hamiltonian",
            f"{source_kind}.parameter_schema",
            f"{source_kind}.measurements",
        ),
    )
    return ProgramReportContext(
        program_id=program.program_id,
        profile="analog",
        source_kind=source_kind,
        execution_hash=program.stable_hash(),
        source_hash=_context_hash(payload),
        section=section,
        plan_payload=None,
        plan_source_paths=(),
    )


def _hybrid_context(program: HybridProgram) -> ProgramReportContext:
    program_ir = program.to_ir()
    analysis = program.analyze()
    compilation = program.compile()
    blocks: list[dict[str, Any]] = []
    for order, block in enumerate(program_ir.blocks):
        if isinstance(block, DigitalBlockIR):
            blocks.append(_hybrid_digital_block(block, order=order))
        elif isinstance(block, AnalogBlockIR):
            blocks.append(_hybrid_analog_block(block, order=order))
        elif isinstance(block, MeasureBlockIR):
            blocks.append(
                {
                    "order": order,
                    "block_id": block.block_id,
                    "block_type": "measure",
                    "measurements": [item.to_dict() for item in block.measurements],
                    "start_time": block.start_time,
                    "duration": block.duration,
                    "time_unit": block.time_unit,
                }
            )
        else:  # pragma: no cover - HybridProgramIR owns a closed block union.
            raise TypeError(f"Unsupported Hybrid block type: {type(block).__name__}.")

    design_payload = {
        "program_kind": "hybrid",
        "program_id": program.program_id,
        "program_hash": program.stable_hash(),
        "block_count": len(blocks),
        "blocks": blocks,
        "mapping": dict(sorted(program_ir.mapping.items())),
        "parameters": program.parameters.schema.to_dict(),
        "parameter_count": len(program.parameters.schema.parameters),
        "analysis": analysis.to_dict(),
    }
    compilation_payload = {
        "hybrid_compilation": compilation.to_dict(),
    }
    section = ExperimentSectionIR(
        section_id="experiment.design",
        stage="design",
        title="Hybrid experiment design",
        status="error" if compilation.has_errors else "available",
        payload=design_payload,
        source_paths=(
            "HybridProgram.blocks",
            "HybridProgram.parameters",
            "HybridProgram.analyze()",
            "HybridProgram.to_ir()",
        ),
    )
    return ProgramReportContext(
        program_id=program.program_id,
        profile="hybrid",
        source_kind="HybridProgram",
        execution_hash=program.stable_hash(),
        source_hash=_context_hash(
            {
                "design": design_payload,
                "plan": compilation_payload,
            }
        ),
        section=section,
        plan_payload=compilation_payload,
        plan_source_paths=("HybridProgram.compile()",),
    )


def _hybrid_ir_context(program: HybridProgramIR) -> ProgramReportContext:
    """Build report context from the serialized Hybrid execution boundary."""
    blocks: list[dict[str, Any]] = []
    for order, block in enumerate(program.blocks):
        if isinstance(block, DigitalBlockIR):
            blocks.append(_hybrid_digital_block(block, order=order))
        elif isinstance(block, AnalogBlockIR):
            blocks.append(_hybrid_analog_block(block, order=order))
        elif isinstance(block, MeasureBlockIR):
            blocks.append(
                {
                    "order": order,
                    "block_id": block.block_id,
                    "block_type": "measure",
                    "measurements": [item.to_dict() for item in block.measurements],
                    "start_time": block.start_time,
                    "duration": block.duration,
                    "time_unit": block.time_unit,
                }
            )
        else:  # pragma: no cover - HybridProgramIR owns a closed block union.
            raise TypeError(f"Unsupported Hybrid block type: {type(block).__name__}.")

    diagnostics = program.validate_ir_only()
    execution_hash = program.metadata.get("hybrid_program_hash")
    if not isinstance(execution_hash, str):
        raise ValueError(
            "HybridProgramIR report context requires metadata.hybrid_program_hash."
        )
    design_payload = {
        "program_kind": "hybrid",
        "program_id": program.program_id,
        "program_hash": execution_hash,
        "block_count": len(blocks),
        "blocks": blocks,
        "mapping": dict(sorted(program.mapping.items())),
        "parameters": {"parameters": []},
        "parameter_count": 0,
        "validation_mode": program.validation_mode,
    }
    plan_payload = {
        "hybrid_ir_validation": [item.to_dict() for item in diagnostics],
    }
    section = ExperimentSectionIR(
        section_id="experiment.design",
        stage="design",
        title="Hybrid experiment design",
        status=(
            "error"
            if any(item.severity == "error" for item in diagnostics)
            else "available"
        ),
        payload=design_payload,
        source_paths=(
            "HybridProgramIR.blocks",
            "HybridProgramIR.mapping",
            "HybridProgramIR.metadata.hybrid_program_hash",
        ),
    )
    return ProgramReportContext(
        program_id=program.program_id,
        profile="hybrid",
        source_kind="HybridProgramIR",
        execution_hash=execution_hash,
        source_hash=_context_hash(
            {"design": design_payload, "plan": plan_payload}
        ),
        section=section,
        plan_payload=plan_payload,
        plan_source_paths=("HybridProgramIR.validate_ir_only()",),
    )


def _hybrid_digital_block(block: DigitalBlockIR, *, order: int) -> dict[str, Any]:
    return {
        "order": order,
        "block_id": block.block_id,
        "block_type": "digital",
        "qubits": list(block.circuit.qubits),
        "gates": [gate.to_dict() for gate in block.circuit.gates],
        "gate_count": len(block.circuit.gates),
        "measurements": [item.to_dict() for item in block.circuit.measurements],
        "start_time": block.start_time,
        "duration": block.duration,
        "time_unit": block.time_unit,
    }


def _hybrid_analog_block(block: AnalogBlockIR, *, order: int) -> dict[str, Any]:
    register = build_register_visualization(block.program)
    pulses = build_pulse_timeline(block.program)
    return {
        "order": order,
        "block_id": block.block_id,
        "block_type": "analog",
        "register_visualization": register.to_dict(),
        "register_snapshot": block.program.register.snapshot_evidence(),
        "pulse_timeline": pulses.to_dict(),
        "site_addressing_timeline": _site_addressing_timeline(block.program),
        "site_phase_patterns": _site_phase_patterns(block.program),
        "measurements": [item.to_dict() for item in block.program.measurements],
        "start_time": block.start_time,
        "duration": block.duration,
        "time_unit": block.time_unit,
    }


def _site_addressing_timeline(program: ProgramIR) -> list[dict[str, Any]]:
    """Project canonical local-control frames without changing waveform facts."""
    terms = (
        *(
            ("local_detuning", index, term.addressing)
            for index, term in enumerate(program.hamiltonian.local_detuning_terms)
        ),
        *(
            ("local_rabi", index, term.addressing)
            for index, term in enumerate(program.hamiltonian.local_rabi_terms)
        ),
    )
    timelines: list[dict[str, Any]] = []
    for control_kind, term_index, addressing in terms:
        frames = []
        for frame_index, (start, weights) in enumerate(
            zip(addressing.times, addressing.weights)
        ):
            is_last = frame_index == addressing.frame_count - 1
            stop = (
                addressing.duration
                if is_last
                else addressing.times[frame_index + 1]
            )
            frames.append(
                {
                    "frame_index": frame_index,
                    "start": start,
                    "stop": stop,
                    "is_last": is_last,
                    "active_sites": [
                        {"site_id": site_id, "weight": weight}
                        for site_id, weight in zip(addressing.site_ids, weights)
                        if weight != 0.0
                    ],
                }
            )
        timelines.append(
            {
                "control_id": f"{control_kind}_{term_index}",
                "control_kind": control_kind,
                "term_index": term_index,
                "source_kind": addressing.source_kind,
                "addressing_hash": addressing.stable_hash(),
                "duration": addressing.duration,
                "time_unit": addressing.time_unit,
                "interpolation": addressing.interpolation,
                "frame_count": addressing.frame_count,
                "is_dynamic": addressing.is_dynamic,
                "site_ids": list(addressing.site_ids),
                "frames": frames,
            }
        )
    return timelines


def _site_phase_patterns(program: ProgramIR) -> list[dict[str, Any]]:
    """Project typed per-site phase offsets without sampling or wrapping them."""
    return [
        {
            "control_id": f"local_rabi_{index}",
            "term_index": index,
            "site_ids": list(term.phase_pattern.site_ids),
            "offsets": list(term.phase_pattern.offsets),
            "unit": term.phase_pattern.unit,
            "phase_pattern_hash": term.phase_pattern.stable_hash(),
            "source_path": (
                f"ProgramIR.hamiltonian.local_rabi_terms[{index}].phase_pattern"
            ),
        }
        for index, term in enumerate(program.hamiltonian.local_rabi_terms)
    ]


def _context_hash(payload: dict[str, object]) -> str:
    """Hash every displayed design fact, not only the executable Program IR."""
    return hashlib.sha256(stable_json(payload).encode("utf-8")).hexdigest()
