"""One-step public API for standard experiment visualization."""

from __future__ import annotations

import hashlib
import os
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal, Union, cast

from cascaqit.algorithms import VariationalResult
from cascaqit.problems.execution import ProblemExecutionResult
from cascaqit.problems.layer_experiment import ProblemLayerExperimentResult
from cascaqit.problems.repeated_layer_experiment import (
    ProblemRepeatedLayerExperimentResult,
)
from cascaqit.results import BatchResultIR, ResultIR
from cascaqit.simulators import LocalHybridScanJobResult
from cascaqit.visualization.algorithm_report import (
    build_algorithm_experiment_report,
)
from cascaqit.visualization.comparison_report import (
    build_comparison_experiment_report,
)
from cascaqit.visualization.experiment import (
    ExperimentProfile,
    ExperimentReportIR,
    ExperimentSectionIR,
)
from cascaqit.visualization.html_report import render_experiment_report_html
from cascaqit.visualization.problem_comparison_report import (
    build_problem_comparison_experiment_report,
)
from cascaqit.visualization.problem_layer_experiment_report import (
    build_problem_layer_experiment_report,
)
from cascaqit.visualization.problem_repeated_layer_experiment_report import (
    build_problem_repeated_layer_experiment_report,
)
from cascaqit.visualization.problem_report import build_problem_experiment_report
from cascaqit.visualization.program_report import ProgramContextSource
from cascaqit.visualization.result_report import build_result_experiment_report
from cascaqit.visualization.scan_batch_report import (
    build_batch_experiment_report,
    build_sweep_experiment_report,
)

__all__ = ["ExperimentReport", "visualize"]

ProfileSelection = Union[Literal["auto"], ExperimentProfile]
OutputPath = Union[str, os.PathLike[str]]

_PROFILE_SELECTIONS = frozenset(
    (
        "auto",
        "digital",
        "analog",
        "hybrid",
        "sweep",
        "comparison",
        "batch",
        "algorithm",
        "problem",
    )
)


@dataclass(frozen=True)
class ExperimentReport:
    """User-facing report with canonical serialization and standalone HTML."""

    report_ir: ExperimentReportIR

    def __post_init__(self) -> None:
        if not isinstance(self.report_ir, ExperimentReportIR):
            raise TypeError("report_ir must be ExperimentReportIR.")

    @property
    def report_id(self) -> str:
        """Return the stable report identity."""
        return self.report_ir.report_id

    @property
    def profile(self) -> ExperimentProfile:
        """Return the resolved standard experiment profile."""
        return self.report_ir.profile

    @property
    def sections(self) -> tuple[ExperimentSectionIR, ...]:
        """Return ordered lifecycle sections."""
        return self.report_ir.sections

    def section(self, section_id: str) -> ExperimentSectionIR:
        """Return a lifecycle section by stable id."""
        return self.report_ir.section(section_id)

    def to_dict(self) -> dict[str, Any]:
        """Return JSON-compatible report facts."""
        return self.report_ir.to_dict()

    def to_json(self) -> str:
        """Return canonical JSON for the current report facts."""
        return self.report_ir.to_json()

    def to_html(self, *, language: str = "en") -> str:
        """Return dependency-free standalone HTML for the current report facts."""
        return render_experiment_report_html(self.report_ir, language=language)

    def stable_hash(self) -> str:
        """Return the semantic hash of the underlying report facts."""
        return self.report_ir.stable_hash()

    def html_hash(self, *, language: str = "en") -> str:
        """Return SHA-256 for the exact standalone HTML bytes."""
        return hashlib.sha256(
            self.to_html(language=language).encode("utf-8")
        ).hexdigest()

    def save(
        self,
        output: OutputPath,
        *,
        format: str = "html",
        language: str = "en",
    ) -> Path:
        """Write standalone HTML and return its normalized path."""
        if format != "html":
            raise ValueError("ExperimentReport.save supports only format='html'.")
        path = _validated_output_path(output)
        path.write_text(self.to_html(language=language), encoding="utf-8")
        return path


def visualize(
    source: object,
    *,
    program: ProgramContextSource | None = None,
    profile: ProfileSelection = "auto",
    output: OutputPath | None = None,
    title: str | None = None,
    language: Literal["en", "zh"] = "en",
) -> ExperimentReport:
    """Build a standard report and optionally save it in the selected language."""
    resolved_selection = _validated_profile(profile)
    if language not in ("en", "zh"):
        raise ValueError("language must be 'en' or 'zh'.")
    if title is not None and (not isinstance(title, str) or not title.strip()):
        raise ValueError("title must be a non-empty string or None.")

    if isinstance(source, ProblemRepeatedLayerExperimentResult):
        _reject_program_context(program, source_kind="repeated layer experiment")
        _require_profile(resolved_selection, expected="comparison")
        report_ir = build_problem_repeated_layer_experiment_report(
            source,
            title="Problem repeated layer experiment" if title is None else title,
        )
    elif isinstance(source, ProblemLayerExperimentResult):
        _reject_program_context(program, source_kind="layer experiment")
        _require_profile(resolved_selection, expected="comparison")
        report_ir = build_problem_layer_experiment_report(
            source,
            title="Problem layer experiment" if title is None else title,
        )
    elif isinstance(source, ProblemExecutionResult):
        _reject_program_context(program, source_kind="problem")
        _require_profile(resolved_selection, expected="problem")
        report_ir = build_problem_experiment_report(source, title=title)
    elif isinstance(source, VariationalResult):
        _reject_program_context(program, source_kind="algorithm")
        _require_profile(resolved_selection, expected="algorithm")
        report_ir = build_algorithm_experiment_report(source, title=title)
    elif isinstance(source, ResultIR):
        requested_profile = (
            None
            if resolved_selection == "auto"
            else resolved_selection
        )
        report_ir = build_result_experiment_report(
            source,
            profile=requested_profile,
            program=program,
            title=title,
        )
    elif isinstance(source, LocalHybridScanJobResult):
        _reject_program_context(program, source_kind="sweep")
        _require_profile(resolved_selection, expected="sweep")
        report_ir = build_sweep_experiment_report(source, title=title)
    elif isinstance(source, BatchResultIR):
        _reject_program_context(program, source_kind="batch")
        _require_profile(resolved_selection, expected="batch")
        report_ir = build_batch_experiment_report(source, title=title)
    elif isinstance(source, Mapping):
        _reject_program_context(program, source_kind="comparison")
        _require_profile(resolved_selection, expected="comparison")
        values = tuple(source.values())
        if not values:
            raise ValueError("Comparison requires at least two sources.")
        if values and all(
            isinstance(value, ProblemExecutionResult) for value in values
        ):
            report_ir = build_problem_comparison_experiment_report(
                cast(Mapping[str, ProblemExecutionResult], source),
                title="Problem optimization comparison" if title is None else title,
            )
        elif values and all(isinstance(value, ResultIR) for value in values):
            report_ir = build_comparison_experiment_report(
                cast(Mapping[str, ResultIR], source),
                title="Experiment comparison" if title is None else title,
            )
        elif any(
            isinstance(value, (ProblemExecutionResult, ResultIR)) for value in values
        ):
            if all(
                isinstance(value, (ProblemExecutionResult, ResultIR))
                for value in values
            ):
                raise TypeError(
                    "Comparison values must all use the same supported result type."
                )
            raise TypeError(
                "Comparison values must be ResultIR or ProblemExecutionResult."
            )
        else:
            raise TypeError(
                "Comparison values must be ResultIR or ProblemExecutionResult."
            )
    else:
        raise TypeError(
            "visualize source must be ProblemRepeatedLayerExperimentResult, "
            "ProblemLayerExperimentResult, "
            "ProblemExecutionResult, VariationalResult, "
            "ResultIR, "
            "LocalHybridScanJobResult, BatchResultIR, or a mapping of labels "
            "to ResultIR or ProblemExecutionResult values."
        )

    report = ExperimentReport(report_ir)
    if output is not None:
        report.save(output, language=language)
    return report


def _validated_profile(profile: object) -> ProfileSelection:
    if not isinstance(profile, str) or profile not in _PROFILE_SELECTIONS:
        raise ValueError(
            "profile must be auto, digital, analog, hybrid, sweep, comparison, "
            "batch, algorithm, or problem."
        )
    return cast(ProfileSelection, profile)


def _require_profile(selection: ProfileSelection, *, expected: str) -> None:
    if selection not in ("auto", expected):
        raise ValueError(
            f"Requested profile {selection!r} does not match {expected} source."
        )


def _reject_program_context(
    program: ProgramContextSource | None,
    *,
    source_kind: str,
) -> None:
    if program is not None:
        raise ValueError(
            f"program context is supported only for a single ResultIR, not "
            f"{source_kind} source."
        )


def _validated_output_path(output: object) -> Path:
    if not isinstance(output, (str, os.PathLike)):
        raise TypeError("output must be a string or path-like value.")
    if isinstance(output, str) and not output.strip():
        raise ValueError("output path must not be empty.")
    path = Path(output).expanduser()
    if path.exists() and path.is_dir():
        raise ValueError("output path must identify a file, not a directory.")
    if path.suffix.lower() != ".html":
        raise ValueError("output path must use the .html extension.")
    if not path.parent.exists():
        raise ValueError("output parent directory does not exist.")
    if not path.parent.is_dir():
        raise ValueError("output parent must be a directory.")
    return path
