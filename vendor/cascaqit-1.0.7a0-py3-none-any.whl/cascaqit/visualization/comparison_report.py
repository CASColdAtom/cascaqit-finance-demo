"""Standard, source-aligned comparison reports for completed ResultIR values."""

from __future__ import annotations

import hashlib
from collections.abc import Mapping
from numbers import Real
from typing import Any

from cascaqit.native_ir.base import canonicalize, stable_json
from cascaqit.results import ResultIR
from cascaqit.visualization.experiment import (
    ExperimentReportIR,
    ExperimentSectionIR,
    unavailable_experiment_section,
)
from cascaqit.visualization.result_report import build_result_experiment_report

__all__ = ["build_comparison_experiment_report"]


def build_comparison_experiment_report(
    sources: Mapping[str, ResultIR],
    *,
    report_id: str | None = None,
    title: str = "Experiment comparison",
) -> ExperimentReportIR:
    """Compare completed results without rerunning or mutating any source."""
    ordered = _validated_sources(sources)
    snapshots = {label: result.to_dict() for label, result in ordered}
    reports = {
        label: build_result_experiment_report(result)
        for label, result in ordered
    }
    baseline_label, baseline = ordered[0]
    sections = (
        unavailable_experiment_section(
            section_id="experiment.design",
            stage="design",
            title="Experiment design",
            reason="Comparison inputs do not include program context.",
        ),
        _comparison_validation_section(ordered),
        _comparison_source_section("plan", "Plan and compile", reports),
        _comparison_source_section("execute", "Execution", reports),
        _comparison_source_section("state", "State and noise", reports),
        _comparison_measurement_section(ordered, baseline_label, baseline),
        _comparison_analysis_section(ordered, baseline_label, baseline),
    )
    source_ids = tuple(result.result_id for _, result in ordered)
    source_hashes = {result.result_id: result.stable_hash() for _, result in ordered}
    digest = hashlib.sha256(
        stable_json(
            {
                "labels": [label for label, _ in ordered],
                "source_hashes": source_hashes,
            }
        ).encode("utf-8")
    ).hexdigest()[:16]
    report = ExperimentReportIR(
        report_id=report_id or f"experiment_report.comparison.{digest}",
        title=title,
        profile="comparison",
        source_kind="ResultComparison",
        source_ids=source_ids,
        source_hashes=source_hashes,
        sections=sections,
        metadata={
            "source_labels": {
                label: result.result_id for label, result in ordered
            },
            "baseline_label": baseline_label,
            "derived_view": True,
            "source_results_mutated": False,
            "artifact_bytes_read": False,
            "backend_called": False,
            "network_accessed": False,
        },
    )
    if any(result.to_dict() != snapshots[label] for label, result in ordered):
        raise ValueError("Comparison report construction mutated a source ResultIR.")
    return report


def _validated_sources(
    sources: Mapping[str, ResultIR],
) -> tuple[tuple[str, ResultIR], ...]:
    if not isinstance(sources, Mapping):
        raise TypeError("sources must be a mapping of labels to ResultIR values.")
    if len(sources) < 2:
        raise ValueError("Comparison requires at least two ResultIR sources.")
    ordered: list[tuple[str, ResultIR]] = []
    for label in sorted(sources):
        if not isinstance(label, str) or not label.strip():
            raise ValueError("Comparison labels must be non-empty strings.")
        result = sources[label]
        if not isinstance(result, ResultIR):
            raise TypeError(f"Comparison source {label!r} must be ResultIR.")
        ordered.append((label, result))
    result_ids = tuple(result.result_id for _, result in ordered)
    if len(set(result_ids)) != len(result_ids):
        raise ValueError("Comparison source result_id values must be unique.")
    baseline = ordered[0][1]
    for label, result in ordered[1:]:
        if result.program_hash != baseline.program_hash:
            raise ValueError(
                f"Comparison source {label!r} has a different program_hash."
            )
        if result.bit_ordering != baseline.bit_ordering:
            raise ValueError(f"Comparison source {label!r} has different bit_ordering.")
        if result.occupation_encoding != baseline.occupation_encoding:
            raise ValueError(
                f"Comparison source {label!r} has different occupation_encoding."
            )
    return tuple(ordered)


def _comparison_validation_section(
    ordered: tuple[tuple[str, ResultIR], ...],
) -> ExperimentSectionIR:
    diagnostics = tuple(
        diagnostic for _, result in ordered for diagnostic in result.diagnostics
    )
    status = "available"
    if any(item.severity == "error" for item in diagnostics):
        status = "error"
    elif any(item.severity == "warning" for item in diagnostics):
        status = "warning"
    return ExperimentSectionIR(
        section_id="experiment.validate",
        stage="validate",
        title="Validation and alignment",
        status=status,  # type: ignore[arg-type]
        payload={
            "source_count": len(ordered),
            "labels": [label for label, _ in ordered],
            "program_hash": ordered[0][1].program_hash,
            "bit_ordering": canonicalize(ordered[0][1].bit_ordering),
            "occupation_encoding": ordered[0][1].occupation_encoding.to_dict(),
            "diagnostic_count": len(diagnostics),
        },
        source_paths=tuple(
            path
            for label, _ in ordered
            for path in (
                f"sources.{label}.program_hash",
                f"sources.{label}.bit_ordering",
                f"sources.{label}.occupation_encoding",
                f"sources.{label}.diagnostics",
            )
        ),
        diagnostics=diagnostics,
    )


def _comparison_source_section(
    stage: str,
    title: str,
    reports: dict[str, ExperimentReportIR],
) -> ExperimentSectionIR:
    sources: dict[str, Any] = {}
    source_paths: list[str] = []
    for label in sorted(reports):
        section = reports[label].sections_for_stage(stage)[0]  # type: ignore[arg-type]
        sources[label] = {
            "status": section.status,
            "payload": section.payload,
            "unavailable_reason": section.unavailable_reason,
        }
        source_paths.extend(f"sources.{label}.{path}" for path in section.source_paths)
    return ExperimentSectionIR(
        section_id=f"experiment.{stage}",
        stage=stage,  # type: ignore[arg-type]
        title=title,
        status="available",
        payload={"sources": sources},
        source_paths=tuple(source_paths),
    )


def _comparison_measurement_section(
    ordered: tuple[tuple[str, ResultIR], ...],
    baseline_label: str,
    baseline: ResultIR,
) -> ExperimentSectionIR:
    sources = {
        label: {
            "shots": result.shots,
            "counts": dict(sorted(result.counts.items())),
            "probabilities": (
                None
                if result.probabilities is None
                else dict(sorted(result.probabilities.items()))
            ),
        }
        for label, result in ordered
    }
    comparisons = {
        label: _measurement_delta(baseline, result)
        for label, result in ordered[1:]
    }
    return ExperimentSectionIR(
        section_id="experiment.measure",
        stage="measure",
        title="Measurement comparison",
        status="available",
        payload={
            "baseline_label": baseline_label,
            "sources": sources,
            "comparisons": comparisons,
        },
        source_paths=tuple(
            path
            for label, _ in ordered
            for path in (
                f"sources.{label}.shots",
                f"sources.{label}.counts",
                f"sources.{label}.probabilities",
            )
        ),
    )


def _measurement_delta(baseline: ResultIR, candidate: ResultIR) -> dict[str, Any]:
    probability_delta = None
    total_variation = None
    if baseline.probabilities is not None and candidate.probabilities is not None:
        outcomes = sorted(set(baseline.probabilities) | set(candidate.probabilities))
        probability_delta = {
            outcome: candidate.probabilities.get(outcome, 0.0)
            - baseline.probabilities.get(outcome, 0.0)
            for outcome in outcomes
        }
        total_variation = 0.5 * sum(abs(value) for value in probability_delta.values())
    return {
        "count_delta": {
            outcome: candidate.counts.get(outcome, 0) - baseline.counts.get(outcome, 0)
            for outcome in sorted(set(baseline.counts) | set(candidate.counts))
        },
        "probability_delta": probability_delta,
        "total_variation_distance": total_variation,
    }


def _comparison_analysis_section(
    ordered: tuple[tuple[str, ResultIR], ...],
    baseline_label: str,
    baseline: ResultIR,
) -> ExperimentSectionIR:
    if not any(result.observables for _, result in ordered):
        return unavailable_experiment_section(
            section_id="experiment.analyze",
            stage="analyze",
            title="Analysis comparison",
            reason="Comparison sources do not contain observables.",
        )
    sources = {
        label: canonicalize(result.observables) for label, result in ordered
    }
    comparisons = {
        label: _observable_delta(baseline.observables, result.observables)
        for label, result in ordered[1:]
    }
    return ExperimentSectionIR(
        section_id="experiment.analyze",
        stage="analyze",
        title="Analysis comparison",
        status="available",
        payload={
            "baseline_label": baseline_label,
            "sources": sources,
            "comparisons": comparisons,
        },
        source_paths=tuple(
            f"sources.{label}.observables" for label, _ in ordered
        ),
    )


def _observable_delta(
    baseline: Mapping[str, Any],
    candidate: Mapping[str, Any],
) -> dict[str, Any]:
    left_numeric = _flatten_numeric_observables(baseline)
    right_numeric = _flatten_numeric_observables(candidate)
    numeric = {
        path: right_numeric[path] - left_numeric[path]
        for path in sorted(set(left_numeric) & set(right_numeric))
    }
    changed = {
        key: canonicalize(baseline.get(key)) != canonicalize(candidate.get(key))
        for key in sorted(set(baseline) | set(candidate))
        if key not in left_numeric or key not in right_numeric
    }
    return {"numeric_delta": numeric, "changed": changed}


def _flatten_numeric_observables(
    values: Mapping[str, Any],
    *,
    prefix: str = "",
) -> dict[str, float]:
    flattened: dict[str, float] = {}
    for key in sorted(values):
        path = f"{prefix}.{key}" if prefix else str(key)
        value = values[key]
        if isinstance(value, Mapping):
            flattened.update(_flatten_numeric_observables(value, prefix=path))
        elif isinstance(value, Real) and not isinstance(value, bool):
            flattened[path] = float(value)
    return flattened
