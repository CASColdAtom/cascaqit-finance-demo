"""Typed contracts shared by standard experiment visualization profiles."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Literal

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.native_ir.base import IRMixin
from cascaqit.native_ir.models import SCHEMA_VERSION

__all__ = [
    "EXPERIMENT_STAGE_ORDER",
    "ExperimentProfile",
    "ExperimentReportIR",
    "ExperimentSectionIR",
    "ExperimentSectionStatus",
    "ExperimentStage",
    "unavailable_experiment_section",
]

ExperimentProfile = Literal[
    "digital",
    "analog",
    "hybrid",
    "sweep",
    "comparison",
    "batch",
    "algorithm",
    "problem",
]
ExperimentStage = Literal[
    "design",
    "validate",
    "plan",
    "execute",
    "state",
    "measure",
    "analyze",
]
ExperimentSectionStatus = Literal[
    "available",
    "unavailable",
    "warning",
    "error",
]

EXPERIMENT_STAGE_ORDER: tuple[ExperimentStage, ...] = (
    "design",
    "validate",
    "plan",
    "execute",
    "state",
    "measure",
    "analyze",
)

_EXPERIMENT_PROFILES = frozenset(
    (
        "digital",
        "analog",
        "hybrid",
        "sweep",
        "comparison",
        "batch",
        "algorithm",
        "problem",
    )
)
_SECTION_STATUSES = frozenset(("available", "unavailable", "warning", "error"))
_STAGE_INDEX = {stage: index for index, stage in enumerate(EXPERIMENT_STAGE_ORDER)}


@dataclass(frozen=True)
class ExperimentSectionIR(IRMixin):
    """One ordered, source-grounded view of an experiment lifecycle stage."""

    section_id: str
    stage: ExperimentStage
    title: str
    status: ExperimentSectionStatus
    payload: dict[str, Any] = field(default_factory=dict)
    source_paths: tuple[str, ...] = ()
    unavailable_reason: str | None = None
    diagnostics: tuple[DiagnosticsIR, ...] = ()
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        _require_non_empty_string(self.section_id, field_name="section_id")
        _require_non_empty_string(self.title, field_name="title")
        if self.stage not in _STAGE_INDEX:
            raise ValueError(f"Unsupported experiment stage: {self.stage!r}.")
        if self.status not in _SECTION_STATUSES:
            raise ValueError(f"Unsupported experiment section status: {self.status!r}.")
        _validate_unique_strings(self.source_paths, field_name="source_paths")

        # These invariants prevent presentation code from treating guessed or empty
        # data as an observed part of the experiment.
        if self.status == "unavailable":
            _require_non_empty_string(
                self.unavailable_reason,
                field_name="unavailable_reason",
            )
            if self.payload:
                raise ValueError("Unavailable section cannot contain payload data.")
        else:
            if self.unavailable_reason is not None:
                raise ValueError(
                    "Only an unavailable section may define unavailable_reason."
                )
            if not self.payload and not self.diagnostics:
                raise ValueError(
                    "An available section requires payload data or diagnostics."
                )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ExperimentSectionIR:
        """Build one lifecycle section from a JSON-compatible dictionary."""
        return cls(
            section_id=str(data["section_id"]),
            stage=data["stage"],
            title=str(data["title"]),
            status=data["status"],
            payload=dict(data.get("payload", {})),
            source_paths=tuple(str(path) for path in data.get("source_paths", ())),
            unavailable_reason=data.get("unavailable_reason"),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(item) for item in data.get("diagnostics", ())
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> ExperimentSectionIR:
        """Build one lifecycle section from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("ExperimentSectionIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class ExperimentReportIR(IRMixin):
    """Profile-aware standard report data before any HTML is rendered."""

    report_id: str
    title: str
    profile: ExperimentProfile
    source_kind: str
    source_ids: tuple[str, ...]
    source_hashes: dict[str, str]
    sections: tuple[ExperimentSectionIR, ...]
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        _require_non_empty_string(self.report_id, field_name="report_id")
        _require_non_empty_string(self.title, field_name="title")
        _require_non_empty_string(self.source_kind, field_name="source_kind")
        if self.profile not in _EXPERIMENT_PROFILES:
            raise ValueError(f"Unsupported experiment profile: {self.profile!r}.")
        _validate_unique_strings(self.source_ids, field_name="source_ids")
        if not self.source_ids:
            raise ValueError("source_ids must contain at least one source id.")
        if set(self.source_hashes) != set(self.source_ids):
            raise ValueError("source_hashes must contain exactly the source_ids.")
        for source_id, source_hash in self.source_hashes.items():
            _require_non_empty_string(
                source_hash,
                field_name=f"source_hashes[{source_id}]",
            )
        if not self.sections:
            raise ValueError("sections must contain the experiment lifecycle.")

        section_ids = tuple(section.section_id for section in self.sections)
        if len(set(section_ids)) != len(section_ids):
            raise ValueError("section_id values must be unique within a report.")

        stage_indices = tuple(_STAGE_INDEX[section.stage] for section in self.sections)
        if stage_indices != tuple(sorted(stage_indices)):
            raise ValueError("sections must follow the standard lifecycle order.")
        present_stages = {section.stage for section in self.sections}
        missing = tuple(
            stage for stage in EXPERIMENT_STAGE_ORDER if stage not in present_stages
        )
        if missing:
            raise ValueError(
                "Report must represent every lifecycle stage; "
                f"missing lifecycle stage(s): {', '.join(missing)}."
            )

    @property
    def has_errors(self) -> bool:
        """Return whether any section or nested diagnostic reports an error."""
        return any(
            section.status == "error"
            or any(diagnostic.severity == "error" for diagnostic in section.diagnostics)
            for section in self.sections
        )

    @property
    def available_stages(self) -> tuple[ExperimentStage, ...]:
        """Return lifecycle stages backed by available, warning, or error facts."""
        available = {
            section.stage
            for section in self.sections
            if section.status != "unavailable"
        }
        return tuple(stage for stage in EXPERIMENT_STAGE_ORDER if stage in available)

    def section(self, section_id: str) -> ExperimentSectionIR:
        """Return one section by stable id."""
        for section in self.sections:
            if section.section_id == section_id:
                return section
        raise KeyError(section_id)

    def sections_for_stage(
        self,
        stage: ExperimentStage,
    ) -> tuple[ExperimentSectionIR, ...]:
        """Return all sections for one lifecycle stage in report order."""
        if stage not in _STAGE_INDEX:
            raise ValueError(f"Unsupported experiment stage: {stage!r}.")
        return tuple(section for section in self.sections if section.stage == stage)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ExperimentReportIR:
        """Build a standard experiment report from a dictionary."""
        return cls(
            report_id=str(data["report_id"]),
            title=str(data["title"]),
            profile=data["profile"],
            source_kind=str(data["source_kind"]),
            source_ids=tuple(str(item) for item in data.get("source_ids", ())),
            source_hashes={
                str(key): str(value)
                for key, value in data.get("source_hashes", {}).items()
            },
            sections=tuple(
                ExperimentSectionIR.from_dict(item)
                for item in data.get("sections", ())
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> ExperimentReportIR:
        """Build a standard experiment report from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("ExperimentReportIR JSON must contain an object.")
        return cls.from_dict(data)


def unavailable_experiment_section(
    *,
    section_id: str,
    stage: ExperimentStage,
    title: str,
    reason: str,
    diagnostics: tuple[DiagnosticsIR, ...] = (),
    metadata: dict[str, Any] | None = None,
) -> ExperimentSectionIR:
    """Build an explicit missing-fact section without inventing plot data."""
    return ExperimentSectionIR(
        section_id=section_id,
        stage=stage,
        title=title,
        status="unavailable",
        unavailable_reason=reason,
        diagnostics=diagnostics,
        metadata={} if metadata is None else dict(metadata),
    )


def _require_non_empty_string(value: object, *, field_name: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field_name} must be a non-empty string.")


def _validate_unique_strings(values: object, *, field_name: str) -> None:
    if not isinstance(values, tuple):
        raise TypeError(f"{field_name} must be a tuple.")
    if any(not isinstance(value, str) or not value.strip() for value in values):
        raise ValueError(f"{field_name} must contain non-empty strings.")
    if len(set(values)) != len(values):
        raise ValueError(f"{field_name} values must be unique.")
