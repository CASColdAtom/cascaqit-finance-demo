"""Build standard experiment lifecycle sections from a native ResultIR."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any, Literal, cast

from cascaqit.native_ir.base import canonicalize
from cascaqit.results import ResultIR, result_references_from_result
from cascaqit.visualization.experiment import (
    ExperimentProfile,
    ExperimentReportIR,
    ExperimentSectionIR,
    unavailable_experiment_section,
)
from cascaqit.visualization.program_report import (
    ProgramContextSource,
    ProgramReportContext,
    build_program_report_context,
)

__all__ = ["build_result_experiment_report"]

SingleResultProfile = Literal["digital", "analog", "hybrid"]
_SINGLE_RESULT_PROFILES = frozenset(("digital", "analog", "hybrid"))


def build_result_experiment_report(
    result: ResultIR,
    *,
    profile: ExperimentProfile | None = None,
    program: ProgramContextSource | None = None,
    report_id: str | None = None,
    title: str | None = None,
) -> ExperimentReportIR:
    """Derive a complete lifecycle report without mutating or rerunning a result."""
    if not isinstance(result, ResultIR):
        raise TypeError("result must be ResultIR.")
    result_before = result.to_dict()
    program_context = (
        None if program is None else build_program_report_context(program)
    )
    resolved_profile = _resolve_profile(result, profile, program_context)
    if (
        program_context is not None
        and result.program_hash != program_context.execution_hash
    ):
        raise ValueError(
            "Program context program hash does not match ResultIR.program_hash."
        )
    sections = (
        (
            unavailable_experiment_section(
                section_id="experiment.design",
                stage="design",
                title="Experiment design",
                reason="No program context was supplied.",
            )
            if program_context is None
            else program_context.section
        ),
        _validation_section(result),
        _plan_section(result, program_context),
        _execution_section(result),
        _state_section(result),
        _measurement_section(result),
        _analysis_section(result),
    )
    report = ExperimentReportIR(
        report_id=report_id or f"experiment_report.{result.result_id}",
        title=title or f"{resolved_profile.title()} experiment result",
        profile=resolved_profile,
        source_kind=(
            "ResultIR"
            if program_context is None
            else f"ResultIR+{program_context.source_kind}"
        ),
        source_ids=(
            (result.result_id,)
            if program_context is None
            else (result.result_id, program_context.program_id)
        ),
        source_hashes={
            result.result_id: result.stable_hash(),
            **(
                {}
                if program_context is None
                else {program_context.program_id: program_context.source_hash}
            ),
        },
        sections=sections,
        metadata={
            "derived_view": True,
            "program_context_supplied": program_context is not None,
            "execution_program_hash": (
                None if program_context is None else program_context.execution_hash
            ),
            "source_result_mutated": False,
            "artifact_bytes_read": False,
            "backend_called": False,
            "network_accessed": False,
        },
    )
    if result.to_dict() != result_before:
        raise ValueError("Experiment report construction mutated source ResultIR.")
    return report


def _resolve_profile(
    result: ResultIR,
    requested: ExperimentProfile | None,
    program_context: ProgramReportContext | None,
) -> SingleResultProfile:
    if requested is not None and requested not in _SINGLE_RESULT_PROFILES:
        raise ValueError(
            "A single ResultIR supports only digital, analog, or hybrid profile."
        )
    if program_context is not None:
        if requested is not None and requested != program_context.profile:
            raise ValueError(
                f"Requested profile {requested!r} does not match program profile "
                f"{program_context.profile!r}."
            )
        return program_context.profile
    detected = _detect_profile(result)
    if requested is None:
        if detected is None:
            raise ValueError(
                "ResultIR metadata cannot determine an experiment profile; "
                "pass profile='digital', 'analog', or 'hybrid'."
            )
        return detected
    if detected is not None and requested != detected:
        raise ValueError(
            f"Requested profile {requested!r} does not match ResultIR profile "
            f"{detected!r}."
        )
    return cast(SingleResultProfile, requested)


def _detect_profile(result: ResultIR) -> SingleResultProfile | None:
    metadata = result.metadata
    candidates: list[str] = []
    simulator = _optional_mapping(metadata, "simulator")
    algorithm = _optional_mapping(metadata, "simulation_algorithm")
    plan = _optional_mapping(metadata, "simulation_plan")
    if simulator is not None:
        candidates.append(str(simulator.get("program_kind", "")))
    if algorithm is not None:
        candidates.append(str(algorithm.get("program_type", "")))
    if plan is not None:
        candidates.append(str(plan.get("program_kind", "")))
    transitions = result.state_transitions()
    references = result_references_from_result(result)
    if len(transitions) > 1 or (
        references is not None
        and (references.plan_hash is not None or references.bundle_hash is not None)
    ):
        candidates.append("hybrid")
    if "measurement_projection" in metadata:
        _optional_mapping(metadata, "measurement_projection")
        candidates.append("digital")
    if "target_snapshot" in metadata:
        _optional_mapping(metadata, "target_snapshot")
        candidates.append("analog")

    valid = {
        candidate for candidate in candidates if candidate in _SINGLE_RESULT_PROFILES
    }
    if len(valid) > 1:
        raise ValueError(
            "ResultIR metadata contains conflicting experiment profiles: "
            f"{', '.join(sorted(valid))}."
        )
    if not valid:
        return None
    return cast(SingleResultProfile, next(iter(valid)))


def _validation_section(result: ResultIR) -> ExperimentSectionIR:
    diagnostics = result.diagnostics
    control_evidence = _control_report_evidence(result)
    control_diagnostics = [
        diagnostic
        for item in control_evidence
        for diagnostic in item.get("diagnostics", ())
        if isinstance(diagnostic, Mapping)
    ]
    by_stage = _counts_by(item.stage for item in diagnostics)
    by_severity = _counts_by(item.severity for item in diagnostics)
    status: Literal["available", "warning", "error"] = "available"
    if any(item.severity == "error" for item in diagnostics):
        status = "error"
    elif any(item.severity == "warning" for item in diagnostics):
        status = "warning"
    return ExperimentSectionIR(
        section_id="experiment.validate",
        stage="validate",
        title="Validation and diagnostics",
        status=status,
        payload={
            "diagnostic_count": len(diagnostics),
            "codes": [item.code for item in diagnostics],
            "by_stage": by_stage,
            "by_severity": by_severity,
            "has_errors": status == "error",
            "has_warnings": status == "warning" or "warning" in by_severity,
            "control_constraint_diagnostics": control_diagnostics,
        },
        source_paths=(
            "ResultIR.diagnostics",
            *(
                ("ResultIR.metadata.control_report_evidence",)
                if control_evidence
                else ()
            ),
        ),
        diagnostics=diagnostics,
    )


def _plan_section(
    result: ResultIR,
    program_context: ProgramReportContext | None,
) -> ExperimentSectionIR:
    plan = _optional_mapping(result.metadata, "simulation_plan")
    algorithm = _optional_mapping(result.metadata, "simulation_algorithm")
    estimate = _optional_mapping(result.metadata, "simulation_resource_estimate")
    context_plan = None if program_context is None else program_context.plan_payload
    control_evidence = _control_report_evidence(result)
    if plan is None and algorithm is None and estimate is None and context_plan is None:
        return unavailable_experiment_section(
            section_id="experiment.plan",
            stage="plan",
            title="Plan and compile",
            reason="ResultIR does not contain simulation or compile plan facts.",
        )
    payload: dict[str, Any] = {}
    source_paths: list[str] = []
    if plan is not None:
        payload["simulation_plan"] = _canonical_mapping(plan)
        if "program_kind" in plan:
            payload["program_kind"] = plan["program_kind"]
        source_paths.append("ResultIR.metadata.simulation_plan")
    if algorithm is not None:
        payload["algorithm"] = _canonical_mapping(algorithm)
        source_paths.append("ResultIR.metadata.simulation_algorithm")
    if estimate is not None:
        payload["resource_estimate"] = _canonical_mapping(estimate)
        source_paths.append("ResultIR.metadata.simulation_resource_estimate")
    if context_plan is not None:
        assert program_context is not None
        payload.update(context_plan)
        source_paths.extend(program_context.plan_source_paths)
    if control_evidence:
        payload["control_schedules"] = control_evidence
        source_paths.append("ResultIR.metadata.control_report_evidence")
    return ExperimentSectionIR(
        section_id="experiment.plan",
        stage="plan",
        title="Plan and compile",
        status="available",
        payload=payload,
        source_paths=tuple(source_paths),
    )


def _execution_section(result: ResultIR) -> ExperimentSectionIR:
    simulator = _optional_mapping(result.metadata, "simulator")
    trace = _optional_mapping(result.metadata, "run_trace")
    execution_config = result.execution_config()
    solver_evidence = result.solver_evidence()
    resource_usage = result.resource_usage()
    payload: dict[str, Any] = {
        "target_id": result.target_id,
        "seed": result.metadata.get("seed"),
        "simulator": None if simulator is None else _canonical_mapping(simulator),
        "execution_config": (
            None if execution_config is None else execution_config.to_dict()
        ),
        "solver_evidence": (
            None if solver_evidence is None else solver_evidence.to_dict()
        ),
        "resource_usage": None if resource_usage is None else resource_usage.to_dict(),
        "run_trace": None if trace is None else _canonical_mapping(trace),
        "truthfulness": result.metadata.get("simulation_truthfulness"),
    }
    source_paths = ["ResultIR.target_id"]
    for key in (
        "seed",
        "simulator",
        "simulation_execution_config",
        "simulation_solver_evidence",
        "simulation_resource_usage",
        "run_trace",
        "simulation_truthfulness",
    ):
        if key in result.metadata:
            source_paths.append(f"ResultIR.metadata.{key}")
    return ExperimentSectionIR(
        section_id="experiment.execute",
        stage="execute",
        title="Execution",
        status="available",
        payload=payload,
        source_paths=tuple(source_paths),
    )


def _state_section(result: ResultIR) -> ExperimentSectionIR:
    state = _optional_mapping(result.metadata, "simulation_state")
    transitions = result.state_transitions()
    references = result_references_from_result(result)
    noise = _optional_mapping(result.metadata, "noise_report")
    has_state_hash = "state_hash" in result.metadata
    if (
        state is None
        and not transitions
        and noise is None
        and not has_state_hash
        and references is None
    ):
        return unavailable_experiment_section(
            section_id="experiment.state",
            stage="state",
            title="State and noise",
            reason="ResultIR does not contain state or noise summaries.",
        )
    dynamic_consumers, dynamic_source_paths = _dynamic_addressing_consumers(
        result,
    )
    phase_consumers, phase_source_paths = _site_phase_pattern_consumers(result)
    register_snapshots = _result_register_snapshots(result)
    payload = {
        "state": None if state is None else _canonical_mapping(state),
        "state_hash": result.metadata.get("state_hash"),
        "state_transitions": [item.to_dict() for item in transitions],
        "references": None if references is None else references.to_dict(),
        "noise_report": None if noise is None else _canonical_mapping(noise),
        "truthfulness": result.metadata.get("simulation_truthfulness"),
    }
    if dynamic_consumers:
        payload["dynamic_addressing_consumers"] = dynamic_consumers
    if phase_consumers:
        payload["site_phase_pattern_consumers"] = phase_consumers
    if register_snapshots:
        payload["register_snapshots"] = register_snapshots
    source_paths = [
        f"ResultIR.metadata.{key}"
        for key in (
            "simulation_state",
            "state_hash",
            "state_transitions",
            "references",
            "noise_report",
            "simulation_truthfulness",
        )
        if key in result.metadata
    ]
    source_paths.extend(dynamic_source_paths)
    source_paths.extend(phase_source_paths)
    if register_snapshots:
        source_paths.append(
            "ResultIR.metadata.register_snapshots"
            if "register_snapshots" in result.metadata
            else "ResultIR.metadata.register_snapshot"
        )
    return ExperimentSectionIR(
        section_id="experiment.state",
        stage="state",
        title="State and noise",
        status="available",
        payload=payload,
        source_paths=tuple(dict.fromkeys(source_paths)),
    )


def _dynamic_addressing_consumers(
    result: ResultIR,
) -> tuple[list[dict[str, Any]], list[str]]:
    """Flatten runtime addressing evidence from canonical transitions."""
    candidates: list[tuple[Mapping[str, Any], str, str, str]] = []

    for index, transition in enumerate(result.state_transitions()):
        evidence = transition.metadata.get("site_addressing")
        if isinstance(evidence, Mapping):
            candidates.append(
                (
                    evidence,
                    transition.block_id,
                    transition.program_kind,
                    (
                        "ResultIR.metadata.state_transitions"
                        f"[{index}].metadata.site_addressing"
                    ),
                )
            )

    metadata = result.metadata
    state = metadata.get("simulation_state")
    if isinstance(state, Mapping):
        provenance = state.get("provenance")
        if isinstance(provenance, Mapping):
            provenance_metadata = provenance.get("metadata")
            if isinstance(provenance_metadata, Mapping):
                evidence = provenance_metadata.get("site_addressing")
                if isinstance(evidence, Mapping):
                    candidates.append(
                        (
                            evidence,
                            "standalone",
                            "analog",
                            "ResultIR.metadata.simulation_state.provenance.metadata.site_addressing",
                        )
                    )

    rows: list[dict[str, Any]] = []
    source_paths: list[str] = []
    seen: set[tuple[str, str, str, int, str]] = set()
    for evidence, block_id, block_type, source_path in candidates:
        consumer = str(evidence.get("consumer", "unknown"))
        program_hash = str(evidence.get("program_hash", ""))
        terms = evidence.get("terms")
        if not isinstance(terms, Sequence) or isinstance(terms, (str, bytes)):
            continue
        for term in terms:
            if not isinstance(term, Mapping):
                continue
            control_kind = str(term.get("control_kind", "unknown"))
            term_index = int(term.get("term_index", 0))
            addressing_hash = str(term.get("addressing_hash", ""))
            identity = (
                block_id,
                consumer,
                control_kind,
                term_index,
                addressing_hash,
            )
            if identity in seen:
                continue
            seen.add(identity)
            rows.append(
                {
                    "block_id": block_id,
                    "block_type": block_type,
                    "consumer": consumer,
                    "program_hash": program_hash,
                    "control_kind": control_kind,
                    "term_index": term_index,
                    "source_kind": str(term.get("source_kind", "")),
                    "frame_count": int(term.get("frame_count", 0)),
                    "duration": term.get("duration"),
                    "time_unit": str(term.get("time_unit", "")),
                    "interpolation": str(term.get("interpolation", "")),
                    "addressing_hash": addressing_hash,
                    "source_path": source_path,
                }
            )
            source_paths.append(source_path)
    return rows, list(dict.fromkeys(source_paths))


def _site_phase_pattern_consumers(
    result: ResultIR,
) -> tuple[list[dict[str, Any]], list[str]]:
    """Flatten runtime phase-pattern evidence from canonical transitions."""
    candidates: list[tuple[Mapping[str, Any], str, str, str]] = []
    for index, transition in enumerate(result.state_transitions()):
        evidence = transition.metadata.get("site_phase_pattern")
        if isinstance(evidence, Mapping):
            candidates.append(
                (
                    evidence,
                    transition.block_id,
                    transition.program_kind,
                    (
                        "ResultIR.metadata.state_transitions"
                        f"[{index}].metadata.site_phase_pattern"
                    ),
                )
            )
    state = result.metadata.get("simulation_state")
    if isinstance(state, Mapping):
        provenance = state.get("provenance")
        if isinstance(provenance, Mapping):
            provenance_metadata = provenance.get("metadata")
            if isinstance(provenance_metadata, Mapping):
                evidence = provenance_metadata.get("site_phase_pattern")
                if isinstance(evidence, Mapping):
                    candidates.append(
                        (
                            evidence,
                            "standalone",
                            "analog",
                            "ResultIR.metadata.simulation_state.provenance.metadata.site_phase_pattern",
                        )
                    )

    rows: list[dict[str, Any]] = []
    source_paths: list[str] = []
    seen: set[tuple[str, str, int, str]] = set()
    for evidence, block_id, block_type, source_path in candidates:
        terms = evidence.get("terms")
        if not isinstance(terms, Sequence) or isinstance(terms, (str, bytes)):
            continue
        for term in terms:
            if not isinstance(term, Mapping):
                continue
            term_index = int(term.get("term_index", 0))
            pattern_hash = str(term.get("phase_pattern_hash", ""))
            identity = (
                block_id,
                str(evidence.get("consumer", "unknown")),
                term_index,
                pattern_hash,
            )
            if identity in seen:
                continue
            seen.add(identity)
            rows.append(
                {
                    "block_id": block_id,
                    "block_type": block_type,
                    "consumer": str(evidence.get("consumer", "unknown")),
                    "program_hash": str(evidence.get("program_hash", "")),
                    "semantics": str(evidence.get("semantics", "")),
                    "term_index": term_index,
                    "site_ids": list(term.get("site_ids", ())),
                    "offsets": list(term.get("offsets", ())),
                    "unit": str(term.get("unit", "")),
                    "phase_pattern_hash": pattern_hash,
                    "source_path": source_path,
                }
            )
            source_paths.append(source_path)
    return rows, list(dict.fromkeys(source_paths))


def _result_register_snapshots(result: ResultIR) -> list[dict[str, Any]]:
    value = result.metadata.get("register_snapshots")
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        return [dict(item) for item in value if isinstance(item, Mapping)]
    single = result.metadata.get("register_snapshot")
    return [dict(single)] if isinstance(single, Mapping) else []


def _control_report_evidence(result: ResultIR) -> list[dict[str, Any]]:
    value = result.metadata.get("control_report_evidence")
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        return []
    return [dict(item) for item in value if isinstance(item, Mapping)]


def _measurement_section(result: ResultIR) -> ExperimentSectionIR:
    measurement = _optional_mapping(result.metadata, "measurement")
    projection = _optional_mapping(result.metadata, "measurement_projection")
    ordering = _optional_mapping(result.metadata, "bitstring_ordering")
    preview_limit = 16
    payload = {
        "shots": result.shots,
        "counts": dict(sorted(result.counts.items())),
        "probabilities": (
            None
            if result.probabilities is None
            else dict(sorted(result.probabilities.items()))
        ),
        "probabilities_available": result.probabilities is not None,
        "sample_summary": {
            "count": len(result.samples),
            "unique_count": len(set(result.samples)),
            "preview": list(result.samples[:preview_limit]),
            "preview_limit": preview_limit,
            "truncated": len(result.samples) > preview_limit,
        },
        "bit_ordering": canonicalize(result.bit_ordering),
        "occupation_encoding": result.occupation_encoding.to_dict(),
        "measurement": None if measurement is None else _canonical_mapping(measurement),
        "measurement_projection": (
            None if projection is None else _canonical_mapping(projection)
        ),
        "bitstring_ordering": (
            None if ordering is None else _canonical_mapping(ordering)
        ),
    }
    source_paths = [
        "ResultIR.shots",
        "ResultIR.counts",
        "ResultIR.samples",
        "ResultIR.bit_ordering",
        "ResultIR.occupation_encoding",
    ]
    if result.probabilities is not None:
        source_paths.append("ResultIR.probabilities")
    for key in ("measurement", "measurement_projection", "bitstring_ordering"):
        if key in result.metadata:
            source_paths.append(f"ResultIR.metadata.{key}")
    return ExperimentSectionIR(
        section_id="experiment.measure",
        stage="measure",
        title="Measurement",
        status="available",
        payload=payload,
        source_paths=tuple(source_paths),
    )


def _analysis_section(result: ResultIR) -> ExperimentSectionIR:
    if not result.observables and result.observable_batch is None:
        return unavailable_experiment_section(
            section_id="experiment.analyze",
            stage="analyze",
            title="Analysis",
            reason="ResultIR does not contain observables.",
        )
    payload: dict[str, Any] = {
        "observables": canonicalize(result.observables),
    }
    source_paths = ["ResultIR.observables"]
    if result.observable_batch is not None:
        payload["observable_batch"] = result.observable_batch.to_dict()
        source_paths.append("ResultIR.observable_batch")
    return ExperimentSectionIR(
        section_id="experiment.analyze",
        stage="analyze",
        title="Analysis",
        status="available",
        payload=payload,
        source_paths=tuple(source_paths),
    )


def _optional_mapping(
    metadata: Mapping[str, Any],
    key: str,
) -> dict[str, Any] | None:
    if key not in metadata:
        return None
    value = metadata[key]
    if not isinstance(value, Mapping):
        raise TypeError(f"ResultIR.metadata.{key} must be a mapping.")
    return {str(item_key): item_value for item_key, item_value in value.items()}


def _canonical_mapping(value: Mapping[str, Any]) -> dict[str, Any]:
    normalized = canonicalize(value)
    if not isinstance(normalized, dict):
        raise TypeError("Expected a JSON-compatible mapping.")
    return normalized


def _counts_by(values: Any) -> dict[str, int]:
    counts: dict[str, int] = {}
    for value in values:
        key = str(value)
        counts[key] = counts.get(key, 0) + 1
    return {key: counts[key] for key in sorted(counts)}
