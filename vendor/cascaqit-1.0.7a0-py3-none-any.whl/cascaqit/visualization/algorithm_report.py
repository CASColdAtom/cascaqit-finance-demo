"""Build the standard Algorithm Profile from one VariationalResult."""

from __future__ import annotations

from typing import Any

from cascaqit.algorithms import VariationalResult
from cascaqit.visualization.experiment import ExperimentReportIR, ExperimentSectionIR
from cascaqit.visualization.gradient_report import build_gradient_report_payload
from cascaqit.visualization.noisy_optimization_report import (
    build_objective_execution_payload,
    build_objective_request_payload,
    build_objective_summary_payload,
)

__all__ = ["build_algorithm_experiment_report"]


def build_algorithm_experiment_report(
    result: VariationalResult,
    *,
    report_id: str | None = None,
    title: str | None = None,
) -> ExperimentReportIR:
    """Derive seven lifecycle views without executing or mutating the workflow."""
    if not isinstance(result, VariationalResult):
        raise TypeError("result must be VariationalResult.")
    before = result.to_dict()
    best = result.best_evaluation
    final = result.final_result
    baseline_energy = (
        None
        if result.baseline is None or result.baseline.status != "available"
        else result.baseline.objective_value
    )
    gradient = build_gradient_report_payload(
        result.gradients,
        termination=result.termination,
    )
    objective_request = build_objective_request_payload(best.execution_evidence)
    objective_execution = build_objective_execution_payload(
        best.execution_evidence
    )
    sections = (
        ExperimentSectionIR(
            section_id="algorithm.design",
            stage="design",
            title="Algorithm and Hamiltonian design",
            status="available",
            payload={
                "algorithm_kind": result.algorithm_kind,
                "algorithm_run_id": result.algorithm_run_id,
                "problem_id": result.problem_id,
                "problem_hash": result.problem_hash,
                "hamiltonian": {
                    "hamiltonian_id": result.hamiltonian.hamiltonian_id,
                    "hash": result.hamiltonian.stable_hash(),
                    "constant": result.hamiltonian.constant,
                    "logical_order": list(result.hamiltonian.logical_order),
                    "term_count": len(result.hamiltonian.terms),
                    "terms": [
                        {
                            "term_id": term.term_id,
                            "coefficient": term.coefficient,
                            "observable_name": term.observable.name,
                            "targets": list(term.observable.targets),
                            "bases": [basis.value for basis in term.observable.bases],
                        }
                        for term in result.hamiltonian.terms
                    ],
                },
                "ansatz": result.ansatz.to_dict(),
            },
            source_paths=(
                "VariationalResult.hamiltonian",
                "VariationalResult.ansatz",
                "VariationalResult.problem_id",
                "VariationalResult.problem_hash",
            ),
        ),
        ExperimentSectionIR(
            section_id="algorithm.validate",
            stage="validate",
            title="Workflow consistency",
            status="available",
            payload={
                "diagnostic_count": 0,
                "by_severity": {},
                "by_stage": {},
                "checks": [
                    {
                        "name": "Hamiltonian continuity",
                        "status": "passed",
                        "value": result.hamiltonian.stable_hash(),
                    },
                    {
                        "name": "Parameter layout",
                        "status": "passed",
                        "value": list(result.ansatz.parameter_names),
                    },
                    {
                        "name": "Objective history",
                        "status": "passed",
                        "value": len(result.evaluations),
                    },
                    {
                        "name": "SciPy nfev alignment",
                        "status": "passed",
                        "value": result.termination.nfev,
                    },
                    {
                        "name": "SciPy njev alignment",
                        "status": "passed",
                        "value": result.termination.njev,
                    },
                    {
                        "name": "Backend execution cost",
                        "status": "passed",
                        "value": result.termination.backend_execution_count,
                    },
                    {
                        "name": "Final sampling evidence",
                        "status": "passed" if final is not None else "unavailable",
                        "value": None if final is None else final.result_id,
                    },
                ],
            },
            source_paths=(
                "VariationalResult.evaluations",
                "VariationalResult.termination.nfev",
                "VariationalResult.final_result",
            ),
        ),
        ExperimentSectionIR(
            section_id="algorithm.plan",
            stage="plan",
            title="Ansatz and optimizer plan",
            status="available",
            payload={
                "ansatz": result.ansatz.to_dict(),
                "ansatz_id": result.ansatz.ansatz_id,
                "ansatz_kind": result.ansatz.ansatz_kind,
                "layers": result.ansatz.layers,
                "logical_order": list(result.ansatz.logical_order),
                "parameter_names": list(result.ansatz.parameter_names),
                "optimizer": result.optimizer.to_dict(),
                "initial_parameters": list(
                    result.metadata.get("initial_parameters", ())
                ),
                "resolved_seed": result.metadata.get("resolved_seed"),
                "start_count": len(result.optimization_starts),
                "selected_start_index": result.selected_start_index,
                "gradient_plan": None if gradient is None else gradient["plan"],
                "objective_request": objective_request,
            },
            source_paths=(
                "VariationalResult.ansatz",
                "VariationalResult.optimizer",
                "VariationalResult.metadata.initial_parameters",
                "VariationalResult.metadata.resolved_seed",
                "VariationalResult.best_evaluation.execution_evidence.noise_model",
                "VariationalResult.best_evaluation.execution_evidence.requested_options",
            ),
        ),
        ExperimentSectionIR(
            section_id="algorithm.execute",
            stage="execute",
            title="Optimization execution",
            status="available" if result.termination.success else "warning",
            payload={
                "termination": result.termination.to_dict(),
                "evaluation_count": len(result.evaluations),
                "backend_result_count": len(
                    {evaluation.result_id for evaluation in result.evaluations}
                ),
                "total_wall_time_seconds": sum(
                    evaluation.wall_time_seconds for evaluation in result.evaluations
                ),
                "best_evaluation_index": result.best_evaluation_index,
                "selected_start_index": result.selected_start_index,
                "starts": [item.to_dict() for item in result.optimization_starts],
                "baseline_energy": baseline_energy,
                "gradient": gradient,
                "evaluations": [
                    {
                        "evaluation_index": evaluation.evaluation_index,
                        "evaluation_id": evaluation.evaluation_id,
                        "energy": evaluation.energy,
                        "parameters": {
                            name: evaluation.parameter_bind.values[name]
                            for name in result.ansatz.parameter_names
                        },
                        "parameter_bind_hash": (
                            evaluation.parameter_bind.parameter_bind_hash
                        ),
                        "result_id": evaluation.result_id,
                        "result_hash": evaluation.result_hash,
                        "observable_source_hash": (
                            evaluation.observable_batch.source_hash
                        ),
                        "wall_time_seconds": evaluation.wall_time_seconds,
                        "cache_hit": evaluation.cache_hit,
                        "execution": build_objective_summary_payload(
                            evaluation.execution_evidence
                        ),
                    }
                    for evaluation in result.evaluations
                ],
                "objective_execution": objective_execution,
            },
            source_paths=(
                "VariationalResult.optimizer",
                "VariationalResult.evaluations",
                "VariationalResult.best_evaluation_index",
                "VariationalResult.optimization_starts",
                "VariationalResult.selected_start_index",
                "VariationalResult.termination",
                "VariationalResult.gradients",
                "VariationalResult.evaluations.execution_evidence",
            ),
        ),
        ExperimentSectionIR(
            section_id="algorithm.state",
            stage="state",
            title="Objective state evidence",
            status="available",
            payload={
                "best_evaluation_id": best.evaluation_id,
                "estimator": best.metadata.get("estimator"),
                "source_kind": best.observable_batch.source_kind.value,
                "observable_set_hash": best.observable_batch.observable_set_hash,
                "observable_source_hash": best.observable_batch.source_hash,
                "hamiltonian_hash": best.hamiltonian_hash,
                "constant": best.constant,
                "contributions": [
                    contribution.to_dict() for contribution in best.contributions
                ],
                "state_bytes_read": False,
                "observable_standard_errors": dict(
                    best.execution_evidence.observable_standard_errors
                ),
            },
            source_paths=(
                "VariationalResult.best_evaluation.observable_batch",
                "VariationalResult.best_evaluation.contributions",
                "VariationalResult.best_evaluation.hamiltonian_hash",
                "VariationalResult.best_evaluation.execution_evidence.observable_standard_errors",
            ),
        ),
        _measurement_section(result),
        ExperimentSectionIR(
            section_id="algorithm.analyze",
            stage="analyze",
            title="Candidate and baseline analysis",
            status="available",
            payload={
                "best_evaluation_index": result.best_evaluation_index,
                "best_evaluation_id": best.evaluation_id,
                "best_energy": best.energy,
                "best_parameters": {
                    name: best.parameter_bind.values[name]
                    for name in result.ansatz.parameter_names
                },
                "most_probable_candidate": _optional_dict(
                    result.most_probable_candidate
                ),
                "best_observed_candidate": _optional_dict(
                    result.best_observed_candidate
                ),
                "candidate_status": result.metadata.get(
                    "candidate_status",
                    "unavailable",
                ),
                "baseline": _optional_dict(result.baseline),
                "candidate_gap": _plain_mapping(
                    result.metadata.get("candidate_gap", {})
                ),
                "final_sampling": _plain_mapping(
                    result.metadata.get("final_sampling", {})
                ),
                "optimality_claim": result.optimality_claim,
            },
            source_paths=(
                "VariationalResult.best_evaluation",
                "VariationalResult.most_probable_candidate",
                "VariationalResult.best_observed_candidate",
                "VariationalResult.baseline",
                "VariationalResult.metadata.candidate_gap",
                "VariationalResult.metadata.final_sampling",
            ),
        ),
    )
    source_ids, source_hashes = _source_identity(result)
    report = ExperimentReportIR(
        report_id=report_id or f"algorithm_report.{result.algorithm_run_id}",
        title=title or f"{result.algorithm_kind.upper()} workflow result",
        profile="algorithm",
        source_kind="VariationalResult",
        source_ids=source_ids,
        source_hashes=source_hashes,
        sections=sections,
        metadata={
            "derived_view": True,
            "source_variational_result_mutated": False,
            "objective_recomputed": False,
            "state_bytes_read": False,
            "artifact_bytes_read": False,
            "backend_called": False,
            "network_accessed": False,
        },
    )
    if result.to_dict() != before:
        raise ValueError("Algorithm report construction mutated VariationalResult.")
    return report


def _measurement_section(result: VariationalResult) -> ExperimentSectionIR:
    final = result.final_result
    if final is None:
        return ExperimentSectionIR(
            section_id="algorithm.measure",
            stage="measure",
            title="Final sampling",
            status="unavailable",
            unavailable_reason="No final sampling ResultIR is available.",
        )
    return ExperimentSectionIR(
        section_id="algorithm.measure",
        stage="measure",
        title="Final sampling",
        status="available",
        payload={
            "result_id": final.result_id,
            "result_hash": final.stable_hash(),
            "program_hash": final.program_hash,
            "shots": final.shots,
            "counts": dict(final.counts),
            "probabilities": (
                None if final.probabilities is None else dict(final.probabilities)
            ),
            "sample_count": len(final.samples),
            "bit_ordering": dict(final.bit_ordering),
            "most_probable_candidate": _optional_dict(result.most_probable_candidate),
            "best_observed_candidate": _optional_dict(result.best_observed_candidate),
            "candidate_status": result.metadata.get(
                "candidate_status",
                "unavailable",
            ),
            "sampling_execution": _plain_mapping(
                result.metadata.get("final_sampling", {})
            ),
        },
        source_paths=(
            "VariationalResult.final_result.counts",
            "VariationalResult.final_result.shots",
            "VariationalResult.final_result.bit_ordering",
            "VariationalResult.most_probable_candidate",
            "VariationalResult.best_observed_candidate",
            "VariationalResult.metadata.final_sampling",
        ),
    )


def _source_identity(
    result: VariationalResult,
) -> tuple[tuple[str, ...], dict[str, str]]:
    pairs = [
        (result.algorithm_run_id, result.stable_hash()),
        (result.hamiltonian.hamiltonian_id, result.hamiltonian.stable_hash()),
        (result.best_evaluation.evaluation_id, result.best_evaluation.stable_hash()),
    ]
    if result.final_result is not None:
        pairs.append((result.final_result.result_id, result.final_result.stable_hash()))
    source_ids = tuple(source_id for source_id, _ in pairs)
    if len(source_ids) != len(set(source_ids)):
        raise ValueError("Algorithm report source identities must be unique.")
    return source_ids, dict(pairs)


def _optional_dict(value: Any) -> dict[str, Any] | None:
    if value is None:
        return None
    data = value.to_dict()
    if not isinstance(data, dict):
        raise TypeError("Algorithm report source must serialize to an object.")
    return data


def _plain_mapping(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict) and not hasattr(value, "items"):
        return {}
    return {str(key): _plain_value(item) for key, item in value.items()}


def _plain_value(value: Any) -> Any:
    if hasattr(value, "items"):
        return _plain_mapping(value)
    if isinstance(value, (tuple, list)):
        return [_plain_value(item) for item in value]
    return value
