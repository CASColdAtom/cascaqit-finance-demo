"""Visualization renderer contracts and required-runtime Bokeh adapters."""

from __future__ import annotations

import importlib
import json
import math
from dataclasses import dataclass, field
from html import escape
from typing import Any, Literal, Union, cast

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.native_ir.base import IRMixin
from cascaqit.native_ir.models import SCHEMA_VERSION
from cascaqit.visualization.models import (
    CountsHistogramVisualizationIR,
    HybridTimelineVisualizationIR,
    PulseTimelineVisualizationIR,
    RegisterVisualizationIR,
    VisualizationKind,
)

__all__ = [
    "VisualizationArtifactIR",
    "render_counts_histogram_bokeh",
    "render_counts_histogram_html",
    "render_hybrid_timeline_bokeh",
    "render_hybrid_timeline_html",
    "render_pulse_timeline_bokeh",
    "render_pulse_timeline_html",
    "render_register_bokeh",
    "render_register_svg",
    "render_visualization",
]

VisualizationArtifactKind = Literal[
    "svg",
    "html",
    "bokeh_json_item",
    "diagnostic",
]
VisualizationRenderer = Literal[
    "svg_fallback",
    "html_fallback",
    "bokeh",
]
VisualizationIR = Union[
    RegisterVisualizationIR,
    PulseTimelineVisualizationIR,
    CountsHistogramVisualizationIR,
    HybridTimelineVisualizationIR,
]


@dataclass(frozen=True)
class VisualizationArtifactIR(IRMixin):
    """A rendered visualization artifact derived from Visualization IR."""

    artifact_id: str
    artifact_kind: VisualizationArtifactKind
    renderer: VisualizationRenderer
    visualization_kind: VisualizationKind
    source_visualization_id: str
    title: str
    content_type: str
    content: str | dict[str, Any]
    interactive: bool
    deterministic: bool
    schema_version: str = SCHEMA_VERSION
    diagnostics: tuple[DiagnosticsIR, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> VisualizationArtifactIR:
        """Build a visualization artifact from a JSON-compatible dictionary."""
        return cls(
            artifact_id=str(data["artifact_id"]),
            artifact_kind=data["artifact_kind"],
            renderer=data["renderer"],
            visualization_kind=data["visualization_kind"],
            source_visualization_id=str(data["source_visualization_id"]),
            title=str(data["title"]),
            content_type=str(data["content_type"]),
            content=data["content"],
            interactive=bool(data["interactive"]),
            deterministic=bool(data["deterministic"]),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            diagnostics=tuple(
                DiagnosticsIR.from_dict(diagnostic)
                for diagnostic in data.get("diagnostics", ())
            ),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> VisualizationArtifactIR:
        """Build a visualization artifact from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("VisualizationArtifactIR JSON must contain an object.")
        return cls.from_dict(data)


def render_visualization(
    visualization: VisualizationIR,
    *,
    backend: Literal["fallback", "bokeh"] = "fallback",
) -> VisualizationArtifactIR:
    """Render visualization IR with a deterministic fallback or Bokeh backend."""
    if backend == "fallback":
        if isinstance(visualization, RegisterVisualizationIR):
            return render_register_svg(visualization)
        if isinstance(visualization, PulseTimelineVisualizationIR):
            return render_pulse_timeline_html(visualization)
        if isinstance(visualization, CountsHistogramVisualizationIR):
            return render_counts_histogram_html(visualization)
        if isinstance(visualization, HybridTimelineVisualizationIR):
            return render_hybrid_timeline_html(visualization)
    elif backend == "bokeh":
        if isinstance(visualization, RegisterVisualizationIR):
            return render_register_bokeh(visualization)
        if isinstance(visualization, PulseTimelineVisualizationIR):
            return render_pulse_timeline_bokeh(visualization)
        if isinstance(visualization, CountsHistogramVisualizationIR):
            return render_counts_histogram_bokeh(visualization)
        if isinstance(visualization, HybridTimelineVisualizationIR):
            return render_hybrid_timeline_bokeh(visualization)
    else:
        raise ValueError("backend must be 'fallback' or 'bokeh'.")
    raise TypeError("Unsupported visualization IR object.")


def render_register_svg(
    visualization: RegisterVisualizationIR,
    *,
    width: int = 480,
    height: int = 360,
) -> VisualizationArtifactIR:
    """Render register visualization IR into deterministic standalone SVG."""
    sites = tuple(visualization.sites)
    padding = 40.0
    plot_width = max(float(width) - 2 * padding, 1.0)
    plot_height = max(float(height) - 2 * padding, 1.0)
    xs = [float(site["x"]) for site in sites] or [0.0]
    ys = [float(site["y"]) for site in sites] or [0.0]
    x_min, x_max = _extent(xs)
    y_min, y_max = _extent(ys)

    parts = [
        (
            f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" '
            f'height="{height}" viewBox="0 0 {width} {height}" '
            f'role="img" aria-label="{_xml(visualization.spec.title)}">'
        ),
        '<rect width="100%" height="100%" fill="#ffffff"/>',
        (
            f'<text x="{width / 2:.1f}" y="24" text-anchor="middle" '
            'font-family="Arial, sans-serif" font-size="16" '
            f'fill="#202124">{_xml(visualization.spec.title)}</text>'
        ),
        (
            f'<rect x="{padding:.1f}" y="{padding:.1f}" '
            f'width="{plot_width:.1f}" height="{plot_height:.1f}" '
            'fill="#f8fafc" stroke="#cbd5e1" stroke-width="1"/>'
        ),
    ]
    status_colors = {
        "filled": ("#2563eb", "#1e3a8a"),
        "vacant": ("#ffffff", "#64748b"),
        "defect": ("#dc2626", "#7f1d1d"),
        "loading_failed": ("#d97706", "#78350f"),
    }
    for site in sites:
        px = padding + (float(site["x"]) - x_min) / (x_max - x_min) * plot_width
        py = height - padding - (
            (float(site["y"]) - y_min) / (y_max - y_min) * plot_height
        )
        status = str(site.get("status", "filled"))
        fill, stroke = status_colors.get(status, ("#ffffff", "#64748b"))
        label = str(site.get("atom_id") or site["site_id"])
        parts.extend(
            [
                (
                    f'<circle cx="{px:.3f}" cy="{py:.3f}" r="8" '
                    f'fill="{fill}" stroke="{stroke}" stroke-width="2" '
                    f'data-site-id="{_xml(str(site["site_id"]))}" '
                    f'data-status="{_xml(status)}" '
                    f'data-atom-id="{_xml(str(site["atom_id"]))}">'
                    f"<title>{_xml(_register_hover(site, visualization))}</title>"
                    "</circle>"
                ),
                (
                    f'<text x="{px:.3f}" y="{py + 23:.3f}" '
                    'text-anchor="middle" font-family="Arial, sans-serif" '
                    f'font-size="11" fill="#334155">{_xml(label)}</text>'
                ),
            ]
        )
    parts.append("</svg>")
    return _artifact(
        visualization,
        artifact_kind="svg",
        renderer="svg_fallback",
        content_type="image/svg+xml",
        content="\n".join(parts),
        interactive=False,
        deterministic=True,
        metadata={
            "width": width,
            "height": height,
            "site_count": len(sites),
            "fallback": "deterministic_svg",
        },
    )


def render_pulse_timeline_html(
    visualization: PulseTimelineVisualizationIR,
) -> VisualizationArtifactIR:
    """Render pulse timeline visualization IR into deterministic HTML."""
    rows = [
        (
            "<tr>"
            f"<td>{_html(str(channel['channel_id']))}</td>"
            f"<td>{_html(str(channel.get('source_path', '')))}</td>"
            f"<td>{_html(_timeline_summary(channel))}</td>"
            "</tr>"
        )
        for channel in visualization.channels
    ]
    content = _html_table(
        title=visualization.spec.title,
        class_name="cascaqit-pulse-timeline",
        headers=("Channel", "Source", "Segments / points"),
        rows=rows,
    )
    return _artifact(
        visualization,
        artifact_kind="html",
        renderer="html_fallback",
        content_type="text/html",
        content=content,
        interactive=False,
        deterministic=True,
        metadata={
            "channel_count": len(visualization.channels),
            "fallback": "deterministic_html",
        },
    )


def render_counts_histogram_html(
    visualization: CountsHistogramVisualizationIR,
) -> VisualizationArtifactIR:
    """Render counts histogram visualization IR into deterministic HTML."""
    rows = [
        (
            "<tr>"
            f"<td>{_html(str(bar['bitstring']))}</td>"
            f"<td>{int(bar['count'])}</td>"
            f"<td>{float(bar['probability']):.12g}</td>"
            "</tr>"
        )
        for bar in visualization.bars
    ]
    content = _html_table(
        title=visualization.spec.title,
        class_name="cascaqit-counts-histogram",
        headers=("Bitstring", "Count", "Probability"),
        rows=rows,
    )
    return _artifact(
        visualization,
        artifact_kind="html",
        renderer="html_fallback",
        content_type="text/html",
        content=content,
        interactive=False,
        deterministic=True,
        metadata={
            "bar_count": len(visualization.bars),
            "shots": visualization.shots,
            "fallback": "deterministic_html",
        },
    )


def render_hybrid_timeline_html(
    visualization: HybridTimelineVisualizationIR,
) -> VisualizationArtifactIR:
    """Render a hybrid timeline visualization into deterministic HTML."""
    block_rows = [
        (
            "<tr>"
            f"<td>{int(block['order'])}</td>"
            f"<td>{_html(str(block['block_id']))}</td>"
            f"<td>{_html(str(block['block_type']))}</td>"
            f"<td>{_html(_optional_number(block.get('start_time')))}</td>"
            f"<td>{_html(_optional_number(block.get('duration')))}</td>"
            f"<td>{_html(str(block.get('time_unit', visualization.time_unit)))}</td>"
            f"<td>{_html(str(block['input_state_kind']))}</td>"
            f"<td>{_html(str(block['output_state_kind']))}</td>"
            f"<td>{_html(_mapping_summary(block.get('mapping', {})))}</td>"
            "</tr>"
        )
        for block in visualization.blocks
    ]
    boundary_rows = [
        (
            "<tr"
            f' data-status="{_html(str(boundary["status"]))}"'
            ' data-unsupported-handoff="'
            f'{str(boundary["unsupported_handoff"]).lower()}">'
            f"<td>{_html(str(boundary['boundary_id']))}</td>"
            f"<td>{_html(str(boundary['left_block_id']))}"
            f" -> {_html(str(boundary['right_block_id']))}</td>"
            f"<td>{_html(str(boundary['status']))}</td>"
            f"<td>{_html(str(boundary['code']))}</td>"
            f"<td>{_html(str(boundary['message']))}</td>"
            "</tr>"
        )
        for boundary in visualization.boundaries
    ]
    mapping_rows = [
        (
            "<tr>"
            f"<td>{_html(logical)}</td>"
            f"<td>{_html(physical)}</td>"
            "</tr>"
        )
        for logical, physical in sorted(visualization.mapping.items())
    ]
    content = (
        '<section class="cascaqit-hybrid-timeline" '
        'data-renderer="html_fallback" data-plan-only="true" '
        'data-fact-source="false" data-full-daqc-state-handoff="false">'
        f"<h2>{_html(visualization.spec.title)}</h2>"
        "<h3>Blocks</h3>"
        "<table><thead><tr>"
        "<th>Order</th><th>Block</th><th>Type</th><th>Start</th>"
        "<th>Duration</th><th>Unit</th><th>Input state</th>"
        "<th>Output state</th><th>Mapping</th>"
        f"</tr></thead><tbody>{''.join(block_rows)}</tbody></table>"
        "<h3>Boundary diagnostics</h3>"
        "<table><thead><tr>"
        "<th>Boundary</th><th>Blocks</th><th>Status</th><th>Code</th>"
        "<th>Message</th>"
        f"</tr></thead><tbody>{''.join(boundary_rows)}</tbody></table>"
        "<h3>Mapping</h3>"
        "<table><thead><tr><th>Logical</th><th>Physical</th></tr></thead>"
        f"<tbody>{''.join(mapping_rows)}</tbody></table>"
        "</section>"
    )
    return _artifact(
        visualization,
        artifact_kind="html",
        renderer="html_fallback",
        content_type="text/html",
        content=content,
        interactive=False,
        deterministic=True,
        metadata={
            "block_count": len(visualization.blocks),
            "boundary_count": len(visualization.boundaries),
            "unsupported_handoff_count": visualization.boundary_summary[
                "unsupported_handoff_count"
            ],
            "fallback": "deterministic_html",
            "plan_only": True,
            "fact_source": False,
            "full_daqc_state_handoff": False,
        },
    )


def render_register_bokeh(
    visualization: RegisterVisualizationIR,
) -> VisualizationArtifactIR:
    """Render register visualization IR into a Bokeh JSON item when available."""
    bokeh = _load_bokeh()
    if bokeh is None:
        return _missing_bokeh_artifact(visualization)
    plotting, models, embed = bokeh
    source = models.ColumnDataSource(
        {
            "x": [float(site["x"]) for site in visualization.sites],
            "y": [float(site["y"]) for site in visualization.sites],
            "site_id": [str(site["site_id"]) for site in visualization.sites],
            "atom_id": [str(site["atom_id"]) for site in visualization.sites],
            "filled": [bool(site["filled"]) for site in visualization.sites],
            "status": [
                str(site.get("status", "filled")) for site in visualization.sites
            ],
            "is_target": [
                bool(site.get("is_target", True)) for site in visualization.sites
            ],
            "color": [
                {
                    "filled": "#2563eb",
                    "vacant": "#ffffff",
                    "defect": "#dc2626",
                    "loading_failed": "#d97706",
                }.get(str(site.get("status", "filled")), "#94a3b8")
                for site in visualization.sites
            ],
        }
    )
    plot = plotting.figure(
        title=visualization.spec.title,
        x_axis_label=f"x ({visualization.coordinate_unit})",
        y_axis_label=f"y ({visualization.coordinate_unit})",
        width=520,
        height=380,
        match_aspect=True,
        aspect_scale=1.0,
        sizing_mode="stretch_width",
        tools="pan,wheel_zoom,box_zoom,reset,save,tap",
    )
    plot.scatter(
        x="x",
        y="y",
        size=14,
        fill_color="color",
        line_color="#334155",
        source=source,
    )
    plot.add_tools(
        models.HoverTool(
            tooltips=[
                ("site", "@site_id"),
                ("atom", "@atom_id"),
                ("filled", "@filled"),
                ("status", "@status"),
                ("target", "@is_target"),
                ("x", "@x"),
                ("y", "@y"),
            ]
        )
    )
    return _bokeh_artifact(visualization, embed.json_item(plot))


def render_pulse_timeline_bokeh(
    visualization: PulseTimelineVisualizationIR,
) -> VisualizationArtifactIR:
    """Render all pulse channels on one time axis with unit-aware y-axes."""
    bokeh = _load_bokeh()
    if bokeh is None:
        return _missing_bokeh_artifact(visualization)
    plotting, models, embed = bokeh

    prepared_channels: list[dict[str, Any]] = []
    for channel in visualization.channels:
        channel_id = str(channel["channel_id"])
        value_unit = str(channel.get("value_unit", "value"))
        times, values = _pulse_channel_samples(channel)
        if not times:
            continue
        prepared_channels.append(
            {
                "channel_id": channel_id,
                "value_unit": value_unit,
                "source_path": str(channel.get("source_path", "")),
                "times": times,
                "values": values,
                "uses_phase_axis": (
                    value_unit.strip().lower() == "rad"
                    or "phase" in channel_id.lower()
                ),
            }
        )

    phase_values = [
        value
        for channel in prepared_channels
        if channel["uses_phase_axis"]
        for value in cast(list[float], channel["values"])
        if math.isfinite(value)
    ]
    extra_y_ranges = {}
    if phase_values:
        phase_min, phase_max = min(phase_values), max(phase_values)
        phase_padding = max((phase_max - phase_min) * 0.1, 0.1)
        extra_y_ranges["phase"] = models.Range1d(
            start=phase_min - phase_padding,
            end=phase_max + phase_padding,
        )

    plot = plotting.figure(
        title="Control waveforms",
        x_axis_label=f"time ({visualization.time_unit})",
        y_axis_label="Rabi / Detuning (rad/us)",
        height=400,
        sizing_mode="stretch_width",
        tools="pan,wheel_zoom,box_zoom,reset,save",
        toolbar_location="right",
        extra_y_ranges=extra_y_ranges,
    )
    if phase_values:
        plot.add_layout(
            models.LinearAxis(y_range_name="phase", axis_label="Phase (rad)"),
            "right",
        )

    colors = ("#087f8c", "#b35900", "#4772b3", "#8a4f9e", "#22805f")
    for index, channel in enumerate(prepared_channels):
        channel_id = str(channel["channel_id"])
        times = cast(list[float], channel["times"])
        values = cast(list[float], channel["values"])
        source = models.ColumnDataSource(
            {
                "time": times,
                "value": values,
                "channel": [channel_id for _ in times],
                "unit": [str(channel["value_unit"]) for _ in times],
                "source_path": [str(channel["source_path"]) for _ in times],
            }
        )
        glyph_options: dict[str, Any] = {
            "x": "time",
            "y": "value",
            "source": source,
            "color": colors[index % len(colors)],
            "legend_label": channel_id.replace("_", " ").title(),
        }
        if channel["uses_phase_axis"]:
            glyph_options["y_range_name"] = "phase"
        plot.line(**glyph_options, line_width=2)
        plot.scatter(**glyph_options, size=7)

    plot.add_tools(
        models.HoverTool(
            tooltips=[
                ("channel", "@channel"),
                ("time", "@time"),
                ("value", "@value @unit"),
                ("source", "@source_path"),
            ]
        )
    )
    plot.legend.location = "top_left"
    plot.legend.click_policy = "hide"
    return _bokeh_artifact(visualization, embed.json_item(plot))


def _pulse_channel_samples(channel: dict[str, Any]) -> tuple[list[float], list[float]]:
    """Return one plottable series for sampled or segmented controls."""
    points = tuple(channel.get("points", ()))
    if points:
        return (
            [float(point["time"]) for point in points],
            [
                0.0 if point.get("value") is None else float(point["value"])
                for point in points
            ],
        )

    times: list[float] = []
    values: list[float] = []
    for segment in tuple(channel.get("segments", ())):
        start = float(segment.get("start", 0.0))
        stop = float(segment.get("stop", start))
        value = float(segment.get("value", 0.0))
        if times and start != times[-1]:
            # Break non-contiguous segments instead of drawing a false bridge.
            times.append(math.nan)
            values.append(math.nan)
        times.extend((start, stop))
        values.extend((value, value))
    return times, values


def render_counts_histogram_bokeh(
    visualization: CountsHistogramVisualizationIR,
) -> VisualizationArtifactIR:
    """Render counts histogram visualization IR into a Bokeh JSON item."""
    bokeh = _load_bokeh()
    if bokeh is None:
        return _missing_bokeh_artifact(visualization)
    plotting, models, embed = bokeh
    bitstrings = [str(bar["bitstring"]) for bar in visualization.bars]
    source = models.ColumnDataSource(
        {
            "bitstring": bitstrings,
            "count": [int(bar["count"]) for bar in visualization.bars],
            "probability": [
                float(bar["probability"]) for bar in visualization.bars
            ],
        }
    )
    plot = plotting.figure(
        title=visualization.spec.title,
        x_range=bitstrings,
        x_axis_label="bitstring",
        y_axis_label="count",
        width=640,
        height=360,
        sizing_mode="stretch_width",
        tools="pan,wheel_zoom,box_zoom,reset,save,tap",
    )
    plot.vbar(x="bitstring", top="count", width=0.8, source=source)
    plot.add_tools(
        models.HoverTool(
            tooltips=[
                ("bitstring", "@bitstring"),
                ("count", "@count"),
                ("probability", "@probability"),
            ]
        )
    )
    return _bokeh_artifact(visualization, embed.json_item(plot))


def render_hybrid_timeline_bokeh(
    visualization: HybridTimelineVisualizationIR,
) -> VisualizationArtifactIR:
    """Render a hybrid timeline visualization into a Bokeh JSON item."""
    bokeh = _load_bokeh()
    if bokeh is None:
        return _missing_bokeh_artifact(visualization)
    plotting, models, embed = bokeh
    block_ids = [str(block["block_id"]) for block in visualization.blocks]
    source = models.ColumnDataSource(
        {
            "block_id": block_ids,
            "block_type": [
                str(block["block_type"]) for block in visualization.blocks
            ],
            "order": [int(block["order"]) for block in visualization.blocks],
            "start": [
                _numeric_or_order(block.get("start_time"), index)
                for index, block in enumerate(visualization.blocks)
            ],
            "duration": [
                _numeric_or_default(block.get("duration"), 1.0)
                for block in visualization.blocks
            ],
            "end": [
                _numeric_or_order(block.get("start_time"), index)
                + _numeric_or_default(block.get("duration"), 1.0)
                for index, block in enumerate(visualization.blocks)
            ],
            "input_state": [
                str(block["input_state_kind"]) for block in visualization.blocks
            ],
            "output_state": [
                str(block["output_state_kind"]) for block in visualization.blocks
            ],
        }
    )
    plot = plotting.figure(
        title=visualization.spec.title,
        x_axis_label=f"time ({visualization.time_unit})",
        y_range=list(reversed(block_ids)),
        width=760,
        height=max(280, 70 + 36 * len(block_ids)),
        tools="pan,wheel_zoom,box_zoom,reset,save,tap",
    )
    plot.hbar(
        y="block_id",
        left="start",
        right="end",
        height=0.6,
        source=source,
    )
    plot.add_tools(
        models.HoverTool(
            tooltips=[
                ("block", "@block_id"),
                ("type", "@block_type"),
                ("start", "@start"),
                ("duration", "@duration"),
                ("input", "@input_state"),
                ("output", "@output_state"),
            ]
        )
    )
    return _bokeh_artifact(visualization, embed.json_item(plot))


def _artifact(
    visualization: VisualizationIR,
    *,
    artifact_kind: VisualizationArtifactKind,
    renderer: VisualizationRenderer,
    content_type: str,
    content: str | dict[str, Any],
    interactive: bool,
    deterministic: bool,
    diagnostics: tuple[DiagnosticsIR, ...] = (),
    metadata: dict[str, Any] | None = None,
) -> VisualizationArtifactIR:
    return VisualizationArtifactIR(
        artifact_id=(
            f"artifact.{visualization.spec.visualization_id}.{renderer}"
        ),
        artifact_kind=artifact_kind,
        renderer=renderer,
        visualization_kind=visualization.spec.visualization_kind,
        source_visualization_id=visualization.spec.visualization_id,
        title=visualization.spec.title,
        content_type=content_type,
        content=content,
        interactive=interactive,
        deterministic=deterministic,
        diagnostics=diagnostics,
        metadata={
            "source_kind": visualization.spec.source_kind,
            "source_id": visualization.spec.source_id,
            "source_hash": visualization.spec.source_hash,
            **(metadata or {}),
        },
    )


def _bokeh_artifact(
    visualization: VisualizationIR,
    json_item: dict[str, Any],
) -> VisualizationArtifactIR:
    return _artifact(
        visualization,
        artifact_kind="bokeh_json_item",
        renderer="bokeh",
        content_type="application/vnd.bokeh.item+json",
        content=json_item,
        interactive=True,
        deterministic=False,
        metadata={"backend": "bokeh", "output": "json_item"},
    )


def _missing_bokeh_artifact(
    visualization: VisualizationIR,
) -> VisualizationArtifactIR:
    diagnostic = DiagnosticsIR(
        diagnostic_id=f"visualization.bokeh.unavailable.{visualization.spec.visualization_id}",
        stage="serialization",
        severity="error",
        code="VISUALIZATION_BOKEH_UNAVAILABLE",
        message="Bokeh visualization backend is unavailable.",
        suggestion=(
            "Reinstall CASCAQit so its required bokeh>=3.4,<4 runtime "
            "dependency is present."
        ),
        metadata={"required_dependency": True, "dependency": "bokeh"},
    )
    return _artifact(
        visualization,
        artifact_kind="diagnostic",
        renderer="bokeh",
        content_type="text/html",
        content=(
            '<div class="cascaqit-visualization-diagnostic" '
            'data-backend="bokeh" data-status="unavailable">'
            "Bokeh visualization backend is unavailable."
            "</div>"
        ),
        interactive=False,
        deterministic=True,
        diagnostics=(diagnostic,),
        metadata={"backend": "bokeh", "available": False},
    )


def _load_bokeh() -> tuple[Any, Any, Any] | None:
    try:
        plotting = importlib.import_module("bokeh.plotting")
        models = importlib.import_module("bokeh.models")
        embed = importlib.import_module("bokeh.embed")
    except ImportError:
        return None
    return plotting, models, embed


def _html_table(
    *,
    title: str,
    class_name: str,
    headers: tuple[str, ...],
    rows: list[str],
) -> str:
    header = "".join(f"<th>{_html(value)}</th>" for value in headers)
    body = "".join(rows)
    return (
        f'<section class="{class_name}" data-renderer="html_fallback">'
        f"<h2>{_html(title)}</h2>"
        "<table>"
        f"<thead><tr>{header}</tr></thead>"
        f"<tbody>{body}</tbody>"
        "</table>"
        "</section>"
    )


def _timeline_summary(channel: dict[str, Any]) -> str:
    if "segments" in channel:
        segments = tuple(channel.get("segments", ()))
        return ", ".join(
            (
                f"{segment.get('segment_id', 'segment')}: "
                f"{segment.get('start', 0.0)}-{segment.get('stop', 0.0)}"
            )
            for segment in segments
        ) or "0 segments"
    points = tuple(channel.get("points", ()))
    return f"{len(points)} points, duration={channel.get('duration', 'unknown')}"


def _mapping_summary(value: Any) -> str:
    if not isinstance(value, dict) or not value:
        return ""
    return ", ".join(
        f"{key}->{value[key]}" for key in sorted(str(key) for key in value)
    )


def _optional_number(value: Any) -> str:
    if value is None:
        return "unspecified"
    if isinstance(value, (int, float)):
        return f"{float(value):.12g}"
    return str(value)


def _numeric_or_order(value: Any, order: int) -> float:
    if isinstance(value, (int, float)):
        return float(value)
    return float(order)


def _numeric_or_default(value: Any, default: float) -> float:
    if isinstance(value, (int, float)):
        return float(value)
    return default


def _register_hover(
    site: dict[str, Any],
    visualization: RegisterVisualizationIR,
) -> str:
    return (
        f"site={site['site_id']}; atom={site['atom_id']}; "
        f"x={site['x']} {visualization.coordinate_unit}; "
        f"y={site['y']} {visualization.coordinate_unit}; "
        f"filled={site['filled']}"
    )


def _extent(values: list[float]) -> tuple[float, float]:
    low = min(values)
    high = max(values)
    if low == high:
        return low - 0.5, high + 0.5
    padding = (high - low) * 0.05
    return low - padding, high + padding


def _html(value: str) -> str:
    return escape(value, quote=True)


def _xml(value: str) -> str:
    return escape(value, quote=True)
