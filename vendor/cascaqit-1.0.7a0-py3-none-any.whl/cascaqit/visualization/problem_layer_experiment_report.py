"""Standard report for one completed automatic Problem layer experiment."""

from __future__ import annotations

from dataclasses import replace
from typing import Any

from cascaqit.problems.layer_experiment import (
    PROBLEM_LAYER_OBJECTIVE_TOLERANCE,
    ProblemLayerExperimentResult,
)
from cascaqit.visualization.experiment import ExperimentReportIR
from cascaqit.visualization.problem_comparison_report import (
    build_problem_comparison_experiment_report,
)

__all__ = ["build_problem_layer_experiment_report"]


def build_problem_layer_experiment_report(
    source: ProblemLayerExperimentResult,
    *,
    title: str = "Problem layer experiment",
) -> ExperimentReportIR:
    """Render stored layer executions without performing new optimization."""
    if not isinstance(source, ProblemLayerExperimentResult):
        raise TypeError("source must be ProblemLayerExperimentResult.")
    snapshot = source.to_dict()
    report = build_problem_comparison_experiment_report(
        source.comparison_sources(),
        report_id=(
            "problem_report.layer-experiment."
            f"{source.experiment_id.rsplit('.', 1)[-1]}"
        ),
        title=title,
    )
    layer_payload = _layer_experiment_payload(source)
    sections = []
    for section in report.sections:
        payload = dict(section.payload)
        if section.section_id == "problem-comparison.validate":
            payload["layer_experiment"] = {
                key: layer_payload[key]
                for key in (
                    "max_layers",
                    "min_improvement",
                    "numeric_tolerance",
                    "patience",
                    "requested_shots",
                    "seed",
                    "selection_rule",
                )
            }
        elif section.section_id == "problem-comparison.execute":
            payload["layer_experiment"] = {
                "executed_layer_count": layer_payload["executed_layer_count"],
                "total_evaluation_count": layer_payload["total_evaluation_count"],
                "warm_start": layer_payload["warm_start"],
            }
        elif section.section_id == "problem-comparison.analyze":
            payload["layer_experiment"] = layer_payload
        sections.append(replace(section, payload=payload))
    result = replace(
        report,
        source_kind="ProblemLayerExperiment",
        sections=tuple(sections),
        metadata={
            **report.metadata,
            "experiment_id": source.experiment_id,
            "selected_layers": source.selected_layers,
            "stop_reason": source.stop_reason,
            "total_evaluation_count": source.total_evaluation_count,
            "backend_called": False,
            "optimizer_called": False,
        },
    )
    if source.to_dict() != snapshot:
        raise ValueError("Problem layer experiment report mutated its source.")
    return result


def _layer_experiment_payload(
    source: ProblemLayerExperimentResult,
) -> dict[str, Any]:
    return {
        "experiment_id": source.experiment_id,
        "max_layers": source.max_layers,
        "executed_layer_count": len(source.steps),
        "selected_layers": source.selected_layers,
        "selected_step_index": source.selected_step_index,
        "stop_reason": source.stop_reason,
        "min_improvement": source.min_improvement,
        "numeric_tolerance": PROBLEM_LAYER_OBJECTIVE_TOLERANCE,
        "patience": source.patience,
        "requested_shots": source.requested_shots,
        "seed": source.seed,
        "total_evaluation_count": source.total_evaluation_count,
        "selection_rule": source.metadata["selection_rule"],
        "warm_start": source.metadata["warm_start"],
        "optimality_claim": "not_claimed",
        "steps": [
            {
                "layers": step.layers,
                "objective_value": step.execution.objective_value,
                "improvement_from_incumbent": step.improvement_from_incumbent,
                "material_improvement": step.material_improvement,
                "incumbent_layer": step.incumbent_layer,
                "no_improvement_count": step.no_improvement_count,
                "evaluation_count": len(step.execution.parameter_history),
                "start_count": (
                    0
                    if step.execution.optimization is None
                    else len(step.execution.optimization.starts)
                ),
                "first_start_initialization": (
                    None
                    if step.execution.optimization is None
                    or not step.execution.optimization.starts
                    else step.execution.optimization.starts[0].initialization
                ),
                "execution_id": step.execution.execution_id,
            }
            for step in source.steps
        ],
    }
