"""Comparison report for completed executions of one optimization Problem."""

from __future__ import annotations

import hashlib
from collections.abc import Mapping, Sequence
from typing import Any

from cascaqit.native_ir.base import stable_json
from cascaqit.problems.execution import ProblemExecutionResult
from cascaqit.visualization.experiment import ExperimentReportIR, ExperimentSectionIR
from cascaqit.visualization.problem_report import build_problem_experiment_report

__all__ = ["build_problem_comparison_experiment_report"]


def build_problem_comparison_experiment_report(
    sources: Mapping[str, ProblemExecutionResult],
    *,
    report_id: str | None = None,
    title: str = "Problem optimization comparison",
) -> ExperimentReportIR:
    """Compare aligned Problem executions without rerunning or mutating them."""
    ordered = _validated_sources(sources)
    snapshots = {label: execution.to_dict() for label, execution in ordered}
    reports = {
        label: build_problem_experiment_report(execution)
        for label, execution in ordered
    }
    baseline = ordered[0][1]
    comparison_kind = _comparison_kind(ordered)
    comparison_title = _comparison_title(ordered, comparison_kind)
    summaries = [_summary(label, execution) for label, execution in ordered]
    routes = [_route(label, execution) for label, execution in ordered]
    modes = sorted({execution.mode for _, execution in ordered})
    algorithms = sorted({execution.algorithm for _, execution in ordered})
    sections = (
        ExperimentSectionIR(
            section_id="problem-comparison.design",
            stage="design",
            title="Shared Problem design",
            status="available",
            payload={
                "problem": baseline.context.analysis.canonical_problem.to_dict(),
                "logical_hamiltonian": (
                    baseline.context.analysis.logical_hamiltonian.to_dict()
                ),
                "penalty_analysis": (
                    None
                    if baseline.context.analysis.penalty_analysis is None
                    else baseline.context.analysis.penalty_analysis.to_dict()
                ),
                "comparison_kind": comparison_kind,
                "routes": routes,
                "source_count": len(ordered),
            },
            source_paths=tuple(
                f"sources.{label}.context.analysis" for label, _ in ordered
            ),
        ),
        _validation_section(
            ordered,
            comparison_kind=comparison_kind,
            modes=modes,
            algorithms=algorithms,
        ),
        ExperimentSectionIR(
            section_id="problem-comparison.plan",
            stage="plan",
            title="Route and compilation plans",
            status="available",
            payload={"sources": summaries},
            source_paths=tuple(
                path
                for label, _ in ordered
                for path in (
                    f"sources.{label}.compile_hash",
                    f"sources.{label}.context.parameter_schema",
                    f"sources.{label}.context.native_program",
                )
            ),
        ),
        ExperimentSectionIR(
            section_id="problem-comparison.execute",
            stage="execute",
            title="Optimization executions",
            status="available",
            payload={
                "sources": {
                    label: {
                        "execution_id": execution.execution_id,
                        "mode": execution.mode,
                        "algorithm": execution.algorithm,
                        "optimization": (
                            None
                            if execution.optimization is None
                            else execution.optimization.to_dict()
                        ),
                        "evaluation_count": len(execution.parameter_history),
                        "selected_evaluation_index": (
                            execution.selected_evaluation_index
                        ),
                    }
                    for label, execution in ordered
                }
            },
            source_paths=tuple(
                path
                for label, _ in ordered
                for path in (
                    f"sources.{label}.parameter_history",
                    f"sources.{label}.optimization",
                )
            ),
        ),
        _source_section(
            reports,
            stage="state",
            section_id="problem-comparison.state",
            title="Final state evidence",
        ),
        ExperimentSectionIR(
            section_id="problem-comparison.measure",
            stage="measure",
            title="Final sampling comparison",
            status="available",
            payload={
                "sources": {
                    label: {
                        "shots": execution.result.shots,
                        "mode": execution.mode,
                        "algorithm": execution.algorithm,
                        "probability_source": _probability_source(execution),
                        "counts": dict(sorted(execution.result.counts.items())),
                        "probabilities": (
                            None
                            if execution.result.probabilities is None
                            else dict(sorted(execution.result.probabilities.items()))
                        ),
                        "best_observed_candidate": (
                            execution.best_observed_candidate.to_dict()
                        ),
                    }
                    for label, execution in ordered
                }
            },
            source_paths=tuple(
                path
                for label, _ in ordered
                for path in (
                    f"sources.{label}.result.counts",
                    f"sources.{label}.result.probabilities",
                    f"sources.{label}.best_observed_candidate",
                )
            ),
        ),
        ExperimentSectionIR(
            section_id="problem-comparison.analyze",
            stage="analyze",
            title=comparison_title,
            status="available",
            payload={
                "series": {
                    label: [
                        {
                            **item.to_dict(),
                            "energy": item.objective_value,
                            "parameters": dict(item.parameter_bind.values),
                        }
                        for item in execution.parameter_history
                    ]
                    for label, execution in ordered
                },
                "summaries": summaries,
                "comparison_kind": comparison_kind,
                "comparison_policy": _comparison_policy(),
                "baseline": (
                    None if baseline.baseline is None else baseline.baseline.to_dict()
                ),
                "optimality_claim": "not_claimed",
            },
            source_paths=tuple(
                path
                for label, _ in ordered
                for path in (
                    f"sources.{label}.parameter_history",
                    f"sources.{label}.best_observed_candidate",
                    f"sources.{label}.baseline",
                )
            ),
        ),
    )
    source_ids = tuple(execution.execution_id for _, execution in ordered)
    source_hashes = {
        execution.execution_id: execution.execution_hash for _, execution in ordered
    }
    digest = hashlib.sha256(
        stable_json(
            {
                "labels": [label for label, _ in ordered],
                "source_hashes": source_hashes,
            }
        ).encode("utf-8")
    ).hexdigest()[:16]
    report = ExperimentReportIR(
        report_id=report_id or f"problem_report.comparison.{digest}",
        title=title,
        profile="comparison",
        source_kind="ProblemExecutionComparison",
        source_ids=source_ids,
        source_hashes=source_hashes,
        sections=sections,
        metadata={
            "source_labels": {
                label: execution.execution_id for label, execution in ordered
            },
            "problem_hash": baseline.problem_hash,
            "logical_order": list(baseline.logical_order),
            "comparison_kind": comparison_kind,
            "modes": modes,
            "algorithms": algorithms,
            "derived_view": True,
            "source_results_mutated": False,
            "artifact_bytes_read": False,
            "backend_called": False,
            "network_accessed": False,
        },
    )
    if any(execution.to_dict() != snapshots[label] for label, execution in ordered):
        raise ValueError("Problem comparison mutated a source execution.")
    return report


def _validated_sources(
    sources: Mapping[str, ProblemExecutionResult],
) -> tuple[tuple[str, ProblemExecutionResult], ...]:
    if not isinstance(sources, Mapping):
        raise TypeError(
            "sources must be a mapping of labels to ProblemExecutionResult values."
        )
    if len(sources) < 2:
        raise ValueError("Problem comparison requires at least two sources.")
    ordered: list[tuple[str, ProblemExecutionResult]] = []
    for label in sorted(sources):
        if not isinstance(label, str) or not label.strip():
            raise ValueError("Problem comparison labels must be non-empty strings.")
        execution = sources[label]
        if not isinstance(execution, ProblemExecutionResult):
            raise TypeError(
                f"Problem comparison source {label!r} must be ProblemExecutionResult."
            )
        ordered.append((label, execution))
    execution_ids = tuple(execution.execution_id for _, execution in ordered)
    if len(set(execution_ids)) != len(execution_ids):
        raise ValueError("Problem comparison execution_id values must be unique.")
    baseline = ordered[0][1]
    for label, execution in ordered[1:]:
        for field_name in ("problem_hash", "logical_order"):
            if getattr(execution, field_name) != getattr(baseline, field_name):
                raise ValueError(
                    f"Problem comparison source {label!r} has a different {field_name}."
                )
    return tuple(ordered)


def _summary(label: str, execution: ProblemExecutionResult) -> dict[str, Any]:
    selected = execution.parameter_history[execution.selected_evaluation_index]
    mapping = execution.context.analysis.mapping_plan
    feasibility = mapping.feasibility_for(execution.mode)
    usage = execution.result.resource_usage()
    execution_config = execution.result.execution_config()
    return {
        "label": label,
        "mode": execution.mode,
        "algorithm": execution.algorithm,
        "topology": execution.topology,
        "layers": _layers(execution),
        "target_id": mapping.target_id,
        "target_hash": mapping.target_hash,
        "compile_feasible": feasibility.feasible,
        "analog_term_count": len(feasibility.analog_term_ids),
        "digital_term_count": len(feasibility.digital_term_ids),
        "energy_scale": feasibility.energy_scale,
        "local_reference": feasibility.local_reference,
        "hardware_executable": feasibility.hardware_executable,
        "parameter_count": len(execution.context.parameter_schema.parameters),
        "evaluation_count": len(execution.parameter_history),
        "shots": execution.result.shots,
        "probability_source": _probability_source(execution),
        "execution_method": (
            None if execution_config is None else execution_config.method
        ),
        "wall_time_seconds": None if usage is None else usage.wall_time_seconds,
        "estimated_peak_bytes": None if usage is None else usage.estimated_peak_bytes,
        "resource_measurement_status": (
            None if usage is None else usage.measurement_status
        ),
        "compile_hash": execution.compile_hash,
        "program_hash": execution.result.program_hash,
        "objective_value": execution.objective_value,
        "minimum_objective": min(
            item.objective_value for item in execution.parameter_history
        ),
        "feasible_probability": selected.feasible_probability,
        "expected_constraint_violation_count": (
            selected.expected_constraint_violation_count
        ),
        "expected_objective_gap": selected.expected_objective_gap,
        "expected_energy_breakdown": selected.energy_breakdown.to_dict(),
        "best_observed_candidate": execution.best_observed_candidate.to_dict(),
    }


def _layers(execution: ProblemExecutionResult) -> int | None:
    if execution.algorithm == "qaa":
        return None
    for metadata in (
        execution.context.native_program.metadata,
        execution.context.parameter_schema.metadata,
    ):
        value = metadata.get("layers")
        if isinstance(value, int) and not isinstance(value, bool) and value > 0:
            return value
    if execution.algorithm == "vqe":
        # The built-in VQE schema uses axis_layer_qubit names even when older
        # execution contexts do not copy the layer count into metadata.
        layer_indices = []
        for parameter in execution.context.parameter_schema.parameters:
            parts = parameter.name.split("_")
            if (
                len(parts) == 3
                and parts[0] in {"ry", "rz"}
                and parts[1].isdigit()
            ):
                layer_indices.append(int(parts[1]))
        return max(layer_indices) + 1 if layer_indices else None
    gamma_count = sum(
        parameter.name.startswith("gamma_")
        for parameter in execution.context.parameter_schema.parameters
    )
    return max(1, gamma_count) if gamma_count else None


def _validation_section(
    ordered: tuple[tuple[str, ProblemExecutionResult], ...],
    *,
    comparison_kind: str,
    modes: Sequence[str],
    algorithms: Sequence[str],
) -> ExperimentSectionIR:
    diagnostics = tuple(
        diagnostic
        for _, execution in ordered
        for diagnostic in execution.result.diagnostics
    )
    status = "available"
    if any(item.severity == "error" for item in diagnostics):
        status = "error"
    elif any(item.severity == "warning" for item in diagnostics):
        status = "warning"
    baseline = ordered[0][1]
    return ExperimentSectionIR(
        section_id="problem-comparison.validate",
        stage="validate",
        title="Problem and execution alignment",
        status=status,  # type: ignore[arg-type]
        payload={
            "source_count": len(ordered),
            "problem_hash": baseline.problem_hash,
            "logical_order": list(baseline.logical_order),
            "comparison_kind": comparison_kind,
            "modes": modes,
            "algorithms": algorithms,
            "varying_dimensions": _varying_dimensions(ordered),
            "comparison_policy": _comparison_policy(),
            "diagnostic_count": len(diagnostics),
        },
        source_paths=tuple(
            path
            for label, _ in ordered
            for path in (
                f"sources.{label}.problem_hash",
                f"sources.{label}.logical_order",
                f"sources.{label}.mode",
                f"sources.{label}.algorithm",
            )
        ),
        diagnostics=diagnostics,
    )


def _comparison_kind(
    ordered: tuple[tuple[str, ProblemExecutionResult], ...],
) -> str:
    routes = {(execution.mode, execution.algorithm) for _, execution in ordered}
    if len(routes) > 1:
        return "route"
    layers = {_layers(execution) for _, execution in ordered}
    return "layer" if len(layers) > 1 else "configuration"


def _comparison_title(
    ordered: tuple[tuple[str, ProblemExecutionResult], ...],
    comparison_kind: str,
) -> str:
    if comparison_kind == "route":
        return "Problem route comparison"
    if comparison_kind == "layer":
        return f"{ordered[0][1].algorithm.upper()} layer comparison"
    return "Problem configuration comparison"


def _route(label: str, execution: ProblemExecutionResult) -> dict[str, Any]:
    mapping = execution.context.analysis.mapping_plan
    feasibility = mapping.feasibility_for(execution.mode)
    return {
        "label": label,
        "mode": execution.mode,
        "algorithm": execution.algorithm,
        "topology": execution.topology,
        "target_id": mapping.target_id,
        "target_hash": mapping.target_hash,
        "compile_feasible": feasibility.feasible,
        "local_reference": feasibility.local_reference,
        "hardware_executable": feasibility.hardware_executable,
    }


def _probability_source(execution: ProblemExecutionResult) -> str:
    return (
        "complete_probabilities"
        if execution.result.probabilities is not None
        else "counts"
    )


def _varying_dimensions(
    ordered: tuple[tuple[str, ProblemExecutionResult], ...],
) -> list[str]:
    fields: dict[str, list[Any]] = {
        "mode": [execution.mode for _, execution in ordered],
        "algorithm": [execution.algorithm for _, execution in ordered],
        "target": [
            execution.context.analysis.mapping_plan.target_hash
            for _, execution in ordered
        ],
        "compile": [execution.compile_hash for _, execution in ordered],
        "program": [execution.result.program_hash for _, execution in ordered],
        "layers": [_layers(execution) for _, execution in ordered],
        "shots": [execution.result.shots for _, execution in ordered],
        "parameter_count": [
            len(execution.context.parameter_schema.parameters)
            for _, execution in ordered
        ],
    }
    return [name for name, values in fields.items() if len(set(values)) > 1]


def _comparison_policy() -> dict[str, dict[str, str]]:
    return {
        "objective": {
            "status": "comparable",
            "reason": "All sources use the same canonical Problem and logical order.",
        },
        "energy_breakdown": {
            "status": "comparable",
            "reason": "Every source reconstructs the same canonical objective.",
        },
        "decoded_candidates": {
            "status": "qualified",
            "reason": (
                "Bitstrings align, but shots and probability sources must be "
                "considered."
            ),
        },
        "convergence": {
            "status": "evidence_only",
            "reason": (
                "Parameterizations and optimizer budgets may differ across routes."
            ),
        },
        "compile_resources": {
            "status": "descriptive_only",
            "reason": (
                "Digital gates, Analog controls, and Hybrid blocks use different units."
            ),
        },
        "runtime_resources": {
            "status": "descriptive_only",
            "reason": "Local process measurements are not a standardized benchmark.",
        },
    }


def _source_section(
    reports: Mapping[str, ExperimentReportIR],
    *,
    stage: str,
    section_id: str,
    title: str,
) -> ExperimentSectionIR:
    sources: dict[str, Any] = {}
    source_paths: list[str] = []
    for label in sorted(reports):
        section = reports[label].sections_for_stage(stage)[0]  # type: ignore[arg-type]
        sources[label] = {
            "status": section.status,
            "payload": section.payload,
            "unavailable_reason": section.unavailable_reason,
        }
        source_paths.extend(f"sources.{label}.{path}" for path in section.source_paths)
    return ExperimentSectionIR(
        section_id=section_id,
        stage=stage,  # type: ignore[arg-type]
        title=title,
        status="available",
        payload={"sources": sources},
        source_paths=tuple(source_paths),
    )
