"""Standard lifecycle report for a unified Problem execution."""

from __future__ import annotations

from dataclasses import replace
from typing import Any, Literal

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.problems.execution import ProblemExecutionResult
from cascaqit.visualization.experiment import ExperimentReportIR, ExperimentSectionIR
from cascaqit.visualization.gradient_report import build_gradient_report_payload
from cascaqit.visualization.models import RegisterVisualizationIR, VisualizationSpecIR
from cascaqit.visualization.noisy_optimization_report import (
    build_objective_execution_payload,
    build_objective_request_payload,
)
from cascaqit.visualization.program_report import build_program_report_context
from cascaqit.visualization.result_report import build_result_experiment_report

__all__ = ["build_problem_experiment_report"]


def build_problem_experiment_report(
    execution: ProblemExecutionResult,
    *,
    report_id: str | None = None,
    title: str | None = None,
) -> ExperimentReportIR:
    """Derive a complete report without rerunning or mutating the execution."""
    if not isinstance(execution, ProblemExecutionResult):
        raise TypeError("execution must be ProblemExecutionResult.")
    before = execution.to_dict()
    context = execution.context
    analysis = context.analysis
    canonical = analysis.canonical_problem
    mapping = analysis.mapping_plan
    selected_evaluation = execution.parameter_history[
        execution.selected_evaluation_index
    ]
    objective_evidence = selected_evaluation.execution_evidence
    # Physical noise is executed through an internal Hybrid wrapper.  In that
    # case ResultIR belongs to the wrapper rather than the source Digital Program,
    # so the generic Result report must derive runtime facts without a mismatched
    # source context.  The Problem sections below still retain the source Program.
    result_program = (
        context.native_program
        if execution.result.program_hash == context.native_program_hash
        else None
    )
    source_program = build_program_report_context(context.native_program)
    base = build_result_experiment_report(execution.result, program=result_program)

    base_sections = {section.stage: section for section in base.sections}
    diagnostics = _unique_diagnostics(
        (*analysis.diagnostics, *execution.result.diagnostics)
    )
    validation_status: Literal["available", "warning", "error"] = "available"
    if any(item.severity == "error" for item in diagnostics):
        validation_status = "error"
    elif any(item.severity == "warning" for item in diagnostics):
        validation_status = "warning"

    design = ExperimentSectionIR(
        section_id="problem.design",
        stage="design",
        title="Problem and Native Program design",
        status=source_program.section.status,
        payload={
            "mode": execution.mode,
            "algorithm": execution.algorithm,
            "topology": execution.topology,
            "problem": canonical.to_dict(),
            "node_weights": [
                {"node": node, "weight": weight}
                for node, weight in canonical.decoder.node_weights
            ],
            "logical_hamiltonian": analysis.logical_hamiltonian.to_dict(),
            "penalty_analysis": (
                None
                if analysis.penalty_analysis is None
                else analysis.penalty_analysis.to_dict()
            ),
            "native_program_kind": execution.mode,
            "native_program": source_program.section.payload,
        },
        source_paths=(
            "ProblemExecutionResult.context.analysis.canonical_problem",
            "ProblemExecutionResult.context.analysis.logical_hamiltonian",
            "ProblemExecutionResult.context.native_program",
        ),
        diagnostics=source_program.section.diagnostics,
    )
    validation = ExperimentSectionIR(
        section_id="problem.validate",
        stage="validate",
        title="Feasibility and diagnostics",
        status=validation_status,
        payload={
            **base_sections["validate"].payload,
            "selected_mode": execution.mode,
            "mode_feasibility": mapping.feasibility_for(execution.mode).to_dict(),
            "layout_valid": mapping.layout.valid,
            "term_conservation": all(item.conserved for item in context.term_mapping),
            "penalty_model_status": (
                "defined" if analysis.penalty_analysis is not None else "not_applicable"
            ),
            "penalty_sufficient": (
                None
                if analysis.penalty_analysis is None
                else analysis.penalty_analysis.sufficient
            ),
            "diagnostic_count": len(diagnostics),
            "codes": [item.code for item in diagnostics],
        },
        source_paths=(
            "ProblemExecutionResult.context.analysis.mapping_plan.feasibility",
            "ProblemExecutionResult.context.term_mapping",
            "ProblemExecutionResult.result.diagnostics",
        ),
        diagnostics=diagnostics,
    )
    plan = ExperimentSectionIR(
        section_id="problem.plan",
        stage="plan",
        title="Target mapping and compilation",
        status="available",
        payload={
            "compile_hash": execution.compile_hash,
            "analysis_hash": execution.analysis_hash,
            "target_id": mapping.target_id,
            "target_hash": mapping.target_hash,
            "layout_policy": mapping.layout.layout_policy,
            "layout_visualization": _layout_visualization(execution),
            "reference_interactions": [item.to_dict() for item in mapping.interactions],
            "term_mapping": [item.to_dict() for item in context.term_mapping],
            "parameter_schema": context.parameter_schema.to_dict(),
            "ansatz": None if context.ansatz is None else context.ansatz.to_dict(),
            "ansatz_spec_hash": context.ansatz_spec_hash,
            "resource_estimate": dict(mapping.resource_estimate),
            "mapping_plan": mapping.to_dict(),
            "runtime_plan": base_sections["plan"].payload,
            "local_reference": context.local_reference,
            "hardware_executable": context.hardware_executable,
            "objective_request": (
                None
                if objective_evidence is None
                else build_objective_request_payload(objective_evidence)
            ),
        },
        source_paths=(
            "ProblemExecutionResult.compile_hash",
            "ProblemExecutionResult.context.analysis.mapping_plan",
            "ProblemExecutionResult.context.term_mapping",
            "ProblemExecutionResult.context.parameter_schema",
            "ProblemExecutionResult.context.ansatz",
            "ProblemExecutionResult.context.ansatz_spec_hash",
            "ProblemExecutionResult.parameter_history.execution_evidence.noise_model",
            "ProblemExecutionResult.parameter_history.execution_evidence.requested_options",
            *base_sections["plan"].source_paths,
        ),
        diagnostics=analysis.diagnostics,
    )
    execute = replace(
        base_sections["execute"],
        section_id="problem.execute",
        title="Bound execution",
        payload={
            **base_sections["execute"].payload,
            "execution_id": execution.execution_id,
            "compile_hash": execution.compile_hash,
            "parameter_bind": execution.parameter_bind.to_dict(),
            "parameter_bind_hash": execution.parameter_bind_hash,
            "native_program_hash": context.native_program_hash,
            "source_program_hash": context.native_program_hash,
            "runtime_program_hash": execution.result.program_hash,
            "program_lineage": (
                "direct"
                if context.native_program_hash == execution.result.program_hash
                else "physical_noise_wrapper"
            ),
            "backend_job_id": execution.metadata.get("backend_job_id"),
            "objective_execution": (
                None
                if objective_evidence is None
                else build_objective_execution_payload(objective_evidence)
            ),
        },
        source_paths=(
            "ProblemExecutionResult.parameter_bind",
            "ProblemExecutionResult.result",
            "ProblemExecutionResult.context.native_program_hash",
            "ProblemExecutionResult.result.program_hash",
            "ProblemExecutionResult.parameter_history.execution_evidence",
            *base_sections["execute"].source_paths,
        ),
    )
    state = replace(
        base_sections["state"],
        section_id="problem.state",
    )
    measure = replace(
        base_sections["measure"],
        section_id="problem.measure",
        payload={
            **base_sections["measure"].payload,
            "candidate_count": len(execution.candidates),
            "logical_order": list(execution.logical_order),
        },
    )
    analyze = ExperimentSectionIR(
        section_id="problem.analyze",
        stage="analyze",
        title="Decoded candidates and objective",
        status="available",
        payload={
            "objective_value": execution.objective_value,
            "feasibility": execution.feasibility,
            "constraint_violations": list(execution.constraint_violations),
            "most_probable_candidate": (execution.most_probable_candidate.to_dict()),
            "best_observed_candidate": (execution.best_observed_candidate.to_dict()),
            "candidates": [item.to_dict() for item in execution.candidates],
            "candidate_energy_breakdowns": [
                item.to_dict() for item in execution.candidate_energy_breakdowns
            ],
            "parameter_history": [
                {
                    **item.to_dict(),
                    "energy": item.objective_value,
                    "parameters": dict(item.parameter_bind.values),
                }
                for item in execution.parameter_history
            ],
            "selected_evaluation_index": execution.selected_evaluation_index,
            "expected_selected_weight": execution.parameter_history[
                execution.selected_evaluation_index
            ].expected_selected_weight,
            "expected_energy_breakdown": execution.parameter_history[
                execution.selected_evaluation_index
            ].energy_breakdown.to_dict(),
            "optimization": (
                None
                if execution.optimization is None
                else execution.optimization.to_dict()
            ),
            "gradient": (
                None
                if execution.optimization is None
                or execution.optimization.termination is None
                else build_gradient_report_payload(
                    execution.optimization.gradients,
                    termination=execution.optimization.termination,
                )
            ),
            "baseline": (
                None if execution.baseline is None else execution.baseline.to_dict()
            ),
            "optimality_claim": execution.optimality_claim,
        },
        source_paths=(
            "ProblemExecutionResult.candidates",
            "ProblemExecutionResult.candidate_energy_breakdowns",
            "ProblemExecutionResult.parameter_history",
            "ProblemExecutionResult.optimization",
            "ProblemExecutionResult.baseline",
        ),
    )

    source_ids = (
        execution.execution_id,
        execution.result.result_id,
        analysis.analysis_id,
        canonical.problem_id,
        context.native_program_id,
    )
    report = ExperimentReportIR(
        report_id=report_id or f"problem_report.{execution.execution_id}",
        title=title or f"{execution.mode.title()} Problem experiment",
        profile="problem",
        source_kind="ProblemExecutionResult",
        source_ids=source_ids,
        source_hashes={
            execution.execution_id: execution.execution_hash,
            execution.result.result_id: execution.result.stable_hash(),
            analysis.analysis_id: analysis.analysis_hash,
            canonical.problem_id: canonical.problem_hash,
            context.native_program_id: context.native_program_hash,
        },
        sections=(design, validation, plan, execute, state, measure, analyze),
        metadata={
            "derived_view": True,
            "mode": execution.mode,
            "algorithm": execution.algorithm,
            "topology": execution.topology,
            "source_execution_mutated": False,
            "backend_called": False,
            "network_accessed": False,
            "artifact_bytes_read": False,
        },
    )
    if execution.to_dict() != before:
        raise ValueError("Problem report construction mutated its execution source.")
    return report


def _layout_visualization(execution: ProblemExecutionResult) -> dict[str, Any]:
    layout = execution.context.analysis.mapping_plan.layout
    visualization = RegisterVisualizationIR(
        spec=VisualizationSpecIR(
            visualization_id=f"viz.problem-layout.{layout.layout_id}",
            visualization_kind="register",
            title="Target atom mapping",
            source_kind="ProblemLayoutIR",
            source_id=layout.layout_id,
            source_hash=layout.stable_hash(),
            axes={
                "x": {"label": "x", "unit": "um"},
                "y": {"label": "y", "unit": "um"},
            },
            metadata={"data_role": "derived_report_plot"},
        ),
        coordinate_unit="um",
        sites=tuple(
            {
                "site_id": item.site_id,
                "atom_id": item.atom_id,
                "logical_id": item.logical_id,
                "x": item.position[0],
                "y": item.position[1],
                "filled": True,
                "status": "filled",
                "is_target": True,
                "metadata": {},
            }
            for item in layout.sites
        ),
        metadata={
            "site_count": len(layout.sites),
            "filled_count": len(layout.sites),
            "layout_policy": layout.layout_policy,
        },
    )
    return visualization.to_dict()


def _unique_diagnostics(
    diagnostics: tuple[DiagnosticsIR, ...],
) -> tuple[DiagnosticsIR, ...]:
    by_id = {item.diagnostic_id: item for item in diagnostics}
    return tuple(by_id[key] for key in sorted(by_id))
