"""Deterministic offline Bokeh embedding for standard experiment reports."""

from __future__ import annotations

import copy
import hashlib
import json
import math
from collections.abc import Mapping, Sequence
from functools import cache
from html import escape
from typing import Any, cast

from bokeh.embed import json_item
from bokeh.models import ColumnDataSource, HoverTool
from bokeh.models.annotations import Whisker
from bokeh.palettes import Category10
from bokeh.plotting import figure
from bokeh.resources import Resources

from cascaqit.native_ir.base import stable_json
from cascaqit.visualization.models import (
    CountsHistogramVisualizationIR,
    PulseTimelineVisualizationIR,
    RegisterVisualizationIR,
    VisualizationSpecIR,
)
from cascaqit.visualization.renderers import (
    VisualizationArtifactIR,
    render_counts_histogram_bokeh,
    render_pulse_timeline_bokeh,
    render_register_bokeh,
)

__all__: list[str] = []

_TREND_COLORS = Category10[10]


@cache
def inline_bokeh_resources_html() -> str:
    """Return only the core BokehJS runtime needed by report plots."""
    rendered = Resources(mode="inline", components=["bokeh"]).render_js()
    # Bokeh owns the minified JavaScript, but report hashes also cover whitespace.
    return "\n".join(line.rstrip() for line in rendered.splitlines())


def render_register_bokeh_html(
    register: Mapping[str, Any],
    *,
    fallback_html: str,
) -> str:
    """Embed an interactive atom register and retain a no-JavaScript fallback."""
    visualization = RegisterVisualizationIR.from_dict(dict(register))
    artifact = render_register_bokeh(visualization)
    return _embed_artifact(
        artifact,
        target_seed={"kind": "register", "source": visualization.to_dict()},
        kind="register",
        aria_label="Atom arrangement",
        fallback_html=fallback_html,
    )


def render_pulse_bokeh_html(
    pulses: Mapping[str, Any],
    *,
    fallback_html: str,
) -> str:
    """Embed linked Bokeh waveform plots for every control channel."""
    visualization = PulseTimelineVisualizationIR.from_dict(dict(pulses))
    artifact = render_pulse_timeline_bokeh(visualization)
    return _embed_artifact(
        artifact,
        target_seed={"kind": "pulse", "source": visualization.to_dict()},
        kind="pulse",
        aria_label="Control waveforms",
        fallback_html=fallback_html,
    )


def render_counts_bokeh_html(
    payload: Mapping[str, Any],
    *,
    identity_hint: str,
    fallback_html: str,
) -> str:
    """Embed an interactive counts histogram derived from measurement facts."""
    counts = payload.get("counts", {})
    probabilities = payload.get("probabilities")
    if not isinstance(counts, Mapping) or not counts:
        return fallback_html

    normalized = sorted(
        ((str(outcome), _non_negative_int(count)) for outcome, count in counts.items()),
        key=lambda item: (-item[1], item[0]),
    )
    shown = normalized[:24]
    shots = _non_negative_int(payload.get("shots")) or sum(
        count for _, count in normalized
    )
    bars = []
    for outcome, count in shown:
        probability = None
        if isinstance(probabilities, Mapping):
            probability = _finite_number(probabilities.get(outcome))
        if probability is None:
            probability = count / shots if shots else 0.0
        bars.append(
            {
                "bitstring": outcome,
                "count": count,
                "probability": probability,
            }
        )
    source = {
        "identity_hint": identity_hint,
        "shots": shots,
        "bars": bars,
    }
    source_hash = _digest(source)
    visualization = CountsHistogramVisualizationIR(
        spec=VisualizationSpecIR(
            visualization_id=f"report.counts.{source_hash[:16]}",
            visualization_kind="counts_histogram",
            title="Measurement distribution",
            source_kind="ExperimentReportIR",
            source_id=identity_hint,
            source_hash=source_hash,
            metadata={"data_role": "derived_report_plot"},
        ),
        shots=shots,
        bars=tuple(bars),
    )
    artifact = render_counts_histogram_bokeh(visualization)
    return _embed_artifact(
        artifact,
        target_seed={"kind": "counts", "source": source},
        kind="counts",
        aria_label="Measurement distribution",
        fallback_html=fallback_html,
    )


def render_trend_bokeh_html(
    series: Mapping[str, Any],
    *,
    value_key: str,
    title: str,
    fallback_html: str,
) -> str:
    """Embed an interactive multi-series scan trend with deterministic data order."""
    normalized = _normalize_trend_series(series, value_key=value_key)
    if not normalized:
        return fallback_html

    plot = figure(
        title="",
        x_axis_label="scan_index",
        y_axis_label=value_key,
        height=340,
        sizing_mode="stretch_width",
        tools="pan,wheel_zoom,box_zoom,reset,save",
        toolbar_location="right",
    )
    for index, (label, points) in enumerate(normalized[:8]):
        source = ColumnDataSource(
            {
                "scan_index": [point[0] for point in points],
                "value": [point[1] for point in points],
                "series": [label for _ in points],
            }
        )
        color = _TREND_COLORS[index % len(_TREND_COLORS)]
        plot.line(
            x="scan_index",
            y="value",
            source=source,
            line_width=2,
            color=color,
            legend_label=label,
        )
        plot.scatter(
            x="scan_index",
            y="value",
            source=source,
            size=7,
            color=color,
        )
    plot.add_tools(
        HoverTool(
            tooltips=[
                ("series", "@series"),
                ("scan_index", "@scan_index"),
                (value_key, "@value{0.000000}"),
            ]
        )
    )
    plot.legend.location = "top_left"
    plot.legend.click_policy = "hide"
    item = cast(dict[str, Any], json_item(plot))
    return _embed_item(
        item,
        target_seed={
            "kind": "trend",
            "title": title,
            "value_key": value_key,
            "series": normalized,
        },
        kind="trend",
        aria_label=title,
        fallback_html=fallback_html,
    )


def render_objective_history_bokeh_html(
    evaluations: Sequence[Any],
    *,
    best_evaluation_index: int,
    baseline_energy: float | None,
    identity_hint: str,
    fallback_html: str,
) -> str:
    """Embed objective energy history with best and baseline evidence."""
    points: list[dict[str, Any]] = []
    for item in evaluations:
        if not isinstance(item, Mapping):
            continue
        index = _non_negative_int(item.get("evaluation_index"))
        energy = _finite_number(item.get("energy"))
        if energy is None:
            continue
        parameters = item.get("parameters", {})
        points.append(
            {
                "evaluation_index": index,
                "energy": energy,
                "parameters": stable_json(parameters),
                "result_id": str(item.get("result_id", "")),
                "is_best": index == best_evaluation_index,
            }
        )
    if not points:
        return fallback_html

    points.sort(key=lambda point: int(point["evaluation_index"]))
    running_best: list[float] = []
    current_best = math.inf
    for point in points:
        current_best = min(current_best, float(point["energy"]))
        point["running_best"] = current_best
        running_best.append(current_best)
    source = ColumnDataSource(
        {
            key: [point[key] for point in points]
            for key in (
                "evaluation_index",
                "energy",
                "running_best",
                "parameters",
                "result_id",
            )
        }
    )
    plot = figure(
        title="",
        x_axis_label="evaluation",
        y_axis_label="energy",
        height=360,
        sizing_mode="stretch_width",
        tools="pan,wheel_zoom,box_zoom,reset,save",
        toolbar_location="right",
    )
    plot.line(
        x="evaluation_index",
        y="energy",
        source=source,
        line_width=2,
        color=_TREND_COLORS[0],
        legend_label="Observed energy",
    )
    plot.scatter(
        x="evaluation_index",
        y="energy",
        source=source,
        size=7,
        color=_TREND_COLORS[0],
    )
    plot.line(
        x="evaluation_index",
        y="running_best",
        source=source,
        line_width=3,
        color=_TREND_COLORS[3],
        legend_label="Running best",
    )
    best_points = [point for point in points if point["is_best"]]
    if best_points:
        best_source = ColumnDataSource(
            {
                "evaluation_index": [best_points[0]["evaluation_index"]],
                "energy": [best_points[0]["energy"]],
                "parameters": [best_points[0]["parameters"]],
                "result_id": [best_points[0]["result_id"]],
            }
        )
        plot.scatter(
            x="evaluation_index",
            y="energy",
            source=best_source,
            marker="diamond",
            size=14,
            color=_TREND_COLORS[1],
            legend_label="Best observed",
        )
    baseline = _finite_number(baseline_energy)
    if baseline is not None:
        indices = [int(point["evaluation_index"]) for point in points]
        low = min(indices)
        high = max(indices)
        plot.line(
            x=[low, high],
            y=[baseline, baseline],
            line_width=2,
            line_dash="dashed",
            color=_TREND_COLORS[2],
            legend_label="Classical baseline",
        )
    plot.add_tools(
        HoverTool(
            tooltips=[
                ("evaluation", "@evaluation_index"),
                ("energy", "@energy{0.000000000}"),
                ("running best", "@running_best{0.000000000}"),
                ("parameters", "@parameters"),
                ("Result", "@result_id"),
            ]
        )
    )
    plot.legend.location = "top_right"
    plot.legend.click_policy = "hide"
    item = cast(dict[str, Any], json_item(plot))
    return _embed_item(
        item,
        target_seed={
            "kind": "objective",
            "identity_hint": identity_hint,
            "points": points,
            "baseline_energy": baseline,
        },
        kind="objective",
        aria_label="Objective history",
        fallback_html=fallback_html,
    )


def render_problem_metrics_bokeh_html(
    evaluations: Sequence[Any],
    *,
    identity_hint: str,
    fallback_html: str,
) -> str:
    """Embed feasibility and constraint metrics for real parameter evaluations."""
    points = _problem_metric_points(evaluations)
    if not points or not any(
        point["feasible_probability"] is not None
        or point["expected_constraint_violation_count"] is not None
        for point in points
    ):
        return fallback_html
    plot = figure(
        title="",
        x_axis_label="evaluation",
        y_axis_label="metric value",
        height=340,
        sizing_mode="stretch_width",
        tools="pan,wheel_zoom,box_zoom,reset,save",
        toolbar_location="right",
    )
    metric_specs = (
        ("feasible_probability", "Feasible probability", _TREND_COLORS[4]),
        (
            "expected_constraint_violation_count",
            "Expected constraint violations",
            _TREND_COLORS[1],
        ),
    )
    for field_name, label, color in metric_specs:
        selected = [point for point in points if point[field_name] is not None]
        if not selected:
            continue
        source = ColumnDataSource(
            {
                "evaluation_index": [point["evaluation_index"] for point in selected],
                "value": [point[field_name] for point in selected],
                "metric": [label for _ in selected],
                "parameters": [point["parameters"] for point in selected],
            }
        )
        plot.line(
            x="evaluation_index",
            y="value",
            source=source,
            line_width=2,
            color=color,
            legend_label=label,
        )
        plot.scatter(
            x="evaluation_index",
            y="value",
            source=source,
            size=7,
            color=color,
        )
    plot.add_tools(
        HoverTool(
            tooltips=[
                ("metric", "@metric"),
                ("evaluation", "@evaluation_index"),
                ("value", "@value{0.000000000}"),
                ("parameters", "@parameters"),
            ]
        )
    )
    plot.legend.location = "top_right"
    plot.legend.click_policy = "hide"
    item = cast(dict[str, Any], json_item(plot))
    return _embed_item(
        item,
        target_seed={
            "kind": "problem-metrics",
            "identity_hint": identity_hint,
            "points": points,
        },
        kind="problem-metrics",
        aria_label="Problem feasibility and constraint metrics",
        fallback_html=fallback_html,
    )


def render_parameter_history_bokeh_html(
    evaluations: Sequence[Any],
    *,
    identity_hint: str,
    fallback_html: str,
) -> str:
    """Embed one trajectory for every finite optimization parameter."""
    normalized: list[tuple[int, dict[str, float]]] = []
    parameter_names: set[str] = set()
    for item in evaluations:
        if not isinstance(item, Mapping):
            continue
        index = _non_negative_int(item.get("evaluation_index"))
        parameters = item.get("parameters")
        if not isinstance(parameters, Mapping):
            continue
        values = {
            str(name): value
            for name, raw_value in parameters.items()
            if (value := _finite_number(raw_value)) is not None
        }
        if values:
            normalized.append((index, values))
            parameter_names.update(values)
    if not normalized:
        return fallback_html
    normalized.sort(key=lambda item: item[0])
    plot = figure(
        title="",
        x_axis_label="evaluation",
        y_axis_label="parameter value",
        height=360,
        sizing_mode="stretch_width",
        tools="pan,wheel_zoom,box_zoom,reset,save",
        toolbar_location="right",
    )
    for index, name in enumerate(sorted(parameter_names)[:12]):
        points = [
            (evaluation_index, parameters[name])
            for evaluation_index, parameters in normalized
            if name in parameters
        ]
        source = ColumnDataSource(
            {
                "evaluation_index": [point[0] for point in points],
                "value": [point[1] for point in points],
                "parameter": [name for _ in points],
            }
        )
        color = _TREND_COLORS[index % len(_TREND_COLORS)]
        plot.line(
            x="evaluation_index",
            y="value",
            source=source,
            line_width=2,
            color=color,
            legend_label=name,
        )
        plot.scatter(
            x="evaluation_index",
            y="value",
            source=source,
            size=7,
            color=color,
        )
    plot.add_tools(
        HoverTool(
            tooltips=[
                ("parameter", "@parameter"),
                ("evaluation", "@evaluation_index"),
                ("value", "@value{0.000000000}"),
            ]
        )
    )
    plot.legend.location = "top_right"
    plot.legend.click_policy = "hide"
    item = cast(dict[str, Any], json_item(plot))
    return _embed_item(
        item,
        target_seed={
            "kind": "parameters",
            "identity_hint": identity_hint,
            "evaluations": normalized,
        },
        kind="parameters",
        aria_label="Optimization parameter trajectories",
        fallback_html=fallback_html,
    )


def render_gradient_history_bokeh_html(
    gradients: Sequence[Any],
    *,
    identity_hint: str,
    fallback_html: str,
) -> str:
    """Embed saved gradient components and their L2 norm by callback index."""
    normalized: list[tuple[int, dict[str, float], float]] = []
    parameter_names: set[str] = set()
    for item in gradients:
        if not isinstance(item, Mapping):
            continue
        index = _non_negative_int(item.get("gradient_index"))
        components = item.get("components")
        norm = _finite_number(item.get("l2_norm"))
        if not isinstance(components, Mapping) or norm is None:
            continue
        values = {
            str(name): value
            for name, raw_value in components.items()
            if (value := _finite_number(raw_value)) is not None
        }
        if values:
            normalized.append((index, values, norm))
            parameter_names.update(values)
    if not normalized:
        return fallback_html
    normalized.sort(key=lambda item: item[0])
    plot = figure(
        title="",
        x_axis_label="gradient callback",
        y_axis_label="derivative",
        height=360,
        sizing_mode="stretch_width",
        tools="pan,wheel_zoom,box_zoom,reset,save",
        toolbar_location="right",
    )
    for color_index, name in enumerate(sorted(parameter_names)[:12]):
        points = [
            (gradient_index, components[name])
            for gradient_index, components, _ in normalized
            if name in components
        ]
        source = ColumnDataSource(
            {
                "gradient_index": [point[0] for point in points],
                "value": [point[1] for point in points],
                "component": [name for _ in points],
            }
        )
        color = _TREND_COLORS[color_index % len(_TREND_COLORS)]
        plot.line(
            x="gradient_index",
            y="value",
            source=source,
            line_width=2,
            color=color,
            legend_label=name,
        )
        plot.scatter(
            x="gradient_index",
            y="value",
            source=source,
            size=7,
            color=color,
        )
    norm_source = ColumnDataSource(
        {
            "gradient_index": [item[0] for item in normalized],
            "value": [item[2] for item in normalized],
            "component": ["L2 norm" for _ in normalized],
        }
    )
    plot.line(
        x="gradient_index",
        y="value",
        source=norm_source,
        line_width=3,
        line_dash="dashed",
        color="#111827",
        legend_label="L2 norm",
    )
    plot.scatter(
        x="gradient_index",
        y="value",
        source=norm_source,
        size=8,
        color="#111827",
    )
    plot.add_tools(
        HoverTool(
            tooltips=[
                ("component", "@component"),
                ("gradient", "@gradient_index"),
                ("value", "@value{0.000000000}"),
            ]
        )
    )
    plot.legend.location = "top_right"
    plot.legend.click_policy = "hide"
    item = cast(dict[str, Any], json_item(plot))
    return _embed_item(
        item,
        target_seed={
            "kind": "gradient",
            "identity_hint": identity_hint,
            "gradients": normalized,
        },
        kind="gradient",
        aria_label="Gradient component trajectories",
        fallback_html=fallback_html,
    )


def render_problem_comparison_bokeh_html(
    series: Mapping[str, Any],
    *,
    identity_hint: str,
    fallback_html: str,
) -> str:
    """Embed observed and running-best objective histories for aligned runs."""
    normalized: list[tuple[str, list[tuple[int, float]]]] = []
    for label, raw_evaluations in sorted(series.items(), key=lambda item: str(item[0])):
        if not _is_sequence(raw_evaluations):
            continue
        points = []
        for item in raw_evaluations:
            if not isinstance(item, Mapping):
                continue
            index = _non_negative_int(item.get("evaluation_index"))
            energy = _finite_number(item.get("energy"))
            if energy is not None:
                points.append((index, energy))
        if points:
            normalized.append((str(label), sorted(points)))
    if not normalized:
        return fallback_html
    plot = figure(
        title="",
        x_axis_label="evaluation",
        y_axis_label="expected objective",
        height=380,
        sizing_mode="stretch_width",
        tools="pan,wheel_zoom,box_zoom,reset,save",
        toolbar_location="right",
    )
    seed_series: list[dict[str, Any]] = []
    for index, (label, points) in enumerate(normalized[:8]):
        best = math.inf
        running_best = []
        for _, energy in points:
            best = min(best, energy)
            running_best.append(best)
        source = ColumnDataSource(
            {
                "evaluation_index": [point[0] for point in points],
                "energy": [point[1] for point in points],
                "running_best": running_best,
                "series": [label for _ in points],
            }
        )
        color = _TREND_COLORS[index % len(_TREND_COLORS)]
        plot.line(
            x="evaluation_index",
            y="energy",
            source=source,
            line_width=1,
            line_dash="dotted",
            line_alpha=0.55,
            color=color,
            legend_label=f"{label} observed",
        )
        plot.scatter(
            x="evaluation_index",
            y="energy",
            source=source,
            size=6,
            fill_alpha=0.65,
            color=color,
        )
        plot.line(
            x="evaluation_index",
            y="running_best",
            source=source,
            line_width=3,
            color=color,
            legend_label=f"{label} running best",
        )
        seed_series.append(
            {"label": label, "points": points, "running_best": running_best}
        )
    plot.add_tools(
        HoverTool(
            tooltips=[
                ("series", "@series"),
                ("evaluation", "@evaluation_index"),
                ("objective", "@energy{0.000000000}"),
                ("running best", "@running_best{0.000000000}"),
            ]
        )
    )
    plot.legend.location = "top_right"
    plot.legend.click_policy = "hide"
    item = cast(dict[str, Any], json_item(plot))
    return _embed_item(
        item,
        target_seed={
            "kind": "problem-comparison",
            "identity_hint": identity_hint,
            "series": seed_series,
        },
        kind="problem-comparison",
        aria_label="Problem optimization convergence comparison",
        fallback_html=fallback_html,
    )


def render_repeated_layer_statistics_bokeh_html(
    payload: Mapping[str, Any],
    *,
    identity_hint: str,
    fallback_html: str,
) -> str:
    """Plot repeated objectives, layer means, and Student-t intervals."""
    raw_steps = payload.get("steps", ())
    if not _is_sequence(raw_steps):
        return fallback_html
    layers: list[int] = []
    means: list[float] = []
    lows: list[float] = []
    highs: list[float] = []
    raw_x: list[float] = []
    raw_y: list[float] = []
    raw_labels: list[str] = []
    seed_steps: list[dict[str, Any]] = []
    for raw_step in raw_steps:
        if not isinstance(raw_step, Mapping):
            continue
        layer = _non_negative_int(raw_step.get("layers"))
        mean = _finite_number(raw_step.get("mean_objective"))
        low = _finite_number(raw_step.get("confidence_interval_low"))
        high = _finite_number(raw_step.get("confidence_interval_high"))
        objectives = raw_step.get("repeat_objectives", ())
        if mean is None or low is None or high is None or not _is_sequence(objectives):
            continue
        normalized_objectives = [
            value
            for value in (_finite_number(item) for item in objectives)
            if value is not None
        ]
        if not normalized_objectives:
            continue
        layers.append(layer)
        means.append(mean)
        lows.append(low)
        highs.append(high)
        count = len(normalized_objectives)
        spacing = min(0.18, 0.7 / max(count, 1))
        for repeat_index, objective in enumerate(normalized_objectives):
            offset = (repeat_index - (count - 1) / 2.0) * spacing
            raw_x.append(layer + offset)
            raw_y.append(objective)
            raw_labels.append(f"p={layer}, repeat={repeat_index + 1}")
        seed_steps.append(
            {
                "layers": layer,
                "mean": mean,
                "low": low,
                "high": high,
                "objectives": normalized_objectives,
            }
        )
    if not layers:
        return fallback_html
    plot = figure(
        title="",
        x_axis_label="Ansatz layers",
        y_axis_label="selected expected objective",
        height=380,
        sizing_mode="stretch_width",
        tools="pan,wheel_zoom,box_zoom,reset,save",
        toolbar_location="right",
    )
    raw_source = ColumnDataSource({"x": raw_x, "objective": raw_y, "run": raw_labels})
    raw_renderer = plot.scatter(
        x="x",
        y="objective",
        source=raw_source,
        size=7,
        fill_alpha=0.45,
        color=_TREND_COLORS[1],
        legend_label="repeated optimizer runs",
    )
    mean_source = ColumnDataSource(
        {
            "layers": layers,
            "mean": means,
            "low": lows,
            "high": highs,
        }
    )
    plot.line(
        x="layers",
        y="mean",
        source=mean_source,
        line_width=3,
        color=_TREND_COLORS[0],
        legend_label="layer mean",
    )
    mean_renderer = plot.scatter(
        x="layers",
        y="mean",
        source=mean_source,
        size=10,
        color=_TREND_COLORS[0],
    )
    plot.add_layout(
        Whisker(
            source=mean_source,
            base="layers",
            upper="high",
            lower="low",
            line_color=_TREND_COLORS[0],
        )
    )
    plot.add_tools(
        HoverTool(
            renderers=[raw_renderer],
            tooltips=[
                ("run", "@run"),
                ("objective", "@objective{0.000000000}"),
            ],
        ),
        HoverTool(
            renderers=[mean_renderer],
            tooltips=[
                ("layers", "@layers"),
                ("mean", "@mean{0.000000000}"),
                ("interval", "[@low{0.000000000}, @high{0.000000000}]"),
            ],
        ),
    )
    plot.xaxis.ticker = sorted(set(layers))
    plot.legend.location = "top_right"
    plot.legend.click_policy = "hide"
    item = cast(dict[str, Any], json_item(plot))
    return _embed_item(
        item,
        target_seed={
            "kind": "repeated-layer-statistics",
            "identity_hint": identity_hint,
            "steps": seed_steps,
        },
        kind="repeated-layer-statistics",
        aria_label="Repeated layer objective statistics",
        fallback_html=fallback_html,
    )


def _problem_metric_points(evaluations: Sequence[Any]) -> list[dict[str, Any]]:
    points: list[dict[str, Any]] = []
    for item in evaluations:
        if not isinstance(item, Mapping):
            continue
        points.append(
            {
                "evaluation_index": _non_negative_int(item.get("evaluation_index")),
                "feasible_probability": _finite_number(
                    item.get("feasible_probability")
                ),
                "expected_constraint_violation_count": _finite_number(
                    item.get("expected_constraint_violation_count")
                ),
                "parameters": stable_json(item.get("parameters", {})),
            }
        )
    return sorted(points, key=lambda point: int(point["evaluation_index"]))


def _embed_artifact(
    artifact: VisualizationArtifactIR,
    *,
    target_seed: Mapping[str, Any],
    kind: str,
    aria_label: str,
    fallback_html: str,
) -> str:
    if artifact.renderer != "bokeh" or not isinstance(artifact.content, dict):
        codes = ", ".join(item.code for item in artifact.diagnostics)
        raise RuntimeError(
            "The standard report requires the Bokeh runtime"
            + (f" ({codes})." if codes else ".")
        )
    return _embed_item(
        artifact.content,
        target_seed=target_seed,
        kind=kind,
        aria_label=aria_label,
        fallback_html=fallback_html,
    )


def _embed_item(
    item: Mapping[str, Any],
    *,
    target_seed: Mapping[str, Any],
    kind: str,
    aria_label: str,
    fallback_html: str,
) -> str:
    target_id = f"cascaqit-bokeh-{kind}-{_digest(target_seed)[:16]}"
    normalized = _normalize_bokeh_model_ids(item)
    normalized["target_id"] = target_id
    data_id = f"{target_id}-data"
    payload = _safe_script_json(normalized)
    return (
        f'<div class="bokeh-plot bokeh-{_attr(kind)}" id="{_attr(target_id)}" '
        f'role="img" aria-label="{_attr(aria_label)}"></div>'
        f'<script type="application/json" id="{_attr(data_id)}">{payload}</script>'
        "<script>(function(){"
        f'const node=document.getElementById("{_attr(data_id)}");'
        "if(node&&window.Bokeh){Bokeh.embed.embed_item(JSON.parse(node.textContent));}"
        "})();</script>"
        f"<noscript>{fallback_html}</noscript>"
    )


def _normalize_bokeh_model_ids(item: Mapping[str, Any]) -> dict[str, Any]:
    """Replace process-global Bokeh IDs with stable per-item identifiers."""
    normalized = copy.deepcopy(dict(item))
    replacements: dict[str, str] = {}
    visited: set[int] = set()

    def visit(value: Any) -> None:
        if isinstance(value, dict):
            # Bokeh reuses the same reference dictionary for shared models such
            # as linked x-ranges. Visiting that object twice would treat its
            # already-normalized ID as a new source ID and break the reference.
            identity = id(value)
            if identity in visited:
                return
            visited.add(identity)
            for key, child in value.items():
                if key in {"id", "root_id"} and isinstance(child, str):
                    replacement = replacements.setdefault(
                        child,
                        f"m{len(replacements) + 1}",
                    )
                    value[key] = replacement
                else:
                    visit(child)
        elif isinstance(value, (list, tuple)):
            identity = id(value)
            if identity in visited:
                return
            visited.add(identity)
            for child in value:
                visit(child)

    visit(normalized)
    return normalized


def _normalize_trend_series(
    series: Mapping[str, Any],
    *,
    value_key: str,
) -> list[tuple[str, list[tuple[float, float]]]]:
    normalized: list[tuple[str, list[tuple[float, float]]]] = []
    for label, raw_points in sorted(series.items(), key=lambda item: str(item[0])):
        if not _is_sequence(raw_points):
            continue
        points = []
        for raw in raw_points:
            if not isinstance(raw, Mapping):
                continue
            x = _finite_number(raw.get("scan_index"))
            y = _finite_number(raw.get(value_key))
            if x is not None and y is not None:
                points.append((x, y))
        if points:
            normalized.append((str(label), points))
    return normalized


def _safe_script_json(value: Mapping[str, Any]) -> str:
    # Bokeh's decoder resolves model references as it walks the serialized
    # document. Preserve Bokeh's insertion order so model definitions such as
    # axes stay ahead of the grids that reference them.
    text = json.dumps(
        value,
        ensure_ascii=True,
        separators=(",", ":"),
    )
    return (
        text.replace("&", "\\u0026")
        .replace("<", "\\u003c")
        .replace(">", "\\u003e")
        .replace("\u2028", "\\u2028")
        .replace("\u2029", "\\u2029")
    )


def _digest(value: Any) -> str:
    return hashlib.sha256(stable_json(value).encode("utf-8")).hexdigest()


def _non_negative_int(value: Any) -> int:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return 0
    if not math.isfinite(float(value)):
        return 0
    return max(0, int(value))


def _finite_number(value: Any) -> float | None:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    number = float(value)
    return number if math.isfinite(number) else None


def _is_sequence(value: Any) -> bool:
    return isinstance(value, Sequence) and not isinstance(value, (str, bytes))


def _attr(value: Any) -> str:
    return escape(str(value), quote=True)
