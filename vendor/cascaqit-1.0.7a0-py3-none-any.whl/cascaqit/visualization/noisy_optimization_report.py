"""Build report payloads for saved variational noise execution evidence."""

from __future__ import annotations

from typing import Any

from cascaqit.algorithms import ObjectiveExecutionEvidenceIR

__all__ = [
    "build_objective_execution_payload",
    "build_objective_request_payload",
    "build_objective_summary_payload",
]


def build_objective_request_payload(
    evidence: ObjectiveExecutionEvidenceIR,
) -> dict[str, Any]:
    """Return the user request facts that selected one objective execution path."""
    _require_evidence(evidence)
    return {
        "execution_mode": "noisy" if evidence.noise_model is not None else "ideal",
        "noise_model": (
            None if evidence.noise_model is None else evidence.noise_model.to_dict()
        ),
        "noise_model_hash": (
            None
            if evidence.noise_model is None
            else evidence.noise_model.stable_hash()
        ),
        "requested_options": (
            None
            if evidence.requested_options is None
            else evidence.requested_options.to_dict()
        ),
        "requested_seed": evidence.requested_seed,
    }


def build_objective_summary_payload(
    evidence: ObjectiveExecutionEvidenceIR,
) -> dict[str, Any]:
    """Return compact per-evaluation facts for an optimization history table."""
    _require_evidence(evidence)
    return {
        "execution_mode": "noisy" if evidence.noise_model is not None else "ideal",
        "method": evidence.simulation_plan.method_selected,
        "estimator": evidence.estimator_kind.value,
        "source_kind": evidence.source_kind.value,
        "effective_seed": evidence.effective_seed,
        "backend_job_id": evidence.backend_job_id,
        "backend_shots": evidence.backend_shots,
        "noise_model_hash": (
            None
            if evidence.noise_model is None
            else evidence.noise_model.stable_hash()
        ),
        "evidence_hash": evidence.evidence_hash,
    }


def build_objective_execution_payload(
    evidence: ObjectiveExecutionEvidenceIR,
) -> dict[str, Any]:
    """Return all typed facts needed by the standard visible execution view."""
    payload = evidence.to_dict()
    payload["execution_mode"] = (
        "noisy" if evidence.noise_model is not None else "ideal"
    )
    payload["noise_model_hash"] = (
        None
        if evidence.noise_model is None
        else evidence.noise_model.stable_hash()
    )
    payload["simulation_plan_hash"] = evidence.simulation_plan.stable_hash()
    payload["noise_report_hash"] = (
        None
        if evidence.noise_report is None
        else evidence.noise_report.stable_hash()
    )
    return payload


def _require_evidence(evidence: ObjectiveExecutionEvidenceIR) -> None:
    if not isinstance(evidence, ObjectiveExecutionEvidenceIR):
        raise TypeError("evidence must be ObjectiveExecutionEvidenceIR.")
