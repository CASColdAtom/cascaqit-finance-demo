"""Serializable visualization data models and builders."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Literal

from cascaqit.analog import AtomRegister
from cascaqit.hybrid import HybridSimulationPlanIR
from cascaqit.native_ir.base import IRMixin
from cascaqit.native_ir.models import (
    SCHEMA_VERSION,
    AtomRegisterIR,
    ProgramIR,
    WaveformIR,
)
from cascaqit.native_ir.reference_compiled import ReferenceCompiledProgramIR
from cascaqit.results import ResultIR

__all__ = [
    "CountsHistogramVisualizationIR",
    "HybridTimelineReportSectionIR",
    "HybridTimelineVisualizationIR",
    "PulseTimelineVisualizationIR",
    "RegisterVisualizationIR",
    "VisualizationSpecIR",
    "build_counts_histogram",
    "build_hybrid_timeline_report_section",
    "build_hybrid_timeline_visualization",
    "build_pulse_timeline",
    "build_register_visualization",
]

VisualizationKind = Literal[
    "register",
    "pulse_timeline",
    "counts_histogram",
    "hybrid_timeline",
]


@dataclass(frozen=True)
class VisualizationSpecIR(IRMixin):
    """Shared visualization specification metadata."""

    visualization_id: str
    visualization_kind: VisualizationKind
    title: str
    source_kind: str
    source_id: str
    source_hash: str | None = None
    schema_version: str = SCHEMA_VERSION
    axes: dict[str, Any] = field(default_factory=dict)
    style: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> VisualizationSpecIR:
        """Build a visualization spec from a JSON-compatible dictionary."""
        return cls(
            visualization_id=str(data["visualization_id"]),
            visualization_kind=data["visualization_kind"],
            title=str(data["title"]),
            source_kind=str(data["source_kind"]),
            source_id=str(data["source_id"]),
            source_hash=data.get("source_hash"),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            axes=dict(data.get("axes", {})),
            style=dict(data.get("style", {})),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> VisualizationSpecIR:
        """Build a visualization spec from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("VisualizationSpecIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class RegisterVisualizationIR(IRMixin):
    """Plot-ready atom register data."""

    spec: VisualizationSpecIR
    coordinate_unit: str
    sites: tuple[dict[str, Any], ...]
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> RegisterVisualizationIR:
        """Build register visualization data from a dictionary."""
        return cls(
            spec=VisualizationSpecIR.from_dict(data["spec"]),
            coordinate_unit=str(data["coordinate_unit"]),
            sites=tuple(dict(site) for site in data.get("sites", ())),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> RegisterVisualizationIR:
        """Build register visualization data from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("RegisterVisualizationIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class PulseTimelineVisualizationIR(IRMixin):
    """Plot-ready pulse timeline data."""

    spec: VisualizationSpecIR
    time_unit: str
    channels: tuple[dict[str, Any], ...]
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PulseTimelineVisualizationIR:
        """Build pulse timeline visualization data from a dictionary."""
        return cls(
            spec=VisualizationSpecIR.from_dict(data["spec"]),
            time_unit=str(data["time_unit"]),
            channels=tuple(
                _json_mapping(channel) for channel in data.get("channels", ())
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> PulseTimelineVisualizationIR:
        """Build pulse timeline visualization data from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("PulseTimelineVisualizationIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class CountsHistogramVisualizationIR(IRMixin):
    """Plot-ready counts histogram data."""

    spec: VisualizationSpecIR
    shots: int
    bars: tuple[dict[str, Any], ...]
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CountsHistogramVisualizationIR:
        """Build counts histogram visualization data from a dictionary."""
        return cls(
            spec=VisualizationSpecIR.from_dict(data["spec"]),
            shots=int(data["shots"]),
            bars=tuple(dict(bar) for bar in data.get("bars", ())),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> CountsHistogramVisualizationIR:
        """Build counts histogram visualization data from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError(
                "CountsHistogramVisualizationIR JSON must contain an object."
            )
        return cls.from_dict(data)


@dataclass(frozen=True)
class HybridTimelineVisualizationIR(IRMixin):
    """Plot-ready hybrid plan timeline data."""

    spec: VisualizationSpecIR
    time_unit: str
    blocks: tuple[dict[str, Any], ...]
    boundaries: tuple[dict[str, Any], ...]
    mapping: dict[str, str]
    boundary_summary: dict[str, Any]
    plan_only: bool = True
    fact_source: bool = False
    full_daqc_state_handoff: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> HybridTimelineVisualizationIR:
        """Build hybrid timeline visualization data from a dictionary."""
        return cls(
            spec=VisualizationSpecIR.from_dict(data["spec"]),
            time_unit=str(data["time_unit"]),
            blocks=tuple(dict(block) for block in data.get("blocks", ())),
            boundaries=tuple(dict(boundary) for boundary in data.get("boundaries", ())),
            mapping={
                str(key): str(value) for key, value in data.get("mapping", {}).items()
            },
            boundary_summary=dict(data["boundary_summary"]),
            plan_only=bool(data.get("plan_only", True)),
            fact_source=bool(data.get("fact_source", False)),
            full_daqc_state_handoff=bool(data.get("full_daqc_state_handoff", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> HybridTimelineVisualizationIR:
        """Build hybrid timeline visualization data from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError(
                "HybridTimelineVisualizationIR JSON must contain an object."
            )
        return cls.from_dict(data)


@dataclass(frozen=True)
class HybridTimelineReportSectionIR(IRMixin):
    """Metadata-only report section for review of a hybrid timeline plan."""

    section_id: str
    plan_id: str
    program_id: str
    plan_hash: str
    status: Literal["planned", "blocked"]
    execution_mode: Literal["plan_only"]
    block_order: tuple[str, ...]
    blocks: tuple[dict[str, Any], ...]
    mapping_summary: dict[str, Any]
    boundary_summary: dict[str, Any]
    unsupported_handoff_highlights: tuple[dict[str, Any], ...]
    visualization: HybridTimelineVisualizationIR
    metadata_only: bool = True
    plan_only: bool = True
    fact_source: bool = False
    full_daqc_state_handoff: bool = False
    backend_called: bool = False
    network_accessed: bool = False
    hardware_execution: bool = False
    cloud_execution: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> HybridTimelineReportSectionIR:
        """Build a hybrid timeline report section from a dictionary."""
        return cls(
            section_id=str(data["section_id"]),
            plan_id=str(data["plan_id"]),
            program_id=str(data["program_id"]),
            plan_hash=str(data["plan_hash"]),
            status=data["status"],
            execution_mode=data.get("execution_mode", "plan_only"),
            block_order=tuple(str(item) for item in data.get("block_order", ())),
            blocks=tuple(dict(block) for block in data.get("blocks", ())),
            mapping_summary=dict(data["mapping_summary"]),
            boundary_summary=dict(data["boundary_summary"]),
            unsupported_handoff_highlights=tuple(
                dict(highlight)
                for highlight in data.get("unsupported_handoff_highlights", ())
            ),
            visualization=HybridTimelineVisualizationIR.from_dict(
                data["visualization"]
            ),
            metadata_only=bool(data.get("metadata_only", True)),
            plan_only=bool(data.get("plan_only", True)),
            fact_source=bool(data.get("fact_source", False)),
            full_daqc_state_handoff=bool(data.get("full_daqc_state_handoff", False)),
            backend_called=bool(data.get("backend_called", False)),
            network_accessed=bool(data.get("network_accessed", False)),
            hardware_execution=bool(data.get("hardware_execution", False)),
            cloud_execution=bool(data.get("cloud_execution", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> HybridTimelineReportSectionIR:
        """Build a hybrid timeline report section from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError(
                "HybridTimelineReportSectionIR JSON must contain an object."
            )
        return cls.from_dict(data)


def build_register_visualization(
    program_or_register: ProgramIR | AtomRegisterIR | AtomRegister,
    *,
    visualization_id: str | None = None,
    title: str = "Atom register",
) -> RegisterVisualizationIR:
    """Build register visualization data from a program or register."""
    register, source_kind, source_id, source_hash = _register_source(
        program_or_register
    )
    sites = tuple(
        {
            "site_id": site.site_id,
            "atom_id": site.atom_id,
            "x": site.position[0],
            "y": site.position[1],
            "filled": site.is_active,
            "status": site.status,
            "is_target": site.is_target,
            "metadata": dict(site.metadata),
        }
        for site in register.sites
    )
    spec = VisualizationSpecIR(
        visualization_id=visualization_id or f"viz.register.{source_id}",
        visualization_kind="register",
        title=title,
        source_kind=source_kind,
        source_id=source_id,
        source_hash=source_hash,
        axes={
            "x": {"label": "x", "unit": register.coordinate_unit},
            "y": {"label": "y", "unit": register.coordinate_unit},
        },
        metadata={"data_role": "plot_data_not_source_of_truth"},
    )
    return RegisterVisualizationIR(
        spec=spec,
        coordinate_unit=register.coordinate_unit,
        sites=sites,
        metadata={
            "site_count": len(sites),
            "filled_count": sum(1 for site in sites if site["filled"]),
            "snapshot": register.snapshot_evidence(),
        },
    )


def build_pulse_timeline(
    program_or_compiled: ProgramIR | ReferenceCompiledProgramIR,
    *,
    visualization_id: str | None = None,
    title: str = "Pulse timeline",
) -> PulseTimelineVisualizationIR:
    """Build pulse timeline data from a ProgramIR or ReferenceCompiledProgramIR."""
    if isinstance(program_or_compiled, ProgramIR):
        source_kind = "ProgramIR"
        source_id = program_or_compiled.program_id
        source_hash = program_or_compiled.stable_hash()
        channels = _channels_from_program(program_or_compiled)
        time_unit = program_or_compiled.unit_conventions.time
    elif isinstance(program_or_compiled, ReferenceCompiledProgramIR):
        source_kind = "ReferenceCompiledProgramIR"
        source_id = program_or_compiled.compiled_program_id
        source_hash = program_or_compiled.stable_hash()
        channels = _channels_from_compiled(program_or_compiled)
        time_unit = str(program_or_compiled.compiled_schedule.get("time_unit", "us"))
    else:
        raise TypeError(
            "build_pulse_timeline accepts ProgramIR or ReferenceCompiledProgramIR."
        )
    spec = VisualizationSpecIR(
        visualization_id=visualization_id or f"viz.pulse_timeline.{source_id}",
        visualization_kind="pulse_timeline",
        title=title,
        source_kind=source_kind,
        source_id=source_id,
        source_hash=source_hash,
        axes={"time": {"label": "time", "unit": time_unit}},
        metadata={"data_role": "plot_data_not_source_of_truth"},
    )
    return PulseTimelineVisualizationIR(
        spec=spec,
        time_unit=time_unit,
        channels=channels,
        metadata={"channel_count": len(channels)},
    )


def build_counts_histogram(
    result: ResultIR,
    *,
    visualization_id: str | None = None,
    title: str = "Counts histogram",
) -> CountsHistogramVisualizationIR:
    """Build counts histogram data from a ResultIR."""
    if not isinstance(result, ResultIR):
        raise TypeError("build_counts_histogram accepts ResultIR.")
    shots = result.shots
    bars = tuple(
        {
            "bitstring": bitstring,
            "count": count,
            "probability": 0.0 if shots == 0 else count / shots,
        }
        for bitstring, count in sorted(result.counts.items())
    )
    spec = VisualizationSpecIR(
        visualization_id=visualization_id or f"viz.counts.{result.result_id}",
        visualization_kind="counts_histogram",
        title=title,
        source_kind="ResultIR",
        source_id=result.result_id,
        source_hash=result.stable_hash(),
        axes={
            "x": {"label": "bitstring"},
            "y": {"label": "count", "unit": "shots"},
        },
        metadata={"data_role": "plot_data_not_source_of_truth"},
    )
    return CountsHistogramVisualizationIR(
        spec=spec,
        shots=shots,
        bars=bars,
        metadata={
            "bar_count": len(bars),
            "bit_ordering": result.bit_ordering,
            "occupation_encoding": result.occupation_encoding.to_dict(),
        },
    )


def build_hybrid_timeline_visualization(
    plan: HybridSimulationPlanIR,
    *,
    visualization_id: str | None = None,
    title: str = "Hybrid timeline",
) -> HybridTimelineVisualizationIR:
    """Build plot-ready hybrid timeline data from a plan-only artifact."""
    blocks = _hybrid_timeline_blocks(plan)
    boundaries = _hybrid_timeline_boundaries(plan)
    summary = _hybrid_boundary_summary(plan)
    time_unit = _dominant_time_unit(blocks)
    spec = VisualizationSpecIR(
        visualization_id=visualization_id or f"viz.hybrid_timeline.{plan.plan_id}",
        visualization_kind="hybrid_timeline",
        title=title,
        source_kind="HybridSimulationPlanIR",
        source_id=plan.plan_id,
        source_hash=plan.stable_hash(),
        axes={
            "x": {"label": "time", "unit": time_unit},
            "y": {"label": "block order"},
        },
        metadata={
            "data_role": "rendered_plan_not_source_of_truth",
            "plan_only": True,
            "fact_source": False,
        },
    )
    return HybridTimelineVisualizationIR(
        spec=spec,
        time_unit=time_unit,
        blocks=blocks,
        boundaries=boundaries,
        mapping=dict(sorted(plan.mapping.items())),
        boundary_summary=summary,
        plan_only=True,
        fact_source=False,
        full_daqc_state_handoff=False,
        metadata={
            "block_count": len(blocks),
            "boundary_count": len(boundaries),
            "unsupported_handoff_count": summary["unsupported_handoff_count"],
            "offline_deterministic": True,
            "hardware_execution": False,
            "cloud_execution": False,
        },
    )


def build_hybrid_timeline_report_section(
    plan: HybridSimulationPlanIR,
    *,
    section_id: str | None = None,
) -> HybridTimelineReportSectionIR:
    """Build a metadata-only report section for a hybrid timeline plan."""
    visualization = build_hybrid_timeline_visualization(plan)
    unsupported = tuple(
        boundary
        for boundary in visualization.boundaries
        if bool(boundary["unsupported_handoff"])
    )
    status: Literal["planned", "blocked"] = "planned" if plan.executable else "blocked"
    return HybridTimelineReportSectionIR(
        section_id=section_id or f"hybrid_timeline_report.{plan.plan_id}",
        plan_id=plan.plan_id,
        program_id=plan.program_id,
        plan_hash=plan.stable_hash(),
        status=status,
        execution_mode=plan.execution_mode,
        block_order=tuple(str(block["block_id"]) for block in visualization.blocks),
        blocks=visualization.blocks,
        mapping_summary=_hybrid_mapping_summary(plan),
        boundary_summary=visualization.boundary_summary,
        unsupported_handoff_highlights=unsupported,
        visualization=visualization,
        metadata_only=True,
        plan_only=True,
        fact_source=False,
        full_daqc_state_handoff=False,
        backend_called=False,
        network_accessed=False,
        hardware_execution=False,
        cloud_execution=False,
        metadata={
            "source_kind": "HybridSimulationPlanIR",
            "visualization_id": visualization.spec.visualization_id,
            "offline_deterministic": True,
            "mixed_state_handoff_executed": False,
        },
    )


def _register_source(
    program_or_register: ProgramIR | AtomRegisterIR | AtomRegister,
) -> tuple[AtomRegisterIR, str, str, str | None]:
    if isinstance(program_or_register, ProgramIR):
        return (
            program_or_register.register,
            "ProgramIR",
            program_or_register.program_id,
            program_or_register.stable_hash(),
        )
    if isinstance(program_or_register, AtomRegisterIR):
        return (
            program_or_register,
            "AtomRegisterIR",
            program_or_register.metadata.get("register_id", "register"),
            program_or_register.stable_hash(),
        )
    if isinstance(program_or_register, AtomRegister):
        register = program_or_register.to_ir()
        return (
            register,
            "AtomRegister",
            register.metadata.get("register_id", "register"),
            register.stable_hash(),
        )
    raise TypeError(
        "build_register_visualization accepts ProgramIR, AtomRegisterIR, "
        "or AtomRegister."
    )


def _channels_from_program(program: ProgramIR) -> tuple[dict[str, Any], ...]:
    hamiltonian = program.hamiltonian
    channels = [
        _waveform_channel("rabi", hamiltonian.rabi),
        _waveform_channel("detuning", hamiltonian.detuning),
    ]
    if isinstance(hamiltonian.phase, WaveformIR):
        channels.append(_waveform_channel("phase", hamiltonian.phase))
    else:
        channels.append(
            {
                "channel_id": "phase",
                "source_path": "program.hamiltonian.phase",
                "value_unit": "rad",
                "segments": (
                    {
                        "start": 0.0,
                        "stop": max(
                            hamiltonian.rabi.duration,
                            hamiltonian.detuning.duration,
                        ),
                        "value": hamiltonian.phase,
                    },
                ),
            }
        )
    for index, detuning_term in enumerate(hamiltonian.local_detuning_terms):
        channel_id = f"local_detuning_{index}"
        channel = _waveform_channel(channel_id, detuning_term.waveform)
        channel.update(
            {
                "source_path": (
                    f"program.hamiltonian.local_detuning_terms[{index}].waveform"
                ),
                "site_ids": list(detuning_term.addressing.site_ids),
                "site_weights": list(detuning_term.addressing.weights[0]),
                "addressing_times": list(detuning_term.addressing.times),
                "addressing_weights": [
                    list(frame) for frame in detuning_term.addressing.weights
                ],
                "addressing_source_kind": detuning_term.addressing.source_kind,
                "addressing_hash": detuning_term.addressing.stable_hash(),
            }
        )
        channels.append(channel)
    for index, rabi_term in enumerate(hamiltonian.local_rabi_terms):
        # The amplitude channel carries addressing frames; phase remains a
        # separate channel because it can have an independent waveform.
        channel_id = f"local_rabi_{index}"
        channel = _waveform_channel(channel_id, rabi_term.rabi)
        channel.update(
            {
                "source_path": f"program.hamiltonian.local_rabi_terms[{index}].rabi",
                "site_ids": list(rabi_term.addressing.site_ids),
                "site_weights": list(rabi_term.addressing.weights[0]),
                "addressing_times": list(rabi_term.addressing.times),
                "addressing_weights": [
                    list(frame) for frame in rabi_term.addressing.weights
                ],
                "addressing_source_kind": rabi_term.addressing.source_kind,
                "addressing_hash": rabi_term.addressing.stable_hash(),
                "phase_pattern": rabi_term.phase_pattern.to_dict(),
                "phase_pattern_hash": rabi_term.phase_pattern.stable_hash(),
            }
        )
        channels.append(channel)
        phase_channel_id = f"local_rabi_phase_{index}"
        if isinstance(rabi_term.phase, WaveformIR):
            phase_channel = _waveform_channel(
                phase_channel_id,
                rabi_term.phase,
            )
            phase_channel["source_path"] = (
                f"program.hamiltonian.local_rabi_terms[{index}].phase"
            )
            channels.append(phase_channel)
        else:
            channels.append(
                {
                    "channel_id": phase_channel_id,
                    "source_path": (
                        f"program.hamiltonian.local_rabi_terms[{index}].phase"
                    ),
                    "value_unit": "rad",
                    "segments": (
                        {
                            "start": 0.0,
                            "stop": rabi_term.rabi.duration,
                            "value": rabi_term.phase,
                        },
                    ),
                }
            )
    return tuple(channels)


def _waveform_channel(channel_id: str, waveform: WaveformIR) -> dict[str, Any]:
    times = waveform.times or (0.0, waveform.duration)
    values = waveform.values or ()
    # Constant WaveformIR stores one value but its plot domain has two endpoints.
    # Repeat the value so a renderer draws a complete horizontal segment instead
    # of presenting the stop point as missing data.
    plotted_values = (
        tuple(values[0] for _ in times)
        if waveform.kind == "constant" and len(values) == 1
        else values
    )
    points = tuple(
        {
            "time": time,
            "value": (
                plotted_values[index] if index < len(plotted_values) else None
            ),
        }
        for index, time in enumerate(times)
    )
    return {
        "channel_id": channel_id,
        "waveform_id": waveform.waveform_id,
        "waveform_kind": waveform.kind,
        "source_path": f"program.hamiltonian.{channel_id}",
        "value_unit": waveform.value_unit,
        "time_unit": waveform.time_unit,
        "duration": waveform.duration,
        "points": points,
    }


def _channels_from_compiled(
    compiled_program: ReferenceCompiledProgramIR,
) -> tuple[dict[str, Any], ...]:
    schedule = compiled_program.compiled_schedule
    segments = schedule.get("segments", ())
    return (
        {
            "channel_id": "compiled_schedule",
            "source_path": "compiled_program.compiled_schedule",
            "time_unit": schedule.get("time_unit", "us"),
            "segments": tuple(dict(segment) for segment in segments)
            if isinstance(segments, list)
            else (),
        },
    )


def _json_mapping(data: dict[str, Any]) -> dict[str, Any]:
    """Return a mapping normalized to builder tuple containers."""
    normalized: dict[str, Any] = {}
    for key, value in data.items():
        if isinstance(value, (list, tuple)):
            normalized[key] = tuple(
                _json_mapping(item) if isinstance(item, dict) else item
                for item in value
            )
        elif isinstance(value, dict):
            normalized[key] = _json_mapping(value)
        else:
            normalized[key] = value
    return normalized


def _hybrid_timeline_blocks(
    plan: HybridSimulationPlanIR,
) -> tuple[dict[str, Any], ...]:
    timeline_by_id = {str(item.get("block_id")): dict(item) for item in plan.timeline}
    blocks: list[dict[str, Any]] = []
    for order, state in enumerate(plan.block_states):
        timeline = timeline_by_id.get(state.block_id, {})
        start_time = state.start_time
        if start_time is None:
            start_time = timeline.get("start_time")
        duration = state.duration
        if duration is None:
            duration = timeline.get("duration")
        blocks.append(
            {
                "order": order,
                "block_id": state.block_id,
                "block_type": state.block_type,
                "input_state_kind": state.input_state_kind,
                "output_state_kind": state.output_state_kind,
                "start_time": start_time,
                "duration": duration,
                "time_unit": state.time_unit or timeline.get("time_unit", "us"),
                "mapping": _block_mapping(plan.mapping, state.metadata),
                "metadata": dict(state.metadata),
            }
        )
    return tuple(blocks)


def _hybrid_timeline_boundaries(
    plan: HybridSimulationPlanIR,
) -> tuple[dict[str, Any], ...]:
    return tuple(
        {
            "boundary_id": boundary.boundary_id,
            "left_block_id": boundary.left_block_id,
            "right_block_id": boundary.right_block_id,
            "left_block_type": boundary.left_block_type,
            "right_block_type": boundary.right_block_type,
            "status": boundary.status,
            "code": boundary.code,
            "message": boundary.message,
            "object_path": boundary.object_path,
            "suggestion": boundary.suggestion,
            "unsupported_handoff": _is_unsupported_handoff(boundary.to_dict()),
            "left_output_state_kind": boundary.metadata.get("left_output_state_kind"),
            "right_input_state_kind": boundary.metadata.get("right_input_state_kind"),
            "metadata": dict(boundary.metadata),
        }
        for boundary in plan.boundary_diagnostics
    )


def _hybrid_boundary_summary(plan: HybridSimulationPlanIR) -> dict[str, Any]:
    by_status: dict[str, int] = {}
    by_code: dict[str, int] = {}
    unsupported_count = 0
    for boundary in plan.boundary_diagnostics:
        by_status[boundary.status] = by_status.get(boundary.status, 0) + 1
        by_code[boundary.code] = by_code.get(boundary.code, 0) + 1
        if _is_unsupported_handoff(boundary.to_dict()):
            unsupported_count += 1
    return {
        "total": len(plan.boundary_diagnostics),
        "by_status": {key: by_status[key] for key in sorted(by_status)},
        "by_code": {key: by_code[key] for key in sorted(by_code)},
        "unsupported_handoff_count": unsupported_count,
        "has_unsupported_handoff": unsupported_count > 0,
        "has_warning_or_error": any(
            boundary.status in {"warning", "error"}
            for boundary in plan.boundary_diagnostics
        ),
    }


def _hybrid_mapping_summary(plan: HybridSimulationPlanIR) -> dict[str, Any]:
    entries = [
        {"logical": key, "physical": value}
        for key, value in sorted(plan.mapping.items())
    ]
    return {
        "available": bool(entries),
        "entry_count": len(entries),
        "entries": entries,
    }


def _block_mapping(
    mapping: dict[str, str],
    metadata: dict[str, Any],
) -> dict[str, str]:
    if "qubits" in metadata and isinstance(metadata["qubits"], list):
        qubits = [str(qubit) for qubit in metadata["qubits"]]
        return {qubit: mapping[qubit] for qubit in qubits if qubit in mapping}
    return dict(sorted(mapping.items()))


def _dominant_time_unit(blocks: tuple[dict[str, Any], ...]) -> str:
    for block in blocks:
        unit = block.get("time_unit")
        if unit is not None:
            return str(unit)
    return "us"


def _is_unsupported_handoff(boundary: dict[str, Any]) -> bool:
    return boundary.get("code") == "HYBRID_STATE_HANDOFF_UNSUPPORTED" or (
        boundary.get("left_block_type") in {"analog", "digital"}
        and boundary.get("right_block_type") in {"analog", "digital"}
        and boundary.get("left_block_type") != boundary.get("right_block_type")
        and boundary.get("status") in {"warning", "error"}
    )
