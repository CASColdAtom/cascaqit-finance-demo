"""Compact report views derived from saved parameter-shift evidence."""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any

from cascaqit.algorithms import ObjectiveGradientIR, OptimizerTerminationIR

__all__ = ["build_gradient_report_payload"]


def build_gradient_report_payload(
    gradients: Sequence[ObjectiveGradientIR],
    *,
    termination: OptimizerTerminationIR,
) -> dict[str, Any] | None:
    """Summarize saved gradients without planning or executing new work."""
    if not gradients:
        return None
    first = gradients[0]
    plan = first.plan
    occurrence_by_id = {
        occurrence.occurrence_id: occurrence for occurrence in plan.occurrences
    }
    history: list[dict[str, Any]] = []
    for gradient in gradients:
        shift_evidence = []
        for pair in gradient.shift_pairs:
            occurrence = occurrence_by_id[pair.occurrence_id]
            shift_evidence.append(
                {
                    "occurrence_id": occurrence.occurrence_id,
                    "gate_index": occurrence.gate_index,
                    "gate_name": occurrence.gate_name,
                    "targets": list(occurrence.targets),
                    "affine_offset": occurrence.affine_offset,
                    "coefficients": dict(occurrence.coefficients),
                    "positive_energy": pair.positive_evaluation.energy,
                    "negative_energy": pair.negative_evaluation.energy,
                    "energy_difference": pair.energy_difference,
                    "gate_derivative": pair.gate_derivative,
                    "backend_execution_count": pair.backend_execution_count,
                }
            )
        history.append(
            {
                "gradient_index": gradient.gradient_index,
                "gradient_id": gradient.gradient_id,
                "gradient_hash": gradient.gradient_hash,
                "parameter_bind": dict(gradient.parameter_bind.values),
                "components": dict(gradient.gradient),
                "parameter_contributions": {
                    name: dict(contributions)
                    for name, contributions in gradient.parameter_contributions.items()
                },
                "l2_norm": gradient.l2_norm,
                "backend_execution_count": gradient.backend_execution_count,
                "shift_evidence": shift_evidence,
            }
        )
    return {
        "plan": {
            "method": plan.method,
            "plan_hash": plan.plan_hash,
            "source_circuit_hash": plan.source_circuit_hash,
            "hamiltonian_hash": plan.hamiltonian_hash,
            "parameter_names": list(plan.parameter_names),
            "occurrence_count": len(plan.occurrences),
            "shift": plan.shift,
            "prefactor": plan.prefactor,
            "expected_backend_execution_count": (plan.expected_backend_execution_count),
            "occurrences": [
                {
                    "occurrence_id": item.occurrence_id,
                    "gate_index": item.gate_index,
                    "gate_name": item.gate_name,
                    "targets": list(item.targets),
                    "affine_offset": item.affine_offset,
                    "coefficients": dict(item.coefficients),
                }
                for item in plan.occurrences
            ],
        },
        "cost": {
            "objective_evaluation_count": termination.nfev,
            "gradient_evaluation_count": termination.njev,
            "gradient_callback_count": len(gradients),
            "shift_job_count": sum(item.backend_execution_count for item in gradients),
            "backend_execution_count": termination.backend_execution_count,
        },
        "history": history,
    }
