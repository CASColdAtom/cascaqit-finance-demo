"""Discretization report IR models."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.native_ir.base import IRMixin
from cascaqit.native_ir.models import SCHEMA_VERSION

__all__ = ["DiscretizationFieldReport", "DiscretizationReport"]

DiscretizationPolicy = Literal["nearest", "floor", "ceil", "strict"]


@dataclass(frozen=True)
class DiscretizationFieldReport(IRMixin):
    """Single rounded field produced during program discretization."""

    path: str
    original_value: float
    discretized_value: float
    absolute_error: float
    unit: str


@dataclass(frozen=True)
class DiscretizationReport(IRMixin):
    """Structured report for ProgramIR discretization."""

    policy: DiscretizationPolicy
    original_program_hash: str
    discretized_program_hash: str
    field_reports: tuple[DiscretizationFieldReport, ...] = ()
    diagnostics: tuple[DiagnosticsIR, ...] = ()
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)
