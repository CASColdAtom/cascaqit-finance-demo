"""ProgramIR discretization against target grid resolutions."""

from __future__ import annotations

import math
from dataclasses import replace
from typing import Literal

from cascaqit.control import (
    ControlScheduleIR,
    ControlSystemIR,
    build_control_schedule,
    validate_control_schedule,
)
from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.discretization.models import (
    DiscretizationFieldReport,
    DiscretizationPolicy,
    DiscretizationReport,
)
from cascaqit.native_ir.models import (
    AtomRegisterIR,
    HamiltonianIR,
    ProgramIR,
    RegisterSiteIR,
    SiteAddressingIR,
    SitePhasePatternIR,
    WaveformIR,
)
from cascaqit.targets import TargetSpec

__all__ = ["discretize_program"]

NumberKind = Literal["coordinate", "time", "rabi", "detuning", "phase"]


def discretize_program(
    program: ProgramIR,
    target: TargetSpec,
    *,
    policy: DiscretizationPolicy,
) -> tuple[ProgramIR, DiscretizationReport]:
    """Discretize a ProgramIR to target grid resolutions."""
    if policy not in ("nearest", "floor", "ceil", "strict"):
        raise ValueError(f"Unsupported discretization policy: {policy}")

    context = _Context(target=target, policy=policy)
    _inspect_phase_pattern_ranges(program, context, value_kind="original")
    if policy == "strict":
        _inspect_program(program, context)
        _inspect_phase_pattern_ranges(
            program,
            context,
            value_kind="discretized",
            report_errors=False,
        )
        control_schedule = _control_schedule(program, context)
        metadata = _control_metadata(control_schedule)
        metadata.update(_phase_pattern_metadata(context))
        report = DiscretizationReport(
            policy=policy,
            original_program_hash=program.stable_hash(),
            discretized_program_hash=program.stable_hash(),
            diagnostics=tuple(context.diagnostics),
            metadata=metadata,
        )
        return program, report

    candidate = _round_program(program, context)
    candidate = replace(candidate, lifecycle_state="discretized")
    _inspect_phase_pattern_ranges(candidate, context, value_kind="discretized")
    candidate_control_schedule = _control_schedule(candidate, context)
    has_errors = any(
        diagnostic.severity in {"error", "critical"}
        for diagnostic in context.diagnostics
    )
    discretized = program if has_errors else candidate
    control_schedule = (
        _build_control_schedule_without_diagnostics(program, context)
        if has_errors
        else candidate_control_schedule
    )
    metadata = _control_metadata(control_schedule)
    metadata.update(_phase_pattern_metadata(context))
    if has_errors:
        metadata["candidate_control_schedule_ir"] = (
            candidate_control_schedule.to_dict()
        )
    report = DiscretizationReport(
        policy=policy,
        original_program_hash=program.stable_hash(),
        discretized_program_hash=discretized.stable_hash(),
        field_reports=tuple(context.field_reports),
        diagnostics=tuple(context.diagnostics),
        metadata=metadata,
    )
    return discretized, report


class _Context:
    """Mutable discretization context for accumulating reports."""

    def __init__(self, *, target: TargetSpec, policy: DiscretizationPolicy) -> None:
        self.target = target
        self.policy = policy
        self.field_reports: list[DiscretizationFieldReport] = []
        self.diagnostics: list[DiagnosticsIR] = []
        self.phase_pattern_range_checks: list[dict[str, object]] = []


def _control_schedule(
    program: ProgramIR,
    context: _Context,
) -> ControlScheduleIR:
    """Attach constraint results using discretization-stage diagnostics."""
    control_system = ControlSystemIR.from_target_spec(context.target)
    schedule = build_control_schedule(program, control_system)
    diagnostics = (
        *schedule.diagnostics,
        *validate_control_schedule(schedule, control_system, program),
    )
    stage_diagnostics = tuple(
        replace(diagnostic, stage="discretization") for diagnostic in diagnostics
    )
    # Full constraint evidence lives in report.metadata. The diagnostic stream
    # keeps its established meaning: only a control failure blocks rounding.
    context.diagnostics.extend(
        diagnostic
        for diagnostic in stage_diagnostics
        if diagnostic.severity == "error"
    )
    return replace(schedule, diagnostics=stage_diagnostics)


def _build_control_schedule_without_diagnostics(
    program: ProgramIR,
    context: _Context,
) -> ControlScheduleIR:
    control_system = ControlSystemIR.from_target_spec(context.target)
    schedule = build_control_schedule(program, control_system)
    diagnostics = (
        *schedule.diagnostics,
        *validate_control_schedule(schedule, control_system, program),
    )
    return replace(
        schedule,
        diagnostics=tuple(
            replace(diagnostic, stage="discretization")
            for diagnostic in diagnostics
        ),
    )


def _control_metadata(schedule: ControlScheduleIR) -> dict[str, object]:
    if not _schedule_evidence_relevant(schedule):
        return {}
    severities = {"info": 0, "warning": 0, "error": 0}
    for diagnostic in schedule.diagnostics:
        severities[diagnostic.severity] += 1
    return {
        "control_schedule_ir": schedule.to_dict(),
        "control_schedule_hash": schedule.stable_hash(),
        "control_constraint_summary": {
            "diagnostic_count": len(schedule.diagnostics),
            "severity_counts": severities,
            "production_scheduling_performed": False,
        },
    }


def _schedule_evidence_relevant(schedule: ControlScheduleIR) -> bool:
    return bool(schedule.diagnostics) or any(
        operation.channel_id.endswith(".local")
        for operation in schedule.operations
    )


def _inspect_program(program: ProgramIR, context: _Context) -> None:
    _round_register(program.register, context)
    _round_hamiltonian(program.hamiltonian, context)


def _round_program(program: ProgramIR, context: _Context) -> ProgramIR:
    return replace(
        program,
        register=_round_register(program.register, context),
        hamiltonian=_round_hamiltonian(program.hamiltonian, context),
    )


def _round_register(register: AtomRegisterIR, context: _Context) -> AtomRegisterIR:
    sites: list[RegisterSiteIR] = []
    for site_index, site in enumerate(register.sites):
        x, y = site.position
        rounded_x = _round_value(
            x,
            _resolution(context.target, "coordinate"),
            context,
            path=f"register.sites[{site_index}].position[0]",
            unit=context.target.coordinate_unit,
        )
        rounded_y = _round_value(
            y,
            _resolution(context.target, "coordinate"),
            context,
            path=f"register.sites[{site_index}].position[1]",
            unit=context.target.coordinate_unit,
        )
        sites.append(replace(site, position=(rounded_x, rounded_y)))
    return replace(register, sites=tuple(sites))


def _round_hamiltonian(
    hamiltonian: HamiltonianIR,
    context: _Context,
) -> HamiltonianIR:
    phase = hamiltonian.phase
    if isinstance(phase, WaveformIR):
        rounded_phase: WaveformIR | float = _round_waveform(
            phase,
            context,
            field_name="phase",
            value_kind="phase",
            value_unit="rad",
        )
    else:
        rounded_phase = _round_value(
            phase,
            _resolution(context.target, "phase"),
            context,
            path="hamiltonian.terms.phase",
            unit="rad",
        )
    rounded_local_detuning_terms = tuple(
        replace(
            term,
            waveform=_round_waveform(
                term.waveform,
                context,
                field_name=f"local_detuning_terms[{index}].waveform",
                value_kind="detuning",
                value_unit=context.target.frequency_unit,
            ),
            addressing=_round_site_addressing(
                term.addressing,
                context,
                field_name=f"local_detuning_terms[{index}].addressing",
            ),
        )
        for index, term in enumerate(hamiltonian.local_detuning_terms)
    )
    rounded_local_rabi_terms = []
    for index, term in enumerate(hamiltonian.local_rabi_terms):
        local_phase = term.phase
        rounded_local_phase: WaveformIR | float
        if isinstance(local_phase, WaveformIR):
            rounded_local_phase = _round_waveform(
                local_phase,
                context,
                field_name=f"local_rabi_terms[{index}].phase",
                value_kind="phase",
                value_unit="rad",
            )
        else:
            rounded_local_phase = _round_value(
                local_phase,
                _resolution(context.target, "phase"),
                context,
                path=f"hamiltonian.terms.local_rabi_terms[{index}].phase",
                unit="rad",
            )
        rounded_local_rabi_terms.append(
            replace(
                term,
                rabi=_round_waveform(
                    term.rabi,
                    context,
                    field_name=f"local_rabi_terms[{index}].rabi",
                    value_kind="rabi",
                    value_unit=context.target.frequency_unit,
                ),
                phase=rounded_local_phase,
                addressing=_round_site_addressing(
                    term.addressing,
                    context,
                    field_name=f"local_rabi_terms[{index}].addressing",
                ),
                phase_pattern=_round_site_phase_pattern(
                    term.phase_pattern,
                    context,
                    field_name=f"local_rabi_terms[{index}].phase_pattern",
                ),
            )
        )
    return replace(
        hamiltonian,
        rabi=_round_waveform(
            hamiltonian.rabi,
            context,
            field_name="rabi",
            value_kind="rabi",
            value_unit=context.target.frequency_unit,
        ),
        detuning=_round_waveform(
            hamiltonian.detuning,
            context,
            field_name="detuning",
            value_kind="detuning",
            value_unit=context.target.frequency_unit,
        ),
        phase=rounded_phase,
        local_detuning_terms=rounded_local_detuning_terms,
        local_rabi_terms=tuple(rounded_local_rabi_terms),
    )


def _round_site_phase_pattern(
    pattern: SitePhasePatternIR,
    context: _Context,
    *,
    field_name: str,
) -> SitePhasePatternIR:
    """Round every static offset on the target phase grid."""
    return replace(
        pattern,
        offsets=tuple(
            _round_value(
                offset,
                _resolution(context.target, "phase"),
                context,
                path=(
                    f"hamiltonian.terms.{field_name}.offsets[{index}]"
                ),
                unit="rad",
            )
            for index, offset in enumerate(pattern.offsets)
        ),
    )


def _inspect_phase_pattern_ranges(
    program: ProgramIR,
    context: _Context,
    *,
    value_kind: str,
    report_errors: bool = True,
) -> None:
    """Record pre/post range evidence for offsets and applied site phases."""
    lower, upper = context.target.phase_range
    for term_index, term in enumerate(program.hamiltonian.local_rabi_terms):
        shared_values = (
            _waveform_values(term.phase)
            if isinstance(term.phase, WaveformIR)
            else (float(term.phase),)
        )
        for site_index, (site_id, offset) in enumerate(
            zip(term.phase_pattern.site_ids, term.phase_pattern.offsets)
        ):
            site_phases = tuple(value + offset for value in shared_values)
            valid = lower <= offset <= upper and all(
                lower <= value <= upper for value in site_phases
            )
            path = (
                "hamiltonian.terms.local_rabi_terms"
                f"[{term_index}].phase_pattern.offsets[{site_index}]"
            )
            context.phase_pattern_range_checks.append(
                {
                    "value_kind": value_kind,
                    "path": path,
                    "site_id": site_id,
                    "offset": offset,
                    "site_phase_values": list(site_phases),
                    "range": [lower, upper],
                    "unit": "rad",
                    "valid": valid,
                }
            )
            if report_errors and not valid:
                context.diagnostics.append(
                    DiagnosticsIR(
                        diagnostic_id=(
                            "discretization.local_rabi_phase_pattern_range."
                            f"{value_kind}.{term_index}.{site_index}"
                        ),
                        stage="discretization",
                        severity="error",
                        code="DISCRETIZATION_LOCAL_RABI_SITE_PHASE_OUT_OF_RANGE",
                        message=(
                            f"{value_kind} local Rabi phase for site {site_id!r} "
                            "is outside the target phase range."
                        ),
                        object_path=path,
                        suggestion=(
                            "Adjust the shared phase or site offset before "
                            "discretization; phases are not wrapped."
                        ),
                        metadata={
                            "value_kind": value_kind,
                            "offset": offset,
                            "site_phase_values": list(site_phases),
                            "range": [lower, upper],
                            "unit": "rad",
                        },
                    )
                )


def _phase_pattern_metadata(context: _Context) -> dict[str, object]:
    if not context.phase_pattern_range_checks:
        return {}
    return {
        "phase_pattern_range_checks": list(context.phase_pattern_range_checks),
        "phase_pattern_range_checked_before_and_after": True,
    }


def _waveform_values(waveform: WaveformIR) -> tuple[float, ...]:
    """Return bound waveform values for static range inspection."""
    if waveform.values is not None:
        return tuple(float(value) for value in waveform.values)
    if "bound_value" in waveform.parameters:
        return (float(waveform.parameters["bound_value"]),)
    return (float(waveform.parameters.get("value", 0.0)),)


def _round_waveform(
    waveform: WaveformIR,
    context: _Context,
    *,
    field_name: str,
    value_kind: NumberKind,
    value_unit: str,
) -> WaveformIR:
    times = None
    if waveform.times is not None:
        times = tuple(
            _round_value(
                value,
                _resolution(context.target, "time"),
                context,
                path=f"hamiltonian.terms.{field_name}.times[{index}]",
                unit=context.target.time_unit,
            )
            for index, value in enumerate(waveform.times)
        )
    values = None
    if waveform.values is not None:
        values = tuple(
            _round_value(
                value,
                _resolution(context.target, value_kind),
                context,
                path=f"hamiltonian.terms.{field_name}.values[{index}]",
                unit=value_unit,
            )
            for index, value in enumerate(waveform.values)
        )
    duration = _round_value(
        waveform.duration,
        _resolution(context.target, "time"),
        context,
        path=f"hamiltonian.terms.{field_name}.duration",
        unit=context.target.time_unit,
    )
    return replace(waveform, duration=duration, times=times, values=values)


def _round_site_addressing(
    addressing: SiteAddressingIR,
    context: _Context,
    *,
    field_name: str,
) -> SiteAddressingIR:
    """Round frame times atomically, rejecting collisions or overflow."""
    duration = _round_value(
        addressing.duration,
        _resolution(context.target, "time"),
        context,
        path=f"hamiltonian.terms.{field_name}.duration",
        unit=context.target.time_unit,
    )
    times = tuple(
        _round_value(
            value,
            _resolution(context.target, "time"),
            context,
            path=f"hamiltonian.terms.{field_name}.times[{index}]",
            unit=context.target.time_unit,
        )
        for index, value in enumerate(addressing.times)
    )
    if context.policy == "strict":
        return addressing

    collision_indices = [
        index
        for index, (left, right) in enumerate(zip(times, times[1:]), start=1)
        if right <= left
    ]
    overflow_indices = [
        index for index, value in enumerate(times) if value < 0.0 or value >= duration
    ]
    if collision_indices or overflow_indices:
        if collision_indices:
            code = "DISCRETIZATION_ADDRESSING_TIME_COLLISION"
            message = "Addressing frame times collide after discretization."
        else:
            code = "DISCRETIZATION_ADDRESSING_TIME_OUT_OF_RANGE"
            message = "Addressing frame time is outside the rounded duration."
        context.diagnostics.append(
            DiagnosticsIR(
                diagnostic_id=code.lower().replace("_", "."),
                stage="discretization",
                severity="error",
                code=code,
                message=message,
                object_path=f"hamiltonian.terms.{field_name}.times",
                suggestion=(
                    "Increase frame spacing, change the time grid, or use strict "
                    "to inspect non-representable values."
                ),
                metadata={
                    "policy": context.policy,
                    "resolution": _resolution(context.target, "time"),
                    "original_duration": addressing.duration,
                    "candidate_duration": duration,
                    "original_times": list(addressing.times),
                    "candidate_times": list(times),
                    "collision_indices": collision_indices,
                    "out_of_range_indices": overflow_indices,
                    "unit": context.target.time_unit,
                },
            )
        )
        return addressing
    return replace(addressing, duration=duration, times=times)


def _round_value(
    value: float,
    resolution: float,
    context: _Context,
    *,
    path: str,
    unit: str,
) -> float:
    rounded = _apply_rounding(value, resolution, context.policy)
    absolute_error = round(abs(rounded - value), 12)
    if absolute_error <= 1e-12:
        return value

    if context.policy == "strict":
        context.diagnostics.append(
            DiagnosticsIR(
                diagnostic_id="discretization.strict_grid_mismatch",
                stage="discretization",
                severity="error",
                code="DISCRETIZATION_STRICT_GRID_MISMATCH",
                message=f"{path}={value} is not representable on grid {resolution}.",
                object_path=path,
                suggestion="Use nearest, floor, or ceil, or provide a grid value.",
                metadata={
                    "absolute_error": absolute_error,
                    "candidate_value": rounded,
                    "resolution": resolution,
                    "unit": unit,
                },
            )
        )
        return value

    context.field_reports.append(
        DiscretizationFieldReport(
            path=path,
            original_value=value,
            discretized_value=rounded,
            absolute_error=absolute_error,
            unit=unit,
        )
    )
    return rounded


def _apply_rounding(
    value: float,
    resolution: float,
    policy: DiscretizationPolicy,
) -> float:
    scaled = value / resolution
    if policy == "floor":
        rounded = math.floor(scaled) * resolution
    elif policy == "ceil":
        rounded = math.ceil(scaled) * resolution
    else:
        rounded = round(scaled) * resolution
    return round(rounded, 12)


def _resolution(target: TargetSpec, kind: NumberKind) -> float:
    if kind == "coordinate":
        return float(target.metadata["coordinate_resolution"])
    if kind == "time":
        return target.time_resolution
    if kind == "rabi":
        return target.amplitude_resolution
    if kind == "detuning":
        return target.detuning_resolution
    return target.phase_resolution
