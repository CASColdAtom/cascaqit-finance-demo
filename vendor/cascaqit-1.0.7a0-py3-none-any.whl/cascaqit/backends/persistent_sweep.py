"""Persistent child-granular controller for local Hybrid sweeps."""

from __future__ import annotations

import os
import secrets
import time
from collections import Counter
from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from typing import NoReturn, cast

from cascaqit.backends.job_history import (
    JobAttemptIR,
    JobAttemptOutcomeIR,
    JobDefinitionIR,
    JobErrorRefIR,
    PersistedJobFailure,
)
from cascaqit.backends.job_store import SQLiteJobStore, StoredSweepChild
from cascaqit.backends.persistent_execution import _error_ref, _not_before
from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.exceptions import CASCAQitRuntimeError
from cascaqit.parameters import ParameterBindIR, ParameterScan
from cascaqit.results import (
    ResultReferencesIR,
    RunTraceEventIR,
    RunTraceIR,
    simulation_solver_evidence_from_metadata,
)
from cascaqit.results.resource_usage import LocalResourceMeasurement
from cascaqit.simulators.execution_evidence import (
    aggregate_solver_evidence,
    execution_config_metadata,
)
from cascaqit.simulators.local_hybrid import (
    LocalHybridScanFailurePolicy,
    LocalHybridScanItemOutcome,
    LocalHybridScanJobResult,
    LocalHybridScanJobStatusIR,
)
from cascaqit.simulators.planning import (
    SimulationExecutionPlan,
    SweepResourcePlanIR,
)

__all__ = ["PersistentLocalHybridScanJob"]


class PersistentLocalHybridScanJob:
    """Lazy sweep Job that commits every child before building its aggregate."""

    def __init__(
        self,
        *,
        store: SQLiteJobStore,
        definition: JobDefinitionIR,
        child_runner_factory: Callable[[StoredSweepChild], LocalHybridScanItemOutcome],
        clock: Callable[[], str] | None = None,
        sleeper: Callable[[float], None] | None = None,
        lease_seconds: float = 300.0,
    ) -> None:
        if definition.job_kind != "sweep":
            raise ValueError("persistent sweep controller requires a sweep definition.")
        spec = definition.scan_spec()
        if spec is None:
            raise ValueError("persistent sweep definition requires scan_spec.")
        self.store = store
        self.definition = definition
        self.job_id = definition.job_id
        self.backend_id = definition.backend_id
        self.program_kind = definition.program_kind
        self.program_hash = definition.program_hash
        self.scan = ParameterScan.from_dict(cast(dict[str, object], spec["scan"]))
        self.parameter_schema_hash = str(spec["parameter_schema_hash"])
        self.plan_hash = str(spec["plan_hash"])
        self.graph_hash = str(spec["graph_hash"])
        self.resource_plan = SweepResourcePlanIR.from_dict(
            cast(dict[str, object], spec["resource_plan"])
        )
        self.failure_policy = cast(
            LocalHybridScanFailurePolicy,
            definition.execution_spec()["failure_policy"],
        )
        self.execution_metadata = dict(spec.get("execution_metadata", {}))
        self.bind_sets = tuple(
            ParameterBindIR.from_json(child.bind_set_json)
            for child in store.load_sweep_children(self.job_id)
        )
        self._child_runner_factory = child_runner_factory
        self._clock: Callable[[], str]
        if clock is None:
            self._clock = lambda: _not_before(_utc_now(), definition.created_at)
        else:
            self._clock = clock
        self._sleeper = time.sleep if sleeper is None else sleeper
        self._lease_seconds = lease_seconds
        self._owner_id = f"process-{os.getpid()}-{secrets.token_hex(8)}"

    def status(self) -> LocalHybridScanJobStatusIR:
        state = self.store.load_state(self.job_id)
        children = self.store.load_sweep_children(self.job_id)
        counts = Counter(child.status for child in children)
        return LocalHybridScanJobStatusIR(
            job_id=self.job_id,
            scan_id=self.scan.scan_id,
            state=state.status,
            failure_policy=self.failure_policy,
            total_items=len(children),
            pending_count=counts["pending"],
            running_count=counts["running"],
            completed_count=counts["completed"],
            failed_count=counts["failed"],
            not_run_count=counts["not_run"],
            cancelled_count=counts["cancelled"],
            message=f"Persistent local Hybrid sweep is {state.status}.",
        )

    def result(self) -> LocalHybridScanJobResult:
        """Execute pending child attempts and return the stable ordered aggregate."""
        terminal = self._load_terminal_result()
        if terminal is not None:
            return terminal
        state = self.store.load_state(self.job_id)
        if state.status in {"cancelled", "expired"}:
            raise CASCAQitRuntimeError(
                f"{state.status.capitalize()} persistent local sweep has no result.",
                code=(
                    "LOCAL_HYBRID_SCAN_JOB_CANCELLED"
                    if state.status == "cancelled"
                    else "LOCAL_HYBRID_SCAN_JOB_EXPIRED"
                ),
                stage="backend",
            )

        measurement = LocalResourceMeasurement.start()
        while True:
            state = self.store.load_state(self.job_id)
            if state.status == "running":
                stored_attempts = self.store.list_outcomes(self.job_id)
                if (
                    not stored_attempts
                    or stored_attempts[-1].attempt_index < state.attempt_count
                ):
                    self._recover_interrupted_parent(state.attempt_count)
                    continue
            if state.status == "failed":
                terminal = self._load_terminal_result()
                if terminal is not None:
                    return terminal
                self._raise_persisted_failure()

            attempt_index = state.attempt_count + 1
            started_at = self._clock()
            claim = self.store.acquire_claim(
                self.job_id,
                owner_id=self._owner_id,
                now=started_at,
                lease_seconds=self._lease_seconds,
            )
            self.store.start_attempt(
                JobAttemptIR(
                    job_id=self.job_id,
                    attempt_index=attempt_index,
                    claim_token_hash=claim.token_hash,
                    definition_hash=self.definition.definition_hash,
                    program_hash=self.program_hash,
                    parameter_bind_hash=None,
                    seed=int(self.definition.execution_spec()["seed"]),
                    started_at=started_at,
                ),
                claim_token=claim.token,
            )
            try:
                outcomes = self._execute_pending_children()
                aggregate = self._build_aggregate(outcomes, measurement)
            except Exception as exc:
                finished_at = self._clock()
                error_ref = _error_ref(
                    self.job_id,
                    attempt_index,
                    exc,
                    policy_override=None,
                    created_at=finished_at,
                )
                can_resume = attempt_index < len(
                    self.store.load_sweep_children(self.job_id)
                ) + 1
                self.store.finish_failure(
                    error_ref,
                    JobAttemptOutcomeIR(
                        job_id=self.job_id,
                        attempt_index=attempt_index,
                        status=(
                            "retryable_failure"
                            if error_ref.retryable
                            else "non_retryable_failure"
                        ),
                        finished_at=finished_at,
                        error_ref_id=error_ref.error_ref_id,
                    ),
                    claim_token=claim.token,
                    terminal=not (error_ref.retryable and can_resume),
                )
                if error_ref.retryable and can_resume:
                    continue
                raise

            finished_at = self._clock()
            result_ref = self.store.results.write(
                aggregate,
                job_id=self.job_id,
                attempt_index=attempt_index,
                created_at=finished_at,
            )
            failed = aggregate.status.failed_count
            if failed == 0:
                self.store.finish_success(
                    result_ref,
                    JobAttemptOutcomeIR(
                        job_id=self.job_id,
                        attempt_index=attempt_index,
                        status="completed",
                        finished_at=finished_at,
                        result_ref_id=result_ref.ref_id,
                    ),
                    claim_token=claim.token,
                )
            elif aggregate.status.completed_count > 0:
                self.store.finish_success(
                    result_ref,
                    JobAttemptOutcomeIR(
                        job_id=self.job_id,
                        attempt_index=attempt_index,
                        status="completed",
                        finished_at=finished_at,
                        result_ref_id=result_ref.ref_id,
                    ),
                    claim_token=claim.token,
                    terminal_state="partially_completed",
                )
            else:
                self.store.finish_sweep_failure(
                    result_ref,
                    self._parent_sweep_error(attempt_index, finished_at),
                    claim_token=claim.token,
                )
            return aggregate

    def cancel(self) -> None:
        self.store.cancel(self.job_id, event_time=self._clock())

    @property
    def diagnostics(self) -> tuple[DiagnosticsIR, ...]:
        """Return persisted terminal diagnostics without starting execution."""
        terminal = self._load_terminal_result()
        return () if terminal is None else terminal.diagnostics

    @property
    def trace(self) -> RunTraceIR | None:
        """Return the persisted aggregate trace without starting execution."""
        terminal = self._load_terminal_result()
        return None if terminal is None else terminal.trace

    def _execute_pending_children(self) -> tuple[LocalHybridScanItemOutcome, ...]:
        children = self.store.load_sweep_children(self.job_id)
        if self.failure_policy == "fail_fast":
            for child in children:
                if child.status in {"completed", "not_run"}:
                    continue
                if child.status == "failed":
                    self.store.mark_sweep_children_not_run(
                        self.job_id,
                        after_index=child.scan_index,
                        event_time=self._clock(),
                    )
                    break
                outcome = self._execute_child(child)
                if outcome.state == "failed":
                    self.store.mark_sweep_children_not_run(
                        self.job_id,
                        after_index=child.scan_index,
                        event_time=self._clock(),
                    )
                    break
        else:
            pending = tuple(child for child in children if child.status == "pending")
            workers = self.resource_plan.selected_workers
            with ThreadPoolExecutor(max_workers=workers) as executor:
                tuple(executor.map(self._execute_child, pending))
        terminal_children = self.store.load_sweep_children(self.job_id)
        return tuple(self._outcome_from_child(child) for child in terminal_children)

    def _execute_child(self, child: StoredSweepChild) -> LocalHybridScanItemOutcome:
        policy = self.definition.retry_policy
        while True:
            started_at = self._clock()
            attempt_index = self.store.start_sweep_child_attempt(
                self.job_id,
                child.scan_index,
                started_at=started_at,
            )
            try:
                outcome = self._child_runner_factory(child)
            except Exception as exc:
                finished_at = self._clock()
                code = getattr(exc, "code", type(exc).__name__.upper())
                error_ref = _error_ref(
                    child.child_id,
                    attempt_index,
                    exc,
                    policy_override=policy.is_retryable_code(code),
                    created_at=finished_at,
                )
                retry = error_ref.retryable and attempt_index < policy.max_attempts
                self.store.finish_sweep_child_failure(
                    self.job_id,
                    child.scan_index,
                    attempt_index=attempt_index,
                    error_ref=error_ref,
                    retry=retry,
                    finished_at=finished_at,
                )
                if retry:
                    self._sleeper(policy.attempt_backoff_seconds(attempt_index + 1))
                    continue
                return self._failed_outcome(child, error_ref)
            artifact_ref = self.store.results.write_sweep_item(outcome)
            self.store.finish_sweep_child_success(
                self.job_id,
                child.scan_index,
                attempt_index=attempt_index,
                artifact_ref=artifact_ref,
                finished_at=self._clock(),
            )
            return outcome

    def _outcome_from_child(
        self,
        child: StoredSweepChild,
    ) -> LocalHybridScanItemOutcome:
        bind_set = ParameterBindIR.from_json(child.bind_set_json)
        if child.status == "completed":
            if child.artifact_ref is None:
                raise CASCAQitRuntimeError(
                    "Completed sweep child has no artifact reference.",
                    code="JOB_SWEEP_CHILD_ARTIFACT_MISSING",
                    stage="backend",
                )
            outcome = self.store.results.read_sweep_item(child.artifact_ref)
            if outcome.scan_index != child.scan_index or outcome.bind_set != bind_set:
                raise CASCAQitRuntimeError(
                    "Sweep child artifact identity drifted from its definition.",
                    code="JOB_SWEEP_CHILD_IDENTITY_MISMATCH",
                    stage="backend",
                )
            return outcome
        if child.status == "failed":
            if child.error_json is None:
                raise CASCAQitRuntimeError(
                    "Failed sweep child has no error evidence.",
                    code="JOB_SWEEP_CHILD_ERROR_MISSING",
                    stage="backend",
                )
            return self._failed_outcome(
                child,
                JobErrorRefIR.from_json(child.error_json),
            )
        if child.status == "not_run":
            return LocalHybridScanItemOutcome(
                scan_index=child.scan_index,
                bind_set=bind_set,
                state="not_run",
            )
        raise CASCAQitRuntimeError(
            "Sweep aggregate cannot be built from a non-terminal child.",
            code="JOB_SWEEP_CHILD_NON_TERMINAL",
            stage="backend",
        )

    def _failed_outcome(
        self,
        child: StoredSweepChild,
        error_ref: JobErrorRefIR,
    ) -> LocalHybridScanItemOutcome:
        bind_set = ParameterBindIR.from_json(child.bind_set_json)
        diagnostic = DiagnosticsIR(
            diagnostic_id=f"persistent-sweep.{self.job_id}.{child.scan_index}.failed",
            stage="simulation",
            severity="error",
            code=error_ref.code,
            message=error_ref.message,
            object_path=f"parameter_scans.{self.scan.scan_id}.points[{child.scan_index}]",
            metadata={"scan_index": child.scan_index},
        )
        trace = RunTraceIR(
            trace_id=f"trace.{child.child_id}.failed",
            events=(
                RunTraceEventIR(
                    stage="failed",
                    event_time=f"logical:item:{child.scan_index:06d}:failure",
                    status="error",
                    message="Persistent Hybrid sweep child failed.",
                ),
            ),
            references=ResultReferencesIR(
                program_hash=child.program_hash,
                plan_hash=self.plan_hash,
                metadata={"parameter_bind_hash": child.bind_hash},
            ),
        )
        return LocalHybridScanItemOutcome(
            scan_index=child.scan_index,
            bind_set=bind_set,
            state="failed",
            job_id=child.child_id,
            bundle_id=f"persistent-sweep-bundle.{child.child_id}",
            diagnostics=(diagnostic,),
            trace=trace,
            metadata={
                "parameter_bind_hash": child.bind_hash,
                "failure_code": error_ref.code,
            },
        )

    def _build_aggregate(
        self,
        outcomes: tuple[LocalHybridScanItemOutcome, ...],
        measurement: LocalResourceMeasurement,
    ) -> LocalHybridScanJobResult:
        counts = Counter(item.state for item in outcomes)
        if counts["failed"] == 0:
            state = "completed"
        elif counts["completed"]:
            state = "partially_completed"
        else:
            state = "failed"
        status = LocalHybridScanJobStatusIR(
            job_id=self.job_id,
            scan_id=self.scan.scan_id,
            state=cast(object, state),  # type: ignore[arg-type]
            failure_policy=self.failure_policy,
            total_items=len(outcomes),
            pending_count=0,
            running_count=0,
            completed_count=counts["completed"],
            failed_count=counts["failed"],
            not_run_count=counts["not_run"],
            cancelled_count=0,
            message=f"Persistent local Hybrid sweep {state}.",
        )
        diagnostics = tuple(
            item for outcome in outcomes for item in outcome.diagnostics
        )
        trace = self._aggregate_trace(status, outcomes)
        metadata = {
            "execution_mode": "persistent_resource_bounded_scan",
            "failure_policy": self.failure_policy,
            "run_count": len(outcomes),
            "scan_resource_plan": self.resource_plan.to_dict(),
            "backend_called": True,
            "network_accessed": False,
            "execution_package_created": False,
            "quantum_state_shared_across_items": False,
            **self.execution_metadata,
        }
        raw_plan = metadata.get("simulation_plan")
        item_evidences = tuple(
            evidence
            for outcome in outcomes
            if outcome.result is not None
            for evidence in (
                simulation_solver_evidence_from_metadata(outcome.result.metadata),
            )
            if evidence is not None
        )
        if isinstance(raw_plan, dict) and item_evidences:
            execution_plan = SimulationExecutionPlan.from_dict(raw_plan)
            aggregate_evidence = aggregate_solver_evidence(
                item_evidences,
                integrator_requested=execution_plan.integrator_requested,
                integrator_selected=execution_plan.integrator_selected,
                aggregation_scope="persistent_scan_items",
            )
            metadata.update(
                execution_config_metadata(
                    execution_plan,
                    aggregate_evidence,
                    workers=self.resource_plan.selected_workers,
                    seed=self.resource_plan.root_seed,
                    execution_scope="scan",
                )
            )
        metadata["simulation_resource_usage"] = measurement.finish(
            measurement_scope="scan",
            estimated_peak_bytes=self.resource_plan.estimated_peak_bytes,
        ).to_dict()
        return LocalHybridScanJobResult(
            job_id=self.job_id,
            scan_id=self.scan.scan_id,
            plan_hash=self.plan_hash,
            parameter_scan_hash=self.scan.stable_hash(),
            parameter_schema_hash=self.parameter_schema_hash,
            status=status,
            items=outcomes,
            diagnostics=diagnostics,
            trace=trace,
            metadata=metadata,
        )

    def _aggregate_trace(
        self,
        status: LocalHybridScanJobStatusIR,
        outcomes: tuple[LocalHybridScanItemOutcome, ...],
    ) -> RunTraceIR:
        events = (
            RunTraceEventIR(
                stage="queued",
                event_time="logical:scan:queued",
                status="ok",
                message="Persistent local Hybrid sweep was queued.",
            ),
            *(
                RunTraceEventIR(
                    stage="completed" if item.state == "completed" else "failed",
                    event_time=f"logical:item:{item.scan_index:06d}",
                    status={
                        "completed": "ok",
                        "failed": "error",
                        "not_run": "skipped",
                    }[item.state],
                    message=f"Persistent sweep child {item.state}.",
                    metadata={"scan_index": item.scan_index, "item_state": item.state},
                )
                for item in outcomes
            ),
            RunTraceEventIR(
                stage="failed" if status.state == "failed" else "completed",
                event_time="logical:scan:terminal",
                status={
                    "completed": "ok",
                    "partially_completed": "warning",
                    "failed": "error",
                }[status.state],
                message=f"Persistent local Hybrid sweep {status.state}.",
            ),
        )
        return RunTraceIR(
            trace_id=f"trace.{self.job_id}",
            events=events,
            references=ResultReferencesIR(
                program_hash=self.program_hash,
                plan_hash=self.plan_hash,
                metadata={
                    "graph_hash": self.graph_hash,
                    "parameter_scan_hash": self.scan.stable_hash(),
                    "parameter_schema_hash": self.parameter_schema_hash,
                },
            ),
            metadata={
                "execution_mode": "persistent_resource_bounded_scan",
                "scan_id": self.scan.scan_id,
                "job_id": self.job_id,
                "failure_policy": self.failure_policy,
                "selected_workers": self.resource_plan.selected_workers,
                "backend_id": self.backend_id,
                "backend_called": True,
            },
        )

    def _recover_interrupted_parent(self, attempt_index: int) -> None:
        event_time = self._clock()
        claim = self.store.acquire_claim(
            self.job_id,
            owner_id=self._owner_id,
            now=event_time,
            lease_seconds=self._lease_seconds,
        )
        for child in self.store.load_sweep_children(self.job_id):
            if child.status != "running":
                continue
            error = JobErrorRefIR(
                error_ref_id=f"error-ref.{child.child_id}.{child.attempt_count}.interrupted",
                job_id=child.child_id,
                attempt_index=child.attempt_count,
                category="backend",
                code="JOB_SWEEP_CHILD_INTERRUPTED",
                message="Previous process stopped before committing the child outcome.",
                retryable=True,
                exception_type="InterruptedProcess",
                created_at=event_time,
            )
            self.store.finish_sweep_child_failure(
                self.job_id,
                child.scan_index,
                attempt_index=child.attempt_count,
                error_ref=error,
                retry=child.attempt_count < self.definition.retry_policy.max_attempts,
                finished_at=event_time,
            )
        parent_error = JobErrorRefIR(
            error_ref_id=f"error-ref.{self.job_id}.{attempt_index}.interrupted",
            job_id=self.job_id,
            attempt_index=attempt_index,
            category="backend",
            code="JOB_ATTEMPT_INTERRUPTED",
            message="Previous process stopped before committing the sweep aggregate.",
            retryable=True,
            exception_type="InterruptedProcess",
            created_at=event_time,
        )
        self.store.finish_failure(
            parent_error,
            JobAttemptOutcomeIR(
                job_id=self.job_id,
                attempt_index=attempt_index,
                status="interrupted",
                finished_at=event_time,
                error_ref_id=parent_error.error_ref_id,
            ),
            claim_token=claim.token,
            terminal=False,
        )

    def _load_terminal_result(self) -> LocalHybridScanJobResult | None:
        state = self.store.load_state(self.job_id)
        if state.status not in {"completed", "partially_completed", "failed"}:
            return None
        ref = self.store.load_result_ref(self.job_id)
        if ref is None:
            return None
        result = self.store.results.read(ref)
        if not isinstance(result, LocalHybridScanJobResult):
            raise CASCAQitRuntimeError(
                "Persistent sweep restored a non-sweep Result artifact.",
                code="JOB_RESULT_KIND_MISMATCH",
                stage="backend",
            )
        return result

    def _parent_sweep_error(
        self,
        attempt_index: int,
        created_at: str,
    ) -> JobErrorRefIR:
        return JobErrorRefIR(
            error_ref_id=f"error-ref.{self.job_id}.{attempt_index}.sweep-failed",
            job_id=self.job_id,
            attempt_index=attempt_index,
            category="backend",
            code="LOCAL_HYBRID_SWEEP_FAILED",
            message="Every persistent Hybrid sweep child failed.",
            retryable=False,
            exception_type="PersistentSweepFailure",
            created_at=created_at,
        )

    def _raise_persisted_failure(self) -> NoReturn:
        error = self.store.load_last_error_ref(self.job_id)
        if error is None:
            raise CASCAQitRuntimeError(
                "Failed persistent sweep has no error reference.",
                code="JOB_ERROR_REF_MISSING",
                stage="backend",
            )
        raise PersistedJobFailure(error_ref=error)


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
