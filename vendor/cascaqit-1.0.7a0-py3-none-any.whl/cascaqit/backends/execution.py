"""User-program execution backend and local job contracts."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, replace
from typing import TYPE_CHECKING, Any, Literal, Protocol, runtime_checkable

from cascaqit.backends.job_state import JobState, validate_job_state
from cascaqit.exceptions import CASCAQitRuntimeError
from cascaqit.native_ir.base import IRMixin
from cascaqit.native_ir.models import SCHEMA_VERSION
from cascaqit.results import ResultIR
from cascaqit.results.resource_usage import (
    LocalResourceMeasurement,
    estimated_peak_bytes_from_metadata,
)

if TYPE_CHECKING:
    from cascaqit.simulators.local_hybrid import (
        LocalHybridScanJobResult,
        LocalHybridScanJobStatusIR,
    )

__all__ = [
    "ExecutionBackendCapabilityProtocol",
    "ExecutionBackendProtocol",
    "ExecutionJobProtocol",
    "ExecutionJobStatusProtocol",
    "LocalBackendCapabilityIR",
    "LocalExecutionJob",
    "LocalExecutionJobStatusIR",
    "ScanExecutionJobProtocol",
]

ExecutionProgramKind = Literal["digital", "analog", "hybrid"]
def _require_identifier(value: object, *, field_name: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field_name} must be a non-empty string.")


def _require_hash(value: object, *, field_name: str) -> None:
    if (
        not isinstance(value, str)
        or len(value) != 64
        or any(character not in "0123456789abcdef" for character in value)
    ):
        raise ValueError(f"{field_name} must be a lowercase SHA-256 hex digest.")


@dataclass(frozen=True)
class LocalBackendCapabilityIR(IRMixin):
    """Resource-driven capability of the offline unified local backend."""

    backend_id: str = "local.simulator"
    supported_program_kinds: tuple[ExecutionProgramKind, ...] = (
        "digital",
        "analog",
        "hybrid",
    )
    execution_model: Literal["synchronous_lazy"] = "synchronous_lazy"
    supported_digital_gates: tuple[str, ...] = ()
    supported_analog_waveforms: tuple[str, ...] = ()
    planned_simulation_methods: tuple[str, ...] = (
        "state_vector",
        "subspace",
        "density_matrix",
        "trajectory",
    )
    executable_simulation_methods: tuple[str, ...] = ("state_vector", "subspace")
    state_representations: tuple[str, ...] = (
        "state_vector",
        "subspace",
        "density_matrix",
        "trajectory_batch",
    )
    supported_devices: tuple[str, ...] = ("cpu",)
    supported_dtypes: tuple[str, ...] = ("complex64", "complex128")
    resource_driven_planning: bool = True
    default_memory_fraction: float = 0.8
    scalable_engine_status: Literal["operational"] = "operational"
    local_detuning_status: Literal["experimental"] = "experimental"
    hybrid_state_handoff_supported: bool = True
    measurement_basis: Literal["computational"] = "computational"
    unified_scan_supported: bool = False
    legacy_hybrid_ir_mode: Literal["plan_only"] = "plan_only"
    offline_deterministic: bool = True
    noise_supported: bool = False
    hardware_or_cloud_supported: bool = False
    execution_package_created: bool = False
    schema_version: str = SCHEMA_VERSION

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> LocalBackendCapabilityIR:
        """Build capability from a JSON-compatible dictionary."""
        return cls(
            backend_id=str(data.get("backend_id", "local.simulator")),
            supported_program_kinds=tuple(
                data.get("supported_program_kinds", ("digital", "analog", "hybrid"))
            ),
            execution_model=data.get("execution_model", "synchronous_lazy"),
            supported_digital_gates=tuple(
                str(item) for item in data.get("supported_digital_gates", ())
            ),
            supported_analog_waveforms=tuple(
                str(item) for item in data.get("supported_analog_waveforms", ())
            ),
            planned_simulation_methods=tuple(
                str(item)
                for item in data.get(
                    "planned_simulation_methods",
                    (
                        "state_vector",
                        "subspace",
                        "density_matrix",
                        "trajectory",
                    ),
                )
            ),
            executable_simulation_methods=tuple(
                str(item)
                for item in data.get(
                    "executable_simulation_methods",
                    ("state_vector", "subspace"),
                )
            ),
            state_representations=tuple(
                str(item)
                for item in data.get(
                    "state_representations",
                    (
                        "state_vector",
                        "subspace",
                        "density_matrix",
                        "trajectory_batch",
                    ),
                )
            ),
            supported_devices=tuple(
                str(item) for item in data.get("supported_devices", ("cpu",))
            ),
            supported_dtypes=tuple(
                str(item)
                for item in data.get(
                    "supported_dtypes",
                    ("complex64", "complex128"),
                )
            ),
            resource_driven_planning=bool(
                data.get("resource_driven_planning", True)
            ),
            default_memory_fraction=float(data.get("default_memory_fraction", 0.8)),
            scalable_engine_status=data.get(
                "scalable_engine_status",
                "operational",
            ),
            local_detuning_status=data.get("local_detuning_status", "experimental"),
            hybrid_state_handoff_supported=bool(
                data.get("hybrid_state_handoff_supported", True)
            ),
            measurement_basis=data.get("measurement_basis", "computational"),
            unified_scan_supported=bool(data.get("unified_scan_supported", False)),
            legacy_hybrid_ir_mode=data.get("legacy_hybrid_ir_mode", "plan_only"),
            offline_deterministic=bool(data.get("offline_deterministic", True)),
            noise_supported=bool(data.get("noise_supported", False)),
            hardware_or_cloud_supported=bool(
                data.get("hardware_or_cloud_supported", False)
            ),
            execution_package_created=bool(
                data.get("execution_package_created", False)
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
        )


@dataclass(frozen=True)
class LocalExecutionJobStatusIR(IRMixin):
    """Immutable lifecycle snapshot for one local user-program job."""

    job_id: str
    state: JobState
    backend_id: str
    program_kind: ExecutionProgramKind
    program_hash: str
    execution_count: int
    message: str
    backend_called: bool = True
    network_accessed: bool = False
    execution_package_created: bool = False
    schema_version: str = SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_identifier(self.job_id, field_name="job_id")
        _require_identifier(self.backend_id, field_name="backend_id")
        validate_job_state(self.state)
        if self.program_kind not in {"digital", "analog", "hybrid"}:
            raise ValueError("invalid local execution program kind.")
        _require_hash(self.program_hash, field_name="program_hash")
        if (
            not isinstance(self.execution_count, int)
            or isinstance(self.execution_count, bool)
            or self.execution_count < 0
        ):
            raise ValueError("execution_count must be a non-negative integer.")
        _require_identifier(self.message, field_name="message")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> LocalExecutionJobStatusIR:
        """Build a local status snapshot from a dictionary."""
        return cls(
            job_id=str(data["job_id"]),
            state=data["state"],
            backend_id=str(data["backend_id"]),
            program_kind=data["program_kind"],
            program_hash=str(data["program_hash"]),
            execution_count=int(data["execution_count"]),
            message=str(data["message"]),
            backend_called=bool(data.get("backend_called", True)),
            network_accessed=bool(data.get("network_accessed", False)),
            execution_package_created=bool(
                data.get("execution_package_created", False)
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
        )


@runtime_checkable
class ExecutionBackendCapabilityProtocol(Protocol):
    """Minimum capability shape shared by user-program execution backends."""

    @property
    def backend_id(self) -> str:
        """Return the backend identifier."""

    @property
    def supported_program_kinds(self) -> tuple[ExecutionProgramKind, ...]:
        """Return the Native program kinds accepted by the backend."""

    @property
    def execution_model(self) -> str:
        """Return the observable execution model."""

    @property
    def offline_deterministic(self) -> bool:
        """Return whether the backend is offline and deterministic."""

    @property
    def hardware_or_cloud_supported(self) -> bool:
        """Return whether the backend can access hardware or cloud execution."""

    @property
    def execution_package_created(self) -> bool:
        """Return whether the public backend creates a private package."""


@runtime_checkable
class ExecutionJobStatusProtocol(Protocol):
    """Common read-only lifecycle fields returned by local jobs."""

    @property
    def job_id(self) -> str:
        """Return the stable job identifier."""

    @property
    def state(self) -> JobState:
        """Return the current local lifecycle state."""

    @property
    def backend_id(self) -> str:
        """Return the execution backend identifier."""

    @property
    def execution_count(self) -> int:
        """Return whether synchronous execution has started."""


@runtime_checkable
class ExecutionJobProtocol(Protocol):
    """Common observable behavior of a submitted user-program job."""

    job_id: str

    def status(self) -> ExecutionJobStatusProtocol:
        """Return the current immutable lifecycle snapshot."""

    def result(self) -> ResultIR:
        """Execute at most once and return the cached result."""

    def cancel(self) -> None:
        """Cancel a job that has not started."""


@runtime_checkable
class ExecutionBackendProtocol(Protocol):
    """Backend protocol for Native user-program execution."""

    @property
    def backend_id(self) -> str:
        """Return the backend identifier."""

    @property
    def capability(self) -> ExecutionBackendCapabilityProtocol:
        """Return the backend's explicit execution capability."""

    def run(
        self,
        program: Any,
        *,
        shots: int | None = None,
        seed: int | None = None,
    ) -> ExecutionJobProtocol:
        """Create a submitted job; concrete backends type their program input."""


@runtime_checkable
class ScanExecutionJobProtocol(Protocol):
    """Observable behavior of a submitted aggregate scan job."""

    job_id: str

    def status(self) -> LocalHybridScanJobStatusIR:
        """Return the current aggregate lifecycle snapshot."""

    def result(self) -> LocalHybridScanJobResult:
        """Execute at most once and return the cached aggregate result."""

    def cancel(self) -> None:
        """Cancel a scan job that has not started."""


class LocalExecutionJob:
    """Synchronous lazy job for one local Digital or Analog runner."""

    def __init__(
        self,
        *,
        job_id: str,
        program_kind: ExecutionProgramKind,
        program_hash: str,
        runner: Callable[[], ResultIR],
        backend_id: str = "local.simulator",
    ) -> None:
        _require_identifier(job_id, field_name="job_id")
        _require_identifier(backend_id, field_name="backend_id")
        if program_kind not in {"digital", "analog", "hybrid"}:
            raise ValueError("invalid local execution program kind.")
        _require_hash(program_hash, field_name="program_hash")
        if not callable(runner):
            raise TypeError("runner must be callable.")
        self.job_id = job_id
        self.backend_id = backend_id
        self.program_kind = program_kind
        self.program_hash = program_hash
        self._runner = runner
        self._state: JobState = "queued"
        self._execution_count = 0
        self._result: ResultIR | None = None
        self._error: Exception | None = None

    def status(self) -> LocalExecutionJobStatusIR:
        """Return current state without triggering execution."""
        return LocalExecutionJobStatusIR(
            job_id=self.job_id,
            state=self._state,
            backend_id=self.backend_id,
            program_kind=self.program_kind,
            program_hash=self.program_hash,
            execution_count=self._execution_count,
            message={
                "created": "Local execution job was created.",
                "queued": "Local execution job is ready.",
                "running": "Local execution job is running synchronously.",
                "completed": "Local execution job completed.",
                "partially_completed": (
                    "Local execution job completed with partial results."
                ),
                "failed": "Local execution job failed.",
                "cancelled": "Local execution job was cancelled before execution.",
                "expired": "Local execution job expired before execution.",
            }[self._state],
        )

    def result(self) -> ResultIR:
        """Execute the runner once and return its cached ResultIR."""
        if self._result is not None:
            return self._result
        if self._state == "cancelled":
            raise CASCAQitRuntimeError(
                "Cancelled local execution job has no result.",
                code="LOCAL_EXECUTION_JOB_CANCELLED",
                stage="backend",
                object_path="job.state",
            )
        if self._error is not None:
            raise self._error
        self._state = "running"
        self._execution_count = 1
        measurement = LocalResourceMeasurement.start()
        try:
            result = self._runner()
            if not isinstance(result, ResultIR):
                raise TypeError("runner must return ResultIR.")
            estimated_peak_bytes = estimated_peak_bytes_from_metadata(
                result.metadata
            )
            if estimated_peak_bytes is None:
                # Reference/mock jobs have no SimulationPlanner fact and may
                # preserve object identity with specialized evidence wrappers.
                self._result = result
            else:
                usage = measurement.finish(
                    measurement_scope="job",
                    estimated_peak_bytes=estimated_peak_bytes,
                )
                self._result = replace(
                    result,
                    metadata={
                        **result.metadata,
                        "simulation_resource_usage": usage.to_dict(),
                    },
                )
        except Exception as exc:
            self._state = "failed"
            self._error = exc
            raise
        self._state = "completed"
        return self._result

    def cancel(self) -> None:
        """Cancel a submitted job; terminal states remain unchanged."""
        if self._state == "queued":
            self._state = "cancelled"
