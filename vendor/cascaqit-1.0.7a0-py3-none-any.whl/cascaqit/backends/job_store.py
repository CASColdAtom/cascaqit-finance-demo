"""Internal SQLite store and local Result repository for persistent Jobs."""

from __future__ import annotations

import base64
import binascii
import hashlib
import json
import os
import secrets
import sqlite3
import tempfile
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal, cast

from cascaqit.backends.job_history import (
    JobAttemptIR,
    JobAttemptOutcomeIR,
    JobBusyError,
    JobDefinitionIR,
    JobErrorRefIR,
    JobHistoryEntry,
    JobHistoryPage,
    JobHistoryQuery,
    JobIdempotencyConflictError,
    JobRecoveryError,
    JobResultRefIR,
    JobStoreError,
    JobTransitionIR,
)
from cascaqit.backends.job_state import JobState, validate_job_state

if TYPE_CHECKING:
    from cascaqit.results import ResultIR
    from cascaqit.simulators.local_hybrid import (
        LocalHybridScanItemOutcome,
        LocalHybridScanJobResult,
    )

__all__ = [
    "DefinitionCreateResult",
    "JobClaim",
    "LocalResultRepository",
    "SQLiteJobStore",
    "StoredJobState",
    "StoredSweepChild",
    "SweepChildArtifactRef",
    "SubmissionIdentity",
]

_STORE_SCHEMA_VERSION = 2


@dataclass(frozen=True)
class SubmissionIdentity:
    """Store-local identity reserved for one independent run() call."""

    sequence: int
    job_id: str
    idempotency_key: str


@dataclass(frozen=True)
class DefinitionCreateResult:
    """Definition returned after create-or-deduplicate transaction."""

    definition: JobDefinitionIR
    submission_sequence: int
    created: bool


@dataclass(frozen=True)
class StoredJobState:
    """Derived current-state snapshot checked against transition sequence."""

    job_id: str
    status: JobState
    attempt_count: int
    last_transition_sequence: int
    updated_at: str
    total_items: int | None
    completed_items: int | None
    failed_items: int | None


@dataclass(frozen=True)
class JobClaim:
    """Operational lease; only its hash is persisted and audited."""

    job_id: str
    token: str
    token_hash: str
    owner_id: str
    acquired_at: str
    expires_at: str
    reclaimed: bool


@dataclass(frozen=True)
class SweepChildArtifactRef:
    """Internal checksum reference to one complete scan-item outcome."""

    artifact_path: str
    checksum: str
    size_bytes: int
    outcome_hash: str


@dataclass(frozen=True)
class StoredSweepChild:
    """Immutable child input plus its transactionally derived current state."""

    job_id: str
    scan_index: int
    child_id: str
    bind_set_json: str
    bind_hash: str
    seed: int
    program_payload_json: str
    program_hash: str
    status: str
    attempt_count: int
    updated_at: str
    artifact_ref: SweepChildArtifactRef | None
    error_json: str | None


class LocalResultRepository:
    """Atomically store typed Result JSON outside the SQLite database."""

    def __init__(self, store_path: str | os.PathLike[str]) -> None:
        self.store_path = Path(store_path)
        self.root = Path(f"{self.store_path}.artifacts")
        self.results_dir = self.root / "results"
        self.sweep_items_dir = self.root / "sweep-items"

    def write(
        self,
        result: ResultIR | LocalHybridScanJobResult,
        *,
        job_id: str,
        attempt_index: int,
        created_at: str,
    ) -> JobResultRefIR:
        """Write one content-addressed artifact and return its immutable ref."""
        result_kind, result_id = _result_identity(result)
        payload = result.to_json().encode("utf-8")
        checksum = hashlib.sha256(payload).hexdigest()
        relative_path = f"results/{checksum}.json"
        destination = self.results_dir / f"{checksum}.json"
        result_ref = JobResultRefIR(
            ref_id=f"result-ref.{job_id}.{attempt_index}.{checksum[:16]}",
            job_id=job_id,
            attempt_index=attempt_index,
            result_kind=result_kind,
            result_id=result_id,
            result_hash=result.stable_hash(),
            artifact_path=relative_path,
            checksum=checksum,
            size_bytes=len(payload),
            content_type="application/json",
            created_at=created_at,
        )
        self._ensure_repository_directories()

        temporary_path: Path | None = None
        try:
            with tempfile.NamedTemporaryFile(
                mode="wb",
                dir=self.results_dir,
                prefix=".tmp-result-",
                delete=False,
            ) as handle:
                temporary_path = Path(handle.name)
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
            if destination.exists():
                if destination.is_symlink():
                    raise OSError("content-addressed Result cannot be a symlink")
                resolved = destination.resolve(strict=True)
                resolved.relative_to(self.root.resolve(strict=True))
                if _sha256_file(destination) != checksum:
                    raise OSError("existing content-addressed Result is corrupt")
                temporary_path.unlink()
                temporary_path = None
            else:
                os.replace(temporary_path, destination)
                temporary_path = None
                _fsync_directory(self.results_dir)
        except (OSError, ValueError) as exc:
            if temporary_path is not None:
                temporary_path.unlink(missing_ok=True)
            raise JobStoreError(
                f"Failed to write Result artifact: {exc}",
                code="JOB_RESULT_ARTIFACT_WRITE_FAILED",
                object_path="job.result_ref",
                cause=exc,
            ) from exc

        return result_ref

    def read(
        self,
        ref: JobResultRefIR,
    ) -> ResultIR | LocalHybridScanJobResult:
        """Resolve, verify, and deserialize a typed Result reference."""
        if not isinstance(ref, JobResultRefIR):
            raise TypeError("ref must be JobResultRefIR.")
        try:
            root = self.root.resolve(strict=True)
            unresolved = self.root / ref.artifact_path
            if unresolved.is_symlink():
                raise ValueError("Result artifact cannot be a symbolic link")
            artifact = unresolved.resolve(strict=True)
            artifact.relative_to(root)
        except (OSError, ValueError) as exc:
            raise JobStoreError(
                "Result artifact must resolve inside the configured artifact root.",
                code="JOB_RESULT_ARTIFACT_PATH_INVALID",
                object_path="job.result_ref.artifact_path",
                cause=exc,
            ) from exc
        try:
            payload = artifact.read_bytes()
        except OSError as exc:
            raise JobStoreError(
                f"Failed to read Result artifact: {exc}",
                code="JOB_RESULT_ARTIFACT_READ_FAILED",
                object_path="job.result_ref",
                cause=exc,
            ) from exc
        checksum = hashlib.sha256(payload).hexdigest()
        if checksum != ref.checksum or len(payload) != ref.size_bytes:
            raise JobStoreError(
                "Result artifact checksum or size does not match its reference.",
                code="JOB_RESULT_ARTIFACT_CHECKSUM_MISMATCH",
                object_path="job.result_ref.checksum",
                source_hashes={"expected": ref.checksum, "actual": checksum},
            )
        result = _deserialize_result(ref.result_kind, payload)
        result_id = getattr(result, "result_id", getattr(result, "job_id", None))
        if result_id != ref.result_id or result.stable_hash() != ref.result_hash:
            raise JobStoreError(
                "Deserialized Result identity or stable hash does not match "
                "its reference.",
                code="JOB_RESULT_ARTIFACT_IDENTITY_MISMATCH",
                object_path="job.result_ref.result_hash",
            )
        return result

    def write_sweep_item(
        self,
        outcome: LocalHybridScanItemOutcome,
    ) -> SweepChildArtifactRef:
        """Atomically persist one complete child outcome outside SQLite."""
        from cascaqit.simulators.local_hybrid import LocalHybridScanItemOutcome

        if not isinstance(outcome, LocalHybridScanItemOutcome):
            raise TypeError("outcome must be LocalHybridScanItemOutcome.")
        payload = outcome.to_json().encode("utf-8")
        checksum = hashlib.sha256(payload).hexdigest()
        relative_path = f"sweep-items/{checksum}.json"
        destination = self.sweep_items_dir / f"{checksum}.json"
        self._write_content_addressed(payload, destination, checksum=checksum)
        return SweepChildArtifactRef(
            artifact_path=relative_path,
            checksum=checksum,
            size_bytes=len(payload),
            outcome_hash=outcome.stable_hash(),
        )

    def read_sweep_item(
        self,
        ref: SweepChildArtifactRef,
    ) -> LocalHybridScanItemOutcome:
        """Verify and restore one persisted child outcome."""
        from cascaqit.simulators.local_hybrid import LocalHybridScanItemOutcome

        payload = self._read_artifact(
            ref.artifact_path,
            checksum=ref.checksum,
            size_bytes=ref.size_bytes,
        )
        try:
            outcome = LocalHybridScanItemOutcome.from_json(payload.decode("utf-8"))
        except (UnicodeDecodeError, TypeError, ValueError) as exc:
            raise JobStoreError(
                "Sweep child artifact cannot be deserialized.",
                code="JOB_SWEEP_CHILD_ARTIFACT_DESERIALIZATION_FAILED",
                object_path="job.sweep_child.artifact",
                cause=exc,
            ) from exc
        if outcome.stable_hash() != ref.outcome_hash:
            raise JobStoreError(
                "Sweep child artifact stable hash does not match its reference.",
                code="JOB_SWEEP_CHILD_ARTIFACT_IDENTITY_MISMATCH",
                object_path="job.sweep_child.artifact",
            )
        return outcome

    def _write_content_addressed(
        self,
        payload: bytes,
        destination: Path,
        *,
        checksum: str,
    ) -> None:
        try:
            if self.root.is_symlink() or destination.parent.is_symlink():
                raise ValueError("artifact directories cannot be symbolic links")
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.parent.resolve(strict=True).relative_to(
                self.root.resolve(strict=True)
            )
        except (OSError, ValueError) as exc:
            raise JobStoreError(
                "Sweep child artifact directory is invalid.",
                code="JOB_SWEEP_CHILD_ARTIFACT_ROOT_INVALID",
                object_path="backend.store",
                cause=exc,
            ) from exc
        temporary_path: Path | None = None
        try:
            with tempfile.NamedTemporaryFile(
                mode="wb",
                dir=destination.parent,
                prefix=".tmp-sweep-item-",
                delete=False,
            ) as handle:
                temporary_path = Path(handle.name)
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
            if destination.exists():
                if destination.is_symlink():
                    raise OSError("content-addressed artifact cannot be a symlink")
                if _sha256_file(destination) != checksum:
                    raise OSError("existing content-addressed artifact is corrupt")
                temporary_path.unlink()
                temporary_path = None
            else:
                os.replace(temporary_path, destination)
                temporary_path = None
                _fsync_directory(destination.parent)
        except OSError as exc:
            if temporary_path is not None:
                temporary_path.unlink(missing_ok=True)
            raise JobStoreError(
                f"Failed to write sweep child artifact: {exc}",
                code="JOB_SWEEP_CHILD_ARTIFACT_WRITE_FAILED",
                object_path="job.sweep_child.artifact",
                cause=exc,
            ) from exc

    def _read_artifact(
        self,
        relative_path: str,
        *,
        checksum: str,
        size_bytes: int,
    ) -> bytes:
        try:
            root = self.root.resolve(strict=True)
            unresolved = self.root / relative_path
            if unresolved.is_symlink():
                raise ValueError("artifact cannot be a symbolic link")
            artifact = unresolved.resolve(strict=True)
            artifact.relative_to(root)
            payload = artifact.read_bytes()
        except (OSError, ValueError) as exc:
            raise JobStoreError(
                "Sweep child artifact path is invalid or unreadable.",
                code="JOB_SWEEP_CHILD_ARTIFACT_PATH_INVALID",
                object_path="job.sweep_child.artifact",
                cause=exc,
            ) from exc
        actual = hashlib.sha256(payload).hexdigest()
        if actual != checksum or len(payload) != size_bytes:
            raise JobStoreError(
                "Sweep child artifact checksum or size does not match its reference.",
                code="JOB_SWEEP_CHILD_ARTIFACT_CHECKSUM_MISMATCH",
                object_path="job.sweep_child.artifact",
            )
        return payload

    def _ensure_repository_directories(self) -> None:
        try:
            if self.root.is_symlink() or self.results_dir.is_symlink():
                raise ValueError("artifact directories cannot be symbolic links")
            self.results_dir.mkdir(parents=True, exist_ok=True)
            root = self.root.resolve(strict=True)
            results = self.results_dir.resolve(strict=True)
            results.relative_to(root)
        except (OSError, ValueError) as exc:
            raise JobStoreError(
                "Result artifact directory is invalid or escapes its store root.",
                code="JOB_RESULT_ARTIFACT_ROOT_INVALID",
                object_path="backend.store",
                cause=exc,
            ) from exc


class SQLiteJobStore:
    """Transactional, append-only evidence store for local persistent Jobs."""

    def __init__(
        self,
        path: str | os.PathLike[str],
        *,
        busy_timeout_seconds: float = 5.0,
    ) -> None:
        self.path = Path(path)
        if not str(self.path):
            raise ValueError("SQLite Job store path cannot be empty.")
        if busy_timeout_seconds <= 0:
            raise ValueError("busy_timeout_seconds must be positive.")
        self.busy_timeout_seconds = float(busy_timeout_seconds)
        self.results = LocalResultRepository(self.path)
        self._bootstrap()

    @property
    def store_id(self) -> str:
        with self._read_connection() as connection:
            row = connection.execute(
                "SELECT store_id FROM store_metadata WHERE singleton = 1"
            ).fetchone()
        if row is None:
            raise JobStoreError("SQLite Job store metadata is missing.")
        return str(row["store_id"])

    def reserve_submission(
        self,
        program_kind: Literal["digital", "analog", "hybrid"],
        program_hash: str,
    ) -> SubmissionIdentity:
        """Reserve a monotonic identity for a non-idempotent run() call."""
        if program_kind not in {"digital", "analog", "hybrid"}:
            raise ValueError("program_kind is unsupported.")
        _require_hash(program_hash, field_name="program_hash")
        with self._write_connection() as connection:
            row = connection.execute(
                "SELECT next_sequence FROM submission_sequence WHERE singleton = 1"
            ).fetchone()
            if row is None:
                raise JobStoreError("SQLite submission sequence is missing.")
            sequence = int(row["next_sequence"])
            connection.execute(
                "UPDATE submission_sequence SET next_sequence = ? WHERE singleton = 1",
                (sequence + 1,),
            )
        return SubmissionIdentity(
            sequence=sequence,
            job_id=(f"local_job.{program_kind}.{program_hash[:16]}.{sequence:08d}"),
            idempotency_key=f"local-submission-{sequence:08d}",
        )

    def create_definition(
        self,
        definition: JobDefinitionIR,
        *,
        submission_sequence: int,
    ) -> DefinitionCreateResult:
        """Atomically create definition/state/initial event or deduplicate it."""
        if not isinstance(definition, JobDefinitionIR):
            raise TypeError("definition must be JobDefinitionIR.")
        if submission_sequence < 1:
            raise ValueError("submission_sequence must be positive.")
        with self._write_connection() as connection:
            existing = connection.execute(
                """
                SELECT definition_json, definition_hash, submission_sequence
                FROM job_definitions
                WHERE backend_id = ? AND idempotency_key = ?
                """,
                (definition.backend_id, definition.idempotency_key),
            ).fetchone()
            if existing is not None:
                if str(existing["definition_hash"]) != definition.definition_hash:
                    stored = JobDefinitionIR.from_json(str(existing["definition_json"]))
                    raise JobIdempotencyConflictError(
                        job_id=stored.job_id,
                        expected_definition_hash=str(existing["definition_hash"]),
                        actual_definition_hash=definition.definition_hash,
                    )
                return DefinitionCreateResult(
                    definition=JobDefinitionIR.from_json(
                        str(existing["definition_json"])
                    ),
                    submission_sequence=int(existing["submission_sequence"]),
                    created=False,
                )
            job_collision = connection.execute(
                "SELECT definition_hash FROM job_definitions WHERE job_id = ?",
                (definition.job_id,),
            ).fetchone()
            if job_collision is not None:
                raise JobStoreError(
                    "Persistent Job id already belongs to another definition.",
                    code="JOB_ID_CONFLICT",
                    object_path="backend.run.job_id",
                )
            connection.execute(
                """
                INSERT INTO job_definitions (
                    job_id, backend_id, job_kind, program_kind, program_hash,
                    definition_hash, idempotency_key, idempotency_explicit,
                    definition_json, created_at, submission_sequence
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    definition.job_id,
                    definition.backend_id,
                    definition.job_kind,
                    definition.program_kind,
                    definition.program_hash,
                    definition.definition_hash,
                    definition.idempotency_key,
                    int(definition.idempotency_explicit),
                    definition.to_json(),
                    definition.created_at,
                    submission_sequence,
                ),
            )
            created_transition = JobTransitionIR(
                job_id=definition.job_id,
                sequence=1,
                from_state=None,
                to_state="created",
                event_time=definition.created_at,
                definition_hash=definition.definition_hash,
                reason="definition_created",
            )
            queued_transition = JobTransitionIR(
                job_id=definition.job_id,
                sequence=2,
                from_state="created",
                to_state="queued",
                event_time=definition.created_at,
                definition_hash=definition.definition_hash,
                reason="definition_queued",
            )
            sweep_children = _sweep_children_from_definition(definition)
            connection.execute(
                """
                INSERT INTO job_transitions (
                    job_id, sequence, from_state, to_state, event_time,
                    attempt_index, definition_hash, reason, error_ref_id,
                    transition_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                _transition_values(created_transition),
            )
            _insert_transition(connection, queued_transition)
            connection.execute(
                """
                INSERT INTO job_state (
                    job_id, status, attempt_count, last_transition_sequence,
                    updated_at, total_items, completed_items, failed_items
                ) VALUES (?, 'queued', 0, 2, ?, ?, ?, ?)
                """,
                (
                    definition.job_id,
                    definition.created_at,
                    None if sweep_children is None else len(sweep_children),
                    None if sweep_children is None else 0,
                    None if sweep_children is None else 0,
                ),
            )
            if sweep_children is not None:
                for child in sweep_children:
                    connection.execute(
                        """
                        INSERT INTO sweep_children (
                            job_id, scan_index, child_id, bind_set_json,
                            bind_hash, seed, program_payload_json, program_hash
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            definition.job_id,
                            child["scan_index"],
                            child["child_id"],
                            json.dumps(
                                child["bind_set"],
                                sort_keys=True,
                                separators=(",", ":"),
                            ),
                            child["bind_hash"],
                            str(child["seed"]),
                            json.dumps(
                                child["program_payload"],
                                sort_keys=True,
                                separators=(",", ":"),
                            ),
                            child["program_hash"],
                        ),
                    )
                    connection.execute(
                        """
                        INSERT INTO sweep_child_state (
                            job_id, scan_index, status, attempt_count, updated_at
                        ) VALUES (?, ?, 'pending', 0, ?)
                        """,
                        (
                            definition.job_id,
                            child["scan_index"],
                            definition.created_at,
                        ),
                    )
            connection.execute(
                """
                UPDATE submission_sequence
                SET next_sequence = MAX(next_sequence, ?)
                WHERE singleton = 1
                """,
                (submission_sequence + 1,),
            )
        return DefinitionCreateResult(
            definition=definition,
            submission_sequence=submission_sequence,
            created=True,
        )

    def load_definition(self, job_id: str) -> JobDefinitionIR:
        with self._read_connection() as connection:
            row = connection.execute(
                "SELECT definition_json, definition_hash "
                "FROM job_definitions WHERE job_id = ?",
                (job_id,),
            ).fetchone()
        if row is None:
            raise JobRecoveryError(
                "Persistent Job definition was not found.",
                code="JOB_NOT_FOUND",
                object_path="backend.resume.job_id",
                metadata={"job_id": job_id},
            )
        definition = JobDefinitionIR.from_json(str(row["definition_json"]))
        if definition.definition_hash != str(row["definition_hash"]):
            raise JobStoreError(
                "Stored Job definition hash is corrupt.",
                code="JOB_DEFINITION_HASH_MISMATCH",
                object_path="job.definition_hash",
            )
        return definition

    def load_state(self, job_id: str) -> StoredJobState:
        with self._read_connection() as connection:
            row = connection.execute(
                "SELECT * FROM job_state WHERE job_id = ?",
                (job_id,),
            ).fetchone()
            transition = connection.execute(
                """
                SELECT sequence, to_state FROM job_transitions
                WHERE job_id = ? ORDER BY sequence DESC LIMIT 1
                """,
                (job_id,),
            ).fetchone()
        if row is None or transition is None:
            raise JobRecoveryError(
                "Persistent Job state was not found.",
                code="JOB_NOT_FOUND",
                metadata={"job_id": job_id},
            )
        if int(row["last_transition_sequence"]) != int(transition["sequence"]) or str(
            row["status"]
        ) != str(transition["to_state"]):
            raise JobStoreError(
                "Persistent Job state snapshot disagrees with its last transition.",
                code="JOB_STATE_SNAPSHOT_DRIFT",
                object_path="job.state",
            )
        return _state_from_row(row)

    def acquire_claim(
        self,
        job_id: str,
        *,
        owner_id: str,
        now: str,
        lease_seconds: float,
    ) -> JobClaim:
        """Acquire the single active execution lease using a write transaction."""
        _require_identifier(owner_id, field_name="owner_id")
        now_value = _parse_utc(now)
        if lease_seconds <= 0:
            raise ValueError("lease_seconds must be positive.")
        expires_at = _format_utc(now_value + timedelta(seconds=lease_seconds))
        token = secrets.token_urlsafe(32)
        token_hash = _token_hash(token)
        reclaimed = False
        with self._write_connection() as connection:
            state = _state_row(connection, job_id)
            if str(state["status"]) in {
                "completed",
                "partially_completed",
                "failed",
                "cancelled",
                "expired",
            }:
                raise JobRecoveryError(
                    "Terminal Job cannot acquire a new execution claim.",
                    code="JOB_TERMINAL_CLAIM_REJECTED",
                    metadata={"job_id": job_id, "status": state["status"]},
                )
            current = connection.execute(
                "SELECT * FROM job_claims WHERE job_id = ?",
                (job_id,),
            ).fetchone()
            if current is not None:
                if _parse_utc(str(current["expires_at"])) > now_value:
                    raise JobBusyError(job_id=job_id)
                reclaimed = True
                connection.execute("DELETE FROM job_claims WHERE job_id = ?", (job_id,))
            connection.execute(
                """
                INSERT INTO job_claims (
                    job_id, token_hash, owner_id, acquired_at, expires_at
                ) VALUES (?, ?, ?, ?, ?)
                """,
                (job_id, token_hash, owner_id, now, expires_at),
            )
        return JobClaim(
            job_id=job_id,
            token=token,
            token_hash=token_hash,
            owner_id=owner_id,
            acquired_at=now,
            expires_at=expires_at,
            reclaimed=reclaimed,
        )

    def load_claim(self, job_id: str) -> JobClaim | None:
        """Return claim metadata without exposing the unavailable raw token."""
        with self._read_connection() as connection:
            row = connection.execute(
                "SELECT * FROM job_claims WHERE job_id = ?",
                (job_id,),
            ).fetchone()
        if row is None:
            return None
        return JobClaim(
            job_id=job_id,
            token="<unavailable>",
            token_hash=str(row["token_hash"]),
            owner_id=str(row["owner_id"]),
            acquired_at=str(row["acquired_at"]),
            expires_at=str(row["expires_at"]),
            reclaimed=False,
        )

    def start_attempt(self, attempt: JobAttemptIR, *, claim_token: str) -> None:
        """Append an attempt and enter running on the first attempt."""
        if not isinstance(attempt, JobAttemptIR):
            raise TypeError("attempt must be JobAttemptIR.")
        with self._write_connection() as connection:
            claim = _require_claim(connection, attempt.job_id, claim_token)
            if str(claim["token_hash"]) != attempt.claim_token_hash:
                raise JobStoreError("Attempt claim hash does not match active claim.")
            definition = _definition_row(connection, attempt.job_id)
            state = _state_row(connection, attempt.job_id)
            current_state = str(state["status"])
            if current_state not in {"queued", "running"}:
                raise JobStoreError(
                    "Job must be queued or running before an attempt starts."
                )
            if attempt.attempt_index != int(state["attempt_count"]) + 1:
                raise JobStoreError("Attempt index must be monotonic.")
            if attempt.definition_hash != str(
                definition["definition_hash"]
            ) or attempt.program_hash != str(definition["program_hash"]):
                raise JobStoreError("Attempt definition or program hash drifted.")
            frozen = JobDefinitionIR.from_json(str(definition["definition_json"]))
            if attempt.parameter_bind_hash != frozen.parameter_bind_hash:
                raise JobStoreError("Attempt parameter bind hash drifted.")
            expected_seed = frozen.execution_spec().get("seed")
            if expected_seed is not None and attempt.seed != expected_seed:
                raise JobStoreError("Attempt seed drifted from Job definition.")
            connection.execute(
                """
                INSERT INTO job_attempts (
                    job_id, attempt_index, claim_token_hash, definition_hash,
                    program_hash, parameter_bind_hash, seed, started_at,
                    attempt_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    attempt.job_id,
                    attempt.attempt_index,
                    attempt.claim_token_hash,
                    attempt.definition_hash,
                    attempt.program_hash,
                    attempt.parameter_bind_hash,
                    attempt.seed,
                    attempt.started_at,
                    attempt.to_json(),
                ),
            )
            if current_state == "queued":
                transition = JobTransitionIR(
                    job_id=attempt.job_id,
                    sequence=int(state["last_transition_sequence"]) + 1,
                    from_state="queued",
                    to_state="running",
                    event_time=attempt.started_at,
                    definition_hash=attempt.definition_hash,
                    reason="attempt_started",
                    attempt_index=attempt.attempt_index,
                )
                _insert_transition(connection, transition)
                last_transition_sequence = transition.sequence
            else:
                # Retry is attempt evidence, not a public Job state transition.
                last_transition_sequence = int(state["last_transition_sequence"])
            connection.execute(
                """
                UPDATE job_state
                SET status = 'running', attempt_count = ?,
                    last_transition_sequence = ?, updated_at = ?
                WHERE job_id = ?
                """,
                (
                    attempt.attempt_index,
                    last_transition_sequence,
                    attempt.started_at,
                    attempt.job_id,
                ),
            )

    def finish_failure(
        self,
        error_ref: JobErrorRefIR,
        outcome: JobAttemptOutcomeIR,
        *,
        claim_token: str,
        terminal: bool,
    ) -> None:
        """Atomically append error/outcome/transition and release the claim."""
        if error_ref.error_ref_id != outcome.error_ref_id:
            raise JobStoreError(
                "Attempt outcome error reference does not match error evidence."
            )
        if (
            error_ref.job_id != outcome.job_id
            or error_ref.attempt_index != outcome.attempt_index
        ):
            raise JobStoreError(
                "Attempt outcome identity does not match error evidence."
            )
        if outcome.status == "retryable_failure" and not error_ref.retryable:
            raise JobStoreError(
                "Retryable attempt outcome requires retryable error evidence."
            )
        if outcome.status == "non_retryable_failure" and error_ref.retryable:
            raise JobStoreError(
                "Non-retryable attempt outcome requires non-retryable error evidence."
            )
        if terminal and outcome.status in {
            "retryable_failure",
            "non_retryable_failure",
            "interrupted",
        }:
            terminal_failure = True
        elif not terminal and outcome.status in {
            "retryable_failure",
            "interrupted",
        }:
            terminal_failure = False
        else:
            raise JobStoreError("Failure outcome is inconsistent with terminal policy.")
        with self._write_connection() as connection:
            _require_claim(connection, outcome.job_id, claim_token)
            state = _require_running_attempt(connection, outcome)
            connection.execute(
                """
                INSERT INTO job_error_refs (
                    error_ref_id, job_id, attempt_index, code, retryable,
                    error_json, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    error_ref.error_ref_id,
                    error_ref.job_id,
                    error_ref.attempt_index,
                    error_ref.code,
                    int(error_ref.retryable),
                    error_ref.to_json(),
                    error_ref.created_at,
                ),
            )
            _insert_outcome(connection, outcome)
            definition_hash = _definition_hash(connection, outcome.job_id)
            if terminal_failure:
                transition = JobTransitionIR(
                    job_id=outcome.job_id,
                    sequence=int(state["last_transition_sequence"]) + 1,
                    from_state="running",
                    to_state="failed",
                    event_time=outcome.finished_at,
                    definition_hash=definition_hash,
                    reason="attempt_failed",
                    attempt_index=outcome.attempt_index,
                    error_ref_id=error_ref.error_ref_id,
                )
                _insert_transition(connection, transition)
                _update_terminal_state(connection, transition)
            else:
                # A retryable attempt failure is immutable evidence while the
                # public Job remains running until a later terminal outcome.
                connection.execute(
                    "UPDATE job_state SET updated_at = ? WHERE job_id = ?",
                    (outcome.finished_at, outcome.job_id),
                )
            connection.execute(
                "DELETE FROM job_claims WHERE job_id = ?", (outcome.job_id,)
            )

    def finish_success(
        self,
        result_ref: JobResultRefIR,
        outcome: JobAttemptOutcomeIR,
        *,
        claim_token: str,
        terminal_state: Literal["completed", "partially_completed"] = "completed",
    ) -> None:
        """Atomically publish result/outcome/terminal transition and release claim."""
        if outcome.status != "completed" or result_ref.ref_id != outcome.result_ref_id:
            raise JobStoreError(
                "Attempt outcome result reference does not match Result evidence."
            )
        if (
            result_ref.job_id != outcome.job_id
            or result_ref.attempt_index != outcome.attempt_index
        ):
            raise JobStoreError(
                "Attempt outcome identity does not match Result evidence."
            )
        with self._write_connection() as connection:
            _require_claim(connection, outcome.job_id, claim_token)
            state = _require_running_attempt(connection, outcome)
            connection.execute(
                """
                INSERT INTO job_result_refs (
                    ref_id, job_id, attempt_index, result_kind, result_id,
                    result_hash, checksum, artifact_path, result_ref_json, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    result_ref.ref_id,
                    result_ref.job_id,
                    result_ref.attempt_index,
                    result_ref.result_kind,
                    result_ref.result_id,
                    result_ref.result_hash,
                    result_ref.checksum,
                    result_ref.artifact_path,
                    result_ref.to_json(),
                    result_ref.created_at,
                ),
            )
            _insert_outcome(connection, outcome)
            transition = JobTransitionIR(
                job_id=outcome.job_id,
                sequence=int(state["last_transition_sequence"]) + 1,
                from_state="running",
                to_state=terminal_state,
                event_time=outcome.finished_at,
                definition_hash=_definition_hash(connection, outcome.job_id),
                reason="attempt_completed",
                attempt_index=outcome.attempt_index,
            )
            _insert_transition(connection, transition)
            _update_terminal_state(connection, transition)
            connection.execute(
                "DELETE FROM job_claims WHERE job_id = ?", (outcome.job_id,)
            )

    def finish_sweep_failure(
        self,
        result_ref: JobResultRefIR,
        error_ref: JobErrorRefIR,
        *,
        claim_token: str,
    ) -> None:
        """Publish a failed sweep aggregate together with terminal error evidence."""
        if (
            result_ref.job_id != error_ref.job_id
            or result_ref.attempt_index != error_ref.attempt_index
        ):
            raise JobStoreError("Sweep Result and error identities must match.")
        outcome = JobAttemptOutcomeIR(
            job_id=error_ref.job_id,
            attempt_index=error_ref.attempt_index,
            status="non_retryable_failure",
            finished_at=error_ref.created_at,
            error_ref_id=error_ref.error_ref_id,
        )
        with self._write_connection() as connection:
            _require_claim(connection, error_ref.job_id, claim_token)
            state = _require_running_attempt(connection, outcome)
            connection.execute(
                """
                INSERT INTO job_result_refs (
                    ref_id, job_id, attempt_index, result_kind, result_id,
                    result_hash, checksum, artifact_path, result_ref_json, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    result_ref.ref_id,
                    result_ref.job_id,
                    result_ref.attempt_index,
                    result_ref.result_kind,
                    result_ref.result_id,
                    result_ref.result_hash,
                    result_ref.checksum,
                    result_ref.artifact_path,
                    result_ref.to_json(),
                    result_ref.created_at,
                ),
            )
            connection.execute(
                """
                INSERT INTO job_error_refs (
                    error_ref_id, job_id, attempt_index, code, retryable,
                    error_json, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    error_ref.error_ref_id,
                    error_ref.job_id,
                    error_ref.attempt_index,
                    error_ref.code,
                    int(error_ref.retryable),
                    error_ref.to_json(),
                    error_ref.created_at,
                ),
            )
            _insert_outcome(connection, outcome)
            transition = JobTransitionIR(
                job_id=error_ref.job_id,
                sequence=int(state["last_transition_sequence"]) + 1,
                from_state="running",
                to_state="failed",
                event_time=error_ref.created_at,
                definition_hash=_definition_hash(connection, error_ref.job_id),
                reason="sweep_failed",
                attempt_index=error_ref.attempt_index,
                error_ref_id=error_ref.error_ref_id,
            )
            _insert_transition(connection, transition)
            _update_terminal_state(connection, transition)
            connection.execute(
                "DELETE FROM job_claims WHERE job_id = ?", (error_ref.job_id,)
            )

    def list_attempts(self, job_id: str) -> tuple[JobAttemptIR, ...]:
        with self._read_connection() as connection:
            rows = connection.execute(
                "SELECT attempt_json FROM job_attempts "
                "WHERE job_id = ? ORDER BY attempt_index",
                (job_id,),
            ).fetchall()
        return tuple(JobAttemptIR.from_json(str(row["attempt_json"])) for row in rows)

    def list_outcomes(self, job_id: str) -> tuple[JobAttemptOutcomeIR, ...]:
        with self._read_connection() as connection:
            rows = connection.execute(
                "SELECT outcome_json FROM job_attempt_outcomes "
                "WHERE job_id = ? ORDER BY attempt_index",
                (job_id,),
            ).fetchall()
        return tuple(
            JobAttemptOutcomeIR.from_json(str(row["outcome_json"])) for row in rows
        )

    def list_transitions(self, job_id: str) -> tuple[JobTransitionIR, ...]:
        with self._read_connection() as connection:
            rows = connection.execute(
                "SELECT transition_json FROM job_transitions "
                "WHERE job_id = ? ORDER BY sequence",
                (job_id,),
            ).fetchall()
        return tuple(
            JobTransitionIR.from_json(str(row["transition_json"])) for row in rows
        )

    def load_result_ref(self, job_id: str) -> JobResultRefIR | None:
        with self._read_connection() as connection:
            row = connection.execute(
                "SELECT result_ref_json FROM job_result_refs WHERE job_id = ?",
                (job_id,),
            ).fetchone()
        return (
            None
            if row is None
            else JobResultRefIR.from_json(str(row["result_ref_json"]))
        )

    def list_error_refs(self, job_id: str) -> tuple[JobErrorRefIR, ...]:
        with self._read_connection() as connection:
            rows = connection.execute(
                "SELECT error_json FROM job_error_refs "
                "WHERE job_id = ? ORDER BY attempt_index",
                (job_id,),
            ).fetchall()
        return tuple(JobErrorRefIR.from_json(str(row["error_json"])) for row in rows)

    def load_last_error_ref(self, job_id: str) -> JobErrorRefIR | None:
        refs = self.list_error_refs(job_id)
        return None if not refs else refs[-1]

    def load_sweep_children(self, job_id: str) -> tuple[StoredSweepChild, ...]:
        """Return child definitions and derived states in stable scan order."""
        with self._read_connection() as connection:
            rows = connection.execute(
                """
                SELECT c.*, s.status, s.attempt_count, s.updated_at,
                       s.artifact_path, s.checksum, s.size_bytes,
                       s.outcome_hash, s.error_json
                FROM sweep_children AS c
                JOIN sweep_child_state AS s
                  ON s.job_id = c.job_id AND s.scan_index = c.scan_index
                WHERE c.job_id = ?
                ORDER BY c.scan_index
                """,
                (job_id,),
            ).fetchall()
        return tuple(_stored_sweep_child_from_row(row) for row in rows)

    def start_sweep_child_attempt(
        self,
        job_id: str,
        scan_index: int,
        *,
        started_at: str,
    ) -> int:
        """Append a child attempt start and mark only that child running."""
        with self._write_connection() as connection:
            parent = _state_row(connection, job_id)
            if str(parent["status"]) != "running":
                raise JobStoreError("Sweep child requires a running parent Job.")
            child = _sweep_child_state_row(connection, job_id, scan_index)
            if str(child["status"]) != "pending":
                raise JobStoreError("Sweep child must be pending before execution.")
            attempt_index = int(child["attempt_count"]) + 1
            definition = connection.execute(
                """
                SELECT bind_hash, seed, program_hash
                FROM sweep_children WHERE job_id = ? AND scan_index = ?
                """,
                (job_id, scan_index),
            ).fetchone()
            if definition is None:
                raise JobRecoveryError(
                    "Sweep child definition was not found.",
                    code="JOB_SWEEP_CHILD_NOT_FOUND",
                )
            connection.execute(
                """
                INSERT INTO sweep_child_attempts (
                    job_id, scan_index, attempt_index, bind_hash,
                    seed, program_hash, started_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    job_id,
                    scan_index,
                    attempt_index,
                    definition["bind_hash"],
                    definition["seed"],
                    definition["program_hash"],
                    started_at,
                ),
            )
            connection.execute(
                """
                UPDATE sweep_child_state
                SET status = 'running', attempt_count = ?, updated_at = ?
                WHERE job_id = ? AND scan_index = ?
                """,
                (attempt_index, started_at, job_id, scan_index),
            )
        return attempt_index

    def finish_sweep_child_success(
        self,
        job_id: str,
        scan_index: int,
        *,
        attempt_index: int,
        artifact_ref: SweepChildArtifactRef,
        finished_at: str,
    ) -> None:
        """Publish one child artifact and its completed outcome atomically."""
        with self._write_connection() as connection:
            _require_running_sweep_child(
                connection,
                job_id,
                scan_index,
                attempt_index,
            )
            connection.execute(
                """
                INSERT INTO sweep_child_outcomes (
                    job_id, scan_index, attempt_index, status, finished_at,
                    artifact_path, checksum, size_bytes, outcome_hash, error_json
                ) VALUES (?, ?, ?, 'completed', ?, ?, ?, ?, ?, NULL)
                """,
                (
                    job_id,
                    scan_index,
                    attempt_index,
                    finished_at,
                    artifact_ref.artifact_path,
                    artifact_ref.checksum,
                    artifact_ref.size_bytes,
                    artifact_ref.outcome_hash,
                ),
            )
            connection.execute(
                """
                UPDATE sweep_child_state
                SET status = 'completed', updated_at = ?, artifact_path = ?,
                    checksum = ?, size_bytes = ?, outcome_hash = ?, error_json = NULL
                WHERE job_id = ? AND scan_index = ?
                """,
                (
                    finished_at,
                    artifact_ref.artifact_path,
                    artifact_ref.checksum,
                    artifact_ref.size_bytes,
                    artifact_ref.outcome_hash,
                    job_id,
                    scan_index,
                ),
            )
            _refresh_sweep_counts(connection, job_id, finished_at)

    def finish_sweep_child_failure(
        self,
        job_id: str,
        scan_index: int,
        *,
        attempt_index: int,
        error_ref: JobErrorRefIR,
        retry: bool,
        finished_at: str,
    ) -> None:
        """Append safe child failure evidence and derive pending/final state."""
        with self._write_connection() as connection:
            _require_running_sweep_child(
                connection,
                job_id,
                scan_index,
                attempt_index,
            )
            connection.execute(
                """
                INSERT INTO sweep_child_outcomes (
                    job_id, scan_index, attempt_index, status, finished_at,
                    artifact_path, checksum, size_bytes, outcome_hash, error_json
                ) VALUES (?, ?, ?, ?, ?, NULL, NULL, NULL, NULL, ?)
                """,
                (
                    job_id,
                    scan_index,
                    attempt_index,
                    "retryable_failure" if retry else "failed",
                    finished_at,
                    error_ref.to_json(),
                ),
            )
            connection.execute(
                """
                UPDATE sweep_child_state
                SET status = ?, updated_at = ?, error_json = ?
                WHERE job_id = ? AND scan_index = ?
                """,
                (
                    "pending" if retry else "failed",
                    finished_at,
                    error_ref.to_json(),
                    job_id,
                    scan_index,
                ),
            )
            _refresh_sweep_counts(connection, job_id, finished_at)

    def mark_sweep_children_not_run(
        self,
        job_id: str,
        *,
        after_index: int,
        event_time: str,
    ) -> None:
        """Freeze fail-fast pending children as never executed."""
        with self._write_connection() as connection:
            connection.execute(
                """
                UPDATE sweep_child_state
                SET status = 'not_run', updated_at = ?
                WHERE job_id = ? AND scan_index > ? AND status = 'pending'
                """,
                (event_time, job_id, after_index),
            )
            _refresh_sweep_counts(connection, job_id, event_time)

    def history(self, query: JobHistoryQuery) -> JobHistoryPage:
        """Return a stable summary page without resolving Result artifacts."""
        if not isinstance(query, JobHistoryQuery):
            raise TypeError("query must be JobHistoryQuery.")
        store_id = self.store_id
        cursor_key = (
            None
            if query.cursor is None
            else _decode_history_cursor(
                query.cursor,
                store_id=store_id,
                filter_hash=query.filter_hash,
            )
        )
        where = ["1 = 1"]
        parameters: list[Any] = []
        _append_in_filter(where, parameters, "s.status", query.statuses)
        _append_in_filter(
            where,
            parameters,
            "d.program_kind",
            query.program_kinds,
        )
        _append_in_filter(where, parameters, "d.job_kind", query.job_kinds)
        if query.created_after is not None:
            where.append("d.created_at >= ?")
            parameters.append(query.created_after)
        if query.created_before is not None:
            where.append("d.created_at <= ?")
            parameters.append(query.created_before)
        if cursor_key is not None:
            where.append("(d.created_at < ? OR (d.created_at = ? AND d.job_id < ?))")
            parameters.extend((cursor_key[0], cursor_key[0], cursor_key[1]))

        # Every interpolated fragment above is selected by this module. Caller
        # values remain placeholders, so filters cannot become executable SQL.
        sql = f"""
            SELECT
                d.job_id, d.backend_id, d.job_kind, d.program_kind,
                d.program_hash, d.definition_hash, d.created_at,
                s.status, s.attempt_count, s.last_transition_sequence,
                s.updated_at, s.total_items, s.completed_items, s.failed_items,
                r.result_ref_json, e.error_json,
                t.sequence AS transition_sequence, t.to_state AS transition_state
            FROM job_definitions AS d
            JOIN job_state AS s ON s.job_id = d.job_id
            JOIN job_transitions AS t
              ON t.job_id = s.job_id
             AND t.sequence = s.last_transition_sequence
            LEFT JOIN job_result_refs AS r ON r.job_id = d.job_id
            LEFT JOIN job_error_refs AS e
              ON e.error_ref_id = (
                  SELECT latest.error_ref_id
                  FROM job_error_refs AS latest
                  WHERE latest.job_id = d.job_id
                  ORDER BY latest.attempt_index DESC, latest.error_ref_id DESC
                  LIMIT 1
              )
            WHERE {' AND '.join(where)}
            ORDER BY d.created_at DESC, d.job_id DESC
            LIMIT ?
        """
        parameters.append(query.limit + 1)
        with self._read_connection() as connection:
            rows = connection.execute(sql, parameters).fetchall()

        entries = tuple(_history_entry_from_row(row) for row in rows[: query.limit])
        next_cursor = None
        if len(rows) > query.limit and entries:
            last = entries[-1]
            next_cursor = _encode_history_cursor(
                store_id=store_id,
                filter_hash=query.filter_hash,
                created_at=last.created_at,
                job_id=last.job_id,
            )
        return JobHistoryPage(
            entries=entries,
            limit=query.limit,
            next_cursor=next_cursor,
            store_id=store_id,
            filter_hash=query.filter_hash,
        )

    def cancel(self, job_id: str, *, event_time: str) -> bool:
        """Persist cancellation only before an active attempt owns the Job."""
        with self._write_connection() as connection:
            state = _state_row(connection, job_id)
            current = str(state["status"])
            if current not in {"queued", "running"}:
                return False
            claim = connection.execute(
                "SELECT 1 FROM job_claims WHERE job_id = ?",
                (job_id,),
            ).fetchone()
            if claim is not None:
                return False
            definition = _definition_row(connection, job_id)
            if str(definition["job_kind"]) == "sweep":
                non_pending = connection.execute(
                    """
                    SELECT 1 FROM sweep_child_state
                    WHERE job_id = ? AND status != 'pending' LIMIT 1
                    """,
                    (job_id,),
                ).fetchone()
                if non_pending is not None:
                    return False
            transition = JobTransitionIR(
                job_id=job_id,
                sequence=int(state["last_transition_sequence"]) + 1,
                from_state=cast(Any, current),
                to_state="cancelled",
                event_time=event_time,
                definition_hash=_definition_hash(connection, job_id),
                reason=(
                    "cancelled_before_attempt"
                    if int(state["attempt_count"]) == 0
                    else "cancelled_between_attempts"
                ),
                attempt_index=(
                    None
                    if int(state["attempt_count"]) == 0
                    else int(state["attempt_count"])
                ),
            )
            _insert_transition(connection, transition)
            _update_terminal_state(connection, transition)
            if str(definition["job_kind"]) == "sweep":
                connection.execute(
                    """
                    UPDATE sweep_child_state
                    SET status = 'cancelled', updated_at = ?
                    WHERE job_id = ? AND status = 'pending'
                    """,
                    (event_time, job_id),
                )
            return True

    def job_count(self) -> int:
        with self._read_connection() as connection:
            row = connection.execute(
                "SELECT COUNT(*) AS count FROM job_definitions"
            ).fetchone()
        return int(row["count"])

    def _bootstrap(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        connection = self._connect()
        try:
            version = int(connection.execute("PRAGMA user_version").fetchone()[0])
            if version > _STORE_SCHEMA_VERSION:
                raise JobStoreError(
                    "SQLite Job store uses a newer schema than this runtime.",
                    code="JOB_STORE_SCHEMA_NEWER",
                    object_path="backend.store",
                    metadata={
                        "store_schema": version,
                        "runtime_schema": _STORE_SCHEMA_VERSION,
                    },
                )
            if version == 0:
                connection.executescript(_SCHEMA_V2_SQL)
            elif version < _STORE_SCHEMA_VERSION:
                raise JobStoreError(
                    "SQLite Job store requires an unavailable migration.",
                    code="JOB_STORE_MIGRATION_UNAVAILABLE",
                )
            metadata = connection.execute(
                "SELECT schema_version FROM store_metadata WHERE singleton = 1"
            ).fetchone()
            if (
                metadata is None
                or int(metadata["schema_version"]) != _STORE_SCHEMA_VERSION
            ):
                raise JobStoreError(
                    "SQLite Job store metadata does not match PRAGMA user_version.",
                    code="JOB_STORE_SCHEMA_METADATA_MISMATCH",
                )
        except JobStoreError:
            raise
        except sqlite3.Error as exc:
            raise _sqlite_error(exc) from exc
        finally:
            connection.close()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(
            self.path,
            timeout=self.busy_timeout_seconds,
            isolation_level=None,
        )
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        connection.execute(
            f"PRAGMA busy_timeout = {int(self.busy_timeout_seconds * 1000)}"
        )
        return connection

    @contextmanager
    def _read_connection(self) -> Iterator[sqlite3.Connection]:
        connection = self._connect()
        try:
            yield connection
        except JobStoreError:
            raise
        except sqlite3.Error as exc:
            raise _sqlite_error(exc) from exc
        finally:
            connection.close()

    @contextmanager
    def _write_connection(self) -> Iterator[sqlite3.Connection]:
        connection = self._connect()
        try:
            # IMMEDIATE obtains the single writer reservation before any read used
            # for compare-and-set, so two processes cannot both claim the Job.
            connection.execute("BEGIN IMMEDIATE")
            yield connection
            connection.commit()
        except JobStoreError:
            connection.rollback()
            raise
        except sqlite3.Error as exc:
            connection.rollback()
            raise _sqlite_error(exc) from exc
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()


def _result_identity(
    result: ResultIR | LocalHybridScanJobResult,
) -> tuple[Literal["result", "sweep_result"], str]:
    from cascaqit.results import ResultIR
    from cascaqit.simulators.local_hybrid import LocalHybridScanJobResult

    if isinstance(result, ResultIR):
        return "result", result.result_id
    if isinstance(result, LocalHybridScanJobResult):
        return "sweep_result", result.job_id
    raise TypeError("result must be ResultIR or LocalHybridScanJobResult.")


def _deserialize_result(
    result_kind: str,
    payload: bytes,
) -> ResultIR | LocalHybridScanJobResult:
    from cascaqit.results import ResultIR
    from cascaqit.simulators.local_hybrid import LocalHybridScanJobResult

    try:
        text = payload.decode("utf-8")
        if result_kind == "result":
            return ResultIR.from_json(text)
        if result_kind == "sweep_result":
            return LocalHybridScanJobResult.from_json(text)
    except (UnicodeDecodeError, TypeError, ValueError) as exc:
        raise JobStoreError(
            "Result artifact cannot be deserialized with its declared type.",
            code="JOB_RESULT_ARTIFACT_DESERIALIZATION_FAILED",
            cause=exc,
        ) from exc
    raise JobStoreError("Result reference contains an unsupported result kind.")


def _state_from_row(row: sqlite3.Row) -> StoredJobState:
    return StoredJobState(
        job_id=str(row["job_id"]),
        status=validate_job_state(row["status"], field_name="stored status"),
        attempt_count=int(row["attempt_count"]),
        last_transition_sequence=int(row["last_transition_sequence"]),
        updated_at=str(row["updated_at"]),
        total_items=row["total_items"],
        completed_items=row["completed_items"],
        failed_items=row["failed_items"],
    )


def _append_in_filter(
    where: list[str],
    parameters: list[Any],
    column: str,
    values: tuple[str, ...],
) -> None:
    """Append one allowlisted-column IN filter using value placeholders."""
    if not values:
        return
    allowed_columns = {"s.status", "d.program_kind", "d.job_kind"}
    if column not in allowed_columns:
        raise AssertionError("history filter column is not allowlisted")
    where.append(f"{column} IN ({', '.join('?' for _ in values)})")
    parameters.extend(values)


def _history_entry_from_row(row: sqlite3.Row) -> JobHistoryEntry:
    if (
        int(row["last_transition_sequence"]) != int(row["transition_sequence"])
        or str(row["status"]) != str(row["transition_state"])
    ):
        raise JobStoreError(
            "Stored Job state does not match its last transition.",
            code="JOB_STATE_TRANSITION_MISMATCH",
            object_path="job.state",
        )
    result_json = row["result_ref_json"]
    error_json = row["error_json"]
    return JobHistoryEntry(
        job_id=str(row["job_id"]),
        backend_id=str(row["backend_id"]),
        job_kind=cast(Any, row["job_kind"]),
        program_kind=cast(Any, row["program_kind"]),
        program_hash=str(row["program_hash"]),
        definition_hash=str(row["definition_hash"]),
        status=cast(Any, row["status"]),
        attempt_count=int(row["attempt_count"]),
        total_items=row["total_items"],
        completed_items=row["completed_items"],
        failed_items=row["failed_items"],
        created_at=str(row["created_at"]),
        updated_at=str(row["updated_at"]),
        result_ref=(
            None
            if result_json is None
            else JobResultRefIR.from_json(str(result_json))
        ),
        error_ref=(
            None if error_json is None else JobErrorRefIR.from_json(str(error_json))
        ),
    )


def _sweep_children_from_definition(
    definition: JobDefinitionIR,
) -> list[dict[str, Any]] | None:
    if definition.job_kind == "single":
        return None
    scan_spec = definition.scan_spec()
    if scan_spec is None or not isinstance(scan_spec.get("children"), list):
        raise JobStoreError(
            "Sweep definition must contain materialized child inputs.",
            code="JOB_SWEEP_CHILD_DEFINITION_MISSING",
            object_path="job.definition.scan_spec.children",
        )
    children = scan_spec["children"]
    if not children:
        raise JobStoreError(
            "Sweep definition requires at least one child.",
            code="JOB_SWEEP_CHILD_DEFINITION_EMPTY",
        )
    normalized: list[dict[str, Any]] = []
    for expected_index, raw in enumerate(children):
        if not isinstance(raw, dict) or raw.get("scan_index") != expected_index:
            raise JobStoreError(
                "Sweep child indices must be contiguous and ordered.",
                code="JOB_SWEEP_CHILD_INDEX_INVALID",
            )
        child = dict(raw)
        _require_identifier(child.get("child_id"), field_name="child_id")
        _require_hash(child.get("bind_hash"), field_name="bind_hash")
        _require_hash(child.get("program_hash"), field_name="program_hash")
        if not isinstance(child.get("seed"), int) or isinstance(
            child.get("seed"), bool
        ):
            raise JobStoreError("Sweep child seed must be an integer.")
        if not isinstance(child.get("bind_set"), dict) or not isinstance(
            child.get("program_payload"), dict
        ):
            raise JobStoreError(
                "Sweep child bind and program payloads must be objects."
            )
        normalized.append(child)
    return normalized


def _stored_sweep_child_from_row(row: sqlite3.Row) -> StoredSweepChild:
    artifact_ref = None
    if row["artifact_path"] is not None:
        artifact_ref = SweepChildArtifactRef(
            artifact_path=str(row["artifact_path"]),
            checksum=str(row["checksum"]),
            size_bytes=int(row["size_bytes"]),
            outcome_hash=str(row["outcome_hash"]),
        )
    return StoredSweepChild(
        job_id=str(row["job_id"]),
        scan_index=int(row["scan_index"]),
        child_id=str(row["child_id"]),
        bind_set_json=str(row["bind_set_json"]),
        bind_hash=str(row["bind_hash"]),
        seed=int(row["seed"]),
        program_payload_json=str(row["program_payload_json"]),
        program_hash=str(row["program_hash"]),
        status=str(row["status"]),
        attempt_count=int(row["attempt_count"]),
        updated_at=str(row["updated_at"]),
        artifact_ref=artifact_ref,
        error_json=None if row["error_json"] is None else str(row["error_json"]),
    )


def _sweep_child_state_row(
    connection: sqlite3.Connection,
    job_id: str,
    scan_index: int,
) -> sqlite3.Row:
    row = connection.execute(
        """
        SELECT * FROM sweep_child_state WHERE job_id = ? AND scan_index = ?
        """,
        (job_id, scan_index),
    ).fetchone()
    if row is None:
        raise JobRecoveryError(
            "Sweep child state was not found.",
            code="JOB_SWEEP_CHILD_NOT_FOUND",
        )
    return cast(sqlite3.Row, row)


def _require_running_sweep_child(
    connection: sqlite3.Connection,
    job_id: str,
    scan_index: int,
    attempt_index: int,
) -> sqlite3.Row:
    state = _sweep_child_state_row(connection, job_id, scan_index)
    if str(state["status"]) != "running" or int(
        state["attempt_count"]
    ) != attempt_index:
        raise JobStoreError(
            "Sweep child outcome does not match its active attempt.",
            code="JOB_SWEEP_CHILD_ATTEMPT_MISMATCH",
        )
    return state


def _refresh_sweep_counts(
    connection: sqlite3.Connection,
    job_id: str,
    event_time: str,
) -> None:
    counts = connection.execute(
        """
        SELECT COUNT(*) AS total,
               SUM(status = 'completed') AS completed,
               SUM(status = 'failed') AS failed
        FROM sweep_child_state WHERE job_id = ?
        """,
        (job_id,),
    ).fetchone()
    if counts is None:
        raise JobStoreError("Sweep child counts are unavailable.")
    connection.execute(
        """
        UPDATE job_state
        SET total_items = ?, completed_items = ?, failed_items = ?, updated_at = ?
        WHERE job_id = ?
        """,
        (
            int(counts["total"]),
            int(counts["completed"] or 0),
            int(counts["failed"] or 0),
            event_time,
            job_id,
        ),
    )


def _encode_history_cursor(
    *,
    store_id: str,
    filter_hash: str,
    created_at: str,
    job_id: str,
) -> str:
    core = {
        "store_id": store_id,
        "filter_hash": filter_hash,
        "created_at": created_at,
        "job_id": job_id,
        "store_schema_version": _STORE_SCHEMA_VERSION,
    }
    canonical = json.dumps(core, sort_keys=True, separators=(",", ":"))
    payload = {
        **core,
        "checksum": hashlib.sha256(canonical.encode("utf-8")).hexdigest(),
    }
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode(
        "utf-8"
    )
    return base64.urlsafe_b64encode(encoded).decode("ascii").rstrip("=")


def _decode_history_cursor(
    cursor: str,
    *,
    store_id: str,
    filter_hash: str,
) -> tuple[str, str]:
    try:
        padding = "=" * (-len(cursor) % 4)
        decoded = base64.b64decode(
            cursor + padding,
            altchars=b"-_",
            validate=True,
        )
        payload = json.loads(decoded.decode("utf-8"))
        if not isinstance(payload, dict):
            raise ValueError("cursor payload is not an object")
        expected_keys = {
            "store_id",
            "filter_hash",
            "created_at",
            "job_id",
            "store_schema_version",
            "checksum",
        }
        if set(payload) != expected_keys:
            raise ValueError("cursor fields are invalid")
        checksum = str(payload.pop("checksum"))
        canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"))
        actual = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
        if not secrets.compare_digest(checksum, actual):
            raise ValueError("cursor checksum is invalid")
        if payload["store_schema_version"] != _STORE_SCHEMA_VERSION:
            raise ValueError("cursor schema is unsupported")
        created_at = str(payload["created_at"])
        job_id = str(payload["job_id"])
        _parse_utc(created_at)
        _require_identifier(job_id, field_name="cursor.job_id")
    except (
        binascii.Error,
        UnicodeDecodeError,
        json.JSONDecodeError,
        ValueError,
    ) as exc:
        raise JobRecoveryError(
            "History cursor is invalid or has been tampered with.",
            code="JOB_HISTORY_CURSOR_INVALID",
            object_path="backend.history.cursor",
            cause=exc,
        ) from exc
    if payload["store_id"] != store_id:
        raise JobRecoveryError(
            "History cursor belongs to a different store.",
            code="JOB_HISTORY_CURSOR_STORE_MISMATCH",
            object_path="backend.history.cursor",
        )
    if payload["filter_hash"] != filter_hash:
        raise JobRecoveryError(
            "History cursor does not match the requested filters.",
            code="JOB_HISTORY_CURSOR_FILTER_MISMATCH",
            object_path="backend.history.cursor",
        )
    return created_at, job_id


def _definition_row(connection: sqlite3.Connection, job_id: str) -> sqlite3.Row:
    row = connection.execute(
        "SELECT * FROM job_definitions WHERE job_id = ?",
        (job_id,),
    ).fetchone()
    if row is None:
        raise JobRecoveryError(
            "Persistent Job definition was not found.", code="JOB_NOT_FOUND"
        )
    return cast(sqlite3.Row, row)


def _state_row(connection: sqlite3.Connection, job_id: str) -> sqlite3.Row:
    row = connection.execute(
        "SELECT * FROM job_state WHERE job_id = ?",
        (job_id,),
    ).fetchone()
    if row is None:
        raise JobRecoveryError(
            "Persistent Job state was not found.", code="JOB_NOT_FOUND"
        )
    return cast(sqlite3.Row, row)


def _definition_hash(connection: sqlite3.Connection, job_id: str) -> str:
    return str(_definition_row(connection, job_id)["definition_hash"])


def _require_claim(
    connection: sqlite3.Connection,
    job_id: str,
    token: str,
) -> sqlite3.Row:
    row = connection.execute(
        "SELECT * FROM job_claims WHERE job_id = ?",
        (job_id,),
    ).fetchone()
    if row is None or not secrets.compare_digest(
        str(row["token_hash"]), _token_hash(token)
    ):
        raise JobStoreError(
            "Caller does not own the active Job claim.",
            code="JOB_CLAIM_LOST",
            object_path="job.claim",
        )
    return cast(sqlite3.Row, row)


def _require_running_attempt(
    connection: sqlite3.Connection,
    outcome: JobAttemptOutcomeIR,
) -> sqlite3.Row:
    state = _state_row(connection, outcome.job_id)
    if str(state["status"]) != "running":
        raise JobStoreError("Attempt can finish only while Job state is running.")
    if int(state["attempt_count"]) != outcome.attempt_index:
        raise JobStoreError("Attempt outcome index does not match current Job attempt.")
    existing = connection.execute(
        "SELECT 1 FROM job_attempts WHERE job_id = ? AND attempt_index = ?",
        (outcome.job_id, outcome.attempt_index),
    ).fetchone()
    if existing is None:
        raise JobStoreError("Attempt outcome has no immutable start record.")
    return state


def _insert_outcome(
    connection: sqlite3.Connection,
    outcome: JobAttemptOutcomeIR,
) -> None:
    connection.execute(
        """
        INSERT INTO job_attempt_outcomes (
            job_id, attempt_index, status, result_ref_id, error_ref_id,
            finished_at, outcome_json
        ) VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        (
            outcome.job_id,
            outcome.attempt_index,
            outcome.status,
            outcome.result_ref_id,
            outcome.error_ref_id,
            outcome.finished_at,
            outcome.to_json(),
        ),
    )


def _transition_values(transition: JobTransitionIR) -> tuple[Any, ...]:
    return (
        transition.job_id,
        transition.sequence,
        transition.from_state,
        transition.to_state,
        transition.event_time,
        transition.attempt_index,
        transition.definition_hash,
        transition.reason,
        transition.error_ref_id,
        transition.to_json(),
    )


def _insert_transition(
    connection: sqlite3.Connection,
    transition: JobTransitionIR,
) -> None:
    connection.execute(
        """
        INSERT INTO job_transitions (
            job_id, sequence, from_state, to_state, event_time,
            attempt_index, definition_hash, reason, error_ref_id,
            transition_json
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        _transition_values(transition),
    )


def _update_terminal_state(
    connection: sqlite3.Connection,
    transition: JobTransitionIR,
) -> None:
    connection.execute(
        """
        UPDATE job_state
        SET status = ?, last_transition_sequence = ?, updated_at = ?
        WHERE job_id = ?
        """,
        (
            transition.to_state,
            transition.sequence,
            transition.event_time,
            transition.job_id,
        ),
    )


def _token_hash(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def _parse_utc(value: str) -> datetime:
    normalized = value[:-1] + "+00:00" if value.endswith("Z") else value
    try:
        parsed = datetime.fromisoformat(normalized)
    except ValueError as exc:
        raise ValueError("timestamp must be ISO-8601 UTC.") from exc
    if parsed.tzinfo is None or parsed.utcoffset() != timedelta(0):
        raise ValueError("timestamp must include UTC timezone.")
    return parsed


def _format_utc(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _require_identifier(value: object, *, field_name: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field_name} must be a non-empty string.")


def _require_hash(value: object, *, field_name: str) -> None:
    if (
        not isinstance(value, str)
        or len(value) != 64
        or any(char not in "0123456789abcdef" for char in value)
    ):
        raise ValueError(f"{field_name} must be a lowercase SHA-256 hex digest.")


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _fsync_directory(path: Path) -> None:
    descriptor = os.open(path, os.O_RDONLY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def _sqlite_error(exc: sqlite3.Error) -> JobStoreError:
    return cast(
        JobStoreError,
        JobStoreError(
            f"SQLite Job store operation failed: {exc}",
            code="JOB_STORE_SQLITE_ERROR",
            object_path="backend.store",
            cause=exc,
        ),
    )


_SCHEMA_V2_SQL = """
BEGIN IMMEDIATE;

CREATE TABLE IF NOT EXISTS store_metadata (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    store_id TEXT NOT NULL UNIQUE,
    schema_version INTEGER NOT NULL CHECK (schema_version = 2),
    created_at TEXT NOT NULL
);

INSERT OR IGNORE INTO store_metadata (
    singleton, store_id, schema_version, created_at
) VALUES (
    1, lower(hex(randomblob(16))), 2,
    strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
);

CREATE TABLE IF NOT EXISTS submission_sequence (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    next_sequence INTEGER NOT NULL CHECK (next_sequence >= 1)
);
INSERT OR IGNORE INTO submission_sequence (singleton, next_sequence) VALUES (1, 1);

CREATE TABLE IF NOT EXISTS job_definitions (
    job_id TEXT PRIMARY KEY,
    backend_id TEXT NOT NULL,
    job_kind TEXT NOT NULL CHECK (job_kind IN ('single', 'sweep')),
    program_kind TEXT NOT NULL CHECK (program_kind IN ('digital', 'analog', 'hybrid')),
    program_hash TEXT NOT NULL CHECK (length(program_hash) = 64),
    definition_hash TEXT NOT NULL CHECK (length(definition_hash) = 64),
    idempotency_key TEXT NOT NULL,
    idempotency_explicit INTEGER NOT NULL CHECK (idempotency_explicit IN (0, 1)),
    definition_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    submission_sequence INTEGER NOT NULL UNIQUE CHECK (submission_sequence >= 1),
    UNIQUE (backend_id, idempotency_key)
);

CREATE TABLE IF NOT EXISTS job_state (
    job_id TEXT PRIMARY KEY REFERENCES job_definitions(job_id),
    status TEXT NOT NULL CHECK (status IN (
        'created', 'queued', 'running', 'completed',
        'partially_completed', 'failed', 'cancelled', 'expired'
    )),
    attempt_count INTEGER NOT NULL CHECK (attempt_count >= 0),
    last_transition_sequence INTEGER NOT NULL CHECK (last_transition_sequence >= 1),
    updated_at TEXT NOT NULL,
    total_items INTEGER CHECK (total_items IS NULL OR total_items >= 0),
    completed_items INTEGER CHECK (completed_items IS NULL OR completed_items >= 0),
    failed_items INTEGER CHECK (failed_items IS NULL OR failed_items >= 0)
);

CREATE TABLE IF NOT EXISTS job_attempts (
    job_id TEXT NOT NULL REFERENCES job_definitions(job_id),
    attempt_index INTEGER NOT NULL CHECK (attempt_index >= 1),
    claim_token_hash TEXT NOT NULL CHECK (length(claim_token_hash) = 64),
    definition_hash TEXT NOT NULL CHECK (length(definition_hash) = 64),
    program_hash TEXT NOT NULL CHECK (length(program_hash) = 64),
    parameter_bind_hash TEXT CHECK (
        parameter_bind_hash IS NULL OR length(parameter_bind_hash) = 64
    ),
    seed TEXT NOT NULL,
    started_at TEXT NOT NULL,
    attempt_json TEXT NOT NULL,
    PRIMARY KEY (job_id, attempt_index)
);

CREATE TABLE IF NOT EXISTS job_attempt_outcomes (
    job_id TEXT NOT NULL,
    attempt_index INTEGER NOT NULL,
    status TEXT NOT NULL CHECK (status IN (
        'completed', 'retryable_failure', 'non_retryable_failure', 'interrupted'
    )),
    result_ref_id TEXT,
    error_ref_id TEXT,
    finished_at TEXT NOT NULL,
    outcome_json TEXT NOT NULL,
    PRIMARY KEY (job_id, attempt_index),
    FOREIGN KEY (job_id, attempt_index)
        REFERENCES job_attempts(job_id, attempt_index),
    CHECK (
        (status = 'completed' AND result_ref_id IS NOT NULL AND error_ref_id IS NULL)
        OR
        (status != 'completed' AND result_ref_id IS NULL AND error_ref_id IS NOT NULL)
    )
);

CREATE TABLE IF NOT EXISTS job_transitions (
    job_id TEXT NOT NULL REFERENCES job_definitions(job_id),
    sequence INTEGER NOT NULL CHECK (sequence >= 1),
    from_state TEXT,
    to_state TEXT NOT NULL,
    event_time TEXT NOT NULL,
    attempt_index INTEGER,
    definition_hash TEXT NOT NULL CHECK (length(definition_hash) = 64),
    reason TEXT NOT NULL,
    error_ref_id TEXT,
    transition_json TEXT NOT NULL,
    PRIMARY KEY (job_id, sequence)
);

CREATE TABLE IF NOT EXISTS job_result_refs (
    ref_id TEXT PRIMARY KEY,
    job_id TEXT NOT NULL UNIQUE REFERENCES job_definitions(job_id),
    attempt_index INTEGER NOT NULL,
    result_kind TEXT NOT NULL CHECK (result_kind IN ('result', 'sweep_result')),
    result_id TEXT NOT NULL,
    result_hash TEXT NOT NULL CHECK (length(result_hash) = 64),
    checksum TEXT NOT NULL CHECK (length(checksum) = 64),
    artifact_path TEXT NOT NULL,
    result_ref_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY (job_id, attempt_index)
        REFERENCES job_attempts(job_id, attempt_index)
);

CREATE TABLE IF NOT EXISTS job_error_refs (
    error_ref_id TEXT PRIMARY KEY,
    job_id TEXT NOT NULL REFERENCES job_definitions(job_id),
    attempt_index INTEGER NOT NULL,
    code TEXT NOT NULL,
    retryable INTEGER NOT NULL CHECK (retryable IN (0, 1)),
    error_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY (job_id, attempt_index)
        REFERENCES job_attempts(job_id, attempt_index)
);

CREATE TABLE IF NOT EXISTS job_claims (
    job_id TEXT PRIMARY KEY REFERENCES job_definitions(job_id),
    token_hash TEXT NOT NULL CHECK (length(token_hash) = 64),
    owner_id TEXT NOT NULL,
    acquired_at TEXT NOT NULL,
    expires_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sweep_children (
    job_id TEXT NOT NULL REFERENCES job_definitions(job_id),
    scan_index INTEGER NOT NULL CHECK (scan_index >= 0),
    child_id TEXT NOT NULL UNIQUE,
    bind_set_json TEXT NOT NULL,
    bind_hash TEXT NOT NULL CHECK (length(bind_hash) = 64),
    seed TEXT NOT NULL,
    program_payload_json TEXT NOT NULL,
    program_hash TEXT NOT NULL CHECK (length(program_hash) = 64),
    PRIMARY KEY (job_id, scan_index)
);

CREATE TABLE IF NOT EXISTS sweep_child_state (
    job_id TEXT NOT NULL,
    scan_index INTEGER NOT NULL,
    status TEXT NOT NULL CHECK (status IN (
        'pending', 'running', 'completed', 'failed', 'not_run', 'cancelled'
    )),
    attempt_count INTEGER NOT NULL CHECK (attempt_count >= 0),
    updated_at TEXT NOT NULL,
    artifact_path TEXT,
    checksum TEXT CHECK (checksum IS NULL OR length(checksum) = 64),
    size_bytes INTEGER CHECK (size_bytes IS NULL OR size_bytes >= 0),
    outcome_hash TEXT CHECK (outcome_hash IS NULL OR length(outcome_hash) = 64),
    error_json TEXT,
    PRIMARY KEY (job_id, scan_index),
    FOREIGN KEY (job_id, scan_index)
        REFERENCES sweep_children(job_id, scan_index),
    CHECK (
        (status = 'completed' AND artifact_path IS NOT NULL
            AND checksum IS NOT NULL AND size_bytes IS NOT NULL
            AND outcome_hash IS NOT NULL)
        OR status != 'completed'
    )
);

CREATE TABLE IF NOT EXISTS sweep_child_attempts (
    job_id TEXT NOT NULL,
    scan_index INTEGER NOT NULL,
    attempt_index INTEGER NOT NULL CHECK (attempt_index >= 1),
    bind_hash TEXT NOT NULL CHECK (length(bind_hash) = 64),
    seed INTEGER NOT NULL,
    program_hash TEXT NOT NULL CHECK (length(program_hash) = 64),
    started_at TEXT NOT NULL,
    PRIMARY KEY (job_id, scan_index, attempt_index),
    FOREIGN KEY (job_id, scan_index)
        REFERENCES sweep_children(job_id, scan_index)
);

CREATE TABLE IF NOT EXISTS sweep_child_outcomes (
    job_id TEXT NOT NULL,
    scan_index INTEGER NOT NULL,
    attempt_index INTEGER NOT NULL,
    status TEXT NOT NULL CHECK (status IN (
        'completed', 'retryable_failure', 'failed', 'interrupted'
    )),
    finished_at TEXT NOT NULL,
    artifact_path TEXT,
    checksum TEXT CHECK (checksum IS NULL OR length(checksum) = 64),
    size_bytes INTEGER CHECK (size_bytes IS NULL OR size_bytes >= 0),
    outcome_hash TEXT CHECK (outcome_hash IS NULL OR length(outcome_hash) = 64),
    error_json TEXT,
    PRIMARY KEY (job_id, scan_index, attempt_index),
    FOREIGN KEY (job_id, scan_index, attempt_index)
        REFERENCES sweep_child_attempts(job_id, scan_index, attempt_index),
    CHECK (
        (status = 'completed' AND artifact_path IS NOT NULL
            AND checksum IS NOT NULL AND size_bytes IS NOT NULL
            AND outcome_hash IS NOT NULL AND error_json IS NULL)
        OR
        (status != 'completed' AND artifact_path IS NULL
            AND checksum IS NULL AND size_bytes IS NULL
            AND outcome_hash IS NULL AND error_json IS NOT NULL)
    )
);

CREATE INDEX IF NOT EXISTS idx_job_definitions_history
    ON job_definitions(created_at DESC, job_id DESC);
CREATE INDEX IF NOT EXISTS idx_job_state_status ON job_state(status);
CREATE INDEX IF NOT EXISTS idx_job_definitions_program_kind
    ON job_definitions(program_kind);

CREATE TRIGGER IF NOT EXISTS immutable_store_metadata_update
BEFORE UPDATE ON store_metadata BEGIN
    SELECT RAISE(ABORT, 'store_metadata is immutable');
END;
CREATE TRIGGER IF NOT EXISTS immutable_store_metadata_delete
BEFORE DELETE ON store_metadata BEGIN
    SELECT RAISE(ABORT, 'store_metadata is immutable');
END;

CREATE TRIGGER IF NOT EXISTS immutable_job_definitions_update
BEFORE UPDATE ON job_definitions BEGIN
    SELECT RAISE(ABORT, 'job_definitions is immutable');
END;
CREATE TRIGGER IF NOT EXISTS immutable_job_definitions_delete
BEFORE DELETE ON job_definitions BEGIN
    SELECT RAISE(ABORT, 'job_definitions is immutable');
END;
CREATE TRIGGER IF NOT EXISTS immutable_job_attempts_update
BEFORE UPDATE ON job_attempts BEGIN
    SELECT RAISE(ABORT, 'job_attempts is immutable');
END;
CREATE TRIGGER IF NOT EXISTS immutable_job_attempts_delete
BEFORE DELETE ON job_attempts BEGIN
    SELECT RAISE(ABORT, 'job_attempts is immutable');
END;
CREATE TRIGGER IF NOT EXISTS immutable_job_attempt_outcomes_update
BEFORE UPDATE ON job_attempt_outcomes BEGIN
    SELECT RAISE(ABORT, 'job_attempt_outcomes is immutable');
END;
CREATE TRIGGER IF NOT EXISTS immutable_job_attempt_outcomes_delete
BEFORE DELETE ON job_attempt_outcomes BEGIN
    SELECT RAISE(ABORT, 'job_attempt_outcomes is immutable');
END;
CREATE TRIGGER IF NOT EXISTS immutable_job_transitions_update
BEFORE UPDATE ON job_transitions BEGIN
    SELECT RAISE(ABORT, 'job_transitions is immutable');
END;
CREATE TRIGGER IF NOT EXISTS immutable_job_transitions_delete
BEFORE DELETE ON job_transitions BEGIN
    SELECT RAISE(ABORT, 'job_transitions is immutable');
END;
CREATE TRIGGER IF NOT EXISTS immutable_job_result_refs_update
BEFORE UPDATE ON job_result_refs BEGIN
    SELECT RAISE(ABORT, 'job_result_refs is immutable');
END;
CREATE TRIGGER IF NOT EXISTS immutable_job_result_refs_delete
BEFORE DELETE ON job_result_refs BEGIN
    SELECT RAISE(ABORT, 'job_result_refs is immutable');
END;
CREATE TRIGGER IF NOT EXISTS immutable_job_error_refs_update
BEFORE UPDATE ON job_error_refs BEGIN
    SELECT RAISE(ABORT, 'job_error_refs is immutable');
END;
CREATE TRIGGER IF NOT EXISTS immutable_job_error_refs_delete
BEFORE DELETE ON job_error_refs BEGIN
    SELECT RAISE(ABORT, 'job_error_refs is immutable');
END;
CREATE TRIGGER IF NOT EXISTS immutable_sweep_children_update
BEFORE UPDATE ON sweep_children BEGIN
    SELECT RAISE(ABORT, 'sweep_children is immutable');
END;
CREATE TRIGGER IF NOT EXISTS immutable_sweep_children_delete
BEFORE DELETE ON sweep_children BEGIN
    SELECT RAISE(ABORT, 'sweep_children is immutable');
END;
CREATE TRIGGER IF NOT EXISTS immutable_sweep_child_attempts_update
BEFORE UPDATE ON sweep_child_attempts BEGIN
    SELECT RAISE(ABORT, 'sweep_child_attempts is immutable');
END;
CREATE TRIGGER IF NOT EXISTS immutable_sweep_child_attempts_delete
BEFORE DELETE ON sweep_child_attempts BEGIN
    SELECT RAISE(ABORT, 'sweep_child_attempts is immutable');
END;
CREATE TRIGGER IF NOT EXISTS immutable_sweep_child_outcomes_update
BEFORE UPDATE ON sweep_child_outcomes BEGIN
    SELECT RAISE(ABORT, 'sweep_child_outcomes is immutable');
END;
CREATE TRIGGER IF NOT EXISTS immutable_sweep_child_outcomes_delete
BEFORE DELETE ON sweep_child_outcomes BEGIN
    SELECT RAISE(ABORT, 'sweep_child_outcomes is immutable');
END;

PRAGMA user_version = 2;
COMMIT;
"""
