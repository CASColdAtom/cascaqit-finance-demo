"""Public hardware-client Job contracts.

Private compiled programs, execution packages, and executor payloads are owned
by ``services/cascaqit_private_hardware`` and must not appear in this module.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Protocol

from cascaqit.backends.job_state import JobState, validate_job_state
from cascaqit.native_ir.base import IRMixin
from cascaqit.native_ir.models import SCHEMA_VERSION
from cascaqit.results import ResultIR

if TYPE_CHECKING:
    from cascaqit.submission import HardwareSubmissionIR

__all__ = [
    "BackendProtocol",
    "JobRef",
    "JobResult",
    "JobStatus",
]


@dataclass(frozen=True)
class JobStatus(IRMixin):
    """Sanitized backend-neutral snapshot using the canonical lifecycle."""

    job_id: str
    state: JobState
    backend_id: str
    message: str | None = None
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        validate_job_state(self.state)
        if not self.job_id:
            raise ValueError("JobStatus.job_id must be a non-empty string.")
        if not self.backend_id:
            raise ValueError("JobStatus.backend_id must be a non-empty string.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> JobStatus:
        if not isinstance(data, dict):
            raise TypeError("JobStatus dictionary must be an object.")
        return cls(
            job_id=str(data["job_id"]),
            state=validate_job_state(data["state"]),
            backend_id=str(data["backend_id"]),
            message=data.get("message"),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> JobStatus:
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("JobStatus JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class JobRef(IRMixin):
    """Public reference to a Job created from one hardware submission."""

    job_id: str
    backend_id: str
    submission_id: str
    status: JobStatus
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.submission_id:
            raise ValueError("JobRef.submission_id must be a non-empty string.")
        if self.status.job_id != self.job_id:
            raise ValueError("JobRef status job_id must match JobRef.job_id.")
        if self.status.backend_id != self.backend_id:
            raise ValueError("JobRef status backend_id must match JobRef.backend_id.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> JobRef:
        if not isinstance(data, dict):
            raise TypeError("JobRef dictionary must be an object.")
        return cls(
            job_id=str(data["job_id"]),
            backend_id=str(data["backend_id"]),
            submission_id=str(data["submission_id"]),
            status=JobStatus.from_dict(dict(data["status"])),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> JobRef:
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("JobRef JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class JobResult(IRMixin):
    """Sanitized result envelope returned by a hardware client."""

    job_ref: JobRef
    result: ResultIR
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.job_ref.status.state not in {"completed", "partially_completed"}:
            raise ValueError("JobResult requires a result-bearing terminal Job state.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> JobResult:
        if not isinstance(data, dict):
            raise TypeError("JobResult dictionary must be an object.")
        return cls(
            job_ref=JobRef.from_dict(dict(data["job_ref"])),
            result=ResultIR.from_dict(dict(data["result"])),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> JobResult:
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("JobResult JSON must contain an object.")
        return cls.from_dict(data)


class BackendProtocol(Protocol):
    """Public client boundary for submitting sanitized hardware requests."""

    backend_id: str

    def submit(self, submission: HardwareSubmissionIR) -> JobRef:
        """Submit one public hardware request."""

    def status(self, job_id: str) -> JobStatus:
        """Return a sanitized Job status."""

    def result(self, job_id: str) -> ResultIR:
        """Return a sanitized result after a result-bearing terminal state."""

    def cancel(self, job_id: str) -> None:
        """Request cancellation of a non-terminal Job."""
