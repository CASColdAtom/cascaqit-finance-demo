"""Backend configuration, capability, and error contracts."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Literal, cast

from cascaqit.diagnostics import DiagnosticsIR
from cascaqit.native_ir.base import IRMixin
from cascaqit.native_ir.models import SCHEMA_VERSION

if TYPE_CHECKING:
    from cascaqit.backends.transport import BackendTransportPolicyIR
    from cascaqit.readiness import (
        CredentialProfileIR,
        CredentialRefIR,
        CredentialRequirementIR,
    )

__all__ = [
    "BackendCapabilitiesIR",
    "BackendConfigIR",
    "BackendErrorIR",
    "BackendErrorCategory",
    "BackendEndpointProfileIR",
    "BackendKind",
    "EndpointAllowlistIR",
    "EndpointExecutionMode",
    "TransportKind",
    "validate_endpoint_profile",
]

BackendKind = Literal["local_simulator", "hardware_mock", "hanyuan", "cloud"]
TransportKind = Literal["in_memory", "fake", "http", "grpc", "cloud"]
EndpointExecutionMode = Literal["offline", "fake", "dry_run", "live_opt_in"]
BackendErrorCategory = Literal[
    "configuration",
    "transport",
    "submission",
    "status",
    "result",
    "cancellation",
    "capability",
    "calibration",
    "unknown",
]

_SECRET_KEY_MARKERS = (
    "access_key",
    "api_key",
    "apikey",
    "authorization",
    "credential",
    "password",
    "private_key",
    "private_endpoint",
    "secret",
    "token",
    "endpoint_url",
)
_OFFLINE_ENDPOINT_MODES = frozenset({"offline", "fake", "dry_run"})
_LIVE_TRANSPORTS = frozenset({"http", "grpc", "cloud"})
_PRIVATE_HOST_PREFIXES = (
    "127.",
    "10.",
    "192.168.",
    "172.16.",
    "172.17.",
    "172.18.",
    "172.19.",
    "172.2",
    "172.30.",
    "172.31.",
)


@dataclass(frozen=True)
class BackendConfigIR(IRMixin):
    """Configuration metadata for backend construction."""

    backend_id: str
    backend_kind: BackendKind
    transport: TransportKind
    endpoint: str | None = None
    target_id: str | None = None
    calibration_profile_id: str | None = None
    timeout_seconds: float | None = None
    retry_policy: dict[str, Any] = field(default_factory=dict)
    credential_ref: str | None = None
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Ensure config metadata cannot retain raw secret-like values."""
        object.__setattr__(self, "retry_policy", _redact_mapping(self.retry_policy))
        object.__setattr__(self, "metadata", _redact_mapping(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> BackendConfigIR:
        """Build backend config from a JSON-compatible dictionary."""
        timeout = data.get("timeout_seconds")
        return cls(
            backend_id=str(data["backend_id"]),
            backend_kind=data["backend_kind"],
            transport=data["transport"],
            endpoint=data.get("endpoint"),
            target_id=data.get("target_id"),
            calibration_profile_id=data.get("calibration_profile_id"),
            timeout_seconds=None if timeout is None else float(timeout),
            retry_policy=dict(data.get("retry_policy", {})),
            credential_ref=data.get("credential_ref"),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> BackendConfigIR:
        """Build backend config from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("BackendConfigIR JSON must contain an object.")
        return cls.from_dict(data)

    def redacted(self) -> BackendConfigIR:
        """Return a copy that redacts known secret-like metadata fields."""
        return BackendConfigIR.from_dict(
            {
                **self.to_dict(),
                "metadata": _redact_mapping(self.metadata),
            }
        )

    def transport_policy(self) -> BackendTransportPolicyIR:
        """Return the typed transport policy derived from config fields."""
        from cascaqit.backends.transport import BackendTransportPolicyIR

        return BackendTransportPolicyIR.from_backend_config(
            self.retry_policy,
            timeout_seconds=self.timeout_seconds,
        )


@dataclass(frozen=True)
class EndpointAllowlistIR(IRMixin):
    """Endpoint allowlist policy for explicit live-opt-in backend profiles."""

    allowlist_id: str
    allowed_endpoints: tuple[str, ...] = ()
    allowed_hosts: tuple[str, ...] = ()
    allow_private_endpoints: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize endpoint policy data and redact policy metadata."""
        object.__setattr__(
            self,
            "allowed_endpoints",
            tuple(str(endpoint) for endpoint in self.allowed_endpoints),
        )
        object.__setattr__(
            self,
            "allowed_hosts",
            tuple(str(host) for host in self.allowed_hosts),
        )
        object.__setattr__(self, "metadata", _redact_mapping(self.metadata))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> EndpointAllowlistIR:
        """Build an endpoint allowlist from a JSON-compatible dictionary."""
        return cls(
            allowlist_id=str(data["allowlist_id"]),
            allowed_endpoints=tuple(
                str(item) for item in data.get("allowed_endpoints", ())
            ),
            allowed_hosts=tuple(str(item) for item in data.get("allowed_hosts", ())),
            allow_private_endpoints=bool(
                data.get("allow_private_endpoints", False)
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> EndpointAllowlistIR:
        """Build an endpoint allowlist from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("EndpointAllowlistIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class BackendEndpointProfileIR(IRMixin):
    """Typed endpoint/profile contract for backend construction safety."""

    endpoint_profile_id: str
    provider: str
    backend_id: str
    backend_kind: BackendKind
    transport: TransportKind
    execution_mode: EndpointExecutionMode
    endpoint_ref: str | None = None
    target_id: str | None = None
    calibration_profile_id: str | None = None
    credential_requirement: CredentialRequirementIR | None = None
    credential_ref: CredentialRefIR | None = None
    endpoint_allowlist: EndpointAllowlistIR | None = None
    opt_in_marker: str | None = None
    network_access_required: bool = False
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Validate endpoint mode shape without opening network or secrets."""
        if self.execution_mode not in ("offline", "fake", "dry_run", "live_opt_in"):
            raise ValueError(
                f"Unsupported endpoint execution mode: {self.execution_mode}"
            )
        from cascaqit.readiness import CredentialRefIR, CredentialRequirementIR

        if self.credential_ref is not None and not isinstance(
            self.credential_ref,
            CredentialRefIR,
        ):
            raise TypeError("credential_ref must be CredentialRefIR or None.")
        if self.credential_requirement is not None and not isinstance(
            self.credential_requirement,
            CredentialRequirementIR,
        ):
            raise TypeError(
                "credential_requirement must be CredentialRequirementIR or None."
            )
        if self.endpoint_allowlist is not None and not isinstance(
            self.endpoint_allowlist,
            EndpointAllowlistIR,
        ):
            raise TypeError("endpoint_allowlist must be EndpointAllowlistIR or None.")
        object.__setattr__(self, "metadata", _redact_mapping(self.metadata))

    @classmethod
    def from_backend_config(
        cls,
        config: BackendConfigIR,
        *,
        provider: str,
        execution_mode: EndpointExecutionMode = "fake",
        credential_requirement: CredentialRequirementIR | None = None,
        credential_ref: CredentialRefIR | None = None,
        endpoint_allowlist: EndpointAllowlistIR | None = None,
        opt_in_marker: str | None = None,
        network_access_required: bool = False,
        endpoint_profile_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> BackendEndpointProfileIR:
        """Build an endpoint profile from legacy backend configuration fields."""
        if not isinstance(config, BackendConfigIR):
            raise TypeError("from_backend_config accepts BackendConfigIR.")
        return cls(
            endpoint_profile_id=(
                endpoint_profile_id or f"endpoint_profile.{config.backend_id}"
            ),
            provider=provider,
            backend_id=config.backend_id,
            backend_kind=config.backend_kind,
            transport=config.transport,
            execution_mode=execution_mode,
            endpoint_ref=config.endpoint,
            target_id=config.target_id,
            calibration_profile_id=config.calibration_profile_id,
            credential_requirement=credential_requirement,
            credential_ref=credential_ref,
            endpoint_allowlist=endpoint_allowlist,
            opt_in_marker=opt_in_marker,
            network_access_required=network_access_required,
            metadata={
                **config.metadata,
                **({} if metadata is None else metadata),
                "source": "BackendConfigIR",
                "credential_ref": config.credential_ref,
            },
        )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> BackendEndpointProfileIR:
        """Build an endpoint profile from a JSON-compatible dictionary."""
        return cls(
            endpoint_profile_id=str(data["endpoint_profile_id"]),
            provider=str(data["provider"]),
            backend_id=str(data["backend_id"]),
            backend_kind=cast(BackendKind, data["backend_kind"]),
            transport=cast(TransportKind, data["transport"]),
            execution_mode=cast(EndpointExecutionMode, data["execution_mode"]),
            endpoint_ref=data.get("endpoint_ref"),
            target_id=data.get("target_id"),
            calibration_profile_id=data.get("calibration_profile_id"),
            credential_requirement=_credential_requirement_from_optional(
                data.get("credential_requirement")
            ),
            credential_ref=_credential_ref_from_optional(data.get("credential_ref")),
            endpoint_allowlist=_endpoint_allowlist_from_optional(
                data.get("endpoint_allowlist")
            ),
            opt_in_marker=data.get("opt_in_marker"),
            network_access_required=bool(data.get("network_access_required", False)),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> BackendEndpointProfileIR:
        """Build an endpoint profile from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("BackendEndpointProfileIR JSON must contain an object.")
        return cls.from_dict(data)


def validate_endpoint_profile(
    profile: BackendEndpointProfileIR,
    *,
    credential_profile: CredentialProfileIR | None = None,
) -> tuple[DiagnosticsIR, ...]:
    """Validate endpoint/profile metadata without network or secret access."""
    from cascaqit.readiness import CredentialProfileIR

    if not isinstance(profile, BackendEndpointProfileIR):
        raise TypeError("profile must be BackendEndpointProfileIR.")
    if credential_profile is not None and not isinstance(
        credential_profile,
        CredentialProfileIR,
    ):
        raise TypeError("credential_profile must be CredentialProfileIR or None.")
    diagnostics = [
        _diagnostic(
            diagnostic_id=f"diagnostic.{profile.endpoint_profile_id}.offline",
            severity="info",
            code="ENDPOINT_PROFILE_OFFLINE",
            message=(
                "Endpoint profile validation uses metadata only and does not "
                "access network or raw credentials."
            ),
            metadata={
                "endpoint_profile_id": profile.endpoint_profile_id,
                "backend_id": profile.backend_id,
                "execution_mode": profile.execution_mode,
            },
        )
    ]
    diagnostics.extend(_endpoint_profile_shape_diagnostics(profile))
    diagnostics.extend(
        _endpoint_profile_credential_diagnostics(
            profile,
            credential_profile=credential_profile,
        )
    )
    return tuple(diagnostics)


@dataclass(frozen=True)
class BackendCapabilitiesIR(IRMixin):
    """Backend capabilities and supported execution features."""

    backend_id: str
    backend_kind: BackendKind
    supported_program_types: tuple[str, ...]
    supported_workload_types: tuple[str, ...]
    supports_batch: bool
    supports_cancel: bool
    supports_artifacts: bool
    max_shots: int | None = None
    max_batch_items: int | None = None
    target_snapshot_hash: str | None = None
    calibration_snapshot_hash: str | None = None
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> BackendCapabilitiesIR:
        """Build backend capabilities from a JSON-compatible dictionary."""
        return cls(
            backend_id=str(data["backend_id"]),
            backend_kind=data["backend_kind"],
            supported_program_types=tuple(
                str(item) for item in data.get("supported_program_types", ())
            ),
            supported_workload_types=tuple(
                str(item) for item in data.get("supported_workload_types", ())
            ),
            supports_batch=bool(data["supports_batch"]),
            supports_cancel=bool(data["supports_cancel"]),
            supports_artifacts=bool(data["supports_artifacts"]),
            max_shots=None
            if data.get("max_shots") is None
            else int(data["max_shots"]),
            max_batch_items=None
            if data.get("max_batch_items") is None
            else int(data["max_batch_items"]),
            target_snapshot_hash=data.get("target_snapshot_hash"),
            calibration_snapshot_hash=data.get("calibration_snapshot_hash"),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> BackendCapabilitiesIR:
        """Build backend capabilities from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("BackendCapabilitiesIR JSON must contain an object.")
        return cls.from_dict(data)


@dataclass(frozen=True)
class BackendErrorIR(IRMixin):
    """Standardized backend error with raw error preservation."""

    error_id: str
    backend_id: str
    category: BackendErrorCategory
    code: str
    message: str
    retryable: bool
    raw_error: dict[str, Any] = field(default_factory=dict)
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> BackendErrorIR:
        """Build backend error from a JSON-compatible dictionary."""
        return cls(
            error_id=str(data["error_id"]),
            backend_id=str(data["backend_id"]),
            category=data["category"],
            code=str(data["code"]),
            message=str(data["message"]),
            retryable=bool(data["retryable"]),
            raw_error=dict(data.get("raw_error", {})),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> BackendErrorIR:
        """Build backend error from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("BackendErrorIR JSON must contain an object.")
        return cls.from_dict(data)

    def redacted(self) -> BackendErrorIR:
        """Return a copy with secret-like raw error and metadata values redacted."""
        return BackendErrorIR.from_dict(
            {
                **self.to_dict(),
                "raw_error": _redact_mapping(self.raw_error),
                "metadata": _redact_mapping(self.metadata),
            }
        )


def _redact_mapping(data: dict[str, Any]) -> dict[str, Any]:
    """Redact common secret-like keys in a JSON-compatible mapping."""
    redacted: dict[str, Any] = {}
    for key, value in data.items():
        lowered = str(key).lower()
        if any(token in lowered for token in _SECRET_KEY_MARKERS):
            redacted[str(key)] = "<redacted>"
        else:
            redacted[str(key)] = _redact_value(value)
    return redacted


def _redact_value(value: Any) -> Any:
    """Recursively redact secret-like dictionary entries in JSON-like values."""
    if isinstance(value, dict):
        return _redact_mapping(value)
    if isinstance(value, list):
        return [_redact_value(item) for item in value]
    if isinstance(value, tuple):
        return tuple(_redact_value(item) for item in value)
    return value


def _credential_ref_from_optional(value: Any) -> CredentialRefIR | None:
    from cascaqit.readiness import CredentialRefIR

    if value is None:
        return None
    if isinstance(value, CredentialRefIR):
        return value
    if isinstance(value, dict):
        return CredentialRefIR.from_dict(value)
    raise TypeError("credential_ref must be CredentialRefIR, object, or null.")


def _credential_requirement_from_optional(
    value: Any,
) -> CredentialRequirementIR | None:
    from cascaqit.readiness import CredentialRequirementIR

    if value is None:
        return None
    if isinstance(value, CredentialRequirementIR):
        return value
    if isinstance(value, dict):
        return CredentialRequirementIR.from_dict(value)
    raise TypeError(
        "credential_requirement must be CredentialRequirementIR, object, or null."
    )


def _endpoint_allowlist_from_optional(value: Any) -> EndpointAllowlistIR | None:
    if value is None:
        return None
    if isinstance(value, EndpointAllowlistIR):
        return value
    if isinstance(value, dict):
        return EndpointAllowlistIR.from_dict(value)
    raise TypeError("endpoint_allowlist must be EndpointAllowlistIR, object, or null.")


def _endpoint_profile_shape_diagnostics(
    profile: BackendEndpointProfileIR,
) -> list[DiagnosticsIR]:
    diagnostics: list[DiagnosticsIR] = []
    if profile.execution_mode in _OFFLINE_ENDPOINT_MODES:
        if profile.network_access_required:
            diagnostics.append(
                _diagnostic(
                    diagnostic_id=(
                        f"diagnostic.{profile.endpoint_profile_id}.network"
                    ),
                    severity="error",
                    code="ENDPOINT_PROFILE_NETWORK_REQUIRES_LIVE_OPT_IN",
                    message=(
                        "Network access is only valid for explicit live opt-in "
                        "endpoint profiles."
                    ),
                    object_path="network_access_required",
                )
            )
        if profile.transport in _LIVE_TRANSPORTS:
            diagnostics.append(
                _diagnostic(
                    diagnostic_id=(
                        f"diagnostic.{profile.endpoint_profile_id}.transport"
                    ),
                    severity="error",
                    code="ENDPOINT_PROFILE_LIVE_TRANSPORT_WITHOUT_OPT_IN",
                    message=(
                        "Live transports require execution_mode='live_opt_in'."
                    ),
                    object_path="transport",
                )
            )
    if profile.execution_mode == "live_opt_in":
        diagnostics.extend(_live_opt_in_diagnostics(profile))
    return diagnostics


def _live_opt_in_diagnostics(
    profile: BackendEndpointProfileIR,
) -> list[DiagnosticsIR]:
    diagnostics: list[DiagnosticsIR] = []
    if not profile.network_access_required:
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"diagnostic.{profile.endpoint_profile_id}.live_network",
                severity="error",
                code="ENDPOINT_PROFILE_LIVE_NETWORK_DISABLED",
                message="Live opt-in endpoint profiles must require network access.",
                object_path="network_access_required",
            )
        )
    if profile.transport not in _LIVE_TRANSPORTS:
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"diagnostic.{profile.endpoint_profile_id}.live_transport",
                severity="error",
                code="ENDPOINT_PROFILE_LIVE_TRANSPORT_MISSING",
                message="Live opt-in endpoint profiles must use a live transport.",
                object_path="transport",
            )
        )
    if not profile.opt_in_marker:
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"diagnostic.{profile.endpoint_profile_id}.opt_in",
                severity="error",
                code="ENDPOINT_PROFILE_OPT_IN_MARKER_MISSING",
                message="Live opt-in endpoint profiles require an opt-in marker.",
                object_path="opt_in_marker",
            )
        )
    if not profile.endpoint_ref:
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"diagnostic.{profile.endpoint_profile_id}.endpoint",
                severity="error",
                code="ENDPOINT_PROFILE_ENDPOINT_MISSING",
                message="Live opt-in endpoint profiles require an endpoint reference.",
                object_path="endpoint_ref",
            )
        )
    if profile.endpoint_allowlist is None:
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"diagnostic.{profile.endpoint_profile_id}.allowlist",
                severity="error",
                code="ENDPOINT_PROFILE_ALLOWLIST_MISSING",
                message="Live opt-in endpoint profiles require an endpoint allowlist.",
                object_path="endpoint_allowlist",
            )
        )
    elif _is_private_endpoint(profile.endpoint_ref) and (
        not profile.endpoint_allowlist.allow_private_endpoints
    ):
        diagnostics.append(
            _diagnostic(
                diagnostic_id=(
                    f"diagnostic.{profile.endpoint_profile_id}.private_endpoint"
                ),
                severity="error",
                code="ENDPOINT_PROFILE_PRIVATE_ENDPOINT_BLOCKED",
                message="Private endpoints require allow_private_endpoints=True.",
                object_path="endpoint_ref",
                metadata={
                    "allowlist_id": profile.endpoint_allowlist.allowlist_id,
                    "endpoint_ref": _redact_endpoint_ref(profile.endpoint_ref),
                },
            )
        )
    elif not _endpoint_allowed(profile):
        diagnostics.append(
            _diagnostic(
                diagnostic_id=(
                    f"diagnostic.{profile.endpoint_profile_id}.allowlist_match"
                ),
                severity="error",
                code="ENDPOINT_PROFILE_ENDPOINT_NOT_ALLOWED",
                message="Endpoint reference is not permitted by the allowlist.",
                object_path="endpoint_ref",
                metadata={
                    "allowlist_id": profile.endpoint_allowlist.allowlist_id,
                    "endpoint_ref": _redact_endpoint_ref(profile.endpoint_ref),
                },
            )
        )
    return diagnostics


def _endpoint_allowed(profile: BackendEndpointProfileIR) -> bool:
    allowlist = profile.endpoint_allowlist
    endpoint_ref = profile.endpoint_ref
    if allowlist is None or not endpoint_ref:
        return False
    if endpoint_ref in allowlist.allowed_endpoints:
        return True
    return any(
        _endpoint_host_matches(endpoint_ref, host)
        for host in allowlist.allowed_hosts
    )


def _endpoint_host_matches(endpoint_ref: str, allowed_host: str) -> bool:
    if endpoint_ref == allowed_host:
        return True
    return _endpoint_host(endpoint_ref) == allowed_host


def _endpoint_host(endpoint_ref: str | None) -> str:
    if endpoint_ref is None:
        return ""
    without_scheme = endpoint_ref.split("://", 1)[-1]
    return without_scheme.split("/", 1)[0].split(":", 1)[0]


def _is_private_endpoint(endpoint_ref: str | None) -> bool:
    host = _endpoint_host(endpoint_ref)
    return (
        host == "localhost"
        or any(host.startswith(prefix) for prefix in _PRIVATE_HOST_PREFIXES)
        or host.endswith(".local")
        or host.endswith(".internal")
    )


def _endpoint_profile_credential_diagnostics(
    profile: BackendEndpointProfileIR,
    *,
    credential_profile: CredentialProfileIR | None,
) -> list[DiagnosticsIR]:
    from cascaqit.readiness import validate_credential_profile

    diagnostics: list[DiagnosticsIR] = []
    if profile.execution_mode != "live_opt_in":
        return diagnostics
    if profile.credential_requirement is None:
        diagnostics.append(
            _diagnostic(
                diagnostic_id=(
                    f"diagnostic.{profile.endpoint_profile_id}."
                    "credential_requirement"
                ),
                severity="error",
                code="ENDPOINT_PROFILE_CREDENTIAL_REQUIREMENT_MISSING",
                message=(
                    "Live opt-in endpoint profiles require credential requirements."
                ),
                object_path="credential_requirement",
            )
        )
        return diagnostics
    if profile.credential_ref is None and credential_profile is None:
        diagnostics.append(
            _diagnostic(
                diagnostic_id=f"diagnostic.{profile.endpoint_profile_id}.credential",
                severity="error",
                code="ENDPOINT_PROFILE_CREDENTIAL_MISSING",
                message=(
                    "Live opt-in endpoint profiles require a credential reference "
                    "or credential profile."
                ),
                object_path="credential_ref",
            )
        )
        return diagnostics
    diagnostics.extend(
        validate_credential_profile(
            credential_profile,
            profile.credential_requirement,
        )
    )
    if profile.credential_ref is not None and credential_profile is not None:
        diagnostics.extend(
            _credential_ref_alignment_diagnostics(profile, credential_profile)
        )
    return diagnostics


def _credential_ref_alignment_diagnostics(
    profile: BackendEndpointProfileIR,
    credential_profile: CredentialProfileIR,
) -> list[DiagnosticsIR]:
    credential_ref = profile.credential_ref
    if credential_ref is None:
        return []
    if credential_ref.credential_ref_id == (
        credential_profile.credential_ref.credential_ref_id
    ):
        return []
    return [
        _diagnostic(
            diagnostic_id=f"diagnostic.{profile.endpoint_profile_id}.credential_ref",
            severity="error",
            code="ENDPOINT_PROFILE_CREDENTIAL_REF_MISMATCH",
            message="Endpoint credential_ref does not match credential profile.",
            object_path="credential_ref.credential_ref_id",
            metadata={
                "endpoint_credential_ref_id": credential_ref.credential_ref_id,
                "profile_credential_ref_id": (
                    credential_profile.credential_ref.credential_ref_id
                ),
            },
        )
    ]


def _diagnostic(
    *,
    diagnostic_id: str,
    severity: Literal["info", "warning", "error"],
    code: str,
    message: str,
    object_path: str | None = None,
    suggestion: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> DiagnosticsIR:
    return DiagnosticsIR(
        diagnostic_id=diagnostic_id,
        stage="validation",
        severity=severity,
        code=code,
        message=message,
        object_path=object_path,
        suggestion=suggestion,
        metadata={} if metadata is None else _redact_mapping(metadata),
    )


def _redact_endpoint_ref(endpoint_ref: str | None) -> str | None:
    if endpoint_ref is None:
        return None
    if _is_private_endpoint(endpoint_ref):
        return "<redacted>"
    return endpoint_ref
