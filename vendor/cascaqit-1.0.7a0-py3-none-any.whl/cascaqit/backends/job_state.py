"""Canonical public Job lifecycle vocabulary and transition rules."""

from __future__ import annotations

from typing import Final, Literal, cast

__all__ = [
    "ALLOWED_JOB_TRANSITIONS",
    "JOB_STATES",
    "TERMINAL_JOB_STATES",
    "JobState",
    "is_job_state",
    "is_terminal_job_state",
    "validate_job_state",
    "validate_job_transition",
]

JobState = Literal[
    "created",
    "queued",
    "running",
    "completed",
    "partially_completed",
    "failed",
    "cancelled",
    "expired",
]

JOB_STATES: Final[frozenset[str]] = frozenset(
    {
        "created",
        "queued",
        "running",
        "completed",
        "partially_completed",
        "failed",
        "cancelled",
        "expired",
    }
)
TERMINAL_JOB_STATES: Final[frozenset[JobState]] = frozenset(
    {
        "completed",
        "partially_completed",
        "failed",
        "cancelled",
        "expired",
    }
)

# ``None -> created`` is the append-only history edge that records identity
# creation before the observable Job lifecycle begins.
ALLOWED_JOB_TRANSITIONS: Final[frozenset[tuple[JobState | None, JobState]]] = (
    frozenset(
        {
            (None, "created"),
            ("created", "queued"),
            ("created", "cancelled"),
            ("queued", "running"),
            ("queued", "cancelled"),
            ("queued", "expired"),
            ("running", "completed"),
            ("running", "partially_completed"),
            ("running", "failed"),
            ("running", "cancelled"),
            ("running", "expired"),
        }
    )
)


def is_job_state(value: object) -> bool:
    """Return whether *value* belongs to the public Job vocabulary."""
    return isinstance(value, str) and value in JOB_STATES


def validate_job_state(value: object, *, field_name: str = "state") -> JobState:
    """Return a typed state or fail before an unknown state crosses an API."""
    if not is_job_state(value):
        raise ValueError(f"{field_name} is not a supported Job state: {value!r}.")
    return cast(JobState, value)


def is_terminal_job_state(value: object) -> bool:
    """Return whether *value* is one of the five terminal states."""
    return is_job_state(value) and value in TERMINAL_JOB_STATES


def validate_job_transition(
    from_state: JobState | None,
    to_state: JobState,
) -> None:
    """Reject lifecycle regressions, terminal continuation, and unknown states."""
    if from_state is not None:
        validate_job_state(from_state, field_name="from_state")
    validate_job_state(to_state, field_name="to_state")
    if (from_state, to_state) not in ALLOWED_JOB_TRANSITIONS:
        raise ValueError(
            f"unsupported Job transition: {from_state!r} -> {to_state!r}."
        )
