"""Typed contracts for durable local Job retry, recovery, and history."""

from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import PurePosixPath
from typing import Any, Literal

from cascaqit.backends.job_state import (
    JOB_STATES,
    JobState,
    validate_job_transition,
)
from cascaqit.exceptions import BackendExecutionError
from cascaqit.native_ir.base import IRMixin, canonicalize, stable_json
from cascaqit.native_ir.models import SCHEMA_VERSION
from cascaqit.readiness.audit import redact_audit_metadata

__all__ = [
    "JobAttemptIR",
    "JobAttemptOutcomeIR",
    "JobBusyError",
    "JobDefinitionIR",
    "JobErrorRefIR",
    "JobHistoryEntry",
    "JobHistoryPage",
    "JobHistoryQuery",
    "JobIdempotencyConflictError",
    "JobRecoveryError",
    "JobResultRefIR",
    "JobStoreError",
    "JobTransitionIR",
    "PersistedJobFailure",
    "RetryPolicy",
]

JobKind = Literal["single", "sweep"]
JobProgramKind = Literal["digital", "analog", "hybrid"]
JobAttemptOutcomeStatus = Literal[
    "completed",
    "retryable_failure",
    "non_retryable_failure",
    "interrupted",
]
JobResultKind = Literal["result", "sweep_result"]
RetryBackoffStrategy = Literal["none", "fixed", "exponential"]

_JOB_STATES = JOB_STATES
_PROGRAM_KINDS = {"digital", "analog", "hybrid"}
_JOB_KINDS = {"single", "sweep"}
_ATTEMPT_OUTCOMES = {
    "completed",
    "retryable_failure",
    "non_retryable_failure",
    "interrupted",
}


@dataclass(frozen=True)
class RetryPolicy(IRMixin):
    """Job-level typed retry policy; distinct from transport retry metadata."""

    max_attempts: int = 1
    timeout_seconds: float | None = None
    backoff_strategy: RetryBackoffStrategy = "none"
    backoff_seconds: float = 0.0
    max_backoff_seconds: float | None = None
    retryable_error_codes: tuple[str, ...] = ()
    non_retryable_error_codes: tuple[str, ...] = ()
    schema_version: str = SCHEMA_VERSION

    def __post_init__(self) -> None:
        if (
            not isinstance(self.max_attempts, int)
            or isinstance(self.max_attempts, bool)
            or self.max_attempts < 1
        ):
            raise ValueError("RetryPolicy.max_attempts must be >= 1.")
        _require_optional_positive_float(
            self.timeout_seconds,
            field_name="RetryPolicy.timeout_seconds",
        )
        if self.backoff_strategy not in {"none", "fixed", "exponential"}:
            raise ValueError("RetryPolicy.backoff_strategy is unsupported.")
        _require_non_negative_float(
            self.backoff_seconds,
            field_name="RetryPolicy.backoff_seconds",
        )
        _require_optional_non_negative_float(
            self.max_backoff_seconds,
            field_name="RetryPolicy.max_backoff_seconds",
        )
        if (
            self.max_backoff_seconds is not None
            and self.max_backoff_seconds < self.backoff_seconds
        ):
            raise ValueError(
                "RetryPolicy.max_backoff_seconds must be >= backoff_seconds."
            )
        retryable = _normalize_codes(
            self.retryable_error_codes,
            field_name="retryable_error_codes",
        )
        non_retryable = _normalize_codes(
            self.non_retryable_error_codes,
            field_name="non_retryable_error_codes",
        )
        overlap = set(retryable).intersection(non_retryable)
        if overlap:
            raise ValueError(
                "RetryPolicy error-code lists cannot overlap: "
                + ", ".join(sorted(overlap))
            )
        object.__setattr__(self, "retryable_error_codes", retryable)
        object.__setattr__(self, "non_retryable_error_codes", non_retryable)
        _require_identifier(self.schema_version, field_name="schema_version")

    def attempt_backoff_seconds(self, attempt_index: int) -> float:
        """Return deterministic delay before a one-based attempt."""
        if (
            not isinstance(attempt_index, int)
            or isinstance(attempt_index, bool)
            or attempt_index < 1
        ):
            raise ValueError("attempt_index must be >= 1.")
        if attempt_index == 1 or self.backoff_strategy == "none":
            return 0.0
        if self.backoff_strategy == "fixed":
            delay = self.backoff_seconds
        else:
            delay = self.backoff_seconds * (2 ** (attempt_index - 2))
        if self.max_backoff_seconds is not None:
            return min(delay, self.max_backoff_seconds)
        return delay

    def is_retryable_code(self, code: str) -> bool | None:
        """Return an explicit policy override, if configured."""
        if code in self.non_retryable_error_codes:
            return False
        if code in self.retryable_error_codes:
            return True
        return None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> RetryPolicy:
        return cls(
            max_attempts=data.get("max_attempts", 1),
            timeout_seconds=data.get("timeout_seconds"),
            backoff_strategy=data.get("backoff_strategy", "none"),
            backoff_seconds=data.get("backoff_seconds", 0.0),
            max_backoff_seconds=data.get("max_backoff_seconds"),
            retryable_error_codes=tuple(data.get("retryable_error_codes", ())),
            non_retryable_error_codes=tuple(data.get("non_retryable_error_codes", ())),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
        )

    @classmethod
    def from_json(cls, text: str) -> RetryPolicy:
        return cls.from_dict(_json_object(text, type_name=cls.__name__))


@dataclass(frozen=True)
class JobDefinitionIR(IRMixin):
    """Frozen executable input captured before a persistent Job is created."""

    job_id: str
    backend_id: str
    job_kind: JobKind
    program_kind: JobProgramKind
    program_payload_kind: str
    program_payload_json: str
    program_hash: str
    parameter_bind_json: str | None
    parameter_bind_hash: str | None
    execution_spec_json: str
    retry_policy: RetryPolicy
    idempotency_key: str
    idempotency_explicit: bool
    created_at: str
    scan_spec_json: str | None = None
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        for name, identifier_value in (
            ("job_id", self.job_id),
            ("backend_id", self.backend_id),
            ("program_payload_kind", self.program_payload_kind),
            ("idempotency_key", self.idempotency_key),
            ("schema_version", self.schema_version),
        ):
            _require_identifier(identifier_value, field_name=name)
        if self.job_kind not in _JOB_KINDS:
            raise ValueError("job_kind must be 'single' or 'sweep'.")
        if self.program_kind not in _PROGRAM_KINDS:
            raise ValueError("program_kind is unsupported.")
        _require_hash(self.program_hash, field_name="program_hash")
        program_payload = _require_canonical_object_json(
            self.program_payload_json,
            field_name="program_payload_json",
        )
        execution_spec = _require_canonical_object_json(
            self.execution_spec_json,
            field_name="execution_spec_json",
        )
        parameter_bind = _require_optional_canonical_object_json(
            self.parameter_bind_json,
            field_name="parameter_bind_json",
        )
        scan_spec = _require_optional_canonical_object_json(
            self.scan_spec_json,
            field_name="scan_spec_json",
        )
        for name, payload_value in (
            ("program_payload_json", program_payload),
            ("execution_spec_json", execution_spec),
            ("parameter_bind_json", parameter_bind),
            ("scan_spec_json", scan_spec),
        ):
            if payload_value is not None:
                _require_secret_free(payload_value, field_name=name)
        if (self.parameter_bind_json is None) != (self.parameter_bind_hash is None):
            raise ValueError(
                "parameter_bind_json and parameter_bind_hash must be present together."
            )
        if self.parameter_bind_hash is not None:
            _require_hash(
                self.parameter_bind_hash,
                field_name="parameter_bind_hash",
            )
        if self.job_kind == "sweep" and self.scan_spec_json is None:
            raise ValueError("sweep definitions require scan_spec_json.")
        if self.job_kind == "single" and self.scan_spec_json is not None:
            raise ValueError("single definitions cannot contain scan_spec_json.")
        if not isinstance(self.retry_policy, RetryPolicy):
            raise TypeError("retry_policy must be RetryPolicy.")
        if not isinstance(self.idempotency_explicit, bool):
            raise TypeError("idempotency_explicit must be bool.")
        _require_utc_timestamp(self.created_at, field_name="created_at")
        object.__setattr__(
            self,
            "metadata",
            canonicalize(redact_audit_metadata(self.metadata)),
        )

    @property
    def definition_hash(self) -> str:
        """Hash execution semantics without submission identity or audit time."""
        payload = {
            "backend_id": self.backend_id,
            "job_kind": self.job_kind,
            "program_kind": self.program_kind,
            "program_payload_kind": self.program_payload_kind,
            "program_payload_json": self.program_payload_json,
            "program_hash": self.program_hash,
            "parameter_bind_json": self.parameter_bind_json,
            "parameter_bind_hash": self.parameter_bind_hash,
            "execution_spec_json": self.execution_spec_json,
            "retry_policy": self.retry_policy,
            "scan_spec_json": self.scan_spec_json,
            "schema_version": self.schema_version,
        }
        return hashlib.sha256(stable_json(payload).encode("utf-8")).hexdigest()

    def program_payload(self) -> dict[str, Any]:
        return _json_object(self.program_payload_json, type_name="program_payload")

    def parameter_bind(self) -> dict[str, Any] | None:
        if self.parameter_bind_json is None:
            return None
        return _json_object(self.parameter_bind_json, type_name="parameter_bind")

    def execution_spec(self) -> dict[str, Any]:
        return _json_object(self.execution_spec_json, type_name="execution_spec")

    def scan_spec(self) -> dict[str, Any] | None:
        if self.scan_spec_json is None:
            return None
        return _json_object(self.scan_spec_json, type_name="scan_spec")

    @classmethod
    def create(
        cls,
        *,
        job_id: str,
        backend_id: str,
        job_kind: JobKind,
        program_kind: JobProgramKind,
        program_payload_kind: str,
        program_payload: dict[str, Any],
        program_hash: str,
        execution_spec: dict[str, Any],
        retry_policy: RetryPolicy,
        idempotency_key: str,
        idempotency_explicit: bool,
        created_at: str,
        parameter_bind: dict[str, Any] | None = None,
        parameter_bind_hash: str | None = None,
        scan_spec: dict[str, Any] | None = None,
        schema_version: str = SCHEMA_VERSION,
        metadata: dict[str, Any] | None = None,
    ) -> JobDefinitionIR:
        return cls(
            job_id=job_id,
            backend_id=backend_id,
            job_kind=job_kind,
            program_kind=program_kind,
            program_payload_kind=program_payload_kind,
            program_payload_json=stable_json(program_payload),
            program_hash=program_hash,
            parameter_bind_json=(
                None if parameter_bind is None else stable_json(parameter_bind)
            ),
            parameter_bind_hash=parameter_bind_hash,
            execution_spec_json=stable_json(execution_spec),
            retry_policy=retry_policy,
            idempotency_key=idempotency_key,
            idempotency_explicit=idempotency_explicit,
            created_at=created_at,
            scan_spec_json=None if scan_spec is None else stable_json(scan_spec),
            schema_version=schema_version,
            metadata={} if metadata is None else metadata,
        )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> JobDefinitionIR:
        return cls(
            job_id=str(data["job_id"]),
            backend_id=str(data["backend_id"]),
            job_kind=data["job_kind"],
            program_kind=data["program_kind"],
            program_payload_kind=str(data["program_payload_kind"]),
            program_payload_json=str(data["program_payload_json"]),
            program_hash=str(data["program_hash"]),
            parameter_bind_json=data.get("parameter_bind_json"),
            parameter_bind_hash=data.get("parameter_bind_hash"),
            execution_spec_json=str(data["execution_spec_json"]),
            retry_policy=RetryPolicy.from_dict(dict(data["retry_policy"])),
            idempotency_key=str(data["idempotency_key"]),
            idempotency_explicit=bool(data["idempotency_explicit"]),
            created_at=str(data["created_at"]),
            scan_spec_json=data.get("scan_spec_json"),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> JobDefinitionIR:
        return cls.from_dict(_json_object(text, type_name=cls.__name__))


@dataclass(frozen=True)
class JobAttemptIR(IRMixin):
    """Immutable start record for one claimed execution attempt."""

    job_id: str
    attempt_index: int
    claim_token_hash: str
    definition_hash: str
    program_hash: str
    parameter_bind_hash: str | None
    seed: int
    started_at: str
    schema_version: str = SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_identifier(self.job_id, field_name="job_id")
        _require_positive_int(self.attempt_index, field_name="attempt_index")
        for name, value in (
            ("claim_token_hash", self.claim_token_hash),
            ("definition_hash", self.definition_hash),
            ("program_hash", self.program_hash),
        ):
            _require_hash(value, field_name=name)
        if self.parameter_bind_hash is not None:
            _require_hash(self.parameter_bind_hash, field_name="parameter_bind_hash")
        if not isinstance(self.seed, int) or isinstance(self.seed, bool):
            raise TypeError("seed must be an integer.")
        _require_utc_timestamp(self.started_at, field_name="started_at")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> JobAttemptIR:
        return cls(
            job_id=str(data["job_id"]),
            attempt_index=data["attempt_index"],
            claim_token_hash=str(data["claim_token_hash"]),
            definition_hash=str(data["definition_hash"]),
            program_hash=str(data["program_hash"]),
            parameter_bind_hash=data.get("parameter_bind_hash"),
            seed=data["seed"],
            started_at=str(data["started_at"]),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
        )

    @classmethod
    def from_json(cls, text: str) -> JobAttemptIR:
        return cls.from_dict(_json_object(text, type_name=cls.__name__))


@dataclass(frozen=True)
class JobAttemptOutcomeIR(IRMixin):
    """Immutable terminal outcome appended after an attempt start record."""

    job_id: str
    attempt_index: int
    status: JobAttemptOutcomeStatus
    finished_at: str
    result_ref_id: str | None = None
    error_ref_id: str | None = None
    schema_version: str = SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_identifier(self.job_id, field_name="job_id")
        _require_positive_int(self.attempt_index, field_name="attempt_index")
        if self.status not in _ATTEMPT_OUTCOMES:
            raise ValueError("attempt outcome status is unsupported.")
        _require_utc_timestamp(self.finished_at, field_name="finished_at")
        if self.status == "completed":
            if self.result_ref_id is None:
                raise ValueError("completed outcome requires result_ref_id.")
            if self.error_ref_id is not None:
                raise ValueError("completed outcome cannot contain error_ref_id.")
        else:
            if self.error_ref_id is None:
                raise ValueError("failed/interrupted outcome requires error_ref_id.")
            if self.result_ref_id is not None:
                raise ValueError(
                    "failed/interrupted outcome cannot contain result_ref_id."
                )
        if self.result_ref_id is not None:
            _require_identifier(self.result_ref_id, field_name="result_ref_id")
        if self.error_ref_id is not None:
            _require_identifier(self.error_ref_id, field_name="error_ref_id")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> JobAttemptOutcomeIR:
        return cls(
            job_id=str(data["job_id"]),
            attempt_index=data["attempt_index"],
            status=data["status"],
            finished_at=str(data["finished_at"]),
            result_ref_id=data.get("result_ref_id"),
            error_ref_id=data.get("error_ref_id"),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
        )

    @classmethod
    def from_json(cls, text: str) -> JobAttemptOutcomeIR:
        return cls.from_dict(_json_object(text, type_name=cls.__name__))


@dataclass(frozen=True)
class JobTransitionIR(IRMixin):
    """Append-only lifecycle edge with a per-Job monotonic sequence."""

    job_id: str
    sequence: int
    from_state: JobState | None
    to_state: JobState
    event_time: str
    definition_hash: str
    reason: str
    attempt_index: int | None = None
    error_ref_id: str | None = None
    schema_version: str = SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_identifier(self.job_id, field_name="job_id")
        _require_positive_int(self.sequence, field_name="sequence")
        validate_job_transition(self.from_state, self.to_state)
        if self.from_state is None and self.sequence != 1:
            raise ValueError("initial transition must use sequence=1.")
        attempt_states = {
            "running",
            "completed",
            "partially_completed",
            "failed",
        }
        if self.to_state in attempt_states and self.attempt_index is None:
            raise ValueError(f"transition to {self.to_state!r} requires attempt_index.")
        if self.attempt_index is not None:
            _require_positive_int(self.attempt_index, field_name="attempt_index")
        _require_utc_timestamp(self.event_time, field_name="event_time")
        _require_hash(self.definition_hash, field_name="definition_hash")
        _require_identifier(self.reason, field_name="reason")
        if self.error_ref_id is not None:
            _require_identifier(self.error_ref_id, field_name="error_ref_id")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> JobTransitionIR:
        return cls(
            job_id=str(data["job_id"]),
            sequence=data["sequence"],
            from_state=data.get("from_state"),
            to_state=data["to_state"],
            event_time=str(data["event_time"]),
            definition_hash=str(data["definition_hash"]),
            reason=str(data["reason"]),
            attempt_index=data.get("attempt_index"),
            error_ref_id=data.get("error_ref_id"),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
        )

    @classmethod
    def from_json(cls, text: str) -> JobTransitionIR:
        return cls.from_dict(_json_object(text, type_name=cls.__name__))


@dataclass(frozen=True)
class JobResultRefIR(IRMixin):
    """Checksum-verified reference to a typed Result sidecar."""

    ref_id: str
    job_id: str
    attempt_index: int
    result_kind: JobResultKind
    result_id: str
    result_hash: str
    artifact_path: str
    checksum: str
    size_bytes: int
    content_type: str
    created_at: str
    schema_version: str = SCHEMA_VERSION

    def __post_init__(self) -> None:
        for name, value in (
            ("ref_id", self.ref_id),
            ("job_id", self.job_id),
            ("result_id", self.result_id),
            ("content_type", self.content_type),
        ):
            _require_identifier(value, field_name=name)
        _require_positive_int(self.attempt_index, field_name="attempt_index")
        if self.result_kind not in {"result", "sweep_result"}:
            raise ValueError("result_kind is unsupported.")
        _require_hash(self.result_hash, field_name="result_hash")
        _require_safe_artifact_path(self.artifact_path)
        _require_hash(self.checksum, field_name="checksum")
        if (
            not isinstance(self.size_bytes, int)
            or isinstance(self.size_bytes, bool)
            or self.size_bytes < 0
        ):
            raise ValueError("size_bytes must be a non-negative integer.")
        _require_utc_timestamp(self.created_at, field_name="created_at")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> JobResultRefIR:
        return cls(
            ref_id=str(data["ref_id"]),
            job_id=str(data["job_id"]),
            attempt_index=data["attempt_index"],
            result_kind=data["result_kind"],
            result_id=str(data["result_id"]),
            result_hash=str(data["result_hash"]),
            artifact_path=str(data["artifact_path"]),
            checksum=str(data["checksum"]),
            size_bytes=data["size_bytes"],
            content_type=str(data["content_type"]),
            created_at=str(data["created_at"]),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
        )

    @classmethod
    def from_json(cls, text: str) -> JobResultRefIR:
        return cls.from_dict(_json_object(text, type_name=cls.__name__))


@dataclass(frozen=True)
class JobErrorRefIR(IRMixin):
    """Safe, bounded error evidence that can be reconstructed after restart."""

    error_ref_id: str
    job_id: str
    attempt_index: int
    category: str
    code: str
    message: str
    retryable: bool
    exception_type: str
    created_at: str
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        for name, value in (
            ("error_ref_id", self.error_ref_id),
            ("job_id", self.job_id),
            ("category", self.category),
            ("code", self.code),
            ("exception_type", self.exception_type),
        ):
            _require_identifier(value, field_name=name)
        _require_positive_int(self.attempt_index, field_name="attempt_index")
        if not isinstance(self.message, str) or not self.message:
            raise ValueError("message must be a non-empty string.")
        if len(self.message) > 2048:
            raise ValueError("message cannot exceed 2048 characters.")
        if not isinstance(self.retryable, bool):
            raise TypeError("retryable must be bool.")
        _require_utc_timestamp(self.created_at, field_name="created_at")
        object.__setattr__(
            self,
            "metadata",
            canonicalize(redact_audit_metadata(self.metadata)),
        )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> JobErrorRefIR:
        return cls(
            error_ref_id=str(data["error_ref_id"]),
            job_id=str(data["job_id"]),
            attempt_index=data["attempt_index"],
            category=str(data["category"]),
            code=str(data["code"]),
            message=str(data["message"]),
            retryable=data["retryable"],
            exception_type=str(data["exception_type"]),
            created_at=str(data["created_at"]),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> JobErrorRefIR:
        return cls.from_dict(_json_object(text, type_name=cls.__name__))


@dataclass(frozen=True)
class JobHistoryQuery(IRMixin):
    """Validated filters used to build stable SQLite history queries."""

    limit: int = 20
    cursor: str | None = None
    statuses: tuple[JobState, ...] = ()
    program_kinds: tuple[JobProgramKind, ...] = ()
    job_kinds: tuple[JobKind, ...] = ()
    created_after: str | None = None
    created_before: str | None = None
    schema_version: str = SCHEMA_VERSION

    def __post_init__(self) -> None:
        if (
            not isinstance(self.limit, int)
            or isinstance(self.limit, bool)
            or not 1 <= self.limit <= 200
        ):
            raise ValueError("history limit must be between 1 and 200.")
        if self.cursor is not None:
            _require_identifier(self.cursor, field_name="cursor")
        statuses = _normalize_literal_tuple(
            self.statuses,
            allowed=_JOB_STATES,
            field_name="statuses",
        )
        program_kinds = _normalize_literal_tuple(
            self.program_kinds,
            allowed=_PROGRAM_KINDS,
            field_name="program_kinds",
        )
        job_kinds = _normalize_literal_tuple(
            self.job_kinds,
            allowed=_JOB_KINDS,
            field_name="job_kinds",
        )
        object.__setattr__(self, "statuses", statuses)
        object.__setattr__(self, "program_kinds", program_kinds)
        object.__setattr__(self, "job_kinds", job_kinds)
        after = _optional_utc_datetime(
            self.created_after,
            field_name="created_after",
        )
        before = _optional_utc_datetime(
            self.created_before,
            field_name="created_before",
        )
        if after is not None and before is not None and after > before:
            raise ValueError("created_after cannot be later than created_before.")

    @property
    def filter_hash(self) -> str:
        """Hash only filters, allowing page size to change between requests."""
        payload = {
            "statuses": self.statuses,
            "program_kinds": self.program_kinds,
            "job_kinds": self.job_kinds,
            "created_after": self.created_after,
            "created_before": self.created_before,
            "schema_version": self.schema_version,
        }
        return hashlib.sha256(stable_json(payload).encode("utf-8")).hexdigest()

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> JobHistoryQuery:
        return cls(
            limit=data.get("limit", 20),
            cursor=data.get("cursor"),
            statuses=tuple(data.get("statuses", ())),
            program_kinds=tuple(data.get("program_kinds", ())),
            job_kinds=tuple(data.get("job_kinds", ())),
            created_after=data.get("created_after"),
            created_before=data.get("created_before"),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
        )

    @classmethod
    def from_json(cls, text: str) -> JobHistoryQuery:
        return cls.from_dict(_json_object(text, type_name=cls.__name__))


@dataclass(frozen=True)
class JobHistoryEntry(IRMixin):
    """Summary-first history row that never embeds a Result body."""

    job_id: str
    backend_id: str
    job_kind: JobKind
    program_kind: JobProgramKind
    program_hash: str
    definition_hash: str
    status: JobState
    attempt_count: int
    total_items: int | None
    completed_items: int | None
    failed_items: int | None
    created_at: str
    updated_at: str
    result_ref: JobResultRefIR | None
    error_ref: JobErrorRefIR | None
    schema_version: str = SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_identifier(self.job_id, field_name="job_id")
        _require_identifier(self.backend_id, field_name="backend_id")
        if self.job_kind not in _JOB_KINDS:
            raise ValueError("job_kind is unsupported.")
        if self.program_kind not in _PROGRAM_KINDS:
            raise ValueError("program_kind is unsupported.")
        _require_hash(self.program_hash, field_name="program_hash")
        _require_hash(self.definition_hash, field_name="definition_hash")
        if self.status not in _JOB_STATES:
            raise ValueError("history status is unsupported.")
        _require_non_negative_int(self.attempt_count, field_name="attempt_count")
        created = _require_utc_timestamp(self.created_at, field_name="created_at")
        updated = _require_utc_timestamp(self.updated_at, field_name="updated_at")
        if updated < created:
            raise ValueError("updated_at cannot be earlier than created_at.")
        if self.job_kind == "single":
            if any(
                item is not None
                for item in (self.total_items, self.completed_items, self.failed_items)
            ):
                raise ValueError("single Job history cannot contain item counts.")
        else:
            if any(
                item is None
                for item in (self.total_items, self.completed_items, self.failed_items)
            ):
                raise ValueError("sweep history requires all item counts.")
            total = _non_optional(self.total_items)
            completed = _non_optional(self.completed_items)
            failed = _non_optional(self.failed_items)
            for name, value in (
                ("total_items", total),
                ("completed_items", completed),
                ("failed_items", failed),
            ):
                _require_non_negative_int(value, field_name=name)
            if completed + failed > total:
                raise ValueError(
                    "completed and failed items cannot exceed total_items."
                )
        if (
            self.status in {"completed", "partially_completed"}
            and self.result_ref is None
        ):
            raise ValueError(f"{self.status} history requires result_ref.")
        if self.status == "failed" and self.error_ref is None:
            raise ValueError("failed history requires error_ref.")
        if self.result_ref is not None and self.result_ref.job_id != self.job_id:
            raise ValueError("result_ref job_id must match history job_id.")
        if self.error_ref is not None and self.error_ref.job_id != self.job_id:
            raise ValueError("error_ref job_id must match history job_id.")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> JobHistoryEntry:
        result_ref = data.get("result_ref")
        error_ref = data.get("error_ref")
        return cls(
            job_id=str(data["job_id"]),
            backend_id=str(data["backend_id"]),
            job_kind=data["job_kind"],
            program_kind=data["program_kind"],
            program_hash=str(data["program_hash"]),
            definition_hash=str(data["definition_hash"]),
            status=data["status"],
            attempt_count=data["attempt_count"],
            total_items=data.get("total_items"),
            completed_items=data.get("completed_items"),
            failed_items=data.get("failed_items"),
            created_at=str(data["created_at"]),
            updated_at=str(data["updated_at"]),
            result_ref=(
                None
                if result_ref is None
                else JobResultRefIR.from_dict(dict(result_ref))
            ),
            error_ref=(
                None if error_ref is None else JobErrorRefIR.from_dict(dict(error_ref))
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
        )

    @classmethod
    def from_json(cls, text: str) -> JobHistoryEntry:
        return cls.from_dict(_json_object(text, type_name=cls.__name__))


@dataclass(frozen=True)
class JobHistoryPage(IRMixin):
    """Immutable page bound to one store and one filter hash."""

    entries: tuple[JobHistoryEntry, ...]
    limit: int
    next_cursor: str | None
    store_id: str
    filter_hash: str
    schema_version: str = SCHEMA_VERSION

    def __post_init__(self) -> None:
        if not isinstance(self.entries, (tuple, list)) or any(
            not isinstance(item, JobHistoryEntry) for item in self.entries
        ):
            raise TypeError("entries must contain JobHistoryEntry values.")
        entries = tuple(self.entries)
        if (
            not isinstance(self.limit, int)
            or isinstance(self.limit, bool)
            or not 1 <= self.limit <= 200
        ):
            raise ValueError("history page limit must be between 1 and 200.")
        if len(entries) > self.limit:
            raise ValueError("history page cannot contain more entries than limit.")
        if self.next_cursor is not None:
            _require_identifier(self.next_cursor, field_name="next_cursor")
        _require_identifier(self.store_id, field_name="store_id")
        _require_hash(self.filter_hash, field_name="filter_hash")
        object.__setattr__(self, "entries", entries)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> JobHistoryPage:
        return cls(
            entries=tuple(
                JobHistoryEntry.from_dict(dict(item))
                for item in data.get("entries", ())
            ),
            limit=data["limit"],
            next_cursor=data.get("next_cursor"),
            store_id=str(data["store_id"]),
            filter_hash=str(data["filter_hash"]),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
        )

    @classmethod
    def from_json(cls, text: str) -> JobHistoryPage:
        return cls.from_dict(_json_object(text, type_name=cls.__name__))


class JobStoreError(BackendExecutionError):
    """Persistent local Job store failure."""

    default_code = "JOB_STORE_ERROR"


class JobRecoveryError(JobStoreError):
    """Stored Job cannot be safely reconstructed or resumed."""

    default_code = "JOB_RECOVERY_ERROR"


class JobIdempotencyConflictError(JobStoreError):
    """An idempotency key was reused with a different definition."""

    def __init__(
        self,
        *,
        job_id: str,
        expected_definition_hash: str,
        actual_definition_hash: str,
    ) -> None:
        _require_hash(
            expected_definition_hash,
            field_name="expected_definition_hash",
        )
        _require_hash(
            actual_definition_hash,
            field_name="actual_definition_hash",
        )
        super().__init__(
            "Idempotency key already belongs to a different Job definition.",
            code="JOB_IDEMPOTENCY_CONFLICT",
            object_path="backend.run.idempotency_key",
            metadata={"job_id": job_id},
            source_hashes={
                "expected_definition_hash": expected_definition_hash,
                "actual_definition_hash": actual_definition_hash,
            },
        )


class JobBusyError(JobStoreError):
    """Another live claimant currently owns Job execution."""

    def __init__(self, *, job_id: str) -> None:
        super().__init__(
            "Persistent Job is currently owned by another active claimant.",
            code="JOB_ACTIVE_CLAIM",
            object_path="job.state",
            retryable=True,
            metadata={"job_id": job_id},
        )


class PersistedJobFailure(JobRecoveryError):
    """Reconstructed terminal failure from a durable error reference."""

    def __init__(self, *, error_ref: JobErrorRefIR) -> None:
        if not isinstance(error_ref, JobErrorRefIR):
            raise TypeError("error_ref must be JobErrorRefIR.")
        super().__init__(
            error_ref.message,
            code=error_ref.code,
            retryable=error_ref.retryable,
            metadata={
                "error_ref_id": error_ref.error_ref_id,
                "job_id": error_ref.job_id,
                "attempt_index": error_ref.attempt_index,
                "persisted_exception_type": error_ref.exception_type,
                **error_ref.metadata,
            },
        )
        self.error_ref = error_ref


def _require_identifier(value: object, *, field_name: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field_name} must be a non-empty string.")


def _require_hash(value: object, *, field_name: str) -> None:
    if (
        not isinstance(value, str)
        or len(value) != 64
        or any(char not in "0123456789abcdef" for char in value)
    ):
        raise ValueError(f"{field_name} must be a lowercase SHA-256 hex digest.")


def _require_positive_int(value: object, *, field_name: str) -> None:
    if not isinstance(value, int) or isinstance(value, bool) or value < 1:
        raise ValueError(f"{field_name} must be a positive integer.")


def _require_non_negative_int(value: object, *, field_name: str) -> None:
    if not isinstance(value, int) or isinstance(value, bool) or value < 0:
        raise ValueError(f"{field_name} must be a non-negative integer.")


def _require_non_negative_float(value: object, *, field_name: str) -> None:
    if (
        not isinstance(value, (int, float))
        or isinstance(value, bool)
        or not math.isfinite(float(value))
        or float(value) < 0.0
    ):
        raise ValueError(f"{field_name} must be finite and non-negative.")


def _require_optional_non_negative_float(
    value: object,
    *,
    field_name: str,
) -> None:
    if value is not None:
        _require_non_negative_float(value, field_name=field_name)


def _require_optional_positive_float(value: object, *, field_name: str) -> None:
    if value is None:
        return
    if (
        not isinstance(value, (int, float))
        or isinstance(value, bool)
        or not math.isfinite(float(value))
        or float(value) <= 0.0
    ):
        raise ValueError(f"{field_name} must be finite and positive or None.")


def _normalize_codes(values: object, *, field_name: str) -> tuple[str, ...]:
    if not isinstance(values, (tuple, list)):
        raise TypeError(f"{field_name} must be a tuple or list of strings.")
    normalized: list[str] = []
    for value in values:
        _require_identifier(value, field_name=field_name)
        normalized.append(value)
    if len(set(normalized)) != len(normalized):
        raise ValueError(f"{field_name} cannot contain duplicates.")
    return tuple(sorted(normalized))


def _normalize_literal_tuple(
    values: object,
    *,
    allowed: set[str] | frozenset[str],
    field_name: str,
) -> tuple[Any, ...]:
    if not isinstance(values, (tuple, list)):
        raise TypeError(f"{field_name} must be a tuple or list.")
    normalized = tuple(str(value) for value in values)
    if any(value not in allowed for value in normalized):
        raise ValueError(f"{field_name} contains an unsupported value.")
    if len(set(normalized)) != len(normalized):
        raise ValueError(f"{field_name} cannot contain duplicates.")
    return tuple(sorted(normalized))


def _json_object(text: str, *, type_name: str) -> dict[str, Any]:
    try:
        data = json.loads(text)
    except (TypeError, json.JSONDecodeError) as exc:
        raise ValueError(f"{type_name} must contain valid JSON.") from exc
    if not isinstance(data, dict):
        raise TypeError(f"{type_name} JSON must contain an object.")
    return data


def _require_canonical_object_json(
    text: object,
    *,
    field_name: str,
) -> dict[str, Any]:
    if not isinstance(text, str):
        raise TypeError(f"{field_name} must be a canonical JSON string.")
    data = _json_object(text, type_name=field_name)
    if stable_json(data) != text:
        raise ValueError(f"{field_name} must use canonical JSON.")
    return data


def _require_optional_canonical_object_json(
    text: object,
    *,
    field_name: str,
) -> dict[str, Any] | None:
    if text is not None:
        return _require_canonical_object_json(text, field_name=field_name)
    return None


def _require_secret_free(value: dict[str, Any], *, field_name: str) -> None:
    # Persisted execution input must remain byte-for-byte reconstructable. Reject
    # secret-like keys instead of redacting them into a different definition.
    if stable_json(redact_audit_metadata(value)) != stable_json(value):
        raise ValueError(f"{field_name} cannot contain secret-like fields.")


def _require_utc_timestamp(value: object, *, field_name: str) -> datetime:
    if not isinstance(value, str) or not value:
        raise ValueError(f"{field_name} must be an ISO-8601 UTC timestamp.")
    normalized = value[:-1] + "+00:00" if value.endswith("Z") else value
    try:
        parsed = datetime.fromisoformat(normalized)
    except ValueError as exc:
        raise ValueError(f"{field_name} must be an ISO-8601 UTC timestamp.") from exc
    if parsed.tzinfo is None or parsed.utcoffset() != timezone.utc.utcoffset(parsed):
        raise ValueError(f"{field_name} must include a UTC timezone.")
    return parsed


def _optional_utc_datetime(
    value: object,
    *,
    field_name: str,
) -> datetime | None:
    if value is None:
        return None
    return _require_utc_timestamp(value, field_name=field_name)


def _require_safe_artifact_path(value: object) -> None:
    if not isinstance(value, str) or not value or "\\" in value:
        raise ValueError("artifact_path must be a safe relative POSIX path.")
    path = PurePosixPath(value)
    if path.is_absolute() or ".." in path.parts or "." in path.parts:
        raise ValueError("artifact_path must stay within the artifact root.")
    if not path.parts or path.parts[0] != "results":
        raise ValueError("artifact_path must be under the results directory.")


def _non_optional(value: int | None) -> int:
    assert value is not None
    return value
