"""Offline backend transport policy and retry helpers."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Callable, Generic, Literal, TypeVar, cast

from cascaqit.backends.config import BackendErrorCategory
from cascaqit.exceptions import BackendExecutionError
from cascaqit.native_ir.base import IRMixin
from cascaqit.native_ir.models import SCHEMA_VERSION

__all__ = [
    "BackoffStrategy",
    "BackendTransportAttemptIR",
    "BackendTransportOperationFailed",
    "BackendTransportPolicyIR",
    "BackendTransportRetryExhausted",
    "BackendTransportResult",
    "classify_retryable_exception",
    "run_transport_operation",
]

BackoffStrategy = Literal["none", "fixed", "exponential"]
_T = TypeVar("_T")


@dataclass(frozen=True)
class BackendTransportPolicyIR(IRMixin):
    """Backend transport timeout, retry, and idempotency policy."""

    max_attempts: int = 1
    timeout_seconds: float | None = None
    backoff_strategy: BackoffStrategy = "none"
    backoff_seconds: float = 0.0
    max_backoff_seconds: float | None = None
    retryable_error_codes: tuple[str, ...] = ()
    non_retryable_error_codes: tuple[str, ...] = ()
    idempotency_scope: str = "execution_package"
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Validate retry and timeout limits."""
        if self.max_attempts < 1:
            raise ValueError("BackendTransportPolicyIR.max_attempts must be >= 1.")
        if self.timeout_seconds is not None and self.timeout_seconds <= 0:
            raise ValueError(
                "BackendTransportPolicyIR.timeout_seconds must be positive."
            )
        if self.backoff_seconds < 0:
            raise ValueError(
                "BackendTransportPolicyIR.backoff_seconds cannot be negative."
            )
        if (
            self.max_backoff_seconds is not None
            and self.max_backoff_seconds < self.backoff_seconds
        ):
            raise ValueError(
                "BackendTransportPolicyIR.max_backoff_seconds must be >= "
                "backoff_seconds."
            )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> BackendTransportPolicyIR:
        """Build a transport policy from a JSON-compatible dictionary."""
        timeout = data.get("timeout_seconds")
        max_backoff = data.get("max_backoff_seconds")
        return cls(
            max_attempts=int(data.get("max_attempts", 1)),
            timeout_seconds=None if timeout is None else float(timeout),
            backoff_strategy=data.get("backoff_strategy", "none"),
            backoff_seconds=float(data.get("backoff_seconds", 0.0)),
            max_backoff_seconds=None
            if max_backoff is None
            else float(max_backoff),
            retryable_error_codes=tuple(
                str(code) for code in data.get("retryable_error_codes", ())
            ),
            non_retryable_error_codes=tuple(
                str(code)
                for code in data.get("non_retryable_error_codes", ())
            ),
            idempotency_scope=str(
                data.get("idempotency_scope", "execution_package")
            ),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, text: str) -> BackendTransportPolicyIR:
        """Build a transport policy from JSON text."""
        data = json.loads(text)
        if not isinstance(data, dict):
            raise TypeError("BackendTransportPolicyIR JSON must contain an object.")
        return cls.from_dict(data)

    @classmethod
    def from_backend_config(
        cls,
        retry_policy: dict[str, Any],
        *,
        timeout_seconds: float | None,
    ) -> BackendTransportPolicyIR:
        """Build a policy from BackendConfigIR fields."""
        return cls.from_dict(
            {
                **retry_policy,
                "timeout_seconds": retry_policy.get(
                    "timeout_seconds",
                    timeout_seconds,
                ),
            }
        )

    def attempt_backoff_seconds(self, attempt_index: int) -> float:
        """Return deterministic backoff delay metadata for an attempt."""
        if attempt_index <= 1 or self.backoff_strategy == "none":
            return 0.0
        if self.backoff_strategy == "fixed":
            delay = self.backoff_seconds
        elif self.backoff_strategy == "exponential":
            delay = self.backoff_seconds * (2 ** (attempt_index - 2))
        else:
            raise ValueError(
                f"Unsupported backoff_strategy: {self.backoff_strategy}"
            )
        if self.max_backoff_seconds is not None:
            return min(delay, self.max_backoff_seconds)
        return delay

    def is_retryable_code(self, code: str) -> bool | None:
        """Classify a code using explicit policy lists when present."""
        if code in self.non_retryable_error_codes:
            return False
        if code in self.retryable_error_codes:
            return True
        return None


@dataclass(frozen=True)
class BackendTransportAttemptIR(IRMixin):
    """Metadata for one backend transport attempt."""

    attempt_index: int
    idempotency_key: str
    timeout_seconds: float | None
    backoff_seconds: float
    status: Literal["success", "retryable_failure", "non_retryable_failure"]
    category: BackendErrorCategory | None = None
    code: str | None = None
    message: str | None = None
    retryable: bool | None = None
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> BackendTransportAttemptIR:
        """Build attempt metadata from a JSON-compatible dictionary."""
        timeout = data.get("timeout_seconds")
        return cls(
            attempt_index=int(data["attempt_index"]),
            idempotency_key=str(data["idempotency_key"]),
            timeout_seconds=None if timeout is None else float(timeout),
            backoff_seconds=float(data["backoff_seconds"]),
            status=data["status"],
            category=data.get("category"),
            code=data.get("code"),
            message=data.get("message"),
            retryable=data.get("retryable"),
            schema_version=str(data.get("schema_version", SCHEMA_VERSION)),
            metadata=dict(data.get("metadata", {})),
        )


@dataclass(frozen=True)
class BackendTransportResult(Generic[_T]):
    """Result of a retry-controlled transport operation."""

    value: _T
    attempts: tuple[BackendTransportAttemptIR, ...]


class BackendTransportRetryExhausted(BackendExecutionError):
    """Raised when a retryable transport operation exhausts its policy."""

    def __init__(
        self,
        message: str,
        *,
        attempts: tuple[BackendTransportAttemptIR, ...],
        last_exception: Exception,
    ) -> None:
        super().__init__(
            message,
            code="BACKEND_TRANSPORT_RETRY_EXHAUSTED",
            retryable=True,
            metadata={"attempt_count": len(attempts)},
            cause=last_exception,
        )
        self.attempts = attempts
        self.last_exception = last_exception


class BackendTransportOperationFailed(BackendExecutionError):
    """Raised when a transport operation fails without another retry."""

    def __init__(
        self,
        message: str,
        *,
        attempts: tuple[BackendTransportAttemptIR, ...],
        last_exception: Exception,
    ) -> None:
        super().__init__(
            message,
            code="BACKEND_TRANSPORT_OPERATION_FAILED",
            retryable=False,
            metadata={"attempt_count": len(attempts)},
            cause=last_exception,
        )
        self.attempts = attempts
        self.last_exception = last_exception


def run_transport_operation(
    operation: Callable[[], _T],
    *,
    policy: BackendTransportPolicyIR,
    idempotency_key: str,
    classify: Callable[[Exception], tuple[str, str, bool]],
) -> BackendTransportResult[_T]:
    """Run an offline operation with deterministic retry metadata."""
    attempts: list[BackendTransportAttemptIR] = []
    last_exception: Exception | None = None
    for attempt_index in range(1, policy.max_attempts + 1):
        backoff_seconds = policy.attempt_backoff_seconds(attempt_index)
        try:
            value = operation()
        except Exception as exc:
            category, code, retryable = classify(exc)
            explicit_retryable = policy.is_retryable_code(code)
            if explicit_retryable is not None:
                retryable = explicit_retryable
            can_retry = retryable and attempt_index < policy.max_attempts
            attempts.append(
                BackendTransportAttemptIR(
                    attempt_index=attempt_index,
                    idempotency_key=idempotency_key,
                    timeout_seconds=policy.timeout_seconds,
                    backoff_seconds=backoff_seconds,
                    status=(
                        "retryable_failure"
                        if can_retry
                        else "non_retryable_failure"
                    ),
                    category=cast(BackendErrorCategory, category),
                    code=code,
                    message=str(exc) or code,
                    retryable=retryable,
                    metadata={
                        "exception_type": type(exc).__name__,
                        "will_retry": can_retry,
                    },
                )
            )
            last_exception = exc
            if can_retry:
                continue
            if retryable:
                raise BackendTransportRetryExhausted(
                    "Backend transport retry attempts exhausted.",
                    attempts=tuple(attempts),
                    last_exception=exc,
                ) from exc
            raise BackendTransportOperationFailed(
                "Backend transport operation failed.",
                attempts=tuple(attempts),
                last_exception=exc,
            ) from exc
        attempts.append(
            BackendTransportAttemptIR(
                attempt_index=attempt_index,
                idempotency_key=idempotency_key,
                timeout_seconds=policy.timeout_seconds,
                backoff_seconds=backoff_seconds,
                status="success",
                metadata={"will_retry": False},
            )
        )
        return BackendTransportResult(value=value, attempts=tuple(attempts))
    if last_exception is None:
        raise RuntimeError("Transport retry loop ended without a result.")
    raise BackendTransportRetryExhausted(
        "Backend transport retry attempts exhausted.",
        attempts=tuple(attempts),
        last_exception=last_exception,
    )


def classify_retryable_exception(exc: Exception) -> tuple[str, str, bool]:
    """Classify generic offline transport exceptions."""
    raw_error = getattr(exc, "raw_error", None)
    code = ""
    retryable = True
    if isinstance(raw_error, dict):
        code = str(
            raw_error.get("code")
            or raw_error.get("vendor_code")
            or raw_error.get("cloud_code")
            or ""
        )
        if "retryable" in raw_error:
            retryable = bool(raw_error["retryable"])
    if not code:
        code = type(exc).__name__.upper()
    return "transport", code, retryable
