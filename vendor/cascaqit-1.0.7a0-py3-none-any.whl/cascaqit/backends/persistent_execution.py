"""Persistent single-Job controller shared by local program kinds."""

from __future__ import annotations

import hashlib
import os
import secrets
import time
from collections.abc import Callable
from datetime import datetime, timezone
from typing import NoReturn

from cascaqit.backends.execution import (
    ExecutionJobProtocol,
    LocalExecutionJobStatusIR,
)
from cascaqit.backends.job_history import (
    JobAttemptIR,
    JobAttemptOutcomeIR,
    JobDefinitionIR,
    JobErrorRefIR,
    PersistedJobFailure,
)
from cascaqit.backends.job_store import SQLiteJobStore
from cascaqit.exceptions import CASCAQitError, CASCAQitRuntimeError
from cascaqit.results import ResultIR

__all__ = ["PersistentLocalExecutionJob"]


class PersistentLocalExecutionJob:
    """Lazy local Job whose lifecycle evidence is committed to SQLite."""

    def __init__(
        self,
        *,
        store: SQLiteJobStore,
        definition: JobDefinitionIR,
        runner_factory: Callable[[], ExecutionJobProtocol],
        clock: Callable[[], str] | None = None,
        sleeper: Callable[[float], None] | None = None,
        lease_seconds: float = 300.0,
    ) -> None:
        self.store = store
        self.definition = definition
        self.job_id = definition.job_id
        self.backend_id = definition.backend_id
        self.program_kind = definition.program_kind
        self.program_hash = definition.program_hash
        self._runner_factory = runner_factory
        self._clock: Callable[[], str]
        if clock is None:
            self._clock = lambda: _not_before(_utc_now(), definition.created_at)
        else:
            self._clock = clock
        self._sleeper = time.sleep if sleeper is None else sleeper
        self._lease_seconds = lease_seconds
        self._owner_id = f"process-{os.getpid()}-{secrets.token_hex(8)}"

    def status(self) -> LocalExecutionJobStatusIR:
        state = self.store.load_state(self.job_id)
        return LocalExecutionJobStatusIR(
            job_id=self.job_id,
            state=state.status,
            backend_id=self.backend_id,
            program_kind=self.program_kind,
            program_hash=self.program_hash,
            execution_count=state.attempt_count,
            message={
                "created": "Persistent local Job was created.",
                "queued": "Persistent local Job is ready.",
                "running": "Persistent local Job has an active attempt.",
                "completed": "Persistent local Job completed.",
                "partially_completed": (
                    "Persistent local Job completed with partial results."
                ),
                "failed": "Persistent local Job failed.",
                "cancelled": "Persistent local Job was cancelled.",
                "expired": "Persistent local Job expired.",
            }.get(state.status, f"Persistent local Job is {state.status}."),
        )

    def result(self) -> ResultIR:
        """Return terminal evidence or execute bounded attempts until terminal."""
        state = self.store.load_state(self.job_id)
        if state.status in {"completed", "partially_completed"}:
            ref = self.store.load_result_ref(self.job_id)
            if ref is None:
                raise CASCAQitRuntimeError(
                    "Completed persistent Job has no Result reference.",
                    code="JOB_RESULT_REF_MISSING",
                    stage="backend",
                )
            result = self.store.results.read(ref)
            if not isinstance(result, ResultIR):
                raise CASCAQitRuntimeError(
                    "Single persistent Job restored a non-ResultIR artifact.",
                    code="JOB_RESULT_KIND_MISMATCH",
                    stage="backend",
                )
            return result
        if state.status == "failed":
            self._raise_persisted_failure()
        if state.status in {"cancelled", "expired"}:
            raise CASCAQitRuntimeError(
                f"{state.status.capitalize()} persistent local Job has no result.",
                code=(
                    "LOCAL_EXECUTION_JOB_CANCELLED"
                    if state.status == "cancelled"
                    else "LOCAL_EXECUTION_JOB_EXPIRED"
                ),
                stage="backend",
                object_path="job.state",
            )

        while True:
            state = self.store.load_state(self.job_id)
            if state.status == "running":
                outcomes = self.store.list_outcomes(self.job_id)
                if not outcomes or outcomes[-1].attempt_index < state.attempt_count:
                    self._recover_interrupted_attempt(state.attempt_count)
                    continue
            attempt_index = state.attempt_count + 1
            policy = self.definition.retry_policy
            if attempt_index > policy.max_attempts:
                self._raise_persisted_failure()
            started_at = self._clock()
            claim = self.store.acquire_claim(
                self.job_id,
                owner_id=self._owner_id,
                now=started_at,
                lease_seconds=self._lease_seconds,
            )
            execution_spec = self.definition.execution_spec()
            attempt = JobAttemptIR(
                job_id=self.job_id,
                attempt_index=attempt_index,
                claim_token_hash=claim.token_hash,
                definition_hash=self.definition.definition_hash,
                program_hash=self.program_hash,
                parameter_bind_hash=self.definition.parameter_bind_hash,
                seed=int(execution_spec["seed"]),
                started_at=started_at,
            )
            self.store.start_attempt(attempt, claim_token=claim.token)
            try:
                result = self._runner_factory().result()
            except Exception as exc:
                finished_at = self._clock()
                error_ref = _error_ref(
                    self.job_id,
                    attempt_index,
                    exc,
                    policy_override=policy.is_retryable_code(
                        getattr(exc, "code", type(exc).__name__.upper())
                    ),
                    created_at=finished_at,
                )
                can_retry = error_ref.retryable and attempt_index < policy.max_attempts
                outcome = JobAttemptOutcomeIR(
                    job_id=self.job_id,
                    attempt_index=attempt_index,
                    status=(
                        "retryable_failure"
                        if error_ref.retryable
                        else "non_retryable_failure"
                    ),
                    finished_at=finished_at,
                    error_ref_id=error_ref.error_ref_id,
                )
                self.store.finish_failure(
                    error_ref,
                    outcome,
                    claim_token=claim.token,
                    terminal=not can_retry,
                )
                if not can_retry:
                    raise
                self._sleeper(policy.attempt_backoff_seconds(attempt_index + 1))
                continue

            finished_at = self._clock()
            result_ref = self.store.results.write(
                result,
                job_id=self.job_id,
                attempt_index=attempt_index,
                created_at=finished_at,
            )
            outcome = JobAttemptOutcomeIR(
                job_id=self.job_id,
                attempt_index=attempt_index,
                status="completed",
                finished_at=finished_at,
                result_ref_id=result_ref.ref_id,
            )
            self.store.finish_success(
                result_ref,
                outcome,
                claim_token=claim.token,
            )
            return result

    def cancel(self) -> None:
        self.store.cancel(self.job_id, event_time=self._clock())

    def _raise_persisted_failure(self) -> NoReturn:
        error_ref = self.store.load_last_error_ref(self.job_id)
        if error_ref is None:
            raise CASCAQitRuntimeError(
                "Failed persistent Job has no error reference.",
                code="JOB_ERROR_REF_MISSING",
                stage="backend",
            )
        raise PersistedJobFailure(error_ref=error_ref)

    def _recover_interrupted_attempt(self, attempt_index: int) -> None:
        """Reclaim stale running work as immutable interrupted evidence."""
        event_time = self._clock()
        claim = self.store.acquire_claim(
            self.job_id,
            owner_id=self._owner_id,
            now=event_time,
            lease_seconds=self._lease_seconds,
        )
        error_ref = JobErrorRefIR(
            error_ref_id=f"error-ref.{self.job_id}.{attempt_index}.interrupted",
            job_id=self.job_id,
            attempt_index=attempt_index,
            category="backend",
            code="JOB_ATTEMPT_INTERRUPTED",
            message="Previous process stopped before committing an attempt outcome.",
            retryable=True,
            exception_type="InterruptedProcess",
            created_at=event_time,
        )
        outcome = JobAttemptOutcomeIR(
            job_id=self.job_id,
            attempt_index=attempt_index,
            status="interrupted",
            finished_at=event_time,
            error_ref_id=error_ref.error_ref_id,
        )
        self.store.finish_failure(
            error_ref,
            outcome,
            claim_token=claim.token,
            terminal=attempt_index >= self.definition.retry_policy.max_attempts,
        )


def _error_ref(
    job_id: str,
    attempt_index: int,
    exc: Exception,
    *,
    policy_override: bool | None,
    created_at: str,
) -> JobErrorRefIR:
    if isinstance(exc, CASCAQitError):
        category = exc.category
        code = exc.code
        retryable = exc.retryable
        metadata = exc.metadata
    else:
        category = "runtime"
        code = type(exc).__name__.upper()
        retryable = False
        metadata = {}
    if policy_override is not None:
        retryable = policy_override
    message = (str(exc) or type(exc).__name__)[:2048]
    digest = hashlib.sha256(
        f"{job_id}:{attempt_index}:{code}:{message}".encode()
    ).hexdigest()
    return JobErrorRefIR(
        error_ref_id=f"error-ref.{digest}",
        job_id=job_id,
        attempt_index=attempt_index,
        category=category,
        code=code,
        message=message,
        retryable=retryable,
        exception_type=type(exc).__name__,
        created_at=created_at,
        metadata=metadata,
    )


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _not_before(candidate: str, lower_bound: str) -> str:
    """Keep persisted lifecycle events ordered after the frozen definition."""
    def parse(value: str) -> datetime:
        normalized = value[:-1] + "+00:00" if value.endswith("Z") else value
        return datetime.fromisoformat(normalized)

    return lower_bound if parse(candidate) < parse(lower_bound) else candidate
